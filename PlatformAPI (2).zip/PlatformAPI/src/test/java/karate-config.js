function fn() {
GExecutionId= "";
  var config = {
	GExecutionId:"SomeValue",
    testEndPoint : 'https://cs2ne.contentservice.net/api/v1/assignments',
    AuthURL :'https://eco-ne.contentservice.net/auth/v1/token'
  }
  karate.configure('connectTimeout', 5000);
  karate.configure('readTimeout', 5000);
  return config;
}