function readFile(args){	
	var JavaFileReader1 = Java.type('features.jsRepo.JSONUpdate');
		var JSUpdate = new JavaFileReader1();
		console.log("Hello from JS file");
		console.log(args.Key);
		return JSUpdate.Update_Json(args.Key,args.Value);
}