package features.jsRepo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Paths;
import java.util.Map;
import java.util.Scanner;

import org.json.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.oracle.truffle.api.impl.TVMCI.Test;

import ch.qos.logback.core.net.SyslogOutputStream;

public class JSONUpdate {	
	@SuppressWarnings("unchecked")
	public void Update_Json(String Key, String Val) throws IOException 
    {      	
		
		ObjectMapper mapper = new ObjectMapper();
        Map root =  mapper.readValue(new File("src/test/java/features/resources/LimitsUpload.json"), Map.class);
        System.out.println("Hello from JSONUpdate java"+Key+Val);
   //    root.replace("id", "Test");
        root.replace(Key, Val);
        try {
        		mapper.writeValue(new File("src/test/java/features/resources/LimitsUpload.json"), root);
        }
        catch(Exception e) {
        	e.printStackTrace();
        }
      }
	
	public String Read_EID() throws FileNotFoundException
	{
		File file = new File("src/test/java/features/jsRepo/Eid.txt");
		Scanner scan = new Scanner(file);
	//	System.out.println(scan.nextLine());
		return scan.nextLine();
	}
	public void Write_EID(String args) throws IOException
	{
		FileWriter file= new FileWriter("src/test/java/features/jsRepo/Eid.txt");
		file.write(args);
		file.close();
		
	}
 }

//Convert Json to HashMap

/*		Map<?, ?> map;
try {
    // create object mapper instance
    ObjectMapper mapper = new ObjectMapper();

    // convert JSON file to map
    map = mapper.readValue(Paths.get("src/test/java/features/resources/AppDefinitionUpload.json").toFile(), Map.class);

    // print map entries
    for (Map.Entry<?, ?> entry : map.entrySet()) {
        System.out.println(entry.getKey() + "=" + entry.getValue());
    }

} catch (Exception ex) {
    ex.printStackTrace();
}*/

/*   root.put(key,val_newer);
try (FileWriter file = new FileWriter("json_file")) 
{
        file.write(map.toString());
        System.out.println("Successfully updated json object to file...!!");
}*/


// Writing file as String

/*    String val_older = root.getString(key);
System.out.println(val_older);/

/*    //Compare values
if(!val_newer.equals(val_older))
{
  //Update value in object
   root.put(key,val_newer);*/

   //Write into the file

/*      try (FileWriter file = new FileWriter("src/test/java/features/resources/AppDefinitionUpload1.json")) 
    {
        file.write(root.toString());
        System.out.println("Successfully updated json object to file...!!");
    }*/

