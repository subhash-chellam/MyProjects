package features.jsRepo;



import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import com.opencsv.CSVWriter;



public class fileList
{

	public List<String> fileListinFolder1() throws IOException
	{
		List<String> FL = new ArrayList<String>();
		String[] Letter = null;
		File[] files = new File(System.getProperty("user.dir")+"/src/test/java/features/jsRepo/").listFiles();
		System.out.println(System.getProperty("user.dir")+"/src/test/java/features/jsRepo/");
		FileWriter writer = new FileWriter(System.getProperty("user.dir")+"/src/test/java/features/jsRepo/filelist.csv");
		CSVWriter cw = new CSVWriter(writer);
		String[] header = {"File Name"};
		cw.writeNext(header);
		for(File file:files)
		{
			System.out.println(file.getName());
			System.out.println(file.getName().substring(file.getName().length()-5));
			if (file.getName().substring(file.getName().length()-5).equalsIgnoreCase(".json")) {
				FL.add(file.getName());
				Letter[0] = file.getName();
				System.out.println(Letter[0]);
				cw.writeNext(Letter);}
		}

		cw.close();
		return FL;
	}
	
	@SuppressWarnings("null")
	public List<String> fileListinFolder() throws IOException
	{
		List<String> FL = new ArrayList<String>();
		int j =0;
		File[] files = new File(System.getProperty("user.dir")+"/src/test/java/features/jsRepo/").listFiles();
		System.out.println(System.getProperty("user.dir")+"/src/test/java/features/jsRepo/");
		FileWriter OutputFile = new FileWriter(System.getProperty("user.dir")+"/src/test/java/features/jsRepo/filelist.csv");
		PrintWriter writer = new PrintWriter(new File(System.getProperty("user.dir")+"/src/test/java/features/jsRepo/filelist2.csv"));
		CSVWriter writter1 = new CSVWriter(OutputFile);
		String header = "FileName";
		String[] body= null;
		writer.write(header);
		writer.write("\n");
		for(File file:files)
		{
			System.out.println(file.getName());
			System.out.println(file.getName().substring(file.getName().length()-5));
			if (file.getName().substring(file.getName().length()-5).equalsIgnoreCase(".json")) 
				FL.add(file.getName()); 
		}
		System.out.println("File Lenghth" + FL.size());
		for (int i=0;i<FL.size();i++) {
			System.out.println(String.valueOf(FL.get(i)));
			writer.write(String.valueOf(FL.get(i)));
			writer.write("\n");
			
		}
		writer.close();
		return FL;
	}
}