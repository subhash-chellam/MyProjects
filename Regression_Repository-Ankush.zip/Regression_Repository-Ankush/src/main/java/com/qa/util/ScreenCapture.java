package com.qa.util;

import java.awt.Robot;
import java.awt.event.KeyEvent;

public class ScreenCapture 
{
	String path = "C:\\Users\\insgo1\\PycharmProjects\\ScreenCapture";
	public static Process process;
	public void screen()
	{
		try 
		{
			String comma = "cd "+path +" && python main.py";
			ProcessBuilder builder = new ProcessBuilder("cmd.exe","/c", comma);
			process = builder.start();
						
		} 
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}
	}
	
	public void stopRecording()
	{
		try
		{
			Thread.sleep(2000);
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_ESCAPE);
			//robot.keyRelease(KeyEvent.VK_ESCAPE);
		}
		catch(Exception e)
		{
			
		}
		
	}
	
	

}
