package com.qa.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.w3c.dom.Document;

import com.qa.pages.User;

public class reuseableCode extends TestBase {

	public JSONObject getjsonObject(String key)
	{
		JSONParser jsonParser = new JSONParser();
	    JSONObject jsonparmeter;
	    JSONObject tableDetails = null;
		
		try (FileReader reader = new FileReader(  System.getProperty("user.dir")+prop.getProperty("downloadPath")+"\\ValidateTableDetails"+prop.getProperty("environment")+".json"))
		{
			//Read JSON file
			Object obj = jsonParser.parse(reader);
			
			jsonparmeter = (JSONObject) obj;
			tableDetails = (JSONObject) jsonparmeter.get(key);
			
		
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return tableDetails;
	}
	
	public static String getMailTemplate(String Mail)
	{
		String mail=null;
		try   
		{  
			String env=prop.getProperty("environment");
		//creating a constructor of file class and parsing an XML file  
		File file = new File(System.getProperty("user.dir") + "\\src\\main\\java\\com\\qa\\config\\mail.Templates\\"+env+"MailTemplates.xml");  
		//an instance of factory that gives a document builder  
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
		//an instance of builder to parse the specified xml file  
		DocumentBuilder db = dbf.newDocumentBuilder();  
		Document doc = db.parse(file);  
		doc.getDocumentElement().normalize();  
		 mail = doc.getElementsByTagName(Mail).item(0).getTextContent();
		return mail;
		}
		// nodeList is not iterable, so we are using for loop  
		
		catch (Exception e)   
		{  
		e.printStackTrace();  
		}  
		return mail;
	}

	public void createJsonFile(JSONArray userDetails,String arrayName, String fileName) {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(arrayName, userDetails);
	    try {
	        FileWriter file = new FileWriter(System.getProperty("user.dir") + "\\src\\test\\java\\resources\\" + fileName + ".json");
	          file.write(jsonObject.toJSONString());
	          file.close();
	       } catch (IOException e) {
	          // TODO Auto-generated catch block
	          e.printStackTrace();
	       }		
		
	}
	
	public void validateTable(List<String> text, List<WebElement> Columns) throws Exception
	{
		Thread.sleep(5000);
		Thread.sleep(3000);
		
		int count = 0;
		for(WebElement tt : Columns){
			System.out.println(tt.getAttribute("innerText"));
			Assert.assertEquals(text.get(count).toUpperCase(), tt.getAttribute("innerText"));
			count++;
		}

	}

	public void waitfor1min(int d)
	{
		try {
			Thread.sleep(60000*d);

		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	

	public static void waitforsec(int d)
	{
		try {
			Thread.sleep(1000*d);

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public static String getUserEmail()
	{
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		System.out.println(formatDate + "&&" + date);
		//formatDate = new java.util.Date().toString();
		date = date.replace(" ", "").replace(":", "").replace("-", "");
		String email =prop.getProperty("userDomain").replace("<adduniquestringhere>",date);
		return email;
	}
	
	public static String getUserEmail(String formattedEmail)
	{
		String  email =prop.getProperty("userDomain").replace("<adduniquestringhere>",formattedEmail);
		return email;
	}
	public void validatethedetails(String header,String tableHeader,String value,String tablerow,String EmailHeader)
	{
		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(tableHeader))));
		List<WebElement> tableRows = driver.findElements(By.xpath(tablerow));
		
		Assert.assertEquals(tableRows.get(getHeaderPosition(EmailHeader,tableHeader)-1).getText(), User.userEmail);
		Assert.assertEquals(tableRows.get(getHeaderPosition(header,tableHeader)-1).getText(), value);
	}

	public void validatethedetails(String header,String tableHeader,String value,String tablerow)
	{
		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(tableHeader))));
		List<WebElement> tableRows = driver.findElements(By.xpath(tablerow));
		
		System.out.println(tableRows.size());
		System.out.println(header);

		System.out.println(tableHeader);
		System.out.println(tableRows.get(getHeaderPosition(header,tableHeader)-1).getText());
		Assert.assertEquals(tableRows.get(getHeaderPosition(header,tableHeader)-1).getText(), value);
	}

	public void scrollLeft()
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
		executor.executeScript("arguments[0].scrollLeft = -arguments[0].offsetWidth", scrollArea);
	}
	public int getHeaderPosition(String header,String tableHeader)
	{
		
		int columnCount = 0;
		try {
			Thread.sleep(5000);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(tableHeader))));
		List<WebElement> tableHeaderRows = driver.findElements(By.xpath(tableHeader));
		for(int i = 1; i <=tableHeaderRows.size(); i++)
		{
			String headerName = driver.findElement(By.xpath(tableHeader + "[" + i +"]")).getText();
			if(headerName.trim().equalsIgnoreCase(header))
			{
				columnCount = i;
				break;				
			}				
		}
		int counter = 0;
	
		System.out.println("The column position for " + header +" is " + columnCount);
		}
		catch(Exception e) {
			Assert.fail(tableHeader);
		}
		return columnCount;
	}
	
	public void createJsonFile() {
		JSONObject jsonObject = new JSONObject();
		try {
	        FileWriter file = new FileWriter(System.getProperty("user.dir") + "\\src\\test\\java\\resources\\MailUsers2.json");
	          file.write(jsonObject.toJSONString());
	          file.close();
	       } catch (IOException e) {
	          // TODO Auto-generated catch block
	          e.printStackTrace();
	       }		
		
	}
}
