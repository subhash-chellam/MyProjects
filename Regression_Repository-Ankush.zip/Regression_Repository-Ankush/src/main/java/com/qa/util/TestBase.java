package com.qa.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.FluentWait;


import io.cucumber.java.Scenario;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.List;
public class TestBase 
{

	  
	//String urlStg = "https://stg-rqi1stop.laerdalblr.in/admin";
	static String chromePath = System.getProperty("user.dir");
	public static WebDriver driver;
	public static Properties prop,propDetails;	
	public static int timeout,pagload;
//	static public FluentWait wait ;
	protected static   FluentWait wait;
	public static Scenario scenario;
	public static JSONObject courseListName;
	public static TestUtils testUtils = new TestUtils();
	public static reuseableCode reuse=new reuseableCode();
	public TestBase()
	{

		try 
		{
			if(prop == null)
			{
				prop = new Properties();
				FileInputStream fis = new FileInputStream
						(System.getProperty("user.dir") + "\\src\\main\\java\\com\\qa\\config\\config.properties");
				prop.load(fis);
			}
		

		}
		catch (IOException e) {
			e.getMessage();
		}
	}

	public static void initialization()
	{
		//Object wait;
		String browserName = prop.getProperty("browser");
		timeout=Integer.parseInt( prop.getProperty("elementWait"));
		pagload=Integer.parseInt( prop.getProperty("pageLoad"));

		//	1234
		//		4567
		if(browserName.equals("chrome"))
		{
			//To set custom download path
			System.setProperty("webdriver.chrome.driver", chromePath + prop.getProperty("ChromeDriver"));
			String defaultPath = System.getProperty("user.dir") + prop.getProperty("downloadPath");
			ChromeOptions options = new ChromeOptions();
			
			options.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			options.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
			HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
			chromePrefs.put("profile.default_content_settings.popups", 0);
			chromePrefs.put("download.default_directory", defaultPath);
			//To remove save password popup
			chromePrefs.put("credentials_enable_service", false);
			chromePrefs.put("profile.password_manager_enabled", false);
			options.setExperimentalOption("prefs", chromePrefs);
//						options.addArguments("--headless");
			options.addArguments("--window-size=1920,1080");
			options.addArguments("--disable-gpu");
			options.addArguments("--no-sandbox");
			options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
			options.setExperimentalOption("useAutomationExtension", false);
       	LoggingPreferences logPrefs = new LoggingPreferences();
	        logPrefs.enable(LogType.BROWSER, Level.ALL);
	        options.setCapability(CapabilityType.LOGGING_PREFS, logPrefs);
	     	driver = new ChromeDriver(options);
	     	
			
		
			coursesNamejson();
			

		}
		else if(browserName.equals("chrome_headless"))
		{
			//To set custom download path
			System.setProperty("webdriver.chrome.driver", chromePath + prop.getProperty("ChromeDriver"));
			String defaultPath = System.getProperty("user.dir") + prop.getProperty("downloadPath");
			ChromeOptions options = new ChromeOptions();
			options.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			options.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
			HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
			chromePrefs.put("profile.default_content_settings.popups", 0);
			chromePrefs.put("download.default_directory", defaultPath);
			//To remove save password popup
			chromePrefs.put("credentials_enable_service", false);
			chromePrefs.put("profile.password_manager_enabled", false);
			options.setExperimentalOption("prefs", chromePrefs);
			options.addArguments("--headless");
			options.addArguments("--window-size=1920,1080");
			options.addArguments("--disable-gpu");
			options.addArguments("--no-sandbox");
			options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
			options.setExperimentalOption("useAutomationExtension", false);
			LoggingPreferences logPrefs = new LoggingPreferences();
	        logPrefs.enable(LogType.BROWSER, Level.ALL);
	        options.setCapability(CapabilityType.LOGGING_PREFS, logPrefs);
	     	driver = new ChromeDriver(options);
	        ((RemoteWebDriver) driver).setLogLevel(Level.INFO);
			
			coursesNamejson();

		}

		if(!prop.getProperty("printConsole").contains("true"))
		{
			try
			{
			 File file = new File(System.getProperty("user.dir") + "\\Report\\Console.log");
		      //Instantiating the PrintStream class
		      PrintStream stream = new PrintStream(file);
		      System.setOut(stream);
			}
			catch(Exception e)
			{
				
			}
		      
		}
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		if(System.getProperty("environment")==null)
		{
			System.setProperty("environment", prop.getProperty("environment") );
		}
		else
		{
			System.out.println("Environment updated");
			prop.put("environment", System.getProperty("environment"))	;
		}
		//		driver.get(prop.getProperty("url"+prop.getProperty("environment")));
		driver.get(prop.getProperty("url"+prop.getProperty("environment")));
		



		 
		wait	 = new FluentWait(driver);
		//Specify the timout of the wait
		wait.withTimeout(timeout, TimeUnit.MILLISECONDS);

		wait.pollingEvery(250, TimeUnit.MILLISECONDS);
		wait.ignoring(NoSuchElementException.class);
		wait.ignoring(TimeoutException.class);
	    // Mentioning type of Log 
      
	}

	public static void initializationEndUser()
	{
		String browserName = prop.getProperty("browser");
		if(browserName.equals("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", chromePath);
			driver = new ChromeDriver();

		}

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get(prop.getProperty("EndUserURL"));

	}
	 public static String takeSnapShot(String file) throws Exception{

	        //Convert web driver object to TakeScreenshot

	        TakesScreenshot scrShot =((TakesScreenshot)driver);

	        //Call getScreenshotAs method to create image file

	                File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

	            //Move image file to new destination

	                String date = new java.util.Date().toString();
	        		date = date.replace(" ", "");
	        		date = date.replace(":", "");
	        		LocalDateTime myDateObj = LocalDateTime.now();
	      		    DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("yyyyMMMdd");

	      		    String formattedDate = myDateObj.format(myFormatObj);
	       	        
	                File DestFile=new File(System.getProperty("user.dir") + "\\target\\Screenshot\\"+formattedDate+"\\Screenshot_"+file+date+".png");

	                //Copy file at destination

	                FileUtils.copyFile(SrcFile, DestFile);
	                
//	                driver.quit();
	                return DestFile.getAbsolutePath();

	    }
		public static void networkLog()
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String log= js.executeScript("return window.performance.getEntries();").toString();
			System.out.println("Test log"+log);
//		 	JSONParser jsonParser = new JSONParser();
//		 	Object obj = null;
//			try {
//				obj = jsonParser.parse(log);
//			} catch (ParseException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			
//		 	 JSONObject  courseListName	= (JSONObject) obj;
//				
//		;System.out.println(courseListName.toJSONString());
			  String[] preformance=log.split("},");
			
			  for(int i=0;i<preformance.length;i++)
			  {
				  if(preformance[i].contains("initiatorType=xmlhttprequest"))
				  System.out.println("Response "+preformance[i].replace("{", ""));
			  }
			  
				  
		}


	public static void coursesNamejson()
	{


		JSONParser jsonParser = new JSONParser();

		try (FileReader reader = new FileReader( System.getProperty("user.dir")+prop.getProperty("downloadPath")+"\\coursesName"+prop.getProperty("environment")+".json", StandardCharsets.UTF_8))
		{
			//Read JSON file
			Object obj = jsonParser.parse(reader);
			
			courseListName = (JSONObject) obj;

			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}



	}




}
