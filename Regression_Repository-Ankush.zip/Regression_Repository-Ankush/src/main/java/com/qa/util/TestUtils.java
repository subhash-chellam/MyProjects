package com.qa.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.w3c.dom.Document;

import junit.framework.Assert;

public class TestUtils extends TestBase {

	// Author : Raghoottam Padaki
	public TestUtils() {
		PageFactory.initElements(driver, this);
	}

	// Product table
	public String TableXpath = "//table[@id='customer-admin-list']//tbody//tr[@role='row'][";
	public String Row_BeforeXpath = "//table[@id='customer-admin-list']//tbody//tr[";
	public static String AfterXpath = "]";
	public static String Column_BeforeXpath = "//td[";
	public String Actions = "//a[";
	public String NotificationLogTable = "//table[@id='reports']//tr";

	// Notification table
	public String AdminNTableXpath = "//div[@class='main_cont']/div/strong//following::table/tbody/tr[";
	public static String StudentNTableXpath = "//div[@class='main_cont']/table[@aria-describedby='table']/tbody/tr[";

	public void SelectTheElementFromTable(List<WebElement> listvalue, String value) {

		try {
			for (int i = 0; i < listvalue.size(); i++) {
				if (listvalue.get(i).toString().equals(value)) {
					listvalue.get(i).click();
					String quantity = listvalue.get(i).getText();
					System.out.println(" The clicked element" + quantity);
					Assert.assertEquals(quantity, value);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String SelectTheValueFromTheTable(List<WebElement> rowCount, String cellValueToCompare, int ColumntoIterate,
			int ToGetvalueFromcolumn) {
		String value = null;
		try {

			Thread.sleep(3000);

			int rowSize = rowCount.size();

			for (int i = 1; i <= rowSize; i++) {
				// String colxpath = TableXpath + i + AfterXpath + Column_BeforeXpath +
				// ColumntoIterate + AfterXpath;
				String colxpath = Row_BeforeXpath + i + AfterXpath + Column_BeforeXpath + ColumntoIterate + AfterXpath;

				WebElement CellElement = driver.findElement(By.xpath(colxpath));
				System.out.println(" The cellElement is : " + CellElement.getText());
				System.out.println(" The cellElement is : " +cellValueToCompare);
				CellElement.click();
				if (CellElement.getText().equalsIgnoreCase(cellValueToCompare)) {
					// String cellvalue = TableXpath + i + AfterXpath + Column_BeforeXpath +
					// ToGetvalueFromcolumn + AfterXpath;
					String cellvalue = Row_BeforeXpath + i + AfterXpath + Column_BeforeXpath + ToGetvalueFromcolumn
							+ AfterXpath;
					WebElement textxpath = driver.findElement(By.xpath(cellvalue));
					System.out.println("textxpath is :" + textxpath.getText());
					value = textxpath.getText();
					break;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return value;
	}

	public void AdminNotificationsTable(List<WebElement> rowCount, String cellValueToCompare, int ColumntoIterate,
			int ToGetvalueFromcolumn) {

		try {

			Thread.sleep(3000);

			int rowSize = rowCount.size();
			for (int i = 1; i <= rowSize; i++) {
				String colxpath = AdminNTableXpath + i + AfterXpath + Column_BeforeXpath + ColumntoIterate + AfterXpath;
				WebElement CellElement = driver.findElement(By.xpath(colxpath));
				CellElement.click();
				if (CellElement.getText().equalsIgnoreCase(cellValueToCompare)) {
					String cellvalue = AdminNTableXpath + i + AfterXpath + Column_BeforeXpath + ToGetvalueFromcolumn
							+ AfterXpath;

					WebElement checkAttributetextxpath = driver.findElement(By.xpath(cellvalue));
					System.out.println("checkAttributetextxpath is :" + checkAttributetextxpath.getText()); // WebElement
																											// textxpath
																											// =
					driver.findElement(By.xpath(cellvalue));
					String inputAttribute = cellvalue + "//input";
					System.out.println(" The input attribute" + inputAttribute);

					// Input Attribute
					WebElement textxpath = driver.findElement(By.xpath(inputAttribute));
					System.out.println(" textxpath " + textxpath);
					String inputcheckedvalue = textxpath.getAttribute("checked");
					System.out.println(" The checkedValue is " + inputcheckedvalue);
					String truevalue = "true";
					if (inputcheckedvalue != null) {
						break;
					} else {
						checkAttributetextxpath.click();
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void AdminNotificationsOff(List<WebElement> rowCount, String cellValueToCompare, int ColumntoIterate,
			int ToGetvalueFromcolumn) {
		try {
			Thread.sleep(3000);
			int rowSize = rowCount.size();
			for (int i = 1; i <= rowSize; i++) {
				String colxpath = AdminNTableXpath + i + AfterXpath + Column_BeforeXpath + ColumntoIterate + AfterXpath;
				WebElement CellElement = driver.findElement(By.xpath(colxpath));
				// System.out.println(" The cellElement is : " + CellElement.getText());
				CellElement.click();
				if (CellElement.getText().equalsIgnoreCase(cellValueToCompare)) {
					String cellvalue = AdminNTableXpath + i + AfterXpath + Column_BeforeXpath + ToGetvalueFromcolumn
							+ AfterXpath;
					WebElement checkAttributetextxpath = driver.findElement(By.xpath(cellvalue));
					System.out.println("checkAttributetextxpath is :" + checkAttributetextxpath.getText()); // WebElement
																											// textxpath
																											// =
					driver.findElement(By.xpath(cellvalue));
					String inputAttribute = cellvalue + "//input";
					System.out.println(" The input attribute" + inputAttribute);
					// String checkAttribute = cellvalue;

					// Input Attribute
					WebElement textxpath = driver.findElement(By.xpath(inputAttribute));
					System.out.println(" textxpath " + textxpath);
					String inputcheckedvalue = textxpath.getAttribute("checked");
					System.out.println(" The checkedValue is " + inputcheckedvalue);
					String truevalue = "true";
					// String nullvalue = "null";
					if (inputcheckedvalue != null) {
						checkAttributetextxpath.click();
						break;
					} else {
						// checkAttributetextxpath.click();
					}

				}
			}

		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	@SuppressWarnings("unlikely-arg-type")
	public void StudentNotificationsTable(List<WebElement> rowCount, String cellValueToCompare, int ColumntoIterate,
			int ToGetvalueFromcolumn) {

		try {

			Thread.sleep(3000);
			int rowSize = rowCount.size();
			for (int i = 1; i <= rowSize; i++) {
				String colxpath = StudentNTableXpath + i + AfterXpath + Column_BeforeXpath + ColumntoIterate
						+ AfterXpath;
				WebElement CellElement = driver.findElement(By.xpath(colxpath));
				System.out.println(" colxpath" + colxpath);
				System.out.println(" CellElement" + CellElement);
				// System.out.println(" The cellElement is : " + CellElement.getText());
				CellElement.click();
				System.out.println(" The cellElement is : " + CellElement.getText());
				if (CellElement.getText().equalsIgnoreCase(cellValueToCompare)) {
					String cellvalue = StudentNTableXpath + i + AfterXpath + Column_BeforeXpath + ToGetvalueFromcolumn
							+ AfterXpath;
					WebElement checkAttributetextxpath = driver.findElement(By.xpath(cellvalue));
					System.out.println("checkAttributetextxpath is :" + checkAttributetextxpath.getText());
					String inputAttribute = cellvalue + "//input";
					System.out.println(" The input attribute" + inputAttribute);

					// Input Attribute
					WebElement textxpath = driver.findElement(By.xpath(inputAttribute));
					System.out.println(" textxpath " + textxpath);
					String inputcheckedvalue = textxpath.getAttribute("checked");
					System.out.println(" The checkedValue is " + inputcheckedvalue);
					String truevalue = "true";
					if (inputcheckedvalue != null) {
						break;
					} else {
						checkAttributetextxpath.click();
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void StudentNotificationsOff(List<WebElement> rowCount, String cellValueToCompare, int ColumntoIterate,
			int ToGetvalueFromcolumn) {
		try {
			Thread.sleep(3000);

			int rowSize = rowCount.size();
			for (int i = 1; i <= rowSize; i++) {
				String colxpath = StudentNTableXpath + i + AfterXpath + Column_BeforeXpath + ColumntoIterate
						+ AfterXpath;
				WebElement CellElement = driver.findElement(By.xpath(colxpath));
				CellElement.click();
				if (CellElement.getText().equalsIgnoreCase(cellValueToCompare)) {
					String cellvalue = StudentNTableXpath + i + AfterXpath + Column_BeforeXpath + ToGetvalueFromcolumn
							+ AfterXpath;
					WebElement checkAttributetextxpath = driver.findElement(By.xpath(cellvalue));
					System.out.println("checkAttributetextxpath is :" + checkAttributetextxpath.getText());
					String inputAttribute = cellvalue + "//input";
					System.out.println(" The input attribute" + inputAttribute);
					WebElement textxpath = driver.findElement(By.xpath(inputAttribute));
					System.out.println(" textxpath " + textxpath);
					String inputcheckedvalue = textxpath.getAttribute("checked");
					System.out.println(" The checkedValue is " + inputcheckedvalue);
					String truevalue = "true";
					if (inputcheckedvalue != null) {
						checkAttributetextxpath.click();
						break;
					} else {
						// checkAttributetextxpath.click();
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public String SelectActionsForProduct(List<WebElement> rowCount, String cellValueToCompare, int ColumntoIterate,
			int ToGetvalueFromcolumn, int selectActionsFromColumns) {

		String value = null;
		try {
			Thread.sleep(3000);

			int rowSize = rowCount.size();
			for (int i = 1; i <= rowSize; i++) {
				String colxpath = TableXpath + i + AfterXpath + Column_BeforeXpath + ColumntoIterate + AfterXpath;
				WebElement CellElement = driver.findElement(By.xpath(colxpath));
				System.out.println(" The cellElement is : " + CellElement.getText());
				CellElement.click();
				if (CellElement.getText().equalsIgnoreCase(cellValueToCompare)) {
					String cellvalue = TableXpath + i + AfterXpath + Column_BeforeXpath + ToGetvalueFromcolumn
							+ AfterXpath + Actions + selectActionsFromColumns + AfterXpath;
					WebElement textxpath = driver.findElement(By.xpath(cellvalue));
					textxpath.click();
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return value;
	}

	public static void selectFromTheList(List<WebElement> element, String value) {
		Iterator<WebElement> itr = element.iterator();
		boolean flg = false;
		while (itr.hasNext()) {
			WebElement clickelement = itr.next();
			if (clickelement.getText().equalsIgnoreCase(value)) {
				clickelement.click();
				flg = true;

				break;
			} else {
				 System.out.println("Element with value '" + value + "' not present in list");
			}
		}
		Assert.assertTrue(flg);
	}
	
	
	public static void checkvalueisPresentInTheList(List<WebElement> element, String value) {
		Iterator<WebElement> itr = element.iterator();
		boolean flg = false;
		while (itr.hasNext()) {
			WebElement clickelement = itr.next();
			if (clickelement.getText().equalsIgnoreCase(value)) {
				clickelement.click();
				flg = true;

				break;
			} else {
				 System.out.println("Element with value '" + value + "' not present in list");
			}
		}
	}
	

	// div[@class='main_cont']/table[@aria-describedby='table']/tbody/tr[1]/td[5]
	public static String EditTemplateInStudentNotifcationsTable(List<WebElement> rowCount, String cellValueToCompare,
			int ColumntoIterate, int ToGetvalueFromcolumn) {

		String value = null;

		try {
			Thread.sleep(3000);
			int rowSize = rowCount.size();
			for (int i = 1; i <= rowSize; i++) {
				String colxpath = StudentNTableXpath + i + AfterXpath + Column_BeforeXpath + ColumntoIterate
						+ AfterXpath;
				WebElement CellElement = driver.findElement(By.xpath(colxpath));
				System.out.println(" The cellElement is : " + CellElement.getText());
				CellElement.click();
				if (CellElement.getText().equalsIgnoreCase(cellValueToCompare)) {
					String cellvalue = StudentNTableXpath + i + AfterXpath + Column_BeforeXpath + ToGetvalueFromcolumn
							+ AfterXpath;
					WebElement textxpath = driver.findElement(By.xpath(cellvalue));
					textxpath.click();
					break;
				}
			}

		} catch (Exception e) {
			// TODO: handle exception
		}
		return value;
	}

	public static void clearWebField(WebElement element) {
		while (!element.getAttribute("value").equals("")) {
			element.sendKeys(Keys.BACK_SPACE);
		}
	}

	public static String getMailTemplate(String Mail) {
		String mail = null;
		try {
			String env = prop.getProperty("environment");
			// creating a constructor of file class and parsing an XML file
			File file = new File(System.getProperty("user.dir") + "\\src\\main\\java\\com\\qa\\config\\mail.Templates\\"
					+ env + "MailTemplates.xml");
			// an instance of factory that gives a document builder
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			// an instance of builder to parse the specified xml file
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(file);
			doc.getDocumentElement().normalize();
			mail = doc.getElementsByTagName(Mail).item(0).getTextContent();
			return mail;
		}
		// nodeList is not iterable, so we are using for loop

		catch (Exception e) {
			e.printStackTrace();
		}
		return mail;
	}

	public static void excel(String ScenarioName,String Status,String errorLog,String FeatureName,String orgID,String path,String env)
	{
		 // Creating file object of existing excel file
        File xlsxFile = new File(System.getProperty("user.dir")+"//ExceptionandOrgLogFolder//AutomationReport.xlsx");
         
        //New students records to update in excel file
    
        try {
            //Creating input stream
            FileInputStream inputStream = new FileInputStream(xlsxFile);
             
            //Creating workbook from input stream
            Workbook workbook = WorkbookFactory.create(inputStream);
 
            //Reading first sheet of excel file
            Sheet sheet = null;
            if(FeatureName.contains("Smoke"))
            	sheet = 	workbook.getSheetAt(0);
            else
            	sheet = 	workbook.getSheetAt(1);
              	
            //Getting the count of existing records
            int rowCount = sheet.getLastRowNum();
            LocalDateTime myDateObj = LocalDateTime.now();
		    DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("yyyy-MMM-dd");

		    String formattedDate = myDateObj.format(myFormatObj);
            Object[][] data = {
                    {rowCount+1,ScenarioName, Status, errorLog,FeatureName, orgID,path,env,formattedDate}};
     
            for (Object[] rowdata : data) {
                 
                //Creating new row from the next row count
                Row row = sheet.createRow(++rowCount);
 
                int columnCount = 0;
 
                //Iterating student informations
                for (Object info : rowdata) {
                     
                    //Creating new cell and setting the value
                    Cell cell = row.createCell(columnCount++);
                    if (info instanceof String) {
                        cell.setCellValue((String) info);
                    } else if (info instanceof Integer) {
                        cell.setCellValue((Integer) info);
                    }
                    CellStyle style5 = workbook.createCellStyle();
                    
                    style5.setBorderBottom(BorderStyle.THIN);
                    style5.setBorderLeft(BorderStyle.THIN);
                    style5.setBorderRight(BorderStyle.THIN);
                    style5.setBorderTop(BorderStyle.THIN);
//                    DataFormat format = workbook.createDataFormat();
//                    
//                    style5.setDataFormat(format.getFormat("#0df23b"));
                    Font my_font=workbook.createFont();
                    
                    if(Status.equalsIgnoreCase("FAILED"))
                    my_font.setColor(Font.COLOR_RED);
                    
                    my_font.setFontName("Times New Roman");	
                    style5.setFont(my_font);

                    cell.setCellStyle(style5);
                    
                  
                }
            }
            //Close input stream
            inputStream.close();
 
            //Crating output stream and writing the updated workbook
            FileOutputStream os = new FileOutputStream(xlsxFile);
            workbook.write(os);
             
            //Close the workbook and output stream
            workbook.close();
            os.close();
             
            System.out.println("Excel file has been updated successfully.");
             
        } catch (EncryptedDocumentException | IOException e) {
            System.err.println("Exception while updating an existing excel file.");
            e.printStackTrace();
        }
	}
	
	public String SelectTheValueFromTheNotificationLogTable(List<WebElement> rowCount, String cellValueToCompare,
			int ColumntoIterate, int ToGetvalueFromcolumn) {
		String value = null;
		try {

			Thread.sleep(3000);

			int rowSize = rowCount.size();

			for (int i = 1; i <= rowSize; i++) {
				String colxpath = NotificationLogTable + i + AfterXpath + Column_BeforeXpath + ColumntoIterate
						+ AfterXpath;
				WebElement CellElement = driver.findElement(By.xpath(colxpath));
				System.out.println(" The cellElement is : " + CellElement.getText());
				CellElement.click();
				if (CellElement.getText().equalsIgnoreCase(cellValueToCompare)) {
					String cellvalue = NotificationLogTable + i + AfterXpath + Column_BeforeXpath + ToGetvalueFromcolumn
							+ AfterXpath;
					WebElement textxpath = driver.findElement(By.xpath(cellvalue));
					System.out.println("textxpath is :" + textxpath.getText());
					value = textxpath.getText();
					break;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return value;
	}

	public String Notitable = "//table[contains(@id,'reports')]//tbody/tr[";

	
	
	public String VerifyTheReportsStatus(List<WebElement> rowCount, String cellValueToCompare, int ColumntoIterate,
			int ToGetvalueFromcolumn) {
	    
		String getvalue = null;

	    try {
			Thread.sleep(3000);
			
			int rowSize = rowCount.size();
			
			for (int i = 1; i <= rowSize; i++) {
				// table[contains(@id,'reports')]//tbody/tr[1]/td[8]
				String colxpath = Notitable + i + AfterXpath + Column_BeforeXpath + ColumntoIterate + AfterXpath;
				WebElement CellElement = driver.findElement(By.xpath(colxpath));
				System.out.println(" The cellElement is : " + CellElement.getText());
				CellElement.click();
				if (CellElement.getText().equalsIgnoreCase(cellValueToCompare)) {
					String cellvalue = Notitable + i + AfterXpath + Column_BeforeXpath + ToGetvalueFromcolumn
							+ AfterXpath;
					WebElement textxpath = driver.findElement(By.xpath(cellvalue));
					System.out.println("textxpath is :" + textxpath.getText());
					getvalue = textxpath.getText();
					System.out.println( " The value is :"+getvalue);
					break;
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return getvalue;
	    
		
	}
	
	
	public String ClickOnCheckBox(List<WebElement> rowCount, String cellValueToCompare, int ColumntoIterate,
			int ToGetvalueFromcolumn) {
	    
		String getvalue = null;

	    try {
			
			Thread.sleep(3000);
			
			int rowSize = rowCount.size();
			
			for (int i = 1; i <= rowSize; i++) {
				// table[contains(@id,'reports')]//tbody/tr[1]/td[8]
				String colxpath = Notitable + i + AfterXpath + Column_BeforeXpath + ColumntoIterate + AfterXpath;
				WebElement CellElement = driver.findElement(By.xpath(colxpath));
				System.out.println(" The cellElement is : " + CellElement.getText());
				CellElement.click();
				if (CellElement.getText().equalsIgnoreCase(cellValueToCompare)) {
					String cellvalue = Notitable + i + AfterXpath + Column_BeforeXpath + ToGetvalueFromcolumn
							+ AfterXpath;
					WebElement textxpath = driver.findElement(By.xpath(cellvalue));
					System.out.println("textxpath is :" + textxpath.getText());
					 textxpath.click();
				//	System.out.println( " The value is :"+getvalue);
					break;
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return getvalue;
	    
		
	}
	
	

	
	public String VerifyAndClickOnCheckBoxReportsStatus(List<WebElement> rowCount, String cellValueToCompare, int ColumntoIterate,
			int ToGetvalueFromcolumn, String Status) {
	    
		String getvalue = null;

	    try {
			
			Thread.sleep(3000);
			
			int rowSize = rowCount.size();
			
			for (int i = 1; i <= rowSize; i++) {
				// table[contains(@id,'reports')]//tbody/tr[1]/td[8]
				String colxpath = Notitable + i + AfterXpath + Column_BeforeXpath + ColumntoIterate + AfterXpath;
				WebElement CellElement = driver.findElement(By.xpath(colxpath));
				System.out.println(" The cellElement is : " + CellElement.getText());
				CellElement.click();
				if (CellElement.getText().equalsIgnoreCase(cellValueToCompare)) {
					String cellvalue = Notitable + i + AfterXpath + Column_BeforeXpath + ToGetvalueFromcolumn
							+ AfterXpath;
					WebElement textxpath = driver.findElement(By.xpath(cellvalue));
					System.out.println("textxpath is :" + textxpath.getText());
					getvalue = textxpath.getText();
					System.out.println( " The value is :"+getvalue);
					if(getvalue.equalsIgnoreCase(Status)) {
						String checkvaluebox = Notitable + i + AfterXpath +  "//td[1]" ; 
							System.out.println(" checbox value :"+checkvaluebox);
						//table[contains(@id,'reports')]//tbody/tr[i]//td[
					WebElement checkBoxElement = driver.findElement(By.xpath(checkvaluebox));
					checkBoxElement.click();
					}
					break;
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return getvalue;
	    
		
	}
	

	public static void saveDetailsinFile(String key,String value)
	{
		try {
			 PropertiesConfiguration properties = new PropertiesConfiguration(System.getProperty("user.dir") +"\\src\\test\\java\\resources\\Featureparameters"+prop.get("environment")+".properties");
	       
			 properties.setProperty(key+prop.get("environment"),value);
			 
			 properties.save();
		 
		 } catch (Exception e) {
			System.out.println("Exception: " + e);
		} finally {
		}
		
	}

	
}
