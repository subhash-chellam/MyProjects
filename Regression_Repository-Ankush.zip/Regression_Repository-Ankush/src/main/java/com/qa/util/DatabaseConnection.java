package com.qa.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Properties;

import org.openqa.selenium.WebDriver;

public class DatabaseConnection {

	public static Properties prop;
	public static FileInputStream fis;
	public static Connection dbcon;
	public static Statement st;
	public static int Master_counter;

	@SuppressWarnings("restriction")
	public static String getUserName() throws Exception {

		/*Process exec = Runtime.getRuntime().exec("cmd /c wmic ComputerSystem get UserName".split(" "));
	      String user;
	        try (BufferedReader bw = new BufferedReader(new InputStreamReader(exec.getInputStream()))) {
	            String username = bw.readLine() + bw.readLine() + bw.readLine();
	            user = username.replaceAll("UserName ", "");
	        }*/

		com.sun.security.auth.module.NTSystem NTSystem = new com.sun.security.auth.module.NTSystem();
		String user = NTSystem.getName();
		return user;
	}

	public void insertMasterTableDetails() throws Exception {
		prop= new Properties();
		fis =new FileInputStream(System.getProperty("user.dir")+"/src/main/java/com/qa/config/inputs.properties");

		prop.load(fis);
		String BrowserName =prop.getProperty("browser");

		dbcon = DriverManager.getConnection("jdbc:mysql://lblr-prod-use1-rds-automation-testcase-executiontracker.cqndk3xkwl7s.us-east-1.rds.amazonaws.com:3306/ExecutionTracker", "naveen.b", "MpO0Qak1#baPAxg2!bYa5!1J");
		System.out.println("Database is connected !");
		st =  dbcon.createStatement();
		ResultSet res =  st.executeQuery("SELECT Max(Execution_id) as EID FROM `Execution_Master`");
		res.next();
		System.out.println(res.getInt(1));
		if(res.getInt(1)==0)
			Master_counter = 1;
		else
			Master_counter = res.getInt(1)+1;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		System.out.println(dtf.format(now));
		String query1 = "INSERT INTO Execution_Master (Execution_Id,Project_Name,Suite_Type,Execution_Start_Date,Execution_End_Date,Executed_By,Execution_Environment,Created_By,Created_On) VALUES ("+Master_counter+",'"+prop.getProperty("ProjectName")+"','"+prop.getProperty("SuitType")+"','"+dtf.format(now)+"','"+dtf.format(now)+"','"+getUserName()+"','"+TestBase.prop .getProperty("instance")+"','"+getUserName()+"','"+dtf.format(now)+"');";
		System.out.println(query1);
		st.executeUpdate(query1);
	}

	public void UpdateMasterExecutionEndDate() throws Exception {
		Statement st =  dbcon.createStatement();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		System.out.println(dtf.format(now));
		st.executeUpdate("UPDATE Execution_Master SET Execution_End_Date= '"+dtf.format(now)+"' WHERE Execution_Id= "+Master_counter+";");
	}

	public void insertExecutionDetails(String suiteType, String ModuleName, String testCaseName,String status) throws Exception {
		Statement st1 =  dbcon.createStatement();
		if(suiteType.equalsIgnoreCase("SMOKE")){
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
			LocalDateTime now = LocalDateTime.now();  
			System.out.println("Test Smoke");
			String query = "INSERT INTO Execution_Sanity_Details (Execution_Id,Test_Case_Name,Execution_Start_Date,Execution_End_Date) VALUES ("+Master_counter+",'"+testCaseName+"','"+dtf.format(now)+"','"+dtf.format(now)+"');";
			st1.executeUpdate(query);
		}else {

			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
			LocalDateTime now = LocalDateTime.now();  
			System.out.println("Test Regression");
			String query1 = "INSERT INTO Execution_Regression_Details (Execution_Id,Module_Name,TestCase_Name,Execution_Start_Date,Execution_End_Date) VALUES ("+Master_counter+",'"+ModuleName+"','"+testCaseName+"','"+dtf.format(now)+"','"+dtf.format(now)+"');";
			st1.executeUpdate(query1);

		}
	}

	public void insertExecutionScenarioStatus(String testCaseName,String status,String Exception,String Error) throws Exception {
		
		Statement st1 =  dbcon.createStatement();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		System.out.println("Test Smoke");
		String query = "INSERT INTO Execution_Result (Execution_Id,Scenario_Name,Result,Exception,Error) VALUES ("+Master_counter+",'"+testCaseName+"','"+status+"','"+Exception+"','"+Error+"');";
		st1.executeUpdate(query);

	}

	
	
	public void UpdateExecutionEndDate(String Type) throws Exception {
		Statement st =  dbcon.createStatement();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		System.out.println(dtf.format(now));
		if(Type.equalsIgnoreCase("smoke")) {
			st.executeUpdate("UPDATE Execution_Sanity_Details SET Execution_End_Date= '"+dtf.format(now)+"' WHERE Execution_Id= "+Master_counter+";");
		}else {
			st.executeUpdate("UPDATE Execution_Regression_Details SET Execution_End_Date= '"+dtf.format(now)+"' WHERE Execution_Id= "+Master_counter+";");
		}
	}
}
