package com.qa.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.python.modules.thread.thread;

import com.qa.util.TestBase;

public class ProgressReport_vini extends TestBase
{
public	static List<String> allassignmentoptions1 = new ArrayList<String>();
	@FindBy(xpath = "//a[contains(text(), 'Reports')]")
	WebElement reportLink;
	
	
	
	@FindBy(xpath = "//*[@id=\"exportbtn\"]")
	WebElement exportBtn;
	
	@FindBy(xpath = "//a[contains(text(), 'Progress Report')]")
	WebElement progressReportLink;
	
	@FindBy(xpath = "//body[@class]")
	WebElement pageLoad;
	
	@FindBy(xpath = "//div[@id = 'progress_report_info']")
	WebElement reportTable;
	
	@FindBy(xpath="//h1[contains(text(),'Progress Report')]")
	WebElement Reportheader;
	
	
	
	@FindBy(xpath="//*[@id=\"reports\"]/tbody/tr/td[10]/a")
	WebElement ecardDownload;
	
	
	
	@FindBy(xpath="//div[2]/a")
	WebElement viewecard;
	
	@FindBy(xpath="(//div[@class=\"dataTables_info\"])[1]")
	WebElement Paginationinfoup;
	
	@FindBy(xpath="(//div[@class=\"dataTables_info\"])[2]")
	WebElement Paginationinfobottom;
	
	@FindBy(xpath="//div[@id='progress_report_length']//label")
	WebElement rowsperpageheader;
	
	@FindBy(xpath="//div[@id='progress_report_length']//label//select//option")
	WebElement rowsperpagevalues;
	
	@FindBy(xpath="//a[contains(text(),'Curriculum Filters')]")
	WebElement curriculumfilterslink;
	
	@FindBy(xpath="//div[@id='ms-list-7']//button")
	WebElement curriculamstatusdropdownCTC;
	
	@FindBy(xpath="//select[@id='curriculam_status']/following-sibling::div//button")
	WebElement curriculamstatusdropdownLMS;
	
	@FindBy(xpath="//div[@id='ms-list-7']//div//ul//li//label")
	List<WebElement> curriculamstatusdropdownvaluesCTC;
	
	@FindBy(xpath="//select[@id='curriculam_status']/following-sibling::div/div//ul//li//label")
	List<WebElement> curriculamstatusdropdownvaluesLMS;
	
	@FindBy(xpath="//a[contains(text(),'More Filters')]")
	WebElement morefilterslink;
	
	@FindBy(xpath="//select[@id='statusFilter']/following-sibling::div//button")
	WebElement userstatusfiltersdropdown;
	
	@FindBy(xpath="//select[@id='statusFilter']/following-sibling::div//ul//li//label")
	List<WebElement> userstatusdropdownvalues;
	
	@FindBy(xpath="(//li[@class='default selected'])[2]")
	WebElement activedefaultselected;
	
	@FindBy(xpath="(//select[@id='statusFilter']/following-sibling::div//ul//li//label)[2]")
	WebElement inactiveelement;
	
	@FindBy(xpath="(//li[@class='selected'])[2]")
	WebElement inactiveselected;

	@FindBy(xpath="//select[@id='assignments']/following-sibling::div//button")
	WebElement Assignmentdropdown;
	
	@FindBy(xpath="//select[@id='statusFilter']/following-sibling::div//ul//li//label")
	List<WebElement> userstatuscolumnvalues;
	
	@FindBy(xpath="(//a[contains(text(),'Unselect all')])[4]")
	WebElement UnselectAllAssignmentdropdown;
	
	@FindBy(xpath="//table[@id='progress_report']//tbody//tr[*]//td[5]")
	List<WebElement> allassignmentvalues;
	

	@FindBy(xpath="(//div[@id='progress_report_wrapper']//div[@class=\"DTFC_ScrollWrapper\"]//div[@class=\"DTFC_LeftWrapper\"]//div[@class=\"DTFC_LeftBodyWrapper\"]//div//table//tbody//tr[@class=\"cursor odd\"])[1]")
	WebElement handiconoddfirst;
	@FindBy(xpath="//div[@id='overLayBlock']//th")
	List<WebElement> coursedetailsheaders;
	
	@FindBy(xpath="//div[@id='overLayBlock']//div//div//a")
    WebElement closeiconwithinpopup;
	
	@FindBy(xpath="//div[@id='overLayBlock']//tbody//tr[1]//td")
	List<WebElement> coursedetailsdata;
	
	@FindBy(xpath="(//button[contains(text(),'Search')])[3]")
	WebElement Searchbutton;
	@FindBy(xpath="//select[@id='courses']/following-sibling::div//button")
	WebElement Curriculumnamedropdown;
	@FindBy(xpath="(//a[contains(text(),'Unselect all')])[3]")
	WebElement UnselectAllcurriculumnamedropdown;
	
	@FindBy(xpath="//input[@id='from_available_date'][@placeholder=\"From\"]")
	WebElement Availabledatefrom;
	@FindBy(xpath="//input[@id='to_available_date'][@placeholder=\"To Date\"]")
	WebElement AvailabledateTo;
	@FindBy(xpath="//input[@id='from_launched_date'][@placeholder=\"From\"]")
	WebElement LaunchedDatefrom;
	@FindBy(xpath="//input[@id='to_launched_date'][@placeholder=\"To Date\"]")
	WebElement LaunchedDateTo;	
	@FindBy(xpath="//input[@id='from_available_date'][@placeholder=\"From\"]")
	WebElement fromDuedate;
	@FindBy(xpath="//input[@id='to_available_date'][@placeholder=\"To Date\"]")
	WebElement ToDuedate;
	@FindBy(xpath="//input[@id='from_completed_date'][@placeholder=\"From\"]")
	WebElement fromCompletedDate;
	@FindBy(xpath="//input[@id='to_completed_date'][@placeholder=\"To Date\"]")
	WebElement ToCompletedDate;
	//input[@id='from_due_date'][@placeholder="From"]
	//input[@id='to_due_date'][@placeholder="To Date"]
	//input[@id='from_completed_date'][@placeholder="From"]
	//input[@id='to_completed_date'][@placeholder="To Date"]
	

	String val;
	String tableRow = "//table[@id = 'progress_report']/tbody/tr[1]/td";
	
	public ProgressReport_vini() 
	{
		PageFactory.initElements(driver, this);
	}
	
	public void clickOnReportLink()
	{
		try {
			Thread.sleep(15000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		wait.until(ExpectedConditions.visibilityOf(reportLink));
		wait.until(ExpectedConditions.elementToBeClickable(reportLink));
		try {
		val = pageLoad.getAttribute("class");
		int m=0;
		while(val.contains("loading") || val.contains("loading_user") )
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		reportLink.click();
		}
		catch (Exception e) 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
         js.executeScript("arguments[0].scrollIntoView();",reportLink);
			reportLink.click();
		}
		
	}
	
	
	public void buttonExportBtn()
	{
		wait.until(ExpectedConditions.visibilityOf(reportLink));
		
		try {
			Thread.sleep(15000);
			exportBtn.click();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			System.out.println("Export is disabled ");;
		}
		
		
	}
	public void buttonExportBttn()
	{
		wait.until(ExpectedConditions.visibilityOf(reportLink));
		
		try {
			Thread.sleep(15000);
			exportBtn.click();
			Assert.fail("Export not disabled ");
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			System.out.println("Export is disabled ");;
		}
		
		
	}
	public void navigateProgressReport()
	{
		wait.until(ExpectedConditions.visibilityOf(progressReportLink));
		progressReportLink.click();
		val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
	}
	public void verifyheaderforreportspage(String expected)
	{
		String ActualTitle = Reportheader.getText();
		Assert.assertEquals(ActualTitle,expected);
	}
	
	
	
	public void clickecardDownload()
	{
		wait.until(ExpectedConditions.visibilityOf(ecardDownload));
		ecardDownload.click();
		
		try
		{
			Thread.sleep(5000);
		}
		catch(Exception e)
		{
			
		}
		String currentHandle= driver.getWindowHandle();
		Set<String> handles=driver.getWindowHandles();
		for(int i=0;i<20;i++)
		{
		if(handles.size() == 1)
		{
			handles=driver.getWindowHandles();
			
		}
		else
			break;
		}
		int m=0;
		for(String actual: handles)
        {
            
         if(!actual.equalsIgnoreCase(currentHandle))
             driver.switchTo().window(actual);
         else
         {
        	 if(m==20)
        		 break;
        	 m++;
         	 
         }
        }
		
		Assert.assertTrue(driver.getCurrentUrl().contains("/certificate/ecard/"));
		try
		{
			Thread.sleep(5000);
			driver.switchTo().frame("examReaderFrame");
		}
		catch(Exception e)
		{
			
		}
		
		driver.findElement(By.xpath("//table/tr[2]/td[2]/img")).click();
		try
		{
			Thread.sleep(5000);
		}
		catch(Exception e)
		{
			
		}
		 currentHandle= driver.getWindowHandle();
		 handles=driver.getWindowHandles();
	
		Assert.assertTrue(driver.getWindowHandles().size()==3);
		 
		 handles=driver.getWindowHandles();
	 
		
	 driver.switchTo().window(handles.toArray()[2].toString()).close();
	 driver.switchTo().window(handles.toArray()[1].toString()).close();
	 driver.switchTo().window(handles.toArray()[0].toString());
	 
	 
		
	}
	public void viewecardDownload()
	{
		wait.until(ExpectedConditions.visibilityOf(viewecard));
		viewecard.click();
		
		try
		{
			Thread.sleep(5000);
		}
		catch(Exception e)
		{
			
		}
		String currentHandle= driver.getWindowHandle();
		Set<String> handles=driver.getWindowHandles();
		for(int i=0;i<20;i++)
		{
		if(handles.size() == 1)
		{
			handles=driver.getWindowHandles();
			
		}
		else
			break;
		}
		int m=0;
		for(String actual: handles)
        {
            
         if(!actual.equalsIgnoreCase(currentHandle))
             driver.switchTo().window(actual);
         else
         {
        	 if(m==20)
        		 break;
        	 m++;
         	 
         }
        }
		
		Assert.assertTrue(driver.getCurrentUrl().contains("/certificate/ecard/"));
		try
		{
			Thread.sleep(5000);
			driver.switchTo().frame("examReaderFrame");
		}
		catch(Exception e)
		{
			
		}
		
		driver.findElement(By.xpath("//table/tr[2]/td[2]/img")).click();
		try
		{
			Thread.sleep(5000);
		}
		catch(Exception e)
		{
			
		}
		 currentHandle= driver.getWindowHandle();
		 handles=driver.getWindowHandles();
	
		Assert.assertTrue(driver.getWindowHandles().size()==3);
		 
		 handles=driver.getWindowHandles();
	 
		
	 driver.switchTo().window(handles.toArray()[2].toString()).close();
	 driver.switchTo().window(handles.toArray()[1].toString()).close();
	 driver.switchTo().window(handles.toArray()[0].toString());
	 
	 
		
	}
	public void clickonfilter(String report)
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*/a[text()='"+report+"']"))));
		driver.findElement(By.xpath("//*/a[text()='"+report+"']")).click();
	}
	public void verifytableheaders(String Tableheaders) throws InterruptedException
	{
		String str = Tableheaders;
		List<String> headerList = Arrays.asList(str.split(","));
		Thread.sleep(2000);
		for(int i = 0; i < headerList.size(); i++) {
		     WebElement header = driver.findElement(By.xpath("(//thead//tr//th["+(i+2)+"])[1]")); 
		     JavascriptExecutor js = (JavascriptExecutor) driver;
		     js.executeScript("arguments[0].scrollIntoView();", header);
		      String actualheader = header.getText();
		//      System.out.println(i+2);
		      System.out.println(actualheader);
		   Assert.assertEquals(headerList.get(i).toUpperCase(),actualheader);
		}
		      
	}
	public void verifypagination()
	{
		Boolean Display = Paginationinfoup.isDisplayed();
		System.out.println("Element displayed is :"+Display);
		
 	  Assert.assertEquals(rowsperpageheader.getText(),"Rows per page\n"
 	  		+ "25\n"
 	  		+ "50\n"
 	  		+ "75\n"
 	  		+ "100");
	}
	public void expandCurriculamfilters() throws InterruptedException
	{
		Thread.sleep(2000);
	  curriculumfilterslink.click();
	}
	public void curriculamstatusoptionsCTC(String options) throws InterruptedException
	{
		Thread.sleep(2000);
		List<String> options1 = Arrays.asList(options.split(","));
		curriculamstatusdropdownCTC.click();
		List<WebElement> allstatusoption = curriculamstatusdropdownvaluesCTC;
		List<String> allstatusoptions1 = new ArrayList<String>();
				for( WebElement option : allstatusoption){
		String add1 = option.getText();
		allstatusoptions1.add(add1);
				}
				System.out.println(allstatusoptions1);
				 Assert.assertEquals(allstatusoptions1,options1);
	}
	public void curriculamstatusoptionsLMS(String options) throws InterruptedException
	{
		Thread.sleep(3000);
		List<String> options1 = Arrays.asList(options.split(","));
		curriculamstatusdropdownLMS.click();
		List<WebElement> allstatusoption = curriculamstatusdropdownvaluesLMS;
		List<String> allstatusoptions1 = new ArrayList<String>();
				for( WebElement option : allstatusoption){
		String add1 = option.getText();
		allstatusoptions1.add(add1);
				}
				System.out.println(allstatusoptions1);
				Assert.assertEquals(options1,allstatusoptions1);
	}
	public void validateCurriculumStatusComplete()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		val = js.executeScript("return document.readyState").toString();
		int m=0;
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			m++;
		}
		wait.until(ExpectedConditions.visibilityOf(reportTable));
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableRow + "[6]/span"))));
		String data = driver.findElement(By.xpath(tableRow + "[6]/span")).getText().trim();
		System.out.println(data);
		Assert.assertTrue(data.equalsIgnoreCase("Completed"));
	}
	public void expandmorefilterslink() throws InterruptedException
	{
		Thread.sleep(2000);
		morefilterslink.click();
	}
	public void userstatusoptions(String options) throws InterruptedException
	{
		Thread.sleep(3000);
		List<String> options1 = Arrays.asList(options.split(","));
		userstatusfiltersdropdown.click();
		List<WebElement> allstatusoption = userstatusdropdownvalues;
		List<String> allstatusoptions1 = new ArrayList<String>();
//				for( WebElement option : allstatusoption){
//		String add1 = option.getText();
//		allstatusoptions1.add(add1);
//				}
				allstatusoption.forEach(ele -> allstatusoptions1.add(ele.getText()));
				System.out.println(allstatusoptions1);
				System.out.println(options1);
			Assert.assertEquals(allstatusoptions1,options1);
	}
	public void verifydefaultselected() throws InterruptedException
	{
		Assert.assertEquals(true,activedefaultselected.isDisplayed());
		inactiveelement.click();
		Thread.sleep(1000);
		Assert.assertEquals(true,inactiveselected.isDisplayed());	
	}
	public void presenceofassignmentname(String booleanvalue) throws InterruptedException
	{
//		Assert.assertEquals(booleanvalue,Assignmentdropdown.isDisplayed());
		Thread.sleep(2000);
		Assignmentdropdown.click();
		Assert.assertEquals(Boolean.parseBoolean(booleanvalue),Assignmentdropdown.isDisplayed());
	}
	public void assignmentunselectall() throws InterruptedException
	{
		UnselectAllAssignmentdropdown.click();
		Thread.sleep(2000);
	}
	public void selectionofassignmentnames(Integer int1)
	 {
//		List<String> allassignmentoptions1 = new ArrayList<String>();
		for(int i=1;i<=int1;i++)
		{
		driver.findElement(By.xpath("//select[@id='assignments']/following-sibling::div//div//ul//li["+i+"]//label")).click();
		String assignmentoptiongettext = driver.findElement(By.xpath("//select[@id='assignments']/following-sibling::div//div//ul//li["+i+"]//label")).getText().trim();
		allassignmentoptions1.add(assignmentoptiongettext);
		}
		System.out.println(allassignmentoptions1);                                                                  
	}
	public void searchclick() throws InterruptedException
	{
		Searchbutton.click();
		Thread.sleep(2000);
	}
	public void recordsvalidationforassignmentnamefield()
	{                 
		System.out.println(allassignmentoptions1);
		List<WebElement> allstatusoption = allassignmentvalues;
		List<String> allstatusoptions1 = new ArrayList<String>();
				allstatusoption.forEach(ele -> allstatusoptions1.add(ele.getText()));
				System.out.println(allstatusoptions1);
				System.out.println(allassignmentoptions1);
			Assert.assertEquals(allstatusoptions1,allassignmentoptions1);
	}
	public void assertionforavailabledate()
	{
		Assert.assertEquals(true,Availabledatefrom.isDisplayed());
		Assert.assertEquals(true,AvailabledateTo.isDisplayed());
	}
	@FindBy(xpath="//*[@id=\"ms-list-5\"]/button")
	WebElement notificationFilter;

	

	@FindBy(xpath="//*[@id=\"ms-list-5\"]/div/a[text()='Unselect all']")
	WebElement unselectAll;

public void navigateReport(String report)
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*/a[text()='"+report+"']"))));
		driver.findElement(By.xpath("//*/a[text()='"+report+"']")).click();
		System.out.println(driver.getTitle());
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//h1['"+report+"']"))));
		
		
		
	}
	
	public void selectNotificationFilter(String filter)
	{
		wait.until(ExpectedConditions.visibilityOf(notificationFilter));
		notificationFilter.click();
		
		unselectAll.click();
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//input[contains(@title,'"+filter+"')]"))));
		driver.findElement(By.xpath("//input[contains(@title,'"+filter+"')]")).click();
		
		driver.findElement(By.xpath("//*[@id=\"notification_log_filter\"]//button[text()='Search']")).click();
	}


	

	public void assertionforLauncheddate()
	{
		Assert.assertEquals(true,LaunchedDatefrom.isDisplayed());
		Assert.assertEquals(true,LaunchedDateTo.isDisplayed());
	}
	public void assertionduedateassertion()
	{
		Assert.assertEquals(true,fromDuedate.isDisplayed());
		Assert.assertEquals(true,ToDuedate.isDisplayed());
	}
	public void assertioncompletedate()
	{
		Assert.assertEquals(true,fromCompletedDate.isDisplayed());
		Assert.assertEquals(true,ToCompletedDate.isDisplayed());
	}
	public void clickhandicon() throws InterruptedException 
	{
		handiconoddfirst.click();
		Thread.sleep(2000);	
	}

	public void verifyactivityheaders(String headers) throws InterruptedException {
		Thread.sleep(3000);
		List<String> headers1 = Arrays.asList(headers.split(","));
		List<WebElement> allactivityheaders = coursedetailsheaders;
		List<String> coursedetailsheaders1 = new ArrayList<String>();
				for( WebElement option : allactivityheaders){
		String add1 = option.getText().replace("\n", " ");
		coursedetailsheaders1.add(add1.trim());
				}
				System.out.println(coursedetailsheaders1);
				System.out.println(headers1);
			Assert.assertEquals(headers1,coursedetailsheaders1);				
	}

	public void verifyactivitytabledata(String string) throws InterruptedException {
		Thread.sleep(3000);
		List<String> headers1 = Arrays.asList(string.split(","));
		List<WebElement> allactivitydata = coursedetailsdata;
		List<String> coursedetailsdata1 = new ArrayList<String>();
				for( WebElement option : allactivitydata){
		String add1 = option.getText();
		coursedetailsdata1.add(add1.trim());
				}
				System.out.println(coursedetailsdata1);
				System.out.println(headers1);
				Assert.assertEquals(headers1,coursedetailsdata1);
	}
	public void selectthecurriculumname(String string) throws InterruptedException
	{
    Thread.sleep(1000);
	Curriculumnamedropdown.click();
	Thread.sleep(1000);
	UnselectAllcurriculumnamedropdown.click();
	Thread.sleep(1000);
	driver.findElement(By.xpath("//select[@id='courses']/following-sibling::div//div//ul//li//label[contains(text(),'"+string+"')]")).click();
	Thread.sleep(2000);
	}
	public void clickonclose() throws InterruptedException
	{
		closeiconwithinpopup.click();
		Thread.sleep(1000);
	}

}

