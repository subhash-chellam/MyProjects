package com.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.qa.util.TestBase;

import junit.framework.Assert;

public class OrganizationDetails extends TestBase
{
	@FindBy(xpath = "//a[text() = 'Edit Organization']")
	WebElement editOrg;
	@FindBy(xpath = "//label[text() = 'Enable']")
	WebElement enable;

    @FindBy(xpath = "//label[@for= 'salesforce_id']/following-sibling::span")
    WebElement salesforceID;
    @FindBy(xpath = "//label[text() = 'Disable']")
	WebElement disable;
	

	@FindBy(xpath = "//*[@id=\"lms_name_id_1_chosen\"]")
	WebElement lmsname;
	
	@FindBy(xpath = "//*[@id=\"lms_name_id_1_chosen\"]/div/ul/li[2]")
	WebElement moodleoption;
	@FindBy(xpath = "//input[@placeholder = 'LMS URL']")
	WebElement lmsInfoUrlInput;
	
	@FindBy(xpath = "//input[@name='organization_id']")
	WebElement org_id;
	
	
	@FindBy(xpath = "//label[text() = 'Organization Name']/following-sibling::span")
	WebElement oldOrgName;
	
	@FindBy(xpath = "//label[text() = 'Contact Person Name ']/following-sibling::span")
	WebElement oldContName;
	
	@FindBy(xpath = "//label[text() = 'Contact Person Email ']/following-sibling::span")
	WebElement oldContEmail;
	
	@FindBy(xpath = "//label[text() = 'Company Address 1']/following-sibling::span")
	WebElement oldCompAdr1;
	
	@FindBy(xpath = "(//label[text() = 'City']/following-sibling::span)[1]")
	WebElement oldCompCity;
	
	@FindBy(xpath = "(//label[text() = 'Zipcode']/following-sibling::span)[1]")
	WebElement oldCompZip;
	
	@FindBy(xpath = "(//i[contains(@class, 'remove')])")
	WebElement errorSymbol;
	
	@FindBy(xpath = "//button[@id = 'submit_btn' and @disabled]")
	WebElement disableSubmitButton;
	
	@FindBy(xpath = "(//button[@type = 'submit'])[2]")
	WebElement submitButton;
	
	@FindBy(xpath = "//div[contains(@class, 'email')]/div[2]/label")
	WebElement emailNotificationOff;
	
	
	
	@FindBy(xpath = "//*[@id=\"customerform\"]//label[@for=\"federal_organisation_no\"]")
	WebElement federal_organisation_no;
	
	@FindBy(xpath = "//*[@id=\"customerform\"]//label[@for=\"federal_organisation_yes\"]")
	WebElement federal_organisation_yes;
	
	
	@FindBy(xpath = "//div[contains(@class, 'email')]/div[1]/label")
	WebElement emailNotificationOn;
	
	@FindBy(xpath = "//label[text() = 'Sub Domain ']//following-sibling::span[@class]")
	WebElement subDomainPath;
	

	@FindBy(xpath = "//*[@id='customerform']/div[2]/div[14]/span")
	WebElement language;
	
	@FindBy(xpath = "//*[@id=\"customerform\"]/div[4]/span")
	WebElement selfR;
	
	
	
	@FindBy(xpath = "//*[@id=\"customerform\"]/div[1]/div[5]/span")
	WebElement Classification;
	
	@FindBy(xpath = "//*[@id=\"customerform\"]/div[2]/div[14]/div/div[3]/label")
	WebElement norsk;
	@FindBy(xpath="//label[text()='Elearning']")
	WebElement Elearningchkbox;
	
	
	NewOrganization org = new NewOrganization();
	
	public static String organisationName, contactName, contactEmail, 
	companyAdr1, companyCity, companyZip, subDomain,SalesforceName;
	
	public OrganizationDetails()
	{
		PageFactory.initElements(driver, this);
	}
	
	public void validatelanguage(String lang)
	{
		if(language.getText().contains(lang))
		{

		    
			Products prod = new Products();
		    
		    prod.navigateOrgList();
		}
		else
		{
			
			NewOrganization newOrg=new NewOrganization();
			clickEditOrganization();
			norsk.click();
			try {
				clickUpdateOrganization();
				getOrgDetails();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
//			orgDetails.getOrgDetails();
		}
	}
	public void validateSelfRegistration(String self)
	{
			NewOrganization newOrg=new NewOrganization();
			clickEditOrganization();
			if(self.contains("Enable"))
			 newOrg.clickSelfRegister();
			else
				newOrg.clickSelfRegisterdisable();
			try {
				
				clickUpdateOrganization();
			
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
//			orgDetails.getOrgDetails();
		
	}
	public void validateSelfRegistrationoptional(String self)
	{
		
			
			NewOrganization newOrg=new NewOrganization();
			clickEditOrganization();
			if(self.contains("Enable"))
			{
			 newOrg.clickSelfRegisterOption();
			}
			else
				newOrg.clickSelfRegisterdisable();
			try {
				
				clickUpdateOrganization();
			
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
//			orgDetails.getOrgDetails();
		
	}
	
	
	
	public void validateClassification(String classification)
	{
		if(Classification.getText().contains(classification))
		{

		    
			Products prod = new Products();
		    
		    prod.navigateOrgList();
		}
		else
		{
			
			NewOrganization newOrg=new NewOrganization();
			clickEditOrganization();
			if(classification.contains("Training Center"))
			 newOrg.clickonTrainingCenter();
			else
				newOrg.clickonTrainingSite();
			try {
				
				clickUpdateOrganization();
			
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
//			orgDetails.getOrgDetails();
		}
	}
	public void checklanguage(String lang)
	{
	
		Assert.assertEquals(contactName, lang);
		
	}
	public void getOrgDetails()
	{
		organisationName = oldOrgName.getText().trim();
		contactName = oldContName.getText().trim();
		contactEmail = oldContEmail.getText().trim();
		companyAdr1 = oldCompAdr1.getText().trim();
		companyCity = oldCompCity.getText().trim();
		companyZip = oldCompZip.getText().trim();
		System.out.println("First name is " + contactName);
	}
	
	public void clickEditOrganization()
	{
		wait.until(ExpectedConditions.visibilityOf(editOrg));
		editOrg.click();
				
	}
	public void clickSelfRegister()
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(enable));
		enable.click();
	}
	public void disableSelfRegister()
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(disable));
		disable.click();
	}
	
	public void getSalesforceId()
    {
        wait.until(ExpectedConditions.visibilityOf(salesforceID));
        SalesforceName = salesforceID.getText().trim();
        System.out.println(SalesforceName);
    }
	public void selecturl() throws InterruptedException
	{
		wait.until(ExpectedConditions.visibilityOf(lmsname));
		lmsname.click();
//		wait.until(ExpectedConditions.visibilityOf(moodleoption));
        Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"lms_name_id_1_chosen\"]/div/div/input")).sendKeys("moodle");
		 Thread.sleep(2000);
		moodleoption.click();

		wait.until(ExpectedConditions.visibilityOf(lmsInfoUrlInput));

		lmsInfoUrlInput.clear();
		lmsInfoUrlInput.sendKeys(prop.getProperty("moodleurl"+prop.getProperty("environment")));
		
	
	}
	
	
	public void changelanguages()
	{
		wait.until(ExpectedConditions.visibilityOf(editOrg));
		editOrg.click();
	}
	
	public void updateDetails()
	{
		org.orgName.click();
		org.orgName.clear();
		org.orgName.sendKeys(organisationName + "_update");
		org.contFirst.click();;
		org.contFirst.clear();
		org.contFirst.sendKeys(contactName.replace(" ", "_update"));
		org.contLast.click();
		org.contLast.clear();
		org.contLast.sendKeys("UpdatedName");
		org.contNumber.click();
		org.contNumber.clear();
		org.contNumber.sendKeys("1223345611");
		org.contEmail.click();
		org.contEmail.clear();
		org.contEmail.sendKeys(contactEmail.replace("@", "_update@"));
		contactEmail=contactEmail.replace("@", "_update@");
		org.cmpAdr1.click();
		org.cmpAdr1.clear();
		org.cmpAdr1.sendKeys(companyAdr1 + "_update");
		org.cmpAdr2.sendKeys("Automation"+ "_update");
		org.cmpCity.click();
		org.cmpCity.clear();
		org.cmpCity.sendKeys(companyCity + "_update");
		org.cmpZip.click();
		org.cmpZip.clear();
		org.cmpZip.sendKeys(companyZip + "1");
//		org.selectProductType("Elearning");
		System.out.println(org_id.getAttribute("readonly"));
		Assert.assertTrue(org_id.getAttribute("readonly").contains("true"));	
		System.out.println("Orid is disable");
		Assert.assertTrue(org.subDomain.getAttribute("disabled").contains("true"));	
		System.out.println("subDomain is disable");
		
		try
		{
		Select drptime = new Select(org.timeZone);
		drptime.selectByValue("5");
		Assert.fail("TimeZone is not disable");	
		
		}
		catch(Exception e)
		{
		System.out.println("TimeZone is disable");
		}
		
	}
	int count=0;
	public void clickUpdateOrganization() throws Exception 
	{
		Boolean flg=false;
		for(int i=0;i<20;i++)
		{		
			Thread.sleep(3000);
		try
		{
			if(disableSubmitButton.isDisplayed())
			{
				System.out.println("Button disabled");
				org.cmpZip.click();
				org.cmpZip.sendKeys(Keys.TAB);
//				submitButton.click();
			}
		}
		catch (Exception e) 
		{
			System.out.println("Button enabled");
			Thread.sleep(2000);
			submitButton.click();
			flg=true;
			break;
		}
		}
		Assert.assertTrue("Update Org Button disabled ",flg);
		
	}
	
	public void turnOffNotification()
	{
		wait.until(ExpectedConditions.visibilityOf(emailNotificationOff));
		emailNotificationOff.click();
	}
	public void turnOffFederal()
	{
		wait.until(ExpectedConditions.visibilityOf(federal_organisation_no));
		federal_organisation_no.click();
	}
	public void turnyesFederal()
	{
		wait.until(ExpectedConditions.visibilityOf(federal_organisation_yes));
		federal_organisation_yes.click();
	}
	public void turnONNotification()
	{
		wait.until(ExpectedConditions.visibilityOf(emailNotificationOn));
		emailNotificationOn.click();
	}
	
	public void getSubdomainName()
	{
		wait.until(ExpectedConditions.visibilityOf(subDomainPath));
		subDomain = subDomainPath.getText().trim();
		System.out.println(subDomain);
	}
	

	public void ClickElearingChkbox()
	{
		wait.until(ExpectedConditions.visibilityOf(Elearningchkbox));
		Elearningchkbox.click();
		
	}
	
	
}


