package com.qa.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.qa.util.TestBase;

public class Admin extends TestBase
{

	@FindBy(xpath = "//a[contains(text(), 'Admins')]")
	WebElement adminTab;
	
	@FindBy(xpath = "//input[@id = 'first_name']")
	WebElement firstName;
	
	@FindBy(xpath = "//input[@id = 'last_name']")
	WebElement lastName;
	
	@FindBy(xpath = "//input[@id = 'email']")
	WebElement emailText;
	
	@FindBy(xpath = "//button[text() = 'Add Administrator' and not(contains(@class, 'grey'))]")
	WebElement addAdmin;
	
	@FindBy(xpath = "//*[text() = 'Yes']")
	WebElement deleteYes;
	
	String tableRow = "//table[@id = 'customer-admin-list']/tbody/tr";
	
	public static String email;
	
	public Admin() 
	{
		PageFactory.initElements(driver, this);
		
	}

	public void clickManageAdmin()
	{
		wait.until(ExpectedConditions.visibilityOf(adminTab));
		adminTab.click();
	}
	
	public void enterDetails(String fName, String lName)
	{
		wait.until(ExpectedConditions.visibilityOf(firstName));
		firstName.sendKeys(fName);
		lastName.sendKeys(lName);
		String date = new java.util.Date().toString().replace(" ", "").replace(":", "");
		email = date + prop.getProperty("userDomain");
		User.userEmail=email;
		emailText.sendKeys(email);
		firstName.click();
	}
	

	public void enterDetails(String fName, String lName,String email) throws InterruptedException
	{
		wait.until(ExpectedConditions.visibilityOf(firstName));
		firstName.sendKeys(fName);
		lastName.sendKeys(lName);
		User.userEmail=email;
		for(int i=0;i<email.length();i++)
		{
		emailText.sendKeys(String.valueOf(email.charAt(i)) );
		Thread.sleep(700);
		}
		for(int i=0;i<4;i++)
		{
			emailText.sendKeys(Keys.TAB);
			
		try
		{
			Thread.sleep(3000);
			wait.until(ExpectedConditions.elementToBeClickable(addAdmin));
			break;
		}
		catch(Exception e)
		{
			
		}
		}
		
		firstName.click();
	}
	
	public void clickAdd()
	{
		wait.until(ExpectedConditions.visibilityOf(addAdmin));
		wait.until(ExpectedConditions.elementToBeClickable(addAdmin));
		addAdmin.click();
	}
	
	
	public void errorMessage(String msg)
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='create-customer-admin']//small"))));
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='create-customer-admin']//small"))));
		if(msg.contains("email id"))
		{
			System.out.println("Message "+driver.findElement(By.xpath("(//*[@id='create-customer-admin']//small)[5]")).getText());
			
			Assert.assertTrue("Message is not excepted "+driver.findElement(By.xpath("(//*[@id='create-customer-admin']//small)[5]")).getText(), driver.findElement(By.xpath("(//*[@id='create-customer-admin']//small)[5]")).getText().contains(msg));	
		}
		else
		{
		System.out.println("Message "+driver.findElement(By.xpath("//*[@id='create-customer-admin']//small[text()='"+msg+"']")).getText());
		Assert.assertTrue("Message is not excepted "+driver.findElement(By.xpath("//*[@id='create-customer-admin']//small[text()='"+msg+"']")).getText(), driver.findElement(By.xpath("//*[@id='create-customer-admin']//small[text()='"+msg+"']")).getText().contains(msg));
		}
	}
	
	public void deleteAdmin()
	{
		List<WebElement> rows = driver.findElements(By.xpath(tableRow));
		for(int i = 1; i <= rows.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath(tableRow + "[" + i + "]/td[2]"));
			String val = elem.getText();
			if(val.equalsIgnoreCase(email))
			{
				driver.findElement(By.xpath(tableRow + "[" + i + "]/td[4]//a")).click();
				WebElement delete = driver.findElement(By.xpath(tableRow + "[" + i + "]/td[4]//a[text() = 'Delete']"));
				wait.until(ExpectedConditions.visibilityOf(delete));
				delete.click();
				wait.until(ExpectedConditions.visibilityOf(deleteYes));
				deleteYes.click();
				break;
			}
			
			
		}
	}
		
	public void EnterAdminDetails(String fisName, String lstName)
	{
		wait.until(ExpectedConditions.visibilityOf(firstName));
		firstName.sendKeys(fisName);
		lastName.sendKeys(lstName);
	}	
}
