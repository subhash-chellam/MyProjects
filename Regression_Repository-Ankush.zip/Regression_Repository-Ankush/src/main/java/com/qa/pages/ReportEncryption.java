package com.qa.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;


import com.qa.util.TestBase;
import com.qa.util.TestUtils;

public class ReportEncryption extends TestBase {

	SFTP sftp;
	OrganizationHome org;
	SSOSetting sso;
	
	
	
	public ReportEncryption() {
		PageFactory.initElements(driver, this);
	}

	String newTab, oldTab;
	JavascriptExecutor js = (JavascriptExecutor) driver;

	@FindBy(xpath = "//div[@class='content']//div[@class='container']//ul//li/a")
	List<WebElement> Content_Header;
	
	@FindBy(xpath = "//button[contains(text(),'Create SFTP Account')]")
	WebElement Button_CreateSFTPAccount;
	

	public void selectThevaluefromHeadContent(String value) {

		try {
			ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
			oldTab = tabs.get(0);
			newTab = tabs.get(1);
			driver.switchTo().window(newTab);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			TestUtils.selectFromTheList(Content_Header, value);

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

public void CheckCreateSFTPAccountIsDisabled(String msg) {
        
		try {
			
			WebDriverWait wait = new WebDriverWait(driver, 20);
			boolean buttondisabled = Button_CreateSFTPAccount.isEnabled();
			if(buttondisabled!=false)
			{
				System.out.println(" Create SFTP Account button is disabled " );
				System.out.println(" Create SFTP Account button is disabled ");
			}
			else {
				
				System.out.println( " Create SFTP Account button is enabled ");
						 sftp.enterPassword();
						 sftp.clickCreateAccount();
						 org=new OrganizationHome();
						 org.validateSucessMesssage(msg);
						 sftp.clickActivateAccount();
						 sftp.clickActivateYes();
						 sftp.clickShowPassword();
						 sso = new SSOSetting();
						 sso.clickOnSSOTab();
						 sso.clickOnGenerateButton();
						 sso.closeTab();
						 
				}
	
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
	}
	
	
	
}
