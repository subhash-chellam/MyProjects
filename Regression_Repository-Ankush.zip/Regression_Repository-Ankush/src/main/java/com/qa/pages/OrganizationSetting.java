package com.qa.pages;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

//import com.qa.OldPages.Students;
import com.qa.util.TestBase;

public class OrganizationSetting extends TestBase {

	private static String Demographic_Settings_Success_Message = null;

	@FindBy(xpath = "//div[@class='left-nav tab-content']//li[2]/a")
	WebElement level2Link;

	@FindBy(xpath = "(//a[@data-target = '#unitdiv'])")
	WebElement unitRow;

	@FindBy(xpath = "(//a[@class = 'action_dropdown'])")
	WebElement unitAction;

	@FindBy(xpath = "(//a[contains(text(), 'Delete')])")
	WebElement unitDelete;

	@FindBy(xpath = "//a[text() = 'Yes']")
	WebElement unitYesButton;

	@FindBy(xpath = "//a[text() = 'Organization Settings']")
	WebElement OrganizationSettingsTab;

	@FindBy(xpath = "//a[contains(text(), 'Demographic Settings')]")
	WebElement DemographicSettingsTab;

	@FindBy(xpath = "//a[contains(text(), 'Create')]")
	WebElement createLevel2Link;

	@FindBy(xpath = "//input[@name = 'unit_name']")
	WebElement unitName;


	@FindBy(xpath="//a[contains(text(), '  Add/Edit ')]")
	WebElement addEditBtn;
	

	@FindBy(xpath = "//input[@name = 'address1']")
	WebElement unitAdr1;

	@FindBy(xpath = "//input[@name = 'city']")
	WebElement unitCity;

	@FindBy(xpath = "//select[@name = 'country_id']")
	WebElement selectUnitCountry;

	@FindBy(xpath="//div[@class='left-nav tab-content']//li[3]/a")
	WebElement level3Link;

	@FindBy(xpath = "//select[@name = 'state_id']")
	WebElement selectunitState;

	@FindBy(xpath = "//input[@name = 'zipcode']")
	WebElement unitZip;

	@FindBy(xpath = "//button[@id = 'submit_btn']")
	WebElement unitCreate;

	@FindBy(xpath = "//a[contains(text(), 'Edit')]")
	WebElement unitEdit;

	@FindBy(xpath = "(//a[contains(text(), 'View')])")
	WebElement unitView;

	@FindBy(xpath = "//a[@class='action_dropdown']")
	WebElement actionsBtn;

	@FindBy(xpath = "//a[text()='Delete Level 2']")
	WebElement deleteUnit;

	@FindBy(xpath = "//a[contains(@class, 'unitadmin')]")
	WebElement AddUnitButton;

	@FindBy(xpath = "//input[@id = 'combobox']")
	WebElement searchTextBox;

	@FindBy(xpath = "//li[@role = 'presentation']/a")
	WebElement learnerSearchResult;

	@FindBy(xpath = "//li[@role = 'presentation']")
	WebElement learnerSearchOption;

	@FindBy(xpath = "//button[@id = 'add-admin-observer']")
	WebElement buttonAddUnitAdmin;

	@FindBy(xpath = "//table[@id = 'admins']//tbody/tr/td[2]")
	WebElement adminTableRow;

///////////////////////////////////////////// JOB TITLE //////////////////////////////////////////	

	@FindBy(xpath = "//a[contains(text(), 'Title')]")
	WebElement titleTab;

	@FindBy(xpath = "//a[contains(text(), 'Job Titles')]")
	WebElement JobTitleTab;

	@FindBy(xpath = "//a[contains(text(), 'Create Job Title')]")
	WebElement createTitle;

	@FindBy(xpath = "//input[@name = 'Job_tilte_name']")
	WebElement newTitleName;

	@FindBy(xpath = "//button[text() = 'Create']")
	WebElement createJob;

	@FindBy(xpath = "//input[@name = 'jobtitle']")
	WebElement titleSearch;

	@FindBy(xpath = "//button[@id = 'searchbtn']")
	WebElement searchTitleButton;

	@FindBy(xpath = "//div[@role = 'status' and text() = 'Showing 1 to 1 of 1 entries']")
	WebElement titleSearchPage;

	@FindBy(xpath = "//table[@aria-describedby = 'jobtitle_info']//td[1]")
	WebElement titleSearchResult;

	@FindBy(xpath = "//a[@title = 'Edit Job Title Details']")
	WebElement editTitle;

	@FindBy(xpath = "//a[text() = 'Create Organization']")
	WebElement CreateOrganization;

	@FindBy(xpath = "//label[text() = 'LMS Information']")
	WebElement LmsInformation;

	@FindBy(xpath = "//button[text() = 'Save']")
	WebElement saveTitle;

	@FindBy(xpath = "//*[@id='jobtitle']//a/i")
	WebElement viewJob;

	///////////////////////////////////////////////// GROUP TAB
	///////////////////////////////////////////////// ///////////////////////////////////////////////////////

	@FindBy(xpath = "//a[contains(text(), 'Groups')]")
	WebElement groupTab;

	@FindBy(xpath = "//a[contains(text(), 'Create Group')]")
	WebElement createGroup;

	@FindBy(xpath = "//input[@name = 'group_name']")
	WebElement newGroupName;

	@FindBy(xpath = "//input[@name = 'creategroup']")
	WebElement createButton;

	@FindBy(xpath = "//input[@name = 'group_name']")
	WebElement groupSearch;

	@FindBy(xpath = "//button[@id = 'searchgroup']")
	WebElement searchButton;

	@FindBy(xpath = "//div[@role = 'status' and contains(text(), 'filtered')]")
	WebElement filteredData;

	@FindBy(xpath = "//table[@aria-describedby = 'tablelisting_info']//td[1]")
	WebElement searchResult;

	@FindBy(xpath = "//a[@title = 'Edit Group Details']")
	WebElement editGroup;

	@FindBy(xpath = "//*[@id='combobox']")
	WebElement search;

	@FindBy(xpath = "//span[@role = 'status']")
	WebElement studentSearchResult;

	@FindBy(xpath = "//*[@id='addstudentstolistbutton']")
	WebElement addUser;

	@FindBy(xpath = "//li[@role = 'presentation']")
	WebElement studentSearchOption;

	@FindBy(xpath = "(//*[@id=\"tablelisting\"]//i)[1]")
	WebElement viewGroup;

	///////////////////////////////////////////////////////////////////////////////////////

	@FindBy(xpath = "//label[@for = 'non_existing_user']")
	WebElement addManuallyRadioButton;

	@FindBy(xpath = "//input[@name = 'first_name']")
	WebElement firstNameText;

	@FindBy(xpath = "//input[@name = 'last_name']")
	WebElement lastNameText;

	@FindBy(xpath = "//input[@id = 'email_address']")
	WebElement emailText;

	@FindBy(xpath = "(//button[@class = 'btn btn-default red_btn'])[2]/span")
	WebElement buttonManuallyEnable;

	@FindBy(xpath = "(//button/span[text() = 'Add Unit Admin'])[2]")
	WebElement buttonAddUnitAdminManually;

	@FindBy(xpath = "//a[contains(@class, 'unitobserver')]")
	WebElement AddUnitObserverButton;

	@FindBy(xpath = "//span[text()='Add Unit Observer - Automation Test']")
	WebElement UnitObserverPopUp;

	@FindBy(xpath = "(//button/span[text() = 'Add Unit Observer'])[2]")
	WebElement buttonAddUnitObserverManually;

	//////////////////////////////////////////////////////////////////////////////////

	@FindBy(xpath = "//a[contains(text(), 'Technical Contacts')]")
	WebElement TechnicalContactsTab;

	@FindBy(xpath = "//a[contains(text(), 'Add Technical Contacts')]")
	WebElement AddTechnicalContactsBtn;

	@FindBy(xpath = "//input[@name = 'firstname[]']")
	WebElement firstnameText_technicalContacts;

	@FindBy(xpath = "//input[@name = 'lastname[]']")
	WebElement lastnameText_technicalContacts;

	@FindBy(xpath = "//input[@name = 'email[]']")
	WebElement emailText_technicalContacts;

	@FindBy(xpath = "//a[@title = 'Edit Technical Contact']")
	WebElement EditTechnicalContact;

	@FindBy(xpath = "//input[@id= 'first_name']")
	WebElement firstNameEdit_technicalContacts;

	@FindBy(xpath = "//input[@id= 'last_name']")
	WebElement lastNameEdit_technicalContacts;

	@FindBy(xpath = "//input[@id= 'email']")
	WebElement emailEdit_technicalContacts;

	@FindBy(xpath = "//input[@id= 'submitBtn']")
	WebElement submitBtn_technicalContacts;

	@FindBy(xpath = "//button[contains(text(), 'Add Contacts')]")
	WebElement AddContactsBtn;

	@FindBy(xpath = "//div[contains(@class,'alert-success')]")
	WebElement technicalContactSuccessMsg;

	@FindBy(xpath = "//div[contains(@class,'alert-success')]")
	WebElement technicalContactUpdateSuccessMsg;

	@FindBy(xpath = "(//*[@class = 'close'])[1]")
	WebElement successMsgCloseButton;

	@FindBy(xpath = "//a[@title = 'Delete Technical Contacts']")
	WebElement deleteTechnicalContactsicon;

	@FindBy(xpath = "//a[contains(text(), 'Delete')]")
	WebElement deleteBtn;

	@FindBy(xpath = "//div[contains(@class,'alert-success')]")
	WebElement deleteTechnicalContactSuccessMsg;

	@FindBy(xpath = "//a[text() = 'Upload ']")
	WebElement uploadFileLink;

	@FindBy(xpath = "//th[@class = 'failurecount']")
	WebElement failureCount;

	@FindBy(xpath = "(//div[@class = 'btndiv']/a[text() = 'Close'])[1]")
	WebElement buttonClose;

///////////////////////////////////////////////////////////////////////////////////////

	@FindBy(xpath = "//a[text() = 'Purchase History']")
	WebElement purchaseHistoryTab;

	@FindBy(xpath = "//a[text() = 'Export to CSV']")
	WebElement exportToCsv;

	@FindBy(xpath = "//a[text() = 'Export to Excel']")
	WebElement exportToExcel;

	@FindBy(xpath = "//a[text() = 'Export to PDF']")
	WebElement exportToPdf;

	@FindBy(xpath = "//a[contains(text(),'Demographic Report')]")
	WebElement demographicReportlink;

	@FindBy(xpath = "//input[@id='imported_from_dated']")
	WebElement startDateFilterOption;

	@FindBy(xpath = "//div[@class='datepicker-days']")
	WebElement dateSelection;

	@FindBy(xpath = "//input[@id='imported_to_dated']")
	WebElement endDateFilterOption;

	@FindBy(xpath = "//button[@id='search']")
	WebElement searchIcon;

	@FindBy(xpath = "//a[contains(text(),'Clear Search')]")
	WebElement clearSearchBtn;

	@FindBy(xpath = "//a[contains(text(),'Demographic Settings')]")
	WebElement demographicSettingslink;

	@FindBy(xpath = "//label[@id='deltachangetext']")
	WebElement fullFeed;

	@FindBy(xpath = "//button[@id='submitBtn']")
	WebElement demographicSettingsSaveBtn;
	
	@FindBy(xpath = "//div[contains(@class,'alert-success')]")
	WebElement demographicSettingsSuccessMsg;
	
	@FindBy(xpath="//button[@id = 'popup-submit-btn']")
	WebElement saveUnitBtn;

	String selectUnits = "(//select[contains(@class, 'unitLevelSelect form-control')])";
	
	String unitSelection = "(//option[contains(text(), 'Automation Test')])";
	String orgName = "//label[text() = 'Organization Name']/following-sibling::span";
	
	String levelList = "//div[@class='left-nav tab-content']//ul[@style]//li";
	String mainLevel_List = "(//div[@class='hierarchy_labels']//label)";
	String unitCode = "//table[@id = 'tablelisting']//tr";
	
	String downloadPath = System.getProperty("user.dir") + prop.getProperty("downloadPath");
	public static String filePath;
	String fileName;
//	public static int groupCount, memberCount, unitCount;
	public static LinkedHashMap<String,String> map;
	
	public OrganizationSetting() {
		PageFactory.initElements(driver, this);
	}

	public void navigateLevel2() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(level2Link));
		level2Link.click();
	}

	public void deleteAutomatedUnit() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(unitRow));
			wait.until(ExpectedConditions.elementToBeClickable(unitRow));
			String rowsElement = unitRow.toString().split("xpath:")[1].trim();
			rowsElement = rowsElement.substring(0, rowsElement.length() - 1);
			List<WebElement> rows = driver.findElements(By.xpath(rowsElement));
			for (int i = 1; i <= rows.size(); i++) {
				String element = rowsElement + "[" + i + "]";
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(element))));
				String text = driver.findElement(By.xpath(element)).getText().toLowerCase().trim();
				if (text.contains("automation test")) {
					String actionElement = unitAction.toString().split("xpath:")[1].trim();
					actionElement = actionElement.substring(0, actionElement.length() - 1) + "[" + i + "]";
					driver.findElement(By.xpath(actionElement)).click();
					String deleteElement = unitDelete.toString().split("xpath:")[1].trim();
					deleteElement = deleteElement.substring(0, deleteElement.length() - 1) + "[" + i + "]";
					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(deleteElement))));
					driver.findElement(By.xpath(deleteElement)).click();
					wait.until(ExpectedConditions.visibilityOf(unitYesButton));
					wait.until(ExpectedConditions.elementToBeClickable(unitYesButton));
					unitYesButton.click();
					break;
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	public void deleteAutomatedUnit(String msg) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(unitRow));
			wait.until(ExpectedConditions.elementToBeClickable(unitRow));
			String rowsElement = unitRow.toString().split("xpath:")[1].trim();
			rowsElement = rowsElement.substring(0, rowsElement.length() - 1);
			List<WebElement> rows = driver.findElements(By.xpath(rowsElement));
			for (int i = 1; i <= rows.size(); i++) {
				String element = rowsElement + "[" + i + "]";
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(element))));
				String text = driver.findElement(By.xpath(element)).getText().toLowerCase().trim();
				if (text.contains("automation test")) {
					String actionElement = unitAction.toString().split("xpath:")[1].trim();
					actionElement = actionElement.substring(0, actionElement.length() - 1) + "[" + i + "]";
					driver.findElement(By.xpath(actionElement)).click();
					String deleteElement = unitDelete.toString().split("xpath:")[1].trim();
					deleteElement = deleteElement.substring(0, deleteElement.length() - 1) + "[" + i + "]";
					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(deleteElement))));
					driver.findElement(By.xpath(deleteElement)).click();
					wait.until(ExpectedConditions.visibilityOf(unitYesButton));
					wait.until(ExpectedConditions.elementToBeClickable(unitYesButton));
					unitYesButton.click();
					break;
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	

	public void clickOnCreateLevelButton() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(createLevel2Link));
		createLevel2Link.click();
	}

	public void enterLevelDetails(String adr1, String city, String country, String state, String zip) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(unitName));
		unitName.sendKeys("Automation Test");
		wait.until(ExpectedConditions.visibilityOf(unitAdr1));
		unitAdr1.sendKeys(adr1);
		unitCity.sendKeys(city);
		Select drpCountry = new Select(selectUnitCountry);
		drpCountry.selectByVisibleText(country);
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		selectunitState.click();
		Select drpState = new Select(selectunitState);
		drpState.selectByVisibleText(state);
		unitZip.sendKeys(zip);
	}

	public void clickCreateUnit() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(unitCreate));
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", unitCreate);

	}

	public void deleteUnit() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(actionsBtn)).click();
		wait.until(ExpectedConditions.visibilityOf(deleteUnit)).click();
	}

	public void clickActionButton() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(unitAction));
		unitAction.click();
	}

	public void clickEditButton() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(unitEdit));
		unitEdit.click();
	}

	public void editUnitDetails() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(unitName));
			String name = unitName.getAttribute("value");
			System.out.println("Name of the unit is " + name);
			unitName.click();
			if (name.contains("_update")) {
				unitName.clear();
				unitName.sendKeys(name.replace("_update", ""));
				unitAdr1.click();
			} else
				unitName.sendKeys("_update");
			Thread.sleep(2000);
		} catch (Exception e) {

		}
	}

	public void viewAutomatedUnit() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(unitRow));
		wait.until(ExpectedConditions.elementToBeClickable(unitRow));
		String rowsElement = unitRow.toString().split("xpath:")[1].trim();
		rowsElement = rowsElement.substring(0, rowsElement.length() - 1);
		List<WebElement> rows = driver.findElements(By.xpath(rowsElement));
		for (int i = 1; i <= rows.size(); i++) {
			String element = rowsElement + "[" + i + "]";
			String text = driver.findElement(By.xpath(element)).getText().toLowerCase().trim();
			if (text.contains("automation test")) {
				String actionElement = unitAction.toString().split("xpath:")[1].trim();
				actionElement = actionElement.substring(0, actionElement.length() - 1) + "[" + i + "]";
				driver.findElement(By.xpath(actionElement)).click();
				String unitViewString = unitView.toString().split("xpath:")[1].trim();
				unitViewString = unitViewString.substring(0, unitViewString.length() - 1) + "[" + i + "]";
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitViewString))));
				driver.findElement(By.xpath(unitViewString)).click();
				break;
			} else if (text.contains("pati")) {
				String actionElement = unitAction.toString().split("xpath:")[1].trim();
				actionElement = actionElement.substring(0, actionElement.length() - 1) + "[" + i + "]";
				driver.findElement(By.xpath(actionElement)).click();
				String unitViewString = unitView.toString().split("xpath:")[1].trim();
				unitViewString = unitViewString.substring(0, unitViewString.length() - 1) + "[" + i + "]";
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitViewString))));
				driver.findElement(By.xpath(unitViewString)).click();
				break;
			}
		}
	}

	public void clickOnUnitAdminButton() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(AddUnitButton));
		wait.until(ExpectedConditions.elementToBeClickable(AddUnitButton));
		AddUnitButton.click();
	}

	public void searchAvailableUser(String email) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(searchTextBox));
		wait.until(ExpectedConditions.elementToBeClickable(searchTextBox));
		searchTextBox.click();
		searchTextBox.sendKeys(email);
	}

	public void selectAvailableUser() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(learnerSearchResult));
		String result = learnerSearchResult.getText();
		while (result.length() == 0) {
			result = learnerSearchResult.getText();
		}
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", learnerSearchOption);
	}

	public void clickAddUnitAdmin() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(buttonAddUnitAdmin));
		wait.until(ExpectedConditions.elementToBeClickable(buttonAddUnitAdmin));
		buttonAddUnitAdmin.click();
	}

	public void checkRowAvailable() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(adminTableRow));
	}

/////////////////////////////////////////////////////////////////// JOB TITLE /////////////////////////////////////////////////////////////////////////	

	public void navigateOrgSettings() {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(OrganizationSettingsTab)).click();
		;
	}

	public void navigateTitle() {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(titleTab));
		titleTab.click();
	}

	public void clickOnCreateTitle() {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(createTitle));
		createTitle.click();
	}

	public void enterTitleDetails() {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(newTitleName));
		String date = new java.util.Date().toString();
		date = date.replace(" ", "");
		String name = "Title_" + date;
		newTitleName.sendKeys(name);
		OrganizationSettings. titleName = name;
	}

	public void clickOnCreateButton() {
		createJob.click();
	}

	public void searchTitleName() {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(titleSearch));
		titleSearch.sendKeys(OrganizationSettings.titleName);
		searchTitleButton.click();
	}

	public void validateSearchTitleResult() {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(titleSearchPage));
		String result = titleSearchResult.getText();
		System.out.println("Title name is " +OrganizationSettings. titleName);
		System.out.println("Searched title name is " + result);
		Assert.assertEquals(OrganizationSettings.titleName.trim(), result.trim());
	}

	public void clickOnEditTitle() {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(editTitle));
		editTitle.click();
	}

	public void clickCreateOrganization() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.elementToBeClickable(CreateOrganization));
		CreateOrganization.click();
	}

	public void verifylmsinfoForCtcOrg(String value) {
		Assert.assertFalse(driver.findElement(By.xpath("//label[text() ='" + value + "']")).isDisplayed());
		
		//label[text() = 'LMS Information']
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			System.out.println("The '\"+value+\"' is not available");
		}
	}

	public void enterUpdatedTitleDetails() {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(newTitleName));
		newTitleName.click();
		newTitleName.clear();
		newTitleName.sendKeys(OrganizationSettings.titleName + "_update");
	}

	public void clickOnSaveButton() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(saveTitle));
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].click()", saveTitle);
	}

	public void clickOnViewJob() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(viewJob));
		viewJob.click();
	}

	public void validateJob() {

		Assert.assertTrue("Validation Job name",
				driver.findElement(By.xpath("//*[@class='form-group']//span[contains(text(),'" + OrganizationSettings.titleName + "')]"))
						.getText().contains(OrganizationSettings.titleName));
	}

	public void navigateGroup() {
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", groupTab);
	}

	public void clickOnCreateGroup() {
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", createGroup);
	}

	public void enterGroupDetails() {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(newGroupName));
		String date = new java.util.Date().toString();
		date = date.replace(" ", "");
		String name = "group_" + date;
		newGroupName.sendKeys(name);
		OrganizationSettings.groupName1 = name;
	}

	public void clickOnCreate() {
		createButton.click();
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(createGroup));
	}

	public void searchGroupName() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOf(groupSearch));
			groupSearch.sendKeys(OrganizationSettings.groupName1);
			searchButton.click();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			String val = js.executeScript("return document.readyState").toString();
			System.out.println(val);
			while (!(val.equalsIgnoreCase("complete"))) {
				val = js.executeScript("return document.readyState").toString();
			}
			Thread.sleep(5000);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void validateSearchResult() {
		String result = searchResult.getText();
		System.out.println("Group name is " + OrganizationSettings.groupName1);
		System.out.println("Searched group name is " + result);
		Assert.assertEquals(OrganizationSettings.groupName1.trim(), result.trim());
	}

	public void clickOnEditGroup() {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(editGroup));
		editGroup.click();
	}

	public void enterUpdatedGroupDetails() {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(newGroupName));
		newGroupName.click();
		newGroupName.clear();
		newGroupName.sendKeys(OrganizationSettings.groupName1 + "_update");
		OrganizationSettings.groupName1 = OrganizationSettings.groupName1 + "_update";
	}

	public void addusergroup(String email) {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(search));
		search.click();
		search.clear();
		for (int i = 0; i < User.userEmail.length(); i++)
			search.sendKeys(String.valueOf(User.userEmail.charAt(i)));
		try {
			String result = studentSearchResult.getText();
			int k = 0;
			while (result.length() == 0) {
				result = studentSearchResult.getText();
				if (k == 232)
					break;
				k++;
			}
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", studentSearchOption);
		} catch (Exception e) {
		}
		wait.until(ExpectedConditions.visibilityOf(addUser));
		addUser.click();
	}

	public void clickOnViewGroup() {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(viewGroup));
		viewGroup.click();
	}

	public void validateGroup() {
		Assert.assertTrue("Validation group name",
				driver.findElement(By.xpath("//*[@id=\"groupform\"]//p[text()='" + OrganizationSettings.groupName1 + "']")).getText()
						.contains(OrganizationSettings.groupName1));
	}

	public void enterOtherGroupDetails() {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(newGroupName));
		String date = new java.util.Date().toString();
		date = date.replace(" ", "");
		String name = "group_" + date;
		newGroupName.sendKeys(name);
		OrganizationSettings.groupName2 = name;
	}

	public void searchOtherGroupName() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOf(groupSearch));
			groupSearch.sendKeys(OrganizationSettings.groupName2);
			searchButton.click();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			String val = js.executeScript("return document.readyState").toString();
			System.out.println(val);
			while (!(val.equalsIgnoreCase("complete"))) {
				val = js.executeScript("return document.readyState").toString();
			}
			Thread.sleep(5000);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void validateAnotherSearchResult() {
		String result = searchResult.getText();
		System.out.println("Group name is " + OrganizationSettings.groupName2);
		System.out.println("Searched group name is " + result);
		Assert.assertEquals(OrganizationSettings.groupName2.trim(), result.trim());
	}

///////////////////////////////////////////////////////////////////////////////////////////////////////////

	public void addLearnerDetailsManually() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(addManuallyRadioButton));
		wait.until(ExpectedConditions.elementToBeClickable(addManuallyRadioButton));
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		date = date.replace(" ", "").replace(":", "").replace("-", "");
		addManuallyRadioButton.click();
		wait.until(ExpectedConditions.elementToBeClickable(firstNameText));
		firstNameText.click();
		firstNameText.sendKeys("user");
		lastNameText.click();
		lastNameText.sendKeys("Test");
		emailText.click();
		User.userEmail = date + prop.getProperty("userDomain");
		emailText.sendKeys(User.userEmail);
		wait.until(ExpectedConditions.visibilityOf(buttonManuallyEnable));
	}

	public void clickAddUnitAdminManually() {
		try {
			Thread.sleep(4000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(buttonAddUnitAdminManually));
			wait.until(ExpectedConditions.elementToBeClickable(buttonAddUnitAdminManually));
			buttonAddUnitAdminManually.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickOnUnitObserverButton() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(AddUnitObserverButton));
			wait.until(ExpectedConditions.elementToBeClickable(AddUnitObserverButton));
			AddUnitObserverButton.click();
			try {
				wait.until(ExpectedConditions.visibilityOf(UnitObserverPopUp));
			} catch (Exception e) {
				clickOnUnitObserverButton();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickAddUnitObserverManually() {
		try {
			Thread.sleep(4000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(buttonAddUnitObserverManually));
			wait.until(ExpectedConditions.elementToBeClickable(buttonAddUnitObserverManually));
			buttonAddUnitObserverManually.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void validateDemographicSettings() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		// wait.until(ExpectedConditions.visibilityOf(DemographicSettingsTab)).getText();
		boolean tabisvisible = DemographicSettingsTab.isDisplayed();
		Assert.assertTrue(tabisvisible);
	}

	public void AddTechnicalContacts() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(TechnicalContactsTab)).click();
		AddTechnicalContactsBtn.click();
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		date = date.replace(" ", "").replace(":", "").replace("-", "");
		wait.until(ExpectedConditions.elementToBeClickable(firstnameText_technicalContacts));
		firstnameText_technicalContacts.click();
		firstnameText_technicalContacts.sendKeys("user");
		lastnameText_technicalContacts.click();
		lastnameText_technicalContacts.sendKeys("Test");
		emailText_technicalContacts.click();
		User.userEmail = date + prop.getProperty("userDomain");
		emailText_technicalContacts.sendKeys(User.userEmail);
		AddContactsBtn.click();
	}

	public void EditTechnicalContacts() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(EditTechnicalContact)).click();
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		date = date.replace(" ", "").replace(":", "").replace("-", "");
		wait.until(ExpectedConditions.elementToBeClickable(firstNameEdit_technicalContacts));
		firstNameEdit_technicalContacts.click();
		firstNameEdit_technicalContacts.sendKeys(Keys.chord(Keys.CONTROL, "a"));
		firstNameEdit_technicalContacts.sendKeys("user2");
		lastNameEdit_technicalContacts.click();
		lastNameEdit_technicalContacts.sendKeys(Keys.chord(Keys.CONTROL, "a"));
		lastNameEdit_technicalContacts.sendKeys("Test2");
		emailEdit_technicalContacts.click();
		emailEdit_technicalContacts.sendKeys(Keys.chord(Keys.CONTROL, "a"));
		User.userEmail = date + "_2" + prop.getProperty("userDomain");
		emailEdit_technicalContacts.sendKeys(User.userEmail);
		submitBtn_technicalContacts.click();
	}
	
	public void deleteTechnicalContacts() {
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOf(deleteTechnicalContactsicon)).click();
		//deleteTechnicalContactsicon.click();
		wait.until(ExpectedConditions.visibilityOf(deleteBtn)).click();
	}

	public void validateSucessMesssage(String msg) {
		if(AssignmentReport.checkifParmeterAvailable(msg))
			msg=AssignmentReport.getParmeterAvailable(msg);
		
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			System.out.println("Validate Message " + msg);
			wait.until(ExpectedConditions.visibilityOf(technicalContactSuccessMsg));
			System.out.println("Message in UI" + technicalContactSuccessMsg.getText());
			Assert.assertTrue(technicalContactSuccessMsg.getText().contains(msg));
			wait.until(ExpectedConditions.visibilityOf(successMsgCloseButton));
			successMsgCloseButton.click();
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Error while creating technical contacts");
		}

	}

	public void validateUpdateSucessMesssage(String msg) {

		if(AssignmentReport.checkifParmeterAvailable(msg))
			msg=AssignmentReport.getParmeterAvailable(msg);
		
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			System.out.println("Validate Message " + msg);
			wait.until(ExpectedConditions.visibilityOf(technicalContactUpdateSuccessMsg));
			System.out.println("Message in UI" + technicalContactUpdateSuccessMsg.getText());
			Assert.assertTrue(technicalContactUpdateSuccessMsg.getText().contains(msg));
			wait.until(ExpectedConditions.visibilityOf(successMsgCloseButton));
			successMsgCloseButton.click();
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Error while updating technical contacts");
		}

	}

	public void validateDeleteSucessMesssage(String msg) {
		
		if(AssignmentReport.checkifParmeterAvailable(msg))
			msg=AssignmentReport.getParmeterAvailable(msg);
		
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			System.out.println("Validate Message " + msg);
			wait.until(ExpectedConditions.visibilityOf(deleteTechnicalContactSuccessMsg));
			System.out.println("Message in UI" + deleteTechnicalContactSuccessMsg.getText());
			Assert.assertTrue(deleteTechnicalContactSuccessMsg.getText().contains(msg));
			wait.until(ExpectedConditions.visibilityOf(successMsgCloseButton));
			successMsgCloseButton.click();
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Error while deleting technical contacts");
		}

	}

	public void clickOnPurchaseHistory() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(purchaseHistoryTab)).click();
	}

	public void clickExportToCsv() throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(exportToCsv)).click();
		Thread.sleep(2000);
		isFileDownloaded_Ext(downloadPath, ".csv");
		Assert.assertTrue(true);
	}

	public void clickExportToExcel() throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(exportToExcel)).click();
		Thread.sleep(2000);
		isFileDownloaded_Ext(downloadPath, ".xlsx");
		Assert.assertTrue(true);
	}

	public void clickExportToPdf() throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(exportToPdf)).click();
		Thread.sleep(2000);
	
		Assert.assertTrue(	isFileDownloaded_Ext(downloadPath, ".pdf"));
	}

	public boolean checkCSVFilePresent() {
		boolean dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
		return dwnld;
	}

	public boolean isFileDownloaded_Ext(String dirPath, String ext) {
		boolean flag = false;
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files != null) {
			for (int i = 0; i < files.length; i++) {
				if (files[i].getName().contains(ext) && !(files[i].getName().contains(".crdowmload"))) {
					fileName = files[i].getName();
					filePath = files[i].getAbsolutePath();
					filePath = filePath.replace(".crdownload", "");
					flag = true;
					break;
				}
			}
		}

		return flag;
	}

	public void uploadFileForFailureValidations() {
		WebDriverWait wait = new WebDriverWait(driver, 180);
		wait.until(ExpectedConditions.visibilityOf(uploadFileLink));
		uploadFileLink.click();
		wait.until(ExpectedConditions.visibilityOf(buttonClose));
		int count = Integer.parseInt(failureCount.getText());
		System.out.println("Count is :" + count);
		Assert.assertTrue(count > 3);
		buttonClose.click();
	}

	public void clickDemographicReport() {
		WebDriverWait wait = new WebDriverWait(driver, 180);
		wait.until(ExpectedConditions.visibilityOf(demographicReportlink));
		demographicReportlink.click();
	}

	public void validateDemographicReportSearch() {

		WebDriverWait wait = new WebDriverWait(driver, 180);
		wait.until(ExpectedConditions.visibilityOf(startDateFilterOption)).click();
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();
		String date1 = dateFormat.format(date);
		System.out.println("Today's Date is " + date1);
		// dateSelection.click();
		wait.until(ExpectedConditions.visibilityOf(dateSelection)).click();
		wait.until(ExpectedConditions.visibilityOf(endDateFilterOption)).click();
		wait.until(ExpectedConditions.visibilityOf(dateSelection)).click();
		wait.until(ExpectedConditions.visibilityOf(searchIcon)).click();

	}

	public void clearSearchFilter() {
		WebDriverWait wait = new WebDriverWait(driver, 180);
		wait.until(ExpectedConditions.visibilityOf(clearSearchBtn)).click();
	}

	public void clickDemographicSettings() {
		WebDriverWait wait = new WebDriverWait(driver, 180);
		wait.until(ExpectedConditions.visibilityOf(demographicSettingslink));
		demographicSettingslink.click();
	}
	public void getUnitCount()
	{
		try {
		OrganizationSettings.	unitCount = 0;
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOf(unitRow));
			wait.until(ExpectedConditions.elementToBeClickable(unitRow));
			String rowsElement = unitRow.toString().split("xpath:")[1].trim();
			rowsElement = rowsElement.substring(0, rowsElement.length()-1);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(rowsElement + "[1]"))));
			Thread.sleep(5000);
			List<WebElement> pagination = driver.findElements(By.xpath(groupPagination));
			if(pagination.size() > 0) {
				for(int i = 1; i <= pagination.size(); i++) {
					driver.findElement(By.xpath(groupPagination + "[" + i + "]")).click();
					Thread.sleep(5000);
					String attr = driver.findElement(By.xpath(groupPagination + "[" + i + "]")).getAttribute("class");
					while(!attr.equals("paginate_button current"))
					{		
						driver.findElement(By.xpath(groupPagination + "[" + i + "]")).click();
						attr = driver.findElement(By.xpath(groupPagination + "[" + i + "]")).getAttribute("class");
					}
					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(rowsElement + "[1]"))));
					List<WebElement> groupRows = driver.findElements(By.xpath(rowsElement));
					OrganizationSettings.	unitCount =	OrganizationSettings. unitCount + groupRows.size();
			
			
				}	
			}
			System.out.println("Total units available are " +	OrganizationSettings. unitCount);
		} 
		catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}
	public void saveDemographicSettingsWithFullFeed() {
		WebDriverWait wait = new WebDriverWait(driver, 180);
		wait.until(ExpectedConditions.visibilityOf(fullFeed));
		fullFeed.click();
		wait.until(ExpectedConditions.visibilityOf(demographicSettingsSaveBtn));
		demographicSettingsSaveBtn.click();
	}

	public void saveDemographicSettings(String message) {
		if(AssignmentReport.checkifParmeterAvailable(message))
			message=AssignmentReport.getParmeterAvailable(message);
        
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			System.out.println("Validate Message " + message);
			wait.until(ExpectedConditions.visibilityOf(demographicSettingsSuccessMsg));
			System.out.println("Message in UI" + demographicSettingsSuccessMsg.getText());
			Assert.assertTrue(demographicSettingsSuccessMsg.getText().contains(message));
			wait.until(ExpectedConditions.visibilityOf(successMsgCloseButton));
			successMsgCloseButton.click();
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Error while updating demographic settings");
		}
	}

	public void enterAnotherLevelDetails(String adr1, String city, String country, String state, String zip)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(unitName));
		String date = new java.util.Date().toString();
		date = date.replace(" ", "");
	   OrganizationSettings.	newUnitName = "Unit_"+date;
		unitName.sendKeys(  OrganizationSettings.	newUnitName);		
		wait.until(ExpectedConditions.visibilityOf(unitAdr1));
		unitAdr1.sendKeys(adr1);
		unitCity.sendKeys(city);
		Select drpCountry = new Select(selectUnitCountry);
		drpCountry.selectByVisibleText(country);
		driver.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);
		Select drpState = new Select(selectunitState);
		drpState.selectByVisibleText(state);
		unitZip.sendKeys(zip);
	}

	String groupTableRow = "//table[@aria-describedby = 'tablelisting_info']//tbody/tr";
	String groupPagination = "//div[@id = 'tablelisting_paginate']//a[not (@id)]";
	
	public void getGroupCount()
	{
		try {
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(groupTableRow + "[1]"))));
			Thread.sleep(5000);
			List<WebElement> pagination = driver.findElements(By.xpath(groupPagination));
			if(pagination.size() > 0) {
				for(int i = 1; i <= pagination.size(); i++) {
					driver.findElement(By.xpath(groupPagination + "[" + i + "]")).click();
					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(groupTableRow + "[1]"))));
					List<WebElement> groupRows = driver.findElements(By.xpath(groupTableRow));
					OrganizationSettings.groupCount =	OrganizationSettings. groupCount + groupRows.size();
			
			
				}	
			}
			System.out.println("Total groups available are " + 	OrganizationSettings.groupCount);
		} 
		catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}
	
	public void getMemberCount()
	{
		WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(groupTableRow + "[1]"))));
    	OrganizationSettings.    memberCount = Integer.parseInt(driver.findElement(By.xpath(groupTableRow + "[1]/td[3]")).getText());
        System.out.println("Total member available are " +	OrganizationSettings. memberCount);
	}
	
	public void navigateLevel3() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(level3Link));
		level3Link.click();
	}
	public void getLevelAndUnitNamesForUnitAdmin() {
		try {
			map=new LinkedHashMap<String,String>();
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(level2Link));
			List<WebElement> level = driver.findElements(By.xpath(levelList));
			for(int i = 1; i <= level.size(); i++) {
				String subLevelUnitName = null;
				driver.findElement(By.xpath(levelList + "[" + i + "]/a")).click();
				String levelName = driver.findElement(By.xpath(levelList + "[" + i + "]/a")).getText().trim();
				wait.until(ExpectedConditions.visibilityOf(unitRow));
				wait.until(ExpectedConditions.elementToBeClickable(unitRow));
				String rowsElement = unitRow.toString().split("xpath:")[1].trim();
				rowsElement = rowsElement.substring(0, rowsElement.length()-1);
				List<WebElement> rows = driver.findElements(By.xpath(rowsElement));
				for(int j = 1; j <= rows.size(); j++)
				{
					String element = rowsElement + "[" + j + "]";
					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(element))));						
					String text =  driver.findElement(By.xpath(element)).getText().trim();
					String code = driver.findElement(By.xpath(unitCode + "[" + j + "]/td[3]")).getText();
					if(code.length() > 0)
						text = code + " - " + text;
					if(subLevelUnitName == null)
						subLevelUnitName = text;
					else
						subLevelUnitName = subLevelUnitName + "," + text;
				}
				map.put(levelName, subLevelUnitName);
			}
			System.out.println(map);
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
	public void enterLevelDetailsWithUnits(String adr1, String city, String country, String state, String zip, int unitLevel) {
		try {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(unitName));
		unitName.sendKeys("Automation Test");
		wait.until(ExpectedConditions.visibilityOf(addEditBtn));
		addEditBtn.click();
		for(int i = 1; i <  unitLevel-1; i++)
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(selectUnits + "[" + i + "]"))));
			driver.findElement(By.xpath(selectUnits + "[" + i + "]")).click();
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitSelection + "[" + i + "]"))));
			driver.findElement(By.xpath(unitSelection + "[" + i + "]")).click();
			Thread.sleep(3000);
		}
		
		wait.until(ExpectedConditions.visibilityOf(saveUnitBtn));
		saveUnitBtn.click();
		wait.until(ExpectedConditions.visibilityOf(unitAdr1));
		unitAdr1.sendKeys(adr1);
		unitCity.sendKeys(city);
		Select drpCountry = new Select(selectUnitCountry);
		drpCountry.selectByVisibleText(country);
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		Select drpState = new Select(selectunitState);
		drpState.selectByVisibleText(state);
		unitZip.sendKeys(zip);
		}
		catch(Exception e)
		{
			
		}
	}
	public void getLevelAndUnitNames() {
		try {
			map=new LinkedHashMap<String,String>();
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(level2Link));
			List<WebElement> level = driver.findElements(By.xpath(levelList));
			for(int i = 1; i <= level.size(); i++) {
				String subLevelUnitName = null;
				driver.findElement(By.xpath(levelList + "[" + i + "]/a")).click();
				String levelName = driver.findElement(By.xpath(levelList + "[" + i + "]/a")).getText().trim();
				if(i == 1) {
					String unitName = driver.findElement(By.xpath(orgName)).getText().trim();
					map.put(levelName, unitName);
				}
				else {
					wait.until(ExpectedConditions.visibilityOf(unitRow));
					wait.until(ExpectedConditions.elementToBeClickable(unitRow));
					String rowsElement = unitRow.toString().split("xpath:")[1].trim();
					rowsElement = rowsElement.substring(0, rowsElement.length()-1);
					List<WebElement> rows = driver.findElements(By.xpath(rowsElement));
					for(int j = 1; j <= rows.size(); j++)
					{
						String element = rowsElement + "[" + j + "]";
						wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(element))));						
						String text =  driver.findElement(By.xpath(element)).getText().trim();
						String code = driver.findElement(By.xpath(unitCode + "[" + j + "]/td[3]")).getText();
						if(code.length() > 0)
							text = code + " - " + text;
						if(subLevelUnitName == null)
							subLevelUnitName = text;
						else
							subLevelUnitName = subLevelUnitName + "," + text;
					}
					map.put(levelName, subLevelUnitName);
				}
			}
			System.out.println(map);
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
