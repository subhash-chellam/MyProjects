package com.qa.pages;

//import static org.junit.jupiter.api.Assertions.assertArrayEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.qa.util.TestBase;

import junit.framework.Assert;

public class Encryption extends TestBase{
	public Encryption() 
	{
		PageFactory.initElements(driver, this);
		
	}
	
	
	@FindBy(xpath = "//select[@id='encryption-method']")
	WebElement encryptiondropdown;
	
	@FindBy(xpath = "//div[@class=\"modal-content\"]//div[@class=\"modal-footer\"]//button[@id='upload-key-modal-submit'][@disabled='disabled']")
	WebElement uploadkeydisabled;
	
	@FindBy(xpath = "//button[contains(text(),'Generate Key')][@disabled='disabled']")
	WebElement Generatekeydisabled;
	
	@FindBy(xpath = "//a[contains(text(),'Demographic Template Settings')]")
	WebElement Demographictemplatelink;
	
	@FindBy(xpath = "//button[@id='upload-key-button']")
	WebElement uploadkeybutton;
	
	
	@FindBy(xpath = "//*[@id=\"regenerate-key-button\"]")
	WebElement regeneratekeybutton;
	
	
	
	@FindBy(xpath = "//button[@id='generate-key-button']")
	WebElement generatekeybutton;
	
	@FindBy(xpath = "//*[@id='remove-encryption']")
	WebElement removekeybutton;
	
	
	@FindBy(xpath = "(//*[@id=\"sftp_type_form\"]//button)[1]")
	WebElement viewkeybutton;
	
	
	@FindBy(xpath = "//textarea[@id='org-key']")
	WebElement textarea;
	
	
	
	@FindBy(xpath = "(//*[@id=\"encryption-key-modal\"]//div[@class='col-md-12'])[2]")
	WebElement publickey;

	@FindBy(xpath = "(//*[@id=\"encryption-key-modal\"]//div[@class='col-md-12'])[1]")
	WebElement privatekey;

	@FindBy(xpath = "//strong[contains(text(),'Encryption Key - Upload')]")
	WebElement headingwithinpopup;
	
	@FindBy(xpath = "//strong[contains(text(),'Encryption Key - View')]")
	WebElement headingwithinpopupview;
	@FindBy(xpath = "//button[@id='upload-key-modal-submit'][@disabled='disabled']")
	WebElement uploadkeyisdisabled;
	
	@FindBy(xpath = "(//div[@class=\"modal-content\"]//div[@class=\"modal-header\"]//button[@class='close'])[1]")
	WebElement clickclose;

	
	@FindBy(xpath = "//*[@id=\"encryption-modal-close\"]")
	WebElement clickcloseBtn;
	
	public void demographiclinkclick() {
		wait.until(ExpectedConditions.visibilityOf(Demographictemplatelink));
		
		Demographictemplatelink.click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			System.out.println("demographic template lin has been clicked");
		}
		
	}
	public void labeldisplayedverification(String string) {
		
		Assert.assertTrue(driver.findElement(By.xpath("//label[contains(text(),'"+string+"')]")).isDisplayed());
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			System.out.println("The label '\"+string+\"' is verified");
		}
	}

	public void selectencryption(String string) throws InterruptedException {
		
		wait.until(ExpectedConditions.visibilityOf(encryptiondropdown));
		
		encryptiondropdown.click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//option[contains(text(),'"+string+"')]")).click();
	}

	
public void defaultselectedvalue(String string) throws InterruptedException {
		
		Select select = new Select(encryptiondropdown);
		Assert.assertEquals(select.getFirstSelectedOption().getText(), string);
	
		
	}

	public void isdiplayedverification(String string) {
		
		
	}
	public void verifybuttonsdisabledbydefault(String string) {
		Assert.assertTrue(driver.findElement(By.xpath("//button[contains(text(),'"+string+"')][@disabled='disabled']")).isDisplayed());
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			System.out.println("The label '\"+string+\"' is verified");
		}
	}
	
	public void verifybuttonsdisabledbyenable(String string) {
		Assert.assertTrue(driver.findElement(By.xpath("//button[contains(text(),'"+string+"')]")).isDisplayed());
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			System.out.println("The label '\"+string+\"' is verified");
		}
	}
	public void verifybuttonsenabledafterverification(String string) {
			try
			{
			driver.findElement(By.xpath("//button[contains(text(),'"+string+"')][@disabled='disabled']")).isDisplayed();
			Assert.fail("elementnot found as expected");
			}
			catch(Exception e)
			{
				System.out.println("button is enabled");
			}
		}
	
	public void clickuploadkey() throws InterruptedException {
		wait.until(ExpectedConditions.visibilityOf(uploadkeybutton));
		
	 uploadkeybutton.click();
	 Thread.sleep(2000);
		
	}
	public void clickgeneratekeybutton() throws InterruptedException {
		wait.until(ExpectedConditions.visibilityOf(generatekeybutton));
		
		generatekeybutton.click();
		 Thread.sleep(2000);
			
		}
	
	public void clickregeneratekeybutton() throws InterruptedException {
		wait.until(ExpectedConditions.visibilityOf(regeneratekeybutton));
		
		regeneratekeybutton.click();
		 Thread.sleep(2000);
			
		}
	
	
	public void clickremovekeybutton() throws InterruptedException {
		 Thread.sleep(3000);
			
		wait.until(ExpectedConditions.visibilityOf(removekeybutton));
		
		removekeybutton.click();
		 Thread.sleep(2000);
			
		}
	public void clickViewkeybutton() throws InterruptedException {
		 Thread.sleep(2000);
			
		wait.until(ExpectedConditions.visibilityOf(viewkeybutton));
	
		
		viewkeybutton.click();
		 Thread.sleep(2000);
			
		}
	public void verifyheaderwithinpopup(String view) {
		if(view.contains("View"))
			Assert.assertTrue(headingwithinpopupview.isDisplayed());
		else
		Assert.assertTrue(headingwithinpopup.isDisplayed());
		
	}
	public void uploadkeydisabled() {
		
		Assert.assertTrue(uploadkeydisabled.isDisplayed());
	}
	public void textareapresent() {
		Assert.assertTrue(textarea.isDisplayed());
		
	}
	public void entertextwithintextarea(String string) {
		textarea.sendKeys(string);
		textarea.sendKeys(Keys.TAB);
		
	}
	
	public void validatepublickey(String string) {
	
		wait.until(ExpectedConditions.visibilityOf(publickey));
		
		Assert.assertTrue(publickey.getText().contains(string));
		
	}
	
	public void validateprivatekey(String string) {
		wait.until(ExpectedConditions.visibilityOf(privatekey));
		
		
		Assert.assertTrue(privatekey.getText().contains(string));
		
	}
	public void uploadkeyisenabled() {
		try
		{
		driver.findElement(By.xpath("//button[contains(text(),'Upload')][@disabled='disabled']")).isDisplayed();
		Assert.fail("elementnot found as expected");
		}catch(Exception e)
		{
			System.out.println("upload button is enabled within pop up");
		}
		
	}
	public void closepopup() throws InterruptedException
	{
		try
		{
		clickclose.click();
		Thread.sleep(1000);
		}
		catch(Exception e)
		{
			clickcloseBtn.click();
		}
	}
	public void labelsnotdisplayed(String string) {
		try
		{
		driver.findElement(By.xpath("//label[contains(text(),'\"+string+\"')]")).isDisplayed();
		Assert.fail("element not found as expected");
		}
		catch(Exception e)
		{
			System.out.println("label is not displayed");
		}
	}	
	}

		
	

