package com.qa.pages;

import java.awt.Robot;
import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.Calendar;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.python.modules.thread.thread;

import com.qa.util.TestBase;

public class Scrom extends TestBase 
{
	@FindBy(xpath = "//a[text() = 'Sign up now']")
	WebElement signUpLink;
	
	@FindBy(xpath = "//input[@type = 'email']")
	WebElement emailText;

	@FindBy(xpath = "//*[@id='collapse1']/tr/td")
	WebElement rowmsg;


	@FindBy(xpath = "//*[@id='past_todo']//td[@title='Completed Activities']//span")
	List<WebElement>  completedActivit;

	@FindBy(xpath = "//*[@id='hideshowbtn']")
	WebElement completeBtn;

	
	
	@FindBy(xpath = "//*[@id='past_todo']//span[text()='Review']")
	List<WebElement>  reviewBtn;
	
	
	
	@FindBy(xpath = "//*[@id='email']")
	WebElement emailTt;
	
	@FindBy(xpath = "//*[@id='cmeEvaluationValidation']//div[@class='full clearfix']")
	WebElement message;
	
	
	
	@FindBy(xpath = "//input[@id = 'password']")
	WebElement pwdText;
	
	@FindBy(xpath = "//input[@id = 'confirmPassword']")
	WebElement cnfrmPwdText;
	
	@FindBy(xpath = "//input[@id = 'firstName']")
	WebElement firstName;
	
	@FindBy(xpath = "//input[@id = 'first_name']")
	WebElement firstNameself;
	
	@FindBy(xpath = "//*[@id='registerbut']")
	WebElement registerbtn;
	
	
	@FindBy(xpath = "(//*[@id='libraryWrapper']//div[@class='card sandbox-card']/div)[1]")
	WebElement scromStatus;

	@FindBy(xpath = "//h4[@id = 'defaultmsg']")
	WebElement errorMessage;

	
	@FindBy(xpath = "//input[@id='last_name']")
	WebElement lastNameself;
	
	@FindBy(xpath = "//input[@id = 'lastName']")
	WebElement lastName;
	
	@FindBy(xpath = "//label[@for = 'termsAgreed']")
	WebElement checkBox;
	
	@FindBy(xpath = "//button[@id = 'signupSubmitBtn']")
	WebElement signUpButton;
	
	@FindBy(xpath = "//button[@id = 'nav-btn']")
	WebElement addContentButton;

	

	
	
	@FindBy(xpath = "//span[contains(@class, 'close')]")
	WebElement closeIcon;
	
	@FindBy(xpath = "(//div[@class = 'dropdown-menu show']//a)[1]")
	WebElement importPackageLink;
	
	@FindBy(xpath = "//label[@for = 'lib_importForm_fileToImport']")
	WebElement browseButton;
		
	@FindBy(xpath = "//button[text() = 'Import Course']")
	WebElement importButton;
	
	
	@FindBy(xpath = "//a[@title='Exit activity']")
	WebElement exitActivity;
	
	
	@FindBy(xpath = "//div[contains(@title, 'Launch')]")
	WebElement courseLaunch;
	
	
	@FindBy(xpath = "//*[@id='cecmeModal']//button[text()='I, Acknowledge']")
	WebElement Acknowledge;
	
	@FindBy(xpath = "//*[@id='send-email']")
	WebElement sendEmail;
	
	

	@FindBy(xpath = "//*[@id='cmeEvaluationValidationClose']/span[text()='Close']")
	WebElement close1;
	@FindBy(xpath = "//*[@id='success-close']/button[text()='Close']")
	WebElement close;
	
	@FindBy(xpath = "//*[@id=\"libraryWrapper\"]//div[contains(text(),'Reset Progress')]")
	WebElement ResetProgress;
	
	@FindBy(xpath = "//input[@type = 'email']")
	WebElement userEmail;
	
	@FindBy(xpath = "//small[text() = 'The Email ID entered is not a valid Email']")
	WebElement validEmailError;
	
	@FindBy(xpath = "//input[@id = 'middle_name']")
	WebElement userMiddleName;
	
	@FindBy(xpath = "//button[text() = 'Save']")
	WebElement saveEmail;
	
	@FindBy(xpath = "//input[@type = 'submit']")
	WebElement submitDate;
	
	@FindBy(xpath = "//td[@title = 'ACTION']/a")
	WebElement startCourse;
	
	@FindBy(xpath = "//td[@title = 'ACTION']/a")
	WebElement endUserStartCourse;
	
	
	
	@FindBy(xpath = "//*[@id=\"courseWithoutTodoList\"]//td[@title='Action']/div/span/a")
	WebElement StartCourse;
	
	@FindBy(xpath = "//td[@title = 'Action']/a")
	WebElement startCoure;
	
	@FindBy(xpath = "//span[contains(text(), 'Resume')]")
	WebElement endUserResumeCourse;
	
	@FindBy(xpath = "//span[text() = 'Exit']")
	WebElement exitCourse;

	@FindBy(xpath = "//table[@aria-describedby = 'course-name']//tbody/tr[1]/td[4]")
	WebElement completedCourseReview;

	@FindBy(xpath = "//a[contains(text(), 'Logout')]")
	WebElement logOut;
	
	@FindBy(xpath = "(//span[@class= 'test_links'])[1]")
	WebElement complete;
	
	@FindBy(xpath = "//iframe[@id = 'basicltiLaunchFrame']")
	WebElement frameOne;
	
	@FindBy(xpath = "//iframe[@id = 'launchFrame']")
	WebElement frameOnline;
	
	
	@FindBy(xpath = "//iframe[@id = 'frame']")
	WebElement frameTwo;
	
	@FindBy(xpath = "//a[text()='Claim CME/CE']")
	WebElement CME_CE;

	@FindBy(xpath = "//iframe[@id = 'launchFrame']")
	WebElement fraeOne;
	
	@FindBy(xpath = "//div[@class='checkcredit-label']//label")
	WebElement CME_CE1;
	


	@FindBy(xpath = "//*[@id='speciality_master_id']")
	WebElement specialitymaster_id;

	@FindBy(xpath = "//*[@id='designation']")
	WebElement designation;

	@FindBy(xpath = "//*[@id='classification_code']")
	WebElement classification_code;


	@FindBy(xpath = "//*[@id='state']")
	WebElement state;

	@FindBy(xpath = "//a[text() = 'Evaluation']")
	WebElement endUserEvaluation;
	

	@FindBy(xpath = "//*[@id='submitButtonCME']")
	WebElement submitButton1;
	
	@FindBy(xpath = "//*[@id='submitButton']")
	WebElement submitButton;

	@FindBy(xpath = "//*[@id='zipcode']")
	WebElement zipcode;

	@FindBy(xpath = "//*[@id='address1']")
	WebElement address;


	@FindBy(xpath = "//*[@id='phone']")
	WebElement phone;

	@FindBy(xpath = "//*[@id='credits_claimed']")
	WebElement credits_claimed;
		
	@FindBy(xpath = "//div[@id = 'announcement']")
	WebElement announcement;
	
	@FindBy(xpath = "//span[text() = 'Exit']")
	WebElement endUserExitCourse;
	
	
	@FindBy(xpath = "//*[@id=\"archievedependentsubmit\"]")
	WebElement active;
	
	@FindBy(xpath = "//button[text() = 'Exit']")
	WebElement ExitCourse;
	
	@FindBy(xpath = "//input[@type = 'submit']")
	WebElement endUserSubmitDate;

	@FindBy(xpath = "//input[@name = 'test_today_date']")
	WebElement endUserCourseDate;
	
	@FindBy(xpath = "//*[@id=\"accept_btn\"]")
	WebElement consentaccept;
	@FindBy(xpath = "//button[text() = 'Accept']")
	WebElement subDomainFederalPopupAccept;
	
	
	@FindBy(xpath = "//*[@id='exampleModal']//div[@class='modal-body']")
	WebElement subDomainFederalPopupText;
	
	@FindBy(xpath = "//*[@id='exampleModal']//h5[@id='exampleModalLabel']")
	WebElement subDomainFederalPopupHeader;

	
	@FindBy(xpath = "//input[@type='submit']")
	WebElement Submitbutton;
	
	@FindBy(xpath = "//button[@id='savedata']")
	WebElement save;

	@FindBy(xpath = "//ul/li[2]/a")
	WebElement home;

	@FindBy(xpath = "(//td[@title = 'Action']//a)[1]")
	WebElement scromUserStartCourse;
	
	@FindBy(xpath = "//button[text() = 'Exit Exercise']")
	WebElement eLearningExitCourse;
	@FindBy(xpath = "//*[@id=\"nav-drawer\"]//li[1]//a")
	WebElement dashbroad;

	
	@FindBy(xpath = "//*[@id='page-wrap']//a[text()='View eCard ']")
	WebElement viewEcard;
	
	@FindBy(xpath = "//*[@id='page-wrap']//a[text()='Certificate']")
	WebElement Certificate;
	

	@FindBy(xpath = "//button[text()='Continue']")
	WebElement Continue;
	
	@FindBy(xpath = "//*[@id='proceed_to_ecards']")
	WebElement proceed;
	
	@FindBy(xpath = "//*[@id='page-wrap']//a[text()='Claim CME/CE']")
	WebElement ClaimCME;
	
	@FindBy(xpath = "//a[contains(text(),'(Download Certificate)')]")
	WebElement download;
	@FindBy(xpath = "//*[@id='successbox']")
	WebElement successmsg;
	
	@FindBy(xpath = "//*[@id='completeuserprofile']//a//span[text()='Cancel']")
	WebElement cancel;
	
	
	@FindBy(xpath = "//select")
	WebElement ClaimCMEpart2;
	
	@FindBy(xpath = "//*[@id='confirm-delete']//span[text()='Yes']")
	WebElement confirm;
	
	@FindBy(xpath = "//input[@type = 'submit']")
	WebElement endUserSubmitEvaluation;


	@FindBy(xpath = "//*[@id='defaultmsg']")
	WebElement msg;

	@FindBy(xpath = "//*[@id='page-wrap']/div[@class='container access-denied-container-body']/p")
	WebElement msg2;

	
	@FindBy(xpath = "//input[@value='Completed Activities']")
	WebElement completedActivitiesButton;
	

	@FindBy(xpath = "//*[@id='heading-content']/span")
	WebElement versionTopic;

	
	@FindBy(xpath = "//div[@class='scormlaunch_readericon_wrap']//li[1]/span")
	WebElement versionEachTopic;
	
	
	
	String firstRadioMandatryQuestion = "((//small[contains(text(), 'required')]//parent::div)[";
	String courseTable = "//table[contains(@class,'table panel panel-default' ) and @id='rqiCourseTodoList']";
	By rhapsodeCourse = By.xpath("(//input[@id = 'lis_result_sourcedid'])");
	String checklocked="//*[@id='collapse1']//tr";
	By mandatoryQuestion = By.xpath("//small[contains(text(), 'required')]//parent::div");
	String firstNameSelfRegister = "//input[@id = 'first_name']";
	String scromCourseTable = "//table[@class = 'table panel panel-default scormCourse-table']";
	
	
	static String  userscrom,passwordscrom,window;

	public static String email;
	RestApi rest;
	public static String courseTopic[];
	EndUser end = new EndUser();
	public Scrom() 
	{
		PageFactory.initElements(driver, this);
	}

	public void navigateToScromUrl()
	{
		driver.get(prop.getProperty("scromUrl"+prop.getProperty("environment")));
    }
	public void clickOnCompletedActivities()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(completedActivitiesButton));
		completedActivitiesButton.click();
	}
	public void clickSignUpLink()
	{
		wait.until(ExpectedConditions.visibilityOf(signUpLink));
		signUpLink.click();
	}
	
	public void clickonHome() throws InterruptedException
	{
		try
		{
		wait.until(ExpectedConditions.visibilityOf(home));
		home.click();
		}
		catch(StaleElementReferenceException e)
		{
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOf(home));
				
			home.click();
		}
	}
	
	public int getRows()
	{
			try
		{
				WebDriverWait wait = new WebDriverWait(driver, 30);

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(checklocked))));
		List<WebElement> count = driver.findElements(By.xpath(checklocked));
		return count.size();
		}
		catch(Exception e)
		{
			return 0;
		}
	}
	public void switchWindowNoEmailAsPerQuarterOnlyStart(int quarter)
	{
		try
		{
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			int m=0;
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==pagload)
					break;
				m++;
			}
			System.out.println(allWindowHandles.size());
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			for(int i = 0; i <= allWindowHandles.size()-1; i++)
			{
				driver.switchTo().window(allWindowHandles.toArray()[i].toString());
				try {
				String url = driver.getCurrentUrl();
				allWindowHandles = driver.getWindowHandles();
				if(url.contains("/dispatch") && (!url.contains("/dispatch.html")))
					break;	
				}
				catch(Exception ex)
				{
					
				}
			}
			System.out.println("After focus" + driver.getWindowHandle());
			LaunchWholeCourseWithoutEmailWithQuarter(quarter);
			driver.close();
			m=0;
			while(allWindowHandles.size() >= 3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==pagload)
					break;
				m++;
			}
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void runScriptForPastDate(String date)
	{
		try 
		{
			LocalDate currentDate = LocalDate.now();
			LocalDate courseDate = LocalDate.parse(date);
			Period diff = Period.between(courseDate, currentDate);
			int days = diff.getDays();
			int months = diff.getMonths();
			int year = diff.getYears();
			if(days >= 1 || months >= 1 || year >=1)
				System.out.println("Date is in past");
			{
				JavascriptExecutor js = (JavascriptExecutor)driver;
				js.executeScript("var testActivatedate; function setValue() {testActivateDate = '"+date+"'  }; setValue(); testActivateDate;");
			}
		} 
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}
	}
	public String changeDate(int quarter)
	{
		LocalDate localDate = LocalDate.now();
		LocalDate firstDayOfQuarter = localDate.with(localDate.getMonth().firstMonthOfQuarter()).with(TemporalAdjusters.firstDayOfMonth());
		LocalDate lastDayOfQuarter = firstDayOfQuarter.plusMonths(quarter*3).plusMonths(2).with(TemporalAdjusters.lastDayOfMonth());
		System.out.println(firstDayOfQuarter);
		System.out.println(lastDayOfQuarter);
		return lastDayOfQuarter.toString();
	}
	public void LaunchWholeCourseWithoutEmailWithQuarter(int quarter)
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);
		try {
		wait.until(ExpectedConditions.elementToBeClickable(saveEmail));
		saveEmail.click();
		}
		catch(Exception e)
		{
			
		}
		String quarterDate = changeDate(quarter);
		runScriptForPastDate(quarterDate);
		clickOnSubmitOnlyWithDate(quarterDate);
		int count = getNumberRows();
		if(count > 0)
			startORResumeCourse();
		onlyExitCourse();
	}
	public void clickOnSubmitOnlyWithDate(String date)
	{
		try
		{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(endUserSubmitDate));
		if(date.length() > 1)
		{
			endUserCourseDate.click();
			endUserCourseDate.clear();
			endUserCourseDate.sendKeys(date);
			endUserCourseDate.click();
		}
		endUserSubmitDate.click();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	public void switchWindowElearningOnlyStart(int quarter)
	{
		try
		{
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			int m=0;
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==pagload)
					break;
				m++;
			}
			System.out.println(allWindowHandles.size());
			System.out.println("Before focus " + allWindowHandles.toArray()[0]);
			for(int i = 0; i <= allWindowHandles.size()-1; i++)
			{
				driver.switchTo().window(allWindowHandles.toArray()[i].toString());
				try {
				String url = driver.getCurrentUrl();
				allWindowHandles = driver.getWindowHandles();
				if(url.contains("/dispatch") && (!url.contains("/dispatch.html")))
					break;	
				}
				catch(Exception ex)
				{
					
				}
			}
			System.out.println("After focus" + driver.getWindowHandle());
			LaunchWholeElearningCourseWithQuarter(quarter);
			driver.close();
			m=0;
			while(allWindowHandles.size() >= 3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==pagload)
					break;
				m++;
			}
			for (String handles : allWindowHandles) {
				if(!handles.contentEquals(window))
				{
					driver.switchTo().window(handles).close();
					allWindowHandles = driver.getWindowHandles();
				}
			}
			driver.switchTo().window(window);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void onlyExitElearningCourse()
	{
		try
		{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(eLearningExitCourse));
		eLearningExitCourse.click();
		}
		catch(Exception e)
		{
			onlyExitCourse();
		}
	}
	
	public void startORResumeElearningCourse()
	{
		WebDriverWait wait = new WebDriverWait(driver, 20);
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(scromUserStartCourse));
			scromUserStartCourse.click();
		}
		catch(Exception ex)
		{
			Assert.fail("Not able to start elearning topic");
		}

	}

	public void LaunchWholeElearningCourseWithQuarter(int quarter)
	{
//		enterEmail(email);
//		String quarterDate = changeDate(quarter);
//		runScriptForPastDate(quarterDate);
//		clickOnSubmitOnlyWithDate(quarterDate);
		int count = getNumberRows();
		System.out.println("No of topic rows: " + count);
		if(count > 0)
			startORResumeElearningCourse();
		onlyExitElearningCourse();
	}
	
	
	public void enterUserDetails(String email, String first, String last)
	{
		wait.until(ExpectedConditions.visibilityOf(emailText));
		last = last.toUpperCase();
		emailText.click();
		emailText.sendKeys(email);
		wait.until(ExpectedConditions.visibilityOf(pwdText));
		pwdText.click();
		pwdText.sendKeys(first + last + "@1234567890");
		wait.until(ExpectedConditions.visibilityOf(cnfrmPwdText));
		cnfrmPwdText.click();
		cnfrmPwdText.sendKeys(first + last + "@1234567890");
		System.out.println("Password is " + first + last + "@1234567890");
		 userscrom=email;
		 passwordscrom=first + last + "@1234567890";
		firstName.click();
		firstName.sendKeys(first);
		lastName.click();
		lastName.sendKeys(last);
	}
	
	public void enterUserDetail()
	{
		if(passwordscrom==null)
		{
			passwordscrom=	Students.firstName+Students.lastName+"@1234567890";
			userscrom=Students.email;			
			
//			passwordscrom=	"AnshG@1234567890";
//			userscrom="Ansh.G112129@yopmail.com";
//			first + last + "@1234567890"
//			
//			firstName 
//			lastName 
		}

		wait.until(ExpectedConditions.visibilityOf(emailText));
		emailText.clear();
		emailText.click();
		emailText.sendKeys(userscrom);
		wait.until(ExpectedConditions.visibilityOf(pwdText));
		pwdText.click();
		pwdText.sendKeys(passwordscrom);
		wait.until(ExpectedConditions.visibilityOf(Submitbutton));
		
				Submitbutton.click();

	}
	public void switchWindowoline(String mail)
	{
		try
		{
			int m=0;
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==700)
					break;
				m++;
			}
			System.out.println(allWindowHandles.size());
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			for(int i = 0; i <= allWindowHandles.size()-1; i++)
			{
				try {
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
				String url = driver.getCurrentUrl();
				allWindowHandles = driver.getWindowHandles();
				System.out.println(url);
				if((url.contains("/dispatch")) && (!url.contains("/dispatch.html")))
					break;	
				}
				catch(Exception ex)
				{
					
				}
			}
			completeWholeCourseOnline();
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void clickSignIn()
	{
		wait.until(ExpectedConditions.visibilityOf(checkBox));
		checkBox.click();
		signUpButton.click();
		navigateToScromUrl();
		enterUserDetail();
		wait.until(ExpectedConditions.visibilityOf(addContentButton));
		try
		{
		closeIcon.click();
		}
		catch(Exception e)
		{
			
		}
	}
	
	public void uploadPackage(String filePath)
	{
		try {
			Thread.sleep(8000);
			JavascriptExecutor jse = (JavascriptExecutor)TestBase.driver;
			  jse.executeScript("window.scrollBy(0,250)");
			
			driver.findElement(By.xpath("//span/div/div/span[2]")).click();
			
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			
		}
		System.out.println(filePath);
		JavascriptExecutor jse = (JavascriptExecutor)TestBase.driver;
		jse.executeScript("arguments[0].scrollIntoView();", addContentButton);
		jse.executeScript("arguments[0].scrollIntoView();", addContentButton);
		
		wait.until(ExpectedConditions.visibilityOf(addContentButton));
		addContentButton.click();
		wait.until(ExpectedConditions.visibilityOf(importPackageLink));
		try
		{
			
		importPackageLink.click();
		}
		catch(Exception e)
		{
			driver.switchTo().alert().accept();
			importPackageLink.click();
				
		}
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		String pageValue = executor.executeScript("return document.readyState").toString();
		int m=0;
		while(!(pageValue.equalsIgnoreCase("complete")))
		{
			pageValue = executor.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			m++;
		}
		try 
		{
			driver.findElement(By.xpath("//input[@id='lib_importForm_fileToImport']")).sendKeys(filePath);
			String val = browseButton.getText();
			m=0;
			while(val.equalsIgnoreCase("Choose file"))
				{
					System.out.println(val);
					Thread.sleep(2000);
					val = browseButton.getText();
					if(m==pagload)
						break;
					m++;
				}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
			
	}
	public void clickonCourse() throws InterruptedException
	{
		Thread.sleep(15000);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"home_wrapper\"]//div/ul/li/a[text()='HeartCode® Complete BLS(BLS)']"))));
		driver.findElement(By.xpath("//*[@id=\"home_wrapper\"]//div/ul/li/a[text()='HeartCode® Complete BLS(BLS)']")).click();
//		addContentButton.click();
	
	}
	public void validateCourseLaunchError()
	{
		
			WebDriverWait wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseTable + "//td"))));
			String getMessage = driver.findElement(By.xpath(courseTable + "//td")).getText().trim();
			System.out.println(getMessage);
			Assert.assertTrue(getMessage.toLowerCase().contains("this course can only launch if other courses have been completed"));
		
	}
	public void switchWindowSelf(String mail, String first, String last)
    {
        try
        {
            Thread.sleep(10000);
            switchWindowCourseTopic();     
            if(driver.findElements(By.xpath(firstNameSelfRegister)).size() > 0)
            	selfregistertion(mail,first,last);
//            completeWholeCourse();
//            switchWindowDefault();
        }
        catch(Exception e)
        {
           
        }
    }
	public void switchWindowCourseTopic()
	{
		try 
		{
		Set<String> allWindowHandles = driver.getWindowHandles();
		System.out.println(allWindowHandles.size());
		int m=0;
		while(allWindowHandles.size()<3)
		{
			allWindowHandles = driver.getWindowHandles();
			if(m==pagload)
				break;
			m++;
		}
		System.out.println(allWindowHandles.size());
		System.out.println("Before focus " + allWindowHandles.toArray()[0]);
		for(int i = 0; i <= allWindowHandles.size()-1; i++)
		{
			driver.switchTo().window(allWindowHandles.toArray()[i].toString());
			try {
			String url = driver.getCurrentUrl();
			allWindowHandles = driver.getWindowHandles();
			if(url.contains("/dispatch") && (!url.contains("/dispatch.html")))
				break;	
			}
			catch(Exception ex)
			{
				
			}
		}
		System.out.println("After focus" + driver.getWindowHandle());
		}  
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	public void clickUploadPackage()
	{

		JavascriptExecutor executor = (JavascriptExecutor)driver;
		
		executor.executeScript("arguments[0].scrollIntoView();", importButton);
		executor.executeScript("arguments[0].click();", importButton);
	
		wait.until(ExpectedConditions.visibilityOf(courseLaunch));
		
	}

//	public void clamCmeDetails(String phne,String addres,String speciality,String designtion,String classification,String stte,String zipcde)
//	{
//		wait.until(ExpectedConditions.visibilityOf(CME_CE));
//
//		CME_CE.click();	
//		wait.until(ExpectedConditions.visibilityOf(address));
//
//		address.sendKeys(addres);
//		wait.until(ExpectedConditions.visibilityOf(phone));
//
//		phone.sendKeys(phne);
//		wait.until(ExpectedConditions.visibilityOf(specialitymaster_id));
//
//		specialitymaster_id.click();
//
//		Select drptime = new Select(specialitymaster_id);
//		drptime.selectByVisibleText(speciality);;
//
//		wait.until(ExpectedConditions.visibilityOf(designation));
//
//		designation.click();
//
//		drptime = new Select(designation);
//		drptime.selectByVisibleText(designtion);;
//		
//		wait.until(ExpectedConditions.visibilityOf(classification_code));
//
//		classification_code.click();
//
//		drptime = new Select(classification_code);
//		drptime.selectByVisibleText(classification);;
//		
//		wait.until(ExpectedConditions.visibilityOf(state));
//		state.click();
//		drptime = new Select(state);
//		drptime.selectByVisibleText(stte);;
//		wait.until(ExpectedConditions.visibilityOf(zipcode));
//
//		zipcode.sendKeys(zipcde);
//
//		wait.until(ExpectedConditions.visibilityOf(submitButton));
//		submitButton.click();
//		
//
//	}
//	
//	public void claimCredit()
//	{
//		wait.until(ExpectedConditions.visibilityOf(ClaimCME));
//
//		ClaimCME.click();
//
//		clamCmeDetails("12345567","Ajekar","Nurse","Physician","Nurse Practitioner","Alabama","12344" );
//		
//		wait.until(ExpectedConditions.visibilityOf(confirm));
//		confirm.click();
//		
//		wait.until(ExpectedConditions.visibilityOf(ClaimCME));
//
//		ClaimCME.click();
//		wait.until(ExpectedConditions.visibilityOf(download));
//		
//		download.click();
//		Students std=new Students();
//		boolean dwnld = false;
//		do 
//		{
//			dwnld =std.isFileDownloaded_Ext(std.downloadPath, ".pdf");
//		}
//		while(dwnld == false);
//		
//		Assert.assertTrue(dwnld);
//		
//		std.deleteFile(Students.filePath);
//		
//	}
	
	public void clickOnResetProgress()
	{
		wait.until(ExpectedConditions.visibilityOf(ResetProgress));
		ResetProgress.click();
		
		driver.switchTo().alert().accept();
	}
	public void clickOnLaunch()
	{
		try
		{
			Thread.sleep(5000);
		wait.until(ExpectedConditions.visibilityOf(courseLaunch));
		courseLaunch.click();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void switchWindowwithout(String email)
	{
		try
		{
			int m=0;
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==700)
					break;
				m++;
			}
			System.out.println(allWindowHandles.size());
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			for(int i = 0; i <= allWindowHandles.size()-1; i++)
			{
				try {
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
				String url = driver.getCurrentUrl();
				allWindowHandles = driver.getWindowHandles();
				System.out.println(url);
				if(url.contains("/dispatch") && (!url.contains("/dispatch.html")))
					break;	
				}
				catch(Exception ex)
				{
					
				}
			}
			
			completeWholeCoursewithoutdate();
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public void completeWholeCoursewithoutdate()
	{
			EndUser	end = new EndUser();
			
			
			
		
//			String date = end.changeDate(quarter);
//			end.runScriptForPastDate(date);
//			  
//		end.clickOnSubmitOnlyWithDate(date);
		int count = end.getAvailableTopiNumber();
		for(int i =1; i <= count; i++)
	    {
			
			startORResumeCourse();
//	    	completeCourse();
			completeCoursetestCode();
		    onlyExitCourse();		    
	    }
	}
	
	

	public void viewCertificateandvalidate(String course)
	{
		if(courseListName.containsKey(course+"Certificate"))
			course=courseListName.get(course+"Certificate").toString();
			
					
		Set<String> handles=driver.getWindowHandles();

		try
		{
			
			wait.until(ExpectedConditions.visibilityOf(Acknowledge));
			Acknowledge.click();
			wait.until(ExpectedConditions.visibilityOf(sendEmail));
			sendEmail.click();
			wait.until(ExpectedConditions.visibilityOf(close));
			close.click();
			
		}
		catch(Exception e)
		{
			
		}
		
		try {
			Thread.sleep(5000);

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		wait.until(ExpectedConditions.visibilityOf(Certificate));
		Certificate.click();
		Students std=new Students();
		
		
		boolean dwnld = false;
		int m=0;
		do 
		{
			dwnld =std.isFileDownloaded_Ext(std.downloadPath, ".pdf");
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			m++;
		}
		while(dwnld == false);
		
		Assert.assertTrue(dwnld);
		
		std.deleteFile(Students.filePath);
	
	}
	public void viewCertificatevalidate(String course)
	{
		if(courseListName.containsKey(course+"Certificate"))
			course=courseListName.get(course+"Certificate").toString();
			
					
		Set<String> handles=driver.getWindowHandles();

		
		
		
		
		
		try
		{
			try
			{
				
				wait.until(ExpectedConditions.visibilityOf(Acknowledge));
				Acknowledge.click();
				wait.until(ExpectedConditions.visibilityOf(sendEmail));
				sendEmail.click();
				wait.until(ExpectedConditions.visibilityOf(close));
				close.click();
				Thread.sleep(5000);
				
			}
			catch(Exception e)
			{
				
			}
			try
			{
				wait.until(ExpectedConditions.visibilityOf(Certificate));
				Certificate.click();
				wait.until(ExpectedConditions.visibilityOf(proceed));
				proceed.click();	
			}
			catch(Exception e)
			{
				
			}
			Thread.sleep(5000);
			
			Boolean flag=	Products.isFileDownloaded_Ext (Products.downloadPath , ".pdf");
			
			if(flag==false)
			{
			driver.switchTo().window(handles.toArray()[0].toString());
			
			String currentHandle= driver.getWindowHandle();
			handles=driver.getWindowHandles();


		
			driver.switchTo().window(handles.toArray()[1].toString());

			Assert.assertTrue(driver.getCurrentUrl().contains("/certificate/completion"));
			
			System.out.println(driver.getCurrentUrl());
			
			try
			{
				Thread.sleep(5000);
				driver.switchTo().frame("examReaderFrame");
				wait.until(ExpectedConditions.visibilityOf(Continue));
				Continue.click();
				Thread.sleep(5000);
				
				wait.until(ExpectedConditions.visibilityOf(Continue));
				Continue.click();
			}
			catch(Exception e)
			{
				
			}

			this.wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//table/tr//td[contains(text(),'"+course+"')]/following::td/img"))));
			
			driver.findElement(By.xpath("//table/tr//td[contains(text(),'"+course+"')]/following::td/img")).click();
			
            handles=driver.getWindowHandles();

			Assert.assertTrue(driver.getWindowHandles().size()==3);
            handles=driver.getWindowHandles();
			
			driver.switchTo().window(handles.toArray()[2].toString());
			driver.close();

			driver.switchTo().window(handles.toArray()[1].toString());
			driver.close();
			driver.switchTo().window(currentHandle);
			
				}
			else if(flag==true)
			{
				String currentHandle= driver.getWindowHandle();
				handles=driver.getWindowHandles();
				driver.close();
				
				driver.switchTo().window(handles.toArray()[0].toString());
			}
				


		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	
	}
	public void Acknowledge()
	{
		try
		{
			
				end.clickOnSubmitOnlyWithDate();
			
			
			wait.until(ExpectedConditions.visibilityOf(Acknowledge));
			Acknowledge.click();
			WebDriverWait wait = new WebDriverWait(driver, 25);
			
			wait.until(ExpectedConditions.visibilityOf(sendEmail));
			sendEmail.click();
			wait.until(ExpectedConditions.visibilityOf(close));
			
			close.click();
			
		}
		catch(Exception e)
		{
			
		}
	}
	
	public void AcknowledgeCME()
	{
		try
		{
			
			
			wait.until(ExpectedConditions.visibilityOf(Acknowledge));
			Acknowledge.click();
			WebDriverWait wait = new WebDriverWait(driver, 25);
			wait.until(ExpectedConditions.visibilityOf(endUserSubmitDate));
			
			wait.until(ExpectedConditions.visibilityOf(sendEmail));
			sendEmail.click();
			wait.until(ExpectedConditions.visibilityOf(close));
			
			close.click();
			
		}
		catch(Exception e)
		{
			
		}
	}
	
	public void viewEcardandvalidate(String course)
	{
		if(courseListName.containsKey(course+"Ecard"))
			course=courseListName.get(course+"Ecard").toString();
					
		Set<String> handles=driver.getWindowHandles();

		try
		{
			
			wait.until(ExpectedConditions.visibilityOf(Acknowledge));
			Acknowledge.click();
			wait.until(ExpectedConditions.visibilityOf(sendEmail));
			sendEmail.click();
			wait.until(ExpectedConditions.visibilityOf(close));
			
			close.click();
			
		}
		catch(Exception e)
		{
			
		}
		wait.until(ExpectedConditions.visibilityOf(viewEcard));
		
		
		viewEcard.click();
		wait.until(ExpectedConditions.visibilityOf(proceed));
		proceed.click();
		
		try
		{
			Thread.sleep(10000);
			driver.switchTo().window(handles.toArray()[0].toString());
			
			String currentHandle= driver.getWindowHandle();
			handles=driver.getWindowHandles();

			driver.switchTo().window(handles.toArray()[1].toString());

			Assert.assertTrue(driver.getCurrentUrl().contains("/certificate/ecard/"));

			System.out.println(driver.getCurrentUrl());
			
			try
			{
				Thread.sleep(5000);
				driver.switchTo().frame("examReaderFrame");
			}
			catch(Exception e)
			{
				
			}

			this.wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//table/tr//td[contains(text(),'"+course+"')]/following::td/img"))));
			
			driver.findElement(By.xpath("//table/tr//td[contains(text(),'"+course+"')]/following::td/img")).click();
			
            handles=driver.getWindowHandles();

			Assert.assertTrue(driver.getWindowHandles().size()==3);
            handles=driver.getWindowHandles();
			
			driver.switchTo().window(handles.toArray()[2].toString());
			driver.close();

			driver.switchTo().window(handles.toArray()[1].toString());
			driver.close();
			driver.switchTo().window(currentHandle);
			



		}
		catch(Exception e)
		{
		Assert.fail("Error viewing ecard"+	e.getMessage());
		}

		

	}
	public void clamCmeDetails(String phne,String addres,String speciality,String designtion,String classification,String stte,String zipcde)
	{
		wait.until(ExpectedConditions.visibilityOf(CME_CE1));

		CME_CE1.click();	
		wait.until(ExpectedConditions.visibilityOf(address));

		address.sendKeys(addres);
		wait.until(ExpectedConditions.visibilityOf(phone));

		phone.sendKeys(phne);
		
		try
		{
			wait.until(ExpectedConditions.visibilityOf(credits_claimed));
			credits_claimed.sendKeys("1");
			
		}
		catch(Exception e)
		{
			
		}
		wait.until(ExpectedConditions.visibilityOf(specialitymaster_id));

		specialitymaster_id.click();

		Select drptime = new Select(specialitymaster_id);
		drptime.selectByVisibleText(speciality);;

		wait.until(ExpectedConditions.visibilityOf(designation));

		designation.click();

		drptime = new Select(designation);
		drptime.selectByVisibleText(designtion);;
		
		wait.until(ExpectedConditions.visibilityOf(classification_code));

		classification_code.click();

		drptime = new Select(classification_code);
		drptime.selectByVisibleText(classification);;
		
		wait.until(ExpectedConditions.visibilityOf(state));
		state.click();
		drptime = new Select(state);
		drptime.selectByVisibleText(stte);;
		wait.until(ExpectedConditions.visibilityOf(zipcode));

		zipcode.sendKeys(zipcde);

		try
		{
		wait.until(ExpectedConditions.visibilityOf(submitButton1));
		submitButton1.click();
		}
		catch(Exception e)
		{
			wait.until(ExpectedConditions.visibilityOf(submitButton));
			submitButton.click();	
		}

	}

	public void evaluateCourse()
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(endUserEvaluation));
			endUserEvaluation.click();
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(mandatoryQuestion)));
			List<WebElement> mandate = driver.findElements(mandatoryQuestion);
			for(int i= 1; i<= mandate.size(); i++)
			{
				driver.findElement(By.xpath(firstRadioMandatryQuestion + i + "]//input[@type = 'radio'])[1]")).click();;
			}
			endUserSubmitEvaluation.click();
		}
		catch(Exception e)
		{
			//			driver.findElement(By.xpath("//button[@id=\"complete_course_topics_close\"]")).click();
			System.out.println(e.getMessage());
		}

	}
	public void validatemsgClaimCME(String msg)
	{
		try
		{
			
			wait.until(ExpectedConditions.visibilityOf(Acknowledge));
			Acknowledge.click();
			wait.until(ExpectedConditions.visibilityOf(sendEmail));
			sendEmail.click();
			wait.until(ExpectedConditions.visibilityOf(close));
			close.click();
			
		}
		catch(Exception e)
		{
			
		}
		wait.until(ExpectedConditions.visibilityOf(ClaimCME));

		ClaimCME.click();
		wait.until(ExpectedConditions.visibilityOf(message));
		Assert.assertTrue("Validate Message"+message.getText(),message.getText().contains(msg) );

		wait.until(ExpectedConditions.visibilityOf(close1));
		close1.click();

		
	}
	

	

	
	public void claimCreditProvider()
	{
		

		wait.until(ExpectedConditions.visibilityOf(ClaimCME));

		ClaimCME.click();

		clamCmeDetails("12345567","Ajekar","Nurse","Physician","Nurse Practitioner","Alabama","12344" );

		try
		{
//		wait.until(ExpectedConditions.visibilityOf(confirm));
//		confirm.click();
//		
		wait.until(ExpectedConditions.visibilityOf(ClaimCMEpart2));
		Select drptime = new Select(ClaimCMEpart2);
		drptime.selectByIndex(1);;
	
		try
		{
			wait.until(ExpectedConditions.visibilityOf(submitButton));
			submitButton.click();
		
		}
		catch(Exception e)
		{
			wait.until(ExpectedConditions.visibilityOf(submitButton1));
			submitButton1.click();
		}
	
		
		
		wait.until(ExpectedConditions.visibilityOf(confirm));
		confirm.click();

		}
		catch(Exception e)
		{
			
		}
		Students std=new Students();
		
		
		std.isFileDownloaded_Ext(std.downloadPath, ".pdf");
		
		wait.until(ExpectedConditions.visibilityOf(successmsg));
		
		Assert.assertTrue(successmsg.getText().contains("CME/CE credits updated successfully."));
		
		wait.until(ExpectedConditions.visibilityOf(ClaimCME));
		ClaimCME.click();
		
		wait.until(ExpectedConditions.visibilityOf(download));
		download.click();
		int m=0;
		boolean dwnld = false;
		do 
		{
			dwnld =std.isFileDownloaded_Ext(std.downloadPath, ".pdf");
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			m++;
		}
		while(dwnld == false);
		
		Assert.assertTrue(dwnld);
		
		std.deleteFile(Students.filePath);
	
		wait.until(ExpectedConditions.visibilityOf(cancel));
		cancel.click();
		
		Set<String> allWindowHandles = driver.getWindowHandles();
		driver.close();
		driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		
		
		
	}
	public void claimCredit()
	{
		wait.until(ExpectedConditions.visibilityOf(ClaimCME));

		ClaimCME.click();

		clamCmeDetails("12345567","Ajekar","Nurse","Physician","Nurse Practitioner","Alabama","12344" );

		try
		{
//		wait.until(ExpectedConditions.visibilityOf(confirm));
//		confirm.click();
//		
		wait.until(ExpectedConditions.visibilityOf(ClaimCMEpart2));
		Select drptime = new Select(ClaimCMEpart2);
		drptime.selectByIndex(1);;
	
		wait.until(ExpectedConditions.visibilityOf(submitButton));
		submitButton.click();
		
		wait.until(ExpectedConditions.visibilityOf(confirm));
		confirm.click();

		}
		catch(Exception e)
		{
			
		}
		Students std=new Students();
		
		
		std.isFileDownloaded_Ext(std.downloadPath, ".pdf");
		
		wait.until(ExpectedConditions.visibilityOf(successmsg));
		
		Assert.assertTrue(successmsg.getText().contains("CME/CE credits updated successfully."));
		
		wait.until(ExpectedConditions.visibilityOf(ClaimCME));
		ClaimCME.click();
		
		wait.until(ExpectedConditions.visibilityOf(download));
		download.click();
		boolean dwnld = false;
		int m=0;
		do 
		{
			dwnld =std.isFileDownloaded_Ext(std.downloadPath, ".pdf");
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			m++;
		}
		while(dwnld == false);
		
		Assert.assertTrue(dwnld);
		
		std.deleteFile(Students.filePath);
	
		wait.until(ExpectedConditions.visibilityOf(cancel));
		cancel.click();
		
		Set<String> allWindowHandles = driver.getWindowHandles();
		driver.close();
		driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		
		
		
	}
	public void clickOnCourseLaunch(String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//li/a[text()='"+course+"']"))));
		driver.findElement(By.xpath("//li/a[text()='"+course+"']")).click();
	}
	public void switchWindowquater(String email,int i)
	{
		try
		{
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			System.out.println(allWindowHandles.size());
			int m=0;
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==pagload)
					break;
				m++;
			}
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			driver.switchTo().window(allWindowHandles.toArray()[1].toString());
			System.out.println("After focus" + driver.getWindowHandle());
			completeWholeCoursequater(i);
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	//tbody/tr/td[4]/a
	public void switchWindow(String email)
	{
		try
		{
			Thread.sleep(10000);
//			Set<String> allWindowHandles = driver.getWindowHandles();
//			System.out.println(allWindowHandles.size());
//			int m=0;
//			while(allWindowHandles.size()<3)
//			{
//				allWindowHandles = driver.getWindowHandles();
//				if(m==pagload)
//					break;
//				m++;
//			}
//			
//			
//			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
//			driver.switchTo().window(allWindowHandles.toArray()[1].toString());
//			System.out.println("After focus" + driver.getWindowHandle());
//			
			Set<String> allWindowHandles = driver.getWindowHandles();
			int m=0;
			System.out.println(allWindowHandles.size());
			
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				System.out.println(allWindowHandles.size());
				
				if(m==pagload)
					break;
				m++;
			}
			for(int i=1;i<allWindowHandles.size();i++)
			{
				System.out.println("Before focus " + allWindowHandles.toArray());
				try
				{
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
					if(driver.getCurrentUrl().contains("scorm/dispatchlaunch"))
						break;
				}
				catch(Exception e)
				{
					
				}
			}
			
			System.out.println(driver.getCurrentUrl()+"After focus" + driver.getWindowHandle());
		
			
			completeWholeCourse();
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public void switchMessage(String mssg)
	{
		try
		{
			Thread.sleep(10000);
//			Set<String> allWindowHandles = driver.getWindowHandles();
//			System.out.println(allWindowHandles.size());
//			int m=0;
//			while(allWindowHandles.size()<3)
//			{
//				allWindowHandles = driver.getWindowHandles();
//				if(m==pagload)
//					break;
//				m++;
//			}
//			
//			
//			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
//			driver.switchTo().window(allWindowHandles.toArray()[1].toString());
//			System.out.println("After focus" + driver.getWindowHandle());
//			
			Set<String> allWindowHandles = driver.getWindowHandles();
			int m=0;
			System.out.println(allWindowHandles.size());
			
			while(allWindowHandles.size()<2)
			{
				allWindowHandles = driver.getWindowHandles();
				System.out.println(allWindowHandles.size());
				
				if(m==pagload)
					break;
				m++;
			}
			for(int i=1;i<allWindowHandles.size();i++)
			{
				System.out.println("Before focus " + allWindowHandles.toArray());
				try
				{
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
					if(driver.getCurrentUrl().contains("dispatch.html"))
						break;
				}
				catch(Exception e)
				{
					
				}
			}
			
			System.out.println(driver.getCurrentUrl()+"After focus" + driver.getWindowHandle());
		
			LocalDateTime myDateObj = LocalDateTime.now().plusDays(1);
		    DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("yyyy-MM-dd");

		    mssg=mssg.replace("<tomorrow>",myDateObj.format(myFormatObj).toString() );
		    System.out.println(msg.getText());
			Assert.assertTrue("Validate message"+msg.getText(), msg.getText().equals(mssg));	
			 ;
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	public void switchWindowithoutExiting(String email)
	{
		try
		{
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			int m=0;
			System.out.println(allWindowHandles.size());
			
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				System.out.println(allWindowHandles.size());
				
				if(m==pagload)
					break;
				m++;
			}
			for(int i=1;i<allWindowHandles.size();i++)
			{
				System.out.println("Before focus " + allWindowHandles.toArray());
				try
				{
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
					if(driver.getCurrentUrl().contains("scorm/dispatchlaunch"))
						break;
				}
				catch(Exception e)
				{
					
				}
			}
			
			System.out.println(driver.getCurrentUrl()+"After focus" + driver.getWindowHandle());
		
		
			completeWholeCourseexiting();
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
//			driver.close(); completeWholeCourseexitng
//			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void switchWindowdireclty()
	{
		try
		{
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			int m=0;
			System.out.println(allWindowHandles.size());
			
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				System.out.println(allWindowHandles.size());
				
				if(m==pagload)
					break;
				m++;
			}
			for(int i=1;i<allWindowHandles.size();i++)
			{
				System.out.println("Before focus " + allWindowHandles.toArray());
				try
				{
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
					if(driver.getCurrentUrl().contains("scorm/dispatchlaunch"))
						break;
				}
				catch(Exception e)
				{
					
				}
			}
			
			System.out.println(driver.getCurrentUrl()+"After focus" + driver.getWindowHandle());
		
		
			completeWholeCoursedirectly();
			
//			driver.close(); completeWholeCourseexitng
//			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void switchWindowithoutExitng(String email)
	{
		try
		{
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			System.out.println(allWindowHandles.size());
			int m=0;
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==pagload)
					break;
				m++;
			}
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			driver.switchTo().window(allWindowHandles.toArray()[1].toString());
			System.out.println("After focus" + driver.getWindowHandle());
			completeWholeCourseexitng();
//			driver.close(); completeWholeCourseexitng
//			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public void switchWindowithoutExiting(String email,String i)
	{
		try
		{
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			System.out.println(allWindowHandles.size());
			int m=0;
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==pagload)
					break;
				m++;
			}
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			driver.switchTo().window(allWindowHandles.toArray()[1].toString());
			System.out.println("After focus" + driver.getWindowHandle());
			completeWholeCourseexiting(i);
//			driver.close();
//			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	public void switchWindowResume(String email)
	{
		try
		{
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			int m=0;
			System.out.println(allWindowHandles.size());
			
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				System.out.println(allWindowHandles.size());
				
				if(m==pagload)
					break;
				m++;
			}
			for(int i=1;i<allWindowHandles.size();i++)
			{
				System.out.println("Before focus " + allWindowHandles.toArray());
				try
				{
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
					if(driver.getCurrentUrl().contains("scorm/dispatchlaunch"))
						break;
				}
				catch(Exception e)
				{
					
				}
			}
			
			System.out.println(driver.getCurrentUrl()+"After focus" + driver.getWindowHandle());
		
			resumWholeCoursequater();
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public void switchWindowMoodle(String email,String name,String lastname)
	{
		try
		{
			int m=0;
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			System.out.println(allWindowHandles.size());
			while(allWindowHandles.size()<2)
			{
				allWindowHandles = driver.getWindowHandles();
				
				System.out.println(driver.getPageSource());
				if(m>=10)
				{
				
					if(recoverySceanrios()&&m==10)
					{
						Thread.sleep(10000);
					}
					else
					Assert.fail("Moodle course launch failed");
				}
				
				m++;
			}
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			driver.switchTo().window(allWindowHandles.toArray()[1].toString());
			System.out.println("After focus" + driver.getWindowHandle());
			
			selfregistertion(email,name,lastname);
			completeWholeCourse();
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		System.out.println(driver.getCurrentUrl());
			driver.switchTo().defaultContent();
			exitActivity.click();
			
			try {
			driver.switchTo().alert().accept();
			}
			catch(Exception e)
			{
				
			}
					
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public boolean recoverySceanrios() throws InterruptedException
	{
		driver.navigate().refresh();
		
		try {
			
			driver.switchTo().alert().accept();
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		Thread.sleep(15000);
		Set<String> allWindowHandles = driver.getWindowHandles();
		System.out.println(allWindowHandles.size());
	
		if(allWindowHandles.size()==2)
		{
			return true;
		}
		else
		{
			dashbroad.click();
			
			try {
				Moodle.selectCourse();
				System.out.println("Recovery Sceanrio");
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return true;
		}
			
	
	}
	public void switchWindowMoodle(String email)
	{
		try
		{int m=0;
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			System.out.println(allWindowHandles.size());
			
			while(allWindowHandles.size()<2)
			{
				allWindowHandles = driver.getWindowHandles();
				
//				System.out.printlnntln(driver.getPageSource());
				if(m>=10)
				{
				
					boolean flag=recoverySceanrios();
					if(flag&&m==10)
					{
						Thread.sleep(10000);
						allWindowHandles = driver.getWindowHandles();
						
					}
					else
						Assert.fail("Moodle course launch failed");
				}
				
				m++;
			}
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			driver.switchTo().window(allWindowHandles.toArray()[1].toString());
			System.out.println("After focus" + driver.getWindowHandle());
			completeWholeCourse();
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		System.out.println(driver.getCurrentUrl());
			driver.switchTo().defaultContent();
			exitActivity.click();
			
			try {
			driver.switchTo().alert().accept();
			}
			catch(Exception e)
			{
				
			}
					
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void switchWindowMoodlequater(int q)
	{
		try
		{
			int m=0;
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			System.out.println(allWindowHandles.size());
			while(allWindowHandles.size()<2)
			{
				allWindowHandles = driver.getWindowHandles();
				
				System.out.println(driver.getPageSource());
				if(m>=10)
				{
				
					if(recoverySceanrios()&&m==10)
					{
						Thread.sleep(10000);
					}
					else
					Assert.fail("Moodle course launch failed");
				}
				
				m++;
			}
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			driver.switchTo().window(allWindowHandles.toArray()[1].toString());
			System.out.println("After focus" + driver.getWindowHandle());
			completeWholeCourse(q);
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		System.out.println(driver.getCurrentUrl());
			driver.switchTo().defaultContent();
			exitActivity.click();
			
			try {
			driver.switchTo().alert().accept();
			}
			catch(Exception e)
			{
				
			}
					
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void switchWindowMoodlequater(String email,String name,String lastname,int q)
	{
		try
		{
			int m=0;
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			System.out.println(allWindowHandles.size());
			while(allWindowHandles.size()<2)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==10)
				{
					Assert.fail("Moodle course launch failed");
				}
				m++;
			}
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			driver.switchTo().window(allWindowHandles.toArray()[1].toString());
			System.out.println("After focus" + driver.getWindowHandle());
			
			selfregistertion(email,name,lastname);
			completeWholeCourse(q);
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		System.out.println(driver.getCurrentUrl());
			driver.switchTo().defaultContent();
			exitActivity.click();
			
			try {
			driver.switchTo().alert().accept();
			}
			catch(Exception e)
			{
				
			}
					
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void selfregistertion(String email,String first,String lastname)
	{
		try
		{
		
			System.out.println(	driver.getCurrentUrl());
			User.userId=email;
		wait.until(ExpectedConditions.visibilityOf(firstNameself));
		firstNameself.clear();
		firstNameself.sendKeys(first);
		wait.until(ExpectedConditions.visibilityOf(lastNameself));
		lastNameself.clear();
		lastNameself.sendKeys(lastname);
		
//		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(emailText));
//		emailText.sendKeys(email);
//		emailText.sendKeys(Keys.TAB);
		 JavascriptExecutor jse = (JavascriptExecutor)driver;
		 emailText.clear();
		 emailText.click();
		 for(int i=0;i<email.length();i++)
		 {
			  
			 emailText.sendKeys(String.valueOf(email.charAt(i))); 
		 }
		 emailText.clear();
			
		 emailText.sendKeys(email);
		 
	
		wait.until(ExpectedConditions.visibilityOf(save));
		jse.executeScript("arguments[0].click();", save);
		try
		{
			Thread.sleep(5000);
			jse.executeScript("arguments[0].click();", save);		
		save.click();
		}
		catch(Exception e)
		{
		}
		}
		catch(Exception e)
		{	
			WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(registerbtn));
		
		
		emailTt.clear();
		emailTt.click();
		 for(int i=0;i<email.length();i++)
		 {
			  
			 emailTt.sendKeys(String.valueOf(email.charAt(i))); 
		 }
		 emailTt.clear();
			
		 emailTt.sendKeys(email);
		 
		 registerbtn.click();
		}
		
	}
	
	public void selfregistertionoptional(String email,String first,String lastname)
	{
		try
		{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(firstNameself));
		firstNameself.clear();
		firstNameself.sendKeys(first);
		wait.until(ExpectedConditions.visibilityOf(lastNameself));
		lastNameself.clear();
		lastNameself.sendKeys(lastname);
		
//		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(emailText));
//		emailText.sendKeys(email);
//		emailText.sendKeys(Keys.TAB);
		 JavascriptExecutor jse = (JavascriptExecutor)driver;
	
		wait.until(ExpectedConditions.visibilityOf(save));
		jse.executeScript("arguments[0].click();", save);
		try
		{
			Thread.sleep(5000);
			jse.executeScript("arguments[0].click();", save);		
		save.click();
		}
		catch(Exception e)
		{
		}
		}
		catch(Exception e)
		{	
			WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(registerbtn));
		
		
		
		 registerbtn.click();
		}
		
	}


	public void switchWindow(String email,int q)
	{
		try
		{
			int m=0;
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==700)
					break;
				m++;
			}
			System.out.println(allWindowHandles.size());
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			for(int i = 0; i <= allWindowHandles.size()-1; i++)
			{
				try {
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
				String url = driver.getCurrentUrl();
				allWindowHandles = driver.getWindowHandles();
				System.out.println(url);
				if(url.contains("/dispatch") && (!url.contains("/dispatch.html")))
					break;	
				}
				catch(Exception ex)
				{
					
				}
			}
			
			completeWholeCourse(q);
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void validateMsg(String msg,int quarter)
	{
		try
		{
			int m=0;
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==700)
					break;
				m++;
			}
			System.out.println(allWindowHandles.size());
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			for(int i = 0; i <= allWindowHandles.size()-1; i++)
			{
				try {
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
				String url = driver.getCurrentUrl();
				allWindowHandles = driver.getWindowHandles();
				System.out.println(url);
				if(url.contains("/dispatch") && (!url.contains("/dispatch.html")))
					break;	
				}
				catch(Exception ex)
				{
					
				}
			}
			String date = end.changeDate(quarter);
			end.clickOnSubmitOnlyWithDate(date);
			
			validatemessage(msg);
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void checkiftopicnotlocked(String email,int q)
	{
		try
		{
			int m=0;
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==700)
					break;
				m++;
			}
			System.out.println(allWindowHandles.size());
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			for(int i = 0; i <= allWindowHandles.size()-1; i++)
			{
				try {
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
				String url = driver.getCurrentUrl();
				allWindowHandles = driver.getWindowHandles();
				System.out.println(url);
				if(url.contains("/dispatch") && (!url.contains("/dispatch.html")))
					break;	
				}
				catch(Exception ex)
				{
					
				}
			}
			
			checkiftopicnotlocked(q);
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public void switchWindowandvalidatelog(String Log)
	{
		try
		{
			int m=0;
			Thread.sleep(10000);
			 LogEntries entry = driver.manage().logs().get(LogType.BROWSER);
			   
			Set<String> allWindowHandles = driver.getWindowHandles();
			System.out.println(allWindowHandles.size());
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==10)
					Assert.fail("Window not handled");
				
				m++;
				
			}
			for(int i = 0; i <= allWindowHandles.size()-1; i++)
			{
				try {
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
				String url = driver.getCurrentUrl();
				allWindowHandles = driver.getWindowHandles();
				System.out.println(url);
				if(url.contains("dispatch.html"))
					entry = driver.manage().logs().get(LogType.BROWSER);
					break;	
				}
				catch(Exception ex)
				{
					
				}
			}
			System.out.println(Log);
			System.out.println(driver.getCurrentUrl());
			     // Retrieving all log 
		        List<LogEntry> logs= entry.getAll();

		        // Print one by one
		        for(LogEntry e: logs)
		        {
		        	System.out.println(e);
		        }
		        
		        // Printing details separately 
		        for(LogEntry e: logs)
		        {
		        	System.out.println("Message is: " +e.getMessage());
		        	System.out.println("Level is: " +e.getLevel());
		        	System.out.println("Level is: " +e.getLevel());
		        }
		       
		        entry = driver.manage().logs().get(LogType.CLIENT);
		        logs= entry.getAll();
		        // Print one by one
		        for(LogEntry e: logs)
		        {
		        	System.out.println(e);
		        }
		        
		        // Printing details separately 
		        for(LogEntry e: logs)
		        {
		        	System.out.println("Message is: " +e.getMessage());
		        	System.out.println("Level is: " +e.getLevel());
		        }
		        
		        entry = driver.manage().logs().get(LogType.DRIVER);
		        logs= entry.getAll();
		        // Print one by one
		        for(LogEntry e: logs)
		        {
		        	System.out.println(e);
		        }
		        
		        // Printing details separately 
		        for(LogEntry e: logs)
		        {
		        	System.out.println("Message is: " +e.getMessage());
		        	System.out.println("Level is: " +e.getLevel());
		        }
		        
		        entry = driver.manage().logs().get(LogType.PERFORMANCE);
		        
		        logs= entry.getAll();
		        // Print one by one
		        for(LogEntry e: logs)
		        {
		        	System.out.println(e);
		        }
		        
		        // Printing details separately 
		        for(LogEntry e: logs)
		        {
		        	System.out.println("Message is: " +e.getMessage());
		        	System.out.println("Level is: " +e.getLevel());
		        }
		        entry = driver.manage().logs().get(LogType.PROFILER);
		        logs= entry.getAll();
		        // Print one by one
		        for(LogEntry e: logs)
		        {
		        	System.out.println(e);
		        }
		        
		        // Printing details separately 
		        for(LogEntry e: logs)
		        {
		        	System.out.println("Message is: " +e.getMessage());
		        	System.out.println("Level is: " +e.getLevel());
		        }
			
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[2].toString());
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void switchWindow(String email,String i)
	{
		try
		{
			int m=0;
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			System.out.println(allWindowHandles.size());
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==10)
					Assert.fail("Window not handled");
				
				m++;
				
			}
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			driver.switchTo().window(allWindowHandles.toArray()[1].toString());
			System.out.println("After focus" + driver.getWindowHandle());
			completeWholeCourse(i);
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[2].toString());
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	public void switchWindw(String email,int q)
	{
		try
		{
			int m=0;
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==100)
					break;
				m++;
			}
			System.out.println(allWindowHandles.size());
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			for(int i = 0; i <= allWindowHandles.size()-1; i++)
			{
				try {
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
				String url = driver.getCurrentUrl();
				allWindowHandles = driver.getWindowHandles();
				System.out.println(url);
				if(url.contains("/dispatch") && (!url.contains("/dispatch.html")))
					break;	
				}
				catch(Exception ex)
				{
					
				}
			}
			
			completeWholeCouse(q);
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void switchWindw(String email,String i)
	{
		try
		{
			int m=0;
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			System.out.println(allWindowHandles.size());
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==30)
					Assert.fail("Window not handled");
				
				m++;
			}
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			driver.switchTo().window(allWindowHandles.toArray()[1].toString());
			System.out.println("After focus" + driver.getWindowHandle());
			completeWholeCouse(i);
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[2].toString());
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void switchWindowquit(String email,int i,String option)
	{
		try
		{
			int m=0;
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			System.out.println(allWindowHandles.size());
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				
				if(m==108)
					Assert.fail("Window not handled");
				
				m++;
			}
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			driver.switchTo().window(allWindowHandles.toArray()[1].toString());
			System.out.println("After focus" + driver.getWindowHandle());
			completeWholeCourse(i,option);
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void switchWindowSelf(String mail)
	{
		try
		{
			int m=0;
		
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==700)
					break;
				m++;
			}
			System.out.println(allWindowHandles.size());
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			for(int i = 0; i <= allWindowHandles.size()-1; i++)
			{
				try {
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
				String url = driver.getCurrentUrl();
				allWindowHandles = driver.getWindowHandles();
				System.out.println(url);
				if(url.contains("/dispatch") && (!url.contains("/dispatch.html")))
					break;	
				}
				catch(Exception ex)
				{
					
				}
			}
			
			
			selfregistertion(Students.email,Students.firstName,Students.lastName);
			completeWholeCourse();
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void switchWindowSelfwithoptional(String mail)
	{
		try
		{
			int m=0;
		
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==700)
					break;
				m++;
			}
			System.out.println(allWindowHandles.size());
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			for(int i = 0; i <= allWindowHandles.size()-1; i++)
			{
				try {
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
				String url = driver.getCurrentUrl();
				allWindowHandles = driver.getWindowHandles();
				System.out.println(url);
				if(url.contains("/dispatch") && (!url.contains("/dispatch.html")))
					break;	
				}
				catch(Exception ex)
				{
					
				}
			}
			
			
			selfregistertionoptional(Students.email,Students.firstName,Students.lastName);
			completeWholeCourse();
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void switchWindowonline(String mail)
	{
		try
		{
			int m=0;
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			System.out.println(allWindowHandles.size());
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==100)
					Assert.fail("Window not handled");
				
				m++;
			}
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			for(int i = 0; i <= allWindowHandles.size()-1; i++)
			{
				try {
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
				String url = driver.getCurrentUrl();
				allWindowHandles = driver.getWindowHandles();
				System.out.println(url);
				if(url.contains("/dispatch") && (!url.contains("/dispatch.html")))
					break;	
				}
				catch(Exception ex)
				{
					
				}
			}
			DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
			Calendar cal = Calendar.getInstance();
			String email = dateFormat.format(cal.getTime());
			String formattedEmail = email.replace(":", "");
			selfregistertion(Students.email,Students.firstName,Students.lastName);
			completeWholeCourseOnline();
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void ValidateErrorMSg(String msg)
	{
		try
		{
			int m=0;
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			System.out.println(allWindowHandles.size());
			while(allWindowHandles.size()<2)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==100)
					Assert.fail("Window not handled");
				
				m++;
			}
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			driver.switchTo().window(allWindowHandles.toArray()[1].toString());
			Assert.assertEquals(driver.findElement(By.id("defaultmsg")).getText(),msg);  
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void switchWindowSelf(String email,int date)
	{
		try
		{
			int m=0;
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==700)
					break;
				m++;
			}
			System.out.println(allWindowHandles.size());
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			for(int i = 0; i <= allWindowHandles.size()-1; i++)
			{
				try {
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
				String url = driver.getCurrentUrl();
				allWindowHandles = driver.getWindowHandles();
				System.out.println(url);
				if(url.contains("/dispatch") && (!url.contains("/dispatch.html")))
					break;	
				}
				catch(Exception ex)
				{
					
				}
			}
		
			
			selfregistertion(Students.email,Students.firstName,Students.lastName);
			completeWholeCouse(date);
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void switchWindows(String email)
	{
		try
		{
			int m=0;
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			System.out.println(allWindowHandles.size());
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==10)
					Assert.fail("Window not handled");
				
				m++;
			}
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			driver.switchTo().window(allWindowHandles.toArray()[1].toString());
			System.out.println("After focus" + driver.getWindowHandle());
			completeWholeCourseexit();
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	public void exitCourse(int number)
	{
//		try
//		{
//			Robot robot = new Robot();
//			for(int i = 1; i<=number; i++)
//			{
//				robot.keyPress(Keys.TAB);
//				robot.keyRelease(KeyEvent.VK_TAB);
//				Thread.sleep(2000);
//			}
//			robot.keyPress(KeyEvent.VK_ENTER);
//			robot.keyRelease(KeyEvent.VK_ENTER);
//		}
//		catch(Exception e)
//		{
//			
//		}
//		
	}

	public void logout()
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(logOut));
			logOut.click();
			driver.close();
		}
		catch (Exception f) 
		{
			try 
			{
				Alert alert = driver.switchTo().alert();
				alert.accept();
			}
			catch (Exception e) 
			{
				System.out.println("No alert Found");
				
			}
		}
	}

	public void enterEmail(String email)
	{
		try {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(userEmail));
			userEmail.click();
			userEmail.sendKeys(email);
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOf(userMiddleName));
			userMiddleName.click();
			saveEmail.click();
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	public void submitandExit()
	{
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOf(submitDate));
		submitDate.click();
		wait.until(ExpectedConditions.visibilityOf(startCourse));
		startCourse.click();
		wait.until(ExpectedConditions.visibilityOf(frameOne));
		driver.switchTo().frame("basicltiLaunchFrame");
		wait.until(ExpectedConditions.visibilityOf(frameTwo));
		driver.switchTo().frame("frame");
		wait.until(ExpectedConditions.visibilityOf(complete));
		complete.click();
		driver.switchTo().defaultContent();
		wait.until(ExpectedConditions.visibilityOf(exitCourse));
		exitCourse.click();
		wait.until(ExpectedConditions.visibilityOf(startCourse));
		startCourse.click();
		wait.until(ExpectedConditions.visibilityOf(frameOne));
		driver.switchTo().frame("basicltiLaunchFrame");
		wait.until(ExpectedConditions.visibilityOf(frameTwo));
		driver.switchTo().frame("frame");
		wait.until(ExpectedConditions.visibilityOf(complete));
		complete.click();
		driver.switchTo().defaultContent();
		wait.until(ExpectedConditions.visibilityOf(exitCourse));
		exitCourse.click();
		wait.until(ExpectedConditions.visibilityOf(startCourse));
		startCourse.click();
		wait.until(ExpectedConditions.visibilityOf(frameOne));
		driver.switchTo().frame("basicltiLaunchFrame");
		wait.until(ExpectedConditions.visibilityOf(frameTwo));
		driver.switchTo().frame("frame");
		wait.until(ExpectedConditions.visibilityOf(complete));
		complete.click();
		driver.switchTo().defaultContent();
		wait.until(ExpectedConditions.visibilityOf(exitCourse));
		exitCourse.click();
	}
	public void clickOnCompletedCourseReview()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(completedCourseReview));
		completedCourseReview.click();
	}
	public void deletePackage(String path)
	{
		System.out.println("delete file path is " + path);
		File file = new File(path);
		file.delete();		
	}

	public void logout_without_quit()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		WebDriverWait wait = new WebDriverWait(driver, 30);
		try 
		{
			String val = js.executeScript("return document.readyState").toString();
			int m=0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(logOut));
			wait.until(ExpectedConditions.elementToBeClickable(logOut));
			logOut.click();
			wait.until(ExpectedConditions.elementToBeClickable(signUpLink));
		} 
		catch (Exception f) 
		{
			try 
			{
				Alert alert = driver.switchTo().alert();
				alert.accept();
				 alert = driver.switchTo().alert();
				alert.accept();
			}
			catch (Exception e) 
			{
				System.out.println("No alert Found");
				
			}
		}
	}
 int count=0;
 public int getNumberRowsscr()
	{
		int count = 0;
		WebDriverWait wait = new WebDriverWait(driver, 10);
		try 
		{		
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseTable))));
			List<WebElement> rows = driver.findElements(By.xpath(courseTable + "//tbody/tr/td[4]//a"));
			List<WebElement> courseRows = driver.findElements(By.xpath("(" + courseTable + ")[1]//tbody/tr/td[1]"));
			count = rows.size();
			courseTopic = new String[courseRows.size()];
			for(int i = 1; i <= courseRows.size(); i++)
			{
				String text = driver.findElement(By.xpath(courseTable + "//tbody/tr[" + i + "]/td[1]")).getText();
				System.out.println(text);
				courseTopic[i-1] = text;
			}
		}
		catch(Exception e)
		{
			try 
			{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(scromCourseTable))));
			List<WebElement> rows = driver.findElements(By.xpath(scromCourseTable + "//tbody/tr/td[4]//a"));
			List<WebElement> courseRows = driver.findElements(By.xpath("(" + scromCourseTable + ")[1]//tbody/tr/td[1]"));
			count = rows.size();
			courseTopic = new String[courseRows.size()];
			for(int i = 1; i <= courseRows.size(); i++)
			{
				String text = driver.findElement(By.xpath(scromCourseTable + "//tbody/tr[" + i + "]/td[1]")).getText();
				System.out.println(text);
				courseTopic[i-1] = text;
			}
			}
			catch(Exception ex)
			{
				
			}
		}
		return count;
	}

	public void navigateToRQIPUrl()
	{
		try {
			Thread.sleep(5000);
		System.out.println(prop.getProperty("url"+prop.getProperty("environment")));
		driver.get(prop.getProperty("url"+prop.getProperty("environment")));
		
		if(!driver.getCurrentUrl().contains(prop.getProperty("url"+prop.getProperty("environment"))))
		{
			System.out.println("Retry...!!");
			driver.navigate().to(prop.getProperty("url"+prop.getProperty("environment")));
					
		}
		
		}
		catch (Exception f) 
		{
			try
			{
			Alert alert = driver.switchTo().alert();
			alert.accept();
			}
			catch(Exception e)
			{
				count++;
				if(count<3)
           			navigateToRQIPUrl();
			}
		}
	}

	public int getNumberRows()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseTable))));
		List<WebElement> count = driver.findElements(By.xpath(courseTable + "//tbody/tr"));
		return count.size();
	}
	
	public void clickOnSubmit()
	{
		try
		{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(endUserSubmitDate));
		endUserSubmitDate.click();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
	}
	
	
	public void startORResumeCourseOnline()
	{
		WebDriverWait wait = new WebDriverWait(driver, 20);
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(StartCourse));
			StartCourse.click();
		} 
		catch (Exception e) 
		{
			try
			{
				wait.until(ExpectedConditions.visibilityOf(endUserResumeCourse));
				endUserResumeCourse.click();
			}
			catch(Exception m)
			{
				try
				{
			
				wait.until(ExpectedConditions.visibilityOf(startCoure));
				startCoure.click();
				}
				catch(Exception k)
				{
					Set<String> allWindowHandles = driver.getWindowHandles();
					System.out.println(allWindowHandles.size());
					
						allWindowHandles = driver.getWindowHandles();
					
						driver.switchTo().window(allWindowHandles.toArray()[allWindowHandles.size()-1].toString());	
						driver.close();
					driver.switchTo().window(allWindowHandles.toArray()[0].toString());	
					
					
					
				}
			}
		}
		
	}
	public void startORResumeCourse()
	{
		WebDriverWait wait = new WebDriverWait(driver, 20);
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(endUserStartCourse));
			endUserStartCourse.click();
		} 
		catch (Exception e) 
		{
			try
			{
				wait.until(ExpectedConditions.visibilityOf(endUserResumeCourse));
				endUserResumeCourse.click();
			}
			catch(Exception m)
			{
				try
				{
			
				wait.until(ExpectedConditions.visibilityOf(startCoure));
				startCoure.click();
				}
				catch(Exception k)
				{
					Set<String> allWindowHandles = driver.getWindowHandles();
					System.out.println(allWindowHandles.size());
					
						allWindowHandles = driver.getWindowHandles();
					
						driver.switchTo().window(allWindowHandles.toArray()[allWindowHandles.size()-1].toString());	
						driver.close();
					driver.switchTo().window(allWindowHandles.toArray()[0].toString());	
					
					
					
				}
			}
		}
		
	}
	
	public void startORResumeCourses()
	{
		WebDriverWait wait = new WebDriverWait(driver, 20);
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(endUserStartCourse));
			endUserStartCourse.click();
		} 
		catch (Exception e) 
		{
			try
			{
				wait.until(ExpectedConditions.visibilityOf(endUserResumeCourse));
				endUserResumeCourse.click();
			}
			catch(Exception m)
			{
				try
				{
			
				wait.until(ExpectedConditions.visibilityOf(startCoure));
				startCoure.click();
				}
				catch(Exception k)
				{
					Set<String> allWindowHandles = driver.getWindowHandles();
					System.out.println(allWindowHandles.size());
					
						allWindowHandles = driver.getWindowHandles();
					
						driver.switchTo().window(allWindowHandles.toArray()[allWindowHandles.size()-1].toString());	
						driver.close();
					driver.switchTo().window(allWindowHandles.toArray()[0].toString());	
					
					
					
				}
			}
		}
		
	}
	
	public void completeCourseonline()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		try 
		{
			
			wait.until(ExpectedConditions.visibilityOf(frameOne));
			Assert.assertTrue(driver.getCurrentUrl().contains("https"));
		
		} 
		catch (Exception e) 
		{
			try
			{
				wait.until(ExpectedConditions.visibilityOf(frameOnline));
				Assert.assertTrue(driver.getCurrentUrl().contains("https"));
				
			}
			catch (Exception m) 
			{
	    	 Assert.fail("Error in course");
			}
		}
	}
	public void completeCourse()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(frameOne));
			Assert.assertTrue(driver.getCurrentUrl().contains("https"));
			
			driver.switchTo().frame("basicltiLaunchFrame");
			wait.until(ExpectedConditions.visibilityOf(frameTwo));
			driver.switchTo().frame("frame");
			wait.until(ExpectedConditions.visibilityOf(complete));
			complete.click();
			wait.until(ExpectedConditions.visibilityOf(announcement));
			driver.switchTo().defaultContent();
		} 
		catch (Exception e) 
		{
			driver.switchTo().defaultContent();
			WebDriverWait wait = new WebDriverWait(driver, 30);
			try
			{
				
				wait.until(ExpectedConditions.visibilityOf(fraeOne));
				driver.switchTo().frame("launchFrame");
				
				if(driver.findElement(By.xpath("//*[@id='defaultmsg']")).getText().contains("NRP organization not found for given lmsOrgId (Error Code: 400)"))
					System.out.println("NRP organization not found for given lmsOrgId (Error Code: 400)");
				
			}
			catch(Exception m)
			{
			
			wait.until(ExpectedConditions.visibilityOf(frameOne));
			driver.switchTo().frame("basicltiLaunchFrame");
			js.executeScript("setInterval(function() {frames[\"HYPER_19720220\"].skipSco();}, 300);//");
			try 
			{
				wait.until(ExpectedConditions.visibilityOf(frameTwo));
				driver.switchTo().frame("frame");
				wait.until(ExpectedConditions.visibilityOf(announcement));
			}
			catch(Exception ex)
			{
				
				
				driver.switchTo().defaultContent();
				wait.until(ExpectedConditions.visibilityOf(frameOne));
				driver.switchTo().frame("basicltiLaunchFrame");
				driver.navigate().refresh();
				try {
					Thread.sleep(40000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				String value = null;
				try {
					driver.navigate().refresh();
					Thread.sleep(20000);
					 value = driver.findElement(rhapsodeCourse).getAttribute("value");
					
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					try
					{
						driver.navigate().refresh();
					Thread.sleep(20000);
					
					}
					catch(Exception e23)
					{
						
					}
					try
					{
					 value = driver.findElement(By.xpath("//*[@id=\"lis_result_sourcedid\"]")).getAttribute("value");
					
					}
					catch(Exception kk)
					{
						 System.out.println(driver.getPageSource().split("name=\"lis_result_sourcedid\" value=\"")[0].split(">")[0].replace("\"", ""));
						 
						value=driver.getPageSource().split("name=\"lis_result_sourcedid\" value=\"")[1].split(">")[0].replace("\"", "");
						 System.out.println(value);
						 
					}
				}
				
				System.out.println(value);
				rest = new RestApi();
				rest.getResponse(value);
			}
			driver.switchTo().defaultContent();
			}
		}
	}
	
	public void completeCoursetestCode()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(frameOne));
            WebDriverWait wait = new WebDriverWait(driver, 30);
			String value=driver.getCurrentUrl().split("sourceId=")[1].split("&")[0];
			System.out.println(value);
			rest = new RestApi();
			rest.getResponse(value);
			
			driver.switchTo().defaultContent();
		} 
		catch (Exception e) 
		{
			
		}
	}
	
	public void completeCourseexit()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(frameOne));
			driver.switchTo().frame("basicltiLaunchFrame");
			wait.until(ExpectedConditions.visibilityOf(frameTwo));
			driver.switchTo().frame("frame");
			wait.until(ExpectedConditions.visibilityOf(complete));
			complete.click();
			wait.until(ExpectedConditions.visibilityOf(announcement));
			driver.switchTo().defaultContent();
		} 
		catch (Exception e) 
		{
			driver.switchTo().defaultContent();
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(frameOne));
			driver.switchTo().frame("basicltiLaunchFrame");
			js.executeScript("setInterval(function() {frames[\"HYPER_19720220\"].skipSco();}, 300);//");
			try 
			{
				wait.until(ExpectedConditions.visibilityOf(frameTwo));
				driver.switchTo().frame("frame");
				wait.until(ExpectedConditions.visibilityOf(announcement));
			}
			catch(Exception ex)
			{
				
				
				driver.switchTo().defaultContent();
				wait.until(ExpectedConditions.visibilityOf(frameOne));
				driver.switchTo().frame("basicltiLaunchFrame");
				driver.navigate().refresh();
				try {
					Thread.sleep(40000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				String value = null;
				try {
					driver.navigate().refresh();
					Thread.sleep(20000);
					 value = driver.findElement(rhapsodeCourse).getAttribute("value");
					
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					try
					{
						driver.navigate().refresh();
					Thread.sleep(20000);
					
					}
					catch(Exception e23)
					{
						
					}
					try
					{
					 value = driver.findElement(By.xpath("//*[@id=\"lis_result_sourcedid\"]")).getAttribute("value");
					
					}
					catch(Exception kk)
					{
						 System.out.println(driver.getPageSource().split("name=\"lis_result_sourcedid\" value=\"")[0].split(">")[0].replace("\"", ""));
						 
						value=driver.getPageSource().split("name=\"lis_result_sourcedid\" value=\"")[1].split(">")[0].replace("\"", "");
						 System.out.println(value);
						 
					}
				}
			}
			driver.switchTo().defaultContent();
		}
	}
 
	public void switchWindowDefault()
	{
		try 
		{
		Set<String> allWindowHandles = driver.getWindowHandles();
		int m=0;
		System.out.println(allWindowHandles.size());
		while(allWindowHandles.size()<3)
		{
			allWindowHandles = driver.getWindowHandles();
			if(m==pagload)
				break;
			m++;
		}
		System.out.println("Before focus " + allWindowHandles.toArray()[2]);
		driver.close();
		driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		System.out.println("After focus" + driver.getWindowHandle());
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	public void closeexistingWindow()
	{
		try 
		{
		Set<String> allWindowHandles = driver.getWindowHandles();
		System.out.println(allWindowHandles.size());
		while(allWindowHandles.size()!=1)
		{
			
			
//			driver.close();
			
			for(int i=1;i<=allWindowHandles.toArray().length;i++)
			{
			try {
				driver.switchTo().window(allWindowHandles.toArray()[i].toString());
			String url = driver.getCurrentUrl();
			allWindowHandles = driver.getWindowHandles();
			System.out.println(url);
			if(url.contains("/dispatch") && (!url.contains("/dispatch.html")))
				break;	
			}
			catch(Exception ex)
			{
				
			}
			}
			driver.close();
			allWindowHandles = driver.getWindowHandles();
		}
		
		
		driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		System.out.println("After focus" + driver.getWindowHandle());
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	public void onlyExitCourse()
	{
		try
		{
		wait.until(ExpectedConditions.visibilityOf(endUserExitCourse));
		endUserExitCourse.click();
		}
		catch(Exception e)
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(ExitCourse));
			ExitCourse.click();
		}
	}
	
	public void completeWholeCourse(int quarter)
	{
			EndUser	end = new EndUser();
			
			
			
		
			String date = end.changeDate(quarter);
			end.runScriptForPastDate(date);
			  
		end.clickOnSubmitOnlyWithDate(date);
		int count = end.getAvailableTopiNumber();
		for(int i =1; i <= count; i++)
	    {
			
			startORResumeCourse();
//	    	completeCourse();
			completeCoursetestCode();
		    onlyExitCourse();		    
	    }
	}
	
	
	public void checkiftopicnotlocked(int quarter)
	{
			EndUser	end = new EndUser();
			
			
			
			
			String date = end.changeDate(quarter);
			end.runScriptForPastDate(date);
			  
		end.clickOnSubmitOnlyWithDate(date);
		int count = getRows();
		Assert.assertEquals(0, count);
		
	}
	
	public void completeWholeCouse(int quarter)
	{
			EndUser	end = new EndUser();
			String date = end.changeDate(quarter);
			end.runScriptForPastDate(date);
			  
		end.clickOnSubmitOnlyWithDate(date);
		int count = getNumberRows();
		for(int i =1; i <= count; i++)
	    {
			startORResumeCourse();
//	    	completeCourse();
			completeCoursetestCode();
		    onlyExitCourse();		    
	    }
	}
	public void completeWholeCouse(String quarter)
	{
			EndUser	end = new EndUser();
			String date;
			if(courseListName.containsKey(quarter))
				date=courseListName.get(quarter).toString();
			else
			  date = end.changeDate(Integer.parseInt(quarter));
			
			end.runScriptForPastDate(date);
			  
		end.clickOnSubmitOnlyWithDate(date);
		int count = getNumberRows();
		for(int i =1; i <= count; i++)
	    {
			startORResumeCourse();
//	    	completeCourse();
			completeCoursetestCode();
		    onlyExitCourse();		    
	    }
	}
	
	public void completeWholeCourse(String quarter)
	{
			EndUser	end = new EndUser();
			String date;
			if(courseListName.containsKey(quarter))
				date=courseListName.get(quarter).toString();
			else
			  date = end.changeDate(Integer.parseInt(quarter));
			
			end.runScriptForPastDate(date);
			  
		end.clickOnSubmitOnlyWithDate(date);
		int count = end.getAvailableTopiNumber();
		for(int i =1; i <= count; i++)
	    {
			startORResumeCourse();
//	    	completeCourse();
			completeCoursetestCode();
		    onlyExitCourse();		    
	    }
	}
	
	public void completeWholeCourseexiting(String quarter)
	{
		EndUser	end = new EndUser();
		String date;
		if(courseListName.containsKey(quarter))
			date=courseListName.get(quarter).toString();
		else
		  date = end.changeDate(Integer.parseInt(quarter));
		
		end.runScriptForPastDate(date);
		  
	end.clickOnSubmitOnlyWithDate(date);
	int count = end.getAvailableTopiNumber();
		
			startORResumeCourse();
//	    	completeCourse();
		 	    
	    
	}
	public void completeWholeCourse(int quarter,String option)
	{
			EndUser	end = new EndUser();
			String date = end.changeDate(quarter);
			end.runScriptForPastDate(date);
			  
		end.clickOnSubmitOnlyWithDate(date);
		int count = end.getNumberRow();
		for(int i =1;;)
	    {
			startORResumeCourse();
	    	completeCourse();
	    	
	    	i++;
    		if(i <= count)
    		{
    			  onlyExitCourse();
		 		   
    		}
    		else
    		{
    			if(option.equals("closeWithoutExit"))
    		{
    					    			break;
    		}
    			else
    			{
    			onlyExitCourse();
    			}
    		}
		       
	    }
	}
	public void clickontestConsent()
	{
		try
		{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		String msg=null;
		wait.until(ExpectedConditions.visibilityOf(subDomainFederalPopupAccept));
		if(AssignmentReport. checkifParmeterAvailable( "FederalHeader"))
			 msg=AssignmentReport.getParmeterAvailable( "FederalHeader");
		Assert.assertEquals(subDomainFederalPopupHeader.getText(), msg);
		if(AssignmentReport. checkifParmeterAvailable( "FederalBody"))
			 msg=AssignmentReport.getParmeterAvailable( "FederalBody");
		System.out.println(msg);
		Assert.assertEquals(subDomainFederalPopupText.getText(), msg);
		
		subDomainFederalPopupAccept.click();
		System.out.println("Click on the consent form");
//		consentaccept.click();
		}
		catch(Exception e)
		{
			
			
				Assert.fail("Consent Popup missing");
			
		}	
	}
	public void completeWholeCoursequater(int quarter)
	{
			EndUser	end = new EndUser();
			String date = end.changeDate(quarter);
			
		end.clickOnSubmitOnlyWithDate(date);
		int count =end. getAvailableTopiNumber();
		for(int i =1; i <= count; i++)
	    {
			startORResumeCourse();
//	    	completeCourse();
			completeCoursetestCode();
		    onlyExitCourse();		    
	    }
	}
	public void resumWholeCoursequater()
	{
			EndUser	end = new EndUser();
			clickOnSubmit();
	int count =end. getAvailableTopiNumber();
		for(int i =1; i <= count; i++)
	    {
			startORResumeCourse();
//	    	completeCourse();
			completeCoursetestCode();
		    onlyExitCourse();		    
	    }
	}
	public void completeWholeCourse()
	{
//		
		clickOnSubmit();
		int count = getNumberRows();
		System.out.println(count);
		for(int i =1; i <= count; i++)
	    {
			startORResumeCourse();
//	    	completeCourse();
			completeCoursetestCode();
		    onlyExitCourse();		    
	    }
		end.cecmepopup();
	}
	
	public void completeWholeCourseexiting()
	{
//		clickontestConsent();
		clickOnSubmit();
		int count = getNumberRows();
		
		for(int i =1; i <= count; i++)
	    {
			startORResumeCourse();
//	    	completeCourse();
			completeCoursetestCode();
			if(i!=count)
		    onlyExitCourse();		  
		    
	    }
			
//	    	completeCourse();
		 	    
	    
	}
	
	public void completeWholeCoursedirectly()
	{
//		clickontestConsent();
		clickOnSubmit();
		int count = getNumberRows();
		
		for(int i =1; i <= count; i++)
	    {
			startORResumeCourse();
//	    	completeCourse();
			completeCoursetestCode();
			onlyExitCourse();		  
		    
	    }
		
		Set<String> allWindowHandles = driver.getWindowHandles();
		driver.switchTo().window(allWindowHandles.toArray()[1].toString());
//		
		driver.close();
		driver.switchTo().window(allWindowHandles.toArray()[0].toString());
//		driver.close();
//	    	completeCourse();
		 	    
	    
	}
	
	public void completeWholeCourseexitng()
	{
//		clickontestConsent();
		clickOnSubmit();
		int count = getNumberRows();
		
//			startORResumeCourse();
//	    	completeCourse();
		 	    
	    
	}
	public void exitButton()
	{
		   onlyExitCourse();	
			Set<String> allWindowHandles = driver.getWindowHandles();
			
		   driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
	}
	public void completeWholeCourseOnline()
	{
//		clickontestConsent();
		clickOnSubmit();
//		int count = getNumberRows();
//		System.out.println(count);
//		
//			System.err.println(i);
			startORResumeCourseOnline();
			completeCourseonline();
		    onlyExitCourse();		    
	    
	}
	
	public void completeWholeCourseexit()
	{
		clickOnSubmit();
		int count = getNumberRows();
		for(int i =1; i <= count; i++)
	    {
			startORResumeCourse();
//			completeCourseexit();
		    onlyExitCourse();		    
	    }
	}

	public void switchWindowSelfone(String mail)
	{
		try
		{
			int m=0;
		
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==700)
					break;
				m++;
			}
			System.out.println(allWindowHandles.size());
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			for(int i = 0; i <= allWindowHandles.size()-1; i++)
			{
				try {
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
				String url = driver.getCurrentUrl();
				allWindowHandles = driver.getWindowHandles();
				System.out.println(url);
				if(url.contains("/dispatch") && (!url.contains("/dispatch.html")))
					break;	
				}
				catch(Exception ex)
				{
					
				}
//				  LogEntries entry = driver.manage().logs().get(LogType.BROWSER);
//			        // Retrieving all log 
//			        List<LogEntry> logs= entry.getAll();
//			        // Print one by one
//			        for(LogEntry e: logs)
//			        {
//			        	System.out.println(e);
//			        }
//			        
//			        // Printing details separately 
//			        for(LogEntry e: logs)
//			        {
//			        	System.out.println("Message is: " +e.getMessage());
//			        	System.out.println("Level is: " +e.getLevel());
//			        
//			        }
			}
			
			
			selfregistertion(Students.email,Students.firstName,Students.lastName);
			clickOnSubmit();
			
		      int count = getNumberRows();
			    System.out.println("count is " + count);
			    if(count > 1)
			    {
			    	for(int j =1; j <= count-1; j++)
				    {
				    	startORResumeCourse();
				    	completeCoursetestCode();
					    onlyExitCourse();
					    
				    }
			    }
			    else
			    {
			    	startORResumeCourse();
			    	completeCoursetestCode();
				    onlyExitCourse();
			    }
			    
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public void complecourseoneTopic()
	{
		if(end == null)
			end = new EndUser();
	  
		try
		{
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			int m=0;
			System.out.println(allWindowHandles.size());
			
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				System.out.println(allWindowHandles.size());
				
				if(m==pagload)
					break;
				m++;
			}
			for(int i=1;i<allWindowHandles.size();i++)
			{
				System.out.println("Before focus " + allWindowHandles.toArray());
				try
				{
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
					if(driver.getCurrentUrl().contains("scorm/dispatchlaunch"))
						break;
				}
				catch(Exception e)
				{
					
				}
			}
			
			System.out.println(driver.getCurrentUrl()+"After focus" + driver.getWindowHandle());
		
			clickOnSubmit();
			
		      int count = getNumberRows();
			    System.out.println("count is " + count);
			    if(count > 1)
			    {
			    	for(int j =1; j <= count-1; j++)
				    {
				    	startORResumeCourse();
				    	completeCoursetestCode();
					    onlyExitCourse();
					    
				    }
			    }
			    else
			    {
			    	startORResumeCourse();
			    	completeCoursetestCode();
				    onlyExitCourse();
			    }
			    
			
		driver.close();
		driver.switchTo().window(allWindowHandles.toArray()[0].toString());
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		}
	
	public void complecourseoneTopicRegister()
	{
		if(end == null)
			end = new EndUser();
	  
		try
		{
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			int m=0;
			System.out.println(allWindowHandles.size());
			
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				System.out.println(allWindowHandles.size());
				
				if(m==pagload)
					break;
				m++;
			}
			for(int i=1;i<allWindowHandles.size();i++)
			{
				System.out.println("Before focus " + allWindowHandles.toArray());
				try
				{
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
					if(driver.getCurrentUrl().contains("scorm/dispatchlaunch"))
						break;
				}
				catch(Exception e)
				{
					
				}
			}
			
			System.out.println(driver.getCurrentUrl()+"After focus" + driver.getWindowHandle());
		
			clickOnSubmit();
			
		      int count = getNumberRows();
			    System.out.println("count is " + count);
			    if(count > 1)
			    {
			    	for(int j =1; j <= count-1; j++)
				    {
				    	startORResumeCourse();
				    	completeCoursetestCode();
					    onlyExitCourse();
					    
				    }
			    }
			    else
			    {
			    	startORResumeCourse();
			    	completeCoursetestCode();
				    onlyExitCourse();
			    }
			    
			
		driver.close();
		driver.switchTo().window(allWindowHandles.toArray()[0].toString());
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		}
	
	

	public void validateStatus(String status)
	{
		if(end == null)
			end = new EndUser();

		try
		{
			wait.until(ExpectedConditions.visibilityOf(scromStatus));
			Assert.assertEquals(scromStatus.getText(), status);

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

    }
		public void complecourseoneTopic(String date)
		{
			if(end == null)
				end = new EndUser();
		  
			try
			{
				Thread.sleep(10000);
				Set<String> allWindowHandles = driver.getWindowHandles();
				System.out.println(allWindowHandles.size());
				int m=0;
				while(allWindowHandles.size()<3)
				{
					allWindowHandles = driver.getWindowHandles();
					if(m==pagload)
						break;
					m++;
				}
				System.out.println("Before focus " + allWindowHandles.toArray()[1]);
				driver.switchTo().window(allWindowHandles.toArray()[1].toString());
				System.out.println("After focus" + driver.getWindowHandle());
				EndUser	end = new EndUser();
			
				if(courseListName.containsKey(date))
					date=courseListName.get(date).toString();
				else
				  date = end.changeDate(Integer.parseInt(date));
				
				end.runScriptForPastDate(date);
				  
			  end.clickOnSubmitOnlyWithDate(date);
			      int count = getNumberRows();
				    System.out.println("count is " + count);
				    if(count > 1)
				    {
				    	for(int j =1; j <= count-1; j++)
					    {
					    	startORResumeCourse();
					    	completeCourse();
						    onlyExitCourse();
						    
					    }
				    }
				    else
				    {
				    	startORResumeCourse();
				    	completeCourse();
					    onlyExitCourse();
				    }
				    
				
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
	}
		public void closeTab()
		{
			Set<String> allWindowHandles = driver.getWindowHandles();
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		
		}
		
		public void validatereviewButton()
		{
			try
			{
				
				//*[@id='hideshowbtn']
				
				
				wait.until(ExpectedConditions.visibilityOf(completeBtn));
				completeBtn.click();
				
				
				wait.until(ExpectedConditions.visibilityOfAllElements(completedActivit));
			
				wait.until(ExpectedConditions.visibilityOfAllElements(reviewBtn));
				;
		        Assert.assertEquals(reviewBtn.size(), completedActivit.size()); ;
		      
				
			}
			catch(Exception e)
			{
				Assert.fail(msg.getText());
			}
			
		}

		public void validateNotreviewButton()
		{
			try
			{
				
				//*[@id='hideshowbtn']
				
				
				wait.until(ExpectedConditions.visibilityOf(completeBtn));
				
				completeBtn.click();
				
				wait.until(ExpectedConditions.visibilityOfAllElements(completedActivit));
			
				wait.until(ExpectedConditions.visibilityOfAllElements(reviewBtn));
				;	Assert.fail("Course shoukd not be in review status");
				
		        Assert.assertEquals(reviewBtn.size(), completedActivit.size()); ;
		      
				
			}
			catch(Exception e)
			{
//				e.printStackTrace();
			}
			
		}
		public void validatemessage(String msg)
		{
			try
			{
				
				wait.until(ExpectedConditions.visibilityOf(rowmsg));
				System.out.println(rowmsg.getText());
				Assert.assertEquals(rowmsg.getText(), msg);

				
			}
			catch(Exception e)
			{
				Assert.fail();
			}
			
		}
		public void changefouse(int quarter)
		{
			if(end == null)
				end = new EndUser();
		  int m=0;
			try
			{
				Thread.sleep(10000);
				
				Set<String> allWindowHandles = driver.getWindowHandles();
				
				while(allWindowHandles.size()<3)
				{
					allWindowHandles = driver.getWindowHandles();
					if(m==700)
						break;
					m++;
				}
				System.out.println(allWindowHandles.size());
				System.out.println("Before focus " + allWindowHandles.toArray()[1]);
				for(int i = 0; i <= allWindowHandles.size()-1; i++)
				{
					try {
						driver.switchTo().window(allWindowHandles.toArray()[i].toString());
					String url = driver.getCurrentUrl();
					allWindowHandles = driver.getWindowHandles();
					System.out.println(url);
					if(url.contains("/dispatch") && (!url.contains("/dispatch.html")))
						break;	
					}
					catch(Exception ex)
					{
						
					}
				}
				
				String date = end.changeDate(quarter);
				end.runScriptForPastDate(date);
				
				  
				end.clickOnSubmitOnlyWithDate(date);
				clickOnSubmit();
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
		public void changefouse()
		{
			if(end == null)
				end = new EndUser();
		  int m=0;
			try
			{
				Thread.sleep(10000);
				
				Set<String> allWindowHandles = driver.getWindowHandles();
				
				while(allWindowHandles.size()<3)
				{
					allWindowHandles = driver.getWindowHandles();
					if(m==700)
						break;
					m++;
				}
				System.out.println(allWindowHandles.size());
				System.out.println("Before focus " + allWindowHandles.toArray()[1]);
				for(int i = 0; i <= allWindowHandles.size()-1; i++)
				{
					try {
						driver.switchTo().window(allWindowHandles.toArray()[i].toString());
					String url = driver.getCurrentUrl();
					allWindowHandles = driver.getWindowHandles();
					System.out.println(url);
					if(url.contains("/dispatch") && (!url.contains("/dispatch.html")))
						break;	
					}
					catch(Exception ex)
					{
						
					}
				}
				
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
	public void complecourseoneTopic(int quarter)
	{
		if(end == null)
			end = new EndUser();
	  
		try
		{
			
			int m=0;
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==100)
					break;
				m++;
			}
			System.out.println(allWindowHandles.size());
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			for(int i = 0; i <= allWindowHandles.size()-1; i++)
			{
				try {
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
				String url = driver.getCurrentUrl();
				allWindowHandles = driver.getWindowHandles();
				System.out.println(url);
				if(url.contains("/dispatch") && (!url.contains("/dispatch.html")))
					break;	
				}
				catch(Exception ex)
				{
					
				}
			}
			
			String date = end.changeDate(quarter);
			end.runScriptForPastDate(date);
			
			  
			end.clickOnSubmitOnlyWithDate(date);
			clickOnSubmit();
			
			
		      int count = end.getAvailableTopiNumber();
			    System.out.println("count is " + count);
			    if(count > 1)
			    {
			    	for(int j =1; j <= count-1; j++)
				    {
				    	startORResumeCourse();
				    	completeCoursetestCode();
					    onlyExitCourse();
					    
				    }
			    }
			    else
			    {
			    	startORResumeCourse();
			    	completeCoursetestCode();
				    onlyExitCourse();
			    }
			    
			
		driver.close();
		driver.switchTo().window(allWindowHandles.toArray()[0].toString());
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
	}
	public void complecourseoneTopics(String date)
	{
		if(end == null)
			end = new EndUser();
	  
		try
		{
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			System.out.println(allWindowHandles.size());
			int m=0;
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==pagload)
					break;
				m++;
			}
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			driver.switchTo().window(allWindowHandles.toArray()[1].toString());
			System.out.println("After focus" + driver.getWindowHandle());
			
			
			end.runScriptForPastDate(date);
			
			  
			end.clickOnSubmitOnlyWithDate(date);
			
			
		      int count = end.getAvailableTopiNumber();
			    System.out.println("count is " + count);
			    if(count > 1)
			    {
			    	for(int j =1; j <= count-1; j++)
				    {
				    	startORResumeCourse();
				    	completeCourse();
					    onlyExitCourse();
					    
				    }
			    }
			    else
			    {
			    	startORResumeCourse();
			    	completeCourse();
				    onlyExitCourse();
			    }
			    
			
		driver.close();
		driver.switchTo().window(allWindowHandles.toArray()[0].toString());
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
	}
	public void onlylaunch()
	{
		if(end == null)
			end = new EndUser();
	  
		try
		{
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			System.out.println(allWindowHandles.size());
			int m=0;
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==pagload)
					break;
				m++;
			}
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			driver.switchTo().window(allWindowHandles.toArray()[1].toString());
			System.out.println("After focus" + driver.getWindowHandle());
			clickOnSubmit();
			
			
		driver.close();
		driver.switchTo().window(allWindowHandles.toArray()[0].toString());
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
	}
	public void onlylaunch(String date)
	{
		if(end == null)
			end = new EndUser();
	  
		try
		{
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			System.out.println(allWindowHandles.size());
			int m=0;
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==pagload)
					break;
				m++;
			}
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			driver.switchTo().window(allWindowHandles.toArray()[1].toString());
			System.out.println("After focus" + driver.getWindowHandle());
			end.runScriptForPastDate(date);
			
			  
			end.clickOnSubmitOnlyWithDate(date);
			
		
			
		driver.close();
		driver.switchTo().window(allWindowHandles.toArray()[0].toString());
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
	}
	
	public void openTab()
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.open('');");
		} 
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}
	}
	public void switchWindowConsentnotice(String email)
	{
		try
		{
			Thread.sleep(10000);
//			Set<String> allWindowHandles = driver.getWindowHandles();
//			System.out.println(allWindowHandles.size());
//			int m=0;
//			while(allWindowHandles.size()<3)
//			{
//				allWindowHandles = driver.getWindowHandles();
//				if(m==pagload)
//					break;
//				m++;
//			}
//			
//			
//			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
//			driver.switchTo().window(allWindowHandles.toArray()[1].toString());
//			System.out.println("After focus" + driver.getWindowHandle());
//			
			Set<String> allWindowHandles = driver.getWindowHandles();
			int m=0;
			System.out.println(allWindowHandles.size());
			
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				System.out.println(allWindowHandles.size());
				
				if(m==pagload)
					break;
				m++;
			}
			for(int i=1;i<allWindowHandles.size();i++)
			{
				System.out.println("Before focus " + allWindowHandles.toArray());
				try
				{
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
					if(driver.getCurrentUrl().contains("scorm/dispatchlaunch"))
						break;
				}
				catch(Exception e)
				{
					
				}
			}
			
			System.out.println(driver.getCurrentUrl()+"After focus" + driver.getWindowHandle());
		
			clickontestConsent();
			completeWholeCourse();
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public void switchWindowConsentnoticeSelf(String mail)
	{
		try
		{
			int m=0;
		
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==700)
					break;
				m++;
			}
			System.out.println(allWindowHandles.size());
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			for(int i = 0; i <= allWindowHandles.size()-1; i++)
			{
				try {
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
				String url = driver.getCurrentUrl();
				allWindowHandles = driver.getWindowHandles();
				System.out.println(url);
				if(url.contains("/dispatch") && (!url.contains("/dispatch.html")))
					break;	
				}
				catch(Exception ex)
				{
					
				}

			}
			
			
			selfregistertion(Students.email,Students.firstName,Students.lastName);
		
			clickontestConsent();
			
			clickOnSubmit();
			
		      int count = getNumberRows();
			
		  	System.out.println(count);
			for(int i =1; i <= count; i++)
		    {
				startORResumeCourse();
//		    	completeCourse();
				completeCoursetestCode();
			    onlyExitCourse();		    
		    }
			
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public void switchWindowVersion(String version)
	{
		try
		{
			int m=0;
		
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==700)
					break;
				m++;
			}
			System.out.println(allWindowHandles.size());
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			for(int i = 0; i <= allWindowHandles.size()-1; i++)
			{
				try {
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
				String url = driver.getCurrentUrl();
				allWindowHandles = driver.getWindowHandles();
				System.out.println(url);
				if(url.contains("/dispatch") && (!url.contains("/dispatch.html")))
					break;	
				}
				catch(Exception ex)
				{
					
				}

			}
			
			
//			selfregistertion(Students.email,Students.firstName,Students.lastName);
		
//			clickontestConsent();
			
			clickOnSubmit();
			
			
			wait.until(ExpectedConditions.visibilityOfAllElements(versionTopic));

			System.out.println(versionTopic.getText());
		Assert.assertEquals(versionTopic.getText(), version);
		
			
		      int count = getNumberRows();
			
		  	System.out.println(count);
			for(int i =1; i <= count; i++)
		    {
				startORResumeCourse();
//		    	completeCourse();
				completeCoursetestCode();

				Assert.assertEquals(versionEachTopic.getText(), version);
				
				
			    onlyExitCourse();		    
		    }
			
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public void switchWindow(int q,String Version)
	{
		try
		{
			int m=0;
			Thread.sleep(10000);
			Set<String> allWindowHandles = driver.getWindowHandles();
			
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				if(m==700)
					break;
				m++;
			}
			System.out.println(allWindowHandles.size());
			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
			for(int i = 0; i <= allWindowHandles.size()-1; i++)
			{
				try {
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
				String url = driver.getCurrentUrl();
				allWindowHandles = driver.getWindowHandles();
				System.out.println(url);
				if(url.contains("/dispatch") && (!url.contains("/dispatch.html")))
					break;	
				}
				catch(Exception ex)
				{
					
				}
			}
			

			EndUser	end = new EndUser();
			
			Assert.assertEquals(versionTopic.getText(), Version);
			
		
			String date = end.changeDate(q);
			end.runScriptForPastDate(date);
			  
		end.clickOnSubmitOnlyWithDate(date);
		int count = end.getAvailableTopiNumber();
		for(int i =1; i <= count; i++)
	    {
			
			startORResumeCourse();
//	    	completeCourse();
			completeCoursetestCode();
			System.out.println(versionEachTopic.getText());
			Assert.assertEquals(versionEachTopic.getText(), Version);
			
			
		    onlyExitCourse();		    
	    }
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void switchMidWindow()
	{
		try 
		{
		Set<String> allWindowHandles = driver.getWindowHandles();
		System.out.println(allWindowHandles.size());
		int counter = 0;
		while(allWindowHandles.size()<3)
		{
			allWindowHandles = driver.getWindowHandles();
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load window after waiting for 1 minute");
		}
		System.out.println(allWindowHandles.size());
		System.out.println("Before focus " + allWindowHandles.toArray()[0]);
		for(int i = 0; i <= allWindowHandles.size()-1; i++)
		{
			driver.switchTo().window(allWindowHandles.toArray()[i].toString());
			try {
			String url = driver.getCurrentUrl();
			allWindowHandles = driver.getWindowHandles();
			if(url.contains("/dispatch.html"))
				break;	
			}
			catch(Exception ex)
			{
				
			}
		}
		System.out.println("After focus" + driver.getWindowHandle());
		}  
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	public void switchMessages(String mssg)
	{
		try
		{
			Thread.sleep(10000);
//			Set<String> allWindowHandles = driver.getWindowHandles();
//			System.out.println(allWindowHandles.size());
//			int m=0;
//			while(allWindowHandles.size()<3)
//			{
//				allWindowHandles = driver.getWindowHandles();
//				if(m==pagload)
//					break;
//				m++;
//			}
//			
//			
//			System.out.println("Before focus " + allWindowHandles.toArray()[1]);
//			driver.switchTo().window(allWindowHandles.toArray()[1].toString());
//			System.out.println("After focus" + driver.getWindowHandle());
//			
			Set<String> allWindowHandles = driver.getWindowHandles();
			int m=0;
			System.out.println(allWindowHandles.size());
			
			
			while(allWindowHandles.size()<3)
			{
				allWindowHandles = driver.getWindowHandles();
				System.out.println(allWindowHandles.size());
				
				if(m==pagload)
					break;
				m++;
			}
			for(int i=1;i<allWindowHandles.size();i++)
			{
				System.out.println("Before focus " + allWindowHandles.toArray());
				try
				{
					driver.switchTo().window(allWindowHandles.toArray()[i].toString());
					if(driver.getCurrentUrl().contains("dispatch/accessdenied"))
						break;
				}
				catch(Exception e)
				{
					
				}
			}
			
			System.out.println(driver.getCurrentUrl()+"After focus" + driver.getWindowHandle());
		
					    System.out.println(msg2.getText());
			Assert.assertTrue("Validate message"+msg2.getText(), msg2.getText().equals(mssg));	
			 ;
			driver.close();
			driver.switchTo().window(allWindowHandles.toArray()[0].toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void validateSelfRegisterMessage()
	{
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(errorMessage));
		String actualMsg = errorMessage.getText().trim();
		String ExpectedMsg = "Self registration not enabled. Please contact your system administrator.";
		Assert.assertEquals(actualMsg, ExpectedMsg);
	}
}
