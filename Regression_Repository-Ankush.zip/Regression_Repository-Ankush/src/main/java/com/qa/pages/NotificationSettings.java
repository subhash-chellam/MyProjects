package com.qa.pages;

import java.io.File;
import java.io.FileReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.opencsv.CSVReader;
import com.qa.util.TestBase;
import com.qa.util.TestUtils;

public class NotificationSettings extends TestBase {

	TestUtils testUtils = new TestUtils();
	String row = "//table[contains(@id,'reports')]//tbody//tr";
	
	@FindBy(xpath = "//a[@href='https://qa-bhagat-rqi1stop.laerdalblr.in/admin/organizations/dashboard']")
	WebElement Link_HomeButton;

//	@FindBy (xpath = "//tr//td[contains(text(),'Assignment completed')]/preceding-sibling::td")
	String Text_AssignmentCompleted = "//tr//td[contains(text(),'Assignment completed')]/preceding-sibling::td";

	@FindBy(xpath = "//div[@class='container navbar-cont']//div[contains(@class,'collapse navbar-collapse')]/ul/li/a")
	List<WebElement> Links_OrgTabs;
	// ul[@class='nav nav-tabs edit_organization_tabs']/li/a

	@FindBy(xpath = "//div[@class='container']//div//ul[@class='nav nav-tabs edit_organization_tabs']//li")
	List<WebElement> Links_NavTabs;
	// ul[@class='nav navbar-nav navbar-nav1']//li

	@FindBy(xpath = "//div[@class='main_cont']/div/strong//following::table/thead/tr/th")
	List<WebElement> Table_AdminNotifications;

	@FindBy(xpath = "//div[@class='main_cont']/table[@aria-describedby='table']/thead/tr/th")
	List<WebElement> Table_StudentNotifications;

	@FindBy(xpath = "//div[@class='main_cont']/div/strong//following::table/tbody/tr")
	List<WebElement> RowCount_AdminNotifications;

	@FindBy(xpath = "//div[@class='main_cont']/table[@aria-describedby='table']/tbody/tr")
	List<WebElement> RowCount_StudentNotifications;

	@FindBy(xpath = "//div[@class='radio radio-primary']//label")
	List<WebElement> RadioButton_GlobalNotifications;
	//input[@type='radio'][@name='notification_status']
	

	@FindBy(xpath = "//a[contains(text(),'Edit Organization')]")
	WebElement Button_EditOganization;

	@FindBy(xpath = "//div[@class='content']//div[@class='container']//following::ul/li/a")
	List<WebElement> Tabs_OrgDetails;

	@FindBy(xpath = "//button[@id='submit_btn']")
	WebElement UpdateOrg;

	@FindBy(xpath = "//input[@id='searchbox_name_email']")
	WebElement InputSearch_Emailid;

	@FindBy(xpath = "//button[@id='searchbtn']")
	WebElement Button_Search;

	@FindBy(xpath = "//table[@aria-describedby='learnerTableList_info']//tbody/tr[1]/td[9]")
	WebElement Button_Action;
	// div[@class='dropdown']//a[@class='action_dropdown']

	@FindBy(xpath = "//div[@class='dropdown open']//ul[@class='dropdown-menu']//li")
	List<WebElement> UserLinks;

	@FindBy(xpath = "//iframe[@id='content_ifr']")
	WebElement EmailTemplateFrame;

	@FindBy(xpath = "//iframe[@class='ot-text-resize']")
	WebElement Frame_Text;

	@FindBy(xpath = "//body[@id='tinymce']/p")
	WebElement Text_Paragraph;

	@FindBy(xpath = "//input[@type='text']")
	WebElement TextField_Subject;

	@FindBy(xpath = "//a[contains(text(),'Save')]")
	WebElement Button_Save;
	// div[@class='main_cont']//preceding-sibling::strong/p[contains(text(),'Student
	// Notifications')]

	@FindBy(xpath = "//span[contains(text(),'Email template was updated successfully.')]")
	WebElement EMailTemplate_Success;

	@FindBy(xpath = "//div[@class='radio']//label[contains(text(),'Yes - Click on “Generate SSO Settings” to configure SAP CDC as active directory.')]")
	WebElement Text_SSOSettings;

	@FindBy(xpath = "(//table[@aria-describedby = 'tablelisting_info']//td[1])[1]")
	WebElement resultOrgID;

	@FindBy(xpath = "(//table[@aria-describedby = 'tablelisting_info']//a[@data-toggle='dropdown'])[1]")
	WebElement actionDropdown;

	@FindBy(xpath = "(//table[@aria-describedby = 'tablelisting_info']//a[text() = 'SFTP Settings '])[1]")
	WebElement orgSFTP;

	@FindBy(xpath = "//button[text()= 'Generate SSO Settings']")
	WebElement generateButton;

	@FindBy(xpath = "//a[contains(text(), 'SSO Settings')]")
	WebElement ssoSettingTab;
	
	@FindBy(xpath = "//div[@class='container']//ul/li/a")
	List<WebElement> Tabs_SSOSettings;

	@FindBy (xpath = "//div[@class='dataTables_scroll']//div[@class='dataTables_scrollBody']//table[@id='reports']//tbody/tr")
	WebElement Text_NoRecordsFound;
	//div[@class='dataTables_scrollBody']//table[@id='reports']//tbody/tr/td
	//div[@class='dataTables_scroll']//div[@class='dataTables_scrollBody']//table//tbody//tr//td[@class='dataTables_empty']
	//div[@class='dataTables_scroll']//div[@class='dataTables_scrollBody']//table[@id='reports']//tbody/tr//td
	
	@FindBy (xpath = "//div[@class='dataTables_scrollBody']//table[@id='reports']//tbody/tr")
	WebElement Text_trNoRecordsFound;
	
	@FindBy (xpath = "//div[@id='messagectn']//div")
	WebElement Text_InboxEmpty;
	
	@FindBy (xpath = "//div[@class='DTFC_ScrollWrapper']//div[@class='dataTables_scroll']//div[@class='dataTables_scrollBody']//table[@id='reports']//tr")
	List<WebElement> NotificationTablelog;
	//[1]//td[5]
	
	String oldTab, newTab;
	String NewUserAdded = "Your account has been created successfully in RQI1Stop.Please click here to reset your password.";
	String ForgotPassword = "A request to reset the password for your account has been made. Please click here to reset your password.";

	String AssignmentCompleted = "Dear {student_name},\r\n" + "\r\n"
			+ "Thank you for completing {assignment_name} .\r\n" + "\r\n"
			+ "To access your assignment anytime, login at {sitename} and go to the My eLearning section.\r\n" + "\r\n"
			+ "For any questions, please contact:\r\n" + "\r\n" + "{contact_person_name}\r\n"
			+ "{contact_person_email}";

	String NewAssignmentAvailable = "Dear {yourname},\r\n" + "\r\n"
			+ "You have a new assignment on {sitename} by {from_user} - {from_email}\r\n" + "\r\n"
			+ "Assignment: {assignment_name}\r\n" + "\r\n" + "Assigned to: {firstname} {lastname} - {toid}\r\n" + "\r\n"
			+ "If you do not already have an account set up on {sitename}, you will be asked to register prior to beginning your assignment.\r\n"
			+ "\r\n" + "To access your assignment anytime, login at {sitename} and go to the My Programs section.\r\n"
			+ "\r\n" + "For any questions, please contact:\r\n" + "\r\n" + "{contact_person_name}\r\n"
			+ "{contact_person_email}";

	public NotificationSettings() {
		PageFactory.initElements(driver, this);

	}

	public void ClickOnHomeButton() {
		Link_HomeButton.click();
	}

	public void checkwhetherStatusIsONorOFF() {
		// boolean flag =0;
		// Text_AssignmentCompleted
		// DriverManager.getDriver().findElement(By.xpath(RegionDisabled)).getAttribute("aria-disabled");
		boolean value = driver.findElement(By.xpath(Text_AssignmentCompleted)).isSelected();
		System.out.println(" The status value is : " + value);
		// Assert.assertTrue(value);
		/*
		 * if(value) { return flag ; }
		 */

		// JavascriptExecutor js = (JavascriptExecutor) driver;

		// driver.findElement(By.xpath(RegionDisabled)).getAttribute("aria-disabled");
	}

	public void SelectOrgTab(String value) {
		TestUtils.selectFromTheList(Links_OrgTabs, value);
	}

	public void SelectNavTab(String value) {
		TestUtils.selectFromTheList(Links_NavTabs, value);
	}

	public void SelectStudentNotifications(String columnValue) {
		TestUtils.selectFromTheList(Table_StudentNotifications, columnValue);
		// testUtils.SelectTheValueFromTheTable(Links_NavTabs, Text_AssignmentCompleted,
		// timeout, pagload)
	}

	public void selectAdminNotifications(String columnValue) {
		TestUtils.selectFromTheList(Table_AdminNotifications, columnValue);
	}

	public void selectEventNameFromAdminNotificationsTable(String cellValueToCompare, int ColumntoIterate,
			int ToGetvalueFromcolumn) {
		testUtils.AdminNotificationsTable(RowCount_AdminNotifications, cellValueToCompare, ColumntoIterate,
				ToGetvalueFromcolumn);
	}
	
	public void AdminNotificationsOff(String cellValueToCompare, int ColumntoIterate,
			int ToGetvalueFromcolumn) {
		testUtils.AdminNotificationsOff(RowCount_AdminNotifications, cellValueToCompare, ColumntoIterate,
				ToGetvalueFromcolumn);
	}
	
	
	

	public void selectEventNameFromStudentNotificationsTable(String cellValueToCompare, int ColumntoIterate,
			int ToGetvalueFromcolumn) {
		testUtils.StudentNotificationsTable(RowCount_StudentNotifications, cellValueToCompare, ColumntoIterate,
				ToGetvalueFromcolumn);
	}
	
	public void StudentNotificationsOff(String cellValueToCompare, int ColumntoIterate,
			int ToGetvalueFromcolumn) {
		testUtils.StudentNotificationsOff(RowCount_StudentNotifications, cellValueToCompare, ColumntoIterate,
				ToGetvalueFromcolumn);
	}
	
	
	public void SelectRadioButton(String radioValue) {
		wait.until(ExpectedConditions.elementToBeClickable(Button_EditOganization));
		Button_EditOganization.click();
		TestUtils.selectFromTheList(RadioButton_GlobalNotifications, radioValue);
	//	wait.until(ExpectedConditions.elementToBeSelected(UpdateOrg));
		wait.until(ExpectedConditions.elementToBeClickable(UpdateOrg));
		UpdateOrg.click();
		/*
		 * if(radioValue.contains("Yes")) {
		 * System.out.println(" The Global Notifiction is On"); } else {
		 * testUtils.selectFromTheList(RadioButton_GlobalNotifications, "No"); }
		 */
	}

	public void SelectTabFromList(String selectTab) {
		TestUtils.selectFromTheList(Tabs_OrgDetails, selectTab);
	}

	public void UpdateOrg() {
		UpdateOrg.click();
	}

	public void SearchUserByEmail(String EmailId) {
		InputSearch_Emailid.sendKeys(EmailId);
		Button_Search.click();
	}

	public void selectViewDetails(String value) {
		Button_Action.click();
		TestUtils.selectFromTheList(UserLinks, value);
	}

	public void navigateToOrg() {
		// driver.navigate().to(null);
	}

//	driver.executeScript("return document.getElementById('gsc-i-id1').getAttribute('class');"));
	// context_id.getAttribute("checked")

//	element.getAttribute

	public void EditTemplateInStudentNotifcationsTable(String cellValueToCompare, int ColumntoIterate,
			int ToGetvalueFromcolumn) {
		TestUtils.EditTemplateInStudentNotifcationsTable(RowCount_StudentNotifications, cellValueToCompare,
				ColumntoIterate, ToGetvalueFromcolumn);
	}

	public void EditEmailContent() throws InterruptedException {
		driver.switchTo().frame(EmailTemplateFrame);
		String Initialvalue = Text_Paragraph.getText();
		String textValue = Text_Paragraph.getText().replace(" www.RQI1Stop.com ", "");
		String contactedValu = textValue + " www.RQI1Stop.com ";
		System.out.println("Template content is " + Text_Paragraph.getText());
		// TextField_Subject.sendKeys(Keys.TAB);
		Text_Paragraph.clear();
		Text_Paragraph.sendKeys(Keys.CLEAR);
		// TestUtils.clearWebField(Text_Paragraph);
		// Text_Paragraph.sendKeys(Keys.CLEAR);
		Text_Paragraph.sendKeys(contactedValu);
		driver.switchTo().defaultContent();
		// contactedValue
		// Text_Paragraph.sendKeys(Keys.TAB.TAB);

		// driver.switchTo().frame(Frame_Text);
		Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(Button_Save));
		Button_Save.click();
		String value = EMailTemplate_Success.getText();
		System.out.println(" the value is :" + value);
		Assert.assertEquals(EMailTemplate_Success.getText(), "Email template was updated successfully.");
	}

	public void EditEmailContentToOriginal() throws InterruptedException {
		driver.switchTo().frame(EmailTemplateFrame);
		String Initialvalue = Text_Paragraph.getText();

		System.out.println("Template content is " + Text_Paragraph.getText());
		// TextField_Subject.sendKeys(Keys.TAB);
		Text_Paragraph.sendKeys(Keys.CLEAR);
		Text_Paragraph.clear();
		// Text_Paragraph.sendKeys(contactedValu);
		driver.switchTo().defaultContent();
		// contactedValue
		// Text_Paragraph.sendKeys(Keys.TAB.TAB);

		// driver.switchTo().frame(Frame_Text);
		Thread.sleep(2000);
		wait.until(ExpectedConditions.elementToBeClickable(Button_Save));
		Button_Save.click();
		String value = EMailTemplate_Success.getText();
		System.out.println(" the value is :" + value);
		Assert.assertEquals(EMailTemplate_Success.getText(), "Email template was updated successfully.");
	}

	public void CheckWhetherSSOSettingsIsOn() {

		try {

			wait.until(ExpectedConditions.visibilityOf(actionDropdown));
			String orgId = resultOrgID.getText();
			actionDropdown.click();
			wait.until(ExpectedConditions.visibilityOf(orgSFTP));
			orgSFTP.click();
			
			TestUtils.selectFromTheList(Tabs_SSOSettings, "SSO Settings");
			
			
			WebDriverWait wait = new WebDriverWait(driver, 120);
			wait.until(ExpectedConditions.visibilityOf(generateButton));
			generateButton.click();

			ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
			oldTab = tabs.get(0);
			newTab = tabs.get(1);
			driver.switchTo().window(newTab);
			WebDriverWait webwait = new WebDriverWait(driver, 30);
			webwait.until(ExpectedConditions.visibilityOf(ssoSettingTab));
			ssoSettingTab.click();

			if (Text_SSOSettings.isEnabled()) {
				System.out.println(" SSO settings is on " + Text_SSOSettings.isEnabled());
			} else {
				WebDriverWait wwait = new WebDriverWait(driver, 120);
				wwait.until(ExpectedConditions.visibilityOf(generateButton));
				generateButton.click();
				driver.close();
				driver.switchTo().window(oldTab);
				// Text_SSOSettings.click();
				// System.out.println(" SSO settings is off ");
			}

		} catch (Exception e) {

			if (Text_SSOSettings.isEnabled()) {
				System.out.println(" SSO settings is on " + Text_SSOSettings.isEnabled());
			} else {
				WebDriverWait wwait = new WebDriverWait(driver, 120);
				wwait.until(ExpectedConditions.visibilityOf(generateButton));
				generateButton.click();
				driver.close();
				driver.switchTo().window(oldTab);
			}

		}

	}
	
	
	public void CheckWhetherSSOSettingsIsOn1() {
		try {
			if(generateButton.isDisplayed()) {
				WebDriverWait wwait = new WebDriverWait(driver, 120);
				wwait.until(ExpectedConditions.visibilityOf(generateButton));
				generateButton.click();
				driver.close();
		//		driver.switchTo().window(oldTab);
			}

		} catch (Exception e) {
			System.out.println(" SSO settings is on " + Text_SSOSettings.isEnabled());
			System.out.println(" Generate button not found ");
			driver.close();
	//		driver.switchTo().window(oldTab);
			// Text_SSOSettings.click();
		}
}

	public void NoRecordsFoundText() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		wait.until(ExpectedConditions.visibilityOf(Text_NoRecordsFound));
		String NoRecordsFound = Text_NoRecordsFound.getText();
		System.out.println( " td : The no records found :"+ NoRecordsFound);
		System.out.println( " td : The no records found :"+ NoRecordsFound);
	//	String NorecordsFoundTr = Text_trNoRecordsFound.getText();
	//	System.err.println( " tr : NorecordsFoundTr"+ NorecordsFoundTr);
		Assert.assertEquals(NoRecordsFound, "No reports data found.");
	//	Assert.assertTrue(NoRecordsFound, true);
	}

	
	public void InboxIsEmpty() {
		try {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			wait.until(ExpectedConditions.visibilityOf(Text_InboxEmpty));
		String Inbox_empty=	Text_InboxEmpty.getText();
		System.err.println( " td : The no records found :"+ Inbox_empty);
		System.out.println( " td : The no records found :"+ Inbox_empty);
		Assert.assertEquals(Inbox_empty, "This inbox is empty");
		
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void selectThevalueFromNotificationLogTable(String cellValueToCompare, int ColumntoIterate,
			int ToGetvalueFromcolumn) {
		testUtils.SelectTheValueFromTheTable(NotificationTablelog,cellValueToCompare , ColumntoIterate, ToGetvalueFromcolumn);
	}
	

	@FindBy(xpath = "//p[text() = 'Student Notifications']")
	WebElement notificationTabStudentHeading;
	
	@FindBy(xpath = "//iframe[@id = 'content_ifr']")
	WebElement emailBodyFrame;
	
	@FindBy(xpath = "//a[@id = 'notificationSubmit']")
	WebElement emailBodySaveButton;
	
	String studentNotificationRow = "//p[text() = 'Student Notifications']//parent::strong//following-sibling::div/table[contains(@class,'notification')]/tbody/tr";
	String adminNotificationRow = "//p[text() = 'Admin Notifications']//parent::strong//following-sibling::table/tbody/tr";
	public static String date;
	
	public void turnOnNotificationStudent(String notificationEvent)
	{
		try {
		wait.until(ExpectedConditions.visibilityOf(notificationTabStudentHeading));
		boolean flag = false;
		List<WebElement> rows = driver.findElements(By.xpath(studentNotificationRow));
		for(int i = 1; i <= rows.size(); i++)
		{
			String name = driver.findElement(By.xpath(studentNotificationRow + "[" + i + "]/td[2]")).getText();
			if(name.equalsIgnoreCase(notificationEvent))
			{
				WebElement element = driver.findElement(By.xpath(studentNotificationRow + "[" + i + "]/td[1]//input"));
				int counter = 0;
				boolean checkValue = element.getAttribute("checked") != null;
				while(!checkValue == true) {
					driver.findElement(By.xpath(studentNotificationRow + "[" + i + "]/td[1]//span")).click();
					wait.until(ExpectedConditions.stalenessOf(element));
					checkValue = driver.findElement(By.xpath(studentNotificationRow + "[" + i + "]/td[1]//input")).getAttribute("checked") != null;
					Thread.sleep(5000);
					counter++;
					if(counter>12)
						Assert.fail("Not able to load page after waiting for 1 minute");
				}
				flag = true;
				break;
			}
		}
		Assert.assertTrue(flag);
		}
		catch(Exception e)
		{
		Assert.fail(e.getMessage());	
		}
		
	}
	
	public void turnOnNotificationAdmin(String notificationEvent)
	{
		try {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(notificationTabStudentHeading));
		boolean flag = false;
		List<WebElement> rows = driver.findElements(By.xpath(adminNotificationRow));
		for(int i = 1; i <= rows.size(); i++)
		{
			String name = driver.findElement(By.xpath(adminNotificationRow + "[" + i + "]/td[2]")).getText();
			if(name.equalsIgnoreCase(notificationEvent))
			{
				WebElement element = driver.findElement(By.xpath(adminNotificationRow + "[" + i + "]/td[1]//input"));
				boolean checkValue = element.getAttribute("checked") != null;
				int counter = 0;
				while(!checkValue == true) {
					driver.findElement(By.xpath(adminNotificationRow + "[" + i + "]/td[1]//span")).click();
					wait.until(ExpectedConditions.stalenessOf(element));
					checkValue = driver.findElement(By.xpath(adminNotificationRow + "[" + i + "]/td[1]//input")).getAttribute("checked") != null;
					Thread.sleep(5000);
					counter++;
					if(counter>12)
						Assert.fail("Not able to load page after waiting for 1 minute");
				}
				flag = true;
				break;
			}
		}
		Assert.assertTrue(flag);
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void turnOFFNotificationStudent(String notificationEvent)
	{
		try {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(notificationTabStudentHeading));
		boolean flag = false;
		Thread.sleep(5000);
		
		List<WebElement> rows = driver.findElements(By.xpath(studentNotificationRow));
		for(int i = 1; i <= rows.size(); i++)
		{
			String name = driver.findElement(By.xpath(studentNotificationRow + "[" + i + "]/td[2]")).getText();
			if(name.equalsIgnoreCase(notificationEvent))
			{
				WebElement element = driver.findElement(By.xpath(studentNotificationRow + "[" + i + "]/td[1]//input"));
				boolean checkValue = element.getAttribute("checked") != null;
				int counter = 0;
				while(checkValue == true) {
					driver.findElement(By.xpath(studentNotificationRow + "[" + i + "]/td[1]//span")).click();
					wait.until(ExpectedConditions.stalenessOf(element));
					checkValue = driver.findElement(By.xpath(studentNotificationRow + "[" + i + "]/td[1]//input")).getAttribute("checked") != null;
					Thread.sleep(5000);
					counter++;
					if(counter>12)
						Assert.fail("Not able to load page after waiting for 1 minute");
				}
				flag = true;
				break;
			}
		}
		Assert.assertTrue(flag);
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());	
		}
	}
	
	public void turnOFFNotificationAdmin(String notificationEvent)
	{
		try {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(notificationTabStudentHeading));
		boolean flag = false;
		List<WebElement> rows = driver.findElements(By.xpath(adminNotificationRow));
		for(int i = 1; i <= rows.size(); i++)
		{
			String name = driver.findElement(By.xpath(adminNotificationRow + "[" + i + "]/td[2]")).getText();
			if(name.equalsIgnoreCase(notificationEvent))
			{
				WebElement element = driver.findElement(By.xpath(adminNotificationRow + "[" + i + "]/td[1]//input"));
				boolean checkValue = element.getAttribute("checked") != null;
				int counter = 0;
				while(checkValue == true) {
					driver.findElement(By.xpath(adminNotificationRow + "[" + i + "]/td[1]//span")).click();
					wait.until(ExpectedConditions.stalenessOf(element));
					checkValue = driver.findElement(By.xpath(adminNotificationRow + "[" + i + "]/td[1]//input")).getAttribute("checked") != null;
					Thread.sleep(5000);
					counter++;
					if(counter>12)
						Assert.fail("Not able to load page after waiting for 1 minute");
				}
				flag = true;
				break;
			}
		}
		Assert.assertTrue(flag);
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
		
	}

	public void editEmailTemplateNotificationStudent(String notificationEvent)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(notificationTabStudentHeading));
		boolean flag = false;
		List<WebElement> rows = driver.findElements(By.xpath(studentNotificationRow));
		for(int i = 1; i <= rows.size(); i++)
		{
			String name = driver.findElement(By.xpath(studentNotificationRow + "[" + i + "]/td[2]")).getText();
			if(name.equalsIgnoreCase(notificationEvent))
			{
				WebElement element = driver.findElement(By.xpath(studentNotificationRow + "[" + i + "]/td[5]/a"));
				element.click();
				wait.until(ExpectedConditions.visibilityOf(emailBodyFrame));
				driver.switchTo().frame(emailBodyFrame);
				wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath("//body[@id='tinymce']/p"))));
				
				List<WebElement> contentRow = driver.findElements(By.xpath("//body[@id='tinymce']/p"));
				String text = driver.findElement(By.xpath("//body[@id='tinymce']/p[" + contentRow.size() + "]")).getText();
				System.out.println(text);
				Date formatDate = new java.util.Date();
				date = formatDate.toString();
				date = date.replace(" ", "").replace(":", "").replace("-", "");
//				JavascriptExecutor js = (JavascriptExecutor)driver;
//				js.executeScript("arguments[0].textContent = arguments[1];", element, text + " " + date);
				//element.sendKeys(text + " " + date);				
				((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();",driver.findElement(By.xpath("//body[@id='tinymce']/p[" + contentRow.size() + "]")));
				driver.findElement(By.xpath("//body[@id='tinymce']/p[" + contentRow.size() + "]")).click();
				driver.findElement(By.xpath("//body[@id='tinymce']/p[" + contentRow.size() + "]")).clear();
				driver.findElement(By.xpath("//body[@id='tinymce']/p[" + contentRow.size() + "]")).sendKeys(Keys.RETURN);
				driver.findElement(By.xpath("//body[@id='tinymce']/p[" + contentRow.size() + "]")).sendKeys(text + " " + date);
				contentRow = driver.findElements(By.xpath("//body[@id='tinymce']/p"));
				text = driver.findElement(By.xpath("//body[@id='tinymce']/p[" + contentRow.size() + "]")).getText();
				Assert.assertTrue(text.contains(date));
				driver.switchTo().defaultContent();
				emailBodySaveButton.click();
				flag = true;
				break;
			}
		}
		Assert.assertTrue(flag);
	}
	
	public void editEmailTemplateNotificationAdmin(String notificationEvent)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(notificationTabStudentHeading));
		boolean flag = false;
		List<WebElement> rows = driver.findElements(By.xpath(adminNotificationRow));
		for(int i = 1; i <= rows.size(); i++)
		{
			String name = driver.findElement(By.xpath(adminNotificationRow + "[" + i + "]/td[2]")).getText();
			if(name.equalsIgnoreCase(notificationEvent))
			{
				WebElement element = driver.findElement(By.xpath(adminNotificationRow + "[" + i + "]/td[5]/a"));
				element.click();
				wait.until(ExpectedConditions.visibilityOf(emailBodyFrame));
				driver.switchTo().frame(emailBodyFrame);
				List<WebElement> contentRow = driver.findElements(By.xpath("//body/p"));
				String text = driver.findElement(By.xpath("//body[@id='tinymce']/p[" + contentRow.size() + "]")).getText();
				System.out.println(text);
				Date formatDate = new java.util.Date();
				date = formatDate.toString();
				date = date.replace(" ", "").replace(":", "").replace("-", "");
//				JavascriptExecutor js = (JavascriptExecutor)driver;
//				js.executeScript("arguments[0].textContent = arguments[1];", element, text + " " + date);
				//element.sendKeys(text + " " + date);
				driver.findElement(By.xpath("//body[@id='tinymce']/p[" + contentRow.size() + "]")).click();
				driver.findElement(By.xpath("//body[@id='tinymce']/p[" + contentRow.size() + "]")).clear();
				driver.findElement(By.xpath("//body[@id='tinymce']/p[" + contentRow.size() + "]")).sendKeys(Keys.RETURN);
				driver.findElement(By.xpath("//body[@id='tinymce']/p[" + contentRow.size() + "]")).sendKeys(text + " " + date);
				contentRow = driver.findElements(By.xpath("//body[@id='tinymce']/p"));
				text = driver.findElement(By.xpath("//body[@id='tinymce']/p[" + contentRow.size() + "]")).getText();
				Assert.assertTrue(text.contains(date));
				driver.switchTo().defaultContent();
				emailBodySaveButton.click();
				flag = true;
				break;
			}
		}
		Assert.assertTrue(flag);
	}

	public void validateNoRecordDisplay()
	 {
		 WebDriverWait wait = new WebDriverWait(driver, 30);
	     wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(row + "/td"))));
	  ;
	     Assert.assertTrue(driver.findElement(By.xpath(row + "/td")).getText().contains("No reports data found."));
	 }


	@FindBy(xpath = "//button[@id = 'resend']")
	WebElement resendButton;

	/*
	 * public void clickOnResendButton() { WebDriverWait wait = new
	 * WebDriverWait(driver, 30);
	 * wait.until(ExpectedConditions.visibilityOf(resendButton));
	 * resendButton.click(); }
	 * 
	 */

	@FindBy(xpath = "//div[@class='card-header']//a[text()='Notification Log  ']")
	WebElement Link_NotificationTab;

	@FindBy(xpath = "(//button[@value='Search'])[4]")
	WebElement ButtonSearch;

	@FindBy(xpath = "//select[@id = 'statusFilter']//following-sibling::div/button")
	WebElement userStatusFilter;

	@FindBy(xpath = "//select[@id = 'job_title_id']//following-sibling::div/button")
	WebElement jobFilter;

	@FindBy(xpath = "//select[@id = 'group_id']//following-sibling::div/button")
	WebElement groupFilter;

	@FindBy(xpath = "//a[@class = 'card-link assignment_filter']")
	WebElement courseFilter;

	@FindBy(xpath = "//a[@class='card-link']")
	WebElement Link_MoreFilters;

	@FindBy(xpath = "//a[@class='card-link collapsed']")
	WebElement MoreFilters;
	// div[@class='card-header']/a[text()='More Filters ']

	public void ClickOnNotificationlink() {
		try {
			Thread.sleep(2000);
			Link_NotificationTab.click();
			SearchNotificationButton();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void SearchNotificationButton() {
		ButtonSearch.click();
	}

	String fileName;
	public static String userEmail, userId, filePath, email, userId1;

	public boolean isFileDownloaded_Ext(String dirPath, String ext) {
		boolean flag = false;
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files != null) {
			for (int i = 0; i < files.length; i++) {
				if (files[i].getName().contains(ext) && !(files[i].getName().contains(".crdownload"))) {
					fileName = files[i].getName();
					filePath = files[i].getAbsolutePath();
					filePath = filePath.replace(".crdownload", "");
					// FileReader reader = new FileReader(
					// System.getProperty("user.dir")+prop.getProperty("downloadPath")+"\\coursesName"+prop.getProperty("environment")+".json",
					// StandardCharsets.UTF_8))
					flag = true;
					break;
				}
			}
		}

		return flag;
	}

	String downloadPath = System.getProperty("user.dir") + prop.getProperty("downloadPath");

	public boolean checkCSVFilePresent() {
		boolean dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
		return dwnld;
	}

	public void deleteFile(String path) {
		try {
			System.out.println("delete file path is " + path);
			File file = new File(path);
			Thread.sleep(5000);
			file.delete();
			boolean dwnld = false;
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
			int counter = 0;
			while (dwnld) {
				file = new File(filePath);
				file.delete();
				dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
				Thread.sleep(5000);
				counter++;
				if (counter > 12)
					Assert.fail("Not able to delete after waiting for 1 minute");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	String enableExportButton = "//button[@id = 'exportbtn' and not(contains(@class, 'disabled'))]";
	@FindBy(xpath = "//button[@id = 'exportbtn']")
	WebElement exportButton;

	@FindBy(xpath = "//body[@class]")
	WebElement pageLoad;

	String val;

	String reportTable = "//table[@id='reports']//tbody/tr";
	JavascriptExecutor js = (JavascriptExecutor) driver;

	public void clickExportButton() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(exportButton));
			int counter = 0;
			val = pageLoad.getAttribute("class");
			while (val.equalsIgnoreCase("loading_compliance")) {
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if (counter > 12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			if (driver.findElements(By.xpath(enableExportButton)).size() > 0)
				js.executeScript("arguments[0].click();", exportButton);
			else
				Assert.fail("Export button is diabled as no record is available");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verifyDownloadFile() {
		try {
			// usr = new User();
			int counter = 0;
			boolean dwnld = false;
			do {
				Thread.sleep(5000);
				dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
				counter = counter + 1;
				if (counter > 24)
					Assert.fail("Not able to download file");
			} while (dwnld == false);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

	public void compareDetails() {
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			String uiList[][];
			int counter = 0;
			val = js.executeScript("return document.readyState").toString();
			while (!(val.equalsIgnoreCase("complete"))) {
				val = js.executeScript("return document.readyState").toString();
				counter++;
				if (counter > 12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(reportTable))));
			List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
			List<List<String>> list_UI = new ArrayList<>();
			List<List<String>> list_report = new ArrayList<>();
			File file = new File(NotificationSettings.filePath);
			FileReader filereader = new FileReader(file, StandardCharsets.UTF_8);
			CSVReader csvReader = new CSVReader(filereader);
			List<String[]> header = csvReader.readAll();
			int rowCount = tableRows.size();
			uiList = new String[rowCount][13];
			String reportDetails[][] = new String[header.size() - 2][13];
			for (int i = 1; i <= rowCount; i++) {
				for (int j = 2; j <= 14; j++) {
					String textValue = driver.findElement(By.xpath("(" + reportTable + ")[" + i + "]/td[" + j + "]"))
							.getText();
					System.out.println("textvalue" + textValue);
					// if(textValue.contains("Failed")) {
					// uiList[i-1][j-1] = textValue.toUpperCase();
					// }
					// else {
					uiList[i - 1][j - 2] = textValue;
					// }
				}
			}
			for (String[] ints : uiList) {
				list_UI.add(Arrays.asList(ints));

			}
			System.err.println(header.size());
			for (int i = 1; i <= header.size() - 3; i++) {
				String[] excel = header.get(i + 2);
				System.out.println(i);
				System.out.println(header.get(i + 2).toString());
				System.out.println(Arrays.toString(header.get(i + 2)));
				System.out.println();
				String[] excelValues = excel[0].split(";");
				System.out.println("UI List " + Arrays.toString(list_UI.toArray()));
				for (int j = 0; j <= 12; j++) {
					System.out.println("execlvalues : " + excelValues[j].replace("\"", "").trim());

					reportDetails[i - 1][j] = excelValues[j].replace("\"", "").trim();
				}
			}
			csvReader.close();
			for (String[] ints : reportDetails) {
				list_report.add(Arrays.asList(ints));
			}
			List<List<String>> differences = new ArrayList<>(list_UI);
			differences.removeAll(list_report);
			Assert.assertTrue(differences.size() == 0);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}

//	======================================================

	@FindBy(xpath = "//button[@data-bb-handler='confirm']")
	WebElement Button_Resend;

	@FindBy(xpath = "//input[@id='searchbox_name_email']")
	WebElement Searchfield;

	@FindBy(xpath = "//div[@class='alert alert-success alert-dismissable']")
	WebElement SuccessMessage_AllNotifications;

	public void SearchField() {
		Assert.fail("fsf");
		Searchfield.sendKeys("20221214215710010@yopmail.com");
	}

	public void SuccessMessageAllNotifications() {

		try {
			String SuccessMessage = SuccessMessage_AllNotifications.getText();
			Assert.assertEquals(SuccessMessage, "All notifications have been successfully triggered");
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	@FindBy(xpath = "//table[contains(@id,'reports')]//tbody/tr")
	List<WebElement> RowCount_ReportsStatus;

	public void VerifyTheReportsStatus(String cellValueToCompare, int ColumntoIterate, int ToGetvalueFromcolumn,
			String Status) {
		String value = testUtils.VerifyTheReportsStatus(RowCount_ReportsStatus, cellValueToCompare, ColumntoIterate,
				ToGetvalueFromcolumn);
		// System.out.println( " The value outside is "+value);
		Assert.assertEquals(value, Status);

	}

	public void ClickOnCheckBox(String cellValueToCompare, int ColumntoIterate, int ToGetvalueFromcolumn) {
		testUtils.ClickOnCheckBox(RowCount_ReportsStatus, cellValueToCompare, ColumntoIterate, ToGetvalueFromcolumn);
		// System.out.println( " The value outside is "+value);
	}

	public void VerifyTheReportsStatusAndClickCheckBox(String cellValueToCompare, String Status, int ColumntoIterate,
			int ToGetvalueFromcolumn) {
		// String value =
		// testUtils.VerifyTheReportsStatusAndClickCheckBox(RowCount_ReportsStatus,
		// cellValueToCompare, ColumntoIterate,
		// ToGetvalueFromcolumn, Status );
		testUtils.VerifyAndClickOnCheckBoxReportsStatus(RowCount_AdminNotifications, cellValueToCompare,
				ColumntoIterate, ToGetvalueFromcolumn, Status);
	}

//	------------------------------------------------------------------------------------------------

	@FindBy(xpath = "//div[@id='job_select']//div/button")
	WebElement Button_JobTitle;

	@FindBy(xpath = "//select[@id='job_title_id']//following-sibling::div//a[text()='Select all']")
	WebElement JobTitle_SelectAll;

	@FindBy(xpath = "//select[@id='job_title_id']//following-sibling::div//div/a[text()='Unselect all']")
	WebElement JobTitle_unSelectAll;

	@FindBy(xpath = "//select[@id='group_id']//following-sibling::div/button")
	WebElement Button_Group;
	// button[@type='button']/span[text()='Select options']

	@FindBy(xpath = "//select[@id='group_id']//following-sibling::div//a[text()='Select all']")
	WebElement Group_SelectAll;

	@FindBy(xpath = "//select[@id='group_id']//following-sibling::div//div/a[text()='Unselect all']")
	WebElement Group_UnSelectAll;

	public void clickOnJobTitle() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			Button_JobTitle.click();

		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	public void clickOnJobTitleSelectAll() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			JobTitle_SelectAll.click();

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void clickOnJobTitleUnSelectAll() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			JobTitle_unSelectAll.click();

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void clickOnGroup() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			Button_Group.click();

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void clickOnGroupSelectAll() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			Group_SelectAll.click();

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void clickOnGroupUnSelectAll() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			Group_UnSelectAll.click();

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@FindBy(xpath = "(//button[@value='Search'])[2]")
	WebElement Button_MoreFilter;

	public void SearchButtonMoreFilter() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			Button_MoreFilter.click();

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@FindBy(xpath = "//select[@id='filterSelect_1']//following-sibling::div/button")
	WebElement Button_OrgName;

	@FindBy(xpath = "//select[@id='filterSelect_1']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement OrgNameUnSelectAll;

	@FindBy(xpath = "//select[@id='filterSelect_1']//following-sibling::div//div//a[text()='Select all']")
	WebElement OrgNameSelectAll;

	public void SearchButtonOrgName() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			Button_OrgName.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void SearchButtonUnSelectAll() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			OrgNameUnSelectAll.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void SearchButtonSelectAll() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			OrgNameSelectAll.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@FindBy(xpath = "(//a[@class='card-link notification_log_filter'])[1]")
	WebElement Tab_CourseFilters;
	
	@FindBy (xpath = "(//button[@data-toggle='dropdown'])[2]")
	WebElement Coure_Button;

	public void ClickOnNotiCourseFilters() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			Tab_CourseFilters.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void Coure_Button() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			Coure_Button.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
		
	@FindBy(xpath = "(//a[@class='card-link notification_log_filter'])[1]")
	WebElement Link_CourseFilters;

	@FindBy(xpath = "//select[@id='orgCourseIds']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement courseFilterUnSelectAll;

	@FindBy(xpath = "//select[@id='orgCourseIds']//following-sibling::div/div/a[text()='Select all']")
	WebElement courseFilterSelectAll;

	@FindBy(xpath = "//select[@id='orgCourseIds']//parent::div//div/button")
	WebElement Button_Course;

	public void SelectCourse() {
		try {
			Thread.sleep(1000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			Button_Course.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void clickOnCourseFilters() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 20);
			Link_CourseFilters.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void UnselectAllCourse() {
		try {
			Thread.sleep(1000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			courseFilterUnSelectAll.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void selectAllCourse() {
		try {
			Thread.sleep(1000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			courseFilterSelectAll.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	String JobFilter = "(//select[@id=\"job_title_id\"]//following-sibling::div//ul//label)";

	public void selectMultiJobFilter() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
//		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(JobFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(JobFilter));
		for (int i = 1; i <= statusList.size(); i++) {
			WebElement elem = driver.findElement(By.xpath("(" + JobFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if (flag == false) {
				driver.findElement(By.xpath("(" + JobFilter + "/input)[" + i + "]")).click();
				break;
			}
		}

	}

	String userCourseFilter = "(//select[@id='orgCourseIds']//following-sibling::div//ul//label)";

	@FindBy(xpath = "(//button[text() = 'Search' and not(@id)])[2]")
	WebElement courseFilterSearchButton;

	public void selectMultiUserCourseFilter() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userCourseFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userCourseFilter));
		for (int i = 1; i <= statusList.size(); i++) {
			WebElement elem = driver.findElement(By.xpath("(" + userCourseFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if (flag == false) {
				driver.findElement(By.xpath("(" + userCourseFilter + "/input)[" + i + "]")).click();
				break;
			}
		}

	}

	public void clickOnCourseFilterSearchButton() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(courseFilterSearchButton));
		courseFilterSearchButton.click();
	}

	String GroupFilter = "(//select[@id=\"group_id\"]//following-sibling::div//ul//label)";

	public void selectMultiGroupFilter() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
//		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(JobFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(GroupFilter));
		for (int i = 1; i <= statusList.size(); i++) {
			WebElement elem = driver.findElement(By.xpath("(" + GroupFilter + "/input)[" + i + "]"));
			System.out.println(" elem " + elem);
			boolean flag = elem.isSelected();
			if (flag == false) {
				driver.findElement(By.xpath("(" + GroupFilter + "/input)[" + i + "]")).click();
				break;
			}
		}

	}
	
	
	@FindBy (xpath = "//select[@id='group_id']//following-sibling::div//div//div[@class='ms-search']//input[@placeholder='Search']")
	WebElement SearchGroup;
	
	
	
	public void selectGroupBySearchFilter(String value) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.elementToBeClickable(SearchGroup));
		SearchGroup.sendKeys(value);
//		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(JobFilter + "[1]"))));
		
		driver.findElement(By.xpath("(//*[contains(text(),'"+value+"')])[2]")).click();
	//	driver.findElement(By.xpath("(" + GroupFilter + "/input)[" + 1 + "]")).click();
	}

//	----------------------------------------------------------- Org level ----------------

	// Org level
	@FindBy(xpath = "//button[@data-id='orgLevel']")
	WebElement Button_OrgLevel;

	@FindBy(xpath = "//button[@data-id='orgLevel']//following-sibling::div/ul/li/a/span[@class='text']")
	List<WebElement> DropDown_orgLevel;
	// button[@data-id='orgLevel']//following-sibling::div/ul/li/a

	public void Button_OrgLevel() {

		try {
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			Button_OrgLevel.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void SelectTextFromOrgList(String value) {

		try {
			Thread.sleep(2000);

//			testUtils.selectFromTheList(DropDown_orgLevel, value);
			
			//button[@data-id='orgLevel']//following-sibling::div/ul/li/a/span[contains(text(),'Organization')]
			String dropdownvalue  = "//button[@data-id='orgLevel']//following-sibling::div/ul/li/a/span[contains(text(),'" + value + "')]";
			driver.findElement(By.xpath(dropdownvalue)).click();
			

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	// Notifications Filter
	@FindBy(xpath = "//a[@href='#notification_log_filter']")
	WebElement Link_NotificationFilter;

	@FindBy(xpath = "//select[@id='notificationTitleIds']//following-sibling::div//button")
	WebElement Button_NotificationTitle;

	@FindBy(xpath = "//select[@id='notificationTitleIds']//following-sibling::div//div/ul/li/label//input[contains(@title,'Assignment completed')]")
	List<WebElement> DropDown_notifications;

	// select[@id='notificationTitleIds']//following-sibling::div//div/ul/li/label/input
	@FindBy(xpath = "//select[@id='notificationTitleIds']//following-sibling::div//div/a[text()='Unselect all']")
	WebElement Notifications_UnselectAll;

	@FindBy(xpath = "//select[@id='notificationTitleIds']//following-sibling::div//div/a[text()='Select all']")
	WebElement Notifications_SelectAll;

	@FindBy(xpath = "//*[@id='ms-list-5']//input[@placeholder='Search']")
	WebElement Notificationtitle;

	public void SelectTextFromDropDownNotifications(String value) {

		try {
			Thread.sleep(2000);
			// testUtils.selectFromTheList(DropDown_notifications, value);

			// wait.until(ExpectedConditions.visibilityOf(SFID));
			// SFID.click();
			wait.until(ExpectedConditions.visibilityOf(Notificationtitle));
			Notificationtitle.clear();
			Notificationtitle.sendKeys(value);
			wait.until(ExpectedConditions
					.visibilityOf(driver.findElement(By.xpath("//*[contains(@title,'" + value + "')]"))));
			// *[contains(@title,'3 consecutive failures by student')]
			// *[@title="10001"]
			driver.findElement(By.xpath("//*[contains(@title,'" + value + "')]")).click();
			// Notificationtitle.click();

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	// Delivery Status
	@FindBy(xpath = "//select[@id='deliveryStatusIds']//following-sibling::div/button")
	WebElement Button_DeliveryStatus;

	@FindBy(xpath = "//select[@id='deliveryStatusIds']//following-sibling::div//div/ul/li")
	List<WebElement> DropDown_DeliveryStatus;

	@FindBy(xpath = "//select[@id='deliveryStatusIds']//following-sibling::div//div//a[text()='Unselect all']")
	WebElement DeliveryStatus_UnselectAll;

	@FindBy(xpath = "//select[@id='deliveryStatusIds']//following-sibling::div//div/a[text()='Select all']")
	WebElement DeliveryStatus_SelectAll;

	public void SelectTextFromDropDownDeliveryStatus(String value) {

		try {
			Thread.sleep(2000);

			// select[@id='deliveryStatusIds']//following-sibling::div//div/ul/li/label/input[contains(@title,"Delivered")]
			String DropDownValue = "//select[@id='deliveryStatusIds']//following-sibling::div//div/ul/li/label/input[contains(@title,'"
					+ value + "')]";
			System.out.println(" DropDownValue " + DropDownValue);
			driver.findElement(By.xpath(DropDownValue)).click();

			// testUtils.selectFromTheList(DropDownValue, value);

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void Link_Notification() {

		try {
			Thread.sleep(1000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			Link_NotificationFilter.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void Button_NotificationTitle() {

		try {
			Thread.sleep(1000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			Button_NotificationTitle.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void NotificationSelectAll() {

		try {
			Thread.sleep(1000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			Notifications_SelectAll.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void NotificationUnSelectAll() {

		try {
			Thread.sleep(1000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			Notifications_UnselectAll.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void Button_DeliveryStatus() {

		try {
			Thread.sleep(1000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			Button_DeliveryStatus.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void DeliveryStatus_SelectAll() {

		try {
			Thread.sleep(1000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			DeliveryStatus_SelectAll.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void DeliveryStatus_UnselectAll() {

		try {
			Thread.sleep(1000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			DeliveryStatus_UnselectAll.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@FindBy(xpath = "(//button[@class='btn btn-default white_btn search_submit'])[2]")
	WebElement Button_NotificationSearch;

	public void Button_NotificationSearch() {

		try {
			Thread.sleep(1000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			Button_NotificationSearch.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@FindBy(xpath = "//table[@id=\"learnerTableList\"]/tbody/tr[@role=\"row\"][")
	WebElement Row_learnerTableList;
//	1]/td[9]
	String value = "//table[@id='learnerTableList']/tbody/tr[@role='row'][";

	// table[@aria-describedby="learnerTableList_info"]//tbody/tr[@role='row'][1]/td[9]

	public void Row_learnerTableList(int rowvalue, int columnValue) {
		try {
			Thread.sleep(2000);
			String columnvalue = value + rowvalue + "]/td[" + columnValue + "]";
			driver.findElement(By.xpath(columnvalue));
			System.out.println("columnvalue " + columnvalue);
			driver.findElement(By.xpath("//div[@class='dropdown open']"));
			// Searchbox_NameEmail.clear();
			// Searchbox_NameEmail.sendKeys(value);
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	@FindBy(xpath = "//table[@aria-describedby='learnerTableList_info']//div[@class='dropdown open']//ul/li/a[contains(text(),'Set as Inactive')]")
//	List<WebElement> DropDownvalues_user;
	WebElement DropDownvalues_user;

	public void DropDownValue(String value) {
		try {
			Thread.sleep(2000);
			DropDownvalues_user.click();
			// TestUtils.selectFromTheList(DropDownvalues_user, value);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@FindBy(xpath = "//button[@id='resend']")
	WebElement ButtonResend;

	@FindBy(xpath = "//div[@class='dataTables_scrollBody']//table//tbody//tr//td//input[@type='checkbox']")
	WebElement Checkbox_Disabled;

	public void ResendButtonDisabled() {

		try {

			String value = ButtonResend.getAttribute("disabled");
			System.out.println(" disabled resend button value " + value);
			Assert.assertTrue(value.contains("true"));

			boolean checkbox = Checkbox_Disabled.isEnabled();
			Assert.assertFalse(checkbox);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

//	(//button[@value="Search"])[4]
	
	
	@FindBy (xpath = "(//a[text()='Clear Search'])[4]")
	WebElement NotificationClearSearch;
	
	
	

	public void NotificationSearchBtn() {
		try {
			
			Thread.sleep(2000);
			wait.until(ExpectedConditions.elementToBeClickable(Button_Search));

			Button_Search.click();
//			NotificationClearSearch.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	public void NotificationClearSearch() {
		try {
			
			Thread.sleep(2000);
			NotificationClearSearch.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@FindBy (xpath = "(//a[text()='Clear Search'])[2]")
	WebElement MoreFilterButtonClearSearch;
	
	
	public void MoreFilterButtonClearSearch() {
		try {
			
			Thread.sleep(2000);
			MoreFilterButtonClearSearch.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@FindBy (xpath = "//select[@id='statusFilter']//following-sibling::div//button")
	WebElement UserStatus_Button;
	
	public void userStatus() {
		try {
			Thread.sleep(2000);
			UserStatus_Button.click();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	@FindBy (xpath = "//*[@id='ms-list-3']/div/div/input")
	WebElement UserStatus_Search;
	
	//*[@id="ms-list-3"]/button
	
	@FindBy(xpath = "//select[@id='statusFilter']//following-sibling::div//div/a[text()='Unselect all']")
	WebElement UserStatus_UnselectAll;
	
	@FindBy(xpath = "//select[@id='statusFilter']//following-sibling::div//div/a[text()='Select all']")
	WebElement UserStatus_SelectAll;
	
	public void SearchStatusValue(String value) {
		try {
			UserStatus_Search.sendKeys(value);
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}
	
	public void UserStatus_UnselectAll() {
		try {
			UserStatus_UnselectAll.click();
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}
	
	public void UserStatus_SelectAll() {
		try {
			UserStatus_SelectAll.click();
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}
}
