package com.qa.pages;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.util.TestBase;

import groovyjarjarantlr4.v4.runtime.tree.xpath.XPath;
import junit.framework.Assert;

public class UserManagement extends TestBase
{	
	@FindBy(xpath = "//input[@name = 'email']")
	WebElement emailSearchBox;
	
	@FindBy(xpath = "//button[@type = 'submit']")
	WebElement searchButton;
	
	@FindBy(xpath = "//button[@id= 'searchbtn']")
	WebElement searchBtn;
	
	@FindBy(xpath = "(//a[@title = 'Proxy user'])[1]")
	WebElement proxyUser;

	@FindBy(xpath = "//li[@id = 'menu_dashboard']")
	WebElement dashboard;
	
	@FindBy(xpath = "//li[@id = 'menu_dashboard']")
	WebElement clearSearch;
	
	@FindBy(xpath = "//a[contains(text(),'Manage Courses')]")
	WebElement managecoursesButton;

	@FindBy(xpath = "//a[text()='Add Course']")
	WebElement addCourse;

	@FindBy(xpath = "//*[@id=\"adduserlicense\"]/div[3]/div[2]/input")
	WebElement submit;
	
	@FindBy(xpath = "//*[@id=\"successbox\"]")
	WebElement successmsg;
	
	
	@FindBy(xpath = "(//tbody//td[1][contains(text(),'Online')])/following::a[3]")
	WebElement TopicsButton;

	@FindBy(xpath = "//a[contains(text(),'Set as Completed')]")
	WebElement setascompleted;
	
	@FindBy(xpath = "//textarea[@id='remeidation_review']")
	WebElement remediationreviewinput;

	@FindBy(xpath = "//*[@id='course']")
	WebElement course;

	
	@FindBy(xpath = "//input[@type='submit']")
	WebElement submitbutton;
	
	@FindBy(xpath = "(//a[@title = 'Delete user'])")
	WebElement deleteUser;
	
	@FindBy(xpath = "//a[@data-target = '#confirm-delete-account']")
	WebElement permanentDeleteUserAccount;
	
	@FindBy(xpath = "(//a[text() = 'Delete'])[2]")
	WebElement confirmDelete;

	
	@FindBy(xpath = "//*[@id='instructor-table']/tbody/tr/td")
	WebElement norecordFound;

	JavascriptExecutor js = (JavascriptExecutor)driver;
	
	String val;
	@FindBy(xpath = "//body[@class]")
	WebElement pageLoad;

	public UserManagement() 
	{
		PageFactory.initElements(driver, this);
	}

	public void searchByEmail(String email)
	{
		WebDriverWait wait = new WebDriverWait(driver, 60);
		
		wait.until(ExpectedConditions.visibilityOf(emailSearchBox));
		emailSearchBox.click();		
		
		emailSearchBox.clear();
		emailSearchBox.sendKeys(email);
	}
	
	public void validateTable(String text) throws InterruptedException
	{
		
			Thread.sleep(5000);
			String[] rowvalue=text.split(",");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,1000)");
			for(int i=0;i<rowvalue.length;i++)
			{
				
//				js.executeScript("arguments[0].scrollIntoView();",select);
				if(rowvalue[i].contains("Uid"))
				{
					Assert.assertEquals(User.userEmail.toLowerCase(), driver.findElement(By.xpath("//*[@id='instructor-table']//td[text()='"+User.userEmail.toLowerCase()+"']")).getText().toLowerCase());
						
				}
				else if(rowvalue[i].contains("Email"))
				{
					Assert.assertEquals(User.userEmail, driver.findElement(By.xpath("//*[@id='instructor-table']//td[text()='"+User.userEmail+"']")).getText());
						
				}
				else if(rowvalue[i].contains("Orid"))
				{
					Assert.assertEquals( TestBase.prop.getProperty("orgName"), driver.findElement(By.xpath("//*[@id='instructor-table']//td[text()='"+ TestBase.prop.getProperty("orgName")+"']")).getText());
						
				}
				else
				Assert.assertEquals(rowvalue[i], driver.findElement(By.xpath("//*[@id='instructor-table']//td[text()='"+rowvalue[i]+"']")).getText());
			}
			
			
		
	}

	public void clickSearch()
	{
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOf(searchButton));
		searchButton.click();
	}
	public void clickSearch(String btn)
	{
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//button[@value='"+btn+"']"))));
		driver.findElement(By.xpath("//button[@value='"+btn+"']")).click();
	}
	public void clickSearchBtn()
	{
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOf(searchBtn));
		
		js.executeScript("arguments[0].click();", searchBtn);
		
	
	}

	
	public void selectProxyUser()
	{
		
		String pageValue = js.executeScript("return document.readyState").toString();
		int m=0;
		while(!(pageValue.equalsIgnoreCase("complete")))
		{
			pageValue = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			
			m++;
		}
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{
			
		}
		proxyUser.click();
	}

	public void endUser_Norecordsfound()
	{
		
		String pageValue = js.executeScript("return document.readyState").toString();
		int m=0;
		while(!(pageValue.equalsIgnoreCase("complete")))
		{
			pageValue = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			
			m++;
		}
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{
			
		}
//		norecordFound.click();
		Assert.assertEquals("No records found", norecordFound.getText());
	}
	
	
	public void switchTab()
	{
		String currentHandle= driver.getWindowHandle();
		Set<String> handles=driver.getWindowHandles();
		for(int i=0;i<20;i++)
		{
		if(handles.size() == 1)
		{
			handles=driver.getWindowHandles();
			
		}
		else
			break;
		}
		int m=0;
		for(String actual: handles)
        {
            
         if(!actual.equalsIgnoreCase(currentHandle))
             driver.switchTo().window(actual);
         else
         {
        	 if(m==10)
        		 break;
        	 m++;
         	 
         }
        }
		System.out.println(driver.getCurrentUrl());
	}

	public void navigateDashboard()
	{
		try {
//		WebDriverWait wait = new WebDriverWait(driver, 10);
//		wait.until(ExpectedConditions.visibilityOf(dashboard));
//		dashboard.click();
			
			
		js.executeScript("arguments[0].click();", dashboard);
		
		if(!driver.getCurrentUrl().contains("admin/dashboard"))
		{
			driver.navigate().to(prop.getProperty("url"+prop.getProperty("environment"))+"/dashboard");
		//	dashboard.click();
		}
		}
		catch(Exception e)
		{
		e.printStackTrace();
		}
	}
	public void clickManagecoursesbutton()
	{
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.visibilityOf(managecoursesButton));
	managecoursesButton.click();
	}
	
	public void clickaddcoursesbutton()
	{
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.visibilityOf(addCourse));
	addCourse.click();
	
	}
	
	public void clickTopicsbutton()
	{
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.visibilityOf(TopicsButton));
	TopicsButton.click();
	}
	
	public void clickTopicsbutton(String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
		course=course.replace("Â", "");
		
	
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//tbody//td[contains(text(),'"+course+"')])/following::a[3]"))));
	driver.findElement(By.xpath("(//tbody//td[contains(text(),'"+course+"')])/following::a[3]")).click();
	}
	
	public void selectCourse(String coursename)
	{
		if(courseListName.containsKey(coursename+"Option"))
			coursename=courseListName.get(coursename+"Option").toString();
		
	WebDriverWait wait = new WebDriverWait(driver, 60);

	Select deflang = new Select(course);
	deflang.selectByVisibleText(coursename);
	course.click();
wait.until(ExpectedConditions.visibilityOf(submit));
	
	submit.click();
	
	if(successmsg.isDisplayed())
	{
		System.out.println("Add Course SuccessFull");
	}
	}
	
	public void clicksetascompleted()
	{
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.visibilityOf(setascompleted));
	setascompleted.click();
	}
	public void remediationreview(String message)
	{
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.visibilityOf(remediationreviewinput));
	remediationreviewinput.sendKeys(message);
	submitbutton.click();
	}
	public void clickClearSearch()
	{
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOf(clearSearch));
		clearSearch.click();
	}

	public void closeOtherTab()
	{
		String currentHandle= driver.getWindowHandle();
		Set<String> handles=driver.getWindowHandles();
		for(int i=0;i<20;i++)
		{
		if(handles.size() == 1)
		{
			handles=driver.getWindowHandles();
		}
		}
		
		for(String actual: handles)
        {
            int m=0;
         if(!actual.equalsIgnoreCase(currentHandle))
             driver.switchTo().window(actual).close();
         else
         {
        	 if(m==20)
        		 break;
        		 m++;
         }
        }
        driver.switchTo().window(currentHandle);
	}

	public void deleteDearchedUser()
	{
		try {
		JavascriptExecutor js = (JavascriptExecutor)driver;
		String pageValue = js.executeScript("return document.readyState").toString();
		int counter = 0;
		while(!(pageValue.equalsIgnoreCase("complete")))
		{
			pageValue = js.executeScript("return document.readyState").toString();
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load page after waiting for 1 minute");
		}
		js.executeScript("arguments[0].click();", deleteUser);	
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOf(permanentDeleteUserAccount));
		permanentDeleteUserAccount.click();
		wait.until(ExpectedConditions.visibilityOf(confirmDelete));
		confirmDelete.click();
		}
		catch(Exception e) {
			Assert.fail("Unable to delete");
		}
	}
}
