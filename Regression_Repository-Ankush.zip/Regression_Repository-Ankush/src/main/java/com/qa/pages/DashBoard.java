package com.qa.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.qa.util.TestBase;

public class DashBoard extends TestBase
{
	@FindBy(xpath = "//div[text()='Organizations']")
	WebElement orgPanel;
	
	@FindBy(xpath = "//li[@id = 'menu_user']/a")
	WebElement userMgmtDrop;
	
	@FindBy(xpath = "//ul[@class = 'dropdown-menu']//a[text() = 'User Management']")
	WebElement userManagementLink;
	
	@FindBy(xpath = "//li[@id = 'menu_course']/a")
	WebElement courseMgmtDrop;
	
	@FindBy(xpath = "//ul[@class = 'dropdown-menu']//a[text() = 'Course Management']")
	WebElement courseManagementLink;
	
	@FindBy(xpath = "//ul[@class = 'dropdown-menu']//a[text() = 'Insights Management']")
	WebElement insightManagementLink;
	
	@FindBy(xpath = "(//li[@id = 'license']//a)[1]")
	WebElement usercourseManagementLink;

	@FindBy(xpath = "//ul[@class = 'dropdown-menu']//a[text() = 'Manage User Course']")
	WebElement manageusercourseLink;

	@FindBy(xpath = "//div[text() = 'Number of Cycles']/following-sibling::div/input")
	WebElement courseManagementCycleNumber;
	
	
	public static int cycleNumber; 
	

	JavascriptExecutor executor = (JavascriptExecutor)driver;
	
	
	//Initialize Page objects
		public DashBoard() 
		{
			PageFactory.initElements(driver, this);
		}
		
		public void selectOrgpanel()
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(orgPanel));
			orgPanel.click();
		}
		
		public void clickUserMgmtDropDown()
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userMgmtDrop));
			userMgmtDrop.click();
		}

		public void waitfor1min(int min)
		{
			try {
				Thread.sleep(60000*min);
				
			} catch (Exception e) {
				// TODO: handle exception
			}
		}

		public void clickUserManagementOption()
		{
			wait.until(ExpectedConditions.visibilityOf(userManagementLink));
			userManagementLink.click();
		}

		public void clickCourseMgmtDropDown()
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(courseMgmtDrop));
			courseMgmtDrop.click();
			//executor.executeScript("arguments[0].click();", courseMgmtDrop);
		}

		public void clickCourseManagementOption()
		{
//			WebDriverWait wait = new WebDriverWait(driver, 30);
//			wait.until(ExpectedConditions.visibilityOf(courseManagementLink));
//			courseManagementLink.click();
			executor.executeScript("arguments[0].click();", courseManagementLink);
		}
		
		public void clickInsightManagementOption()
		{
//			WebDriverWait wait = new WebDriverWait(driver, 30);
//			wait.until(ExpectedConditions.visibilityOf(insightManagementLink));
//			insightManagementLink.click();
			executor.executeScript("arguments[0].click();", insightManagementLink);
		}
		public void clickUsercourseMgmtDropDown()
		{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(usercourseManagementLink));
		usercourseManagementLink.click();
		}
		public void clickManageusercourseOption()
		{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(manageusercourseLink));
		manageusercourseLink.click();
		}
		
		public void getNumberOfCycle()
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(courseManagementCycleNumber));
			cycleNumber = Integer.parseInt(courseManagementCycleNumber.getAttribute("value"));
			System.out.println("The number of cycles displayed in course mgmt page is " + cycleNumber);
		}


}
