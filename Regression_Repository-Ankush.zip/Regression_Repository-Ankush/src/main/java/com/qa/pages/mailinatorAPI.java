package com.qa.pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.manybrain.mailinator.client.MailinatorClient;
import com.manybrain.mailinator.client.message.GetInboxRequest;
import com.manybrain.mailinator.client.message.GetMessageRequest;
import com.manybrain.mailinator.client.message.Inbox;
import com.manybrain.mailinator.client.message.Message;
import com.manybrain.mailinator.client.message.Sort;
import com.qa.util.TestBase;

public class mailinatorAPI extends TestBase{

	MailinatorClient mailinatorClient = new MailinatorClient(prop.getProperty("APIToken"));

	String getmessageId(String subject,String validate)
	{
		String  messageID=null;
		Inbox inbox = mailinatorClient.request(
				GetInboxRequest.builder()
				.domain(prop.getProperty("userDomain").replace("@", ""))
				.limit(20)
				.skip(0)
				.sort(Sort.DESC)
				.build());
		List<Message> messages = inbox.getMsgs();

		for (Message m : messages) {
			System.out.println("Email id "+m.getTo());
			System.out.println("Message id "+m.getId());
			System.out.println("User Email "+User.userEmail);
			System.out.println("Subject id "+ m.getSubject());
			
			if(User.userEmail.toLowerCase().contains(m.getTo())&& m.getSubject().contains(subject))
			{
				messageID =m.getId();
				System.out.println(messageID);
				break;
			}
		}

		if(messageID==null&&(!validate.contains("validate if not existing")))
		{
			Assert.fail("Mail is not found "+inbox.getMsgs());
		}
		return messageID;
	}
	String links;
	void validatemail(String validate,String  subject)
	{
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{
			
		}
		String messageid=getmessageId(subject,validate);

		System.out.println(messageid);
		if(!validate.contains("validate if not existing"))
		{
		Message m = mailinatorClient.request(new GetMessageRequest(
				prop.getProperty("userDomain").replace("@", ""), 
				messageid.split("-")[0], 
				messageid));
		System.out.println("Mail body: "+m.getParts().get(0).getBody());
		
		if(subject.contains("Account created successfully.")||subject.contains("Forgot Password")||subject.contains("Email Updated successfully."))
		links=m.getParts().get(0).getBody().split("<a href=\"")[1].split("\">click here</a>")[0];
		}
	}

	
	public void validatemailbody(String validate,String  subject)
	{
		if(AssignmentReport.checkifParmeterAvailable(subject))
			subject=AssignmentReport.getParmeterAvailable(subject);
     
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{
			
		}
		String messageid=getmessageId(subject,validate);

		System.out.println(messageid);
		Message m = mailinatorClient.request(new GetMessageRequest(
				prop.getProperty("userDomain").replace("@", ""), 
				messageid.split("-")[0], 
				messageid));
		System.out.println("Mail body: "+m.getParts().get(0).getBody());
	    
		String body=m.getParts().get(0).getBody();
		
		Boolean flag=false;
		String[] contentRow = body.split("\n");
		for(int i = 0; i < contentRow.length; i++)
		{
			System.out.println(contentRow[i]);
			if(contentRow[i].contains(NotificationSettings.date))
			{
				flag = true;
				break;
			}
		}
		Assert.assertTrue(flag);
	}

	void navigatechangePassword()
	{
		driver.navigate().to(links);
		KeyClock key=new KeyClock();
		key.setNewPwd();
	}

	public void validateifmail(String validate,String subject) throws InterruptedException
	{

		if(AssignmentReport.checkifParmeterAvailable(subject))
			subject=AssignmentReport.getParmeterAvailable(subject);
     
		switch(validate.toLowerCase())
		{
		case "change password": Thread.sleep(10000);
		validatemail(validate.toLowerCase(),subject);
		navigatechangePassword();
		break;
		case "validate if existing":validatemail(validate.toLowerCase(),subject);
		break;
		case "validate if not existing":validatemail(validate.toLowerCase(),subject);
		break;

		}

	}
	
	
	public void clickOnPwdChangeLink_Admin(String validate,String subject) throws InterruptedException
	{

		if(AssignmentReport.checkifParmeterAvailable(subject))
			subject=AssignmentReport.getParmeterAvailable(subject);
     
		validatemail(validate.toLowerCase(),subject);
		driver.navigate().to(links);
	
	}


	public void validatethemailcount(String subject,int count)
	{
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{
			
		}
		String  messageID=null;
		int mailcount=0;
		Inbox inbox = mailinatorClient.request(
				GetInboxRequest.builder()
				.domain(prop.getProperty("userDomain").replace("@", ""))
				.limit(20)
				.skip(0)
				.sort(Sort.DESC)
				.build());
		List<Message> messages = inbox.getMsgs();

		for (Message m : messages) {
			System.out.println("Email id "+m.getTo());
			System.out.println("Message id "+m.getId());
//			System.out.println("Body "+m.getParts().get(0).getBody());
			System.out.println("User Email "+User.userEmail);
			System.out.println("Subject id "+ m.getSubject());
			
			if(User.userEmail.toLowerCase().contains(m.getTo())&& m.getSubject().contains(subject))
			{
				messageID =m.getId();
				mailcount++;
			}
		}

		
		if(mailcount!=count)
		{
			Assert.fail("Mail is not found "+inbox.getMsgs());
		}
		
	}

	public void validatethnoemailisTriggred()
	{
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{
			
		}
		String  messageID=null;
		int mailcount=0;
		Inbox inbox = mailinatorClient.request(
				GetInboxRequest.builder()
				.domain(prop.getProperty("userDomain").replace("@", ""))
				.limit(20)
				.skip(0)
				.sort(Sort.DESC)
				.build());
		List<Message> messages = inbox.getMsgs();

		for (Message m : messages) {
			System.out.println("Email id "+m.getTo());
			System.out.println("Message id "+m.getId());
//			System.out.println("Body "+m.getParts().get(0).getBody());
			System.out.println("User Email "+User.userEmail);
			System.out.println("Subject id "+ m.getSubject());
			
			if(User.userEmail.toLowerCase().contains(m.getTo()))
			{
				messageID =m.getId();
				mailcount++;
			}
		}

		
		if(mailcount!=0)
		{
			Assert.fail("Mail is  found "+inbox.getMsgs());
		}
		
	}
	public String getmailsubject()
	{
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{
			
		}
		String  messageID=null;
		String mailsubject=null;
		Inbox inbox = mailinatorClient.request(
				GetInboxRequest.builder()
				.domain(prop.getProperty("userDomain").replace("@", ""))
				.limit(20)
				.skip(0)
				.sort(Sort.DESC)
				.build());
		List<Message> messages = inbox.getMsgs();

		for (Message m : messages) {
			System.out.println("Email id "+m.getTo());
			System.out.println("Message id "+m.getId());
			System.out.println("User Email "+User.userEmail);
			System.out.println("Subject id "+ m.getSubject());
			
			if( User.userEmail.toLowerCase().contains(m.getTo()+prop.getProperty("userDomain")))
			{
				if(mailsubject==null)
				mailsubject=m.getSubject();
				else
				mailsubject =mailsubject+","+m.getSubject();
			}
		}

		if(mailsubject==null)
		{
			Assert.fail("Mails not found "+inbox.getMsgs());
		}
		return mailsubject;
	}

}
