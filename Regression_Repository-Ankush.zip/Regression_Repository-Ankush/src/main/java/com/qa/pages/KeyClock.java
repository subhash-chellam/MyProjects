package com.qa.pages;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.python.modules.thread.thread;

import com.mysql.cj.jdbc.Driver;
import com.qa.util.TestBase;

import junit.framework.Assert;

public class KeyClock extends TestBase
{	
	@FindBy(xpath = "//input[@id = 'login']")
	WebElement searchEmailText;
	@FindBy(xpath = "//div[text() = 'This inbox is empty']")
	WebElement emptyInbox;
	@FindBy(xpath = "//div[text() = 'Assignment completed']")
	WebElement yopmailAssignmentCompleted;
	
	@FindBy(xpath = "//div[text() = 'Unit Observer access has been granted to the LMS dashboard']")
	WebElement yopmailUnitObserverCreated;
	
	@FindBy(xpath = "//button[@title]")
	WebElement searchEmailButton;
	
	@FindBy(xpath = "//iframe[@id = 'ifmail']")
	WebElement frame;
	
	@FindBy(xpath = "//a[text() = 'click here']")
	WebElement pwdLink;
	
	@FindBy(xpath = "//input[@name = 'password']")
	WebElement enterNewPwd;
	
	String accountCreationNotification = "//div[text() = 'Account created successfully.']";
	
	@FindBy(xpath = "//div[text() = 'Unit Admin access has been granted to the LMS dashboard']")
	WebElement yopmailUnitAdminCreated;
	
	@FindBy(xpath = "//div[text() = 'New assignment available']")
	WebElement yopmailAssignmentAvailable;

	
	@FindBy(xpath = "//*[@id='onetrust-accept-btn-handler']")
	WebElement acceptBtn;
	
	@FindBy(xpath = "//input[@name = 'confirmpassword']")
	WebElement confirmPwd;

	@FindBy(xpath = "//input[@name = 'savedata']")
	WebElement createPwd;
	
	@FindBy(xpath = "//a[@class = 'returnHome ']")
	WebElement returnHome;
	
	@FindBy(xpath = "(//a[@aria-label = 'Login'])[2]")
	WebElement subDomainHomeLogin;
	
	@FindBy(xpath = "//a[text()='Login']")
	WebElement subDomainHomeLoginADFS;
	
	
	@FindBy(xpath = "(//input[@name = 'username'])[2]")
	WebElement subDomainUserId1;
	
	 
	@FindBy(xpath = "//*[@id='gigya-login-form']//div[@role='alert']")
	WebElement errorMsg;
	
	@FindBy(xpath = "(//input[@name = 'password'])[2]")
	WebElement subDomainPwd1;
	
	@FindBy(xpath = "(//input[@type = 'submit'])[2]")
	WebElement subDomainSignIn1;
	
	@FindBy(xpath = "//input[@name = 'username']")
	WebElement subDomainUserId;
	
	@FindBy(xpath = "//input[@name = 'password']")
	WebElement subDomainPwd;
	
	@FindBy(xpath = "//*[@id='side_menu']/li//a[text()='Log Out']")
	WebElement loggout;
	
	

	@FindBy(xpath = "//*[@id='header']//a[text()=' Login']")
	WebElement Login;
	
	@FindBy(xpath = "//*[@id='userNameInput']")
	WebElement subDomainUserIdADFS;
	
	@FindBy(xpath = "//*[@id='passwordInput']")
	WebElement subDomainPwdADFS;
	
	
	@FindBy(xpath = "//*[@name=\"username\" and @id=\"gigya-input-text\"]")
	WebElement subDomainUserstudent;
	
	@FindBy(xpath = "(//*[@name=\"password\"])[2]")
	WebElement subDomainPasswordstudent;
	
	@FindBy(xpath = "//button[@type = 'submit']")
	WebElement subDomainSignIn;

	@FindBy(xpath = "//*[@id='submitButton']")
	WebElement subDomainSignInADFS;

	@FindBy(xpath = "//span[contains(text(),'Admin')]")
	WebElement subDomainAdminRole;
	
	@FindBy(xpath = "//span[contains(text(),'Observer')]")
	WebElement subDomainObserverRole;
	
	@FindBy(xpath = "//button[text() = 'Accept']")
	WebElement subDomainFederalPopupAccept;
	
	
	
	@FindBy(xpath = "//*[@id='exampleModal']//div[@class='modal-body']")
	WebElement subDomainFederalPopupText;
	
	@FindBy(xpath = "//*[@id='exampleModal']//h5[@id='exampleModalLabel']")
	WebElement subDomainFederalPopupHeader;
	
	@FindBy(xpath = "//*[@id=\"declineid\"]")
	WebElement subDomainFederalPopupdecline;
	
	
	@FindBy(xpath = "//*[text() = 'Menu']")
	WebElement subDomainMenu;
	
	@FindBy(xpath = "//*[text() = 'Menu']")
	WebElement subDomainLogout;
	
	@FindBy(xpath = "//div[text() = 'Account created successfully.']")
	WebElement yopmailAccountCreated;

	@FindBy(xpath = "//div[text() = 'Email Updated successfully.']")
	WebElement yopmailUpdatedAccountCreated;

	
	@FindBy(xpath = "//div[text() = 'Email Updated Successfully")
	WebElement yopmailEmailUpdated;
	
	@FindBy(xpath = "//div[@class = 'bname']")
	WebElement emailLogin;
	
	@FindBy(xpath = "//*[text()='Home']")
	WebElement homeLink;
	
	@FindBy(xpath = "//*[@id='mail']")
	WebElement mail;
	@FindBy(xpath = "//div[text() = 'Unit Admin access has been granted to the Enterprise dashboard']")
	WebElement yopmailUnitAdminCreatedForCTC;
	
	@FindBy(xpath = "//div[text() = 'Unit Observer access has been granted to the Enterprise dashboard']")
	WebElement yopmailUnitObserverCreatedForCTC;
	
	
	LoginPage login;
	
	public static String pwd;
	
	public KeyClock() 
	{
		PageFactory.initElements(driver, this);
	}
	
	public void navigateYopmail()
	{
		driver.get("https://www.yopmail.com");
	}
	
	public void clickOnPwdChangeLink()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(searchEmailText));
		searchEmailText.click();
		searchEmailText.clear();
		System.out.println(User.userEmail);
		for(int i=0;i<User.userEmail.length();i++)
		{
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				// TODO: handle exception
			}
			searchEmailText.sendKeys(String.valueOf(User.userEmail.charAt(i)));
		}
		
		searchEmailButton.click();
		wait.until(ExpectedConditions.visibilityOf(emailLogin));
		String user = emailLogin.getText().trim();
		while(!(User.userEmail.toLowerCase().contains(user)))
		{
			wait.until(ExpectedConditions.visibilityOf(homeLink));
			homeLink.click();
			wait.until(ExpectedConditions.visibilityOf(searchEmailText));
			searchEmailText.clear();
			searchEmailText.sendKeys(User.userEmail);
		}
		try {
			wait.until(ExpectedConditions.visibilityOf(frame));
			driver.switchTo().frame("ifinbox");
			wait.until(ExpectedConditions.visibilityOf(yopmailAccountCreated));
			yopmailAccountCreated.click();
			driver.switchTo().defaultContent();
		}
		catch(Exception e)
		{
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOf(frame));
			driver.switchTo().frame("ifinbox");
			wait.until(ExpectedConditions.visibilityOf(yopmailAccountCreated));
			yopmailAccountCreated.click();
			driver.switchTo().defaultContent();
		}
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifmail");
		wait.until(ExpectedConditions.visibilityOf(pwdLink));
		pwdLink.click();
		driver.switchTo().defaultContent();
	}
	public void clickOnPwdChange()
	{
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifmail");
		wait.until(ExpectedConditions.visibilityOf(pwdLink));
		pwdLink.click();
		driver.switchTo().defaultContent();
	}

	public void setNewPwd()
	{
		
		
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		date = date.replace(" ", "").replace(":", "").replace("-", "").substring(0, 10);
		pwd = "Pwd@" + date;
		System.out.println(pwd);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(enterNewPwd));
		enterNewPwd.click();
		enterNewPwd.sendKeys(pwd);
		confirmPwd.click();
		confirmPwd.sendKeys(pwd);
		try
		{
			Thread.sleep(5000);
			acceptBtn.click();
		}
		catch(Exception e)
		{
			
		}
		createPwd.click();
		
//		wait.until(ExpectedConditions.visibilityOf(returnHome));
		
	}
	
	public void setNewPwd(String flage)
	{
		
		
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		date = date.replace(" ", "").replace(":", "").replace("-", "").substring(0, 10);
		pwd = "Pwd@" + date;
		System.out.println(pwd);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(enterNewPwd));
		enterNewPwd.click();
		enterNewPwd.sendKeys(pwd);
		confirmPwd.click();
		confirmPwd.sendKeys(pwd);
		try
		{
			Thread.sleep(5000);
			acceptBtn.click();
		}
		catch(Exception e)
		{
			
		}
		createPwd.click();
		
		if(flage.contains("yes"))
		{
			OrganizationHome orgHome=new OrganizationHome();
			orgHome.errormsg("New password must not be the same as the last 10 passwords");
		}
//		wait.until(ExpectedConditions.visibilityOf(returnHome));
		
	}
	public void setNewPwd2()
	{
		
		
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		date = date.replace(" ", "").replace(":", "").replace("-", "").substring(0, 10);
		pwd = String.valueOf(generatePassword(15));
		System.out.println(pwd);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(enterNewPwd));
		enterNewPwd.click();
		enterNewPwd.sendKeys(pwd);
		confirmPwd.click();
		confirmPwd.sendKeys(pwd);
		try
		{
			Thread.sleep(5000);
			acceptBtn.click();
		}
		catch(Exception e)
		{
			
		}
		createPwd.click();
		
//		wait.until(ExpectedConditions.visibilityOf(returnHome));
		
	}
	
	 private static char[] generatePassword(int length) {
	      String capitalCaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	      String lowerCaseLetters = "abcdefghijklmnopqrstuvwxyz";
	      String specialCharacters = "!@#$";
	      String numbers = "1234567890";
	      String combinedChars = capitalCaseLetters + lowerCaseLetters + specialCharacters + numbers;
	      Random random = new Random();
	      char[] password = new char[length];

	      password[0] = lowerCaseLetters.charAt(random.nextInt(lowerCaseLetters.length()));
	      password[1] = capitalCaseLetters.charAt(random.nextInt(capitalCaseLetters.length()));
	      password[2] = specialCharacters.charAt(random.nextInt(specialCharacters.length()));
	      password[3] = numbers.charAt(random.nextInt(numbers.length()));
	   
	      for(int i = 4; i< length ; i++) {
	         password[i] = combinedChars.charAt(random.nextInt(combinedChars.length()));
	      }
	      return password;
	   }
	
	
	
	public void checkinstruction(String instruction)
	{
		
		try
		{
			Thread.sleep(2000);
			acceptBtn.click();
		}
		catch(Exception e)
		{
			
		}
		
		
		Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"validation-info\"]/span[contains(text(),'"+instruction+"')]")).getText(), instruction);
//		wait.until(ExpectedConditions.visibilityOf(returnHome));
		
	}
	public void validatebody(String data)
	{
		
		try
		{
			driver.switchTo().defaultContent();
			Thread.sleep(5000);
			driver.switchTo().frame("ifmail");
//			System.out.println(driver.findElement(By.xpath("//*[@id=\"mail\"]")).getText());
			if(data.contains("Orgid"))
			{
				data=data.replace("Orgid", TestBase.prop.getProperty("orgName"));
				
			}
			
			System.out.println(data);
			if(!(mail.getText().contains(data)))
	       	Assert.fail("Mail Body doesnt match");;
		}
		catch(Exception e)
		{
			driver.findElement(By.xpath("//*[@id=\"mail\"]/div/p[contains(text(),'"+data+"')]"));
			driver.findElement(By.xpath("//*[@id=\"mail\"]/div/p/strong[contains(text(),'"+data+"')]"));
			Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"mail\"]/div/p/strong[contains(text(),'"+data+"')]")).getText(), data);
			
		}
//		wait.until(ExpectedConditions.visibilityOf(returnHome));
		
		
		
	}
	public void validatetitle(String data)
	{
		
	
		 if(AssignmentReport. checkifParmeterAvailable(data))
             data=AssignmentReport.getParmeterAvailable(data);
		Assert.assertEquals(driver.findElement(By.xpath("//div[contains(text(),'"+data+"')]")).getText(), data);
//		wait.until(ExpectedConditions.visibilityOf(returnHome));
		

	}
	
	public void navigateSubDomain()
	{
		driver.get(OrganizationDetails.subDomain);
	}
	
	public void navigateADFSSubDomain()
	{
		driver.get(prop.getProperty("urlADFS"+prop.getProperty("environment")));
	}
	public void clickLoginSubDomain()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(subDomainHomeLogin));
		subDomainHomeLogin.click();
	}
	public void subDomainHomeLoginADFS()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(subDomainHomeLogin));
		subDomainHomeLogin.click();
	}
	
	
	public void loginToADFSSubDomain()
	{
		String ADFSuserEmail=	prop.getProperty("userEmailIdADFS"+prop.getProperty("environment"));
		String ADFSuserPassword=	prop.getProperty("userPasswordADFS"+prop.getProperty("environment"));
		
		try {
			
		Thread.sleep(5000);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(subDomainUserIdADFS));
		subDomainUserIdADFS.click();
		subDomainUserIdADFS.sendKeys(ADFSuserEmail);
		subDomainPwd.click();
		subDomainPwd.sendKeys(ADFSuserPassword);
		subDomainSignInADFS.click();
		}
		catch(Exception w)
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(subDomainUserIdADFS));
			subDomainUserIdADFS.clear();
			subDomainUserIdADFS.sendKeys(ADFSuserEmail);
			subDomainPwdADFS.click();
			subDomainPwdADFS.sendKeys(ADFSuserPassword);
			subDomainSignInADFS.click();
		}
		
	}
	
	public void loginToSubDomain()
	{
		try {
		Thread.sleep(10000);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(subDomainUserId));
		subDomainUserId.click();
		subDomainUserId.sendKeys(User.userEmail);
		subDomainPwd.click();
		subDomainPwd.sendKeys(pwd);
		subDomainSignIn.click();
		}
		catch(Exception w)
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(subDomainUserId1));
			subDomainUserId1.click();
			subDomainUserId1.sendKeys(User.userEmail);
			subDomainPwd1.click();
			subDomainPwd1.sendKeys(pwd);
			subDomainSignIn1.click();
		}
		
	}
	
	public void loginToSubDomain(String msg)
	{
		try {
		Thread.sleep(10000);
		
		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(subDomainUserId1));
		subDomainUserId1.click();
		subDomainUserId1.sendKeys(User.userEmail);
		subDomainPwd1.click();
		subDomainPwd1.sendKeys(pwd);
		subDomainSignIn1.click();
		wait.until(ExpectedConditions.visibilityOf(errorMsg));
		Assert.assertEquals(errorMsg.getText(), msg);
		
		
		}
		catch(Exception w)
		{
			Assert.fail("Error login while loggin to application");
		}
		
	}
	
	
	public void loginToSubDomainStudent()
	{
		try {
		Thread.sleep(5000);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(subDomainUserId));
		subDomainUserId.click();
		subDomainUserId.sendKeys(User.userEmail);
		subDomainPwd.click();
		subDomainPwd.sendKeys(pwd);
		subDomainSignIn.click();
		}
		catch(Exception w)
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(subDomainUserId1));
			subDomainUserId1.click();
			subDomainUserId1.sendKeys(User.userEmail);
			subDomainPwd1.click();
			subDomainPwd1.sendKeys(pwd);
			subDomainSignIn1.click();
		}
		
	}
	
	public void handleFederalPopup()
	{
		try
		{
			Thread.sleep(5000);
				wait.until(ExpectedConditions.visibilityOf(subDomainFederalPopupAccept));
			subDomainFederalPopupAccept.click();
			Thread.sleep(5000);
		}
		catch(Exception e)
		{
			try
			{
				login = new LoginPage();
				login.clickOnAdminSignIn();
				loginToSubDomain_Admin();
			}
			catch(Exception ex)
			{
				System.out.println("No federal popup");
			}
		}
	}
	
	public void handleFederalPopupyes()
	{
		try
		{
			String msg=null;
			wait.until(ExpectedConditions.visibilityOf(subDomainFederalPopupAccept));
			if(AssignmentReport. checkifParmeterAvailable( "FederalHeader"))
				 msg=AssignmentReport.getParmeterAvailable( "FederalHeader");
			Assert.assertEquals(subDomainFederalPopupHeader.getText(), msg);
			if(AssignmentReport. checkifParmeterAvailable( "FederalBody"))
				 msg=AssignmentReport.getParmeterAvailable( "FederalBody");
			System.out.println(msg);
			Assert.assertEquals(subDomainFederalPopupText.getText(), msg);
			
			subDomainFederalPopupAccept.click();
			Thread.sleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail("Federal Popup");
		}
	}
	
	public void handlenotavalableFederalPopupyes()
	{
		try
		{
			Thread.sleep(10000);
			wait.until(ExpectedConditions.visibilityOf(subDomainFederalPopupAccept));
			subDomainFederalPopupAccept.click();
			Assert.fail("Federal Popup");
			Thread.sleep(5000);
		}
		catch(Exception e)
		{
			System.out.println("Federal pop up not avalable");
		
		}
	}
	public void federalhandleFederalPopup()
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(subDomainFederalPopupAccept));
			subDomainFederalPopupAccept.click();
			Assert.fail("Federal Popup");
		}
		catch(Exception e)
		{
			try
			{
				login = new LoginPage();
				login.clickOnAdminSignIn();
				loginToSubDomain_Admin();
			}
			catch(Exception ex)
			{
				System.out.println("No federal popup");
			}
		}
	}
	
	public void declinehandleFederalPopup()
	{
		try
		{
			wait.until(ExpectedConditions.visibilityOf(subDomainFederalPopupdecline));
			String msg=null;
			if(AssignmentReport. checkifParmeterAvailable( "FederalHeader"))
				 msg=AssignmentReport.getParmeterAvailable( "FederalHeader");
			System.out.println(subDomainFederalPopupHeader.getText());
			Assert.assertEquals(subDomainFederalPopupHeader.getText(), msg);
			if(AssignmentReport. checkifParmeterAvailable( "FederalBody"))
				 msg=AssignmentReport.getParmeterAvailable( "FederalBody");
			System.out.println(subDomainFederalPopupText.getText());
			
			Assert.assertEquals(subDomainFederalPopupText.getText(), msg);
		
			subDomainFederalPopupdecline.click();
			Thread.sleep(5000);
		}
		catch(Exception e)
		{
			
				Assert.fail("No federal popup");
			
		}
	}
	
	public void loginYopmail()
	{

		wait.until(ExpectedConditions.visibilityOf(searchEmailText));
		searchEmailText.click();
		searchEmailText.clear();
		System.out.println(User.userEmail);
		searchEmailText.sendKeys(User.userEmail);
		searchEmailButton.click();
		wait.until(ExpectedConditions.visibilityOf(emailLogin));
		String user = emailLogin.getText().trim();
		while(!(User.userEmail.toLowerCase().contains(user)))
		{
			wait.until(ExpectedConditions.visibilityOf(homeLink));
			homeLink.click();
			wait.until(ExpectedConditions.visibilityOf(searchEmailText));
			searchEmailText.clear();
			searchEmailText.sendKeys(User.userEmail);
		}
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifinbox");
	}
	
	
	public void logoutFromSubDomain()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(subDomainMenu));
		subDomainMenu.click();
		wait.until(ExpectedConditions.visibilityOf(subDomainLogout));
		subDomainLogout.click();
//		driver.quit();
		Admin.email = null;
	}
	
//////////////////////////////////////////////////////////Admin /////////////////////////////////////
	
	public void clickOnPwdChangeLink_Admin()
	{
		try
		{
		wait.until(ExpectedConditions.visibilityOf(searchEmailText));
		searchEmailText.click();
		searchEmailText.clear();
		String userEntered;
		if(Admin.email == null)
		{
			searchEmailText.sendKeys(User.userEmail);
			userEntered = User.userEmail.trim();
		}
		else
		{
			searchEmailText.sendKeys(Admin.email);
			userEntered = Admin.email.trim();
		}
		System.out.println("Entered value: " + userEntered);
		
		searchEmailButton.click();
		wait.until(ExpectedConditions.visibilityOf(emailLogin));
		String user = emailLogin.getText().trim();
		while(!(userEntered.toLowerCase().contains(user)))
		{	
			wait.until(ExpectedConditions.visibilityOf(homeLink));
			homeLink.click();
			wait.until(ExpectedConditions.visibilityOf(searchEmailText));
			searchEmailText.clear();
			searchEmailText.sendKeys(userEntered);
		}
		Thread.sleep(5000);
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifinbox");
		try
		{
		wait.until(ExpectedConditions.visibilityOf(yopmailAccountCreated));
		yopmailAccountCreated.click();
		}
		catch(Exception e)
		{
			
		}
		driver.switchTo().defaultContent();
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifmail");
		wait.until(ExpectedConditions.visibilityOf(pwdLink));
		pwdLink.click();
		driver.switchTo().defaultContent();
		
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail("Captcha code popuped");
		}
	}
	
	public void searching()
	{

		try
		{
		wait.until(ExpectedConditions.visibilityOf(searchEmailText));
		searchEmailText.click();
		searchEmailText.clear();
		String userEntered;
		if(Admin.email == null)
		{
			searchEmailText.sendKeys(User.userEmail);
			userEntered = User.userEmail.trim();
		}
		else
		{
			searchEmailText.sendKeys(Admin.email);
			userEntered = Admin.email.trim();
		}
		System.out.println("Entered value: " + userEntered);
		searchEmailButton.click();
		wait.until(ExpectedConditions.visibilityOf(emailLogin));
		String user = emailLogin.getText().trim();
		while(!(userEntered.toLowerCase().contains(user)))
		{	
			wait.until(ExpectedConditions.visibilityOf(homeLink));
			homeLink.click();
			wait.until(ExpectedConditions.visibilityOf(searchEmailText));
			searchEmailText.clear();
			searchEmailText.sendKeys(userEntered);
		}
		
		}
		catch(Exception e)
		{
			Assert.fail("Captcha code popuped");
		}
	
	}
	
	
	public void logoutToSuddomain()
	{
		try 
		{
			Thread.sleep(10000);
			wait.until(ExpectedConditions.visibilityOf(loggout));
			wait.until(ExpectedConditions.elementToBeClickable(loggout));
			loggout	.click();
		Thread.sleep(10000);
		   
		}
		catch (Exception e) 
		{
		
			wait.until(ExpectedConditions.visibilityOf(loggout));
			wait.until(ExpectedConditions.elementToBeClickable(loggout));
			loggout	.click();
		
//			e.printStackTrace();
		}
	}
	public void loginToSubDomain_Student()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(subDomainUserId));
			subDomainUserId.click();
			if(Admin.email == null)
			{
				subDomainUserId.sendKeys(User.userEmail);
			}
			else
			{
				subDomainUserId.sendKeys(Admin.email);
			}
			subDomainPwd.click();
			if(pwd==null)
			{
				Date formatDate = new java.util.Date();
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String date = formatter.format(formatDate);
				date = date.replace(" ", "").replace(":", "").replace("-", "").substring(0, 10);
				pwd = "Pwd@" + date;
				System.out.println(pwd);
				
				subDomainPwd.sendKeys(pwd);
				subDomainSignIn.click();	
			}
			else
			{
			subDomainPwd.sendKeys(pwd);
			subDomainSignIn.click();
			}
		} 
		catch (Exception e) 
		{
			try
			{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(subDomainUserId1));
			subDomainUserId1.click();
			if(Admin.email == null)
			{
				subDomainUserId1.sendKeys(User.userEmail);
			}
			else
			{
				subDomainUserId1.sendKeys(Admin.email);
			}
			subDomainPwd1.click();
			
			if(pwd==null)
			{
				Date formatDate = new java.util.Date();
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String date = formatter.format(formatDate);
				date = date.replace(" ", "").replace(":", "").replace("-", "").substring(0, 10);
				pwd = "Pwd@" + date;
				System.out.println(pwd);
				subDomainPwd1.sendKeys(pwd);
				subDomainSignIn1.click();
			}
			else
			{	subDomainPwd1.sendKeys(pwd);
			subDomainSignIn1.click();
			}
		
			}
			catch(Exception m)
			{
			login = new LoginPage();
			login.clickOnAdminSignIn();
			loginToSubDomain_Admin();
			}
		}
		
		try
		{
		Thread.sleep(10000);	
		}
		catch (Exception e) 
		{
		}
	}

	public void loginToSubDomain_Admin()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.visibilityOf(subDomainUserId));
			subDomainUserId.click();
			if(Admin.email == null)
			{
				subDomainUserId.sendKeys(User.userEmail);
			}
			else
			{
				subDomainUserId.sendKeys(Admin.email);
			}
			subDomainPwd.click();
			subDomainPwd.sendKeys(pwd);
			subDomainSignIn.click();
		} 
		catch (Exception e) 
		{
			try
			{
				WebDriverWait wait = new WebDriverWait(driver, 15);
					wait.until(ExpectedConditions.visibilityOf(subDomainUserId1));
			subDomainUserId1.click();
			if(Admin.email == null)
			{
				subDomainUserId1.sendKeys(User.userEmail);
			}
			else
			{
				subDomainUserId1.sendKeys(Admin.email);
			}
			subDomainPwd1.click();
			subDomainPwd1.sendKeys(pwd);
			subDomainSignIn1.click();
			}
			catch(Exception m)
			{
			login = new LoginPage();
			login.clickOnAdminSignIn();
			loginToSubDomain_Admin();
			}
		}
		
		try
		{
		Thread.sleep(10000);	
		}
		catch (Exception e) 
		{
		}
	}
	public void loginToSubDomain_savedAdmin(String UserEmailID,String password)
	{
		try 
		{
			
			WebDriverWait wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.visibilityOf(subDomainUserId1));
			try
			{
				Thread.sleep(5000);
				acceptBtn.click();
			}
			catch(Exception e)
			{
				
			}
	subDomainUserId1.click();
	if(Admin.email == null)
	{
		subDomainUserId1.sendKeys(UserEmailID);
	}
	else
	{
		subDomainUserId1.sendKeys(UserEmailID);
	}
	subDomainPwd1.click();
	subDomainPwd1.sendKeys(password);
	subDomainSignIn1.click();
		
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
//			try
//			{
//				WebDriverWait wait = new WebDriverWait(driver, 15);
//			wait.until(ExpectedConditions.visibilityOf(subDomainUserId));
//			subDomainUserId.click();
//			if(Admin.email == null)
//			{
//				subDomainUserId.sendKeys(UserEmailID);
//			}
//			else
//			{
//				subDomainUserId.sendKeys(UserEmailID);
//			}
//			subDomainPwd.click();
//			subDomainPwd.sendKeys(password);
//			subDomainSignIn.click();
//			}
//			catch(Exception m)
//			{
//			login = new LoginPage();
//			login.clickOnAdminSignIn();
//			loginToSubDomain_Admin();
//			}
		}
		
		try
		{
		Thread.sleep(10000);	
		}
		catch (Exception e) 
		{
		}
	}
	public void loginToSubDomain_student()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(subDomainUserstudent));
			subDomainUserstudent.click();
			
			subDomainPasswordstudent.click();
			subDomainPasswordstudent.sendKeys(pwd);
			subDomainSignIn.click();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	public void loginToSubDomain_Admin(String msg)
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(subDomainUserId));
			subDomainUserId.click();
			if(Admin.email == null)
			{
				subDomainUserId.sendKeys(User.userEmail);
			}
			else
			{
				subDomainUserId.sendKeys(Admin.email);
			}
			subDomainPwd.click();
			subDomainPwd.sendKeys(pwd);
			subDomainSignIn.click();
		} 
		catch (Exception e) 
		{
			login = new LoginPage();
			login.clickOnAdminSignIn();
			loginToSubDomain_Admin();
		}
	}

	public void navigateSubDomainAsAdmin()
	{
		System.out.println(OrganizationDetails.subDomain+ "/admin");
	driver.get(OrganizationDetails.subDomain + "/admin");
	}
	public void navigateSubDomainAsAdmin(String subDomain)
	{
	driver.get(subDomain + "/admin");
	}
	
	public void navigateSubDomainAsStudent()
	{
	driver.get(OrganizationDetails.subDomain + "/mycourse");
	try
	{
	Thread.sleep(10000);	
	wait.until(ExpectedConditions.visibilityOf(Login));
	
	Login.click();
	}
	catch(Exception e)
	{
		
	}
	}
	
	
	public void clickOnAdminRole()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		try
		{
		wait.until(ExpectedConditions.visibilityOf(	driver.findElement(By.xpath("//span[text()='"+TestBase.prop.getProperty("orgName")+"_UnitAdmin']"))));
		}
		catch(Exception e)
		{
			wait.until(ExpectedConditions.visibilityOf(	driver.findElement(By.xpath("//span[text()='"+TestBase.prop.getProperty("orgName")+"_OrgAdmin']"))));
			
		}
		wait.until(ExpectedConditions.visibilityOf(subDomainAdminRole));
		try
		{
		Thread.sleep(1000);	
		}
		catch(Exception e)
		{
			
		}
		subDomainAdminRole.click();
		driver.findElement(By.xpath("//li[1]/a[text()='Users']"));
		
		driver.findElement(By.xpath("//li/a[text()='Organization Settings']"));
		
		//li/a[text()='Organization Settings']
		
	}
	public void clickOnOrgAdminRole()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		
			wait.until(ExpectedConditions.visibilityOf(	driver.findElement(By.xpath("//span[text()='"+TestBase.prop.getProperty("orgName")+"_OrgAdmin']"))));
			
		wait.until(ExpectedConditions.visibilityOf(subDomainAdminRole));
		try
		{
		Thread.sleep(1000);	
		}
		catch(Exception e)
		{
			
		}
		subDomainAdminRole.click();
		driver.findElement(By.xpath("//li[1]/a[text()='Users']"));
		
		driver.findElement(By.xpath("//li/a[text()='Organization Settings']"));
		
		//li/a[text()='Organization Settings']
		
	}
	
////////////////////////////////////////////////////////// Observer /////////////////////////////////////	
	
	public void clickOnObserverRole()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		
		wait.until(ExpectedConditions.visibilityOf(	driver.findElement(By.xpath("//span[text()='"+TestBase.prop.getProperty("orgName")+"_UnitObserver']"))));
		
		wait.until(ExpectedConditions.visibilityOf(subDomainObserverRole));
		wait.until(ExpectedConditions.elementToBeClickable(subDomainObserverRole));
		
		subDomainObserverRole.click();
	}
	public void ValidatebodyText() throws InterruptedException {
		
		driver.switchTo().defaultContent();
	//	Thread.sleep(5000);
		driver.switchTo().frame("ifmail");
		Thread.sleep(5000);
		System.out.println( " mail"+ mail.getText());
	//	System.out.println( " The paragraph "+ Body_paragraph.getText());
		Assert.assertTrue(mail.getText().contains(" www.RQI1Stop.com "));
		
	//	Your account has been created successfully in RQI1Stop.Please click here to reset your password. www.RQI1Stop.com
	}
		
	public void sendemail()
	{
//		User.userEmail="";
		
		
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifinbox");
		try
		{
		wait.until(ExpectedConditions.visibilityOf(yopmailUpdatedAccountCreated));
		yopmailUpdatedAccountCreated.click();
		}
		catch(Exception e)
		{
			
		}
		driver.switchTo().defaultContent();
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifmail");
		wait.until(ExpectedConditions.visibilityOf(pwdLink));
		pwdLink.click();
		driver.switchTo().defaultContent();
		
		
	}
	
	public void setSamePwd()
	{
		String msg=null;
		if(AssignmentReport. checkifParmeterAvailable( "RestPasswordErrorMsg"))
			 msg=AssignmentReport.getParmeterAvailable( "RestPasswordErrorMsg");
	
		
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		date = date.replace(" ", "").replace(":", "").replace("-", "").substring(0, 10);
		pwd = "Pwd@" + date;
		System.out.println(pwd);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(enterNewPwd));
		enterNewPwd.click();
		enterNewPwd.sendKeys(pwd);
		confirmPwd.click();
		confirmPwd.sendKeys(pwd);
		try
		{
			Thread.sleep(5000);
			acceptBtn.click();
		}
		catch(Exception e)
		{
			
		}
		createPwd.click();
		
		OrganizationHome orgHome=new OrganizationHome();
   		orgHome.errormsg(msg);
		
//		wait.until(ExpectedConditions.visibilityOf(returnHome));
		
	}
	@FindBy(xpath = "//div[text() = 'Forgot Password']")
	WebElement yopmailForgotPassword;
	

	public void loginYopmailForForgotPassword()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(searchEmailText));
		searchEmailText.click();
		searchEmailText.clear();
		System.out.println(User.userEmail);
		searchEmailText.sendKeys(User.userEmail);
		searchEmailButton.click();
		wait.until(ExpectedConditions.visibilityOf(emailLogin));
		String user = emailLogin.getText().trim();
		try {
			int counter = 0;
		while(!(User.userEmail.toLowerCase().contains(user)))
		{
			wait.until(ExpectedConditions.visibilityOf(homeLink));
			homeLink.click();
			wait.until(ExpectedConditions.visibilityOf(searchEmailText));
			searchEmailText.clear();
			searchEmailText.sendKeys(User.userEmail);
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load yopmail page after waiting for 1 minute");
		}
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifinbox");
		wait.until(ExpectedConditions.visibilityOf(yopmailForgotPassword));
		driver.switchTo().defaultContent();
		}
		catch(Exception e)
		{
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOf(frame));
			driver.switchTo().frame("ifinbox");
			wait.until(ExpectedConditions.visibilityOf(yopmailForgotPassword));
			driver.switchTo().defaultContent();
		}
	}
	
	public void validateRowCount_Account_Creation(int count)
	{
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOf(searchEmailText));
		searchEmailText.click();
		searchEmailText.clear();
		String userEntered;
		if(Admin.email == null)
		{
			if(User.userEmail != null)
			{
				searchEmailText.sendKeys(User.userEmail);
				userEntered = User.userEmail.trim();
			}
			else
			{
				searchEmailText.sendKeys(Students.email);
				userEntered = Students.email.trim();
			}			
		}
		else
		{
			searchEmailText.sendKeys(Admin.email);
			userEntered = Admin.email.trim();
		}
		System.out.println("Entered value: " + userEntered);
		searchEmailButton.click();
		wait.until(ExpectedConditions.visibilityOf(emailLogin));
		String user = emailLogin.getText().trim();
		try {
			int counter = 0;
		while(!(userEntered.toLowerCase().contains(user)))
		{	
			wait.until(ExpectedConditions.visibilityOf(homeLink));
			homeLink.click();
			wait.until(ExpectedConditions.visibilityOf(searchEmailText));
			searchEmailText.clear();
			searchEmailText.sendKeys(userEntered);
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load yopmail page after waiting for 1 minute");
		}				
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifinbox");
		wait.until(ExpectedConditions.visibilityOf(yopmailAccountCreated));
		Assert.assertTrue(driver.findElements(By.xpath(accountCreationNotification)).size() == count);

		}
		catch(Exception e)
		{
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOf(frame));
			driver.switchTo().frame("ifinbox");
			wait.until(ExpectedConditions.visibilityOf(yopmailAccountCreated));
			Assert.assertTrue(driver.findElements(By.xpath(accountCreationNotification)).size() == count);
		}
		
	}

	public void loginYopmailForOrgAdmin()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(searchEmailText));
		searchEmailText.click();
		searchEmailText.clear();
		System.out.println(Admin.email);
		searchEmailText.sendKeys(Admin.email);
		searchEmailButton.click();
		wait.until(ExpectedConditions.visibilityOf(emailLogin));
		String user = emailLogin.getText().trim();
		try {
			int counter = 0;
		while(!(Admin.email.toLowerCase().contains(user)))
		{
			wait.until(ExpectedConditions.visibilityOf(homeLink));
			homeLink.click();
			wait.until(ExpectedConditions.visibilityOf(searchEmailText));
			searchEmailText.clear();
			searchEmailText.sendKeys(Admin.email);
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load yopmail page after waiting for 1 minute");
		}
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifinbox");
		wait.until(ExpectedConditions.visibilityOf(yopmailAccountCreated));
		driver.switchTo().defaultContent();
		}
		catch(Exception e)
		{
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOf(frame));
			driver.switchTo().frame("ifinbox");
			wait.until(ExpectedConditions.visibilityOf(yopmailAccountCreated));
			driver.switchTo().defaultContent();
		}
	}
	public void loginYopmailForUnitAdmin()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(searchEmailText));
		searchEmailText.click();
		searchEmailText.clear();
		String email = User.userEmail;
		System.out.println(email);
		searchEmailText.sendKeys(email);
		searchEmailButton.click();
		wait.until(ExpectedConditions.visibilityOf(emailLogin));
		String user = emailLogin.getText().trim();
		try {
			int counter = 0;
		while(!(email.toLowerCase().contains(user)))
		{
			wait.until(ExpectedConditions.visibilityOf(homeLink));
			homeLink.click();
			wait.until(ExpectedConditions.visibilityOf(searchEmailText));
			searchEmailText.clear();
			searchEmailText.sendKeys(email);
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load yopmail page after waiting for 1 minute");
		}
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifinbox");
		wait.until(ExpectedConditions.visibilityOf(yopmailUnitAdminCreated));
		driver.switchTo().defaultContent();
		}
		catch(Exception e)
		{
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOf(frame));
			driver.switchTo().frame("ifinbox");
			wait.until(ExpectedConditions.visibilityOf(yopmailUnitAdminCreated));
			driver.switchTo().defaultContent();
		}
	}
	public void loginYopmailForStudentLMS()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(searchEmailText));
		searchEmailText.click();
		searchEmailText.clear();
		System.out.println(Students.email);
		searchEmailText.sendKeys(Students.email);
		searchEmailButton.click();
		wait.until(ExpectedConditions.visibilityOf(emailLogin));
		String user = emailLogin.getText().trim();
		try {
			int counter = 0;
		while(!(Students.email.toLowerCase().contains(user)))
		{
			wait.until(ExpectedConditions.visibilityOf(homeLink));
			homeLink.click();
			wait.until(ExpectedConditions.visibilityOf(searchEmailText));
			searchEmailText.clear();
			searchEmailText.sendKeys(Students.email);
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load yopmail page after waiting for 1 minute");
		}
			Assert.assertTrue(emptyInbox.isDisplayed());
		}
		catch(Exception e)
		{

		}
	}
	public String enterEmail()
	{
		String reqEmail = null;
		if(Admin.email == null)
		{
			if(User.userEmail != null)
		    	reqEmail = User.userEmail;
		    else
		    	reqEmail = Students.email;
		}
		else {
			reqEmail = Admin.email;
		}
		return reqEmail;
	}
	
	public void loginYopmailForUnitObserver()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(searchEmailText));
		searchEmailText.click();
		searchEmailText.clear();
		String email = enterEmail();
		System.out.println(email);
		searchEmailText.sendKeys(email);
		searchEmailButton.click();
		wait.until(ExpectedConditions.visibilityOf(emailLogin));
		String user = emailLogin.getText().trim();
		try {
			int counter = 0;
		while(!(email.toLowerCase().contains(user)))
		{
			wait.until(ExpectedConditions.visibilityOf(homeLink));
			homeLink.click();
			wait.until(ExpectedConditions.visibilityOf(searchEmailText));
			searchEmailText.clear();
			searchEmailText.sendKeys(email);
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load yopmail page after waiting for 1 minute");
		}
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifinbox");
		wait.until(ExpectedConditions.visibilityOf(yopmailUnitObserverCreated));
		driver.switchTo().defaultContent();
		}
		catch(Exception e)
		{
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOf(frame));
			driver.switchTo().frame("ifinbox");
			wait.until(ExpectedConditions.visibilityOf(yopmailUnitObserverCreated));
			driver.switchTo().defaultContent();
		}
	}
	public void loginYopmailForAssignmentCompleted()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(searchEmailText));
		searchEmailText.click();
		searchEmailText.clear();
		System.out.println(User.userEmail);
		searchEmailText.sendKeys(User.userEmail);
		searchEmailButton.click();
		wait.until(ExpectedConditions.visibilityOf(emailLogin));
		String user = emailLogin.getText().trim();
		try {
			int counter = 0;
		while(!(User.userEmail.toLowerCase().contains(user)))
		{
			wait.until(ExpectedConditions.visibilityOf(homeLink));
			homeLink.click();
			wait.until(ExpectedConditions.visibilityOf(searchEmailText));
			searchEmailText.clear();
			searchEmailText.sendKeys(User.userEmail);
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load yopmail page after waiting for 1 minute");
		}
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifinbox");
		wait.until(ExpectedConditions.visibilityOf(yopmailAssignmentCompleted));
		driver.switchTo().defaultContent();
		}
		catch(Exception e)
		{
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOf(frame));
			driver.switchTo().frame("ifinbox");
			wait.until(ExpectedConditions.visibilityOf(yopmailAssignmentCompleted));
			driver.switchTo().defaultContent();
		}
	}
	public void loginYopmailForEmailUpdatedStudent()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(searchEmailText));
		searchEmailText.click();
		searchEmailText.clear();
		System.out.println(Students.email);
		searchEmailText.sendKeys(Students.email);
		searchEmailButton.click();
		wait.until(ExpectedConditions.visibilityOf(emailLogin));
		String user = emailLogin.getText().trim();
		try {
			int counter = 0;
		while(!(Students.email.toLowerCase().contains(user)))
		{
			wait.until(ExpectedConditions.visibilityOf(homeLink));
			homeLink.click();
			wait.until(ExpectedConditions.visibilityOf(searchEmailText));
			searchEmailText.clear();
			searchEmailText.sendKeys(Students.email);
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load yopmail page after waiting for 1 minute");
		}
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifinbox");
		wait.until(ExpectedConditions.visibilityOf(yopmailEmailUpdated));
		driver.switchTo().defaultContent();
		}
		catch(Exception e)
		{
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOf(frame));
			driver.switchTo().frame("ifinbox");
			wait.until(ExpectedConditions.visibilityOf(yopmailEmailUpdated));
			driver.switchTo().defaultContent();
		}
	}
	public void loginYopmailForUnitAdminForCTC()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(searchEmailText));
		searchEmailText.click();
		searchEmailText.clear();
		String email = enterEmail();
		System.out.println(email);
		searchEmailText.sendKeys(email);
		searchEmailButton.click();
		wait.until(ExpectedConditions.visibilityOf(emailLogin));
		String user = emailLogin.getText().trim();
		try {
			int counter = 0;
		while(!(email.toLowerCase().contains(user)))
		{
			wait.until(ExpectedConditions.visibilityOf(homeLink));
			homeLink.click();
			wait.until(ExpectedConditions.visibilityOf(searchEmailText));
			searchEmailText.clear();
			searchEmailText.sendKeys(email);
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load yopmail page after waiting for 1 minute");
		}
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifinbox");
		wait.until(ExpectedConditions.visibilityOf(yopmailUnitAdminCreatedForCTC));
		driver.switchTo().defaultContent();
		}
		catch(Exception e)
		{
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOf(frame));
			driver.switchTo().frame("ifinbox");
			wait.until(ExpectedConditions.visibilityOf(yopmailUnitAdminCreatedForCTC));
			driver.switchTo().defaultContent();
		}
	}

	public void loginYopmailForUnitObserverForCTC()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(searchEmailText));
		searchEmailText.click();
		searchEmailText.clear();
		String email = enterEmail();
		System.out.println(email);
		searchEmailText.sendKeys(email);
		searchEmailButton.click();
		wait.until(ExpectedConditions.visibilityOf(emailLogin));
		String user = emailLogin.getText().trim();
		try {
			int counter = 0;
		while(!(email.toLowerCase().contains(user)))
		{
			wait.until(ExpectedConditions.visibilityOf(homeLink));
			homeLink.click();
			wait.until(ExpectedConditions.visibilityOf(searchEmailText));
			searchEmailText.clear();
			searchEmailText.sendKeys(email);
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load yopmail page after waiting for 1 minute");
		}
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifinbox");
		wait.until(ExpectedConditions.visibilityOf(yopmailUnitObserverCreatedForCTC));
		driver.switchTo().defaultContent();
		}
		catch(Exception e)
		{
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOf(frame));
			driver.switchTo().frame("ifinbox");
			wait.until(ExpectedConditions.visibilityOf(yopmailUnitObserverCreatedForCTC));
			driver.switchTo().defaultContent();
		}
	}
	public void validateEmailContentUserCreated()
	{
		boolean flag = false;
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(searchEmailText));
		searchEmailText.click();
		searchEmailText.clear();
		System.out.println(User.userEmail);
		searchEmailText.sendKeys(User.userEmail);
		searchEmailButton.click();
		wait.until(ExpectedConditions.visibilityOf(emailLogin));
		String user = emailLogin.getText().trim();
		try {
			int counter = 0;
		while(!(User.userEmail.toLowerCase().contains(user)))
		{
			wait.until(ExpectedConditions.visibilityOf(homeLink));
			homeLink.click();
			wait.until(ExpectedConditions.visibilityOf(searchEmailText));
			searchEmailText.clear();
			searchEmailText.sendKeys(User.userEmail);
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load yopmail page after waiting for 1 minute");
		}
			wait.until(ExpectedConditions.visibilityOf(frame));
			driver.switchTo().frame("ifinbox");
			wait.until(ExpectedConditions.visibilityOf(yopmailAccountCreated));
			yopmailAccountCreated.click();
			driver.switchTo().defaultContent();
		}
		catch(Exception e)
		{
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOf(frame));
			driver.switchTo().frame("ifinbox");
			wait.until(ExpectedConditions.visibilityOf(yopmailAccountCreated));
			yopmailAccountCreated.click();
			driver.switchTo().defaultContent();
		}
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifmail");
		List<WebElement> contentRow = driver.findElements(By.xpath("//p"));
		for(int i = 1; i <= contentRow.size(); i++)
		{
			String text = driver.findElement(By.xpath("//p[" + i + "]")).getText();
			if(text.contains(NotificationSettings.date))
			{
				flag = true;
				break;
			}
		}
		driver.switchTo().defaultContent();
		Assert.assertTrue(flag);
	}
	public void validateEmailContentAssignmentAvailable()
	{
		boolean flag = false;
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(searchEmailText));
		searchEmailText.click();
		searchEmailText.clear();
		System.out.println(User.userEmail);
		searchEmailText.sendKeys(User.userEmail);
		searchEmailButton.click();
		wait.until(ExpectedConditions.visibilityOf(emailLogin));
		String user = emailLogin.getText().trim();
		try {
			int counter = 0;
		while(!(User.userEmail.toLowerCase().contains(user)))
		{
			wait.until(ExpectedConditions.visibilityOf(homeLink));
			homeLink.click();
			wait.until(ExpectedConditions.visibilityOf(searchEmailText));
			searchEmailText.clear();
			searchEmailText.sendKeys(User.userEmail);
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load yopmail page after waiting for 1 minute");
		}
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifinbox");
		wait.until(ExpectedConditions.visibilityOf(yopmailAssignmentAvailable));
		yopmailAssignmentAvailable.click();
		driver.switchTo().defaultContent();
		}
		catch(Exception e)
		{
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOf(frame));
			driver.switchTo().frame("ifinbox");
			wait.until(ExpectedConditions.visibilityOf(yopmailAssignmentAvailable));
			yopmailAssignmentAvailable.click();
			driver.switchTo().defaultContent();
		}
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifmail");
		List<WebElement> contentRow = driver.findElements(By.xpath("//p"));
		for(int i = 1; i <= contentRow.size(); i++)
		{
			String text = driver.findElement(By.xpath("//p[" + i + "]")).getText();
			if(text.contains(NotificationSettings.date))
			{
				flag = true;
				break;
			}
		}
		driver.switchTo().defaultContent();
		Assert.assertTrue(flag);
	}

	public void validateEmailContentUnitAdminForCTC()
	{
		boolean flag = false;
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(searchEmailText));
		searchEmailText.click();
		searchEmailText.clear();
		String email = enterEmail();
		System.out.println(email);
		searchEmailText.sendKeys(email);
		searchEmailButton.click();
		wait.until(ExpectedConditions.visibilityOf(emailLogin));
		String user = emailLogin.getText().trim();
		try {
			int counter = 0;
		while(!(email.toLowerCase().contains(user)))
		{
			wait.until(ExpectedConditions.visibilityOf(homeLink));
			homeLink.click();
			wait.until(ExpectedConditions.visibilityOf(searchEmailText));
			searchEmailText.clear();
			searchEmailText.sendKeys(email);
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load yopmail page after waiting for 1 minute");
		}
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifinbox");
		wait.until(ExpectedConditions.visibilityOf(yopmailUnitAdminCreatedForCTC));
		yopmailUnitAdminCreatedForCTC.click();
		driver.switchTo().defaultContent();
		}
		catch(Exception e)
		{
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOf(frame));
			driver.switchTo().frame("ifinbox");
			wait.until(ExpectedConditions.visibilityOf(yopmailUnitAdminCreatedForCTC));
			yopmailUnitAdminCreatedForCTC.click();
			driver.switchTo().defaultContent();
		}
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifmail");
		List<WebElement> contentRow = driver.findElements(By.xpath("//p"));
		for(int i = 1; i <= contentRow.size(); i++)
		{
			String text = driver.findElement(By.xpath("//p[" + i + "]")).getText();
			if(text.contains(NotificationSettings.date))
			{
				flag = true;
				break;
			}
		}
		driver.switchTo().defaultContent();
		Assert.assertTrue(flag);
	}
	
	public void validateEmailContentUnitObserverForCTC()
	{
		boolean flag = false;
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(searchEmailText));
		searchEmailText.click();
		searchEmailText.clear();
		String email = enterEmail();
		System.out.println(email);
		searchEmailText.sendKeys(email);
		searchEmailButton.click();
		wait.until(ExpectedConditions.visibilityOf(emailLogin));
		String user = emailLogin.getText().trim();
		try {
			int counter = 0;
		while(!(email.toLowerCase().contains(user)))
		{
			wait.until(ExpectedConditions.visibilityOf(homeLink));
			homeLink.click();
			wait.until(ExpectedConditions.visibilityOf(searchEmailText));
			searchEmailText.clear();
			searchEmailText.sendKeys(email);
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load yopmail page after waiting for 1 minute");
		}
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifinbox");
		wait.until(ExpectedConditions.visibilityOf(yopmailUnitObserverCreatedForCTC));
		yopmailUnitObserverCreatedForCTC.click();
		driver.switchTo().defaultContent();
		}
		catch(Exception e)
		{
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOf(frame));
			driver.switchTo().frame("ifinbox");
			wait.until(ExpectedConditions.visibilityOf(yopmailUnitObserverCreatedForCTC));
			yopmailUnitObserverCreatedForCTC.click();
			driver.switchTo().defaultContent();
		}
		
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifmail");
		List<WebElement> contentRow = driver.findElements(By.xpath("//p"));
		for(int i = 1; i <= contentRow.size(); i++)
		{
			String text = driver.findElement(By.xpath("//p[" + i + "]")).getText();
			if(text.contains(NotificationSettings.date))
			{
				flag = true;
				break;
			}
		}
		driver.switchTo().defaultContent();
		Assert.assertTrue(flag);
	}
	public void loginYopmailForAssignmentAvailable()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(searchEmailText));
		searchEmailText.click();
		searchEmailText.clear();
		System.out.println(User.userEmail);
		searchEmailText.sendKeys(User.userEmail);
		searchEmailButton.click();
		wait.until(ExpectedConditions.visibilityOf(emailLogin));
		String user = emailLogin.getText().trim();
		try {
			int counter = 0;
		while(!(User.userEmail.toLowerCase().contains(user)))
		{
			wait.until(ExpectedConditions.visibilityOf(homeLink));
			homeLink.click();
			wait.until(ExpectedConditions.visibilityOf(searchEmailText));
			searchEmailText.clear();
			searchEmailText.sendKeys(User.userEmail);
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load yopmail page after waiting for 1 minute");
		}
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifinbox");
		wait.until(ExpectedConditions.visibilityOf(yopmailAssignmentAvailable));
		driver.switchTo().defaultContent();
		}
		catch(Exception e)
		{
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOf(frame));
			driver.switchTo().frame("ifinbox");
			wait.until(ExpectedConditions.visibilityOf(yopmailAssignmentAvailable));
			driver.switchTo().defaultContent();
		}
	}
	public void loginYopmailForUser()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(searchEmailText));
		searchEmailText.click();
		searchEmailText.clear();
		System.out.println(User.userEmail);
		searchEmailText.sendKeys(User.userEmail);
		searchEmailButton.click();
		wait.until(ExpectedConditions.visibilityOf(emailLogin));
		String user = emailLogin.getText().trim();
		try {
			int counter = 0;
		while(!(User.userEmail.toLowerCase().contains(user)))
		{
			wait.until(ExpectedConditions.visibilityOf(homeLink));
			homeLink.click();
			wait.until(ExpectedConditions.visibilityOf(searchEmailText));
			searchEmailText.clear();
			searchEmailText.sendKeys(User.userEmail);
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load yopmail page after waiting for 1 minute");
		}
			Assert.assertTrue(emptyInbox.isDisplayed());
		}
		catch(Exception e)
		{
			Assert.fail("Email received");
		}
	}
}
