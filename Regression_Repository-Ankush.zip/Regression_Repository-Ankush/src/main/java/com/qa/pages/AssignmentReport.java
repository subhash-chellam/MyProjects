package com.qa.pages;

import java.io.File;
import java.io.FileReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.opencsv.CSVReader;
import com.qa.util.TestBase;

public class AssignmentReport extends TestBase
{
	@FindBy(xpath = "//a[contains(text(), 'Assignment Report')]")
	WebElement AssignmentReportLink;
	@FindBy(xpath = "//a[contains(text(), 'Reports')]")
	WebElement reportLink;

	@FindBy(xpath = "//body[@class]")
	WebElement pageLoad;
	
	@FindBy(xpath = "//table[@id = 'assignment_reports']/tbody//td[7]")
	WebElement assignmentStatus;
	
	@FindBy(xpath = "//table[@id = 'assignment_reports']/tbody//td[9]")
	WebElement dueDate;
	
	@FindBy(xpath = "//table[@id = 'assignment_reports']/tbody//td[1]")
	WebElement userId;
	
	@FindBy(xpath = "//table[@id = 'assignment_reports']/tbody//td[13]")
	WebElement jobTitle;
	
	@FindBy(xpath = "//table[@id = 'assignment_reports']/tbody//td[10]")
	WebElement userStatus;
	
	@FindBy(xpath = "//label[@id='inputSearch']")
	WebElement searchTextBox;
	
	@FindBy(xpath = "//input[@type='search']")
	WebElement searchinputText;
	
	@FindBy(xpath = "//button[@id= 'searchbtn']")
	WebElement searchButton;
	@FindBy(xpath = "//a[@data-target = '#unitdiv']")
	WebElement[] searchResultUnitName;
	@FindBy(xpath = "//div[@id]/a[text()= 'Clear Search']")
	WebElement searchClear;
	
	@FindBy(xpath = "//label[@id='inputSearch']")
	WebElement searchText;
	
	
	@FindBy(xpath = "//table[@id = 'assignment_reports']/tbody//td[1]")
	WebElement searchResultUserId;
	
	@FindBy(xpath = "//table[@id = 'assignment_reports']/tbody//td[14]")
	WebElement searchResultUserEmail;
	
	@FindBy(xpath = "//a[contains(text(), 'More Filters')]")
	WebElement moreFilter;
	
	@FindBy(xpath = "//div[@class = 'collapse in']//select[@id = 'job_title_id']//following-sibling::div")
	WebElement userJobFilter;
	
	@FindBy(xpath = "//select[@id = 'job_title_id']//following-sibling::div//a")
	WebElement selectAllJobFilter;
	
	@FindBy(xpath = "//select[@id = 'group_id']//following-sibling::div/button")
	WebElement userGroupFilter;
	
	@FindBy(xpath = "//select[@id = 'group_id']//following-sibling::div//a")
	WebElement selectAllGroupFilter;
	
	@FindBy(xpath = "//select[@id = 'statusFilter']//following-sibling::div/button")
	WebElement userStatusFilter;
	
	@FindBy(xpath = "(//select[@id = 'statusFilter']//following-sibling::div//label/input)[1]")
	WebElement activeStatusFilter;
	
	@FindBy(xpath = "(//select[@id = 'statusFilter']//following-sibling::div//label/input)[2]")
	WebElement inActiveStatusFilter;
	
	@FindBy(xpath = "(//button[@value= 'Search'])[2]")
	WebElement moreFilterSearch;
	
	@FindBy(xpath = "(//a[text()= 'Clear Search'])[2]")
	WebElement moreFilterClearSearch;
	
	
	
	@FindBy(xpath = "//div[@id=\"filter_start_date\"]//div//input[@id=\"from_start_date\"]")
	WebElement filter_start_date;
	
	@FindBy(xpath = "//div[@id=\"filter_start_date\"]//div//input[@id=\"to_start_date\"]")
	WebElement filter_to_start_date;
	
	@FindBy(xpath = "//div[@id='filter_due_date']//div//input[@id='from_due_date']")
	WebElement filter_due_date;
	
	@FindBy(xpath = "//div[@id='filter_due_date']//div//input[@id='to_due_date']")
	WebElement filter_to_due_date;
	
	
	

	@FindBy(xpath = "//button[@title=\"Organization\"]")
	WebElement Organization;
	
	
	@FindBy(xpath = "//select[@id = 'assignments']//following-sibling::div/button")
	WebElement assignmentNameFilter;
	
	
	@FindBy(xpath = "//*[@id=\"ms-list-1\"]/button")
	WebElement CourseFilter;
	
	@FindBy(xpath = "//select[@id = 'assignment_status']//following-sibling::div//a")
	WebElement unSelectAllAssignmentStatusFilter;
	
	@FindBy(xpath = "//*[@id=\"ms-list-2\"]//a[text()='Unselect all']")
	WebElement unSelectAllAssignmentNameFilter;
	
	 
	@FindBy(xpath = "//*[@id=\"ms-list-1\"]/div/a[text()='Unselect all']")
	WebElement unSelectAllCourseFilter;
	
	
	@FindBy(xpath = "(//button[@value= 'Search'])[3]")
	WebElement moreCourseFilterSearch;
	
	@FindBy(xpath = "(//a[text()= 'Clear Search'])[3]")
	WebElement courseFilterClearSearch;
	
	@FindBy(xpath = "//select[@id = 'group_id']//following-sibling::div/button")
	WebElement groupFilter;
	
	@FindBy(xpath = "//select[@id = 'group_id']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement groupFilterUnSelectAll;
	
	@FindBy(xpath = "//select[@id = 'group_id']//following-sibling::div//a[text() = 'Select all']")
	WebElement groupFilterSelectAll;
	
	@FindBy(xpath = "(//select[@id = 'group_id']//following-sibling::div)//input[@type= 'text']")
	WebElement groupFilterFilterSearch;
	
	@FindBy(xpath = "//select[@id = 'job_title_id']//following-sibling::div/button")
	WebElement jobFilter;
	
	@FindBy(xpath = "//select[@id = 'job_title_id']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement jobFilterUnSelectAll;
	
	@FindBy(xpath = "//select[@id = 'job_title_id']//following-sibling::div//a[text() = 'Select all']")
	WebElement jobFilterSelectAll;
	
	@FindBy(xpath = "(//select[@id = 'job_title_id']//following-sibling::div)//input[@type= 'text']")
	WebElement jobFilterFilterSearch;
	@FindBy(xpath = "(//select[@id = 'statusFilter']//following-sibling::div)//input[@type= 'text']")
	WebElement userFilterSearch;
	
//	String userJobFilter = "(//select[@id = 'job_title_id']//following-sibling::div//ul//label)";
	@FindBy(xpath = "//button[text() = 'Search' and not(@id)]")
	WebElement moreFilterSearchButton;
	@FindBy(xpath = "//select[@id = 'statusFilter']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement userUnSelectAll;
	@FindBy(xpath = "//select[@id = 'statusFilter']//following-sibling::div//a[text() = 'Select all']")
	WebElement userSelectAll;
	 @FindBy(xpath = "//button//span[contains(text(),'Active')]")
		WebElement userSelectdropdown;
	
	@FindBy(xpath = "//label[@class and text() = 'Search for Name, Email or User ID']")
	WebElement userSearchLabel;
	
	@FindBy(xpath = "//input[@id = 'searchbox_name_email']")
	WebElement userSearchInput;
	
	@FindBy(xpath = "//label[text() = 'Organization Level']")
	WebElement orgLevelLabel;
	
	@FindBy(xpath = "//button[@title = 'Organization']")
	WebElement orgLevelDropdown;
	
	@FindBy(xpath = "//label[text() = 'Organization (s) Name']")
	WebElement unitLevelLabel;
	
	@FindBy(xpath = "//select[@id = 'filterSelect_1']")
	WebElement unitLevelDropdown;
	
	@FindBy(xpath = "//select[@id = 'orgLevel']")
	WebElement selectOrgLevelDropdown;

	String reportTable = "//table[@id = 'assignment_reports']//tbody/tr";
	
	By userTableRow = By.xpath("//table[@id = 'assignment_reports']/tbody/tr");
	
	String assignmentStatusPath = "//select[@id = 'assignment_status']//following-sibling::div//label[contains(text(),'";
	String val;
	String userStatus1 = "(//select[@id = 'statusFilter']//following-sibling::div//ul//label)";
	String userJobFilter1 = "(//select[@id = 'job_title_id']//following-sibling::div//ul//label)";
	
	@FindBy(xpath = " //a[contains( @class,'card-link assignment_filter')]")
	WebElement courseFilter;
	
	@FindBy(xpath = "//select[@id = 'courses']//following-sibling::div/button")
	WebElement courseStatusFilter;
	
	@FindBy(xpath = "//select[@id = 'assignment_status']//following-sibling::div/button")
	WebElement assignmentStatusFilter;
	
	@FindBy(xpath = "//input[@id = 'from_start_date']")
	WebElement assignmentFromDate;
	
	@FindBy(xpath = "//input[@id = 'to_start_date']")
	WebElement assignmentToDate;
	
	@FindBy(xpath = "//input[@id = 'from_due_date']")
	WebElement assignmentFromDueDate;
	
	@FindBy(xpath = "//input[@id = 'to_due_date']")
	WebElement assignmentToDueDate;
	
	@FindBy(xpath = "(//button[text() = 'Search' and not(@id)])[2]")
	WebElement courseFilterSearchButton;
	
	
	@FindBy(xpath = "//select[@id = 'courses']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement courseFilterUnSelectAll;
	
	@FindBy(xpath = "//select[@id = 'courses']//following-sibling::div//a[text() = 'Select all']")
	WebElement courseFilterSelectAll;
	
	@FindBy(xpath = "(//select[@id = 'courses']//following-sibling::div)//input[@type= 'text']")
	WebElement courseFilterFilterSearch;
	
	@FindBy(xpath = "//label[text() = 'Rows per page ']//select")
	WebElement rowPerPageSelect;
	
	@FindBy(xpath = "//button[@id = 'exportbtn']")
	WebElement exportButton;
	
	String pagination = "(//div[@class = 'dataTables_paginate paging_simple_numbers'])";
	String enableExportButton = "//button[@id = 'exportbtn' and not(contains(@class, 'disabled'))]";
	String downloadPath = System.getProperty("user.dir") + prop.getProperty("downloadPath");

	String courseFilterLabel1 = "//label[contains(text(), '";
	String userCourseFilter1 = "(//select[@id = 'courses']//following-sibling::div//ul//label)";
	String courseFilterLabel = "//label[contains(text(), '";
	String userCourseFilter = "(//select[@id = 'courses']//following-sibling::div//ul//label)";
	String assignmentFilterLabel = "(//label[contains(text(), '";
	String tableHeader = "(//table[@aria-describedby = 'assignment_reports_info'])[1]//th";
	User	usr = new User();
	public AssignmentReport() 
	{
		PageFactory.initElements(driver, this);
	}
	
	
	public void selectAssignmentReportLink()
	{
		wait.until(ExpectedConditions.visibilityOf(AssignmentReportLink));
		AssignmentReportLink.click();
		int m=0;
		val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_compliance"))
        {
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		System.out.println(val);
       driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
	  	
		if(!driver.getCurrentUrl().contains("assignment_report"))
		{
			wait.until(ExpectedConditions.visibilityOf(reportLink));
			
			reportLink.click();
			wait.until(ExpectedConditions.visibilityOf(AssignmentReportLink));
			AssignmentReportLink.click();
			

		}
		
		
		
		
	}
	
	public void validaterow(int row)
	{
	int cont=0;
		int rowCount=0;
		while(row!=rowCount)
		{
		try
		{
			Thread.sleep(250);
			List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
            rowCount = tableRows.size();
            System.out.println(rowCount);
		}
		catch (Exception e) {
			// TODO: handle exception
		}
         if(cont==650)
        	 break;
         
         cont++;
    	}
		
	}

	public void validateStatusWithValueAndCourse(String value,String course)
    {
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
		course=course.replace("Â","");

		int m=0;
		boolean flag = false;
		try
		{

			JavascriptExecutor js = (JavascriptExecutor)driver;
				val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading"))
			{
				val = pageLoad.getAttribute("class");
				try
				{
					String curriculum = reportTable + "[1]/td[4]";
					String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();

				}
				catch(Exception e)
				{

				}
				
			}

			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			int rowCount=0;
			int cont=0;
			while(rowCount==0)
			{	
				List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
				rowCount = tableRows.size();
				if(cont==150)
					break;

				cont++;
			}
		

			for (int i= 1; i<= rowCount; i++)
			{
				String curriculum = reportTable + "[" + i + "]/td[4]";

			    String Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[14]")).getText();

				String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();

				System.out.println("curricuclumText "+curricuclumText);
				System.out.println("Email "+Email);
				
				if(course.toLowerCase().contains(curricuclumText.toLowerCase())&&Email.contains(User.userEmail))
				{
					String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[7]")).getText();
					Assert.assertTrue(data.trim().toLowerCase().equalsIgnoreCase(value.trim().toLowerCase()));
					flag = true;
					break;
				}
			}
			Assert.assertFalse(flag == false);

		}
		catch(StaleElementReferenceException e)
		{
			m=0;
			validateStatusWithValueAndCourse(value,course);
		}
		catch(Exception e)
		{
			Assert.fail("Issues with application");
		}
        
    }
	public void validateUserStatusWithValueAndCourse(String value,String course)
    {
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
		course=course.replace("Â","");

		int m=0;
		boolean flag = false;
		try
		{

			JavascriptExecutor js = (JavascriptExecutor)driver;
				val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading"))
			{
				val = pageLoad.getAttribute("class");
				try
				{
					String curriculum = reportTable + "[1]/td[4]";
					String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();

				}
				catch(Exception e)
				{

				}
				
			}

			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			int rowCount=0;
			int cont=0;
			while(rowCount==0)
			{
				List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
				rowCount = tableRows.size();
				if(cont==150)
					break;

				cont++;
			}
		

			for (int i= 1; i<= rowCount; i++)
			{
				String curriculum = reportTable + "[" + i + "]/td[4]";

			    String Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[14]")).getText();

				String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();

				System.out.println("curricuclumText "+curricuclumText);
				System.out.println("Email "+Email);
				
				if(course.toLowerCase().contains(curricuclumText.toLowerCase())&&Email.contains(User.userEmail))
				{
					String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[10]")).getText();
					Assert.assertTrue(data.trim().toLowerCase().equalsIgnoreCase(value.trim().toLowerCase()));
					flag = true;
					break;
				}
			}
			Assert.assertFalse(flag == false);

		}
		catch(StaleElementReferenceException e)
		{
			m=0;
			validateStatusWithValueAndCourse(value,course);
		}
		catch(Exception e)
		{
			Assert.fail("Issues with application");
		}
        
    }
	public void validateAssignmentStatus(String expected)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		System.out.println("value of attribute is " + val);
		while(val.contains("loading"))
        {
        	val = pageLoad.getAttribute("class");
        	if(m==pagload)
				break;
        	m++;
        }
		wait.until(ExpectedConditions.visibilityOf(assignmentStatus));
		String actualStatus = driver.findElement(By.xpath("//table[@id = 'assignment_reports']/tbody//td[14][text()='"+User.userEmail+"']//preceding::td[7]")).getText();
		Assert.assertEquals(expected.toLowerCase(), actualStatus.toLowerCase());
	}
	

	public void validateActivationDate(String expected)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		System.out.println("value of attribute is " + val);
		while(val.contains("loading"))
        {
        	val = pageLoad.getAttribute("class");
        	if(m==pagload)
				break;
        	m++;
        }
		wait.until(ExpectedConditions.visibilityOf(assignmentStatus));
		String actualStatus = driver.findElement(By.xpath("//table[@id = 'assignment_reports']/tbody//td[14][text()='"+User.userEmail+"']//preceding::td[8]")).getText();
		Assert.assertEquals(expected.toLowerCase(), actualStatus.toLowerCase());
	}
	

	public void validateAssignmentDate(String expected)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		System.out.println("value of attribute is " + val);
		while(val.contains("loading"))
        {
        	val = pageLoad.getAttribute("class");
        	if(m==pagload)
				break;
        	m++;
        	
        }
		wait.until(ExpectedConditions.visibilityOf(assignmentStatus));
		String actualStatus = driver.findElement(By.xpath("//table[@id = 'assignment_reports']/tbody//td[14][text()='"+User.userEmail+"']//preceding::td[6]")).getText();
		String date=null;
		if(expected.contains("today"))
	{
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		 date = formatter.format(formatDate);
		System.out.println( date);	
	}
		Assert.assertEquals(date.toLowerCase(), actualStatus.toLowerCase());
	}
	
	
	public void validateDueDate(String expected)
	{
		wait.until(ExpectedConditions.visibilityOf(dueDate));
		String actualStatus = dueDate.getText();
		System.out.println(actualStatus);
		if(expected.toLowerCase().contains("na"))
		{
			Assert.assertEquals(expected, actualStatus);
		}
		else
			Assert.assertNotSame(expected, actualStatus);
		
	}
	
	public void validateJobTitle(String expected)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		System.out.println("value of attribute is " + val);
		while(val.contains("loading"))
        {
        	val = pageLoad.getAttribute("class");
        	if(m==pagload)
				break;
        	m++;
        }
		wait.until(ExpectedConditions.visibilityOf(jobTitle));
		 jobTitle.getText();
		 String actualStatus=null;
		 try
		 {
		  actualStatus =driver.findElement(By.xpath("//table[@id = 'assignment_reports']/tbody//td[14][text()='"+User.userEmail+"']//preceding::td[1]")).getText(); 
		 }
		 catch(NoSuchElementException e)
		 {
			 Assert.fail("Row doesnt exist");
		 }
		 if(expected.toLowerCase().contains("na"))
		{
			Assert.assertEquals(expected, actualStatus);
		}
		else
			Assert.assertNotSame(expected, actualStatus);
	}

	public void validateJobTitle(String expected,int i)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		System.out.println("value of attribute is " + val);
		while(val.contains("loading"))
        {
        	val = pageLoad.getAttribute("class");
        	if(m==pagload)
				break;
        	m++;
        }
		wait.until(ExpectedConditions.visibilityOf(jobTitle));
		 jobTitle.getText();
		 String actualStatus =driver.findElement(By.xpath("//table[@id = 'assignment_reports']/tbody//td[14][text()='"+User.usrEmail[i]+"']//preceding::td[1]")).getText(); 
		if(expected.toLowerCase().contains("na"))
		{
			Assert.assertEquals(expected, actualStatus);
		}
		else
			Assert.assertNotSame(expected, actualStatus);
	}
	
	public void userSearch(String searchText)
	{
		String result;
		wait.until(ExpectedConditions.visibilityOf(searchTextBox));
		wait.until(ExpectedConditions.elementToBeClickable(searchTextBox));
		System.out.println("Search text is " + searchText);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", searchTextBox);
		wait.until(ExpectedConditions.elementToBeClickable(searchinputText));
		searchinputText.sendKeys(searchText);
		wait.until(ExpectedConditions.elementToBeClickable(searchResultUserId));
	 	executor.executeScript("arguments[0].click();", searchResultUserId);
		searchButton.click();
        JavascriptExecutor js = (JavascriptExecutor)driver;
		
		val = pageLoad.getAttribute("class");
		int m=0;
		while(val.contains("loading") || val.contains("loading_user") )
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		wait.until(ExpectedConditions.elementToBeClickable(searchinputText));
		if(searchText.toLowerCase().contains("@"))
		{
			wait.until(ExpectedConditions.visibilityOf(searchResultUserEmail));
			result = searchResultUserEmail.getText();
		}
		else 
		{
			wait.until(ExpectedConditions.visibilityOf(searchResultUserId));
			result = searchResultUserId.getText();
		}
		Assert.assertEquals(searchText, result);
		executor.executeScript("arguments[0].click();", searchClear);
	}
	
	public void waitForUserRow(int count)
	{
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(userTableRow));
			List<WebElement> rowCount = driver.findElements(userTableRow);
			for(int i = 0; i<=5; i++)
			{
				if(rowCount.size() != count)
				{
					Thread.sleep(10000);
					driver.navigate().refresh();
					wait.until(ExpectedConditions.visibilityOfElementLocated(userTableRow));
					rowCount = driver.findElements(userTableRow);
				}
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
	}
	
	public void clickMoreFilters()
	{
		wait.until(ExpectedConditions.visibilityOf(moreFilter));
		moreFilter.click();
	}
	
	public void selectJobFilter()
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		System.out.println("value of attribute is " + val);
		while(val.contains("loading"))
        {
        	val = pageLoad.getAttribute("class");
        	if(m==pagload)
				break;
        	m++;
        }
		try 
		{
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(userJobFilter));
			userJobFilter.click();
			wait.until(ExpectedConditions.visibilityOf(selectAllJobFilter));
			selectAllJobFilter.click();
			wait.until(ExpectedConditions.visibilityOf(moreFilterSearch));
			moreFilterSearch.click();		
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	public void selectGroupFilter()
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		System.out.println("value of attribute is " + val);
		while(val.contains("loading"))
        {
        	val = pageLoad.getAttribute("class");
        	if(m==pagload)
				break;
        	m++;
        }
		try 
		{
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(userGroupFilter));
			userGroupFilter.click();
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(selectAllGroupFilter));
			selectAllGroupFilter.click();
			wait.until(ExpectedConditions.visibilityOf(moreFilterSearch));
			moreFilterSearch.click();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	public void selectInactiveUser()
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		System.out.println("value of attribute is " + val);
		while(val.contains("loading"))
        {
        	val = pageLoad.getAttribute("class");
        	if(m==pagload)
				break;
        	m++;
        }
		try 
		{
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(userStatusFilter));
			userStatusFilter.click();
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(activeStatusFilter));
			activeStatusFilter.click();
			Thread.sleep(1000);
			wait.until(ExpectedConditions.visibilityOf(inActiveStatusFilter));
			inActiveStatusFilter.click();
			wait.until(ExpectedConditions.visibilityOf(moreFilterSearch));
			moreFilterSearch.click();
			val = pageLoad.getAttribute("class");
	        while(val.contains("loading"))
	        {
	            val = pageLoad.getAttribute("class");
	        }
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	public void searchFilter(String criteria)
	{
		if(criteria.toLowerCase().contains("job title"))
		{
			selectJobFilter();
		}
		else if(criteria.toLowerCase().contains("group"))
		{
			selectGroupFilter();
		}
		else if(criteria.toLowerCase().contains("user"))
		{
			selectInactiveUser();
		}
	}
	public static boolean checkifParmeterAvailable(String Orgid)
	{
		try {
			 PropertiesConfiguration properties = new PropertiesConfiguration(System.getProperty("user.dir") +"\\src\\test\\java\\resources\\Featureparameters"+prop.get("environment")+".properties");
	       
			 
		 return properties.containsKey(Orgid);
		 
		 } catch (Exception e) {
			System.out.println("Exception: " + e);
		} finally {
		}
		return false;
	}

	public  static String getParmeterAvailable(String Orgid)
	{
		try {
			 PropertiesConfiguration properties = new PropertiesConfiguration(System.getProperty("user.dir") +"\\src\\test\\java\\resources\\Featureparameters"+prop.get("environment")+".properties");
	       
			 
		 return properties.getString(Orgid);
		 
		 } catch (Exception e) {
			System.out.println("Exception: " + e);
		} finally {
		}
		return null;
	}
	
	
	public void searchFilterAssignmentDate(String start)
	{
		 if(checkifParmeterAvailable(start))
			 start=getParmeterAvailable(start);
		 
		 String val = pageLoad.getAttribute("class");
			int m=0;
			System.out.println("value of attribute is " + val);
			while(val.contains("loading"))
	        {
	        	val = pageLoad.getAttribute("class");
	        	if(m==pagload)
					break;
	        	m++;
	        }
			try 
			{
				JavascriptExecutor js = (JavascriptExecutor) driver;
				
				Thread.sleep(3000);
				wait.until(ExpectedConditions.visibilityOf(filter_start_date));
			
				
				
				js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", filter_start_date,"value",start);

				  LocalDateTime myDateObj = LocalDateTime.now().plusDays(1);
				    System.out.println("Before formatting: " + myDateObj);
				    DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("yyyy/MM/dd");

				    String formattedDate = myDateObj.format(myFormatObj);
				    
			
				js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", filter_to_start_date,"value",formattedDate);

				wait.until(ExpectedConditions.visibilityOf(moreCourseFilterSearch));
				moreCourseFilterSearch.click();
				val = pageLoad.getAttribute("class");
		        while(val.contains("loading"))
		        {
		            val = pageLoad.getAttribute("class");
		        }
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		 
	}
	
	public void searchFilterDueDate(String start,String From)
	{
		 ;
		
		 if(checkifParmeterAvailable(start))
			 start=getParmeterAvailable(start);
		 
		 if(checkifParmeterAvailable(From))
			 From=getParmeterAvailable(From);
		 
		 ;
		 String val = pageLoad.getAttribute("class");
			int m=0;
			System.out.println("value of attribute is " + val);
			while(val.contains("loading"))
	        {
	        	val = pageLoad.getAttribute("class");
	        	if(m==pagload)
					break;
	        	m++;
	        }
			try 
			{
				JavascriptExecutor js = (JavascriptExecutor) driver;
				
				Thread.sleep(3000);
				wait.until(ExpectedConditions.visibilityOf(filter_due_date));
			
				
				
				js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);",filter_due_date ,"value",start);

			
				js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", filter_to_due_date,"value",From);

				wait.until(ExpectedConditions.visibilityOf(moreCourseFilterSearch));
				moreCourseFilterSearch.click();
				val = pageLoad.getAttribute("class");
		        while(val.contains("loading"))
		        {
		            val = pageLoad.getAttribute("class");
		        }
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		 
	}
	
	
	
	public void clearSearch_more_filters()
	{
		try {
			String val = pageLoad.getAttribute("class");
			int m=0;
			System.out.println("value of attribute is " + val);
			while(val.contains("loading"))
	        {
	        	val = pageLoad.getAttribute("class");
	        	if(m==pagload)
					break;
	        	m++;
	        }
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(moreFilterClearSearch));
			moreFilterClearSearch.click();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	public void clickcourseFilters()
	{
		wait.until(ExpectedConditions.visibilityOf(courseFilter));
		courseFilter.click();
	}
	
	public void selectAssignmentStatusFilter(String status)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		System.out.println("value of attribute is " + val);
		while(val.contains("loading"))
        {
        	val = pageLoad.getAttribute("class");
        	if(m==pagload)
				break;
        	m++;
        }
		try 
		{
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(assignmentStatusFilter));
			assignmentStatusFilter.click();
			wait.until(ExpectedConditions.visibilityOf(unSelectAllAssignmentStatusFilter));
			unSelectAllAssignmentStatusFilter.click();
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(assignmentStatusPath + status + "')]"))));
			driver.findElement(By.xpath(assignmentStatusPath + status + "')]")).click();
			wait.until(ExpectedConditions.visibilityOf(moreCourseFilterSearch));
			moreCourseFilterSearch.click();		
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	
	public void selectAssignmentNameFilter(String name)
	{
		 if(checkifParmeterAvailable(name))
			 name=getParmeterAvailable(name);
		
		String val = pageLoad.getAttribute("class");
		int m=0;
		System.out.println("value of attribute is " + val);
		while(val.contains("loading"))
        {
        	val = pageLoad.getAttribute("class");
        	if(m==pagload)
				break;
        	m++;
        }
		try 
		{
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(assignmentNameFilter));
			assignmentNameFilter.click();
		
			wait.until(ExpectedConditions.visibilityOf(unSelectAllAssignmentNameFilter));
			unSelectAllAssignmentNameFilter.click();
			
			
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//input[contains(@title,'"+name+"')]"))));
			driver.findElement(By.xpath("//input[contains(@title,'"+name+"')]")).click();
			wait.until(ExpectedConditions.visibilityOf(moreCourseFilterSearch));
			moreCourseFilterSearch.click();		
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	public void selectCourseStatusFilter(String Coursename)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		if(courseListName.containsKey(Coursename+"Option"))
			Coursename=courseListName.get(Coursename+"Option").toString();
			
	
		System.out.println("value of attribute is " + val);
		while(val.contains("loading"))
        {
        	val = pageLoad.getAttribute("class");
        	if(m==pagload)
				break;
        	m++;
        }
		try 
		{
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(CourseFilter));
			CourseFilter.click();
			wait.until(ExpectedConditions.visibilityOf(unSelectAllCourseFilter));
			unSelectAllCourseFilter.click();
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id=\"ms-list-1\"]/div//label/input[contains(@title,'"+Coursename+"')]"))));
			driver.findElement(By.xpath("//*[@id=\"ms-list-1\"]/div//label/input[contains(@title,'"+Coursename+"')]")).click();
			wait.until(ExpectedConditions.visibilityOf(moreCourseFilterSearch));
			moreCourseFilterSearch.click();		
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	public void selectLevelFilter(String level)
	{
		if(AssignmentReport. checkifParmeterAvailable(level))
			level=AssignmentReport.getParmeterAvailable(level);

		String val = pageLoad.getAttribute("class");
		int m=0;
		System.out.println("value of attribute is " + val);
		while(val.contains("loading"))
        {
        	val = pageLoad.getAttribute("class");
        	if(m==pagload)
				break;
        	m++;
        }
		try 
		{
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(Organization));
			Organization.click();
		
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id=\"searchFilters\"]//span[text()='"+level+"']"))));
			driver.findElement(By.xpath("//*[@id=\"searchFilters\"]//span[text()='"+level+"']")).click();
		 
			wait.until(ExpectedConditions.elementToBeClickable(searchButton));
			
			searchButton.click();
			
			;
			
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	
	
	
	public void validateUserId()
	{
		String val = pageLoad.getAttribute("class");
        while(val.contains("loading"))
        {
            val = pageLoad.getAttribute("class");
        }
		wait.until(ExpectedConditions.visibilityOf(userId));
		String actualStatus = userId.getText();
		Assert.assertEquals(User.userId, actualStatus);
		
	}
	
	public void validateUserStatus(String expected)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		System.out.println("value of attribute is " + val);
		while(val.contains("loading"))
        {
        	val = pageLoad.getAttribute("class");
        	if(m==pagload)
				break;
        	m++;
        }
		wait.until(ExpectedConditions.visibilityOf(userStatus));
		String actualStatus = userStatus.getText().toLowerCase();
		Assert.assertEquals(expected.toLowerCase(), actualStatus);
		
	}
	
	public void clearSearch_course_filters()
	{
		try {
			String val = pageLoad.getAttribute("class");
			int m=0;
			System.out.println("value of attribute is " + val);
			while(val.contains("loading"))
	        {
	        	val = pageLoad.getAttribute("class");
	        	if(m==pagload)
					break;
	        	m++;
	        }
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(courseFilterClearSearch));
			courseFilterClearSearch.click();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	public void clearSearch()
	{
		try {
			String val = pageLoad.getAttribute("class");
			int m=0;
			System.out.println("value of attribute is " + val);
			while(val.contains("loading"))
	        {
	        	val = pageLoad.getAttribute("class");
	        	if(m==pagload)
					break;
	        	m++;
	        }
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(searchClear));
			searchClear.click();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	public void usersearchEmail(String unitName)
	{
		try 
		{
				if(AssignmentReport. checkifParmeterAvailable(unitName))
					 unitName=AssignmentReport.getParmeterAvailable(unitName);
		
			
//			navigateUserModule();
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchClear));
			wait.until(ExpectedConditions.elementToBeClickable(searchClear));
			searchClear.click();
			wait.until(ExpectedConditions.visibilityOf(searchText));
			wait.until(ExpectedConditions.elementToBeClickable(searchText));
			System.out.println("unit name is " + unitName);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", searchText);
			wait.until(ExpectedConditions.elementToBeClickable(searchinputText));
			
			 int cont=0;
     		 int rowCount=0;
   		while(rowCount>=1)
   		{
           List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
           rowCount = tableRows.size();
            if(cont==150)
           	 break;
            
            cont++;
       	}
				searchinputText.sendKeys(unitName);
				
			executor.executeScript("arguments[0].click();", searchButton);
			wait.until(ExpectedConditions.visibilityOf(searchResultUnitName[searchResultUnitName.length-1]));
			String result = searchResultUnitName[searchResultUnitName.length-1].getText();
			Assert.assertEquals(unitName, result);
			js = (JavascriptExecutor)driver;
			pageValue = js.executeScript("return document.readyState").toString();

      		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
      		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
      		Thread.sleep(12000);
			
     		 cont=0;
     		 int usercount=0;
   		while(rowCount!=usercount)
   		{
   			try
   			{
           List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
           usercount = tableRows.size();
   			}
   			catch(Exception e)
   			{
   				
   			}
            if(cont==150)
           	 break;
            
            cont++;
       	}
			
    		val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
			}
        
		} 
		catch (Exception e) 
		{
			
		}
	}
	public void validateAssignmentReportDueDate(String course)
    {
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
		
	
        boolean flag = false;
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 2);
        String formattedEndDate = dateFormat.format(cal.getTime());
        List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
        int rowCount = tableRows.size();
        for (int i= 1; i<= rowCount; i++)
        {
            String curriculum = reportTable + "[" + i + "]/td[4]";
            String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();

			String Email =driver.findElement(By.xpath(reportTable + "[" + i + "]/td[14]")).getText();

            if(course.toLowerCase().contains(curricuclumText.toLowerCase())&&Email.contains(User.userEmail))
            {
                String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[9]")).getText();
                System.out.println(data);
                System.out.println(formattedEndDate.trim().toLowerCase());
                Assert.assertTrue(data.trim().toLowerCase().equalsIgnoreCase(formattedEndDate.trim().toLowerCase()));
                flag = true;
                break;
            }
        }
        Assert.assertFalse(flag == false);
    }

	public void validateAssignmentReportDueDateAsValue(String date, String course)
    {
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
		course=course.replace("Â","");
		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(reportTable))));
		
        boolean flag = false;
        List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
        int rowCount = tableRows.size();
        for (int i= 1; i<= rowCount; i++)
        {
            String curriculum = reportTable + "[" + i + "]/td[4]";
            String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
            course = course.replaceAll("registered", "\u00AE");
            if(course.toLowerCase().contains(curricuclumText.toLowerCase()))
            {
                String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[9]")).getText();
                Assert.assertTrue(data.trim().toLowerCase().equalsIgnoreCase(date.trim().toLowerCase()));
                flag = true;
                break;
            }
        }
        Assert.assertFalse(flag == false);
    }
	
	public void cearSearchResult()	
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		
		js.executeScript("arguments[0].click();", searchClear);
	}
	
	public void validateOtherdetailsInactiveCourse(String course)
    {
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
		course=course.replace("Â","");
		
        
        JavascriptExecutor js = (JavascriptExecutor)driver;
		
      		val = pageLoad.getAttribute("class");
      		int m=0;
      		while(val.contains("loading") || val.contains("loading_user") )
      		{
      			val = pageLoad.getAttribute("class");
      			if(m==pagload)
      				break;
      			m++;
      		}
      		
      		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
     
	
        LocalDate localDate = LocalDate.now();
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd");        
        String formattedEndDate = localDate.format(dateFormat);
        List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
        String[] expectedValues = {User.userId,"G","Ansh",Assignments.AssgnmentName, formattedEndDate,"NA", "Active","Organization",TestBase.prop.getProperty("orgName"),
                "NA", User.userEmail};
        String actualValue[] = new String[expectedValues.length];
        int rowCount = tableRows.size();
        for (int i= 1; i<= rowCount; i++)
        {
            String curriculum = reportTable + "[" + i + "]/td[4]";
            String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
            course = course.replaceAll("registered", "\u00AE");
            if(course.toLowerCase().contains(curricuclumText.toLowerCase()))
            {
                List<WebElement> column = driver.findElements(By.xpath(reportTable + "[" + i + "]/td"));
                int columnCount = column.size();
                int k = 1;
                for(int j = 1; j <= columnCount; j++)
                {
                    if(!(j == 4 || j == 6 || j == 7))
                    {
                        String value = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[" + j + "]" )).getText();
                        actualValue[j-k] = value;
                        System.out.println(actualValue[j-k].trim() + " " + expectedValues[j-k].trim());
                        Assert.assertTrue(actualValue[j-k].trim().equalsIgnoreCase(expectedValues[j-k].trim()));
                    }
                    else    
                    {
                        k++;
                        continue;
                    }
                        
                    
                        
                }
            }
        }
        
    }


   public void validateAssignmentReportActivationDateAsValue(String date, String course)
    {
	   
	   if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
		course=course.replace("Â","");
		  JavascriptExecutor js = (JavascriptExecutor)driver;
			
			val = pageLoad.getAttribute("class");
			int m=0;
			while(val.contains("loading") || val.contains("loading_user") )
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			
			
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			
        boolean flag = false;
        LocalDate localDate = LocalDate.now();
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd");        
        String formattedEndDate = localDate.format(dateFormat);
        List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
        int rowCount = tableRows.size();
        for (int i= 1; i<= rowCount; i++)
        {
            String curriculum = reportTable + "[" + i + "]/td[4]";
            String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
            course = course.replaceAll("registered", "\u00AE");
            if(course.toLowerCase().contains(curricuclumText.toLowerCase()))
            {
                String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[6]")).getText();
                if(!date.equalsIgnoreCase("na"))
                    Assert.assertTrue(data.trim().toLowerCase().equalsIgnoreCase(formattedEndDate.trim().toLowerCase()));
                else
                    Assert.assertTrue(data.trim().toLowerCase().equalsIgnoreCase("na"));
                flag = true;
                break;
            }
        }
        Assert.assertFalse(flag == false);
    }
   
   public void clickMoreFilter()
	{
		try
		{
			Thread.sleep(5000);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(moreFilter));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", moreFilter);
			Thread.sleep(2000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

   public void validateUserStatusFilterAvailability()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(userStatusFilter));
		userStatusFilter.click();
	}
   public void validateJobFilterFilterAvailability()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(jobFilter));
		jobFilter.click();
	}

   public void validateGroupFilterFilterAvailability()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(groupFilter));
		groupFilter.click();
	}

   public void selectSingleUserStatusFilter(String status)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userStatus1 + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userStatus1));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userStatus1 + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == true)
				driver.findElement(By.xpath("(" + userStatus1 + "/input)[" + i + "]")).click();
		}
		driver.findElement(By.xpath(userStatus1 + "//input[contains(@title,'" + status + "')]")).click();
	}

   public void clickOnMoreFilterSearchButton() throws InterruptedException
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(moreFilterSearchButton));
		moreFilterSearchButton.click();
		Thread.sleep(2000);
	}
   public void validateRecordAvailable()
	{
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			counter = 0;
			 JavascriptExecutor js = (JavascriptExecutor)driver;
				
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		String text = driver.findElement(By.xpath(reportTable + "[1]/td[1]")).getText();
		System.out.println(text);
		Assert.assertFalse(text.equals("No reports data found."));
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
   public void selectMultiUserStatusFilter(String status)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userStatus1 + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userStatus1));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath(userStatus1 + "//input[contains(@title,'" + status + "')]"));
			boolean flag = elem.isSelected();
			if(flag == false)
				driver.findElement(By.xpath(userStatus1 + "//input[contains(@title,'" + status + "')]")).click();
		}
		
	}
   public void unSelectAllStatus()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userUnSelectAll));
			userUnSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
   public void selectAllStatus()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userSelectAll));
			userSelectAll.click();
			Thread.sleep(2000);
			userSelectdropdown.click();
			;
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
   public void searchUserStatus(String status)
	{
		try {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(userFilterSearch));
		int counter = 0;
		userFilterSearch.click();
		userFilterSearch.clear();
		userFilterSearch.sendKeys(status);
		List<WebElement> statusList = driver.findElements(By.xpath(userStatus1 + "/parent::li[not(contains(@class,'hidden'))]"));
		while(statusList.size() > 1)
		{
			statusList = driver.findElements(By.xpath(userStatus1 + "/parent::li[not(contains(@class,'hidden'))]"));
			Thread.sleep(2000);
			if(counter > 12)
				Assert.fail("Search functionality for user status is not working");
			counter++;
		}
		driver.findElement(By.xpath(userStatus1 + "//input[contains(@title,'" + status + "')]")).click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
		
	}
   
   public void selectSingleUserJobFilter()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userJobFilter1 + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userJobFilter1));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userJobFilter1 + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == true)
				driver.findElement(By.xpath("(" + userJobFilter1 + "/input)[" + i + "]")).click();
		}
		driver.findElement(By.xpath(userJobFilter1 + "//input[contains(@title,'" + OrganizationSettings.titleName + "')]")).click();
	}
	
   public void selectMultiUserJobFilter()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userJobFilter1 + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userJobFilter1));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userJobFilter1 + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == false) {
				driver.findElement(By.xpath("(" + userJobFilter1 + "/input)[" + i + "]")).click();
				break;
			}
		}
		
	}

   public void unSelectAllJobFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			List<WebElement> statusList = driver.findElements(By.xpath(userJobFilter1));
			for(int i = 1; i <= statusList.size(); i++)
			{
				WebElement elem = driver.findElement(By.xpath("(" + userJobFilter1 + "/input)[" + i + "]"));
				boolean flag = elem.isSelected();
				if(flag == false)
					driver.findElement(By.xpath("(" + userJobFilter1 + "/input)[" + i + "]")).click();
			}
			wait.until(ExpectedConditions.visibilityOf(jobFilterUnSelectAll));
			jobFilterUnSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
   
	public void selectAllJobFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(jobFilterSelectAll));
			jobFilterSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void searchJobFilter()
	{
		try {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(jobFilterFilterSearch));
		int counter = 0;
		jobFilterFilterSearch.click();
		jobFilterFilterSearch.clear();
		jobFilterFilterSearch.sendKeys(OrganizationSettings.titleName);
		List<WebElement> statusList = driver.findElements(By.xpath(userJobFilter1 + "/parent::li[not(contains(@class,'hidden'))]"));
		while(statusList.size() > 1)
		{
			statusList = driver.findElements(By.xpath(userJobFilter1 + "/parent::li[not(contains(@class,'hidden'))]"));
			Thread.sleep(2000);
			if(counter > 12)
				Assert.fail("Search functionality for user status is not working");
			counter++;
		}
		driver.findElement(By.xpath(userJobFilter1 + "//input[contains(@title,'" + OrganizationSettings.titleName + "')]")).click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
		
	}
	
	
	String userGroupFilter1 = "(//select[@id = 'group_id']//following-sibling::div//ul//label)";
	
	

	public void selectSingleUserGroupFilter()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userGroupFilter1 + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userGroupFilter1));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userGroupFilter1 + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == true)
				driver.findElement(By.xpath("(" + userGroupFilter1 + "/input)[" + i + "]")).click();
		}
		driver.findElement(By.xpath(userGroupFilter1 + "//input[contains(@title,'" + OrganizationSettings.groupName + "')]")).click();
	}

	public void selectMultiUserGroupFilter()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userGroupFilter1 + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userGroupFilter1));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userGroupFilter1 + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == false) {
				driver.findElement(By.xpath("(" + userGroupFilter1 + "/input)[" + i + "]")).click();
				break;
			}
		}
		
	}

	public void unSelectAllGroupFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			List<WebElement> statusList = driver.findElements(By.xpath(userGroupFilter1));
			for(int i = 1; i <= statusList.size(); i++)
			{
				WebElement elem = driver.findElement(By.xpath("(" + userGroupFilter1 + "/input)[" + i + "]"));
				boolean flag = elem.isSelected();
				if(flag == false)
					driver.findElement(By.xpath("(" + userGroupFilter1 + "/input)[" + i + "]")).click();
			}
			wait.until(ExpectedConditions.visibilityOf(groupFilterUnSelectAll));
			groupFilterUnSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void selectAllGroupFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(groupFilterSelectAll));
			groupFilterSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void searchGroupFilter()
	{
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(groupFilterFilterSearch));
		counter = 0;
		groupFilterFilterSearch.click();
		groupFilterFilterSearch.clear();
		groupFilterFilterSearch.sendKeys(OrganizationSettings.groupName2);
		List<WebElement> statusList = driver.findElements(By.xpath(userGroupFilter1 + "/parent::li[not(contains(@class,'hidden'))]"));
		while(statusList.size() > 1)
		{
			statusList = driver.findElements(By.xpath(userGroupFilter1 + "/parent::li[not(contains(@class,'hidden'))]"));
			Thread.sleep(2000);
			if(counter > 12)
				Assert.fail("Search functionality for user status is not working");
			counter++;
		}
		driver.findElement(By.xpath(userGroupFilter1 + "//input[contains(@title,'" + OrganizationSettings.groupName2 + "')]")).click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
		
	}
	public void validateUserSearchFilterOptions()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(userSearchLabel));
		wait.until(ExpectedConditions.visibilityOf(userSearchInput));
	}

	public void validateOrgLevelFilterOptions()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(orgLevelLabel));
		wait.until(ExpectedConditions.visibilityOf(orgLevelDropdown));
	}
	
	public void validateUnitLevelFilterOptions()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(unitLevelLabel));
	}
	public void selectOrgLevelMainFilter(int level)
	{
		try
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int counter = 0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userSearchLabel));
			Select select = new Select(selectOrgLevelDropdown);
			select.selectByIndex(level - 1);
			val = pageLoad.getAttribute("class");
			counter = 0;
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(2000);
				counter++;
				if(counter>30)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			js.executeScript("arguments[0].click();", searchButton);
			counter = 0;
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(2000);
				counter++;
				if(counter>30)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	
	public void clickCourseFilter()
	{
		try
		{
			Thread.sleep(5000);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(courseFilter));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", courseFilter);
			Thread.sleep(2000);
		}
		catch(Exception e)
		{e.printStackTrace();
			
		}
	}
	
	public void validateCourseStatusFilterAvailability(String label)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		Assert.assertTrue(driver.findElement(By.xpath(courseFilterLabel + label + "')]")).isDisplayed());
		wait.until(ExpectedConditions.visibilityOf(courseStatusFilter));
		courseStatusFilter.click();
	}

	public void validateAssignmentStatusFilterAvailability(String label)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		Assert.assertTrue(driver.findElement(By.xpath(courseFilterLabel + label + "')]")).isDisplayed());
		wait.until(ExpectedConditions.visibilityOf(assignmentStatusFilter));
		assignmentStatusFilter.click();
	}
	
	public void validateAssignmentDateFilterAvailability(String label)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		Assert.assertTrue(driver.findElement(By.xpath(courseFilterLabel + label + "')]")).isDisplayed());
		wait.until(ExpectedConditions.visibilityOf(assignmentFromDate));
		assignmentFromDate.click();
		wait.until(ExpectedConditions.visibilityOf(assignmentToDate));
		assignmentToDate.click();
	}

	public void validateAssignmentDueDateFilterAvailability(String label)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		Assert.assertTrue(driver.findElement(By.xpath(courseFilterLabel + label + "')]")).isDisplayed());
		wait.until(ExpectedConditions.visibilityOf(assignmentFromDueDate));
		assignmentFromDueDate.click();
		wait.until(ExpectedConditions.visibilityOf(assignmentToDueDate));
		assignmentToDueDate.click();
	}

	public void clickOnCourseFilterSearchButton()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(courseFilterSearchButton));
		courseFilterSearchButton.click();
	}
	
	public void selectSingleUserCourseFilter(String courseName)
	{
		if(courseListName.containsKey(courseName+"Option"))
    		courseName=courseListName.get(courseName+"Option").toString();
	
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userCourseFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userCourseFilter));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userCourseFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == true)
				driver.findElement(By.xpath("(" + userCourseFilter + "/input)[" + i + "]")).click();
		}
		driver.findElement(By.xpath(userCourseFilter + "//input[contains(@title,'" + courseName + "')]")).click();
	}
	
	public void selectMultiUserCourseFilter()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userCourseFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userCourseFilter));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userCourseFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == false) {
				driver.findElement(By.xpath("(" + userCourseFilter + "/input)[" + i + "]")).click();
				break;
			}
		}
		
	}

	public void unSelectAllCourseFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			List<WebElement> statusList = driver.findElements(By.xpath(userCourseFilter));
			for(int i = 1; i <= statusList.size(); i++)
			{
				WebElement elem = driver.findElement(By.xpath("(" + userCourseFilter + "/input)[" + i + "]"));
				boolean flag = elem.isSelected();
				if(flag == false)
					driver.findElement(By.xpath("(" + userCourseFilter + "/input)[" + i + "]")).click();
			}
			wait.until(ExpectedConditions.visibilityOf(courseFilterUnSelectAll));
			courseFilterUnSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void selectAllCourseFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(courseFilterSelectAll));
			courseFilterSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void searchCourseFilter(String courseName)
	{
		try {

	    	if(courseListName.containsKey(courseName+"Option"))
	    		courseName=courseListName.get(courseName+"Option").toString();
		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(courseFilterFilterSearch));
		int counter = 0;
		courseFilterFilterSearch.click();
		courseFilterFilterSearch.clear();
		courseFilterFilterSearch.sendKeys(courseName);
		List<WebElement> statusList = driver.findElements(By.xpath(userCourseFilter + "/parent::li[not(contains(@class,'hidden'))]"));
		while(statusList.size() > 1)
		{
			statusList = driver.findElements(By.xpath(userCourseFilter + "/parent::li[not(contains(@class,'hidden'))]"));
			Thread.sleep(2000);
			if(counter > 12)
				Assert.fail("Search functionality for user status is not working");
			counter++;
		}
		driver.findElement(By.xpath(userCourseFilter + "//input[contains(@title,'" + courseName + "')]")).click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
		
	}

	public void validateAssignmentNameFilterAvailability(String label)
	{
		try {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		val = pageLoad.getAttribute("class");
		int counter = 0;
		while(val.equalsIgnoreCase("loading_compliance"))
		{
			val = pageLoad.getAttribute("class");
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load page after waiting for 1 minute");
		}
		Thread.sleep(2000);
//		Assert.assertTrue(driver.findElement(By.xpath(assignmentFilterLabel + label + "')])[1]")).isDisplayed());
		wait.until(ExpectedConditions.visibilityOf(assignmentNameFilter));
		assignmentNameFilter.click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
	}
	public void validateHeader()
	{
		try {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		val = pageLoad.getAttribute("class");
		int counter= 0;
		while(val.equalsIgnoreCase("loading_compliance"))
		{
			val = pageLoad.getAttribute("class");
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load page after waiting for 1 minute");
		}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableHeader + "[1]"))));
		List<WebElement> headerList = driver.findElements(By.xpath(tableHeader));
		
		String[] headerData = new String[headerList.size()];
		for(int i = 1; i <= headerList.size(); i++)
		{
			headerData[i-1] = headerList.get(i-1).getText();
			if(i == 7)
				scrollRight();
		}
		String expectedHeader[] = {"User ID", "Last Name", "First Name", "Course", "Assignment", "Activation Date", "Assignment Status",
				"Assignment Date","Due Date", "User Status", "Unit Level", "Unit Name", "Job Title", "Email"};
		for(int i = 0; i <= expectedHeader.length - 1; i++)
		{
			expectedHeader[i] = expectedHeader[i].toUpperCase();
		}
		System.out.println("The actual displaying data " + headerData);
		System.out.println("The app headerdata expected " + expectedHeader);
		boolean flag = Arrays.equals(headerData, expectedHeader);
		System.out.println(flag);
		Assert.assertTrue(flag);
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
	public void scrollRight()
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
		executor.executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", scrollArea);
	}
	public void validateRecordNotAvailableCount()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(reportTable + "/td[1]"))));
		String text = driver.findElement(By.xpath(reportTable + "/td[1]")).getText();
		System.out.println(text);
		Assert.assertTrue(text.equalsIgnoreCase("No reports data found."));
	}

	
	@FindBy(xpath = "//select[@id = 'assignments']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement assignmentFilterUnSelectAll;
	
	@FindBy(xpath = "//select[@id = 'assignments']//following-sibling::div//a[text() = 'Select all']")
	WebElement assignmentFilterSelectAll;
	
	@FindBy(xpath = "(//select[@id = 'assignments']//following-sibling::div)//input[@type= 'text']")
	WebElement assignmentsFilterFilterSearch;
	
	String userAssignmentFilter = "(//select[@id = 'assignments']//following-sibling::div//ul//label)";
	
	
		
	public void selectSingleUserAssignmentFilter()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userAssignmentFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userAssignmentFilter));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userAssignmentFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == true)
				driver.findElement(By.xpath("(" + userAssignmentFilter + "/input)[" + i + "]")).click();
		}
		driver.findElement(By.xpath(userAssignmentFilter + "//input[contains(@title,'" + Assignments.titleName + "')]")).click();
	}
	
	public void selectMultiUserAssignmentFilter()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userAssignmentFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userAssignmentFilter));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userAssignmentFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == false) {
				driver.findElement(By.xpath("(" + userAssignmentFilter + "/input)[" + i + "]")).click();
				break;
			}
		}
		
	}

	public void unSelectAllAssignmentFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			List<WebElement> statusList = driver.findElements(By.xpath(userAssignmentFilter));
			for(int i = 1; i <= statusList.size(); i++)
			{
				WebElement elem = driver.findElement(By.xpath("(" + userAssignmentFilter + "/input)[" + i + "]"));
				boolean flag = elem.isSelected();
				if(flag == false)
					driver.findElement(By.xpath("(" + userAssignmentFilter + "/input)[" + i + "]")).click();
			}
			wait.until(ExpectedConditions.visibilityOf(assignmentFilterUnSelectAll));
			assignmentFilterUnSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void selectAllAssignmentFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(assignmentFilterSelectAll));
			assignmentFilterSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void searchAssignmentFilter()
	{
		try {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(assignmentsFilterFilterSearch));
		int counter = 0;
		assignmentsFilterFilterSearch.click();
		assignmentsFilterFilterSearch.clear();
		assignmentsFilterFilterSearch.sendKeys(Assignments.titleName);
		List<WebElement> statusList = driver.findElements(By.xpath(userAssignmentFilter + "/parent::li[not(contains(@class,'hidden'))]"));
		while(statusList.size() > 1)
		{
			statusList = driver.findElements(By.xpath(userAssignmentFilter + "/parent::li[not(contains(@class,'hidden'))]"));
			Thread.sleep(2000);
			if(counter > 12)
				Assert.fail("Search functionality for user status is not working");
			counter++;
		}
		driver.findElement(By.xpath(userAssignmentFilter + "//input[contains(@title,'" + Assignments.titleName + "')]")).click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
		
	}
		
	public void validatePageNumbers()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(rowPerPageSelect));
		int paginationOption = driver.findElements(By.xpath(pagination)).size();
		System.out.println("Pagination option available on progress report is " + paginationOption);
		Assert.assertTrue(paginationOption == 2);
	}
	
	public void getLocationPageNumber()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(rowPerPageSelect));
		List<WebElement> statusList = driver.findElements(By.xpath(pagination));
		Point location1 = null, location2 = null;
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath(pagination + "[" + i + "]"));
			System.out.println(elem.getLocation());
			if(location1 == null)
				location1 = elem.getLocation();
			else if(location2 == null)
				location2 = elem.getLocation();	
		}
		Assert.assertFalse(location1 == location2);
		int x1 = location1.getX();
		int x2 = location2.getX();
		Assert.assertTrue(x1 == x2);
		int y1 = location1.getY();
		int y2 = location2.getY();
		Assert.assertFalse(y1 == y2);
	}
	public void validatePaginationDropdown()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(rowPerPageSelect));
		Select select = new Select(rowPerPageSelect);
		List<WebElement> values = select.getOptions();
		for(int i = 0; i <= values.size() - 1; i++)
		{
			int value = Integer.parseInt(values.get(i).getText());
			Assert.assertTrue(value%25 == 0);
		}
	}
	
	public void selectPaginationDropdown()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(rowPerPageSelect));
		Select select = new Select(rowPerPageSelect);
		List<WebElement> values = select.getOptions();
		for(int i = 0; i <= values.size() - 1; i++)
		{
			int value = Integer.parseInt(values.get(i).getText());
			if(value == 50) {
				values.get(i).click();
				break;
			}
		}
		validateRowCount(50);
	}
	public void validateRowCount(int count)
	{
		try {
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		int counter = 0;
		while(val.equalsIgnoreCase("loading_compliance"))
		{
			val = pageLoad.getAttribute("class");
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load page after waiting for 1 minute");
		}
		Thread.sleep(5000);
		List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
		int rowCount = tableRows.size();

		if(rowCount == count)
			Assert.assertTrue(rowCount == count);
		else
		{
			List<WebElement> pageNumber = driver.findElements(By.xpath(pagination + "[1]/span/a"));
			Assert.assertTrue(pageNumber.size() == 1);
		}

		}
		catch(Exception e) {
			
		}
	}
	public void clickExportButton()
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(exportButton));
			int counter = 0;
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			if(driver.findElements(By.xpath(enableExportButton)).size()>0)
				js.executeScript("arguments[0].click();", exportButton);
			else
				Assert.fail("Export button is diabled as no record is available");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	public void verifyDownloadFile()
	{
		try 
		{
			usr = new User();
			int counter = 0;
			boolean dwnld = false;
			do 
			{
				Thread.sleep(5000);
				dwnld = usr.isFileDownloaded_Ext(downloadPath, ".csv");
				counter = counter +1;
				if(counter > 24)
					Assert.fail("Not able to download file");
			}
			while(dwnld == false);
		} 
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}
	}

	public void compareDetails()
	{
		try
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String  uiList[][];
			int counter = 0;
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(reportTable))));
			List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
			List<List<String>> list_UI = new ArrayList<>();
			List<List<String>> list_report = new ArrayList<>();
			File file = new File(User.filePath);
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			List<String[]> header = csvReader.readAll();
			int rowCount = tableRows.size();
			uiList = new String[rowCount][14];
			String reportDetails[][] = new String[header.size() - 2][14];
			for (int i= 1; i<= rowCount; i++)
			{
				for(int j = 1; j <= 14; j++)
				{
					String textValue = driver.findElement(By.xpath("(" + reportTable + ")[" + i + "]/td[" + j + "]")).getText();
					uiList[i-1][j-1] = textValue;
				}
			}
			for (String[] ints : uiList) 
			{
				list_UI.add(Arrays.asList(ints));
			}
			for(int i = 1; i < header.size() - 2; i++)
			{
				String []excel = header.get(i+2);
				System.out.println(i);
				String []excelValues = excel[0].split(";");
				for(int j = 0; j <= 13; j++)
				{
					reportDetails[i-1][j] = excelValues[j].replace("\"", "").trim();
				}				
			}
			csvReader.close();
			for (String[] ints : reportDetails) {
				list_report.add(Arrays.asList(ints));
			}
			List<List<String>> differences = new ArrayList<>(list_UI);
			differences.removeAll(list_report);
			Assert.assertTrue(differences.size() == 0);
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	public void validateDefaultUserStatusFilter(String status)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userStatus1 + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userStatus1));
		boolean flag = false;
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath(userStatus1 + "//input[contains(@title,'" + status + "')]"));
			flag = elem.isSelected();
			if(flag == true)
				break;
		}
		Assert.assertTrue(flag);
	}
	
	@FindBy(xpath = "//select[@id = 'assignment_status']//following-sibling::div/button")
	WebElement assignmentStatusNameFilter;
	
	@FindBy(xpath = "//select[@id = 'assignment_status']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement assignmentStatusFilterUnSelectAll;
	
	@FindBy(xpath = "//select[@id = 'assignment_status']//following-sibling::div//a[text() = 'Select all']")
	WebElement assignmentStatusFilterSelectAll;
	
	@FindBy(xpath = "(//select[@id = 'assignment_status']//following-sibling::div)//input[@type= 'text']")
	WebElement assignmentStatusFilterFilterSearch;
	
	String assignmentStatusFilterLabel = "//label[contains(text(), '";
	String userAssignmentStatusFilter = "(//select[@id = 'assignment_status']//following-sibling::div//ul//label)";
	JavascriptExecutor js = (JavascriptExecutor)driver;
	
	public void validateAssignmentStatusNameFilterAvailability(String label)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		Assert.assertTrue(driver.findElement(By.xpath(assignmentStatusFilterLabel + label + "')]")).isDisplayed());
		wait.until(ExpectedConditions.visibilityOf(assignmentStatusNameFilter));
		assignmentStatusNameFilter.click();
	}
		
	public void selectSingleUserAssignmentStatusFilter(String status)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userAssignmentStatusFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userAssignmentStatusFilter));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userAssignmentStatusFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == true)
				driver.findElement(By.xpath("(" + userAssignmentStatusFilter + "/input)[" + i + "]")).click();
		}
		driver.findElement(By.xpath(userAssignmentStatusFilter + "//input[contains(@title,'" + status + "')]")).click();
	}
	
	public void selectMultiUserAssignmentStatusFilter()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userAssignmentStatusFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userAssignmentStatusFilter));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userAssignmentStatusFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == false) {
				driver.findElement(By.xpath("(" + userAssignmentStatusFilter + "/input)[" + i + "]")).click();
				break;
			}
		}
		
	}

	public void unSelectAllAssignmentStatusFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			List<WebElement> statusList = driver.findElements(By.xpath(userAssignmentStatusFilter));
			for(int i = 1; i <= statusList.size(); i++)
			{
				WebElement elem = driver.findElement(By.xpath("(" + userAssignmentStatusFilter + "/input)[" + i + "]"));
				boolean flag = elem.isSelected();
				if(flag == false)
					driver.findElement(By.xpath("(" + userAssignmentStatusFilter + "/input)[" + i + "]")).click();
			}
			wait.until(ExpectedConditions.visibilityOf(assignmentStatusFilterUnSelectAll));
			assignmentStatusFilterUnSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void selectAllAssignmentStatusFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(assignmentStatusFilterSelectAll));
			assignmentStatusFilterSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void searchAssignmentStatusFilter(String status)
	{
		try {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(assignmentStatusFilterFilterSearch));
		int counter = 0;
		assignmentStatusFilterFilterSearch.click();
		assignmentStatusFilterFilterSearch.clear();
		assignmentStatusFilterFilterSearch.sendKeys(status);
		List<WebElement> statusList = driver.findElements(By.xpath(userAssignmentStatusFilter + "/parent::li[not(contains(@class,'hidden'))]"));
		while(statusList.size() > 1)
		{
			statusList = driver.findElements(By.xpath(userAssignmentStatusFilter + "/parent::li[not(contains(@class,'hidden'))]"));
			Thread.sleep(2000);
			if(counter > 12)
				Assert.fail("Search functionality for user status is not working");
			counter++;
		}
		driver.findElement(By.xpath(userAssignmentStatusFilter + "//input[contains(@title,'" + status + "')]")).click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
		
	}
	
	@FindBy(xpath = "//input[@id = 'from_due_date']")
	WebElement fromDueDate;
	
	@FindBy(xpath = "//input[@id = 'to_due_date']")
	WebElement toDueDate;
	
	public String changeDateAsPerTime(int num, String time)
	{
		LocalDate localDate = LocalDate.now();
		LocalDate requiredDate = null;
		if(time.equalsIgnoreCase("days"))
		{
			requiredDate = localDate.plusDays(num);
		}
		else if(time.equalsIgnoreCase("month"))
		{
			requiredDate = localDate.plusMonths(num);
		}
		else if(time.equalsIgnoreCase("year"))
		{
			requiredDate = localDate.plusYears(num);
		}
		return requiredDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd")).toString();
	}	
	
	public void enterFromAssignmentDueDate(int num, String time)
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(5000);
			String date = changeDateAsPerTime(num, time);
			System.out.println(date);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(fromDueDate));
			js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", fromDueDate,"value",date);
		}
		catch(Exception e)
		{
			Assert.fail("Issue in hire date selection");
		}
	}

	public void enterToAssignmentDueDateQuarterEnd(int quarter)
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(5000);
			String date = changeDate(quarter);
			System.out.println(date);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(fromDueDate));
			js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", toDueDate,"value",date);
		}
		catch(Exception e)
		{
			Assert.fail("Issue in hire date selection");
		}
	}
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	@FindBy(xpath = "//input[@id = 'from_start_date']")
	WebElement fromStartDate;
	
	@FindBy(xpath = "//input[@id = 'to_start_date']")
	WebElement toStartDate;
	
	public void enterFromAssignmentStartDate(int num, String time)
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(5000);
			String date = changeDateAsPerTime(num, time);
			System.out.println(date);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(fromDueDate));
			js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", fromStartDate,"value",date);
		}
		catch(Exception e)
		{
			Assert.fail("Issue in hire date selection");
		}
	}

	public void enterToAssignmentStartDateQuarterEnd(int quarter)
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(5000);
			String date = changeDate(quarter);
			System.out.println(date);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(fromDueDate));
			js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", toStartDate,"value",date);
		}
		catch(Exception e)
		{
			Assert.fail("Issue in hire date selection");
		}
	}
	public String changeDate(int quarter)
	{
		
		LocalDate localDate = LocalDate.now();
		LocalDate firstDayOfQuarter = localDate.with(localDate.getMonth().firstMonthOfQuarter()).with(TemporalAdjusters.firstDayOfMonth());
		LocalDate lastDayOfQuarter;
		lastDayOfQuarter = firstDayOfQuarter.plusMonths(quarter*3).plusMonths(2).with(TemporalAdjusters.lastDayOfMonth());
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd");		
		String formattedEndDate = lastDayOfQuarter.format(dateFormat);//dateFormat.format(lastDayOfQuarter);
		return formattedEndDate;
	}
	
}
