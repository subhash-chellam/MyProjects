package com.qa.pages;

import java.util.ArrayList;

import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.util.TestBase;

public class SFTP extends TestBase
{
	@FindBy(xpath = "//a[contains(text(), 'SFTP Settings')]")
	WebElement setting;
	
	@FindBy(xpath = "//input[@name = 'sftp_password']")
	WebElement passwordText;
	
	
			
	@FindBy(xpath = "//input[@id='custom_sftp_login']")
	WebElement sftp_username;
	
			
	@FindBy(xpath = "//input[@name='custom_sftp_password']")
	WebElement sftppasswordText;



	@FindBy(xpath = "//*[@id='sftp_csv']")
	WebElement sftp_csv;


	@FindBy(xpath = "//*[@id='custom_ftp_btn']")
	WebElement custom_ftp_btn;

	@FindBy(xpath = "//button[text() = 'Create SFTP Account']")
	WebElement createButton;
	
	@FindBy(xpath = "//button[text() = 'Activate']")
	WebElement activateButton;
	
	@FindBy(xpath = "//button[text() = 'Yes']")
	WebElement yesButton;
	
	@FindBy(xpath = "//button[text() = 'Show Password']")
	WebElement showPasswordButton;
	
	@FindBy(xpath = "//button[text() = 'Hide Password']")
	WebElement hidePasswordButton;
	
	@FindBy(xpath = "//div[@id = 'sftpPassword']")
	WebElement passwordLabel;


	
	@FindBy(xpath = "//*[@id='sftp_host']")
	WebElement sftp_host;

	
		
	@FindBy(xpath = "//a[contains(text(),'Completion Report Settings')]")
	WebElement CompletionReportTab;


	@FindBy(xpath = "//*[@id='custom_sftp_host']")
	WebElement sftpHost;

	
	
	@FindBy(xpath = "//*[@id='custom_sftp_port']")
	WebElement sftp_port;

	

	@FindBy(xpath = "//*[@id='file_path']")
	WebElement file_path;

	@FindBy(xpath = "//*[@id='report_file_path']")
	WebElement file_name;

	

	static public String sftp;
	String oldTab, newTab;
	public SFTP() 
	{
		PageFactory.initElements(driver, this);
	}

	public void clickSFTP()
	{
		ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
		oldTab = tabs.get(0);
		newTab = tabs.get(1);
	    driver.switchTo().window(newTab);
		wait.until(ExpectedConditions.visibilityOf(setting));
		setting.click();
	}

	public void enterPassword()
	{
		try {
			wait.until(ExpectedConditions.visibilityOf(passwordText));
			passwordText.click();
			passwordText.sendKeys("1234567890");
			sftp=sftp_host.getAttribute("value");
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void CompletionReportTab()
	{
		ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
		oldTab = tabs.get(0);
		newTab = tabs.get(1);
	    driver.switchTo().window(newTab);
	
		wait.until(ExpectedConditions.visibilityOf(CompletionReportTab));
		CompletionReportTab.click();
		
	}

	public void ConfigureCompletionReport(String password,String username,String host,String port,String path,String name)
	{
		
		
		wait.until(ExpectedConditions.visibilityOf(sftp_csv));
		sftp_csv.click();
		wait.until(ExpectedConditions.visibilityOf(sftppasswordText));
		sftppasswordText.sendKeys(password);
		wait.until(ExpectedConditions.visibilityOf(sftp_username));
		sftp_username.sendKeys(username);
		wait.until(ExpectedConditions.visibilityOf(sftpHost));

		sftpHost.sendKeys(host);
		wait.until(ExpectedConditions.visibilityOf(sftp_port));

		sftp_port.sendKeys(port);
		wait.until(ExpectedConditions.visibilityOf(file_path));

		file_path.sendKeys(path);
		wait.until(ExpectedConditions.visibilityOf(file_name));

		file_name.sendKeys(name);

		wait.until(ExpectedConditions.visibilityOf(custom_ftp_btn));

		custom_ftp_btn.click();
		
	}
	public void clickCreateAccount()
	{
		wait.until(ExpectedConditions.visibilityOf(createButton));
		wait.until(ExpectedConditions.elementToBeClickable(createButton));
		createButton.click();
	}

	public void clickActivateAccount()
	{
		wait.until(ExpectedConditions.visibilityOf(activateButton));
		wait.until(ExpectedConditions.elementToBeClickable(activateButton));
		activateButton.click();
	}
	
	public void clickActivateYes()
	{
		WebDriverWait wait = new WebDriverWait(driver, 300);
		wait.until(ExpectedConditions.visibilityOf(yesButton));
		wait.until(ExpectedConditions.elementToBeClickable(yesButton));
		yesButton.click();
	}
	
	public void clickShowPassword()
	{
		WebDriverWait wait = new WebDriverWait(driver, 300);
		wait.until(ExpectedConditions.visibilityOf(showPasswordButton));
		showPasswordButton.click();
		wait.until(ExpectedConditions.visibilityOf(hidePasswordButton));
		Assert.assertTrue(passwordLabel.isDisplayed());
	}
	
	public void clickHidePassword()
	{
		WebDriverWait wait = new WebDriverWait(driver, 300);
		wait.until(ExpectedConditions.visibilityOf(hidePasswordButton));
		wait.until(ExpectedConditions.elementToBeClickable(hidePasswordButton));
		hidePasswordButton.click();
		wait.until(ExpectedConditions.visibilityOf(showPasswordButton));
		Assert.assertFalse(passwordLabel.isDisplayed());
	}

	public void closeTab()
	{
		driver.close();
		driver.switchTo().window(oldTab);
	}
}
