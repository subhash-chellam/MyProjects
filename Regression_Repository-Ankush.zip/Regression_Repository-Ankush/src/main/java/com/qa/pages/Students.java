package com.qa.pages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.python.modules.thread.thread;

import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.qa.util.TestBase;
import com.qa.util.TestUtils;

import groovyjarjarantlr4.v4.codegen.model.ExceptionClause;

public class Students extends TestBase
{
	OrganizationHome org;
	
	@FindBy(xpath = "//a[text() = 'Manage Students']")
	WebElement manageStudentTab;
	
	@FindBy(xpath = "//a[text() = 'Import Demographic Data']")
	WebElement importDataLink;
	
	@FindBy(xpath = "//a[contains(text() , 'download a formatted blank')]")
	public WebElement downloadFileLink;
	
	
	
		
	@FindBy(xpath = "//a[@id = 'selFile']")
	WebElement uploadedFile;
	
	@FindBy(xpath = "//a[text() = 'Choose file']")
	WebElement chooseFileLink;
	
	@FindBy(xpath = "//a[text() = 'Upload ']")
	WebElement uploadFileLink;
	
	@FindBy(xpath = "//th[@class = 'failurecount']")
	WebElement failureCount;
	
	@FindBy(xpath = "(//div[@class = 'btndiv']/a[text() = 'Close'])[1]")
	WebElement buttonClose;
	
	@FindBy(xpath = "//input[@name='unit_name']")
	WebElement searchTextUnitName;
	
	@FindBy(xpath = "//button[@id = 'search']")
	WebElement searchIcon;

	@FindBy(xpath = "//a[text()='Clear Search']")
	WebElement ClearBtn;

	@FindBy(xpath = "//*[text() = 'Showing 1 to 1 of 1 entries']")
	WebElement studentSearchResult;
	
	@FindBy(xpath = "//table[@id = 'learnerTableList']//td[3]")
	WebElement searchResultStudentEmail;
	
	
	@FindBy(xpath = "//*[@id='learnerTableList_info']")
	WebElement studentResult;
	
	
	@FindBy(xpath = "//input[@name='email']")
	WebElement searchTextstudentEmail;
	
	@FindBy(xpath = "//input[@name='unit_name']")
	WebElement searchTextstudentunit_name;
	
	
	@FindBy(xpath = "//input[@name='last_name']")
	WebElement searchTextstudentLastname;
	
	@FindBy(xpath = "//input[@name='first_name']")
	WebElement searchTextstudentfirst_name;

	@FindBy(xpath = "//a[@data-target = '#unitdiv']")
	WebElement searchResultUnitName;
	
	@FindBy(xpath = "//a[@class = 'action_dropdown']")
	WebElement actionDetails;
	
	
	
	
	@FindBy(xpath = "//*[@id='productInner']//td[text()=' No Course data available']")
	WebElement noCoursedata;
	
	@FindBy(xpath = "//*[@id='courseList']//a[text()='Close']")
	WebElement closebtn;
	
	
	@FindBy(xpath = "//*[@id='statusFilter']")
	WebElement userStatus;
	
	@FindBy(xpath = "//a[text() = 'Manage Subscribed Courses']")
	WebElement manageSubscribedCourses;
	
	@FindBy(xpath = "//table[@id = 'customer-admin-list']//td[2]")
	WebElement subscribedCourseName;
	
	@FindBy(xpath = "//table[@id = 'customer-admin-list']//td[7]")
	WebElement unenrollCourse;
	
	@FindBy(xpath = "//*[@id='common-btn-unenroll']")
	WebElement unenrollCourseDeleteYes;
	
	
	@FindBy(xpath = "//*[@id='common-modal-content']//label")
	WebElement unenrollCheckBox;
	
	@FindBy(xpath = "//*[@id='common-modal-content']//button[contains(text(),'Cancel')]")
	WebElement unenrollcancel;
	
	
	
	@FindBy(xpath = "//table[@id = 'customer-admin-list']//td[8]")
	WebElement unenrollCourseLMS;
	
	@FindBy(xpath = "//td[text() = 'No records are available']")
	WebElement noRecordsAvaialble;
	
	
	@FindBy(xpath = "//*[@id=\"learnerTableList\"]/tbody/tr[2]/td[text()='Inactive']/following-sibling::td//a[@class=\"action_dropdown\"]")
	WebElement InactionDetails;

	

	@FindBy(xpath = "//*[@id=\"learnerTableList\"]/thead/tr/th[8]")
	WebElement status;

	@FindBy(xpath = "//*[@id=\"learnerTableList\"]/thead/tr/th[6]")
	WebElement statusLMS;

	@FindBy(xpath = "//*[@id='learnerTableList']/tbody/tr[2]/td[text()='Inactive']/following-sibling::td//a[text()='View Details']")
	WebElement InactionViewDetails;

	
	
	@FindBy(xpath = "//a[text() = 'View Details']")
	WebElement viewDetails;
	

	@FindBy(xpath = "//a[text() = 'Inactivate User']")
	WebElement Inactivate;
	
	@FindBy(xpath = "//a[text() = 'Activate User']")
	WebElement activate;
	
	@FindBy(xpath = "//td[text() = 'No records are present.']")
	WebElement noRecordPresent;
	
	
	@FindBy(xpath = "//a[@title='Delete User']")
	WebElement deleteUser;
	
	@FindBy(xpath = "//button[text() = 'Yes']")
	WebElement deleteYesButton;
	
	
	@FindBy(xpath = "//a[text() = 'View Courses']")
	WebElement viewCourses;
	
	
	
	@FindBy(xpath = "//*[@id=\"learnerTableList\"]//a[text()='Manage Subscribed Courses']")
	WebElement ManageCourses;
	
	
	
	@FindBy(xpath = "//*[@title=\'Update subscription details\']")
	WebElement updateSubscriptionDetails;
	
	@FindBy(xpath = "(//input[@id=\"end_date\"])[1]")
	WebElement SubscriptionDate;
	
	
	@FindBy(xpath = "(//input[@value=\"Update License\"])[1]")
	WebElement UpdateBtn;
			
	@FindBy(xpath = "//*[@id=\"customer-admin-list\"]/tbody/tr/td[4]")
	WebElement enddate;
	
	
	@FindBy(xpath = "(//a[text() = 'Close'])[2]")
	WebElement closeCourses;
	
	@FindBy(xpath = "//div[text()='Unit Name']//following-sibling::div")
	WebElement viewUnitName;
	
	@FindBy(xpath = "//button[text()='Yes']")
	WebElement yesBtn;
	
	
	@FindBy(xpath = "//div[text()='First Name']//following-sibling::div")
	WebElement viewFirstName;
	
	@FindBy(xpath = "//div[text()='Last Name']//following-sibling::div")
	WebElement viewLastName;
	
	@FindBy(xpath = "//div[text()='Email']//following-sibling::div")
	WebElement viewEmail;
	
	@FindBy(xpath = "(//button[text() = 'Cancel'])[2]")
	WebElement cancelViewOnlyDetails;
	
	@FindBy(xpath = "(//button[text() = 'Cancel'])[1]")
	WebElement cancelViewDetails;
	
	
	@FindBy(xpath = "//*[@id=\"courseList\"]//a[text()='Close']")
	WebElement closeViewDetails;
	
	@FindBy(xpath = "//a[@id = 'editUserDetails']")
	WebElement editViewDetails;
	
	@FindBy(xpath = "//form[@name = 'studentDetailsForm']//input[@id = 'first_name']")
	WebElement editFirstName;
	

	@FindBy(xpath = "//form[@name = 'studentDetailsForm']//input[@id = 'middle_name']")
	WebElement editMiddlename;
	
	
	@FindBy(xpath = "//form[@name = 'studentDetailsForm']//input[@id = 'last_name']")
	WebElement editLastName;
	
	@FindBy(xpath = "//form[@name = 'studentDetailsForm']//input[@id='year_of_exp']")
	WebElement year_of_exp;
	
	@FindBy(xpath = "//*[@id='hire_date']")
	WebElement hire_date;
	
	@FindBy(xpath = "//*[@id='dob']")
	WebElement dob;
	
	
	
	
	@FindBy(xpath = "//button[contains(text(), 'Update')]")
	WebElement submitButton;
	

	@FindBy(xpath = "(//input[@id='email'])[2]")
	WebElement editEmail;
	
	
	@FindBy(xpath = "//a[text() = 'Edit Details']")
	WebElement editDetails;
	
	@FindBy(xpath = "//*[@id='edit_link_icon']/a")
	WebElement editLevel;
	
	@FindBy(xpath = "//*[@id='tablelisting']//a[@title='Download Source File']")
	public WebElement downloadSourceFile;
	
	@FindBy(xpath = "//*[@id='tablelisting']//a[@title='Download Error Log File']")
	public WebElement downloadErrorFile;


	   @FindBy(xpath = "//table[@id='tablelisting']")
		WebElement demographicReport;
		
	   
			   @FindBy(xpath = "(//*[@id='log-modal-content']//button[@class='close'])[1]")
				WebElement close;

			   
		

	@FindBy(xpath = "//*[@id='errorLogTableData']")
	WebElement errorLogTableData;

	@FindBy(xpath = "//*[@id='errorLogTableData']/tr")
	List<WebElement> errorLogTableDatacount;
	
	
	@FindBy(xpath = "//a[text() = 'View activities']")
	WebElement viewActivities;
	
	@FindBy(xpath = "//a[text() = 'View Activities']")
	WebElement viewActivity;
	
	@FindBy(xpath = "//tr[2]//table")
	WebElement courseTable;
	
	@FindBy(xpath = "//button[text() = 'Advance Activity']")
	WebElement advancedActivity;
	
	@FindBy(xpath = "//*[@id='action-alert']/div")
	WebElement successMsg;
	
	@FindBy(xpath = "//*[@id='action-alert']//a[text()='×']")
	WebElement closeSuccess;
	
	
	

	@FindBy(xpath = "//a[text() = 'Send Reset Password Mail']")
	WebElement reset;
	
	@FindBy(xpath = "//*[@data-bb-handler = 'confirm']")
	WebElement confirmButton;
	
	@FindBy(xpath = "//div[@class='bootbox-body']//text()[3]")
	WebElement errorMsg;
	@FindBy(xpath = "//input[@id='email']")
	WebElement searchTextEmailId;
	@FindBy(xpath = "//div[@class='dropdown']//a[@class='action_dropdown']")
	WebElement ClickOnActionsButton;
	
	@FindBy (xpath = "//div[@class='dropdown open']//ul[@class='dropdown-menu']//li/a")
	List<WebElement> DropDown;
	
	@FindBy (xpath = "//div[@class='modal-content']/div[3]/button[contains(text(),'Yes')]")
	WebElement Button_Yes;
	
	//button[contains(text(),'Yes')]

	@FindBy (xpath = "//div[@class,'alert alert-success alert-dismissable flash-success']")
	WebElement Flash_message;
	
	@FindBy (xpath = "//div[@class='container navbar-cont']/div/ul/li/a")
	List<WebElement> Users_Tabs; 
	
	
	
	@FindBy (xpath = "//*[@id='popup-submit-btn' and contains(text(),'Apply')]")
	WebElement apply; 
	
	@FindBy (xpath = "//*[@id='studentDetailsForm']//button[text()='Update Student']")
	WebElement update_Student; 
	
	@FindBy (xpath = "//*[@id='common-modal-content']//p")
	WebElement contentp; 
	
	

	@FindBy (xpath = "//*[@id='common-modal-content']//li")
	List<WebElement> listli;
	
	@FindBy (xpath = "//*[@id='common-modal-content']//label")
	WebElement listlabel;
	
	
	

	@FindBy (xpath = "//*[@id='common-modal-content']//label")
	WebElement contentlabel; 

	@FindBy(xpath = "//*[@id='customer-admin-list']//th")
	List<WebElement> ManageSubscribedColumns;
	
	@FindBy(xpath = "//*[@id='customer-admin-list']//td")
	List<WebElement> ManageSubscribedData;
	
	
	@FindBy (xpath = "//li[@class='dropdown  open']//ul[@class='dropdown-menu']//li/a")
	List<WebElement> Notifications_Tabs;
	
	String studenttable="//*[@id='learnerTableList']//";
	public static String downloadPath = System.getProperty("user.dir") + prop.getProperty("downloadPath");
	String fileName; 
	public static String filePath, firstName, lastName, email;
	public String sourceFile;

	String courseTableRow = "//tr[2]//table//tbody//tr";
	String comActivity="//*[@id='productInner']//*[@id='no_sort']//a[@title='Complete Activity']";
	String viewCourseTable="//*[@id='no_sort']";

	String viewcourseTopicTable="//tbody[@id='productInner']//table[@id='no_sort']";
	
	String courseSubscriptionTable = "//table[@id = 'customer-admin-list']//tbody/tr";

	
	OrganizationHome orgHome;
	
	public Students() 
	{
		PageFactory.initElements(driver, this);
		
	}
	
	public void navigateToStudentTab()
	{
		wait.until(ExpectedConditions.visibilityOf(manageStudentTab));
		manageStudentTab.click();
	}

	public void clickImportData()
	{
		try
		{
			Thread.sleep(5000);
		wait.until(ExpectedConditions.visibilityOf(importDataLink));
		importDataLink.click();

		Thread.sleep(5000);
		}
		catch(Exception e)
		{
			
		}
	}
	public void notavalibleImportData()
	{
		try
		{
		wait.until(ExpectedConditions.visibilityOf(importDataLink));
		importDataLink.click();
		Assert.fail("ImportData btn should not exists");
		}
		catch (Exception e) {
			System.out.println("Import data btn is not available ");
		}
	}

	public void clickOnDownloadFile()
	{
		try
		{
			Thread.sleep(5000);
			
		wait.until(ExpectedConditions.visibilityOf(downloadFileLink));
		deleteCSVFile();
		downloadFileLink.click();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void addFileDataVariations_LMS_Level2()
	{
		try 
		{
			boolean dwnld = false;
			int m=0;
			do 
			{
				dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
				if(m==pagload)
					break;
				else
				{
					try {
						Thread.sleep(550);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				m++;
			}
			while(dwnld == false);
			Thread.sleep(3000);
			File file = new File(filePath); 
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			  
			List<String[]> rowsList = csvReader.readAll();
			csvReader.close();
			if(rowsList.size() == 0)
			{
				csvReader.close();
				deleteFile(Students.filePath);
				clickOnDownloadFile();
				addFileDataVariations_LMS_Level2();
			}			
			
			String header[] = rowsList.get(0);
			CSVWriter writer = new CSVWriter(new FileWriter(filePath), ',',
                    CSVWriter.NO_QUOTE_CHARACTER,
                    CSVWriter.DEFAULT_ESCAPE_CHARACTER,
                    CSVWriter.DEFAULT_LINE_END);
			DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
			Calendar cal = Calendar.getInstance();
			String email = dateFormat.format(cal.getTime());
			String formattedEmail = email.replace(":", "");
			List<String[]> list = new ArrayList<String[]>();
			list.add(header);
			writer.writeNext(header);
			String row1[] = {"Inst1", "InstName", "", "", formattedEmail, "Ansh", "", "G", "Ansh.G"+ formattedEmail + prop.getProperty("userDomain"), "", "", "", "Active", "", "","","",""};
			list.add(row1);
			writer.writeNext(row1);
			Thread.sleep(1000);
			dateFormat = new SimpleDateFormat("HH:mm:ss");
			cal = Calendar.getInstance();
			String date = dateFormat.format(cal.getTime());
			String row2[] = {"Inst1", "InstName", "Dep1", "DepName", date, "Ansh", "", "G", "Ansh.G"+ date.replace(":", "") + prop.getProperty("userDomain"), "", "", "", "Active", "", "","","",""};
			list.add(row2);
			writer.writeNext(row2);
			
			Thread.sleep(2000);
			
			dateFormat = new SimpleDateFormat("HH:mm:ss");
			cal = Calendar.getInstance();
			String mail=date = dateFormat.format(cal.getTime());
			
			Thread.sleep(2000);
			dateFormat = new SimpleDateFormat("HH:mm:ss");
			cal = Calendar.getInstance();
			 mail=date = dateFormat.format(cal.getTime());
			dateFormat = new SimpleDateFormat("MM-dd-yyyy");
			cal = Calendar.getInstance();
			date = dateFormat.format(cal.getTime());
			String row4[] = {"Inst2", "InstName2", "Dep2", "DepName2", date, "Ansh", "", "G", "Ansh.G"+ mail.replace(":", "") + prop.getProperty("userDomain"), "", "", date, "Active", "", "","","",""};
			list.add(row4);
			writer.writeNext(row4);
			
			Thread.sleep(2000);
			dateFormat = new SimpleDateFormat("HH:mm:ss");
			cal = Calendar.getInstance();
			 mail=date = dateFormat.format(cal.getTime());
			dateFormat = new SimpleDateFormat("MM-dd-yyyy");
			cal = Calendar.getInstance();
			date = dateFormat.format(cal.getTime());
			String row5[] = {"Inst2", "InstName2", "Dep1", "DepName1", date, "Ansh", "", "G", "Ansh.G"+ mail.replace(":", "") + prop.getProperty("userDomain"), "", "", date, "InActive", "", "","","",""};
			list.add(row5);
			writer.writeNext(row5);
			
			Thread.sleep(2000);
			dateFormat = new SimpleDateFormat("HH:mm:ss");
			cal = Calendar.getInstance();
			date = dateFormat.format(cal.getTime());
			String row6[] = {"Inst2", "InstName2", "Dep2", "DepName2", date, "Ansh", "", "G", "Ansh.G"+ date.replace(":", "") + prop.getProperty("userDomain"), "job2", "jobName2", "", "Active", "", "","","",""};
			list.add(row6);
			writer.writeNext(row6);
			
			Thread.sleep(2000);
			dateFormat = new SimpleDateFormat("HH:mm:ss");
			cal = Calendar.getInstance();
			date = dateFormat.format(cal.getTime());
			String row7[] = {"Inst2", "InstName2", "Dep2", "DepName2", date, "Ansh", "", "G", "Ansh.G"+ date.replace(":", "") + prop.getProperty("userDomain"), "job1", "jobName1", "", "Active", "", "","","",""};
			list.add(row7);
			writer.writeNext(row7);
			OrganizationSettings.titleName="jobName1";
			User.userEmail="Ansh.G"+ date.replace(":", "")+ prop.getProperty("userDomain");
			User.userId=date;
			System.out.println(Students.email);
			
			Thread.sleep(5000);
			writer.flush();
			writer.close();
		;
	
			Thread.sleep(5000);
			readandUpdateFile();
	} 
		catch (Exception e) 
		{
		e.printStackTrace();
		}
	}
	public void prepareFile(int count)
	{
		boolean dwnld = false;
		int m=0;
		do 
		{
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			m++;
		}
		while(dwnld == false);
		addFileData(count); 
		readandUpdateFile();
		
	}
	
	public void downloadsourceFile()
	{
		
	}
	public void prepareFileWitoutlevel(int count)
	{
		boolean dwnld = false;
		int m=0;
		do 
		{
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			m++;
		}
		while(dwnld == false);
		addFileDataLevel(count); 
		readandUpdateFile();
		
	}
	
	public void prepareFileWitoutlevel(int count,String First,String Last)
	{
		boolean dwnld = false;
		int m=0;
		do 
		{
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			m++;
		}
		while(dwnld == false);
		addFileDataLevel(count,First,Last); 
		readandUpdateFile();
		
	}
	
	public void prepareFileWitoutlevel(int count,String validation)
	{
		boolean dwnld = false;
		int m=0;
		do 
		{
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			m++;
		}
		while(dwnld == false);
		addFileDataLevel(count,validation); 
		readandUpdateFile();
		
	}
	
	public void prepareFileWitoutlevelupdate(int count)
	{
		boolean dwnld = false;
		int m=0;
		do 
		{
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			m++;
		}
		while(dwnld == false);
		addFileDataupdateLevel(count); 
		readandUpdateFile();
		
	}
	
	
	public void prepareFileeditlevel(int count)
	{
		boolean dwnld = false;
		int m=0;
		do 
		{
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			m++;
		}
		while(dwnld == false);
		editdeatlis(count); 
		readandUpdateFile();
		
	}
	public void prepareFileWitoutlevelactive(int count)
	{
		boolean dwnld = false;
		int m=0;
		do 
		{
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			m++;
		}
		while(dwnld == false);
		addFileDataLevelInActive(count); 
		readandUpdateFile();
		
	}
	public void uploadFile()
	{
		WebDriverWait wait = new WebDriverWait(driver, 180);
		wait.until(ExpectedConditions.visibilityOf(uploadFileLink));
		uploadFileLink.click();
		wait.until(ExpectedConditions.visibilityOf(buttonClose));
		int count = Integer.parseInt(failureCount.getText());
		Assert.assertTrue(count == 0);
		buttonClose.click();
	}
	
	public void uploadDemographicFile(int fcount)
	{
		WebDriverWait wait = new WebDriverWait(driver, 180);
		wait.until(ExpectedConditions.visibilityOf(uploadFileLink));
		uploadFileLink.click();
		wait.until(ExpectedConditions.visibilityOf(buttonClose));
		int count = Integer.parseInt(failureCount.getText());
		Assert.assertTrue(count == fcount);
		buttonClose.click();
	}
	 public void uploadFileForMultipleValidations()
	    {
	        WebDriverWait wait = new WebDriverWait(driver, 180);
	        wait.until(ExpectedConditions.visibilityOf(uploadFileLink));
	        uploadFileLink.click();
	        wait.until(ExpectedConditions.visibilityOf(buttonClose));
	        int count = Integer.parseInt(failureCount.getText());
	        Assert.assertTrue(count == 8);
	        buttonClose.click();
	    }
	 

	 public void uploadFileForMultipleValidationslms()
	    {
	        WebDriverWait wait = new WebDriverWait(driver, 180);
	        wait.until(ExpectedConditions.visibilityOf(uploadFileLink));
	        uploadFileLink.click();
	        wait.until(ExpectedConditions.visibilityOf(buttonClose));
	        int count = Integer.parseInt(failureCount.getText());
	        System.out.println(count);
	        Assert.assertTrue(count == 7);
	        buttonClose.click();
	    }

	public boolean isFileDownloaded_Ext(String dirPath, String ext){
		boolean flag=false;
	    File dir = new File(dirPath);
	    File[] files = dir.listFiles();
	    if (files != null)
	    {
	    	 for (int i = 0; i < files.length; i++) 
	 	    {
	 	    	if(files[i].getName().contains(ext)) 
	 	    	{
	 	    		System.out.println(files[i].getName());
	 	    		fileName = files[i].getName();
	 	    		filePath = files[i].getAbsolutePath();
	 	    		filePath = filePath.replace(".crdownload", "");
	 	    		flag=true;
	 	    		break;
	 	    	}
	 	    }
	    }
	    
	    return flag;
	}
	
	public boolean isFileDownloaded(String dirPath, String ext){
		boolean flag=false;
		
	    File dir = new File(dirPath);
	    File[] files = dir.listFiles();
	    if (files != null)
	    {
	    	 for (int i = 0; i < files.length; i++) 
	 	    {
	 	    	if(files[i].getName().contains(ext)&&(files[i].getName().contains("demographicinfo_template"))) 
	 	    	{
	 	    		System.out.println(files[i].getName());
//	 	    		fileName = files[i].getName();
	 	    		sourceFile = files[i].getAbsolutePath();
	 	    		sourceFile = sourceFile.replace(".crdownload", "");
	 	    		flag=true;
	 	    		break;
	 	    	}
	 	    }
	    }
	    
	    return flag;
	}
	

	public void compareFile() throws IOException
	{
		  File firstFile = new File(sourceFile);
	        File secondFile = new File(Products. filePath);
	        System.out.println(sourceFile);
		    System.out.println(Products. filePath);
	       
		    BufferedReader reader1 = new BufferedReader(new FileReader(Products. filePath));  
		    BufferedReader reader2 = new BufferedReader(new FileReader(sourceFile));
		       String line1 = reader1.readLine();    
		       String line2 = reader2.readLine();
		       int lineNum = 1;  
		       boolean areEqual = true;
		       while (line1 != null || line2 != null){
		    	   System.out.println(line1);
		    	   System.out.println(line2);
		          if(line1 == null || line2 == null){
		             areEqual = false; 
		             break;
		          } else if(! line1.equalsIgnoreCase(line2)) {
		             areEqual = false; 
		             break;
		          }
		          line1 = reader1.readLine();  
		          line2 = reader2.readLine();
		          
		          lineNum++;
		       }
		       if(areEqual){
		          System.out.println("Both the files have same content"+lineNum);
		       } else {
		          System.out.println("Both the files have different content");
		          System.out.println("In both files, there is a difference at line number: "+lineNum); 
		          System.out.println("One file has "+line1+" and another file has "+line2+" at line "+lineNum);
		       }
		       reader1.close();
		       reader2.close();
		    Assert.assertTrue("File Compared"+ areEqual,areEqual);;
	 
	}

	
	
	public void clickclose()
	{
	
			wait.until(ExpectedConditions.visibilityOf(close));
			close.click();
	}
	
	public void clickDownloadSourceFile() throws InterruptedException
	{
	
			wait.until(ExpectedConditions.visibilityOf(downloadSourceFile));
			downloadSourceFile.click();
			Thread.sleep(10000);
			
	}
	
	public void clickerrorLogFile() throws InterruptedException
	{
	
			wait.until(ExpectedConditions.visibilityOf(downloadErrorFile));
			downloadErrorFile.click();
			Thread.sleep(13000);
			
	}
	
	public void clickonFailedLink(int row)
	{
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(demographicReport));
			Thread.sleep(3000);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//a[@title='View Error Log' and contains(text(),'"+row+"')]"))));
		driver.findElement(By.xpath("//a[@title='View Error Log' and contains(text(),'"+row+"')]")).click();
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
	}
	public void validateStudentTable(String header,String value)
	{
		reuse.validatethedetails(header, studenttable+"th", value, studenttable+"td","Email");
	}
	public void validateErrorTable(int row,int col,String Cell)
	{
		try 
		{
			
		;
		wait.until(ExpectedConditions.visibilityOf(errorLogTableData));
		int count=0;
		while(errorLogTableData.getText().contains("Processing"))
		{
			if(count>=pagload)
				break;
			Thread.sleep(100);
			count++;
		}
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//tbody[@id='errorLogTableData']//tr["+row+"]/td["+col+"]"))));
			WebElement errorTableCell=driver.findElement(By.xpath("//tbody[@id='errorLogTableData']//tr["+row+"]/td["+col+"]"));
//			System.out.println("Table Data"+Cell);
//			System.out.println("Table Data"+errorTableCell.getText());
//			
			Assert.assertEquals(errorTableCell.getText(), Cell);
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
		
	}
	public void readerfilendvalidate() throws IOException, InterruptedException
	{
		int count=0;
		while(errorLogTableData.getText().contains("Processing"))
		{
			if(count>=pagload)
				break;
			Thread.sleep(200);
			count++;
		}
		
		
		for(int i=1;i<=errorLogTableDatacount.size();i++)
		{
		Boolean flag=false;	
	   String row= 	driver.findElement(By.xpath("//tbody[@id='errorLogTableData']//tr["+i+"]/td["+1+"]")).getText();
	   String column= 	driver.findElement(By.xpath("//tbody[@id='errorLogTableData']//tr["+i+"]/td["+2+"]")).getText();
	   String error= 	driver.findElement(By.xpath("//tbody[@id='errorLogTableData']//tr["+i+"]/td["+3+"]")).getText();
	   System.out.println("row "+row);
	   System.out.println("column "+column);
	   System.out.println("error "+error);
			
	   int headerCount=0;
	   System.out.println("headerCount "+headerCount);
		
	   BufferedReader reader = new BufferedReader(new FileReader(filePath));
	    String header = reader.readLine(); 
	    for(int m=0;m<header.split(";").length;m++)
	    {
	    
	    	if(header.split(";")[m].contains(column))
	    	{
	    		headerCount=m;
	    		break;
	    	}
	    }
	    String line=reader.readLine();  ;
	    while(line != null)   {
	    	   System.out.println(line);
		    	if(line.split(";")[0].equals(row))  
		    	{
		    		
		    		if(line.split(";")[headerCount].contains(error))
		    		{
		    				flag=true;
		    		}
		    				
		    	}
		    	line = reader.readLine();  
		    	   
	    }
		Assert.assertTrue("Data mismatch",flag);
		reader.close();
		}
		
	}

	
	public void studentSearch(String studentEmail)
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchTextstudentEmail));
			ClearBtn.click();
			searchTextstudentEmail.sendKeys(studentEmail);
			searchIcon.click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(studentSearchResult));
			wait.until(ExpectedConditions.visibilityOf(searchResultStudentEmail));
			String result = searchResultStudentEmail.getText();
			Assert.assertEquals(studentEmail, result);
		} 
		catch (Exception e) 
		{
		 Assert.fail(	e.getMessage());;
		}
		
	}
	
	public void studentSearchnoresult(String studentEmail)
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchTextstudentEmail));
			ClearBtn.click();
			searchTextstudentEmail.sendKeys(studentEmail);
			searchIcon.click();
			Thread.sleep(3000);
			
		} 
		catch (Exception e) 
		{
		 Assert.fail(	e.getMessage());;
		}
		
	}
	
	
	public void studentFirstSearch(String first_name)
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchTextstudentEmail));
			ClearBtn.click();
			searchTextstudentfirst_name.sendKeys(first_name);
			searchIcon.click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(studentSearchResult));
			wait.until(ExpectedConditions.visibilityOf(searchResultStudentEmail));
			String result = searchResultStudentEmail.getText();
			Assert.assertEquals(User.userEmail, result);
		} 
		catch (Exception e) 
		{
		 Assert.fail(	e.getMessage());;
		}
		
	}
	
	
	public void studentLastSearch(String studentEmail)
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchTextstudentEmail));
			ClearBtn.click();
			searchTextstudentLastname.sendKeys(studentEmail);
			searchIcon.click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(studentSearchResult));
			wait.until(ExpectedConditions.visibilityOf(searchResultStudentEmail));
			String result = searchResultStudentEmail.getText();
			Assert.assertEquals(User.userEmail, result);
		} 
		catch (Exception e) 
		{
		 Assert.fail(	e.getMessage());;
		}
		
	}
	public void studentUnitSearch(String studentEmail)
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			Thread.sleep(5000);
			wait.until(ExpectedConditions.elementToBeClickable(searchTextstudentEmail));
			ClearBtn.click();
			searchTextstudentunit_name.sendKeys(studentEmail);
			searchIcon.click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(studentSearchResult));
			wait.until(ExpectedConditions.visibilityOf(searchResultStudentEmail));
			String result = searchResultStudentEmail.getText();
			Assert.assertEquals(User.userEmail, result);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		 Assert.fail(	e.getMessage());;
		}
		
	}
	
	public void clear()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchTextstudentEmail));
			Thread.sleep(3000);

			ClearBtn.click();
			
			Thread.sleep(3000);
//			wait.until(ExpectedConditions.visibilityOf(studentResult));
//			wait.until(ExpectedConditions.visibilityOf(searchResultStudentEmail));
			String result = studentResult.getText();
			Assert.assertFalse("Clear filter not working","Showing 1 to 1 of 1 entries".contains(result));
		} 
		catch (Exception e) 
		{
		 Assert.fail(	e.getMessage());;
		}
		
	}
	public void selectManageSubscribedCourses()
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 10);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", actionDetails);
			wait.until(ExpectedConditions.visibilityOf(manageSubscribedCourses));
			manageSubscribedCourses.click();
		}
		catch (Exception e) 
		{
			
		}
	}
	public void unenrollCourseLMS()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(unenrollCourseLMS));
		unenrollCourseLMS.click();
		wait.until(ExpectedConditions.visibilityOf(unenrollCheckBox));
		unenrollCheckBox.click();
		wait.until(ExpectedConditions.visibilityOf(unenrollCourseDeleteYes));
		unenrollCourseDeleteYes.click();
		wait.until(ExpectedConditions.visibilityOf(noRecordsAvaialble));
	}
	public void unenrollCourseWithName(String course,String msg)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
			
		if(AssignmentReport.checkifParmeterAvailable(msg))
			msg=AssignmentReport.getParmeterAvailable(msg);
    
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(unenrollCourse));
		List<WebElement> courseList = driver.findElements(By.xpath(courseSubscriptionTable));
		int originalCount = courseList.size();
		for(int i = 1; i <= originalCount; i++)
		{
			String productCode = driver.findElement(By.xpath(courseSubscriptionTable + "[" + i + "]/td[1]")).getText();
			String productName = driver.findElement(By.xpath(courseSubscriptionTable + "[" + i + "]/td[2]")).getText();
			String actualCourse = productName;
			if(course.equalsIgnoreCase(actualCourse))
			{
				driver.findElement(By.xpath(courseSubscriptionTable + "[" + i + "]/td[7]")).click();
				wait.until(ExpectedConditions.visibilityOf(unenrollCheckBox));
				unenrollCheckBox.click();
				wait.until(ExpectedConditions.visibilityOf(unenrollCourseDeleteYes));
				unenrollCourseDeleteYes.click();
				org = new OrganizationHome();
				org.validateSucessMesssage(msg);
				break;
			}
		}
		courseList = driver.findElements(By.xpath(courseSubscriptionTable));
		int newCount = courseList.size();
		if(originalCount==1)
			wait.until(ExpectedConditions.visibilityOf(noRecordsAvaialble));
		else
		Assert.assertTrue(newCount < originalCount);
		
	}
	
	
	public void clickunenrollCourseWithName(String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
			
		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(unenrollCourse));
		List<WebElement> courseList = driver.findElements(By.xpath(courseSubscriptionTable));
		int originalCount = courseList.size();
		for(int i = 1; i <= originalCount; i++)
		{
			String productCode = driver.findElement(By.xpath(courseSubscriptionTable + "[" + i + "]/td[1]")).getText();
			String productName = driver.findElement(By.xpath(courseSubscriptionTable + "[" + i + "]/td[2]")).getText();
			String actualCourse = productName;
			if(course.equalsIgnoreCase(actualCourse))
			{
				driver.findElement(By.xpath(courseSubscriptionTable + "[" + i + "]/td[7]")).click();
				break;
			}
		}
	
		
	}
	public void clickunenrollCourseWithNameLMS(String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
			
		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(unenrollCourse));
		List<WebElement> courseList = driver.findElements(By.xpath(courseSubscriptionTable));
		int originalCount = courseList.size();
		for(int i = 1; i <= originalCount; i++)
		{
			String productCode = driver.findElement(By.xpath(courseSubscriptionTable + "[" + i + "]/td[1]")).getText();
			String productName = driver.findElement(By.xpath(courseSubscriptionTable + "[" + i + "]/td[2]")).getText();
			String actualCourse = productName;
			if(course.equalsIgnoreCase(actualCourse))
			{
				driver.findElement(By.xpath(courseSubscriptionTable + "[" + i + "]/td[8]")).click();
				break;
			}
		}
	
		
	}
	
	
	public void validateunenrollmodel(String model,String content)
	{
		if(AssignmentReport.checkifParmeterAvailable(content))
			content=AssignmentReport.getParmeterAvailable(content);
		wait.until(ExpectedConditions.visibilityOf(contentp));

		if(model.contains("content"))
		{
			
			Assert.assertEquals(contentp.getText(), content);
			
			
		}
		else if(model.contains("course"))
		{
		
			if(courseListName.containsKey(content+"Option"))
				content=courseListName.get(content+"Option").toString();
		
			Assert.assertEquals(listli.get(0).getText(), content);
			
			
		}
		else if(model.contains("note1"))
		{
			
		
			Assert.assertEquals(listli.get(1).getText(), content);
			Assert.assertEquals(driver.findElement(By.xpath("//*[@id='note']/strong")).getText(), "Note:");
				
		}
		else if(model.contains("note2"))
		{
			Assert.assertEquals(listli.get(2).getText(), content);
			Assert.assertEquals(listlabel.getText(), "Proceed with unenrolling this user from this RQI discipline");
				
			
		}
	}
	
	
	public void closeonUnenroll()
	{
		wait.until(ExpectedConditions.visibilityOf(unenrollcancel));
		unenrollcancel.click();
	}
	
	public void unenrollCourseWithNameLMS(String course,String msg)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
			
		if(AssignmentReport.checkifParmeterAvailable(msg))
			msg=AssignmentReport.getParmeterAvailable(msg);
    
		wait.until(ExpectedConditions.visibilityOf(unenrollCourse));
		List<WebElement> courseList = driver.findElements(By.xpath(courseSubscriptionTable));
		int originalCount = courseList.size();
		for(int i = 1; i <= originalCount; i++)
		{
			String productCode = driver.findElement(By.xpath(courseSubscriptionTable + "[" + i + "]/td[1]")).getText();
			String productName = driver.findElement(By.xpath(courseSubscriptionTable + "[" + i + "]/td[2]")).getText();
			String actualCourse = productName;
			if(course.equalsIgnoreCase(actualCourse))
			{
				driver.findElement(By.xpath(courseSubscriptionTable + "[" + i + "]/td[8]")).click();
				wait.until(ExpectedConditions.visibilityOf(unenrollCheckBox));
				unenrollCheckBox.click();
				wait.until(ExpectedConditions.visibilityOf(unenrollCourseDeleteYes));
				unenrollCourseDeleteYes.click();
				org = new OrganizationHome();
				org.validateSucessMesssage(msg);
				break;
			}
		}
		courseList = driver.findElements(By.xpath(courseSubscriptionTable));
		int newCount = courseList.size();
		if(originalCount==1)
			wait.until(ExpectedConditions.visibilityOf(noRecordsAvaialble));
		else
		Assert.assertTrue(newCount < originalCount);
		
	}
	
	public void validateNoRecordFound()
	{
		wait.until(ExpectedConditions.visibilityOf(noRecordsAvaialble));
		Assert.assertEquals(noRecordsAvaialble.getText(), "No records are available");
	}
	
	public void unenrollCourseWithNameLMSrecurrence(String course,String msg)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
			
		if(AssignmentReport.checkifParmeterAvailable(msg))
			msg=AssignmentReport.getParmeterAvailable(msg);
    
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(unenrollCourse));
		List<WebElement> courseList = driver.findElements(By.xpath(courseSubscriptionTable));
		int originalCount = courseList.size();
		for(int i = 1; i <= originalCount; i++)
		{
			String productCode = driver.findElement(By.xpath(courseSubscriptionTable + "[" + i + "]/td[1]")).getText();
			String productName = driver.findElement(By.xpath(courseSubscriptionTable + "[" + i + "]/td[2]")).getText();
			String Status = driver.findElement(By.xpath(courseSubscriptionTable + "[" + i + "]/td[5]")).getText();
			String actualCourse = productName;
			System.err.println(Status.contains("Completed"));
			if(course.equalsIgnoreCase(actualCourse)&&(!(Status.contains("Completed"))))
			{
				driver.findElement(By.xpath(courseSubscriptionTable + "[" + i + "]/td[8]")).click();
				wait.until(ExpectedConditions.visibilityOf(unenrollCheckBox));
				unenrollCheckBox.click();
				wait.until(ExpectedConditions.visibilityOf(unenrollCourseDeleteYes));
				unenrollCourseDeleteYes.click();
				org = new OrganizationHome();
				org.validateSucessMesssage(msg);
				break;
			}
			else if(course.equalsIgnoreCase(actualCourse)&&(Status.contains("Completed")))
			{	
				try
				{
					driver.findElement(By.xpath(courseSubscriptionTable + "[" + i + "]/td[8]")).click();
					Assert.fail("Unenroll should not come for complete course");
				}
				catch (Exception e) {
					
				}
			}
				
		}
		courseList = driver.findElements(By.xpath(courseSubscriptionTable));
		int newCount = courseList.size();
		if(originalCount==1)
			wait.until(ExpectedConditions.visibilityOf(noRecordsAvaialble));
		else
		Assert.assertTrue(newCount < originalCount);
		
	}
	
	
	public void unenrollCourse()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(unenrollCourse));
		unenrollCourse.click();
		wait.until(ExpectedConditions.visibilityOf(unenrollCourseDeleteYes));
		unenrollCourseDeleteYes.click();
		wait.until(ExpectedConditions.visibilityOf(noRecordsAvaialble));
	}
	
	public void deleteFile(String path)
	{
		try {
			System.out.println("delete file path is " + path);
			File file = new File(path);
			Thread.sleep(5000);
			file.delete();
			boolean dwnld = false;
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");	
			int m=0;
			while(dwnld)
			{
				file = new File(filePath);
				file.delete();
				dwnld = isFileDownloaded_Ext(downloadPath, ".csv");	
				if(m==pagload)
					break;
				else
				{
					try {
						Thread.sleep(550);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				m++;
				
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	public void deleteUserDetails()
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(deleteUser));
			deleteUser.click();
			wait.until(ExpectedConditions.visibilityOf(deleteYesButton));
			deleteYesButton.click();
			pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
			}
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(noRecordPresent));
			Assert.assertTrue(noRecordPresent.isDisplayed());
			
		}
		catch (Exception e) 
		{
			
		}
	}	
	
	public void deleteCSVFile()
	{
		boolean dwnld = false;
		dwnld = isFileDownloaded_Ext(downloadPath, ".csv");		
		int m=0;
		while(dwnld)
		{
			if(m==200)
				Assert.fail("File download fail");
			else
			{
			File file = new File(filePath);
			System.out.println(filePath);
			file.delete();
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");	
			}
			m++;
			
		}
	}
	
	
	public void readandUpdateFle()
	{
		try 
		{
			String file ="";
			int m=0;
		do 
		{
			
			wait.until(ExpectedConditions.visibilityOf(chooseFileLink));
			file = uploadedFile.getText();
			
			driver.findElement(By.xpath("//*[@id = 'upload']")).sendKeys(filePath);
			Thread.sleep(15000);
			if(m==pagload)
				break;
			m++;
		}
		while(file.length() > 0);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void readandUpdateFile()
	{
		try 
		{
			String file ="";
			int m=0;
		do 
		{
			
			wait.until(ExpectedConditions.visibilityOf(chooseFileLink));
			file = uploadedFile.getText();
			
			driver.findElement(By.xpath("//*[@id = 'upload']")).sendKeys(filePath);
			Thread.sleep(15000);
			if(m==pagload)
				break;
			m++;
		}
		while(file.length() > 0);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	@SuppressWarnings("resource")
	public void addFileData_LMS(int userCount)
	{
		try 
		{
			boolean dwnld = false;
			int m=0;
			do 
			{
				dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
				if(m==pagload)
					break;
				else
				{
					try {
						Thread.sleep(550);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				m++;
			}
			while(dwnld == false);
			Thread.sleep(3000);
			File file = new File(filePath); 
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			CSVWriter writer = new CSVWriter(new FileWriter(filePath));
			DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
			Calendar cal = Calendar.getInstance();
			String email = dateFormat.format(cal.getTime());
			String formattedEmail = email.replace(":", "");
			List<String[]> list = new ArrayList<String[]>();
			list.add(header);
			for(int i=1; i<= userCount; i++)
			{
				String row[] = {String.valueOf(i), "Ansh" + i, "", "G" + i, "Ansh.G" + i + formattedEmail + prop.getProperty("userDomain"), "", "", "", "Active", "", "", "", "", ""};
				list.add(row);
			}
			writer.writeAll(list);
			writer.flush();
			readandUpdateFile();
	} 
		catch (Exception e) 
		{
		e.printStackTrace();
		}
	}
	
	public void addFileData(int count)
	{
		String level = "";
		String nextLine[] = null;
		File file = new File(filePath); 
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		String data[] = {"","","","","Ansh.G" + formattedEmail + prop.getProperty("userDomain"), "Ansh", "", "G", "Ansh.G" + formattedEmail + prop.getProperty("userDomain"), "", "", "", "Active", "", "", "", "", ""};
		if(count > 1)
		{
			User.userEmail="Ansh.G" + formattedEmail + prop.getProperty("userDomain");
			String dataLevel [];
			for(int i = 2; i <= count; i++ )
				{
					String id = Integer.toString(i);
					String name = "level_" + i;
					level = level + id + "," + name;
					if(i<count)
						level = level + ",";
				}
			dataLevel = level.split(",");
			nextLine = new String[data.length + dataLevel.length];
			System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
			System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
			System.out.println(nextLine);
		}
		try
		{
			Thread.sleep(5000);
	 		FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeNext(header);
			if(count > 1)
			{
				writer.writeNext(nextLine);
			}
			else
			{
				writer.writeNext(data);
			}
			writer.close();
			csvReader.close();
		}
		catch(Exception e)
		{
			System.out.println("Data no read");
			e.getMessage();
		}
	}
	public void addFileDataLevel(int count)
	{
		try
		{
		String level = "";
		String nextLine[] = null;
		File file = new File(filePath); 
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		String data[] = {"Anshs.m" + formattedEmail + prop.getProperty("userDomain"), "Ansh", "", "G", "Anshs.m" + formattedEmail + prop.getProperty("userDomain"), "", " ", "", "Active", "", "", "", "", ""};
		User.userEmail="Anshs.m" + formattedEmail+ prop.getProperty("userDomain");
		User.userId="Anshs.m" + formattedEmail+ prop.getProperty("userDomain");
		System.out.println(User.userEmail);
		if(count > 1)
		{
			String dataLevel [];
			for(int i = 2; i <= count; i++ )
				{
					String id = Integer.toString(i);
					String name = "level_" + i;
					level = level + id + "," + name;
					if(i<count)
						level = level + ",";
				}
			dataLevel = level.split(",");
			nextLine = new String[data.length + dataLevel.length];
			System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
			System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
			System.out.println(nextLine);
		}
		try
		{
			Thread.sleep(5000);
	 		FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeNext(header);
			if(count > 1)
			{
				writer.writeNext(nextLine);
			}
			else
			{
				writer.writeNext(data);
			}
			writer.close();
			csvReader.close();
		}
		catch(Exception e)
		{
			System.out.println("Data no read");
			e.getMessage();
		}
		}
		catch(Exception e)
		{
		Assert.fail("File not downloaded");
		}
	}
	
	public void addFileDataLevel(int count,String first,String last)
	{
		try
		{
		String level = "";
		String nextLine[] = null;
		File file = new File(filePath); 
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		String data[] = {first+last + formattedEmail + prop.getProperty("userDomain"), first, "", last, first+last  + formattedEmail + prop.getProperty("userDomain"), "", " ", "", "Active", "", "", "", "", ""};
		User.userEmail=first+last  + formattedEmail+ prop.getProperty("userDomain");
		User.userId=first+last + formattedEmail+ prop.getProperty("userDomain");
		System.out.println(User.userEmail);
		if(count > 1)
		{
			String dataLevel [];
			for(int i = 2; i <= count; i++ )
				{
					String id = Integer.toString(i);
					String name = "level_" + i;
					level = level + id + "," + name;
					if(i<count)
						level = level + ",";
				}
			dataLevel = level.split(",");
			nextLine = new String[data.length + dataLevel.length];
			System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
			System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
			System.out.println(nextLine);
		}
		try
		{
			Thread.sleep(5000);
	 		FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeNext(header);
			if(count > 1)
			{
				writer.writeNext(nextLine);
			}
			else
			{
				writer.writeNext(data);
			}
			writer.close();
			csvReader.close();
		}
		catch(Exception e)
		{
			System.out.println("Data no read");
			e.getMessage();
		}
		}
		catch(Exception e)
		{
		Assert.fail("File not downloaded");
		}
	}
	
	public void addFileDataLevel(int count,String validation)
	{
		try
		{
		String level = "";
		String nextLine[] = null;
		File file = new File(filePath); 
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		String data[];
		FileReader filereader = new FileReader(file);
		CSVReader csvReader = new CSVReader(filereader); 
		String header[] = csvReader.readNext();
		FileWriter outputfile = new FileWriter(file);
		CSVWriter writer = new CSVWriter(outputfile);
		writer.writeNext(header);
		String dataLevel [] = null;
		if(count > 1)
		{
			
			for(int i = 2; i <= count; i++ )
				{
					String id = Integer.toString(i);
					String name = "level_" + i;
					level = level + id + "," + name;
					if(i<count)
						level = level + ",";
				}
			dataLevel = level.split(",");
		}
		if(validation.equals("Blank"))
		{
			String[]  data1= {"", "", "", "", "", "", " ", "", "", "", "", "", "", ""};
			data=data1;
			if(count > 1)
			{
			nextLine = new String[data.length + dataLevel.length];
			System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
			System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
			}
		}
		if(validation.equals("OnlyOptional"))
		{
			dateFormat = new SimpleDateFormat("MM-dd-yyyy");
			cal = Calendar.getInstance();
		String	date = dateFormat.format(cal.getTime());
			String data1[] = {"", "", "M", "", "", "Job_code_" + count, "Job_name_" + count, date, "", "02-02-1995", "Male", "5", "02-02-2019", "02-02-2027"};
			
//			String[]  data1= {"", "", "", "", "", "", " ", "", "", "", "", "", "", ""};
			data=data1;
			if(count > 1)
			{
			nextLine = new String[data.length + dataLevel.length];
			System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
			System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
			}
		}
		else if(validation.equals("FewBlank"))
		{
			String[]  data1= {"", "Ansh", "", "G", "Ansh.J" + formattedEmail + prop.getProperty("userDomain"), "", " ", "", "", "", "", "", "", ""};
			data=data1;
			if(count > 1)
			{
			nextLine = new String[data.length + dataLevel.length];
			System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
			System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
			}
		}
		else if(validation.contains("empty"))
		{
			String[]  data1= {"", "", "", "","", "", "", "", "", "", " ", "", "", "", "", "", "", ""};
			data=data1;
			nextLine=data;
		
		}
		else  if(validation.contains("invalid"))
		{
		String data1[] = {"Ansh.J:@@^()'##%%" + formattedEmail + prop.getProperty("userDomain"), "Ansh:'##%%", "", "G:'##%%", "Ansh.J:'##%%" + formattedEmail + prop.getProperty("userDomain"), "", " ", "", "Active:'##%%", "", "", "", "", ""};
		data=data1;
		if(count > 1)
		{
		nextLine = new String[data.length + dataLevel.length];
		System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
		System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
		}
		
		}
		else if(validation.equals("DuplicateFewChange"))
		{
//			String data1[] =new String[2];
			String			    data1[] = {"Ansh.J" + formattedEmail + prop.getProperty("userDomain"), "TEst", "", "ss", "updtedMan" + formattedEmail + prop.getProperty("userDomain"),
		                "Jobcode_" + count, "Jobname_" + count, "", "Active", "", "", "", "", ""};
		     
			   data=data1;
			   
			   if(count > 1)
				{
				nextLine = new String[data.length + dataLevel.length];
				System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
				System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
				}
				if(count > 1)
				{
					writer.writeNext(nextLine);
				}
				else
				{
					writer.writeNext(data);
				}
			
				String   data2[] = {"Ansh.J" + formattedEmail + prop.getProperty("userDomain"), "Ansh", "", "J", "Ansh.J" + formattedEmail + prop.getProperty("userDomain"),
		                "Job_code_" + count, "Job_name_" + count, "", "Active", "", "", "", "", ""};
		     
			   data=data2;
				if(count > 1)
				{
				nextLine = new String[data.length + dataLevel.length];
				System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
				System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
				}
		}
		else if(validation.equals("Duplicate"))
		{
//			String data1[] =new String[2];
			String			    data1[] = {"Ansh.J" + formattedEmail + prop.getProperty("userDomain"), "Ansh", "", "G", "Ansh.J" + formattedEmail + prop.getProperty("userDomain"),
		                "Job_code_" + count, "Job_name_" + count, "", "Active", "", "", "", "", ""};
		     
			   data=data1;
			   
			   if(count > 1)
				{
				nextLine = new String[data.length + dataLevel.length];
				System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
				System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
				}
				if(count > 1)
				{
					writer.writeNext(nextLine);
				}
				else
				{
					writer.writeNext(data);
				}
			
		}
		else if(validation.equals("AllField"))
		{
			dateFormat = new SimpleDateFormat("MM-dd-yyyy");
			cal = Calendar.getInstance();
		String	date = dateFormat.format(cal.getTime());
		String data1[] = {"Ansh.J" + formattedEmail + prop.getProperty("userDomain"), "Ansh", "M", "G", "Ansh.J" + formattedEmail + prop.getProperty("userDomain"), "Job_code_" + count, "Job_name_" + count, date, "Active", "02-02-1995", "Male", "5", "02-02-2019", "02-02-2027"};
		data=data1;
		 if(count > 1)
			{
			nextLine = new String[data.length + dataLevel.length];
			System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
			System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
			}
		 
		}
		else if(validation.equals("update"))
		{
			dateFormat = new SimpleDateFormat("MM-dd-yyyy");
			cal = Calendar.getInstance();
		String	date = dateFormat.format(cal.getTime());
		String data1[] = {User.userId, "Anshupdate", "Mupdate", "GAnshupdate", "Ansh.J" + formattedEmail + prop.getProperty("userDomain"), "Job_code_" + count, "Job_name_update" + count, date, "Active", "02-02-1995", "Male", "9", "02-02-2019", "02-02-2027"};
		data=data1;
		 if(count > 1)
			{
			nextLine = new String[data.length + dataLevel.length];
			System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
			System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
			}
		 
		}
		else
		{
		String data1[] = {"Ansh.J" + formattedEmail + prop.getProperty("userDomain"), "Ansh", "", "G", "Ansh.J" + formattedEmail + prop.getProperty("userDomain"), "", " ", "", "Active", "", "", "", "", ""};
		data=data1;
		
		}
		
		User.userEmail="Ansh.J" + formattedEmail+ prop.getProperty("userDomain");
		User.userId="Ansh.J" + formattedEmail+ prop.getProperty("userDomain");
		System.out.println(User.userEmail);
		
		
		try
		{
			Thread.sleep(5000);
	 			if(count > 1)
			{
				writer.writeNext(nextLine);
			}
			else
			{
				writer.writeNext(data);
			}
			writer.close();
			csvReader.close();
		}
		catch(Exception e)
		{
			System.out.println("Data no read");
			e.getMessage();
		}
		}
		catch(Exception e)
		{
		Assert.fail("File not downloaded");
		}
	}
	public void addFileDataupdateLevel(int count)
	{
		try
		{
		String level = "";
		String nextLine[] = null;
		File file = new File(filePath); 
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		String data[] = {"Ansh.J" + formattedEmail + prop.getProperty("userDomain"), "Ansh", "", "G", "Ansh.J" + formattedEmail + prop.getProperty("userDomain"), "", " ", "", "Active", "", "", "", "", ""};
		User.userEmail="Ansh.J" + formattedEmail + prop.getProperty("userDomain");
		User.userId="Ansh.J" + formattedEmail + prop.getProperty("userDomain");
		System.out.println(User.userEmail);
		if(count > 1)
		{
			String dataLevel [];
			for(int i = 2; i <= count; i++ )
				{
					String id = Integer.toString(i);
					String name = "level_update" + i;
					level = level + id + "," + name;
					if(i<count)
						level = level + ",";
				}
			dataLevel = level.split(",");
			nextLine = new String[data.length + dataLevel.length];
			System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
			System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
			System.out.println(nextLine);
		}
		try
		{
			Thread.sleep(5000);
	 		FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeNext(header);
			if(count > 1)
			{
				writer.writeNext(nextLine);
			}
			else
			{
				writer.writeNext(data);
			}
			writer.close();
			csvReader.close();
		}
		catch(Exception e)
		{
			System.out.println("Data no read");
			e.getMessage();
		}
		}
		catch(Exception e)
		{
		Assert.fail("File not downloaded");
		}
	}
	public void editdeatlis(int count)
	{
		String level = "";
		String nextLine[] = null;
		File file = new File(filePath); 
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		String data[] = {User.userId, "Anshupdate", "", "Gupdate", "Aupdate" + formattedEmail + prop.getProperty("userDomain"), "", "", "", "Active", "", "", "", "", ""};
		User.userEmail= "Aupdate" + formattedEmail + prop.getProperty("userDomain");
		if(count > 1)
		{
			String dataLevel [];
			for(int i = 2; i <= count; i++ )
				{
					String id = Integer.toString(i);
					String name = "level_" + i;
					level = level + id + "," + name;
					if(i<count)
						level = level + ",";
				}
			dataLevel = level.split(",");
			nextLine = new String[data.length + dataLevel.length];
			System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
			System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
			System.out.println(nextLine);
		}
		try
		{
			Thread.sleep(5000);
	 		FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeNext(header);
			if(count > 1)
			{
				writer.writeNext(nextLine);
			}
			else
			{
				writer.writeNext(data);
			}
			writer.close();
			csvReader.close();
		}
		catch(Exception e)
		{
			System.out.println("Data no read");
			e.getMessage();
		}
	}
	public void addFileDataLevelInActive(int count)
	{
		String level = "";
		String nextLine[] = null;
		File file = new File(filePath); 
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		String data[] = {"Ansh.G" + formattedEmail + prop.getProperty("userDomain"), "Ansh", "", "G", "Ansh.G" + formattedEmail + prop.getProperty("userDomain"), "", "", "", "Inactive", "", "", "", "", ""};
		User.userEmail="Ansh.G" + formattedEmail + prop.getProperty("userDomain");
		if(count > 1)
		{
			String dataLevel [];
			for(int i = 2; i <= count; i++ )
				{
					String id = Integer.toString(i);
					String name = "level_" + i;
					level = level + id + "," + name;
					if(i<count)
						level = level + ",";
				}
			dataLevel = level.split(",");
			nextLine = new String[data.length + dataLevel.length];
			System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
			System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
			System.out.println(nextLine);
		}
		try
		{
			Thread.sleep(5000);
	 		FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeNext(header);
			if(count > 1)
			{
				writer.writeNext(nextLine);
			}
			else
			{
				writer.writeNext(data);
			}
			writer.close();
			csvReader.close();
		}
		catch(Exception e)
		{
			System.out.println("Data no read");
			e.getMessage();
		}
	}
	public void userSearch(String unitName)
	{
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(searchTextUnitName));
			searchTextUnitName.sendKeys(unitName);
			
			searchIcon.click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(searchResultUnitName));
			String result = driver.findElement(By.xpath("//td[text()='"+User.userEmail+"']//following::td[3]/a[@data-target = '#unitdiv']")).getText();
			System.out.println(unitName);
			System.out.println(result);
			Assert.assertEquals(unitName, result);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
	}

	public void viewStudentDetails() 
	{
		try
		{
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewDetails));
		viewDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewUnitName));
		cancelViewDetails.click();
		}
		catch(Exception e)
		{
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(viewDetails));
			viewDetails.click();
			wait.until(ExpectedConditions.visibilityOf(viewUnitName));
			cancelViewDetails.click();
				
		}
	}
	public void viewStudentDetail() 
	{
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewDetails));
		viewDetails.click();
	}
	public void validate(String Header,String data) 
	{
		try
		{
		wait.until(ExpectedConditions.visibilityOf(viewUnitName));
	
		System.out.println("Header "+Header);
		System.out.println("Value"+data);
		
		if(Header.contains("Hire Date"))
		{	
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			Calendar cal = Calendar.getInstance();
			String	date =null;
			if(data.equals("tomorrow"))
			{
				cal = Calendar.getInstance();
				cal.add(Calendar.DAY_OF_MONTH, 1);
				
					date = dateFormat.format(cal.getTime());
				
			}
			else
			{
			
			
			date = dateFormat.format(cal.getTime());
			}
		Assert.assertEquals("Data doesnt match"+driver.findElement(By.xpath("//div[text()='"+Header+"']/following::div[1]")).getText(),driver.findElement(By.xpath("//div[text()='"+Header+"']/following::div[1]")).getText(), date);
		
		}
		else if(Header.contains("Email"))
		{	
			
		Assert.assertEquals("Data doesnt match"+driver.findElement(By.xpath("//div[text()='"+Header+"']/following::div[1]")).getText(),driver.findElement(By.xpath("//div[text()='"+Header+"']/following::div[1]")).getText(), User.userEmail);
		
		}
		else
		{
			Assert.assertEquals("Data doesnt match"+driver.findElement(By.xpath("//div[text()='"+Header+"']/following::div[1]")).getText(),driver.findElement(By.xpath("//div[text()='"+Header+"']/following::div[1]")).getText(), data);
		}
		}
		catch(Exception e)
		{
		Assert.fail(e.getMessage());
		}
	}
	
	
	public void validateHeaderforManageSubscribed (List<String> list) 
	{
		try
		{
		wait.until(ExpectedConditions.visibilityOfAllElements(ManageSubscribedColumns));
		reuse.validateTable(list, ManageSubscribedColumns);
		}
		catch(Exception e)
		{
		Assert.fail(e.getMessage());
		}
	}
	
	public void validateDataforManageSubscribed (String data,int i) 
	{
		try
		{
			if(AssignmentReport.checkifParmeterAvailable(data))
				data=AssignmentReport.getParmeterAvailable(data);

			if(courseListName.containsKey(data+"Option"))
				data=courseListName.get(data+"Option").toString();
		
		wait.until(ExpectedConditions.visibilityOfAllElements(ManageSubscribedColumns));
		if(data.equals("Today"))
		{
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			Calendar cal = Calendar.getInstance();
		data = dateFormat.format(cal.getTime());
		
				
		}
		else if(data.contains("Today+2year"))
		{
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			Calendar cal = Calendar.getInstance();
			cal.add((Calendar.YEAR), 2);  
			
		data = dateFormat.format(cal.getTime());
		
				
		}
		
		Assert.assertEquals(ManageSubscribedData.get(i).getText(), data);
		//		reuse.validateTable(list, ManageSubscribedColumns);
		}
		catch(Exception e)
		{
		Assert.fail(e.getMessage());
		}
	}
	

	
	public void validatetabledataviewcourse (String header,String data) 
	{
		try
		{
			if(AssignmentReport.checkifParmeterAvailable(data))
				data=AssignmentReport.getParmeterAvailable(data);

			if(courseListName.containsKey(data))
				data=courseListName.get(data).toString().replace(" (", "(");
		
		if(data.equals("Today"))
		{
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			Calendar cal = Calendar.getInstance();
		data = dateFormat.format(cal.getTime());
		
				
		}
		else if(data.contains("Today+2year"))
		{
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			Calendar cal = Calendar.getInstance();
			cal.add((Calendar.YEAR), 2);  
			
		data = dateFormat.format(cal.getTime());
		
				
		}
//		viewCourseTable'
	
		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(viewCourseTable+"//th"))));
		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(viewCourseTable+"//td"))));
		
		reuse.validatethedetails(header, viewCourseTable+"//th", data, viewCourseTable+"//td");
	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		Assert.fail(e.getMessage());
		}
	}
	
	public void validatetabledataviewtopic (String header,String data,int row) 
	{
		try
		{
			if(AssignmentReport.checkifParmeterAvailable(data))
				data=AssignmentReport.getParmeterAvailable(data);

			if(courseListName.containsKey(data))
				data=courseListName.get(data).toString();
		
		if(data.equals("Today"))
		{
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			Calendar cal = Calendar.getInstance();
		data = dateFormat.format(cal.getTime());
		
				
		}
		else if(data.contains("Today+2year"))
		{
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			Calendar cal = Calendar.getInstance();
			cal.add((Calendar.YEAR), 2);  
			
		data = dateFormat.format(cal.getTime());
		
				
		}
	
		reuse.validatethedetails(header, viewcourseTopicTable+"//th", data, viewcourseTopicTable+"//tr["+row+"]//td");
	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		Assert.fail(e.getMessage());
		}
	}
	
	
	public void cancelViewDetail() 
	{
		
		wait.until(ExpectedConditions.visibilityOf(cancelViewDetails));
		cancelViewDetails.click();
	}
	
	
	
	public void closeViewDetails() 
	{
		
		wait.until(ExpectedConditions.visibilityOf(closeViewDetails));
		closeViewDetails.click();
	}
	
	public void deleteStudentDetails() 
	{
//		//*[@id="learnerTableList"]//td[3][text()='Ansh.G102254@yopmail.com']/following-sibling::td[4]//a[@class="action_dropdown"]
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(deleteUser));
		deleteUser.click();
		try
		{
		Thread.sleep(5000);	
		}
		catch(Exception e)
		{
			
		}
	}
	


	public void errorMsg(String msg) 
	{
//		//*[@id="learnerTableList"]//td[3][text()='Ansh.G102254@yopmail.com']/following-sibling::td[4]//a[@class="action_dropdown"]
//		wait.until(ExpectedConditions.visibilityOf(errorMsg));
		Assert.assertTrue(driver.getPageSource().contains(msg));
		
	}
	public void editStudentDetails()
	{
		orgHome = new OrganizationHome();
	
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='learnerTableList']/tbody/tr[1]/td[7]/div/a"))));
		driver.findElement(By.xpath("//*[@id='learnerTableList']/tbody/tr[1]/td[7]/div/a")).click();
		wait.until(ExpectedConditions.visibilityOf(editDetails));
		editDetails.click();
		wait.until(ExpectedConditions.visibilityOf(editFirstName));
		String fName = editFirstName.getAttribute("value");
		editFirstName.click();
		editFirstName.clear();
	   editFirstName.sendKeys(fName + " update");
		editLastName.click();
		submitButton.click();
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewDetails));
		viewDetails.click();
		wait.until(ExpectedConditions.visibilityOf(cancelViewDetails));
		String viewFirst = viewFirstName.getText().trim();
		Assert.assertEquals(fName + " update", viewFirst);
		cancelViewDetails.click();
	}
	
	public void editallStudentDetails()
	{
		orgHome = new OrganizationHome();
	
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='learnerTableList']/tbody/tr[1]/td[7]/div/a"))));
		driver.findElement(By.xpath("//*[@id='learnerTableList']/tbody/tr[1]/td[7]/div/a")).click();
		wait.until(ExpectedConditions.visibilityOf(editDetails));
		editDetails.click();
		wait.until(ExpectedConditions.visibilityOf(editFirstName));
		String fName = editFirstName.getAttribute("value");
		editFirstName.click();
		editFirstName.clear();
		editFirstName.sendKeys(fName + " update");
		
		editMiddlename.click();

		editMiddlename.clear();
		editMiddlename.sendKeys("M"+" update");

		editLastName.click();
		editLastName.clear();
		editLastName.sendKeys("G"+" update");

		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		User.userEmail="Ansh.G" + formattedEmail + prop.getProperty("userDomain");
		editEmail.clear();
		editEmail.sendKeys(User.userEmail);
		
		year_of_exp.clear();
		year_of_exp.sendKeys("6");
	  
	    JavascriptExecutor js = (JavascriptExecutor)driver;

		
//		js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", FromDateRange,"value","2022/10/10");		
	js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", dob,"value", "1996/02/02" );		

	
		WebDriverWait wait = new WebDriverWait(driver, 30);
		 dateFormat = new SimpleDateFormat("dd");
		cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_MONTH, 1);
		
		
		String formattedStartDate = dateFormat.format(cal.getTime());
		
		
		hire_date.click();
		WebElement reqDate = driver.findElement(By.xpath("//td[@class='day' and text()='"+formattedStartDate+"']"));
		reqDate.click();
	    Select deflang = new Select(driver.findElement(By.xpath("//select[@id='job']")));
		deflang.selectByVisibleText("Jobname_3");

		  updateOrg("Organization Structure","Level 2");
		    updatedLevel("Level 2","Automation Test");

		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewDetails));
		viewDetails.click();
		wait.until(ExpectedConditions.visibilityOf(cancelViewDetails));
		String viewFirst = viewFirstName.getText().trim();
		Assert.assertEquals(fName + " update", viewFirst);
		cancelViewDetails.click();
	}
	
	public void emailStudentDetails()
	{
		orgHome = new OrganizationHome();
	
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", actionDetails);

		wait.until(ExpectedConditions.visibilityOf(editDetails));
		editDetails.click();
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		User.userEmail="Ansh.G" + formattedEmail + prop.getProperty("userDomain");
		wait.until(ExpectedConditions.visibilityOf(editEmail));
		
		editEmail.clear();
		editEmail.sendKeys(User.userEmail);
		editEmail.sendKeys("\t");
		
		submitButton.click();
		
	}

	public void viewEditDetails()
	{
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewDetails));
		viewDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewUnitName));
		editViewDetails.click();
		wait.until(ExpectedConditions.visibilityOf(editFirstName));
		String fName = editFirstName.getAttribute("value");
		editFirstName.click();
		editFirstName.clear();
		editFirstName.sendKeys(fName.replace(" update", ""));
		editLastName.click();
		submitButton.click();
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewDetails));
		viewDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewFirstName));
		String viewFirst = viewFirstName.getText().trim();
		Assert.assertEquals(fName.replace(" update", ""), viewFirst);
		cancelViewDetails.click();
	}

	public void getStudentDetails()
	{
		try
		{
			Thread.sleep(4000);
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		wait.until(ExpectedConditions.elementToBeClickable(actionDetails));
		}
		catch(Exception e)
		{
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			wait.until(ExpectedConditions.elementToBeClickable(actionDetails));
				
		}
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewDetails));
		viewDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewUnitName));
		firstName = viewFirstName.getText().trim();
		lastName = viewLastName.getText().trim();
		email = viewEmail.getText().trim();
		User.userEmail=email;
		
		System.out.println(firstName + " " + lastName + " " + email);
		cancelViewDetails.click();
	}
	

	public void setStudentInActive()
	{
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(Inactivate));
		Inactivate.click();
		wait.until(ExpectedConditions.visibilityOf(yesBtn));
		
		yesBtn.click();
		try
		{
		Thread.sleep(5000);	
		}
		catch(Exception e)
		{
			
		}
	}
	
	public void setStudentActive()
	{
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(activate));
		activate.click();
		wait.until(ExpectedConditions.visibilityOf(yesBtn));
		
		yesBtn.click();
		try
		{
		Thread.sleep(5000);	
		}
		catch(Exception e)
		{
			
		}
	}
	
	
	
	
	
	
	public void getStudentDetails(String level)
	{
		if(AssignmentReport. checkifParmeterAvailable(level))
			level=AssignmentReport.getParmeterAvailable(level);

	
	
		level=level.contains("OrgCTCName")?prop.get("orgName").toString():level;
		WebDriverWait wait = new WebDriverWait(driver, 100);
			try
			{
			Thread.sleep(5000);	
			}
			catch(Exception e)
			{
				
			}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"learnerTableList\"]//a[text()='"+level+"']//following::td[text()='Active']//preceding::td[3]"))));
		User.orgUserEmail=driver.findElement(By.xpath("//*[@id=\"learnerTableList\"]//a[text()='"+level+"']//following::td[text()='Active']//preceding::td[3]")).getText();
		
	
	}
	public void setFilterUserStatus(String status) throws InterruptedException
	{
		wait.until(ExpectedConditions.visibilityOf(userStatus));
		Select select = new Select(userStatus);
		select.selectByVisibleText(status);
		searchIcon.click();
		Thread.sleep(3000);
		
		
		
	}
	public void getStudentDetailsInActive()
	{
		
		try
		{
		wait.until(ExpectedConditions.visibilityOf(InactionDetails));
		InactionDetails.click();
		}
		catch(Exception e)
		{
			try
			{
			status.click();
			status.click();
			Thread.sleep(3000);
			}
			catch(Exception m)
			{
				statusLMS.click();
				statusLMS.click();
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
						
			}
			wait.until(ExpectedConditions.visibilityOf(InactionDetails));
			InactionDetails.click();
			
		}
		wait.until(ExpectedConditions.visibilityOf(InactionViewDetails));
		InactionViewDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewUnitName));
		firstName = viewFirstName.getText().trim();
		lastName = viewLastName.getText().trim();
		email = viewEmail.getText().trim();
		User.userEmail=email;
		System.out.println(firstName + " " + lastName + " " + email);
		cancelViewDetails.click();
	}

	public void updateInvalidReport()
	{
		boolean dwnld = false;
		int m=0;
		do 
		{
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			m++;
		}
		while(dwnld == false);
		File file = new File(filePath); 
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		String data[] = {"Ansh.G" + formattedEmail + prop.getProperty("userDomain"), "", "", "G", "Ansh.G" + formattedEmail + prop.getProperty("userDomain"), "", "", "", "Active", "", "", "", "", ""};
		try
		{
			Thread.sleep(5000);
     		FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeNext(header);
			writer.writeNext(data);
			writer.close();
			csvReader.close();
		}
		catch(Exception e)
		{
			e.getMessage();
		}
		readandUpdateFile();
	}

	public void uploadInavlidFile()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(uploadFileLink));
		uploadFileLink.click();
		wait.until(ExpectedConditions.visibilityOf(buttonClose));
		int count = Integer.parseInt(failureCount.getText());
		Assert.assertTrue(count == 1);
		buttonClose.click();
	}

	public void updateOptionalReport(int count)
	{
		boolean dwnld = false;
		int m=0;
		do 
		{
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			m++;
		}
		while(dwnld == false);
		String level = "";
		String nextLine[] = null;
		
		File file = new File(filePath); 
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		String data[] = {"","","","","Ansh.G" + formattedEmail + prop.getProperty("userDomain"), "Ansh", "", "G", "Ansh.G" + formattedEmail + prop.getProperty("userDomain"), 
				"Job_code_" + count, "Job_name_" + count, "", "Active", "", "", "", "", ""};
		if(count > 1)
		{
			String dataLevel [];
			for(int i = 2; i <= count; i++ )
				{
					String id = Integer.toString(i);
					String name = "level_" + i;
					level = level + id + "," + name;
					if(i<count)
						level = level + ",";
				}
			dataLevel = level.split(",");
			nextLine = new String[data.length + dataLevel.length];
			System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
			System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
			System.out.println(nextLine);
		}
		
		try
		{
			User.userEmail="Ansh.G" + formattedEmail + prop.getProperty("userDomain");
			OrganizationSettings.titleName="Job_name_" + count;
			OrganizationSettings.titleCode="Job_code_" + count;
			Thread.sleep(5000);
     		FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeNext(header);
			writer.writeNext(data);
			writer.close();
			csvReader.close();
		}
		catch(Exception e)
		{
			e.getMessage();
		}
		readandUpdateFile();
	}

	public void updateOptionalReportwithoutlevel(int count)
	{
		boolean dwnld = false;
		int m=0;
		do 
		{
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			m++;
		}
		while(dwnld == false);
		
		File file = new File(filePath); 
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		String data[] = {"Ansh.G" + formattedEmail + prop.getProperty("userDomain"), "Ansh", "", "G", "Ansh.G" + formattedEmail + prop.getProperty("userDomain"), 
				"Job_code_" + count, "Job_name_" + count, "", "Active", "", "", "", "", ""};
		try
		{
			User.userEmail="Ansh.G" + formattedEmail + prop.getProperty("userDomain");
			User.dropdn= "Job_name_" + count;
			OrganizationSettings.titleName= "Job_name_" + count;
			Thread.sleep(5000);
     		FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeNext(header);
			writer.writeNext(data);
			writer.close();
			csvReader.close();
		}
		catch(Exception e)
		{
			e.getMessage();
		}
		readandUpdateFile();
	}
	

	public void updateOptionalReportwithotlevel(int count)
	{
		User.usrEmail 	=new String[count];
		int m=0;
		boolean dwnld = false;
		do 
		{
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			m++;
		}
		while(dwnld == false);
		File file = new File(filePath); 
		try
		{
			Thread.sleep(10000);
		FileReader filereader = new FileReader(file);
		CSVReader csvReader = new CSVReader(filereader); 
		String header[] = csvReader.readNext();
		FileWriter outputfile = new FileWriter(file);
		CSVWriter writer = new CSVWriter(outputfile);
		writer.writeNext(header);
		
		for(int i=1;i<=count;i++)
		{
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		String data[] = {"Ansh.G"+i + formattedEmail + prop.getProperty("userDomain"), "Ansh"+i, "", "G"+i, "Ansh.G" +i+ formattedEmail + prop.getProperty("userDomain"), 
				"Job_code_" + count, "Job_name_" + count, "", "Active", "", "", "", "", ""};
	
			User.usrEmail[i-1]="Ansh.G" + formattedEmail + prop.getProperty("userDomain");
			User.dropdn= "Job_name_" + count;
			OrganizationSettings.titleName= "Job_name_" + count;
			Thread.sleep(5000);
     	
			writer.writeNext(data);
			
		}
		writer.close();
		csvReader.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		readandUpdateFile();
	}

	public void updateOptionalReportwithoutlevelblankjobtitle(int count)
	{
		boolean dwnld = false;
		int m=0;
		do 
		{
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			m++;
		}
		while(dwnld == false);
		File file = new File(filePath); 
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		String data[] = {"Ansh.G" + formattedEmail + prop.getProperty("userDomain"), "Ansh", "", "G", "Ansh.G" + formattedEmail + prop.getProperty("userDomain"), 
				" ", " ", "", "Active", "", "", "", "", ""};
		try
		{
			User.userEmail="Ansh.G" + formattedEmail + prop.getProperty("userDomain");
			User.dropdn= " ";
			OrganizationSettings.titleName= " ";
			Thread.sleep(5000);
     		FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeNext(header);
			writer.writeNext(data);
			writer.close();
			csvReader.close();
		}
		catch(Exception e)
		{
			e.getMessage();
		}
		readandUpdateFile();
	}
	public void updateOptionalReportHireDate(int count)
	{
		boolean dwnld = false;
		int m=0;
		do 
		{
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			m++;
		}
		while(dwnld == false);
		File file = new File(filePath); 
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		cal.add(Calendar.DAY_OF_MONTH, -1);
		String hireDate = dateFormat.format(cal.getTime());
		System.out.println(hireDate);
		String data[] = {"Ansh.G" + formattedEmail + prop.getProperty("userDomain"), "Ansh", "", "G", "Ansh.G" + formattedEmail + prop.getProperty("userDomain"), 
				"", "", String.valueOf(hireDate), "Active", "", "", "", "", ""};
		try
		{
			User.userEmail="Ansh.G" + formattedEmail + prop.getProperty("userDomain");
			Thread.sleep(5000);
     		FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeNext(header);
			writer.writeNext(data);
			writer.close();
			csvReader.close();
		}
		catch(Exception e)
		{
			e.getMessage();
		}
		readandUpdateFile();
	}

	
	public void updateOptionalReportGroup(String name)
	{
		boolean dwnld = false;
		int m=0;
		do 
		{
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			m++;
		}
		while(dwnld == false);
		File file = new File(filePath); 
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		cal.add(Calendar.DAY_OF_MONTH, -1);
		String date = dateFormat.format(cal.getTime());
		System.out.println(date);
		String data[] = {"", "", "", "","Ansh.G" + formattedEmail + prop.getProperty("userDomain"), "Ansh", "", "G", "Ansh.G" + formattedEmail + prop.getProperty("userDomain"), 
				"", "", "", "Active", "", "", "", "", "", name + "_" + date.replace("/", "")};
		try
		{
			User.userEmail="Ansh.G" + formattedEmail + prop.getProperty("userDomain");
			User.dropdn= name + "_" + date.replace("/", "");
			User.group=new String[2];
			User.group[0]= name + "_" + date.replace("/", "");
			Thread.sleep(5000);
     		FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeNext(header);
			writer.writeNext(data);
			writer.close();
			csvReader.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		readandUpdateFile();
	}

	public void viewCourses()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewCourses));
		viewCourses.click();
	}
	

	public void validatenocourse()
	{
		wait.until(ExpectedConditions.visibilityOf(noCoursedata));
		wait.until(ExpectedConditions.visibilityOf(closebtn));
		
		Assert.assertEquals(noCoursedata.getText(), "No Course data available");
		
		closebtn.click();
		
	}
	
	public void ManageCourses()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(ManageCourses));
		ManageCourses.click();
		wait.until(ExpectedConditions.visibilityOf(updateSubscriptionDetails));
		updateSubscriptionDetails.click();
		
		wait.until(ExpectedConditions.visibilityOf(SubscriptionDate));
		
		  LocalDateTime myDateObj = LocalDateTime.now().plusDays(1);
		    System.out.println("Before formatting: " + myDateObj);
		    DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("MM/dd/yyyy");

		    String formattedDate = myDateObj.format(myFormatObj);
		    SubscriptionDate.clear();
		    
		    SubscriptionDate.sendKeys(formattedDate);
			wait.until(ExpectedConditions.visibilityOf(UpdateBtn));
			UpdateBtn.click();
			
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@class='tab-content']//div[@class='alert alert-success alert-dismissable']"))));

			String  msg=driver.findElement(By.xpath("//div[@class='tab-content']//div[@class='alert alert-success alert-dismissable']")).getText();
			
			 Assert.assertTrue(msg.contains("Student license updated successfully."));
				
			myDateObj = LocalDateTime.now().plusDays(1);
		    System.out.println("Before formatting: " + myDateObj);
		     myFormatObj = DateTimeFormatter.ofPattern("yyyy/MM/dd");

		     formattedDate = myDateObj.format(myFormatObj);
		
		     Assert.assertEquals(formattedDate, enddate.getText());
		
	}
	public void viewActivities()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(viewActivities));
		viewActivities.click();
	}

	public void completeCourse()
	{
		WebDriverWait wait = new WebDriverWait(driver, 120);
		wait.until(ExpectedConditions.visibilityOf(courseTable));
		List<WebElement> rowCourse = driver.findElements(By.xpath(courseTableRow));
		for (int i = 1; i <= rowCourse.size(); i++ ) 
		{

	        reuse.waitforsec(3);
	    	
	        wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(comActivity))));
			
	        List<WebElement> comple = driver.findElements(By.xpath(comActivity));
			
			comple.get(0).click();
			wait.until(ExpectedConditions.visibilityOf(advancedActivity));
			advancedActivity.click();
			wait.until(ExpectedConditions.visibilityOf(successMsg));
			  Assert.assertTrue("Message in correct"+successMsg.getText(),successMsg.getText().contains("Successfully marked course activity as completed."));
			  wait.until(ExpectedConditions.visibilityOf(closeSuccess));
				
			  ;closeSuccess.click();
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			wait.until(ExpectedConditions.visibilityOf(viewActivity));
			executor.executeScript("arguments[0].click();", viewActivity);
		
		
		}
		wait.until(ExpectedConditions.visibilityOf(closeCourses));
		closeCourses.click();
	}
	
	public void resetPassword()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(reset));
		reset.click();
		wait.until(ExpectedConditions.visibilityOf(confirmButton));
		confirmButton.click();
		
	}
	public void clickonSubmitBtn()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		
	   wait.until(ExpectedConditions.visibilityOf(confirmButton));
	
	confirmButton.click();
	}
	@SuppressWarnings("resource")
	public void addFileDataScrom_LMS(int userCount)
	{
		try 
		{
			boolean dwnld = false;
			int m=0;
			do 
			{
				dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
				if(m==pagload)
					break;
				else
				{
					try {
						Thread.sleep(550);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				m++;
			}
			while(dwnld == false);
			Thread.sleep(3000);
			File file = new File(filePath); 
			FileReader filereader = new FileReader(file);
			
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			CSVWriter writer = new CSVWriter(new FileWriter(filePath));
			DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
			Calendar cal = Calendar.getInstance();
			String email = dateFormat.format(cal.getTime());
			String formattedEmail = email.replace(":", "");
			List<String[]> list = new ArrayList<String[]>();
			list.add(header);
			for(int i=1; i<= userCount; i++)
			{
				if(userCount==1)
				Students.email = "Ansh.G" + i + formattedEmail + prop.getProperty("userDomain");
				
				String row[] = {"Ansh.G" + i + formattedEmail + prop.getProperty("userDomain"), "Ansh" + i, "", "G" + i, "Ansh.G" + i + formattedEmail + prop.getProperty("userDomain"), "", "", "", "Active", "", "", "", "", ""};
				list.add(row);
			}
			writer.writeAll(list);
			writer.flush();
			readandUpdateFile();
	} 
		catch (Exception e) 
		{
		e.printStackTrace();
		}
	}
	public void clickOnActionButton() {
		ClickOnActionsButton.click();
	}
	
	public void selectDropDownValueFromList(String dropDownValue) {
		TestUtils.selectFromTheList(DropDown, dropDownValue );
	}

	public void clickOnPasswordResetLink() {
		try {
			Thread.sleep(1000);
			wait.until(ExpectedConditions.elementToBeClickable(Button_Yes));
			Button_Yes.click();
			
		} catch (InterruptedException e) {
			Assert.fail("Reset password link is not available");
			e.printStackTrace();
		}
		
	}
	
	
	public void flashmessage() {
		String flash_message = Flash_message.getText();
		Assert.assertEquals(flash_message, "Reset Password mail send to user successfully!");
	}
	
	
	public void Users_Tabs(String value) throws InterruptedException {
		Thread.sleep(1000);
		TestUtils.selectFromTheList(Users_Tabs, value);
	}
	
	public void Notifications_Tabs(String value) throws InterruptedException {
		Thread.sleep(1000);
		TestUtils.selectFromTheList(Notifications_Tabs, value);
	}
	

	public void emailStudentDetailsToUpperCase()
	{
		orgHome = new OrganizationHome();
	
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"learnerTableList\"]/tbody/tr[1]/td[7]/div/a"))));
		driver.findElement(By.xpath("//*[@id=\"learnerTableList\"]/tbody/tr[1]/td[7]/div/a")).click();
		wait.until(ExpectedConditions.visibilityOf(editDetails));
		editDetails.click();
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		User.userEmail="Ansh.G" + formattedEmail + prop.getProperty("userDomain");
		wait.until(ExpectedConditions.visibilityOf(editEmail));
		
		editEmail.clear();
		editEmail.sendKeys(User.userEmail.toUpperCase());
		System.out.println(" The uppercase value is"+ User.userEmail.toUpperCase());
		editEmail.sendKeys("\t");
		
		submitButton.click();
		wait.until(ExpectedConditions.visibilityOf(manageStudentTab));
		
		
		
	}
	@SuppressWarnings("unchecked")
	public void searchStudentByEmailId(String EmailId) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor)TestBase.driver;
			  jse.executeScript("window.scrollBy(0,-1250)");
			wait.until(ExpectedConditions.visibilityOf(searchTextEmailId));
			searchTextEmailId.clear();
			searchTextEmailId.sendKeys(EmailId);
			searchIcon.click();
			Thread.sleep(7000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void updateOptionalReportwithotlevel(int count,int count1)
    {
        User.usrEmail     =new String[count];
        String level="";
        int counter = 0;
        try {
        boolean dwnld = false;
        do
        {
            dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
            Thread.sleep(5000);
            counter++;
            if(counter>12)
                Assert.fail("Not able to load page after waiting for 1 minute");
        }
        while(dwnld == false);
        File file = new File(filePath);
        Thread.sleep(10000);
        FileReader filereader = new FileReader(file);
        CSVReader csvReader = new CSVReader(filereader);
        String header[] = csvReader.readNext();
        FileWriter outputfile = new FileWriter(file);
        CSVWriter writer = new CSVWriter(outputfile);
        writer.writeNext(header);
        String nextLine[] = null;
        for(int i=1;i<=count;i++)
        {
        DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        Calendar cal = Calendar.getInstance();
        String email = dateFormat.format(cal.getTime());
        String formattedEmail = email.replace(":", "");
        
        String data[] = {"Ansh.G"+i + formattedEmail + prop.getProperty("userDomain"), "Ansh"+i, "", "G"+i, "Ansh.G" +i+ formattedEmail + prop.getProperty("userDomain"),
                "Job_code_" + count, "Job_name_" + count, "", "Active", "", "", "", "", ""};
        level="";
        if(count1 > 1)
        {
            String dataLevel [];
            for(int m = 2; m <= count1; m++ )
                {
                    String id = Integer.toString(i);
                    String name = "level_" + m;
                    level = level + id + "," + name;
                    if(m<count1)
                        level = level + ",";
                }
            dataLevel = level.split(",");
            nextLine = new String[data.length + dataLevel.length];
            System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
            System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
            System.out.println(nextLine);
        }
            User.usrEmail[i-1]="Ansh.G"+i + formattedEmail + prop.getProperty("userDomain");
            User.userEmail="Ansh.G"+i + formattedEmail+ prop.getProperty("userDomain");
            User.userId="Ansh.G"+i + formattedEmail + prop.getProperty("userDomain");
            OrganizationSettings.titleName= "Job_name_" + count;
            Thread.sleep(5000);
         
            writer.writeNext(nextLine);
            
        }
        writer.close();
        csvReader.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        readandUpdateFile();
    }
	public void updateOptionalReportwithotlevelHire(int count,int count1)
    {
        User.usrEmail     =new String[count];
        String level="";
        int counter = 0;
        try {
        boolean dwnld = false;
        do
        {
            dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
            Thread.sleep(5000);
            counter++;
            if(counter>12)
                Assert.fail("Not able to load page after waiting for 1 minute");
        }
        while(dwnld == false);
        File file = new File(filePath);
        FileReader filereader = new FileReader(file);
        CSVReader csvReader = new CSVReader(filereader);
        String header[] = csvReader.readNext();
        FileWriter outputfile = new FileWriter(file);
        CSVWriter writer = new CSVWriter(outputfile);
        writer.writeNext(header);
        String nextLine[] = null;
        for(int i=1;i<=count;i++)
        {
        DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        Calendar cal = Calendar.getInstance();
        String email = dateFormat.format(cal.getTime());
        String formattedEmail = email.replace(":", "");
        
        DateFormat dateFormat1 = new SimpleDateFormat("MM-dd-yyyy");
		 cal = Calendar.getInstance();

		String formattedStartDate = dateFormat1.format(cal.getTime());
		
		
        
        String data[] = {"Ansh.G"+i + formattedEmail + prop.getProperty("userDomain"), "Ansh"+i, "", "G"+i, "Ansh.G" +i+ formattedEmail + prop.getProperty("userDomain"),
                "", "", formattedStartDate, "Active", "", "", "", "", ""};
        level="";
        if(count1 > 1)
        {
            String dataLevel [];
            for(int m = 2; m <= count1; m++ )
                {
                    String id = Integer.toString(i);
                    String name = "level_" + m;
                    level = level + id + "," + name;
                    if(m<count1)
                        level = level + ",";
                }
            dataLevel = level.split(",");
            nextLine = new String[data.length + dataLevel.length];
            System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
            System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
            System.out.println(nextLine);
        }
            User.usrEmail[i-1]="Ansh.G"+i + formattedEmail + prop.getProperty("userDomain");
            User.userEmail="Ansh.G"+i + formattedEmail + prop.getProperty("userDomain");
            User.userId="Ansh.G"+i + formattedEmail+ prop.getProperty("userDomain");
//            Thread.sleep(5000);
         
            writer.writeNext(nextLine);
            
        }
        writer.close();
        csvReader.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        readandUpdateFile();
    }
	
	public void updateOptionalReportGroup(String group,int count)
	{

		try
		{
			boolean dwnld = false;
			int m=0;
			do 
			{
				dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
				if(m==pagload)
					break;
				else
				{
					try {
						Thread.sleep(550);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				m++;
			}
			while(dwnld == false);
		String level = "";
		String nextLine[] = null;
		File file = new File(filePath); 
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		
		dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		cal.add(Calendar.DAY_OF_MONTH, -1);
		String date = dateFormat.format(cal.getTime());
		String data[] = {"Ansh.G" + formattedEmail + prop.getProperty("userDomain"), "Ansh", "", "G", "Ansh.G" + formattedEmail + prop.getProperty("userDomain"), 
				"", "", "", "Active", "", "", "", "", "", group + "_" + formattedEmail};
		User.userEmail="Ansh.G" + formattedEmail + prop.getProperty("userDomain");
		User.userId="Ansh.G" + formattedEmail + prop.getProperty("userDomain");
		OrganizationSettings.groupName=group + "_" + formattedEmail;
		
		if(count > 1)
		{
			String dataLevel [];
			for(int i = 2; i <= count; i++ )
				{
					String id = Integer.toString(i);
					String name = "level_" + i;
					level = level + id + "," + name;
					if(i<count)
						level = level + ",";
				}
			dataLevel = level.split(",");
			nextLine = new String[data.length + dataLevel.length];
			System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
			System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
			System.out.println(nextLine);
		}
		try
		{
			Thread.sleep(5000);
	 		FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeNext(header);
			if(count > 1)
			{
				writer.writeNext(nextLine);
			}
			else
			{
				writer.writeNext(data);
			}
			writer.close();
			csvReader.close();
		}
		catch(Exception e)
		{
			System.out.println("Data no read");
			e.getMessage();
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		Assert.fail("File not downloaded");
		}
	
		
		
		readandUpdateFile();
	}
	
	public void unenrollCourseWithNameLMSnodisplay(String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
			
	
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(unenrollCourse));
		List<WebElement> courseList = driver.findElements(By.xpath(courseSubscriptionTable));
		int originalCount = courseList.size();
		for(int i = 1; i <= originalCount; i++)
		{
			String productCode = driver.findElement(By.xpath(courseSubscriptionTable + "[" + i + "]/td[1]")).getText();
			String productName = driver.findElement(By.xpath(courseSubscriptionTable + "[" + i + "]/td[2]")).getText();
			String actualCourse = productName;
			if(course.equalsIgnoreCase(actualCourse))
			{
				try
				{
				driver.findElement(By.xpath(courseSubscriptionTable + "[" + i + "]/td[8]/a")).click();
				Assert.fail("Unenroll is should not avalble");
				wait.until(ExpectedConditions.visibilityOf(unenrollCheckBox));
				unenrollCheckBox.click();
				wait.until(ExpectedConditions.visibilityOf(unenrollCourseDeleteYes));
				unenrollCourseDeleteYes.click();
				break;
				}
				catch(Exception e )
				{
					
				}
			}
		}
		
		
	}
	public void viewEditEmailDetails()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewDetails));
		viewDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewUnitName));
		editViewDetails.click();
		wait.until(ExpectedConditions.visibilityOf(editFirstName));
		String fName = editFirstName.getAttribute("value");
		String femail = editEmail.getAttribute("value");
		editFirstName.click();
		editFirstName.clear();
		editFirstName.sendKeys(fName + " update");
		editEmail.click();
		editEmail.clear();
		editEmail.sendKeys(femail.replace("@", "_update@"));
		editLastName.click();		
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", submitButton);
		driver.navigate().refresh();
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewDetails));
		viewDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewFirstName));
		String viewFirst = viewFirstName.getText().trim();
		Assert.assertEquals(fName + " update", viewFirst);
		cancelViewDetails.click();
	}
	
	public void clickonEditStudentDetails()
	{
		orgHome = new OrganizationHome();
		JavascriptExecutor js = (JavascriptExecutor)driver;
		String pageValue = js.executeScript("return document.readyState").toString();
		System.out.println(pageValue);
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='learnerTableList']/tbody/tr[1]/td[7]/div/a"))));
		driver.findElement(By.xpath("//*[@id='learnerTableList']/tbody/tr[1]/td[7]/div/a")).click();
		wait.until(ExpectedConditions.visibilityOf(editDetails));
		editDetails.click();
		
	}
	
	
//	public void updateOrganizationStructure(String level)
//	{
//		orgHome = new OrganizationHome();
//	
//		wait.until(ExpectedConditions.visibilityOf(editLevel));
//		
//		editLevel.click();
//		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[contains(text(),'"+level+"')]/ancestor::div[@class='form-group left-label clearfix']//select"))));
//		
//		driver.findElement(By.xpath("//div[contains(text(),'"+level+"')]/ancestor::div[@class='form-group left-label clearfix']//select")).click();
//		Select deflang = new Select(driver.findElement(By.xpath("//div[contains(text(),'"+level+"')]/ancestor::div[@class='form-group left-label clearfix']//select")));
//		deflang.selectByVisibleText(levelname);
//	wait.until(ExpectedConditions.visibilityOf(apply));
//	apply.click();
//	wait.until(ExpectedConditions.visibilityOf(update_Student));
//		
//	update_Student.click();
//	}
	
	
	public void updateOrg(String level,String levelname)
	{
		orgHome = new OrganizationHome();
	
		wait.until(ExpectedConditions.visibilityOf(editLevel));
		
		editLevel.click();
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[contains(text(),'"+level+"')]/ancestor::div[@class='form-group left-label clearfix']//select"))));
		
		driver.findElement(By.xpath("//div[contains(text(),'"+level+"')]/ancestor::div[@class='form-group left-label clearfix']//select")).click();
		Select deflang = new Select(driver.findElement(By.xpath("//div[contains(text(),'"+level+"')]/ancestor::div[@class='form-group left-label clearfix']//select")));
		deflang.selectByVisibleText(levelname);
	}
	public void updateLevel(String level,String levelname)
	{
		orgHome = new OrganizationHome();
	
		wait.until(ExpectedConditions.visibilityOf(editLevel));
		
		editLevel.click();
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[contains(text(),'"+level+"')]/ancestor::div[@class='form-group left-label clearfix']//select"))));
		
		driver.findElement(By.xpath("//div[contains(text(),'"+level+"')]/ancestor::div[@class='form-group left-label clearfix']//select")).click();
		Select deflang = new Select(driver.findElement(By.xpath("//div[contains(text(),'"+level+"')]/ancestor::div[@class='form-group left-label clearfix']//select")));
		deflang.selectByVisibleText(levelname);
	wait.until(ExpectedConditions.visibilityOf(apply));
	apply.click();
	wait.until(ExpectedConditions.visibilityOf(update_Student));
		
	update_Student.click();
	}
	public void updatedLevel(String level,String levelname)
	{
		orgHome = new OrganizationHome();
	
//		wait.until(ExpectedConditions.visibilityOf(editLevel));
//		
//		editLevel.click();
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[contains(text(),'"+level+"')]/ancestor::div[@class='form-group left-label clearfix']//select"))));
		
		driver.findElement(By.xpath("//div[contains(text(),'"+level+"')]/ancestor::div[@class='form-group left-label clearfix']//select")).click();
		Select deflang = new Select(driver.findElement(By.xpath("//div[contains(text(),'"+level+"')]/ancestor::div[@class='form-group left-label clearfix']//select")));
		deflang.selectByVisibleText(levelname);
	wait.until(ExpectedConditions.visibilityOf(apply));
	apply.click();
	wait.until(ExpectedConditions.visibilityOf(update_Student));
		
	update_Student.click();
	}
	public void prepareFile(int userCount,int levelCount)
	{
		boolean dwnld = false;
		int counter = 0;
		try {
		do 
		{
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to download after waiting for 1 minute");
		}
		while(dwnld == false);
		}
		catch(Exception e) {
		}
		addFileData(userCount, levelCount); 
		readandUpdateFile();
	}
	public void addFileData(int userCount,int levelCount)
	{
		String level = "";
		String nextLine[] = null;
		try
		{
			File file = new File(filePath); 
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeNext(header);
			for(int i=1;i<=userCount;i++)
		    {
		    DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		    Calendar cal = Calendar.getInstance();
		    String email = dateFormat.format(cal.getTime());
		    String formattedEmail = email.replace(":", "");
		
		    String data[] = {"Ansh.G"+i + formattedEmail + prop.getProperty("userDomain"), "Ansh"+i, "", "G"+i, "Ansh.G" +i+ formattedEmail + prop.getProperty("userDomain"),
		            "", "", "", "Active", "", "", "", "", ""};
		    level="";
			if(levelCount > 1)
			{
				String dataLevel [];
				for(int j = 2; j <= levelCount; j++ )
					{
						String id = Integer.toString(j);
						String name = "level_" + j;
						level = level + id + "," + name;
						if(j<levelCount)
							level = level + ",";
					}
				dataLevel = level.split(",");
				nextLine = new String[data.length + dataLevel.length];
				System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
				System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
				System.out.println(nextLine);
			}
				Thread.sleep(2000);
				writer.writeNext(nextLine);
		}
			writer.flush();
			writer.close();
			filereader.close();
			csvReader.close();
		}
		catch(Exception e)
		{
			System.out.println("Data no read");
			System.out.println(e.getMessage());
		}
	}
	
	public void prepareFileSpecialCharacter(int userCount,int levelCount)
	{
		boolean dwnld = false;
		int counter = 0;
		try {
		do 
		{
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to download after waiting for 1 minute");
		}
		while(dwnld == false);
		}
		catch(Exception e) {
		}
		addFileDataSpecialCharacter(userCount, levelCount); 
		readandUpdateFile();
	}
	public void addFileDataSpecialCharacter(int userCount,int levelCount)
	{
		String level = "";
		String nextLine[] = null;
		try
		{
			File file = new File(filePath); 
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeNext(header);
			String characters = "._-'";
			for(int i=1;i<=userCount;i++)
		    {
		    DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		    Calendar cal = Calendar.getInstance();
		    String email = dateFormat.format(cal.getTime());
		    String formattedEmail = email.replace(":", "");
		
		    String data[] = {"Ansh.G" + characters +i , "Ansh" + characters +i, "", "G" + characters +i, "Ansh.G" +i+ formattedEmail + prop.getProperty("userDomain"),
		            "", "", "", "Active", "", "", "", "", ""};
		    level="";
			if(levelCount > 1)
			{
				String dataLevel [];
				for(int j = 2; j <= levelCount; j++ )
					{
						String id = Integer.toString(j);
						String name = "level_" + j;
						level = level + id + "," + name;
						if(j<levelCount)
							level = level + ",";
					}
				dataLevel = level.split(",");
				nextLine = new String[data.length + dataLevel.length];
				System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
				System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
				System.out.println(nextLine);
			}
				Thread.sleep(2000);
				writer.writeNext(nextLine);
		}
			writer.flush();
			writer.close();
			filereader.close();
			csvReader.close();
		}
		catch(Exception e)
		{
			System.out.println("Data no read");
			System.out.println(e.getMessage());
		}
	}
	public void prepareFileEachDetail(int levelCount)
	{
		boolean dwnld = false;
		int counter = 0;
		try {
		do 
		{
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to download after waiting for 1 minute");
		}
		while(dwnld == false);
		}
		catch(Exception e) {
		}
		addFileDataEachDetail(levelCount); 
		readandUpdateFile();
	}

	public void addFileDataEachDetail(int levelCount)
	{
		String level = "";
		String nextLine[] = null;
		try
		{
			File file = new File(filePath); 
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeNext(header);
			DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		    Calendar cal = Calendar.getInstance();
		    String email = dateFormat.format(cal.getTime());
		    String formattedEmail = email.replace(":", "");
		
		    String dataNormal[] = {"Ansh.G1" , "Ansh1", "", "G1", "Ansh.G1"+ formattedEmail + prop.getProperty("userDomain"),
		            "", "", "", "Active", "", "", "", "", ""};
		    level="";
		    String dataLevel [] = null;
			if(levelCount > 1)
			{				
				for(int j = 2; j <= levelCount; j++ )
					{
						String id = Integer.toString(j);
						String name = "level_" + j;
						level = level + id + "," + name;
						if(j<levelCount)
							level = level + ",";
					}
				dataLevel = level.split(",");
				nextLine = new String[dataNormal.length + dataLevel.length];
				System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
				System.arraycopy(dataNormal, 0, nextLine, dataLevel.length, dataNormal.length);
				System.out.println(nextLine);
			}
				Thread.sleep(2000);
				writer.writeNext(nextLine);
				String date = LocalDate.now().toString();
				String dataJob[] = {"Ansh.G2" , "Ansh2", "", "G2", "Ansh.G2"+ formattedEmail + prop.getProperty("userDomain"), "JobCode"+date, "JobDetail"+date, "", "Active", "", "","", "", ""};
				OrganizationSettings.titleName = "JobDetail"+date;
				nextLine = new String[dataJob.length + dataLevel.length];
				System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
				System.arraycopy(dataJob, 0, nextLine, dataLevel.length, dataJob.length);	
				writer.writeNext(nextLine);
				date = LocalDate.now().format(DateTimeFormatter.ofPattern("MM-dd-YYYY")).toString();
				String dataHireDate[] = {"Ansh.G3" , "Ansh3", "", "G3", "Ansh.G3"+ formattedEmail + prop.getProperty("userDomain"), "", "", date, "Active", "", "","", "", ""};
				nextLine = new String[dataHireDate.length + dataLevel.length];
				System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
				System.arraycopy(dataHireDate, 0, nextLine, dataLevel.length, dataHireDate.length);	
				writer.writeNext(nextLine);
				date = LocalDate.now().plusDays(-1).format(DateTimeFormatter.ofPattern("MM-dd-YYYY")).toString();
				String dataPastHireDate[] = {"Ansh.G4" , "Ansh4", "", "G4", "Ansh.G4"+ formattedEmail + prop.getProperty("userDomain"), "", "", date, "Active", "", "","", "", ""};
				nextLine = new String[dataHireDate.length + dataLevel.length];
				System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
				System.arraycopy(dataPastHireDate, 0, nextLine, dataLevel.length, dataPastHireDate.length);	
				writer.writeNext(nextLine);
				writer.flush();
				writer.close();
				filereader.close();
				csvReader.close();
		}
		catch(Exception e)
		{
			System.out.println("Data no read");
			System.out.println(e.getMessage());
		}
	}
	
	public void prepareFileUnitWithJobDetails(int userCount,int levelCount)
	{
		boolean dwnld = false;
		int counter = 0;
		try {
		do 
		{
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to download after waiting for 1 minute");
		}
		while(dwnld == false);
		}
		catch(Exception e) {
		}
		addFileDataUnitJobTitleDetails(userCount, levelCount); 
		readandUpdateFile();
	}
	public void prepareFileWithJobDetails(int userCount,int levelCount)
	{
		boolean dwnld = false;
		int counter = 0;
		try {
		do 
		{
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to download after waiting for 1 minute");
		}
		while(dwnld == false);
		}
		catch(Exception e) {
		}
		addFileDataJobTitleDetails(userCount, levelCount); 
		readandUpdateFile();
	}
	

	public void addFileDataJobTitleDetails(int userCount,int levelCount)
	{
		String level = "";
		String nextLine[] = null;
		try
		{
			File file = new File(filePath); 
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeNext(header);
			for(int i=1;i<=userCount;i++)
		    {
		    DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		    Calendar cal = Calendar.getInstance();
		    String email = dateFormat.format(cal.getTime());
		    String formattedEmail = email.replace(":", "");
		    String date = LocalDate.now().toString();
		    String data[] = {"Ansh.G"+i + formattedEmail + prop.getProperty("userDomain"), "Ansh"+i, "", "G"+i, "Ansh.G" +i+ formattedEmail + prop.getProperty("userDomain"),
		    		"JobCode"+date, "JobDetail"+date, "", "Active", "", "", "", "", ""};
		    OrganizationSettings.titleName = "JobDetail" + date;
		    OrganizationSettings.titleCode = "JobCode" + date;
		    level=" ";
		    String[] dataLevel=null;
		    if(levelCount > 1)
			{				
				for(int j = 2; j <= levelCount; j++ )
					{
						String id = Integer.toString(j);
						String name = "level_" + j;
						level = level + id + "," + name;
						if(j<levelCount)
							level = level + ",";
					}
				dataLevel = level.split(",");
				nextLine = new String[data.length + dataLevel.length];
				System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
				System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
				System.out.println(nextLine);
			}
				Thread.sleep(2000);
				writer.writeNext(nextLine);
		}
			writer.flush();
			writer.close();
			filereader.close();
			csvReader.close();
		}
		catch(Exception e)
		{
			System.out.println("Data no read");
			System.out.println(e.getMessage());
		}
	}
	public void  addFileDataUnitJobTitleDetails(int userCount,int levelCount)
	{
		String level = "";
		String nextLine[] = null;
		try
		{
			File file = new File(filePath); 
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeNext(header);
			for(int i=1;i<=userCount;i++)
		    {
		    DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		    Calendar cal = Calendar.getInstance();
		    String email = dateFormat.format(cal.getTime());
		    String formattedEmail = email.replace(":", "");
		    String date = LocalDate.now().toString();
		    String data[] = {"Ansh.G"+i + formattedEmail + prop.getProperty("userDomain"), "Ansh"+i, "", "G"+i, "Ansh.G" +i+ formattedEmail + prop.getProperty("userDomain"),
		    		"JobCode"+date, "JobDetail"+date, "", "Active", "", "", "", "", ""};
		    OrganizationSettings.titleName = "JobDetail" + date;
		    OrganizationSettings.titleCode = "JobCode" + date;
		    level=" ";
			if(levelCount > 1)
			{
				String dataLevel [];
				for(int j = 2; j <= levelCount; j++ )
					{
						String name = OrganizationSettings.newUnitName;
						level = level + "," + name;
						if(j<levelCount)
							level = level + ",";
					}
				dataLevel = level.split(",");
				nextLine = new String[data.length + dataLevel.length];
				System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
				System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
				System.out.println(nextLine);
			}
				Thread.sleep(2000);
				writer.writeNext(nextLine);
		}
			writer.flush();
			writer.close();
			filereader.close();
			csvReader.close();
		}
		catch(Exception e)
		{
			System.out.println("Data no read");
			System.out.println(e.getMessage());
		}
	}
	public void prepareFileUnitDetails(int userCount,int levelCount)
	{
		boolean dwnld = false;
		int counter = 0;
		try {
		do 
		{
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to download after waiting for 1 minute");
		}
		while(dwnld == false);
		}
		catch(Exception e) {
		}
		addFileDataUnitDetails(userCount, levelCount); 
		readandUpdateFile();
	}
	public void addFileDataUnitDetails(int userCount,int levelCount)
	{
		String level = "";
		String nextLine[] = null;
		try
		{
			File file = new File(filePath); 
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeNext(header);
			for(int i=1;i<=userCount;i++)
		    {
		    DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		    Calendar cal = Calendar.getInstance();
		    String email = dateFormat.format(cal.getTime());
		    String formattedEmail = email.replace(":", "");
		
		    String data[] = {"Ansh.G"+i + formattedEmail + prop.getProperty("userDomain"), "Ansh"+i, "", "G"+i, "Ansh.G" +i+ formattedEmail + prop.getProperty("userDomain"),
		            "", "", "", "Active", "", "", "", "", ""};
		    level=" ";
			if(levelCount > 1)
			{
				String dataLevel [];
				for(int j = 2; j <= levelCount; j++ )
					{
						String name = OrganizationSettings.newUnitName;
						level = level + "," + name;
						if(j<levelCount)
							level = level + ",";
					}
				dataLevel = level.split(",");
				nextLine = new String[data.length + dataLevel.length];
				System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
				System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
				System.out.println(nextLine);
			}
				Thread.sleep(2000);
				writer.writeNext(nextLine);
		}
			writer.flush();
			writer.close();
			filereader.close();
			csvReader.close();
		}
		catch(Exception e)
		{
			System.out.println("Data no read");
			System.out.println(e.getMessage());
		}
	}

	public void updateOptionalReportExitingGroup(String name)
	{
		boolean dwnld = false;
		do 
		{
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
		}
		while(dwnld == false);
		File file = new File(filePath); 
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		cal.add(Calendar.DAY_OF_MONTH, -1);
		String date = dateFormat.format(cal.getTime());
		System.out.println(date);
		String data[] = {"","","","", "Ansh.G" + formattedEmail + prop.getProperty("userDomain"), "Ansh", "", "G", "Ansh.G" + formattedEmail + prop.getProperty("userDomain"), 
				"", "", "", "Active", "", "","", "", "", OrganizationSettings.groupName };
		try
		{
			User.userEmail="Ansh.G" + formattedEmail + prop.getProperty("userDomain");
			User.dropdn=OrganizationSettings.groupName ;
			User.group=new String[2];
			User.group[0]=OrganizationSettings.groupName ;
			Thread.sleep(5000);
     		FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeNext(header);
			writer.writeNext(data);
			writer.close();
			csvReader.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		readandUpdateFile();
	}
	
	

}
