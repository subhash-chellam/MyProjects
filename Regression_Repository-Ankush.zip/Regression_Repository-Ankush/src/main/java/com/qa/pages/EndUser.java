package com.qa.pages;

import java.io.File;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.python.modules.thread.thread;

import com.qa.util.TestBase;


public class EndUser extends TestBase 
{
	@FindBy(xpath = "//span[contains(text(), 'Welcome')]")
	WebElement endUserHomePage;

	@FindBy(xpath = "//a[contains(text(), 'My Account') and @target]")
	WebElement endUserAccountLink;

	@FindBy(xpath = "//h2[contains(text(), 'Edit')]")
	WebElement endUserAccountPage;

	@FindBy(xpath = "//button[text() = 'Completed and Expired Programs']")
	WebElement endUsercompletedPrograms;

	@FindBy(xpath = "//button[text()='Current Programs']")
	WebElement endUserCurrentPrograms;
	
	@FindBy(xpath = "//*[@id='tab1']//div[@class='nocourse-available']//span")
	WebElement nocoursepresnt;
	
	
	
	@FindBy(xpath = "//a[contains(text(), 'Log Out') and @target]")
	WebElement endUserLogOut;

	@FindBy(xpath = "(//a[text() = 'Activate'])[1]")
	WebElement endUserActivateCourse;

	@FindBy(xpath = "(//span[text() = 'I Agree'])[1]")
	WebElement endUserAgreeLink;

	@FindBy(xpath = "(//span[contains(text(), 'Launch')])[1]")
	WebElement endUserLaunch;

	@FindBy(xpath = "(//span[contains(text(), 'Review')])[1]")
	WebElement endUserReview;

	@FindBy(xpath = "//*[@name='context_id']")
	WebElement context_id;

	@FindBy(xpath = "//*[@name='context_label']")
	WebElement context_label;

	@FindBy(xpath = "//*[@name='context_title']")
	WebElement context_title;
	

	@FindBy(xpath = "//*[@id=\"page-wrap-inner\"]//a[text()='Claim CME/CE']")
	WebElement ClaimCME;
	
	
	@FindBy(xpath = "//*[@id='cmeEvaluationValidation']//div[@class='full clearfix']")
	WebElement message;
	
	@FindBy(xpath = "//*[@id='cmeEvaluationValidationClose']/span[1]")
	WebElement close;
	
	
	
	@FindBy(xpath = "//select")
	WebElement ClaimCMEpart2;
	
	

	@FindBy(xpath = "//div[@class='checkcredit-label']//label")
	WebElement CME_CE;


	@FindBy(xpath = "//*[@id=\"speciality_master_id\"]")
	WebElement specialitymaster_id;

	@FindBy(xpath = "//*[@id=\"designation\"]")
	WebElement designation;

	@FindBy(xpath = "//*[@id=\"classification_code\"]")
	WebElement classification_code;


	@FindBy(xpath = "//*[@id=\"state\"]")
	WebElement state;



	@FindBy(xpath = "//*[@id=\"submitButton\"]")
	WebElement submitButton;

	@FindBy(xpath = "//*[@id=\"zipcode\"]")
	WebElement zipcode;

	@FindBy(xpath = "//*[@id=\"address1\"]")
	WebElement address;


	@FindBy(xpath = "//*[@id=\"phone\"]")
	WebElement phone;

	@FindBy(xpath = "//*[@id='credits_claimed']")
	WebElement credits_claimed;

	

	@FindBy(xpath = "//input[@type = 'submit']")
	WebElement endUserSubmitDate;

	@FindBy(xpath = "//span[contains(text(),'Start')]")
	WebElement endUserStartCourse;

	@FindBy(xpath = "//span[contains(text(), 'Resume')]")
	WebElement endUserResumeCourse;
	@FindBy(xpath = "//input[@name = 'vendor_sharable_id']")
	WebElement vendorSharableId;
	@FindBy(xpath = "//span[contains(text(),'Start')]")
	WebElement endUserStartCourseonline;

	@FindBy(xpath = "//span[text() = 'Exit']")
	WebElement endUserExitCourse;


	@FindBy(xpath = "//*[@id='cecmeModal']//button[text()='I, Acknowledge']")
	WebElement cecmeBtn;

	@FindBy(xpath = "//*[@id='send-email']")
	WebElement sendemai;

	
	@FindBy(xpath = "//button[@id='exit']")
	WebElement ExitCourse;

	@FindBy(xpath = "//span//a[text() = 'My Courses']")
	WebElement endUserMyCoursesLink;
	
	@FindBy(xpath = "//span//a[text() = 'My Programs']")
	WebElement endUserProgramLink;

	@FindBy(xpath = "//iframe[@id = 'frame']")
	WebElement frameTwo;
	@FindBy(xpath = "//div[contains(@class,'footer')]/p")
	WebElement laerdalFooter;
	
	@FindBy(xpath = "(//span[@class= 'test_links'])[1]")
	WebElement complete;

	@FindBy(xpath = "//iframe[@id = 'basicltiLaunchFrame']")
	WebElement frameOne;

	@FindBy(xpath = "//iframe[@id = 'launchFrame']")
	WebElement fraeOne;

	@FindBy(xpath = "//table[@class]")
	WebElement sharedCourses;

	@FindBy(xpath = "//span[text() = 'I Agree']")
	WebElement iAgreeButton;

	@FindBy(xpath = "//a[text() = 'Evaluation']")
	WebElement endUserEvaluation;

	@FindBy(xpath = "//input[@type = 'submit']")
	WebElement endUserSubmitEvaluation;

	@FindBy(xpath = "(//td[@title = 'Action'])[1]//a")
	WebElement endUserCourseAction;

	@FindBy(xpath = "//div[@id = 'announcement']")
	WebElement courseExit;

	@FindBy(xpath = "//input[@name = 'test_today_date']")
	WebElement endUserCourseDate;

	@FindBy(xpath = "//a[@aria-label='Completed Activities']")
	WebElement completedActivitiesButton;

	@FindBy(xpath = "//button[text() = 'Completed and Expired Programs']")
	WebElement completedProgramsButton;

	@FindBy(xpath = "//table[@aria-describedby = 'course-name']//tbody/tr[1]/td[4]")
	WebElement completedCourseReview;



	@FindBy(xpath = "//table[@aria-describedby = 'completed_courses']//tbody/tr[1]/td[6]//a")
	WebElement completedCourseReviews;

	
	@FindBy(xpath = "//*[@id=\"page-wrap-inner\"]//a[text()='View eCard']")
	WebElement completedCourseEcard;


	@FindBy(xpath = "//*[@id='page-wrap-inner']//a[text()='Certificate']")
	WebElement completedCourseCertificate;

	@FindBy(xpath = "//button[text()='Continue']")
	WebElement Continue;

	
	

	@FindBy(xpath = "//button[text()='Activate']")
	WebElement Activate;

	@FindBy(xpath = "//a[text() = 'Survey']")
	WebElement endUserSurvey;


	@FindBy(xpath = "//input[@type = 'submit']")
	WebElement endUserSubmitSurvey;

	@FindBy(xpath = "//*[@id='successbox']")
	WebElement successmsg;

	@FindBy(xpath = "//*[@id=\"confirm-delete\"]//a/span[text()='Continue']")
	WebElement confirm;
	
	@FindBy(xpath = "//a[@aria-label='Cancel Claim CME/CE Credit']")
	WebElement cancel;
	@FindBy(xpath = "//a[@title='View eCard']")
	WebElement viewEcardButton;
	@FindBy(xpath = "//img[@title='View Certificate']")
	WebElement viewCertficateButton;
	
	

	@FindBy(xpath = "//img[@alt = 'RQI Logo']")
	WebElement laerdalLogo;
	
	
	@FindBy(xpath = "//div/span[@class='welcomeuser']")
	WebElement welcome;
	
	@FindBy(xpath = "//ul[@aria-labelledby = 'navAccountMenu']/li//a/ancestor::li/a")
	WebElement menuDropdown;
	
	@FindBy(xpath = "//ul[@aria-labelledby = 'navAccountSupp']/li//a/ancestor::li/a")
	WebElement supportDropdown;
	
	@FindBy(xpath = "//a[contains(text(),'(Download Certificate)')]")
	WebElement download;
	String topicAvailable = "//table[@class ='table panel panel-default referencePanel' ]";

	String courseTablescrom = "//div[@id='accordion']//table[contains(@class, 'table panel panel-default')]";

	String courseTable = "//table[@class = 'table panel panel-default referencePanel']";
	String curseTable="//table[@class = 'table panel panel-default']";
	String courseTablelock = "//table[contains(@class, 'table panel panel-default')]";
	String completeTable = "//table[@aria-describedby = 'completed_courses']//tbody/tr";
	By course = By.xpath("//div[@id='current-programs']//div[contains(@class,'wrapper')]");
	String courseAvailable = "//div[@id='current-programs']//div[contains(@class,'wrapper-bg wrapper')]";
	String buttonxpath="//div[@class='w-sm-100 text-sm-right d-block']//a";
	
	String supportOptionList = "//ul[@aria-labelledby = 'navAccountSupp']/li//a";

	
	By mandatoryQuestion = By.xpath("//small[contains(text(), 'required')]//parent::div");
	By rhapsodeCourse = By.xpath("(//input[@id = 'lis_result_sourcedid'])");
	String sideMenu = "//ul[@id = 'side_menu']/li//a";
	String menuOptionList = "//ul[@aria-labelledby = 'navAccountMenu']/li//a";
	String pagelinks = "//a[not (@href = '#') and not (@href = 'javascript:void(0);') and not (@href = 'javascript:void(0)') and @href]";

	String firstRadioMandatryQuestion = "((//small[contains(text(), 'required')]//parent::div)[";
	String completeTableRow = "//table[@aria-describedby = 'completed_courses']//tbody/tr/td[";
	public static String courseTopic[];
	public static boolean flag = false;

	RestApi rest;

	public EndUser() 
	{
		PageFactory.initElements(driver, this);
		driver.manage().timeouts().pageLoadTimeout(300, TimeUnit.SECONDS);
	}

	

	public void validatemsgClaimCME(String msg)
	{
		wait.until(ExpectedConditions.visibilityOf(ClaimCME));

		ClaimCME.click();
		wait.until(ExpectedConditions.visibilityOf(message));
		Assert.assertTrue("Validate Message"+message.getText(),message.getText().contains(msg) );

		wait.until(ExpectedConditions.visibilityOf(close));
		close.click();

		
	}
	public static boolean isFileDownloaded_Ext(String dirPath, String ext){
		boolean flag=false;
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			flag = false;
		}

		for (int i = 1; i < files.length; i++) 
		{
			if(files[i].getName().contains(ext)) 
			{
				System.out.println(files[i].getName());
				files[i].delete();
				flag=true;
			}
		}
		return flag;
	}

	public void claimCredit()
	{
		wait.until(ExpectedConditions.visibilityOf(ClaimCME));

		ClaimCME.click();

		clamCmeDetails("12345567","Ajekar","Nurse","Physician","Nurse Practitioner","Alabama","12344" );

		try
		{
		wait.until(ExpectedConditions.visibilityOf(confirm));
		confirm.click();
		
		wait.until(ExpectedConditions.visibilityOf(ClaimCMEpart2));
		Select drptime = new Select(ClaimCMEpart2);
		drptime.selectByIndex(1);;
	
		submitButton.click();
		
		wait.until(ExpectedConditions.visibilityOf(confirm));
		confirm.click();

		}
		catch(Exception e)
		{
			
		}
		Students std=new Students();
		
		isFileDownloaded_Ext(std.downloadPath, ".pdf");
		
		wait.until(ExpectedConditions.visibilityOf(successmsg));
		
		Assert.assertTrue(successmsg.getText().contains("CME/CE credits updated successfully."));
		
		wait.until(ExpectedConditions.visibilityOf(ClaimCME));
		ClaimCME.click();
		
		wait.until(ExpectedConditions.visibilityOf(download));
		download.click();
		boolean dwnld = false;
		int m=0;
		do 
		{
			dwnld =std.isFileDownloaded_Ext(std.downloadPath, ".pdf");
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			m++;
		}
		while(dwnld == false);
		
		Assert.assertTrue(dwnld);
		
		std.deleteFile(Students.filePath);
	
		wait.until(ExpectedConditions.visibilityOf(cancel));
		cancel.click();
		
		
		
		
	}
	public void clamCmeDetails(String phne,String addres,String speciality,String designtion,String classification,String stte,String zipcde)
	{
		wait.until(ExpectedConditions.visibilityOf(CME_CE));

		CME_CE.click();	
		wait.until(ExpectedConditions.visibilityOf(address));

		address.sendKeys(addres);
		wait.until(ExpectedConditions.visibilityOf(phone));

		phone.sendKeys(phne);
		
		try
		{
			wait.until(ExpectedConditions.visibilityOf(credits_claimed));
			credits_claimed.sendKeys("1");
			
		}
		catch(Exception e)
		{
			
		}
		wait.until(ExpectedConditions.visibilityOf(specialitymaster_id));

		specialitymaster_id.click();

		Select drptime = new Select(specialitymaster_id);
		drptime.selectByVisibleText(speciality);;

		wait.until(ExpectedConditions.visibilityOf(designation));

		designation.click();

		drptime = new Select(designation);
		drptime.selectByVisibleText(designtion);;
		
		wait.until(ExpectedConditions.visibilityOf(classification_code));

		classification_code.click();

		drptime = new Select(classification_code);
		drptime.selectByVisibleText(classification);;
		
		wait.until(ExpectedConditions.visibilityOf(state));
		state.click();
		drptime = new Select(state);
		drptime.selectByVisibleText(stte);;
		wait.until(ExpectedConditions.visibilityOf(zipcode));

		zipcode.sendKeys(zipcde);

		wait.until(ExpectedConditions.visibilityOf(submitButton));
		submitButton.click();
		

	}
	public void launchFurtureAssignmentUrl(int numCount, String dateType)
	{
		LocalDate localDate = LocalDate.now();
		LocalDate changeDate = null;
		switch(dateType.toLowerCase().trim())
		{
		case "days":
			changeDate = localDate.plusDays(numCount);
			break;
		case "months":
			changeDate = localDate.plusMonths(numCount);
			break;
		case "weeks":
			changeDate = localDate.plusWeeks(numCount);
			break;
		}
		
			
			driver.navigate().to(prop.getProperty("url"+prop.getProperty("environment")).replace("admin", "mycourse?request_date=") + changeDate.toString());
		
	}
	public void clickOnSubmitOnlyWithDate()
	{
		try
		{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(endUserSubmitDate));
		String date = LocalDate.now().toString();
		System.out.println("Current date is " + date);
		if(date.length() > 1)
		{
			endUserCourseDate.click();
			endUserCourseDate.clear();
			endUserCourseDate.sendKeys(date);
			endUserCourseDate.click();
		}
		endUserSubmitDate.click();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	public void verifyHomePage() 
	{

		wait.until(ExpectedConditions.visibilityOf(endUserHomePage));
	}
	public void validateContextItems(String contextid, String contextlabel, String contexttitle)
	{
		String source = driver.getPageSource();
		
		Assert.assertTrue(source.toLowerCase().contains("context_id"));
		Assert.assertTrue(source.toLowerCase().contains("context_label"));
		Assert.assertTrue(source.toLowerCase().contains("context_title"));
		
		System.out.println(context_id.getAttribute("value")+" "+contextid);
		System.out.println(context_label.getAttribute("value")+" "+contextlabel);
		System.out.println(context_title.getAttribute("value")+" "+contexttitle);
		
		
	}
	public void validateRowCountActiveCourses(int expectedCount)
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);	
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" + courseAvailable + ")[1]"))));
		List<WebElement> rowCount = driver.findElements(By.xpath(courseAvailable));
		System.out.println("Row count from UI is " + rowCount.size() + " and expected count is " + expectedCount);
		Assert.assertTrue(rowCount.size() == expectedCount);
	}
	
	public void validateRowCountActiveCourses(int expectedCount,String name)
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);	
		if(courseListName.containsKey( name+"Option"))
			 name=courseListName.get( name+"Option").toString();
		try {
			name=name.replace("Â", "");
			System.out.println(name.replace("Â", ""));
			courseAvailable = "//div[@id='current-programs']//div[contains(@class,'wrapper-bg wrapper')]";
		

			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[contains(text(),'"+name+"')]" ))));
		}
		catch(NoSuchElementException e)
		{
			
			courseAvailable = "//div[@class='wrapper']//div[@class='row inner-content d-flex']";
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[contains(text(),'"+name+"')]" ))));
			
		}
		List<WebElement> rowCount = driver.findElements(By.xpath(courseAvailable+"//span[@class='course-title' and contains(text(),'"+name+"')]"));
		System.out.println("Row count from UI is " + rowCount.size() + " and expected count is " + expectedCount);
		Assert.assertTrue(rowCount.size() == expectedCount);
	}
	

	public void validateRowCountCurrentCourses(int expectedCount,String name) throws InterruptedException
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);	
		if(courseListName.containsKey( name+"Option"))
			 name=courseListName.get( name+"Option").toString();

				name=name.replace("Â", "");
			System.out.println(name.replace("Â", ""));
			courseAvailable = "//div[@id='current-programs']//div[contains(@class,'wrapper-bg wrapper')]";
			
			Thread.sleep(3000);

		
		List<WebElement> rowCount = driver.findElements(By.xpath(courseAvailable+"//span[@class='course-title' and contains(text(),'"+name+"')]"));
		System.out.println("Row count from UI is " + rowCount.size() + " and expected count is " + expectedCount);
		Assert.assertTrue(rowCount.size() == expectedCount);
	}
	public void clickOnCompletedPrograms()
	{
		wait.until(ExpectedConditions.visibilityOf(endUsercompletedPrograms));
		endUsercompletedPrograms.click();
	}
	
	public void clickOnCurrentPrograms()
	{
		wait.until(ExpectedConditions.visibilityOf(endUserCurrentPrograms));
		endUserCurrentPrograms.click();
	}
	
	
	
	public void nocoursepresent()
	{
		wait.until(ExpectedConditions.visibilityOf(nocoursepresnt));
		Assert.assertEquals(nocoursepresnt.getText(), "No programs available.");
	}
	
	
	public void validateDateShared(int count, String dateType)
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);	
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" + courseAvailable + ")[1]"))));
		List<WebElement> rowCount = driver.findElements(By.xpath(courseAvailable));
		Assert.assertTrue(rowCount.size() == count);
		for(int i = 1; i <= count; i++)
		{
			String shareDate = driver.findElement(By.xpath("(" + courseAvailable + ")[" + i + "]/td[2]")).getText();
			LocalDate localDate = LocalDate.now();
			switch(dateType.toLowerCase().trim())
			{
			case "days":
				LocalDate addedDays = localDate.plusDays(i-1);
				String formattedDate = addedDays.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
				Assert.assertEquals(shareDate, formattedDate);
				break;
			case "months":
				LocalDate addedMonths = localDate.plusMonths(i-1);
				formattedDate = addedMonths.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
				Assert.assertEquals(shareDate, formattedDate);
				break;
			case "weeks":
				LocalDate addedWeeks = localDate.plusWeeks(i-1);
				formattedDate = addedWeeks.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
				Assert.assertEquals(shareDate, formattedDate);
				break;		
			}
			
		}
	}

	public void clickMyAccount()
	{
		wait.until(ExpectedConditions.visibilityOf(endUserAccountLink));
		endUserAccountLink.click();
		wait.until(ExpectedConditions.visibilityOf(endUserAccountPage));
	}
	public void surveyCourse()
	{
		try
		{
			Thread.sleep(5000);
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(endUserSurvey));
			endUserSurvey.click();
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(mandatoryQuestion)));
			List<WebElement> mandate = driver.findElements(mandatoryQuestion);
			for(int i= 1; i<= mandate.size(); i++)
			{
				driver.findElement(By.xpath(firstRadioMandatryQuestion + i + "]//input[@type = 'radio'])[1]")).click();;
			}
			endUserSubmitSurvey.click();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}

	}

	public void clickLogOut()
	{
		wait.until(ExpectedConditions.visibilityOf(endUserLogOut));
		endUserLogOut.click();
	}

	public void launchCourse()
	{
		wait.until(ExpectedConditions.visibilityOf(endUserActivateCourse));
		endUserActivateCourse.click();
		if(endUserAgreeLink.isDisplayed())
			endUserAgreeLink.click();
		wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
		endUserLaunch.click();
	}

	public void clickActivate()
	{
		try 
		{
			checkCourseAvailable();
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(endUserActivateCourse));
			endUserActivateCourse.click();
			if(wait.until(ExpectedConditions.visibilityOf(endUserAgreeLink)).isDisplayed())
				endUserAgreeLink.click();
			wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	public void clickLaunch()
	{
		wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
		endUserLaunch.click();
		clickOnSubmitOnly();
		startCourse();
		exitCourse();
	}

	public void startORResumeCourse()
	{
		WebDriverWait wait = new WebDriverWait(driver, 20);
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(endUserStartCourse));
			endUserStartCourse.click();
		} 
		catch (Exception e) 
		{

			wait.until(ExpectedConditions.visibilityOf(endUserResumeCourse));
			endUserResumeCourse.click();
		}

	}
	public void getVendorSharableId()
	{
		WebDriverWait wait = new WebDriverWait(driver, 20);
		try 
		{
			JavascriptExecutor j = (JavascriptExecutor) driver;
			String pageSource = (String) j.executeScript("return arguments[0].getAttribute('value')", vendorSharableId);
			System.out.println("Vendor sharable id is " + pageSource);
			if(!(pageSource.length() > 0))
				Assert.fail("Vendor Sharable id not available");
		} 
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}
	}
	public void startCourse()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(endUserStartCourse));
		endUserStartCourse.click();

	}
	public int getTopicAvaialble()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(topicAvailable))));
		List<WebElement> count = driver.findElements(By.xpath(topicAvailable + "//tbody/tr"));
		return count.size();
	}

	public void completeCourse() 
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		try 
		{
			Thread.sleep(15000);
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(frameOne));
			Assert.assertTrue(driver.getCurrentUrl().contains("https"));
			driver.switchTo().frame("basicltiLaunchFrame");
			wait.until(ExpectedConditions.visibilityOf(frameTwo));
			driver.switchTo().frame("frame");
			wait.until(ExpectedConditions.visibilityOf(complete));
			complete.click();
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(courseExit));
			driver.switchTo().defaultContent();



		} 
		catch (Exception e) 
		{
			driver.switchTo().defaultContent();
			driver=driver;
			WebDriverWait wait = new WebDriverWait(driver, 30);
			try
			{
				WebDriverWait wait1 = new WebDriverWait(driver, 50);

				wait1.until(ExpectedConditions.visibilityOf(fraeOne));
				driver.switchTo().frame("playerframe");
				if(driver.findElement(By.xpath("//*[@id='defaultmsg']")).getText().contains("NRP organization not found for given lmsOrgId (Error Code: 400)"))
				{
					System.err.println("NRP organization not found for given lmsOrgId (Error Code: 400)");
					driver.switchTo().defaultContent();
				}
				else
					System.out.println(driver.findElement(By.xpath("//*[@id='defaultmsg']")).getText());



			}
			catch(Exception m)
			{

				driver.switchTo().defaultContent();
				driver.navigate().refresh();
				try
				{
					wait.until(ExpectedConditions.visibilityOf(frameOne));
				}
				catch(StaleElementReferenceException s)
				{

					driver.navigate().refresh();
					driver=driver;
				}
				driver.switchTo().frame("basicltiLaunchFrame");
				js.executeScript("setInterval(function() {frames[\"HYPER_19720220\"].skipSco();}, 300);//");
				try 
				{
					wait = new WebDriverWait(driver, 60);
					wait.until(ExpectedConditions.visibilityOf(frameTwo));
					driver.switchTo().frame("frame");
					wait.until(ExpectedConditions.visibilityOf(courseExit));
				}
				catch(Exception ex)
				{
					try {
						Thread.sleep(15000);
					} catch (InterruptedException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					driver.switchTo().defaultContent();
					wait.until(ExpectedConditions.visibilityOf(frameOne));
					driver.switchTo().frame("basicltiLaunchFrame");
					driver.navigate().refresh();

					String value = null;
					try {
						driver.navigate().refresh();
						Thread.sleep(20000);
						value = driver.findElement(rhapsodeCourse).getAttribute("value");

					} catch (Exception e1) {

						try
						{
							value = driver.findElement(By.xpath("//*[@id=\"lis_result_sourcedid\"]")).getAttribute("value");

						}
						catch(Exception kk)
						{
							System.out.println(driver.getPageSource().split("name=\"lis_result_sourcedid\" value=\"")[0].split(">")[0].replace("\"", ""));

							value=driver.getPageSource().split("name=\"lis_result_sourcedid\" value=\"")[1].split(">")[0].replace("\"", "");
							System.out.println(value);

						}

					}
					System.out.println(value);
					rest = new RestApi();
					rest.getResponse(value);
				}
				driver.switchTo().defaultContent();
			}
		}
	}
	
	public void completeCourseTestCode() 
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(frameOne));
			Assert.assertTrue(driver.getCurrentUrl().contains("https"));
		
			String value=driver.getCurrentUrl().split("sourceId=")[1];
			rest = new RestApi();
			rest.getResponse(value);
			driver.switchTo().defaultContent();
//			wait.until(ExpectedConditions.visibilityOf(courseExit));
			
		} 
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}
	}

	public void exitCourse()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(endUserExitCourse));
			Thread.sleep(3000);
			endUserExitCourse.click();
			wait.until(ExpectedConditions.visibilityOf(endUserProgramLink));
			endUserProgramLink.click();
		} 
		catch (Exception e) 
		{

		}
	}

	public void cecmepopup(String name)
	{
			if(courseListName.containsKey(name+"CME_CE"))
			{
				wait.until(ExpectedConditions.visibilityOf(cecmeBtn));
				cecmeBtn.click();
			}

		
	}
	public void cecmepopup()
	{
		try
		{
//			    WebDriverWait wait = new WebDriverWait(driver, 15);
				wait.until(ExpectedConditions.visibilityOf(cecmeBtn));
				cecmeBtn.click();
		}
		catch(Exception e)
		{
			
		}
		
	}
	public void cecmepopupforsub()
	{
				wait.until(ExpectedConditions.visibilityOf(cecmeBtn));
				cecmeBtn.click();
		
				try
				{
					wait.until(ExpectedConditions.visibilityOf(sendemai));
					
					sendemai.click();
				}
				catch(Exception e)
				{
					
				}
		
	}
	public void clickEndUserProgramLink()
	{
		try 
		{
			driver.navigate().refresh();
			WebDriverWait wait = new WebDriverWait(driver, 30);
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(endUserProgramLink));
			endUserProgramLink.click();
		} 
		catch (Exception e) 
		{
			
		}
	}
	
	public void clickEndUserProgramLinkonline()
	{
		try 
		{
			Thread.sleep(5000);
			
			driver.navigate().refresh();
			Thread.sleep(3000);
			
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(endUserProgramLink));
			endUserProgramLink.click();
		} 
		catch (Exception e) 
		{
			Assert.fail("Error with the course");
		}
	}
	
	
	public void startORResumeCourseOnline()
	{
		WebDriverWait wait = new WebDriverWait(driver, 20);
		try
		{
			wait.until(ExpectedConditions.visibilityOf(endUserStartCourseonline));
			endUserStartCourseonline.click();
		}
		catch (Exception e)
		{

			wait.until(ExpectedConditions.visibilityOf(endUserResumeCourse));
			endUserResumeCourse.click();
		}

	}
	public void clickEndUserMyCoursesLink()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(endUserMyCoursesLink));
			endUserMyCoursesLink.click();
		} 
		catch (Exception e) 
		{
			
		}
	}
	public void onlyExitCourse()
	{
		try
		{
			Thread.sleep(5000);
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(endUserExitCourse));
			endUserExitCourse.click();
		}
		catch(Exception e)
		{
			wait.until(ExpectedConditions.visibilityOf(ExitCourse));
			JavascriptExecutor js = (JavascriptExecutor)driver;

			js.executeScript("arguments[0].click()", ExitCourse);
			
		}
	}

	public void closeTab()
	{
		driver.close();
	}
	public boolean checkCoursesAvailable()
	{
		boolean flag = false;

		for(int m=0;m<=40;m++)
		{
		 try 
		{
			
				Thread.sleep(5000);
				driver.findElement(course).isDisplayed();
				flag = true;
				break;
			}		
		
		catch (Exception e) 
		{
			driver.navigate().refresh();
				
		}
		}
		return flag;
	}
	static int m=0;
	public void checkCourseAvailable()
	{
		for(int m=0;m<=40;m++)
		{
		try 
		{
			Thread.sleep(2000);
			driver.findElement(course).isDisplayed();
			break;
		} 
		catch (Exception e) 
		{
			
					driver.navigate().refresh();
			
		}
		}
	}

	public void launchUserCourse()
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);	
		try
		{
			checkCourseAvailable();
			wait.until(ExpectedConditions.visibilityOf(endUserActivateCourse));
			endUserActivateCourse.click();
			if(wait.until(ExpectedConditions.visibilityOf(iAgreeButton)).isDisplayed())
				iAgreeButton.click();
			wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
			endUserLaunch.click();
		}
		catch(Exception e)
		{
			try
			{
				boolean flag = endUserLaunch.isDisplayed();
				if(flag)
					endUserLaunch.click();
				else if(wait.until(ExpectedConditions.visibilityOf(endUserResumeCourse)).isDisplayed())
				{
					wait.until(ExpectedConditions.visibilityOf(endUserResumeCourse));
					endUserResumeCourse.click();
				}

			}
			catch(Exception ex)
			{
				System.out.println(ex.getMessage());
			}

		}
	}

	public void launchUserCourse1()
	{
		WebDriverWait wait = new WebDriverWait(driver, 40);	
		try
		{
			checkCourseAvailable();
			wait.until(ExpectedConditions.visibilityOf( driver.findElement(By.xpath("(" + courseAvailable +buttonxpath+")[1]"))));
			String action = null;
			try
			{
				action = driver.findElement(By.xpath("(" + courseAvailable +buttonxpath+")[1]")).getText();
			}
			catch(Exception e)
			{
					action = driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[1]")).getText();
				
			}
			action=action.toLowerCase();
			System.out.println(action);
			if(action.contains("resume"))
			{
				endUserResumeCourse.click();
			}
			else if(action.contains("activate"))
			{
				endUserActivateCourse.click();
				try {
					wait.until(ExpectedConditions.visibilityOf(iAgreeButton)).isDisplayed();
					iAgreeButton.click();
					wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
					endUserLaunch.click();
					
					
				}
				catch(Exception e)
				{
					wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
					endUserLaunch.click();
				}	
				
			}

			else if(action.contains("review"))
			{
				wait.until(ExpectedConditions.visibilityOf(endUserReview));
				endUserReview.click();
			}

			else if(action.contains("launch"))
			{
				wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
				endUserLaunch.click();
			}
			flag = true;
		}
		catch(Exception e)
		{
			flag = false;
			System.out.println(e.getMessage());
		}

	}
	public String changeDate(int quarter)
	{

		LocalDate localDate = LocalDate.now();
		LocalDate firstDayOfQuarter = localDate.with(localDate.getMonth().firstMonthOfQuarter()).with(TemporalAdjusters.firstDayOfMonth());
		LocalDate lastDayOfQuarter;
		lastDayOfQuarter = firstDayOfQuarter.plusMonths(quarter*3).plusMonths(2).with(TemporalAdjusters.lastDayOfMonth());
		System.out.println(firstDayOfQuarter);
		System.out.println(lastDayOfQuarter);
		return lastDayOfQuarter.toString();
	}
	//div[@class='checkcredit-label']//label


	public int getAvailableTopicNumberscrom()
	{
		int topicCount = 0;
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseTablescrom))));
			Thread.sleep(5000);
			List<WebElement> count = driver.findElements(By.xpath(courseTablescrom + "//tbody[@class]/tr/td[4]//a"));
			if(count.size() > 0) {
			if(!driver.findElement(By.xpath(courseTablescrom + "//tbody/tr/td[4]//a[1]")).isDisplayed())
				topicCount = 0;
			else if(driver.findElement(By.xpath(courseTablescrom + "//tbody/tr/td[4]//a[1]")).getText().equalsIgnoreCase("review"))
				topicCount = 0;
			else
				topicCount = count.size();
			}
			else
				topicCount = count.size();
		}
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}
		return topicCount;
	}
	  public int validateAvailableTopicLocked()
	    {
	        int topicCount = 0;
	        try
	        {
	            WebDriverWait wait = new WebDriverWait(driver, 30);
	            wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseTablelock))));
	            Thread.sleep(5000);
	            List<WebElement> count = driver.findElements(By.xpath(courseTablelock + "//tbody/tr/td[4]/span[@class = 'lock_icon']"));
	            topicCount = count.size();
	        }
	        catch (Exception e)
	        {
	            System.out.println(e.getMessage());
	        }
	        return topicCount;
	    }
	  public void clickEcardButton()
		{
			WebDriverWait wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.visibilityOf(viewEcardButton));
			viewEcardButton.click();
			driver.close();
		}
	  public void switchToApplicationPage()
		{
			Set<String> handles=driver.getWindowHandles();
			String window = null;
			for(String actual: handles)
	        {
				driver.switchTo().window(actual);
				String currentUrl = driver.getCurrentUrl();
				if(currentUrl.contains("/manageuser"))
				{
					window = actual;
				}			
				else
					driver.close();
				handles=driver.getWindowHandles();
	        }
			driver.switchTo().window(window);
			
		}
	  public void switchToPDFPage()
		{
			Set<String> handles=driver.getWindowHandles();
			
			boolean flag = false;
			try {
				Thread.sleep(5000);
				for(String actual: handles)
				{
					driver.switchTo().window(actual);
					String currentUrl = driver.getCurrentUrl();
					int m=0;
					while(currentUrl.contains("blank"))
					{
						Thread.sleep(5000);
						currentUrl = driver.getCurrentUrl();
						if(m==pagload)
							break;
						else
						{
							try {
								Thread.sleep(550);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
						m++;
					}
					if(currentUrl.contains("blob"))
					{
						String source = driver.getPageSource();
						Assert.assertTrue(source.toLowerCase().contains("application/pdf"));
						flag= true;
						break;
					}
					else
					{
						continue;
					}
				}
				Assert.assertTrue(flag == true);
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		}
	  public void clickviewCertficateButtonPage()
		{
			WebDriverWait wait = new WebDriverWait(driver, 15);
			driver.switchTo().frame("examReaderFrame");
			wait.until(ExpectedConditions.visibilityOf(viewCertficateButton));
			viewCertficateButton.click();
			driver.switchTo().defaultContent();
		}

	  public void switchToCertificatePage()
		{
			Set<String> handles=driver.getWindowHandles();
			for(String actual: handles)
	        {
				driver.switchTo().window(actual);
				String currentUrl = driver.getCurrentUrl();
				if(currentUrl.contains("certificate"))
				{
					break;
				}
				else
				{
					continue;
				}
	        }
		}

	public boolean launchCourseWithName(String name)
	{
		if(courseListName.containsKey( name+"Option"))
		 name=courseListName.get( name+"Option").toString();

		System.out.println(name);

//		name=name.replace("Â", "");
		WebDriverWait wait = new WebDriverWait(driver, 40);	
		boolean flag = false;
		checkCourseAvailable();


		try {
			name=name.replace("Â", "");
			System.out.println(name.replace("Â", ""));
			try
			{
			courseAvailable = "//div[@id='current-programs']//div[contains(@class,'wrapper-bg wrapper')]";
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[text()='"+name+"']" ))));

			}
			catch(NoSuchElementException e)
			{
				courseAvailable = "//div[@id='current-programs']//div[contains(@class,'wrapper-bg wrapper')]";
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[contains(text(),'"+name+"')]" ))));

			}
		}
		catch(NoSuchElementException e)
		{
			try
			{
				courseAvailable = "//div[@class='wrapper']//div[@class='row inner-content d-flex']";
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[text()='"+name+"']" ))));

			}
			catch(NoSuchElementException m)
			{
				courseAvailable = "//div[@class='wrapper']//div[@class='row inner-content d-flex']";
								wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[contains(text(),'"+name+"')]" ))));

			}

			
			
		}

	
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath( courseAvailable ))));

		List<WebElement> rowCount = driver.findElements(By.xpath(courseAvailable));

		for(int i = 1; i <= rowCount.size(); i++)
		{
			System.out.println("tess");
			String courseName = driver.findElement(By.xpath("(" + courseAvailable + "//span[@class='course-title'])[" + i + "]")).getText().trim();

			System.out.println(courseName);
			System.out.println(name);
			System.out.println(courseAvailable);
			System.out.println(rowCount.size());
			System.out.println(name.toLowerCase().trim().contains(courseName.toLowerCase().trim().replace(" new!", "")));
			System.out.println(name.toLowerCase().trim().contains(courseName.toLowerCase().trim().replace("new!", "")));
				
			if(name.toLowerCase().trim().contains(courseName.toLowerCase().trim().replace(" new!", "")))
			{
				String action;
				try
				{
					action = driver.findElement(By.xpath("(" + courseAvailable +buttonxpath+")[" + i + "]")).getText();
				}
				catch(Exception e)
				{
						action = driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).getText();
					
				}
				System.out.println(action.toLowerCase());
				if(action.toLowerCase().contains("resume"))
				{
					try
					{
						driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).click();
					}
					catch(Exception e)
					{
						driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).click();

					}
					flag = true;
					break;
				}
				else if(action.toLowerCase().contains("activate"))
				{
					driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).click();
					try
					{

				    wait.until(ExpectedConditions.visibilityOf(Activate));
					
						Activate.click();	
					}
					catch (Exception e) {
						// TODO: handle exception

						System.out.println(driver.getWindowHandles().size());
					}
					try 
					{Thread.sleep(4000);
						this.wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
						endUserLaunch.click();
						flag = true;
						break;
						
					}
					catch(Exception e)
					{
						
						
						wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//span[text() = 'I Agree'])[" + i + "]")))).isDisplayed();
						driver.findElement(By.xpath("(//span[text() = 'I Agree'])[" + i + "]")).click();
						wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
						endUserLaunch.click();
						flag = true;
						break;
					}	
				}
				else if(action.toLowerCase().contains("launch"))
				{
					wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
					endUserLaunch.click();
					flag = true;
					break;
				}
			}
		}
		return flag;
	}
	
	public boolean launchCourseWithNamealready(String name)
	{
		if(courseListName.containsKey( name+"Option"))
			 name=courseListName.get( name+"Option").toString();
	
		name=name.replace("Â", "");
		WebDriverWait wait = new WebDriverWait(driver, 50);	
		boolean flag = false;
		checkCourseAvailable();


		try {
			
			
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//td//span[contains(text(),'"+name+"')]" ))));
		}
		catch(NoSuchElementException e)
		{
			courseAvailable = "//table[@class and @aria-describedby='my_courseList']//tbody/tr";
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//td//span[contains(text(),'"+name+"')]" ))));
			
		}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath( courseAvailable ))));

		List<WebElement> rowCount = driver.findElements(By.xpath(courseAvailable));

		for(int i = 1; i <= rowCount.size(); i++)
		{
			System.out.println("tess");
			String courseName = driver.findElement(By.xpath("(" + courseAvailable + "/td[1]//span)[" + i + "]")).getText().trim();
			if(name.toLowerCase().trim().contains(courseName.toLowerCase().trim().replace(" new!", "")))
			{
				String action;
				try
				  {
					action = driver.findElement(By.xpath("(" + courseAvailable + "/td[5]//a)[" + i + "]")).getText();
				}
				catch(Exception e)
				{
					try {
						action = driver.findElement(By.xpath("(" + courseAvailable + "/td[4]//a)[" + i + "]")).getText();
					}
					catch(Exception m)
					{
						action = driver.findElement(By.xpath("(" + courseAvailable + "/td[3]//a)[" + i + "]")).getText();

					}
				}
				if(action.toLowerCase().contains("resume"))
				{
					try
					{
						driver.findElement(By.xpath("(" + courseAvailable + "/td[5]//a)[" + i + "]")).click();
					}
					catch(Exception e)
					{
						driver.findElement(By.xpath("(" + courseAvailable + "/td[4]//a)[" + i + "]")).click();

					}
					flag = true;
					break;
				}
				else if(action.toLowerCase().contains("activate"))
				{
					driver.findElement(By.xpath("(" + courseAvailable + "/td[5]//a)[" + i + "]")).click();
					try
					{

						//					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[20]/div/div/div[3]/button[2]"))));
						System.out.println("test");
						Thread.sleep(15000);
						driver.findElement(By.xpath("//div/div/div/div[3]/button[2]")).click();

					}
					catch (Exception e) {
						// TODO: handle exception

						System.out.println(driver.getWindowHandles().size());
					}
					try 
					{
						wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//span[text() = 'I Agree'])[" + i + "]")))).isDisplayed();
						driver.findElement(By.xpath("(//span[text() = 'I Agree'])[" + i + "]")).click();
						wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
						endUserLaunch.click();
						flag = true;
						break;
					}
					catch(Exception e)
					{
						wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
						endUserLaunch.click();
						flag = true;
						break;
					}	
				}
				else if(action.toLowerCase().contains("launch"))
				{
					wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
					endUserLaunch.click();
					flag = true;
					break;
				}
			}
		}
		return flag;
	}

	public boolean launchCourseWithNameResume(String name)
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);	
		boolean flag = false;
		checkCourseAvailable();
		if(courseListName.containsKey(name))
			name=courseListName.get(name).toString();

	


		try {
			courseAvailable = "//table[@class and @aria-describedby='my_courseList']//tbody/tr";
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" + courseAvailable + ")[1]"))));
		}
		catch(NoSuchElementException e)
		{
			courseAvailable = "//*[@id=\"accordion2\"]/table/tbody/tr";
		}

		List<WebElement> rowCount = driver.findElements(By.xpath(courseAvailable));
		//		 driver.findElement(By.xpath(courseAvailable));

		for(int i = 1; i <= rowCount.size(); i++)
		{
			String courseName = driver.findElement(By.xpath("(" + courseAvailable + "/td[1]//span)[" + i + "]")).getText().trim();
			if(name.toLowerCase().trim().contains(courseName.toLowerCase().trim()))
			{
				String action;
				try
				{
					action = driver.findElement(By.xpath("(" + courseAvailable + "/td[5]//a)[" + i + "]")).getText();
				}
				catch(Exception e)
				{
					try
					{
						action = driver.findElement(By.xpath("(" + courseAvailable + "/td[4]//a)[" + i + "]")).getText();
					}
					catch(Exception w )
					{
						action = driver.findElement(By.xpath("(" + courseAvailable + "/td[3]//a)[" + i + "]")).getText();

					}
				}
				if(action.toLowerCase().contains("resume"))
				{
					try
					{
						driver.findElement(By.xpath("(" + courseAvailable + "/td[5]//a)[" + i + "]")).click();
					}
					catch(Exception e)
					{
						try
						{
							driver.findElement(By.xpath("(" + courseAvailable + "/td[4]//a)[" + i + "]")).click();
						}	
						catch(Exception m)
						{
							driver.findElement(By.xpath("(" + courseAvailable + "/td[3]//a)[" + i + "]")).click();

						}

					}
					flag = true;
					break;
				}
				else if(action.toLowerCase().contains("activate"))
				{
					driver.findElement(By.xpath("(" + courseAvailable + "/td[5]//a)[" + i + "]")).click();
					try 
					{
						wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//span[text() = 'I Agree'])[" + i + "]")))).isDisplayed();
						driver.findElement(By.xpath("(//span[text() = 'I Agree'])[" + i + "]")).click();
						wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
						endUserLaunch.click();
						flag = true;
						break;
					}
					catch(Exception e)
					{
						wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
						endUserLaunch.click();
						flag = true;
						break;
					}	
				}
				else if(action.toLowerCase().contains("launch"))
				{
					wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
					endUserLaunch.click();
					flag = true;
					break;
				}
			}
		}
		return flag;
	}


	public void clickOnSubmitOnly()
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.visibilityOf(endUserSubmitDate));
			endUserSubmitDate.click();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	public boolean validateCourseAvailable()
	{
		boolean flag = false;
		for(int  i = 1; i <2; i++)
		{
			flag = checkCoursesAvailable();
			if(flag == false)
			{
				driver.navigate().refresh();
			}
			else
				break;
		}
		return flag;
	}
	public int getNumberRows()
	{
		
		List<WebElement> count;
		try
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseTable))));
			count = driver.findElements(By.xpath(courseTable + "//tbody/tr"));
		}
		catch(Exception e)
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"courseWithoutTodoList\"]"))));
			count = driver.findElements(By.xpath("//*[@id=\"courseWithoutTodoList\"]" + "//tbody/tr"));

		}
		return count.size();
	}

	public int getNumberRow()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);

		List<WebElement> count;
		try
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(curseTable))));
			count = driver.findElements(By.xpath(curseTable + "//tbody/tr"));
		}
		catch(Exception e)
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"courseWithoutTodoList\"]"))));
			count = driver.findElements(By.xpath("//*[@id=\"courseWithoutTodoList\"]" + "//tbody/tr"));

		}
		return count.size();
	}
	public void evaluateCourse()
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(endUserEvaluation));
			endUserEvaluation.click();
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(mandatoryQuestion)));
			List<WebElement> mandate = driver.findElements(mandatoryQuestion);
			for(int i= 1; i<= mandate.size(); i++)
			{
				driver.findElement(By.xpath(firstRadioMandatryQuestion + i + "]//input[@type = 'radio'])[1]")).click();;
			}
			endUserSubmitEvaluation.click();
		}
		catch(Exception e)
		{
			//			driver.findElement(By.xpath("//button[@id=\"complete_course_topics_close\"]")).click();
			System.out.println(e.getMessage());
		}

	}
	
	public void evaluateCourse(String course)
	{
		if(courseListName.containsKey(course+"evaluateCourse"))
		{
		
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(endUserEvaluation));
			endUserEvaluation.click();
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(mandatoryQuestion)));
			List<WebElement> mandate = driver.findElements(mandatoryQuestion);
			for(int i= 1; i<= mandate.size(); i++)
			{
				driver.findElement(By.xpath(firstRadioMandatryQuestion + i + "]//input[@type = 'radio'])[1]")).click();;
			}
			endUserSubmitEvaluation.click();
		}
		catch(Exception e)
		{
			//			driver.findElement(By.xpath("//button[@id=\"complete_course_topics_close\"]")).click();
		Assert.fail("Evaluate Course is not enabled"+course);
		
		}
		}

	}

	public void validateMenuOption()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(laerdalLogo));
		List<WebElement> menuOption = driver.findElements(By.xpath(menuOptionList));
		boolean flag = false;
		Assert.assertTrue(menuOption.size() == 4);
		for(WebElement element:menuOption)
		{
			flag = false;
			menuDropdown.click();
			String text = element.getText();
			if(text.toLowerCase().trim().equalsIgnoreCase("my programs")||text.toLowerCase().trim().equalsIgnoreCase("my account")||
					text.toLowerCase().trim().equalsIgnoreCase("Log Out")||	text.toLowerCase().trim().equalsIgnoreCase("reference library"))
				flag = true;
			
		}
		Assert.assertFalse("Menu Options are not matching", flag == false);
	}
	public void courseNotAvaialble() {
		Assert.assertFalse(driver.findElement(By.xpath("//table[@class]/caption")).getAttribute("id").equalsIgnoreCase("shared_courses"));
	}

	public void validateResponseForLink()
	{
		String url = "";
		HttpURLConnection huc = null;
		int respCode = 200;
		List<WebElement> links = driver.findElements(By.xpath(pagelinks));
		Iterator<WebElement> it = links.iterator();
		while(it.hasNext())
		{
			url = it.next().getAttribute("href");
			if(url == null || url.isEmpty()){
				System.out.println("URL is either not configured for anchor tag or it is empty");
				continue;
			}
			try 
			{
				huc = (HttpURLConnection)(new URL(url).openConnection());
				huc.setRequestMethod("HEAD");
				huc.connect();
				respCode = huc.getResponseCode();
				if(respCode >= 400)
					System.out.println(url+" is a broken link");
				else
					System.out.println(url+" is a valid link");
			} 
			catch (Exception e)
			{
//				Assert.fail(url + e.getMessage());
			}
			}
	}
	public void validateSideMenuOption()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(laerdalLogo));
		List<WebElement> sideMenuOption = driver.findElements(By.xpath(sideMenu));
		boolean flag = false;
		Assert.assertTrue(sideMenuOption.size() == 4);
		for(WebElement element:sideMenuOption)
		{
			flag = false;
			String text = element.getText();
			System.out.println(text);
			if(text.toLowerCase().trim().equalsIgnoreCase("my programs")||text.toLowerCase().trim().equalsIgnoreCase("my account")||
					text.toLowerCase().trim().equalsIgnoreCase("Log Out")||	text.toLowerCase().trim().equalsIgnoreCase("reference library"))
		
				flag = true;
			
		}
		Assert.assertFalse("Menu Options are not matching", flag == false);
	}
	public void validateWelcome()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(welcome));
		Point location = welcome.getLocation();
		System.out.println(location);
	}
	
	public void validateSupportOption()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(laerdalLogo));
		List<WebElement> supportOption = driver.findElements(By.xpath(supportOptionList));
		boolean flag = false;
		Assert.assertTrue(supportOption.size() == 2);
		for(WebElement element:supportOption)
		{
			flag = false;
			supportDropdown.click();
			String text = element.getText();
			System.out.println(text);
			if(text.toLowerCase().trim().equalsIgnoreCase("FAQ")||text.toLowerCase().trim().equalsIgnoreCase("Contact Customer Support"))
				flag = true;
			
		}
		Assert.assertFalse("Menu Options are not matching", flag == false);
	}
	
	public void validateHeaderFooter()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(laerdalLogo));
		boolean header = laerdalLogo.isDisplayed();
		Assert.assertFalse("AHA Logo is not avaialble", header == false);
		LocalDate date = LocalDate.now();
		int currentYear = date.getYear();
		wait.until(ExpectedConditions.visibilityOf(laerdalFooter));
		String footerTextUI = laerdalFooter.getText();
		
		String footerTextExpected = "Copyright © "+currentYear+" RQI Partners, LLC. All rights reserved. Unauthorized use prohibited";
		System.out.println(footerTextExpected);
		System.out.println(footerTextUI);
//		Assert.assertFalse("Footer text not matched",!footerTextUI.equalsIgnoreCase(footerTextExpected));		
	}
	public void clickOnSubmitOnlyWithDate(String date)
	{
		String url=driver.getCurrentUrl();
		
		try
		{
			if(courseListName.containsKey(date))
				date=courseListName.get(date).toString();
			
			LocalDate currentQDate = LocalDate.now();
		      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	         
		
		      Calendar cal = Calendar.getInstance();
		      int month = cal.get(Calendar.MONTH);
		      int quarter = (month / 3) + 1;
		      month=((quarter-1)*3)-1;
		      
		      Calendar cal1 = Calendar.getInstance();
		      SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		      cal1.set(Calendar.MONTH,month);
		      Date date1 = cal1.getTime();             
		      String previousQdate = format1.format(date1);   
			 
		      if(date.contains("previousQdate"))
		    	  date=  previousQdate;
		      
		      if(date.contains("currentQDate"))
		    	  date=  formatter.format(currentQDate);
		      
			WebDriverWait wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.visibilityOf(endUserSubmitDate));
			if(date.length() > 1)
			{
				endUserCourseDate.click();
				endUserCourseDate.clear();
				endUserCourseDate.sendKeys(date);
				endUserCourseDate.click();
			}
			endUserSubmitDate.click();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
//			runScriptForPastDate(date);
//			driver.navigate().to(url+"?test_today_date="+date);
			
		}
	}

	public int getAvailableTopicNumber()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseTable))));
		List<WebElement> count = driver.findElements(By.xpath(courseTable + "//tbody/tr/td[4]/a"));
		return count.size();
	}
	public int getAvailableTopiNumber()
	{
		try
		{
		Thread.sleep(6000);
		
		}
		catch(Exception e)
		{
			
		}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(curseTable))));
		List<WebElement> count = driver.findElements(By.xpath(curseTable + "//tbody/tr/td[4]/a"));
		return count.size();
	}

	public int getlockTopiNumber()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(curseTable))));
		List<WebElement> count = driver.findElements(By.xpath(curseTable + "//tbody/tr/td[4]/a"));
		return count.size();
	}

	public void clickOnCompletedActivities()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(completedActivitiesButton));
		completedActivitiesButton.click();
	}

	public void navigateCompletedPrograms()
	{
			wait.until(ExpectedConditions.visibilityOf(completedProgramsButton));
			wait.until(ExpectedConditions.elementToBeClickable(completedProgramsButton));
			
			completedProgramsButton.click();
	}

	public void clickReviewGivenCourse(String courseName)
	{

		if(courseListName.containsKey(courseName))
			courseName=courseListName.get(courseName).toString();


		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(completeTable))));
		List<WebElement> count = driver.findElements(By.xpath(completeTable));
		for(int i=1; i<=count.size(); i++)
		{
			String prog = driver.findElement(By.xpath(completeTableRow + i + "]//span")).getText();
			if(courseName.toLowerCase().contains(prog.toLowerCase()))
			{
				driver.findElement(By.xpath(completeTableRow + "6]//a")).click();
			}
		}
	}

	public void clickOnCompletedCourseReview()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(completedCourseReview));
		completedCourseReview.click();
	}


	public void clickOnCompletedCourseReviews()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(completedCourseReviews));
		completedCourseReviews.click();
	}

	public void clickOnCompletedCourseReviews(String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
			
		try
		{
		Thread.sleep(5000);
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//span[text()='"+course+"']//following::div//a[@aria-label='Review'])[1]"))));
		driver.findElement(By.xpath("(//span[text()='"+course+"']//following::div//a[@aria-label='Review'])[1]")).click();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	public void clickOnCompletedCourseEcard()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(completedCourseEcard));
		completedCourseEcard.click();
		try
		{
			Thread.sleep(10000);

			String currentHandle= driver.getWindowHandle();
			Set<String> handles=driver.getWindowHandles();

			driver.switchTo().window(handles.toArray()[handles.size()-1].toString());

			Assert.assertTrue(driver.getCurrentUrl().contains("/certificate/ecard/"));

			
			driver.close();

			driver.switchTo().window(handles.toArray()[handles.size()-2].toString());



		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	
	public void clickOnCompletedCourseCertificate(String course)
	{
		
		
		if(courseListName.containsKey(course+"Certificate"))
			course=courseListName.get(course+"Certificate").toString();
			
	
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(completedCourseCertificate));
		completedCourseCertificate.click();
		try
		{
			Thread.sleep(10000);

			String currentHandle= driver.getWindowHandle();
			Set<String> handles=driver.getWindowHandles();

		Boolean flag=	Products.isFileDownloaded_Ext (Products.downloadPath , ".pdf");
			
			if(flag==false)
			{
			driver.switchTo().window(handles.toArray()[handles.size()-1].toString());

			Assert.assertTrue(driver.getCurrentUrl().contains("/certificate/completion"));
			try
			{
				
				Thread.sleep(5000);
				driver.switchTo().frame("examReaderFrame");
				wait.until(ExpectedConditions.visibilityOf(Continue));
				Continue.click();
				Thread.sleep(5000);
				
				wait.until(ExpectedConditions.visibilityOf(Continue));
				Continue.click();
//				driver.switchTo().alert().accept();
				
			}
			catch(Exception e)
			{
			
				
			}
			
			driver.findElement(By.xpath("//table/tr//td[contains(text(),'"+course+"')]/following::td/img")).click();

			Assert.assertTrue(driver.getWindowHandles().size()==4);
            handles=driver.getWindowHandles();
			
			driver.switchTo().window(handles.toArray()[3].toString());
			driver.close();

			driver.switchTo().window(handles.toArray()[2].toString());
			driver.close();

			driver.switchTo().window(handles.toArray()[1].toString());
			}


		}
		catch(Exception e)
		{
			Assert.fail("error");
		}

	}
	
	public void clickOnCompletedCourseEcard(String course)
	{
		if(courseListName.containsKey(course+"Ecard"))
			course=courseListName.get(course+"Ecard").toString();
			
	
		
		
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(completedCourseEcard));
		completedCourseEcard.click();
		try
		{
			Thread.sleep(5000);

			String currentHandle= driver.getWindowHandle();
			Set<String> handles=driver.getWindowHandles();

			driver.switchTo().window(handles.toArray()[handles.size()-1].toString());

			Assert.assertTrue(driver.getCurrentUrl().contains("/certificate/ecard/"));

			System.out.println(driver.getCurrentUrl());
			
			try
			{
				Thread.sleep(5000);
				driver.switchTo().frame("examReaderFrame");
			}
			catch(Exception e)
			{
				
			}

			this.wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//table/tr//td[contains(text(),'"+course+"')]/following::td/img"))));
			
			driver.findElement(By.xpath("//table/tr//td[contains(text(),'"+course+"')]/following::td/img")).click();
			
            handles=driver.getWindowHandles();

			Assert.assertTrue(driver.getWindowHandles().size()==4);
            handles=driver.getWindowHandles();
			
			driver.switchTo().window(handles.toArray()[3].toString());
			driver.close();

			driver.switchTo().window(handles.toArray()[2].toString());
			driver.close();

			driver.switchTo().window(handles.toArray()[1].toString());



		}
		catch(Exception e)
		{
				Assert.fail( e.getMessage());
		}

	}
	
	public void validateCourseLaunchError()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseTable + "//td"))));
		String getMessage = driver.findElement(By.xpath(courseTable + "//td")).getText().trim();
		System.out.println(getMessage);
		Assert.assertTrue(getMessage.toLowerCase().contains("this course can only launch if other courses have been completed"));
	}
	public boolean startCourseWithName(String courseName)
	{
		if(courseListName.containsKey(courseName))
			courseName=courseListName.get(courseName).toString();

		WebDriverWait wait = new WebDriverWait(driver, 30);	
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" + courseAvailable + ")[1]"))));
		List<WebElement> rowCount = driver.findElements(By.xpath(courseAvailable));
		for(int i = 1; i <= rowCount.size(); i++)
		{
			String courseNameAvailable = driver.findElement(By.xpath("(" + courseAvailable + ")[" + i + "]/td[1]")).getText();
			courseNameAvailable = courseNameAvailable.replace("New!", "");
			if(courseName.toLowerCase().trim().contains(courseNameAvailable.trim().toLowerCase()))
			{
				if(driver.findElements(By.xpath("(" + courseAvailable + ")[" + i + "]/td[5]")).size() > 0)
				{
					driver.findElement(By.xpath("(" + courseAvailable + ")[" + i + "]/td[5]")).click();
					try
					{
						wait.until(ExpectedConditions.visibilityOf(endUserAgreeLink)).isDisplayed();
						endUserAgreeLink.click();
						Thread.sleep(9000);
					}
					catch(Exception e)
					{
					
					}
					flag = true;
					break;
				}
				else if(driver.findElements(By.xpath("(" + courseAvailable + ")[" + i + "]/td[4]")).size() > 0)
				{
					driver.findElement(By.xpath("(" + courseAvailable + ")[" + i + "]/td[4]")).click();
					flag = true;
					break;
				}
				else if(driver.findElements(By.xpath("(" + courseAvailable + ")[" + i + "]/td[3]")).size() > 0)
				{
					driver.findElement(By.xpath("(" + courseAvailable + ")[" + i + "]/td[3]//a")).click();
					flag = true;
					break;
				}
			}
			
		}
		return flag;
	}
	public void runScriptForPastDate(String date)
	{
		try 
		{
			if(courseListName.containsKey(date))
				date=courseListName.get(date).toString();

			
			LocalDate currentQDate = LocalDate.now();
		      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	         
		
		      Calendar cal = Calendar.getInstance();
		      int month = cal.get(Calendar.MONTH);
		      int quarter = (month / 3) + 1;
		      month=((quarter-1)*3)-1;
		      
		      Calendar cal1 = Calendar.getInstance();
		      SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		      cal1.set(Calendar.MONTH,month);
		      Date date1 = cal1.getTime();             
		      String previousQdate = format1.format(date1);   
			 
		      if(date.contains("previousQdate"))
		    	  date=  previousQdate;
		      
		      if(date.contains("currentQDate"))
		    	  date=  formatter.format(currentQDate);
		      
			 
			LocalDate currentDate = LocalDate.now();
			LocalDate courseDate = LocalDate.parse(date);
			Period diff = Period.between(courseDate, currentDate);
			int days = diff.getDays();
			int months = diff.getMonths();
			int year = diff.getYears();
			
			Thread.sleep(5000);
			if(days >= 1 || months >= 1 || year >=1)
				System.out.println("Date is in past");
			
				JavascriptExecutor js = (JavascriptExecutor)driver;
				js.executeScript("var testActivatedate; function setValue() {testActivateDate = '"+date+"' ; }; setValue(); testActivateDate;");
			
			
			
		} 
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}
	}



}