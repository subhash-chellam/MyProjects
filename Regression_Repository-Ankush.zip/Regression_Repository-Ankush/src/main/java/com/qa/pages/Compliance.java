
package com.qa.pages;

import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.FileReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.python.modules.thread.thread;

import com.opencsv.CSVReader;
import com.qa.util.TestBase;

public class Compliance extends TestBase
{
	@FindBy(xpath = "//a[contains(text(), 'Reports')]")
	WebElement reportLink;

	@FindBy(xpath = "//a[contains(text(), 'Compliance Report')]")
	WebElement complianceReportLink;

	@FindBy(xpath = "//label[@id = 'inputSearch']")
	WebElement searchTextBox;

	@FindBy(xpath = "//input[@id = 'searchbox_name_email']")
	WebElement inputTextBox;

	@FindBy(xpath = "//button[@id = 'searchbtn']")
	WebElement searchButton;

	@FindBy(xpath = "//div[@id = 'clear']//a[text() = 'Clear Search']")
	WebElement clearSearch;

	@FindBy(xpath = "//select[@id = 'statusFilter']//following-sibling::div/button")
	WebElement userStatusFilter;

	@FindBy(xpath = "//select[@id = 'statusFilter']//following-sibling::div//a")
	WebElement userSelectAll;

	@FindBy(xpath = "//button[text() = 'Search' and not(@id)]")
	WebElement moreFilterSearchButton;

	@FindBy(xpath = "//table[@id = 'reports']//tr[1]//td[1]")
	WebElement userId;

	@FindBy(xpath = "//table[@id = 'reports']//tr[1]//td[2]")
	WebElement lastName;

	@FindBy(xpath = "//table[@id = 'reports']//tr[1]//td[3]")
	WebElement firstName;

	@FindBy(xpath = "//table[@id = 'reports']//tr[1]//td[11]")
	WebElement email;

	@FindBy(xpath = "//table[@id = 'reports']//tr[1]//td[6]")
	WebElement courseName;

	@FindBy(xpath = "//div[@id = 'reports_info']")
	WebElement listLabel;

	@FindBy(xpath = "//body[@class]")
	WebElement pageLoad;

	@FindBy(xpath = "//button[@id = 'exportbtn']")
	WebElement exportButton;

	@FindBy(xpath = "//a[@class='card-link']")
	WebElement moreFilter;

	@FindBy(xpath = "//span[text()='Active']")
	WebElement userStatus;

	@FindBy(xpath = "//table[@id='reports']/tbody//td[5]")
	List<WebElement> resultStatus;

	@FindBy(xpath = "//select[@id='statusFilter']/following-sibling::div/button")
	WebElement statusButton;

	@FindBy(xpath = "(//a[@class='ms-selectall global'])[3]")
	WebElement selectAllButton;

	@FindBy(xpath = "(//a[@class='ms-selectall global'])[4]")
	WebElement ComplianceSelectAllButton;

	@FindBy(xpath = "//input[@value='SUPER_COMPLIANT']")
	WebElement currentStatus;

	@FindBy(xpath = "//input[contains(@title,'Inactive')]")
	WebElement InActiveCheckbox;

	@FindBy(xpath = "(//button[@value='Search'])[2]")
	WebElement filterSearchButton;

	@FindBy(xpath = "(//a[text()='Clear Search'])[2]")
	WebElement clearSearch2;

	@FindBy(xpath = "//select[@id='compliance_status']/following-sibling::div/button")
	WebElement ComplianceStatusButton;

	@FindBy(xpath = "//select[@id='compliance_status']/following-sibling::div//ul//label")
	List<WebElement> ComplianceOptions;

	@FindBy(xpath = "//div[@class='dataTables_scroll']/div[1]/div/table/thead//th")
	List<WebElement> ComplianceColumns;

	@FindBy(xpath = "//td[contains(text(),'No reports data found')]")
	WebElement searchText;

	@FindBy(xpath = "//label[@id='inputSearch']")
	WebElement searchText2;

	@FindBy(xpath = "//input[@type='search']")
	WebElement searchinputText;

	@FindBy(xpath = "//div[@id]/a[text()= 'Clear Search']")
	WebElement searchClear;

	@FindBy(xpath = "//a[@data-target = '#unitdiv']")
	WebElement[] searchResultUnitName;

	@FindBy(xpath = "//table[@id = 'learnerTableList']//td[4]")
	WebElement searchResultFirstName;
	@FindBy(xpath = "(//a[text()= 'Clear Search'])[2]")
	WebElement moreFilterClearSearch;

	By table = By.xpath("//table[@id = 'reports']/tbody/tr[1]/td");
	By CurriculumTable = By.xpath("//div[contains(@class, 'title')]");
	String downloadPath = System.getProperty("user.dir") + prop.getProperty("downloadPath");
	String val;
	String tableRow = "//table[@id = 'reports']/tbody/tr[1]/td";
	String reportTable = "//table[@id = 'reports']//tbody/tr";
	String activeAssignments = "(//div[text() = 'Active Assignments:']/following-sibling::div)[";
	String incompliantLearners = "(//div[text() = 'Incompliant learners:']/following-sibling::div)[";
	String activationNumber = "(//div[text() = 'Number of activations:']/following-sibling::div)[";
	String compliance = "(//div[text() = 'Compliance:']/following-sibling::div)[";
	public static int oldAssignments, oldIncompliant, oldActivations,newAssignments, newIncompliant, newActivations;	
	public static String  newCompliance;
	String entryDetails = "(//div[contains(@class, 'course-list-box compliant')]//div[text() = '";
	Students std;

	public Compliance() 
	{
		PageFactory.initElements(driver, this);
	}
	String tableheader = "(//table[@aria-describedby = 'reports_info' and not (@id)])[1]//th";
	
	public void validateHeader()
	{
		try {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		val = pageLoad.getAttribute("class");
		int counter = 0;
		while(val.equalsIgnoreCase("loading_compliance"))
		{
			val = pageLoad.getAttribute("class");
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load page after waiting for 1 minute");
		}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableheader + "[1]"))));
		List<WebElement> headerList = driver.findElements(By.xpath(tableheader));
		
		String[] headerData = new String[headerList.size()];
		for(int i = 0; i <= headerList.size()-1; i++)
		{
			headerData[i] = headerList.get(i).getText();
			if(i == 7)
				scrollRight();
		}
		String expectedHeader[] = {"User ID", "Last Name", "First Name", "Unit Name", "Status", "Curriculum", "Compliance Status",
				"Compliant Until","Ecard Valid Until", "Ecard Url", "Contact", "Last Activity", "Completion Date"};
		for(int i = 0; i <= expectedHeader.length - 1; i++)
		{
			expectedHeader[i] = expectedHeader[i].toUpperCase();
		}
		boolean flag = Arrays.equals(headerData, expectedHeader);
		System.out.println(flag);
		Assert.assertTrue(flag);	
		}
		catch(Exception e)
		{
			
		}
	}
	public void scrollRight()
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
		executor.executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", scrollArea);
	}

	public void getNewEntryDetailsCourseName(String courseName)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();


		WebDriverWait wait = new WebDriverWait(driver, 30);
		String entryRows = entryDetails + courseName + "']/../..)/following-sibling::div";
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(entryRows+ "//div[text() = 'Active Assignments:']/following-sibling::div")));
		newAssignments = Integer.parseInt(driver.findElement(By.xpath(entryRows + "//div[text() = 'Active Assignments:']/following-sibling::div")).getText());
		newIncompliant = Integer.parseInt(driver.findElement(By.xpath(entryRows + "//div[text() = 'Incompliant learners:']/following-sibling::div")).getText());
		newActivations = Integer.parseInt(driver.findElement(By.xpath(entryRows + "//div[text() = 'Number of activations:']/following-sibling::div")).getText());
		newCompliance = driver.findElement(By.xpath(entryRows + "//div[text() = 'Compliance:']/following-sibling::div")).getText();
	}

	public void clickOnReportLink()
	{
		wait.until(ExpectedConditions.visibilityOf(reportLink));
		wait.until(ExpectedConditions.elementToBeClickable(reportLink));
		try {
			Thread.sleep(2000);
			val = pageLoad.getAttribute("class");
			while(val.contains("loading") || val.contains("loading_user") )
			{
				val = pageLoad.getAttribute("class");
			}
			reportLink.click();
		}
		catch (Exception e) 
		{
			reportLink.click();
		}

	}
	public void getOldEntryDetailsCourseName(String courseName)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();


		WebDriverWait wait = new WebDriverWait(driver, 30);
		String entryRows = entryDetails  + courseName + "']/../..)/following-sibling::div";
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(entryRows+ "//div[text() = 'Active Assignments:']/following-sibling::div")));
		oldAssignments = Integer.parseInt(driver.findElement(By.xpath(entryRows + "//div[text() = 'Active Assignments:']/following-sibling::div")).getText());
		oldIncompliant = Integer.parseInt(driver.findElement(By.xpath(entryRows + "//div[text() = 'Incompliant learners:']/following-sibling::div")).getText());
		oldActivations = Integer.parseInt(driver.findElement(By.xpath(entryRows + "//div[text() = 'Number of activations:']/following-sibling::div")).getText());		
	}

	public void validateCompliantStatusDateWithValueAndCourse(String status,String course)
	{
		int m=0;
		boolean flag = false;

		try
		{
			if(courseListName.containsKey(course+"Option"))
				course=courseListName.get(course+"Option").toString();


			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading"))
			{
				val = pageLoad.getAttribute("class");
				try
				{
					String curriculum = reportTable + "[1]/td[6]";
					String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
					wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(reportTable))));

				}
				catch(Exception e)
				{

				}
				if(m==pagload)
					break;
				m++;
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

			List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
			int rowCount = tableRows.size();
			for (int i= 1; i<= rowCount; i++)
			{
				String curriculum = reportTable + "[" + i + "]/td[6]";
				String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
				course = course.replaceAll("registered", "\u00AE");
				String Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[11]")).getText();
				System.out.println(curricuclumText);
				System.out.println(course);

				if(course.toLowerCase().contains(curricuclumText.toLowerCase())&&Email.contains(User.userEmail))
				{
					String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[7]")).getText();
					Assert.assertTrue(data.trim().toLowerCase().equalsIgnoreCase(status.trim().toLowerCase()));
					flag = true;
					break;
				}
			}  

			Assert.assertTrue(flag);
		}
		catch(StaleElementReferenceException e)
		{
			m=0;
			validateCompliantStatusDateWithValueAndCourse(status,course);
		}
		catch(Exception j)
		{
			Assert.fail("App issues" +j.getMessage());
		}
	}
	public void validateunitnameAndCourse(String org,String course)
	{
		int m=0;
		boolean flag = false;
		if(org.contains("Orgname"))
			org=	TestBase.prop.getProperty("orgName");
		try
		{
			if(courseListName.containsKey(course+"Option"))
				course=courseListName.get(course+"Option").toString();


			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading"))
			{
				val = pageLoad.getAttribute("class");
				try
				{
					String curriculum = reportTable + "[1]/td[6]";
					String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
					wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(reportTable))));

				}
				catch(Exception e)
				{

				}
				if(m==pagload)
					break;
				m++;
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

			List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
			int rowCount = tableRows.size();
			for (int i= 1; i<= rowCount; i++)
			{
				String curriculum = reportTable + "[" + i + "]/td[6]";
				String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
				course = course.replaceAll("registered", "\u00AE");
				String Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[11]")).getText();

				if(course.toLowerCase().contains(curricuclumText.toLowerCase())&&Email.contains(User.userEmail))
				{
					String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[4]")).getText();
					Assert.assertTrue(data.trim().toLowerCase().equalsIgnoreCase(org.trim().toLowerCase()));
					flag = true;
					break;
				}
			}  

			Assert.assertTrue(flag);
		}
		catch(StaleElementReferenceException e)
		{
			m=0;
			validateunitnameAndCourse(org,course);
		}
		catch(Exception j)
		{
			Assert.fail("App issues");
		}
	}

	public void validatelastactiveAndCourse(String org,String course)
	{
		int m=0;
		boolean flag = false;
		try
		{
			if(courseListName.containsKey(course+"Option"))
				course=courseListName.get(course+"Option").toString();


			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading"))
			{
				val = pageLoad.getAttribute("class");
				try
				{
					String curriculum = reportTable + "[1]/td[6]";
					String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
					wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(reportTable))));

				}
				catch(Exception e)
				{

				}
				if(m==pagload)
					break;
				m++;
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

			List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
			int rowCount = tableRows.size();
			for (int i= 1; i<= rowCount; i++)
			{
				String curriculum = reportTable + "[" + i + "]/td[6]";
				String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
				course = course.replaceAll("registered", "\u00AE");
				String Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[11]")).getText();

				if(course.toLowerCase().contains(curricuclumText.toLowerCase())&&Email.contains(User.userEmail))
				{
					String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[12]")).getText();
					Assert.assertTrue(data.trim().toLowerCase().equalsIgnoreCase(org.trim().toLowerCase()));
					flag = true;
					break;
				}
			}  

			Assert.assertTrue(flag);
		}
		catch(StaleElementReferenceException e)
		{
			m=0;
			validateunitnameAndCourse(org,course);
		}
		catch(Exception j)
		{
			Assert.fail("App issues");
		}
	}

	public void validateuserStatusAndCourse(String status,String course)
	{
		int m=0;
		boolean flag = false;
		try
		{
			if(courseListName.containsKey(course+"Option"))
				course=courseListName.get(course+"Option").toString();


			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading"))
			{
				val = pageLoad.getAttribute("class");
				try
				{
					String curriculum = reportTable + "[1]/td[6]";
					String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
					wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(reportTable))));

				}
				catch(Exception e)
				{

				}
				if(m==pagload)
					break;
				m++;
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

			List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
			int rowCount = tableRows.size();
			for (int i= 1; i<= rowCount; i++)
			{
				String curriculum = reportTable + "[" + i + "]/td[6]";
				String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
				course = course.replaceAll("registered", "\u00AE");
				String Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[11]")).getText();

				if(course.toLowerCase().contains(curricuclumText.toLowerCase())&&Email.contains(User.userEmail))
				{
					String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[5]")).getText();
					Assert.assertTrue(data.trim().toLowerCase().equalsIgnoreCase(status.trim().toLowerCase()));
					flag = true;
					break;
				}
			}  

			Assert.assertTrue(flag);
		}
		catch(StaleElementReferenceException e)
		{
			m=0;
			validateuserStatusAndCourse(status,course);
		}
		catch(Exception j)
		{
			Assert.fail("App issues");
		}
	}

	public void validateuserFirstLastNameAndCourse(String first,String last,String course)
	{
		int m=0;
		boolean flag = false;
		try
		{
			if(courseListName.containsKey(course+"Option"))
				course=courseListName.get(course+"Option").toString();


			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading"))
			{
				val = pageLoad.getAttribute("class");
				try
				{
					String curriculum = reportTable + "[1]/td[6]";
					String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
					wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(reportTable))));

				}
				catch(Exception e)
				{

				}
				if(m==pagload)
					break;
				m++;
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

			List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
			int rowCount = tableRows.size();
			for (int i= 1; i<= rowCount; i++)
			{
				String curriculum = reportTable + "[" + i + "]/td[6]";
				String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
				course = course.replaceAll("registered", "\u00AE");
				String Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[11]")).getText();

				if(course.toLowerCase().contains(curricuclumText.toLowerCase())&&Email.contains(User.userEmail))
				{
					String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[3]")).getText();
					Assert.assertTrue(data.trim().toLowerCase().equalsIgnoreCase(first.trim().toLowerCase()));
					data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[2]")).getText();
					Assert.assertTrue(data.trim().toLowerCase().equalsIgnoreCase(last.trim().toLowerCase()));

					flag = true;
					break;
				}
			}  

			Assert.assertTrue(flag);
		}
		catch(StaleElementReferenceException e)
		{
			m=0;
			validateuserFirstLastNameAndCourse(first,last,course);
		}
		catch(Exception j)
		{
			Assert.fail("App issues");
		}
	}

	public void validateuserIDAndCourse(String userID,String course)
	{
		int m=0;
		boolean flag = false;
		try
		{
			if(courseListName.containsKey(course+"Option"))
				course=courseListName.get(course+"Option").toString();


			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading"))
			{
				val = pageLoad.getAttribute("class");
				try
				{
					String curriculum = reportTable + "[1]/td[6]";
					String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
					wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(reportTable))));

				}
				catch(Exception e)
				{

				}
				if(m==pagload)
					break;
				m++;
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

			List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
			int rowCount = tableRows.size();
			for (int i= 1; i<= rowCount; i++)
			{
				String curriculum = reportTable + "[" + i + "]/td[6]";
				String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
				course = course.replaceAll("registered", "\u00AE");
				String Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[11]")).getText();

				if(course.toLowerCase().contains(curricuclumText.toLowerCase())&&Email.contains(User.userEmail))
				{
					String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[1]")).getText();
					Assert.assertTrue(data.trim().toLowerCase().equalsIgnoreCase(userID.trim().toLowerCase()));
					flag = true;
					break;
				}
			}  

			Assert.assertTrue(flag);
		}
		catch(StaleElementReferenceException e)
		{
			m=0;
			validateuserIDAndCourse(userID,course);
		}
		catch(Exception j)
		{
			Assert.fail("App issues");
		}
	}
	public void clickMoreFilter()
	{
		try
		{
			Thread.sleep(2000);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			wait.until(ExpectedConditions.visibilityOf(moreFilter));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", moreFilter);
			Thread.sleep(2000);
		}
		catch(Exception e)
		{

		}
	}
	public void validateUserStatusFilterAvailability()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(userStatusFilter));
		userStatusFilter.click();
	}

	public void selectAllStatus()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userSelectAll));
			userSelectAll.click();
			moreFilterSearchButton.click();
		}
		catch(Exception e)
		{

		}
	}
	public void validateNoReportGenerated()
	{
		WebDriverWait wait = new WebDriverWait(driver, 60);
		val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading"))
		{
			val = pageLoad.getAttribute("class");
		}
		
		
		//wait.until(ExpectedConditions.visibilityOf(progressTableFirstRow));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(reportTable)));
		List<WebElement> columnList = driver.findElements(By.xpath(reportTable + "/td"));
		String text = driver.findElement(By.xpath(reportTable + "/td[1]")).getText();
		System.out.println(text);
		if(columnList.size()>1 || (!text.equalsIgnoreCase("No reports data found.")))
		{
			Assert.fail("Compliance report generated");
			System.err.println("Compliance report generated");
		}        
	}


	public void validateEcardWithValueAndCourse(String value,String course)
	{
		try
		{

			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

			if(courseListName.containsKey(course+"Option"))
				course=courseListName.get(course+"Option").toString();
			int m=0;
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading"))
			{
				val = pageLoad.getAttribute("class");
				try
				{
					String curriculum = reportTable + "[1]/td[6]";
					String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
					wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(reportTable))));

				}
				catch(Exception e)
				{

				}
				if(m==pagload)
					break;
				m++;
			}

			course=course.replace("Â","");
			boolean flag = false;
			int rowCount=0;
			int cont=0;
			while(rowCount==0)
			{
				List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
				rowCount = tableRows.size();
				if(cont==150)
					break;

				cont++;
			}
			System.out.println(rowCount);
			for (int i= 1; i<= rowCount; i++)
			{
				String curriculum = reportTable + "[" + i + "]/td[6]";
				String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
				System.out.println(value);
				System.out.println(course);
				String Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[11]")).getText();

				System.out.println(curricuclumText);
				if(course.toLowerCase().contains(curricuclumText.toLowerCase())&&Email.contains(User.userEmail))
				{
					flag = true;

					String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[9]")).getText();
					System.out.println(data);

					Assert.assertTrue(data.trim().toLowerCase().equalsIgnoreCase(value.trim().toLowerCase()));
					break;
				}
			}    
			Assert.assertTrue(flag);
		}
		catch(StaleElementReferenceException e)
		{
			validateEcardWithValueAndCourse(value,course);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail("Issues with application");
		}

	}

	public String changeDate(int quarter)
	{

		LocalDate localDate = LocalDate.now();
		LocalDate firstDayOfQuarter = localDate.with(localDate.getMonth().firstMonthOfQuarter()).with(TemporalAdjusters.firstDayOfMonth());
		LocalDate lastDayOfQuarter;
		lastDayOfQuarter = firstDayOfQuarter.plusMonths(quarter*3).plusMonths(2).with(TemporalAdjusters.lastDayOfMonth());
		System.out.println(firstDayOfQuarter);
		System.out.println(lastDayOfQuarter);
		return lastDayOfQuarter.toString();
	}
	public void validateFilters(String status) throws Exception
	{
		wait.until(ExpectedConditions.visibilityOf(moreFilter));

		if(status.equalsIgnoreCase("Active")) {
			moreFilter.click();
			Thread.sleep(2000);
			for(WebElement tt : resultStatus){
				Assert.assertEquals(userStatus.getText(), tt.getText());
			}
		}else {
			statusButton.click();
			wait.until(ExpectedConditions.visibilityOf(selectAllButton));
			selectAllButton.click();
			selectAllButton.click();
			InActiveCheckbox.click();
			filterSearchButton.click();
			Thread.sleep(2000);
			for(WebElement tt : resultStatus){
				Assert.assertEquals(status, tt.getText());
			}
		}

	}

	public void clearSearch() throws Exception
	{

		Assert.assertTrue(clearSearch2.isEnabled());
		clearSearch2.click();
		Thread.sleep(3000);
		for(WebElement tt : resultStatus){
			Assert.assertEquals("Active", tt.getText());
		}
	}

	public void complianceStatusField(List<String> text) throws Exception
	{
		wait.until(ExpectedConditions.visibilityOf(moreFilter));
		moreFilter.click();
		Thread.sleep(3000);
		ComplianceStatusButton.click();
		int count = 0;
		for(WebElement tt : ComplianceOptions){
			Assert.assertEquals(text.get(count), tt.getText().trim());
			count++;
		}

	}

	public void AfterSearchMessageValidation(String text) throws Exception
	{
		driver.navigate().refresh();
		Thread.sleep(2000);
		moreFilter.click();
		Thread.sleep(2000);
		ComplianceStatusButton.click();
		ComplianceSelectAllButton.click();
		currentStatus.click();
		filterSearchButton.click();
		wait.until(ExpectedConditions.visibilityOf(searchText));
		Assert.assertEquals(text, searchText.getText());
	}

	public void complianceStatusColumnsValidation(List<String> text, String tc) throws Exception
	{
		Thread.sleep(5000);
		wait.until(ExpectedConditions.visibilityOf(moreFilter));
		moreFilter.click();
		Thread.sleep(3000);
		if(tc.equalsIgnoreCase("afterSearch")) {

			searchButton.click();
		}
		int count = 0;
		for(WebElement tt : ComplianceColumns){
			System.out.println(tt.getAttribute("innerText"));
			Assert.assertEquals(text.get(count).toUpperCase(), tt.getAttribute("innerText"));
			count++;
		}

	}

	public void usersearchEmail(String userEmail)
	{
		try 
		{
			if(AssignmentReport. checkifParmeterAvailable(userEmail))
				userEmail=AssignmentReport.getParmeterAvailable(userEmail);


			//			navigateUserModule();
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchClear));
			wait.until(ExpectedConditions.elementToBeClickable(searchClear));
			searchClear.click();
			wait.until(ExpectedConditions.visibilityOf(searchText2));
			wait.until(ExpectedConditions.elementToBeClickable(searchText2));
			System.out.println("unit name is " + userEmail);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", searchText2);
			wait.until(ExpectedConditions.elementToBeClickable(searchinputText));

			int rowCount=0;
			int cont=0;
			while(rowCount>=1)
			{
				List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
				rowCount = tableRows.size();
				if(cont==150)
					break;

				cont++;
			}
			searchinputText.sendKeys(userEmail);

			executor.executeScript("arguments[0].click();", searchButton);
			wait.until(ExpectedConditions.visibilityOf(searchResultUnitName[searchResultUnitName.length-1]));
			String result = searchResultUnitName[searchResultUnitName.length-1].getText();
			Assert.assertEquals(userEmail, result);

			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			Thread.sleep(15000);
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
			}
			cont=0;
			int usercount=0;
			while(rowCount!=usercount)
			{
				try
				{
					List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
					usercount = tableRows.size();
				}
				catch  (Exception e) 
				{

				}
				if(cont==150)
					break;

				cont++;
			}


		} 
		catch (Exception e) 
		{

		}
	}
	public void selectComplianceReportLink()
	{
		wait.until(ExpectedConditions.visibilityOf(complianceReportLink));
		complianceReportLink.click();
		val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_compliance"))
		{
			val = pageLoad.getAttribute("class");
		}

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

		if(!driver.getCurrentUrl().contains("compliance_report"))
		{
			clickOnReportLink();
			wait.until(ExpectedConditions.visibilityOf(complianceReportLink));
			complianceReportLink.click();


		}
	}

	public void searchByfirstName()
	{
		try {
			wait.until(ExpectedConditions.visibilityOf(userId));
			String id = firstName.getText();
			System.out.println(id);
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
			}
			wait.until(ExpectedConditions.elementToBeClickable(searchTextBox));
			searchTextBox.click();
			inputTextBox.sendKeys(id);
			searchButton.click();
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
			}
			wait.until(ExpectedConditions.elementToBeClickable(firstName));
			String result = firstName.getText();
			Assert.assertEquals(id, result);
			String lbl = listLabel.getText();
			//Assert.assertTrue(lbl.contains("1 to 1 of 1 entries"));
			Thread.sleep(5000);
			clearSearch.click();
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor)driver;
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
			}
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	public void searchByLastName()
	{
		try {
			wait.until(ExpectedConditions.visibilityOf(userId));
			clearSearch.click();
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOf(lastName));
			String id = lastName.getText();
			System.out.println(id);
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
			}
			wait.until(ExpectedConditions.elementToBeClickable(searchTextBox));
			searchTextBox.click();
			inputTextBox.sendKeys(id);
			searchButton.click();
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
			}
			wait.until(ExpectedConditions.elementToBeClickable(lastName));
			String result = lastName.getText();
			Assert.assertEquals(id, result);
			String lbl = listLabel.getText();
			//Assert.assertTrue(lbl.contains("1 to 1 of 1 entries"));
			wait.until(ExpectedConditions.elementToBeClickable(clearSearch));
			Thread.sleep(5000);
			clearSearch.click();
			JavascriptExecutor js = (JavascriptExecutor)driver;
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void searchByUserID()
	{
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(userId));
			clearSearch.click();
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOf(userId));
			String id = userId.getText();
			System.out.println(id);
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
			}
			wait.until(ExpectedConditions.elementToBeClickable(searchTextBox));
			searchTextBox.click();
			inputTextBox.sendKeys(id);
			searchButton.click();
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor)driver;
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
			}
			wait.until(ExpectedConditions.elementToBeClickable(userId));
			String result = userId.getText();
			Assert.assertEquals(id, result);
			Thread.sleep(5000);
			clearSearch.click();
			Thread.sleep(3000);
			js = (JavascriptExecutor)driver;
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	public void searchByEmail()
	{
		try {
			wait.until(ExpectedConditions.visibilityOf(userId));
			clearSearch.click();
			driver.navigate().refresh();
			wait.until(ExpectedConditions.visibilityOf(email));
			String id = email.getText();
			System.out.println(id);
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
			}
			wait.until(ExpectedConditions.elementToBeClickable(searchTextBox));
			searchTextBox.click();
			inputTextBox.sendKeys(id);
			searchButton.click();
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor)driver;
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
			}
			wait.until(ExpectedConditions.elementToBeClickable(email));
			String result = email.getText();
			Assert.assertEquals(id, result);
			String lbl = listLabel.getText();
			Assert.assertTrue(lbl.contains("1 to 1 of 1 entries"));
			clearSearch.click();
			Thread.sleep(5000);
			js = (JavascriptExecutor)driver;
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickExportButton()
	{
		wait.until(ExpectedConditions.visibilityOf(exportButton));
		val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_compliance"))
		{
			val = pageLoad.getAttribute("class");
		}
		exportButton.click();
	}

	public void verifyDownloadFile()
	{
		std = new Students();

		boolean dwnld = false;
		int m=0;
		do 
		{
			dwnld = std.isFileDownloaded_Ext(downloadPath, ".csv");
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			m++;
		}
		while(dwnld == false);
	}

	public boolean checkCSVFilePresent()
	{
		std = new Students();
		boolean dwnld = std.isFileDownloaded_Ext(downloadPath, ".csv");
		return dwnld;
	}

	public void noRecordsPresent()
	{
		val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_compliance"))
		{
			val = pageLoad.getAttribute("class");
		}
		wait.until(ExpectedConditions.visibilityOf(listLabel));
		String lbl = listLabel.getText();
		Assert.assertTrue(lbl.contains("0 to 0 of 0 entries"));
	}

	public void recordsPresent()
	{
		val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_compliance"))
		{
			val = pageLoad.getAttribute("class");
		}
		String lbl = listLabel.getText();
		Assert.assertFalse(lbl.contains("0 to 0 of 0 entries"));
	}

	public void validateCourseName(String name)
	{
		wait.until(ExpectedConditions.visibilityOf(courseName));
		String result = courseName.getText();
		Assert.assertEquals(name, result);
	}

	@SuppressWarnings("resource")
	public void validateDetails()
	{
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(table)));
			File file = new File(Students.filePath); 
			List<WebElement> rows = driver.findElements(table);		
			Thread.sleep(5000);
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			List<String[]> header = csvReader.readAll();
			ArrayList<String> rowData =new ArrayList<>();
			ArrayList<String> reportData =new ArrayList<>();
			String []excel = header.get(header.size() - 1);
			String data[] = excel[0].split(";");
			for (WebElement row : rows) 
			{
				if(!row.getText().isEmpty())
				{
					String text = row.getText();
					rowData.add(text);

				}
				else
				{
					String xpath[] = row.toString().split("xpath:");
					String path = xpath[1].substring(0, xpath[1].length()-1);
					String text = driver.findElement(By.xpath(path)).getText();
					System.out.println(text);
					if(text.length()>0)
					{
						rowData.add(text);
					}
				}
			}
			for (int i = 0; i<=data.length-1; i++) 
			{
				reportData.add(data[i].replace("\"", ""));
			}

			System.out.println(rowData);
			System.out.println(reportData);
			for(int i = 0; i<= rowData.size()-1; i++)
			{
				Assert.assertEquals(reportData.get(i).trim().toLowerCase(), rowData.get(i).trim().toLowerCase());
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	//	Consumption
	@SuppressWarnings("resource")
	public void validateComplianceDetails()
	{
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(table)));
			File file = new File(Students.filePath); 
			List<WebElement> rows = driver.findElements(table);		
			Thread.sleep(5000);
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			List<String[]> header = csvReader.readAll();
			ArrayList<String> rowData =new ArrayList<>();
			ArrayList<String> reportData =new ArrayList<>();
			String []excel = header.get(header.size() - 1);
			String data[] = excel[0].split(";");
			for (WebElement row : rows) 
			{
				if(!row.getText().isEmpty())
				{
					String text = row.getText();
					rowData.add(text);

				}
				else
				{
					String xpath[] = row.toString().split("xpath:");
					String path = xpath[1].substring(0, xpath[1].length()-1) + "[" + (rows.indexOf(row)+1) + "]/a";
					String text = driver.findElement(By.xpath(path)).getAttribute("href");
					System.out.println(text);
					if(text.length()>0)
					{
						rowData.add(text);
					}
				}
			}
			for (int i = 0; i<=data.length-1; i++) 
			{
				reportData.add(data[i].replace("\"", ""));
			}

			System.out.println(rowData);
			System.out.println(reportData);
			for(int i = 0; i<= rowData.size()-1; i++)
			{
				//Assert.assertEquals(reportData.get(i).trim().toLowerCase(), rowData.get(i).trim().toLowerCase());
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	@SuppressWarnings("resource")
	public void validateConsumptionDetails()
	{
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//table[@id = 'consumption_report']/tbody/tr[1]/td"))));
			File file = new File(Students.filePath); 
			Thread.sleep(5000);
			System.out.println(file);
			FileReader filereader = new FileReader(file,StandardCharsets.UTF_8);
			CSVReader csvReader = new CSVReader(filereader); 
			List<String[]> header = csvReader.readAll();
			for (int m = 2; m<=header.size()-1;m++) 
			{
				ArrayList<String> rowData =new ArrayList<>();
				ArrayList<String> reportData =new ArrayList<>();

				String []excel = header.get(m);
				String data[] = excel;
				int rw=m-1;
				List<WebElement> rows = driver.findElements(By.xpath("//table[@id = 'consumption_report']/tbody/tr["+Integer.toString(rw)+"]/td"));		

				for (WebElement row : rows) 
				{
					if(!row.getText().isEmpty())
					{
						String text = row.getText();
						rowData.add(text);

					}
					else
					{
						String xpath[] = row.toString().split("xpath:");
						String path = xpath[1].substring(0, xpath[1].length()-1) + "[" + (rows.indexOf(row)+1) + "]/a";
						String text = driver.findElement(By.xpath(path)).getAttribute("href");
						System.out.println(text);
						if(text.length()>0)
						{
							rowData.add(text);
						}
					}
				}
				for (int i = 3; i<=data.length-1; i++) 
				{
					reportData.add(data[i].replace("\"", ""));
				}

				System.out.println(rowData);
				System.out.println(reportData);
				for(int i = 0; i<= rowData.size()-1; i++)
				{
					Assert.assertEquals(reportData.get(i).trim().toLowerCase(), rowData.get(i).trim().toLowerCase());
				}
			}
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}


	public void validatExcelDetails()
	{
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//table[contains(@aria-describedby,\"reports_info\")]/tbody/tr[1]/td"))));
			File file = new File(Students.filePath); 
			Thread.sleep(5000);
			System.out.println(file);
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader,';'); 
			List<String[]> header = csvReader.readAll();
			System.out.println(header);
			System.out.println(header.size());
			for (int m = 3; m<header.size();m++) 
			{
				ArrayList<String> rowData =new ArrayList<>();
				ArrayList<String> reportData =new ArrayList<>();

				String []excel = header.get(m).toString().split(";");
				String data[] = excel;
				int rw=m-2;
				List<WebElement> rows = driver.findElements(By.xpath("(//table[contains(@aria-describedby,\"reports_info\")]/tbody/tr["+Integer.toString(rw)+"])[1]/td"));		

				for (WebElement row : rows) 
				{
					if(!row.getText().isEmpty())
					{
						String text = row.getText();
						rowData.add(text);

					}
					else
					{
						try
						{
							String xpath[] = row.toString().split("xpath:");
							String path = xpath[1].substring(0, xpath[1].length()-1) + "[" + (rows.indexOf(row)+1) + "]/a";
							String text = driver.findElement(By.xpath(path)).getAttribute("href");
							System.out.println(text);
							if(text.length()>0)
							{
								rowData.add(text);
							}
						}
						catch(Exception e)
						{
							System.out.println("No hyperlink present");
						}

					}
				}

				for (int i = 0; i<Arrays.toString(header.get(m)).split(",").length; i++) 
				{
					reportData.add(Arrays.toString(header.get(m)).split(",")[i].replace("\"", "").replace("[", "").replace("]", ""));
				}
				;
				System.out.println(reportData);
				System.out.println(rowData);
				for(int i = 0; i<= rowData.size()-1; i++)
				{
					String dat=reportData.get(i).trim().toLowerCase();
					if(dat.equals(""))
					{
						dat="na";
					}
					Assert.assertEquals(dat, rowData.get(i).trim().toLowerCase());
				}
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	public void validateComplaint(String value)
	{
		Select drpState = new Select(driver.findElement(By.xpath("//*[@id=\"reports_length\"]/label/select")));
		drpState.selectByValue("100");
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{

		}

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableRow + "[8]"))));
		String data = driver.findElement(By.xpath("//table[@id = 'reports']/tbody/tr//*[text()='"+User.userEmail+"']/preceding::td[3]")).getText();
		if(value.toLowerCase().equalsIgnoreCase("yes"))
			Assert.assertTrue(!data.equalsIgnoreCase("NA"));
		else
			Assert.assertTrue(data.equalsIgnoreCase("NA"));
	}

	public void validateComplaintWithDate(String value)
	{
		if(courseListName.containsKey(value+"complianceDate"))
			value=courseListName.get(value+"complianceDate").toString();

		Select drpState = new Select(driver.findElement(By.xpath("//*[@id=\"reports_length\"]/label/select")));
		drpState.selectByValue("100");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableRow + "[8]"))));
		String data = driver.findElement(By.xpath("//table[@id = 'reports']/tbody/tr//*[text()='"+User.userEmail+"']/preceding::td[3]")).getText();
		Assert.assertTrue(data.equalsIgnoreCase(value));
	}

	public String getdate(int year)
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");	

		Calendar cal = Calendar.getInstance();
		int res = cal.getActualMaximum(Calendar.DATE);
		cal.add((Calendar.YEAR), year);  
		cal.set(Calendar.DATE,  cal.getActualMaximum(Calendar.DATE));

		System.out.println(sdf.format(cal.getTime()));
		return sdf.format(cal.getTime());



	}

	public void validateComplainceWithDateAndCourse(String value,String course)
	{
		int m=0;
		try
		{
			if(courseListName.containsKey(course+"Option"))
				course=courseListName.get(course+"Option").toString();

			if(courseListName.containsKey(value+"complianceDate"))
				value=courseListName.get(value+"complianceDate").toString();

			course=course.replace("Â","");
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading"))
			{
				val = pageLoad.getAttribute("class");
				try
				{
					String curriculum = reportTable + "[1]/td[6]";
					String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
					wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(reportTable))));

				}
				catch(Exception e)
				{

				}
				if(m==pagload)
					break;
				m++;
			}
			Boolean flag = false;

			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			int rowCount=0;
			int cont=0;
			while(rowCount==0)
			{
				List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
				rowCount = tableRows.size();
				if(cont==150)
					break;

				cont++;
			}

			System.out.println("Row Size"+rowCount);
			System.out.println("Course "+course);
			System.out.println("Value "+value);
			System.out.println("USer mail"+User.userEmail);
			for (int i= 1; i<= rowCount; i++)
			{
				String curriculum = reportTable + "[" + i + "]/td[6]";
				String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
				String Email;

				try
				{
					Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[11]")).getText();

				}
				catch(Exception e)
				{

					Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[11]")).getText();
				}
				if(course.toLowerCase().contains(curricuclumText.toLowerCase())&&Email.contains(User.userEmail))
				{
					flag = true;
					String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[8]")).getText();
					Assert.assertTrue(data.equalsIgnoreCase(value));
				}
			}	
			Assert.assertTrue(flag);
		}
		catch(StaleElementReferenceException e)
		{
			m=0;
			validateComplainceWithDateAndCourse(value,course);
		}
		catch(Exception e)
		{
//			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}

	public void validateeCardlinkverification(String course)
	{
		int m=0;
		Boolean flag=false;
		try
		{

			if(courseListName.containsKey(course+"Option"))
				course=courseListName.get(course+"Option").toString();

			course=course.replace("Â","");
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading"))
			{
				val = pageLoad.getAttribute("class");
				try
				{
					String curriculum = reportTable + "[1]/td[6]";
					String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
					wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(reportTable))));

				}
				catch(Exception e)
				{

				}
				if(m==pagload)
					break;
				m++;
			}

			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			int rowCount=0;
			int cont=0;
			while(rowCount==0)
			{
				List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
				rowCount = tableRows.size();
				if(cont==150)
					break;

				cont++;
			}

			System.out.println("Row Size"+rowCount);
			System.out.println("Course "+course);
			System.out.println("USer mail"+User.userEmail);
			for (int i= 1; i<= rowCount; i++)
			{
				String curriculum = reportTable + "[" + i + "]/td[6]";
				String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
				String Email;

				try
				{
					Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[11]")).getText();
					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(reportTable + "[" + i + "]/td[10]/a"))));

				}
				catch(Exception e)
				{

					Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[11]")).getText();
				}
				if(course.toLowerCase().contains(curricuclumText.toLowerCase())&&Email.contains(User.userEmail))
				{
					System.out.println("Click on ecard");
					
					try
					{
						Thread.sleep(5000);
						
					driver.findElement(By.xpath(reportTable + "[" + i + "]/td[10]/a")).click();
					}
					catch(Exception e)
					{
						WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
						JavascriptExecutor js = (JavascriptExecutor)driver;
						
						js.executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", scrollArea);
						Thread.sleep(5000);
						
						driver.findElement(By.xpath(reportTable + "[" + i + "]/td[10]/a")).click();
						
					}
					Thread.sleep(5000);
					flag=true;
					break;
				}
			}	
			assertTrue(flag);
		}
		catch(StaleElementReferenceException e)
		{
			m=0;
			validateeCardlinkverification(course);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail("Click failed");

		}
	}

	public void validaterowcount(int value)
	{
		int rowCount=0;
		List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
		rowCount = tableRows.size();

		Assert.assertEquals(value, rowCount);
	}
	public void validateComplaintWithDateAndCourseoptionalemail(String value,String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();

		if(courseListName.containsKey(value+"complianceDate"))
			value=courseListName.get(value+"complianceDate").toString();

		course=course.replace("Â","");

		Select drpState = new Select(driver.findElement(By.xpath("//*[@id=\"reports_length\"]/label/select")));
		drpState.selectByValue("100");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		boolean flag = false;
		List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
		int rowCount = tableRows.size();
		System.out.println("Row Size"+rowCount);
		System.out.println("Course "+course);
		System.out.println("USer mail"+User.userEmail);
		for (int i= 1; i<= rowCount; i++)
		{
			String curriculum = reportTable + "[" + i + "]/td[6]";
			String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
			String Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[11]")).getText();

			if(course.toLowerCase().contains(curricuclumText.toLowerCase())&&Email.equals(""))
			{
				flag = true;
				String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[8]")).getText();
				Assert.assertTrue(data.equalsIgnoreCase(value));
			}
		}	
		Assert.assertTrue(flag);
	}

	public void validateEcard(String value)
	{
		Select drpState = new Select(driver.findElement(By.xpath("//*[@id=\"reports_length\"]/label/select")));
		drpState.selectByValue("100");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//table[@id = 'reports']/tbody/tr//*[text()='"+User.userEmail+"']/preceding::td[2]"))));
		String data = driver.findElement(By.xpath("//table[@id = 'reports']/tbody/tr//*[text()='"+User.userEmail+"']/preceding::td[2]")).getText();
		if(value.toLowerCase().equalsIgnoreCase("yes"))
			Assert.assertTrue(!data.equalsIgnoreCase("NA"));
		else
			Assert.assertTrue(data.equalsIgnoreCase("NA"));
	}

	public void validateEcardWithDate(String value)
	{
		if(courseListName.containsKey(value+"EcardDate"))
			value=courseListName.get(value+"EcardDate").toString();

		Select drpState = new Select(driver.findElement(By.xpath("//*[@id=\"reports_length\"]/label/select")));
		drpState.selectByValue("100");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//table[@id = 'reports']/tbody/tr//*[text()='"+User.userEmail+"']/preceding::td[2]"))));
		String data = driver.findElement(By.xpath("//table[@id = 'reports']/tbody/tr//*[text()='"+User.userEmail+"']/preceding::td[2]")).getText();
		Assert.assertTrue(data.equalsIgnoreCase(value));
	}

	public void validateEcardWithDateAndCourse(String value,String course)
	{
		try
		{

			boolean flag = false;
			if(courseListName.containsKey(course+"Option"))
				course=courseListName.get(course+"Option").toString();

			if(courseListName.containsKey(value+"EcardDate"))
				value=courseListName.get(value+"EcardDate").toString();

			course=course.replace("Â","");

			Select drpState = new Select(driver.findElement(By.xpath("//*[@id=\"reports_length\"]/label/select")));
			drpState.selectByValue("100");


			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			int rowCount=0;
			int cont=0;
			while(rowCount==0)
			{
				List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
				rowCount = tableRows.size();
				if(cont==150)
					break;

				cont++;
			}

			for (int i= 1; i<= rowCount; i++)
			{
				driver=driver;
				String curriculum = reportTable + "[" + i + "]/td[6]";
				String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();

				String Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[11]")).getText();
				if((course.toLowerCase().contains(curricuclumText.toLowerCase()))&&(Email.contains(User.userEmail)))
				{
					flag = true;
					String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[9]")).getText();
					System.out.println(data +" "+value);
					Assert.assertTrue(data.equalsIgnoreCase(value));

				}
			}	
			Assert.assertTrue(flag);
		}
		catch(StaleElementReferenceException e)
		{
			validateEcardWithDateAndCourse(value,course);
		}
		catch(Exception e)
		{
			e.printStackTrace();

		}
	}
	public void validateEntryDetails(int assignments, int compliant, int activations, String compliance)
	{
		Assert.assertTrue(newAssignments - oldAssignments == assignments);
		Assert.assertTrue(newIncompliant - oldIncompliant == compliant);
		Assert.assertTrue(newActivations - oldActivations == activations);
		Assert.assertTrue(newCompliance.contains(compliance));
	}
	public void validateCompliantUntilDateWithValueAndCourse(String value,String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();

		boolean flag = false;

		List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String curriculum = reportTable + "[" + i + "]/td[6]";
			String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
			course = course.replaceAll("registered", "\u00AE");
			if(course.toLowerCase().contains(curricuclumText.toLowerCase()))
			{
				String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[8]")).getText();
				Assert.assertTrue(data.trim().toLowerCase().equalsIgnoreCase(value.trim().toLowerCase()));

				flag = true;
				break;
			}
		}		
		Assert.assertTrue(flag);
	}
	public void validateEcardWithDateAndCourseOptionalEmail(String value,String course)
	{
		boolean flag = false;
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();

		if(courseListName.containsKey(value+"EcardDate"))
			value=courseListName.get(value+"EcardDate").toString();

		course=course.replace("Â","");

		Select drpState = new Select(driver.findElement(By.xpath("//*[@id=\"reports_length\"]/label/select")));
		drpState.selectByValue("100");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			driver=driver;
			String curriculum = reportTable + "[" + i + "]/td[6]";
			String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();

			String Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[11]")).getText();
			if((course.toLowerCase().contains(curricuclumText.toLowerCase()))&&(Email.contains("")))
			{
				flag = true;
				String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[9]")).getText();
				System.out.println(data +" "+value);
				Assert.assertTrue(data.equalsIgnoreCase(value));

			}
		}	
		Assert.assertTrue(flag);
	}

	public void validateCompletion(String value)
	{
		Select drpState = new Select(driver.findElement(By.xpath("//*[@id=\"reports_length\"]/label/select")));
		drpState.selectByValue("100");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//table[@id = 'reports']/tbody/tr//*[text()='"+User.userEmail+"']/following-sibling::td[2]"))));
		String data = driver.findElement(By.xpath("//table[@id = 'reports']/tbody/tr//*[text()='"+User.userEmail+"']/following-sibling::td[2]")).getText();
		if(value.toLowerCase().equalsIgnoreCase("yes"))
			Assert.assertTrue(!data.equalsIgnoreCase("NA"));
		else
			Assert.assertTrue(data.equalsIgnoreCase("NA"));
	}

	public void validateLastActivity(String value)
	{
		Select drpState = new Select(driver.findElement(By.xpath("//*[@id=\"reports_length\"]/label/select")));
		drpState.selectByValue("100");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//table[@id = 'reports']/tbody/tr//*[text()='"+User.userEmail+"']/following-sibling::td[1]"))));
		String data = driver.findElement(By.xpath("//table[@id = 'reports']/tbody/tr//*[text()='"+User.userEmail+"']/following-sibling::td[1]")).getText();
		if(value.toLowerCase().equalsIgnoreCase("yes"))
			Assert.assertTrue(!data.equalsIgnoreCase("NA"));
		else
			Assert.assertTrue(data.equalsIgnoreCase("NA"));
	}


	public void validaterow(int row)
	{
		int cont=0;
		int rowCount=0;
		while(row!=rowCount)
		{
			try
			{
				Thread.sleep(250);
				List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
				rowCount = tableRows.size();
			}
			catch (Exception e) {
				// TODO: handle exception
			}
			if(cont==650)
				break;

			cont++;
		}

	}
	public void validateCompletionDateWithValueAndCourse(String value,String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();

		course=course.replace("Â","");
		Boolean flag=false;
		List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String curriculum = reportTable + "[" + i + "]/td[6]";
			String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
			course = course.replaceAll("registered", "\u00AE");
			if(course.toLowerCase().contains(curricuclumText.toLowerCase()))
			{
				String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[13]")).getText();
				Assert.assertTrue(data.trim().toLowerCase().equalsIgnoreCase(value.trim().toLowerCase()));
				flag=true;
			}
		}	
		Assert.assertTrue(flag);
	}
	public void validateConsumedWithCourseNameCurrentDate(String courseName)
	{

		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(reportTable))));
		List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = reportTable + "[" + i + "]/td[6]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			courseName = courseName.replaceAll("registered", "\u00AE");
			if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String launchDate = reportTable + "[" + i + "]/td[12]";
				String launchDateText = driver.findElement(By.xpath(launchDate)).getText();
				System.out.println(launchDateText);
				LocalDate localDate = LocalDate.now();
				String date = localDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
				System.out.println(launchDateText);

				Assert.assertTrue(launchDateText.equalsIgnoreCase(date));
				flag = true;
				break;
			}
		}	
		if(flag == false)
			Assert.fail("Course Name not found");
	}

	public void viewEcardWithCourseName(String courseName)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(reportTable))));
		List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = reportTable + "[" + i + "]/td[6]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			courseName = courseName.replaceAll("registered", "\u00AE");
			if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				scrollRight();
				String ecardUrl = reportTable + "[" + i + "]/td[10]/a";
				driver.findElement(By.xpath(ecardUrl)).click();
				flag = true;
				break;
			}
		}	
		if(flag == false)
			Assert.fail("Course Name not found");
	}
	public boolean validateCurriculumCourse(String course)
	{boolean flg = false;

	try
	{

		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();

		course=course.replace("Â","");


		int m=0;
		val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading"))
		{
			val = pageLoad.getAttribute("class");
			try
			{

				String curriculum = reportTable + "[1]/td[6]";
				String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
				wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(reportTable))));

			}
			catch(Exception e)
			{

			}
			if(m==pagload)
				break;
			m++;
		}
		Thread.sleep(5000);
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

		course=course.replace("Â","");
		int rowCount=0;
		int cont=0;
		while(rowCount==0)
		{
			List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
			rowCount = tableRows.size();
			if(cont==150)
				break;

			cont++;
		}

		System.out.println(rowCount);
		for (int i= 1; i<= rowCount; i++)
		{
			String curriculum = reportTable + "[" + i + "]/td[6]";
			String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
			System.out.println("UI curricuclumText "+curricuclumText);
			String Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[11]")).getText();
			System.out.println("Email "+Email);
			System.out.println("Course "+course);

			if(course.toLowerCase().contains(curricuclumText.toLowerCase())&&Email.contains(User.userEmail))
			{
				System.out.println("Course are available");

				flg = true;
				break;
			}
		}
		System.out.println("Return status "+flg);
		return flg;

	}
	catch(StaleElementReferenceException e)
	{
		System.out.println("StaleElementReferenceException");
		flg=validateCurriculumCourse(course);

	}
	catch(Exception e)
	{
		e.printStackTrace();

		Assert.fail("Issues with application");

	}

	return flg;
	}

	public void validateCompletionWithCourse(String value,String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();

		course=course.replace("Â","");


		Select drpState = new Select(driver.findElement(By.xpath("//*[@id=\"reports_length\"]/label/select")));

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		int rowCount=0;
		int cont=0;
		while(rowCount==0)
		{
			List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
			rowCount = tableRows.size();
			if(cont==150)
				break;

			cont++;
		}

		boolean flag = false;

		for (int i= 1; i<= rowCount; i++)
		{
			String curriculum = reportTable + "[" + i + "]/td[6]";
			String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
			String Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[11]")).getText();

			if(course.toLowerCase().contains(curricuclumText.toLowerCase())&&Email.contains(User.userEmail))
			{
				flag = true;
				String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[13]")).getText();
				if(value.toLowerCase().equalsIgnoreCase("yes"))
					Assert.assertTrue(!data.equalsIgnoreCase("NA"));
				else
					Assert.assertTrue(data.equalsIgnoreCase("NA"));
			}
		}
		Assert.assertTrue(flag);
	}

	public void validateEcard(String value,String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();

		if(courseListName.containsKey(value+"complianceDate"))
			value=courseListName.get(value+"complianceDate").toString();

		course=course.replace("Â","");


		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		int rowCount=0;
		int cont=0;
		while(rowCount==0)
		{
			List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
			rowCount = tableRows.size();
			if(cont==150)
				break;

			cont++;
		}


		boolean flag = false;
		for (int i= 1; i<= rowCount; i++)
		{
			String curriculum = reportTable + "[" + i + "]/td[6]";
			String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
			String Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[11]")).getText();

			if(course.toLowerCase().contains(curricuclumText.toLowerCase())&&Email.contains(User.userEmail))
			{
				flag = true;
				String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[9]")).getText();
				if(value.toLowerCase().equalsIgnoreCase("yes"))
					Assert.assertTrue(!data.equalsIgnoreCase("NA"));
				else
					Assert.assertTrue(data.equalsIgnoreCase("NA"));
			}
		}
		Assert.assertTrue(flag);

	}

	public void validateLastActivityWithCourse(String value,String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();

		boolean flag = false;
		Select drpState = new Select(driver.findElement(By.xpath("//*[@id=\"reports_length\"]/label/select")));
		//		drpState.selectByValue("100");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String curriculum = reportTable + "[" + i + "]/td[6]";
			String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
			String Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[11]")).getText();

			if(course.toLowerCase().contains(curricuclumText.toLowerCase())&&Email.contains(User.userEmail))
			{
				flag = true;
				String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[12]")).getText();
				if(value.toLowerCase().equalsIgnoreCase("yes"))
					Assert.assertTrue(!data.equalsIgnoreCase("NA"));
				else
					Assert.assertTrue(data.equalsIgnoreCase("NA"));
			}
		}
		Assert.assertTrue(flag);
	}

	public int getCurriculumCourseName(String reqCourse)
	{
		if(courseListName.containsKey(reqCourse+"Option"))
			reqCourse=courseListName.get(reqCourse+"Option").toString();

		int tableNumber;
		List<WebElement> tableRows = driver.findElements(CurriculumTable);
		int rowCount = tableRows.size();
		for(tableNumber = 1; tableNumber <= rowCount; tableNumber++)
		{
			String existCourse = driver.findElement(CurriculumTable).getText();
			if(reqCourse.toLowerCase().contains(existCourse.toLowerCase()))
			{
				break;
			}
		}	
		return tableNumber;
	}


	public void validateActiveAssignmentCount(String number)
	{
		String value = driver.findElement(By.xpath(activeAssignments + number + "]")).getText();
		Assert.assertTrue(value.equalsIgnoreCase("1"));
	}

	public void validateIncompliantLearnersCount(String number)
	{
		String value = driver.findElement(By.xpath(incompliantLearners + number + "]")).getText();
		Assert.assertTrue(value.equalsIgnoreCase("0"));
	}

	public void validateActivationNumberCount(String number)
	{
		String value = driver.findElement(By.xpath(activationNumber + number + "]")).getText();
		Assert.assertTrue(value.equalsIgnoreCase("1"));
	}

	public void validateCompliancePercentCount(String number)
	{
		String value = driver.findElement(By.xpath(compliance + number + "]")).getText();
		Assert.assertTrue(value.equalsIgnoreCase("100.00%"));
	}

	public void validateComplaintStatusWithValueAndCourse(String value,String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();


		course=course.replace("Â","");
		try
		{

			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			int rowCount=0;
			int cont=0;
			while(rowCount==0)
			{
				List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
				rowCount = tableRows.size();
				if(cont==150)
					break;

				cont++;
			}

			for (int i= 1; i<= rowCount; i++)
			{
				String curriculum = reportTable + "[" + i + "]/td[6]";
				String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
				String Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[11]")).getText();

				if(course.toLowerCase().contains(curricuclumText.toLowerCase())&&Email.contains(User.userEmail))
				{
					String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[7]")).getText();
					Assert.assertTrue(data.equalsIgnoreCase(value));
				}
			}
		}
		catch(StaleElementReferenceException e)
		{
			validateComplaintStatusWithValueAndCourse(value,course);
		}
		catch(Exception e)
		{
			e.printStackTrace();

		}
	}

	//===============================================================================================	  


	////////////////////////////////////////////////////////P2 Cases ///////////////////////////////////////
	User usr;

	@FindBy(xpath = "//label[text() = 'Rows per page ']//select")
	WebElement rowPerPageSelect;
	String tableHeader = "//div[@class = 'dataTables_scrollHead']//th[text() = '";
	String tableLabel = "//div[@class = 'dataTables_scrollHead']//th";



	String pagination = "(//div[@class = 'dataTables_paginate paging_simple_numbers'])";
	String userStatus1 = "(//select[@id = 'statusFilter']//following-sibling::div//ul//label)";
	String enableExportButton = "//button[@id = 'exportbtn' and not(contains(@class, 'disabled'))]";

	public static int originalRowCount;

	public void validatePageNumbers()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(rowPerPageSelect));
		int paginationOption = driver.findElements(By.xpath(pagination)).size();
		System.out.println("Pagination option available on progress report is " + paginationOption);
		Assert.assertTrue(paginationOption == 2);
	}

	public void getLocationPageNumber()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(rowPerPageSelect));
		List<WebElement> statusList = driver.findElements(By.xpath(pagination));
		Point location1 = null, location2 = null;
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath(pagination + "[" + i + "]"));
			System.out.println(elem.getLocation());
			if(location1 == null)
				location1 = elem.getLocation();
			else if(location2 == null)
				location2 = elem.getLocation();	
		}
		Assert.assertFalse(location1 == location2);
		int x1 = location1.getX();
		int x2 = location2.getX();
		Assert.assertTrue(x1 == x2);
		int y1 = location1.getY();
		int y2 = location2.getY();
		Assert.assertFalse(y1 == y2);
	}

	public void validatePaginationDropdown()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(rowPerPageSelect));
		Select select = new Select(rowPerPageSelect);
		List<WebElement> values = select.getOptions();
		for(int i = 0; i <= values.size() - 1; i++)
		{
			int value = Integer.parseInt(values.get(i).getText());
			System.out.print(value);
			Assert.assertTrue(value%25 == 0);
		}
	}

	public void selectPaginationDropdown()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(rowPerPageSelect));
		Select select = new Select(rowPerPageSelect);
		List<WebElement> values = select.getOptions();
		for(int i = 0; i <= values.size() - 1; i++)
		{
			int value = Integer.parseInt(values.get(i).getText());
			if(value == 50) {
				values.get(i).click();
				break;
			}
		}
		validateRowCount(50);	
	}

	public void validateDefaultUserStatus(String status)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userStatus1 + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userStatus1));
		boolean flag = false;
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath(userStatus1 + "[" + i + "]"));
			String text = elem.getText().trim();
			if(text.equalsIgnoreCase(status)) {
				flag = driver.findElement(By.xpath("(" + userStatus1 + "/input)[" + i + "]")).isSelected();			
			}
		}
		Assert.assertTrue(flag);
	}

	public int getHeaderPosition(String header)
	{

		int columnCount = 0;
		try {
			//WebDriverWait wait = new WebDriverWait(driver, 30);
			//wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableLabel))));
			List<WebElement> tableHeaderRows = driver.findElements(By.xpath(tableLabel));
			for(int i = 1; i <=tableHeaderRows.size(); i++)
			{
				String headerName = driver.findElement(By.xpath(tableLabel + "[" + i +"]")).getText();
				if(headerName.equalsIgnoreCase(header))
				{
					columnCount = i;
					break;				
				}				
			}
			int counter = 0;
			while(columnCount == 0) {
				scrollRight();
				columnCount = getHeaderPosition(header);
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			System.out.println("The column position for " + header +" is " + columnCount);
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return columnCount;
	}


	public void compareDetails()
	{
		try
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String  uiList[][];
			int counter = 0;
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				Thread.sleep(2000);
				counter++;
				if(counter>30)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(reportTable))));
			List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
			List<List<String>> list_UI = new ArrayList<>();
			List<List<String>> list_report = new ArrayList<>();
			File file = new File(std.filePath);
			FileReader filereader = new FileReader(file,StandardCharsets.UTF_8);
			CSVReader csvReader = new CSVReader(filereader); 
			List<String[]> header = csvReader.readAll();
			int rowCount = tableRows.size();
			uiList = new String[rowCount][13];
			int excelRow = 0;
			if(header.size() > rowCount)
				excelRow = rowCount;
			else
				excelRow = header.size()-2;
			String reportDetails[][] = new String[excelRow][13];
			int url = getHeaderPosition("Ecard Url");
			for (int i= 1; i<= rowCount; i++)
			{				
				for(int j = 1; j <= 13; j++)
				{					
					String textValue = "";
					if(j != url) 
						textValue = driver.findElement(By.xpath("(" + reportTable + ")[" + i + "]/td[" + j + "]")).getText();
					else {
						if(driver.findElements(By.xpath("(" + reportTable + ")[" + i + "]/td[" + j + "]/a")).size() > 0)
						{
							textValue = driver.findElement(By.xpath("(" + reportTable + ")[" + i + "]/td[" + j + "]/a")).getAttribute("href");
							HttpURLConnection huc = null;
							int respCode = 200;
						
							huc = (HttpURLConnection)(new URL(textValue).openConnection());
							huc.setRequestMethod("HEAD");
							huc.connect();
							respCode = huc.getResponseCode();
							if(respCode != 200)
								Assert.fail("URL is broken or not valid");
							else
								System.out.println(respCode);
						}
						else	
							textValue = driver.findElement(By.xpath("(" + reportTable + ")[" + i + "]/td[" + j + "]")).getText();
					}
					System.out.println("UI Data "+textValue);
					uiList[i-1][j-1] = textValue;
				}
			}
			for (String[] ints : uiList) 
			{
				list_UI.add(Arrays.asList(ints));
			}
			int count=0;
			for(int i = 1; i <= excelRow; i++)
			{
				String []excel = header.get(i+2);
				String []excelValues = excel[0].split(";");
				for(int j = 0; j < 13; j++)
				{
					System.out.println("Excel Data "+excelValues[j].replace("\"", "").trim());
				
					if(j==9)
					{
					if(!excelValues[j].replace("\"", "").trim().equals("NA"))
					{
					HttpURLConnection huc = null;
					int respCode = 200;
					huc = (HttpURLConnection)(new URL(excelValues[j].replace("\"", "").trim()).openConnection());
					huc.setRequestMethod("HEAD");
					huc.connect();
					respCode = huc.getResponseCode();
					if(respCode != 200)
						Assert.fail("URL is broken or not valid");
					else
						System.out.println(respCode);
			     	System.out.println(uiList[i-1][j]);
					if(!excelValues[j].replace("\"", "").trim().equals(uiList[i-1][j]))
					count++;
					}
					}
				    if(j==6)
					{
				    	reportDetails[i-1][j] = excelValues[j].replace("\"", "").trim().toUpperCase();
					}
				    else	
					reportDetails[i-1][j] = excelValues[j].replace("\"", "").trim();
				}				
			}
			csvReader.close();
			for (String[] ints : reportDetails) {
				list_report.add(Arrays.asList(ints));
			}
			List<List<String>> differences = new ArrayList<>(list_report);
			differences.removeAll(list_UI);
			System.out.println(differences.size());
			System.out.println(count);
			System.out.println(list_report);
			System.out.println(list_UI.toString());
			
			Assert.assertTrue("List report -"+list_report+" UI list -"+ list_UI.toString(), differences.size() == 0||differences.size() == count);
		 	}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}

	public void selectSingleUserStatusFilter(String status)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userStatus1 + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userStatus1));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userStatus1 + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == true)
				driver.findElement(By.xpath("(" + userStatus1 + "/input)[" + i + "]")).click();
		}
		driver.findElement(By.xpath(userStatus1 + "//input[contains(@title,'" + status + "')]")).click();
	}

	public void clickOnMoreFilterSearchButton()
	{
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(5000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(moreFilterSearchButton));
			moreFilterSearchButton.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}


	public void getRowCount()
	{
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(2000);
				counter++;
				if(counter>30)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
			originalRowCount = tableRows.size();

		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void compareRowCount()
	{
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(2000);
				counter++;
				if(counter>30)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
			int rowCount = tableRows.size();
			if(rowCount == originalRowCount)
				Assert.assertTrue(rowCount == originalRowCount);
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void validateDefaultColumnSort(String columnName)
	{
		boolean flag = false;
		
		for(WebElement tt : ComplianceColumns){
			System.out.println(tt.getAttribute("innerText"));
			 if(tt.getAttribute("innerText").toUpperCase().contains(columnName.toUpperCase()))
			 {
					String attribute = tt.getAttribute("aria-sort");
					Assert.assertTrue(attribute != null);
					flag=true;
			 }
			
		}
		Assert.assertTrue(flag);
	}

	public void clickOnColumnHeader(String columnName)
	{
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(2000);
				counter++;
				if(counter>30)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
//			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableHeader + columnName + "']"))));
			JavascriptExecutor js = (JavascriptExecutor) driver;
			
			js.executeScript("arguments[0].click()", driver.findElement(By.xpath("//table[@aria-describedby='reports_info']/thead/tr/th['" + columnName + "']")));
			
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////

	@FindBy(xpath = "//select[@id = 'orgLevel']/preceding-sibling::button")
	WebElement orgLevelFilter;

	@FindBy(xpath = "//label[@class and text() = 'Search for Name, Email or User ID']")
	WebElement userSearchLabel;

	@FindBy(xpath = "//select[@id = 'filterSelect_2']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement orgLevelFilterUnSelectAll;

	@FindBy(xpath = "//select[@id = 'filterSelect_2']//following-sibling::div//a[text() = 'Select all']")
	WebElement orgLevelFilterSelectAll;

	@FindBy(xpath = "(//select[@id = 'filterSelect_2']//following-sibling::div)//input[@type= 'text']")
	WebElement orgLevelFilterFilterSearch;

	@FindBy(xpath = "//select[@id = 'orgLevel']")
	WebElement selectOrgLevelDropdown;

	String unitLevelFilter = "(//select[@id = 'filterSelect_2']//following-sibling::div//ul//label)";
	String unitLevelButton = "(//select[@id = 'filterSelect_2']//following-sibling::div/button)";

	public void validateOrgLevelFilterFilterAvailability()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(orgLevelFilter));
			orgLevelFilter.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void selectOrgLevelMainFilter(int level)
	{
		try
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int counter = 0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userSearchLabel));
			Select select = new Select(selectOrgLevelDropdown);
			select.selectByIndex(level - 1);
			val = pageLoad.getAttribute("class");
			counter = 0;
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(2000);
				counter++;
				if(counter>30)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			js.executeScript("arguments[0].click();", searchButton);
			counter = 0;
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(2000);
				counter++;
				if(counter>30)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void clickOnOrgFilterSearchButton()
	{
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchButton));
			searchButton.click();
			val = pageLoad.getAttribute("class");
			 counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			wait.until(ExpectedConditions.visibilityOf(searchButton));
			searchButton.click();
			
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void validateRecordAvailable()
	{
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			String text = driver.findElement(By.xpath(reportTable + "[1]/td[1]")).getText();
			System.out.println(text);
			System.err.println(text);
			Assert.assertFalse(text.equals("No reports data found."));
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void selectSingleOrgLevelFilter(String courseName)
	{
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitLevelButton))));
			List<WebElement> statusList = driver.findElements(By.xpath(unitLevelFilter));
			driver.findElement(By.xpath(unitLevelButton)).click();
			for(int i = 1; i <= statusList.size(); i++)
			{
				WebElement elem = driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]"));
				boolean flag = elem.isSelected();
				if(flag == true)
					driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]")).click();
			}
			driver.findElement(By.xpath(unitLevelFilter + "//input[contains(@title,'" + courseName + "')]")).click();
			driver.findElement(By.xpath(unitLevelButton)).click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void selectMultiOrgLevelFilter(int count)
	{
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitLevelButton))));
			List<WebElement> statusList = driver.findElements(By.xpath(unitLevelFilter));
			driver.findElement(By.xpath(unitLevelButton)).click();
			for(int j = 0; j < count; j++) {
				for(int i = 1; i <= statusList.size(); i++)
				{
					WebElement elem = driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]"));
					boolean flag = elem.isSelected();
					if(flag == false) {
						driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]")).click();
						break;
					}
				}
			}
			driver.findElement(By.xpath(unitLevelButton)).click();
			//counter = 0;
			//while(val.equalsIgnoreCase("loading_compliance"))
			//{
			//val = js.executeScript("return document.readyState").toString();
			//Thread.sleep(5000);
			//counter++;
			//if(counter>18)
			//Assert.fail("Not able to load page after waiting for 1 minute");
			//}
		}
		catch(Exception e) {

		}

	}

	public void unSelectAllOrgLevelFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitLevelButton))));
			driver.findElement(By.xpath(unitLevelButton)).click();
			List<WebElement> statusList = driver.findElements(By.xpath(unitLevelFilter));
			for(int i = 1; i <= statusList.size(); i++)
			{
				WebElement elem = driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]"));
				boolean flag = elem.isSelected();
				if(flag == false)
					driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]")).click();
			}
			wait.until(ExpectedConditions.visibilityOf(orgLevelFilterUnSelectAll));
			orgLevelFilterUnSelectAll.click();
			driver.findElement(By.xpath(unitLevelButton)).click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void selectAllOrgLevelFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitLevelButton))));
			driver.findElement(By.xpath(unitLevelButton)).click();
			wait.until(ExpectedConditions.visibilityOf(orgLevelFilterSelectAll));
			orgLevelFilterSelectAll.click();
			driver.findElement(By.xpath(unitLevelButton)).click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void searchOrgLevelFilter(String courseName)
	{
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitLevelButton))));
			driver.findElement(By.xpath(unitLevelButton)).click();
			wait.until(ExpectedConditions.visibilityOf(orgLevelFilterFilterSearch));
			counter = 0;
			orgLevelFilterFilterSearch.click();
			orgLevelFilterFilterSearch.clear();
			orgLevelFilterFilterSearch.sendKeys(courseName);
			List<WebElement> statusList = driver.findElements(By.xpath(unitLevelFilter + "/parent::li[not(contains(@class,'hidden'))]"));
			while(statusList.size() > 1)
			{
				statusList = driver.findElements(By.xpath(unitLevelFilter + "/parent::li[not(contains(@class,'hidden'))]"));
				Thread.sleep(2000);
				if(counter > 12)
					Assert.fail("Search functionality for user status is not working");
				counter++;
			}
			driver.findElement(By.xpath(unitLevelFilter + "//input[contains(@title,'" + courseName + "')]")).click();
			driver.findElement(By.xpath(unitLevelButton)).click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}

	}	

	////////////////////////////////////////USER FILTER /////////////////////////////////////////////////////////////

	@FindBy(xpath = "//select[@id = 'statusFilter']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement userUnSelectAll;

	@FindBy(xpath = "(//select[@id = 'statusFilter']//following-sibling::div)//input[@type= 'text']")
	WebElement userFilterSearch;

	public void selectMultiUserStatusFilter(String status)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userStatus1 + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userStatus1));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath(userStatus1 + "//input[contains(@title,'" + status + "')]"));
			boolean flag = elem.isSelected();
			if(flag == false)
				driver.findElement(By.xpath(userStatus1 + "//input[contains(@title,'" + status + "')]")).click();
		}
	}

	public void unSelectAllStatus()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userUnSelectAll));
			userUnSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void searchUserStatus(String status)
	{
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userFilterSearch));
			counter = 0;
			userFilterSearch.click();
			userFilterSearch.clear();
			userFilterSearch.sendKeys(status);
			List<WebElement> statusList = driver.findElements(By.xpath(userStatus1 + "/parent::li[not(contains(@class,'hidden'))]"));
			while(statusList.size() > 1)
			{
				statusList = driver.findElements(By.xpath(userStatus1 + "/parent::li[not(contains(@class,'hidden'))]"));
				Thread.sleep(2000);
				if(counter > 12)
					Assert.fail("Search functionality for user status is not working");
				counter++;
			}
			driver.findElement(By.xpath(userStatus1 + "//input[contains(@title,'" + status + "')]")).click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}

	}

	////////////////////////////////COMPLIANCE FILTER ///////////////////////////////////////////////

	@FindBy(xpath = "//select[@id = 'compliance_status']//following-sibling::div/button")
	WebElement complianceStatusFilter;

	@FindBy(xpath = "//select[@id = 'compliance_status']//following-sibling::div//a")
	WebElement complianceSelectAll;

	@FindBy(xpath = "//select[@id = 'compliance_status']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement complianceUnSelectAll;

	@FindBy(xpath = "(//select[@id = 'compliance_status']//following-sibling::div)//input[@type= 'text']")
	WebElement complianceFilterSearch;


	String complianceStatus = "(//select[@id = 'compliance_status']//following-sibling::div//ul//label)";

	public void validateComplianceStatusFilterAvailability()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(2000);
				counter++;
				if(counter>30)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(complianceStatusFilter));
			complianceStatusFilter.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void selectSingleComplianceStatusFilter(String status)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(complianceStatus + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(complianceStatus));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + complianceStatus + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == true)
				driver.findElement(By.xpath("(" + complianceStatus + "/input)[" + i + "]")).click();
		}
		driver.findElement(By.xpath(complianceStatus + "//input[contains(@title,'" + status + "')]")).click();
	}

	public void selectMultiComplianceStatusFilter(String status)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(complianceStatus + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(complianceStatus));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath(complianceStatus + "//input[contains(@title,'" + status + "')]"));
			boolean flag = elem.isSelected();
			if(flag == false)
				driver.findElement(By.xpath(complianceStatus + "//input[contains(@title,'" + status + "')]")).click();
		}

	}

	public void selectAllComplianceStatus()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(complianceSelectAll));
			complianceSelectAll.click();
			moreFilterSearchButton.click();
		}
		catch(Exception e)
		{

		}
	}

	public void unSelectAllComplianceStatus()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(complianceUnSelectAll));
			complianceUnSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void searchComplianceStatus(String status)
	{
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(complianceFilterSearch));
			counter = 0;
			complianceFilterSearch.click();
			complianceFilterSearch.clear();
			complianceFilterSearch.sendKeys(status);
			List<WebElement> statusList = driver.findElements(By.xpath(complianceStatus + "/parent::li[not(contains(@class,'hidden'))]"));
			while(statusList.size() > 1)
			{
				statusList = driver.findElements(By.xpath(complianceStatus + "/parent::li[not(contains(@class,'hidden'))]"));
				Thread.sleep(2000);
				if(counter > 12)
					Assert.fail("Search functionality for user status is not working");
				counter++;
			}
			driver.findElement(By.xpath(complianceStatus + "//input[contains(@title,'" + status + "')]")).click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}

	}

	public void validateCurriculumStatusOptions()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(complianceStatus + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(complianceStatus));
		Assert.assertTrue(statusList.size() == 3);
		ArrayList<String> statusListAvaialble =new ArrayList<String>();
		ArrayList<String> statusListExpected =new ArrayList<String>();
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath(complianceStatus + "[" + i + "]"));
			String val = elem.getText().replace(" ", "").trim();
			statusListAvaialble.add(val);
		}
		String statusExpected[] = {"Current", "Compliant", "Overdue"};
		for(int i = 0; i <= statusExpected.length - 1; i++)
		{
			statusListExpected.add(statusExpected[i]);
		}
		List<List<String>> list_ui = new ArrayList<>();
		for (String expected : statusListExpected) {
			list_ui.add(Arrays.asList(expected));
		}

		List<List<String>> list_actual = new ArrayList<>();
		for (String actual : statusListAvaialble) {
			list_actual.add(Arrays.asList(actual));
		}

		List<List<String>> differences = new ArrayList<>(list_ui);
		differences.removeAll(list_actual);
		Assert.assertTrue(differences.size() == 0);
	}

	public void scrollBarCount()
	{
		List<WebElement> scrollArea = driver.findElements(By.className("dataTables_scrollBody"));
		Assert.assertTrue(scrollArea.size() == 1);
	}

	public void validateRowCount(int count)
	{
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(2000);
				counter++;
				if(counter>30)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
			int rowCount = tableRows.size();
			if(rowCount == count)
				Assert.assertTrue(rowCount == count);
			else {
				List<WebElement> pageNumber = driver.findElements(By.xpath(pagination + "[1]/span/a"));
				Assert.assertTrue(pageNumber.size() == 1);
			}
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
	}
	public void clearSearchResult()
	{
		try {
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			JavascriptExecutor js = (JavascriptExecutor)driver;
			
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchClear));
			executor.executeScript("arguments[0].click();", searchClear);
			executor.executeScript("arguments[0].click();", searchButton);
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			val = js.executeScript("return document.readyState").toString();
			counter = 0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(5000);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	String row = "//table[@aria-describedby='reports_info' and @id='reports']//tbody/tr";

	String searchTable = "//table[@aria-describedby='reports_info']/thead/tr/th";
	
	public void validatecomplianceSortingEachColumn() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		int countna=0;
		for (int i = 1; i <= 13; i++) {
			ArrayList<String> obtainedList = new ArrayList<>();
			// div[@id="courseList_wrapper"]//th
			WebElement column = driver.findElement(By.xpath(searchTable + "[" + i + "]"));
			try {
				Thread.sleep(4000);
				wait.until(ExpectedConditions.elementToBeClickable(column));
			} catch (Exception e) {
				WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
				js.executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", scrollArea);
				
				wait.until(ExpectedConditions
						.elementToBeClickable(driver.findElement(By.xpath(searchTable + "[" + i + "]"))));
			}
			js.executeScript("arguments[0].click()", column);
			val = pageLoad.getAttribute("class");
			int m = 0;
			while (val.toLowerCase().contains("loading")) {
				val = pageLoad.getAttribute("class");
				if (m == pagload)
					break;
				m++;
			}
			try
			{
			Thread.sleep(4000);
			}catch (Exception e) {
			}
			List<WebElement> elementList = driver.findElements(By.xpath(row + "/td[" + i + "]"));
			
			for (WebElement we : elementList) {
				obtainedList.add(we.getText());
				
				
			}
			ArrayList<String> sortedList = new ArrayList<>();
			for (String s : obtainedList) {
				
				sortedList.add(s);
			}
			Collections.sort(sortedList);

			System.out.println("Sorted list" + sortedList.toString());
			System.out.println("Obtainted lists" + obtainedList);
//			Assert.assertTrue(sortedList.equals(obtainedList));

			if(column.getText().contains("ECARD VALID UNTIL")||column.getText().contains("ECARD URL") ||column.getText().contains("COMPLETION DATE")||column.getText().contains("COMPLIANT UNTIL")||column.getText().contains("LAST ACTIVITY")||column.getText().contains("COMPLIANCE STATUS"))
			{
				
				System.out.println("====================================================================");
				  List[] lists = split(sortedList);
				  String list=lists[1].toString()+lists[0].toString();
				  System.out.println(list);
//				  System.err.println(lists[1].toString()+", "+lists[0].toString());
				  Assert.assertTrue(column.getText()+"Obtainted lists", obtainedList.toString().equals(list.replace("][", ", ")));

			}
			else
				Assert.assertTrue(column.getText()+"Obtainted lists", sortedList.equals(obtainedList));

			js.executeScript("arguments[0].click()", column);
			obtainedList.removeAll(obtainedList);
			val = pageLoad.getAttribute("class");
			m = 0;
			while (val.toLowerCase().contains("loading")) {
				val = pageLoad.getAttribute("class");
				if (m == pagload)
					break;
				m++;
			}
			try
			{
			Thread.sleep(4000);
			}catch (Exception e) {
			}
			elementList = driver.findElements(By.xpath(row + "/td[" + i + "]"));
			for (WebElement we : elementList) {
//				System.err.println(we.getText());
				
				obtainedList.add(we.getText());
			}
			
			Collections.reverse(sortedList);
			
			if(column.getText().contains("ECARD VALID UNTIL")||column.getText().contains("ECARD URL") ||column.getText().contains("COMPLETION DATE")||column.getText().contains("COMPLIANT UNTIL")||column.getText().contains("LAST ACTIVITY")||column.getText().contains("COMPLIANCE STATUS"))
			{
				
				System.out.println("====================================================================");
				  List[] lists = split(sortedList);
				  String list=lists[0].toString()+lists[1].toString();
				  System.out.println(list);
//				  System.err.println(lists[1].toString()+", "+lists[0].toString());
				  Assert.assertTrue(column.getText()+"Obtainted lists", obtainedList.toString().equals(list.replace("][", ", ")));
			
			}
			else
				Assert.assertTrue(column.getText()+"Obtainted lists", sortedList.equals(obtainedList));

			
//			
//			Assert.assertTrue(sortedList.equals(obtainedList));

		}

	}
	
	public static List[] split(List<String> list)
    {
 
        // Creating two empty lists
        List<String> first = new ArrayList<String>();
        List<String> second = new ArrayList<String>();
 
        // Getting size of the list
        // using size() method
        int size = list.size();
 
        // Step 1
        // (First size)/2 element copy into list
        // first and rest second list
        for (int i = 0; i < size; i++)
        {
        
        	if(list.get(i).equals("NA"))
        	{
            	second.add(list.get(i));
        	}
        	else
            	first.add(list.get(i));

        }
        // Step 2
        // (Second size)/2 element copy into list first and
        // rest second list
        
        // Returning a List of array
        return new List[] { first, second };
    }
 
}
