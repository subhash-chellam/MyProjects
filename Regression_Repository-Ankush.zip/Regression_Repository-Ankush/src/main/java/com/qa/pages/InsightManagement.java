package com.qa.pages;

import java.awt.AWTException;
import java.awt.Robot;
//import java.awt.event.KeyEvent;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.python.modules.thread.thread;

import com.qa.util.TestBase;
import org.junit.Assert;

public class InsightManagement extends TestBase
{
	@FindBy(xpath = "//input[@id= 'add_application']")
	WebElement addApplication;
	
	@FindBy(xpath = "//input[@name= 'application_name']")
	WebElement applicationName;
	
	@FindBy(xpath = "//textarea[@name= 'short_description']")
	WebElement applicationDescription;
	
	@FindBy(xpath = "//input[@name= 'link']")
	WebElement applicationLink;
	
	@FindBy(xpath = "//input[@value= 'Save']")
	WebElement saveButton;
	
	@FindBy(xpath = "//div[@class= 'modal-body']/p")
	WebElement deleteMessage;
	
	@FindBy(xpath = "//div[@class= 'modal-footer']/a")
	WebElement deleteButton;
	
	@FindBy(xpath = "//small[@data-fv-validator = 'callback' and @data-fv-for = 'application_name']")
	WebElement appNameLengthError;

	@FindBy(xpath = "//small[@data-fv-validator = 'remote' and @data-fv-for = 'link']")
	WebElement invalidLinkError;
	
	public static String insightAppName;
	String message = "Are you sure you want to delete the Insights Application?";
	String insightTable = "//table[@id = 'insights-table']//tbody/tr";
	String link="//*[@id=\"insights-table_paginate\"]/span/a";
	String errorMessage = "is required and can't be empty";	
	String mandatoryMessagePath = "(//small[@data-fv-validator = 'notEmpty'])";
	String lengthErrorMessage = "The Analytics Application Name must be less than 50 characters long";
	String invalidLinkMessage = "The link is not valid";
	public static String description = "This is created for automation and updated the description";
	
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	
	public InsightManagement() 
	{
		PageFactory.initElements(driver, this);			      
	}
	
	public void clickOnAddApplication()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(addApplication));
		addApplication.click();
		//executor.executeScript("arguments[0].click();", addApplication);
	}

	public void addAppDetails()
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(applicationName));
			applicationName.click();
			applicationName.clear();
			String date = new java.util.Date().toString();
			date = date.replace(" ", "");
			insightAppName = "insight_" + date;
			applicationName.sendKeys(insightAppName);
			applicationDescription.click();
			applicationDescription.clear();
			applicationDescription.sendKeys("This is created for automation");
			applicationLink.click();
			applicationLink.clear();
			applicationLink.sendKeys("https://eco-dev.contentservice.net/analytics/applications/launch/rqi-2020-insights");
			Thread.sleep(4000);
			saveButton.click();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	public void deleteAppInsight()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(insightTable))));
			List<WebElement> table = driver.findElements(By.xpath(insightTable));
		
			List<WebElement> hyper = driver.findElements(By.xpath(link));
			
			hyper.get(hyper.size()-1).click();
			
			Thread.sleep(5000);
			
			for(int i= 1; i <= table.size(); i++)
			{
				String appName = driver.findElement(By.xpath(insightTable + "[" + i + "]/td[1]")).getText();
				if(appName.equalsIgnoreCase(insightAppName))
				{
					driver.findElement(By.xpath(insightTable + "[" + i + "]/td[4]/a[2]")).click();
					validateDeleteWarningMessage();
				}
			}
			
		} 
		catch (Exception e) 
		{
			
		}
	}
	
	public void deleteMultipleAppInsight()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(insightTable))));
		List<WebElement> table = driver.findElements(By.xpath(insightTable));
		for(int i= 1; i <= table.size(); i++)
		{
			String appName = driver.findElement(By.xpath(insightTable + "[" + i + "]/td[1]")).getText();
			if(!(appName.equalsIgnoreCase("RQI-T") || appName.equalsIgnoreCase("Rqi-2020") ||
				appName.equalsIgnoreCase("ZEdit") || appName.equalsIgnoreCase("googletest")|| 
				appName.equalsIgnoreCase("goo'gletest")	))
			{
				driver.findElement(By.xpath(insightTable + "[" + i + "]/td[4]/a[2]")).click();
				validateDeleteWarningMessage();
			}
		}
	}
	
	public void validateDeleteWarningMessage()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(deleteMessage));
		String val = deleteMessage.getText();
		Assert.assertTrue(val.equalsIgnoreCase(message));
		wait.until(ExpectedConditions.visibilityOf(deleteButton));
		deleteButton.click();
	}
	
	public void clickOnEditApplication()
	{
		try
		{
			Thread.sleep(4000);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(insightTable))));
		List<WebElement> table = driver.findElements(By.xpath(insightTable));
		for(int i= 1; i <= table.size(); i++)
		{
			String appName = driver.findElement(By.xpath(insightTable + "[" + i + "]/td[1]")).getText();
			if(appName.equalsIgnoreCase(insightAppName))
			{
				driver.findElement(By.xpath(insightTable + "[" + i + "]/td[4]/a[1]/em")).click();
				wait.until(ExpectedConditions.visibilityOf(applicationName));
			}
		}
		}
		catch(Exception e)
		{
			
		}
	}
	
	public void removeAllAppDetails()
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(applicationName));
			applicationName.click();
			applicationName.clear();
			saveButton.click();
			validateMandatoryErrorMessage("1", "Analytics Application Name");
			driver.navigate().refresh();
			applicationDescription.click();
			applicationDescription.clear();
			saveButton.click();
			validateMandatoryErrorMessage("2", "description");
			driver.navigate().refresh();
			applicationLink.click();
			applicationLink.clear();
			saveButton.click();
			validateMandatoryErrorMessage("3", "link");			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

//	public void selectAllDelete()
//	{
//		Robot robot;
//		try {
//			robot = new Robot();
//			robot.keyPress(KeyEvent.VK_CONTROL);
//			robot.keyPress(KeyEvent.VK_A);
//			robot.keyRelease(KeyEvent.VK_A);
//			robot.keyRelease(KeyEvent.VK_CONTROL);
//			robot.keyPress(KeyEvent.VK_DELETE);
//			robot.keyRelease(KeyEvent.VK_DELETE);
//		} 
//		catch (AWTException e) 
//		{
//			
//		}
//		
//	}
	
	public void validateMandatoryErrorMessage(String number, String name)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(mandatoryMessagePath + "[" + number + "]"))));
		String val = driver.findElement(By.xpath(mandatoryMessagePath + "[" + number + "]")).getText().trim();
		System.out.println(val);
		Assert.assertTrue(val.equalsIgnoreCase("The " + name + " " + errorMessage));
	}

	public void validateLengthErrorMessage()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(appNameLengthError));
		String val = appNameLengthError.getText();
		Assert.assertTrue(val.equalsIgnoreCase(lengthErrorMessage));
	}
	
	public void enterNameWithGivenLength(int length)
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(applicationName));
			applicationName.click();
			applicationName.clear();
			String date = new java.util.Date().toString();
			date = date.replace(" ", "");
			insightAppName = "insight_" + date;
			while(insightAppName.length() < 50)
			{
				insightAppName = insightAppName + "_" + date;
			}
			applicationName.sendKeys(insightAppName);
			validateLengthErrorMessage();
			applicationDescription.click();
			applicationDescription.clear();
			applicationDescription.sendKeys("This is created for automation");
			applicationLink.click();
			applicationLink.clear();
			applicationLink.sendKeys("https://eco-dev.contentservice.net/analytics/applications/launch/rqi-2020-insights");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	public void enterNameWithURL()
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(applicationName));
			applicationName.click();
			applicationName.clear();
			applicationName.sendKeys("https://eco-dev.contentservice.net/analytics/applications/launch/rqi-2020-insights");
			validateLengthErrorMessage();
			applicationDescription.click();
			applicationDescription.clear();
			applicationDescription.sendKeys("This is created for automation");
			applicationLink.click();
			applicationLink.clear();
			applicationLink.sendKeys("https://eco-dev.contentservice.net/analytics/applications/launch/rqi-2020-insights");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	public void editName()
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(applicationName));
			applicationName.click();
			applicationName.clear();
			String date = new java.util.Date().toString();
			date = date.replace(" ", "");
			insightAppName = "insight_" + date + "_update";
			applicationName.sendKeys(insightAppName);
			applicationDescription.click();
			applicationDescription.clear();
			applicationDescription.sendKeys("This is created for automation and updated the name");
			applicationLink.click();
			applicationLink.clear();
			applicationLink.sendKeys("https://eco-dev.contentservice.net/analytics/applications/launch/rqi-2020-insights");
			Thread.sleep(4000);
			saveButton.click();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	public void editDesription()
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(applicationName));
			applicationDescription.click();
			applicationDescription.clear();
			applicationDescription.sendKeys(description);
			applicationLink.click();
			applicationLink.clear();
			applicationLink.sendKeys("https://eco-dev.contentservice.net/analytics/applications/launch/rqi-2020-insights");
			Thread.sleep(4000);
			saveButton.click();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	public void removeDescriptionAppDetails()
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(applicationName));
			applicationDescription.click();
//			selectAllDelete();
			validateMandatoryErrorMessage("2", "description");		
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	public void enterInvalidUrl()
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(applicationName));
			applicationLink.click();
			applicationLink.clear();
			applicationLink.sendKeys("wewttw.com");
			validateInvalidUrlMessage();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	public void validateInvalidUrlMessage()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(invalidLinkError));
		String val = invalidLinkError.getText();
		Assert.assertTrue(val.equalsIgnoreCase(invalidLinkMessage));
		
	}

}
