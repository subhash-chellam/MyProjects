package com.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.util.DatabaseConnection;
import com.qa.util.TestBase;


import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Properties;

import org.apache.commons.io.FilenameUtils;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.junit.Cucumber;

public class LoginPage extends TestBase
{
	DashBoard db;

//	@FindBy(xpath = "//input[@type = 'submit']")
//	WebElement adminSignIn;

	@FindBy(xpath = "//a[text()= ' Sign In']")
	WebElement adminSignIna;
	
//	@FindBy(xpath = "//input[@name='username']")
//	WebElement userEmail;
//
//	@FindBy(xpath = "//input[@name = 'password']")
//	WebElement userPwd;
//
//	@FindBy(xpath = "//button[text() = 'Log in']")
//	WebElement signIn;

	@FindBy(xpath = "//*[@id='onetrust-accept-btn-handler']")
	WebElement acceptBtn;
	
	@FindBy(xpath = "//span[text()='Super Administrator']")
	WebElement userRole;

	@FindBy(xpath = "//span[text()='Administrator']")
	WebElement homePage;

	@FindBy(xpath = "//div[contains(@class, 'user_details')]//a[@data-toggle='dropdown']")
	WebElement menuOption;

	@FindBy(xpath = "//div[contains(@class, 'user_details')]//a[contains(text(),'Logout')]")
	WebElement logOut;

	@FindBy(xpath = "//div[contains(@class, 'user_details')]//a[contains(text(),'Dashboard')]")
	WebElement adminDashboard;

	@FindBy(xpath = "(//a[contains(text(), 'Login')])[2]")
	WebElement loginEndUser;

	@FindBy(xpath = "//input[@id = 'username']")
	WebElement endUserEmail;

	@FindBy(xpath = "//input[@id = 'password']")
	WebElement endUserPwd;

	@FindBy(xpath = "//span[text()='RQI Implementer']")
	WebElement userRQIRole;

	@FindBy(xpath = "//span[text()='Super Implementer']")
	WebElement userSuperRole;

	@FindBy(xpath = "//a[contains(text(), 'Dashboard')]")
	WebElement dashboard;

	@FindBy(xpath = "//ul[@id = 'main-menu']")
	WebElement dashboardMainMenu;

	@FindBy(xpath = "//a[text() = 'Logout']")
	WebElement dashboardLogout;

	@FindBy(xpath = "//a[@id = 'sap-link']")
//	@FindBy(xpath = "//input[@type = 'submit']")
    WebElement adminSignIn;
	
	@FindBy(xpath = "//input[@id='gigya-input-text']")
//	@FindBy(xpath = "//input[@id='username']")
	WebElement userEmail;
    
	@FindBy(xpath = "//input[@placeholder = 'Password *']")
//	@FindBy(xpath = "//input[@placeholder = 'Password']")
	WebElement userPwd;
	
	@FindBy(xpath = "(//input[@value='Log in'])[2]")
//	@FindBy(xpath = "//button[text() = 'Log in']")
    WebElement signIn;

	String signinXpth;
	
	public LoginPage() 
	{
		signinXpth="(//input[@value='Log in'])[2]";
		PageFactory.initElements(driver, this);
		
		
	}

	@Before
	public void getScenarioName(Scenario scenario) throws Exception
	{   
		Properties prop1= new Properties();
		FileInputStream fis1 =new FileInputStream(System.getProperty("user.dir")+"/src/test/java/resources/inputs.properties");
		prop1.load(fis1);
		String scenarioName = scenario.getName();
		String featureName = scenario.getId();
		System.out.println("Feature file scenario is *********** " + scenarioName);
		String name = FilenameUtils.getName(featureName);
		String result = name.split(":")[0];
		System.out.println("Feature file scenario is *********** " + result);
		//		try {
		//			DatabaseConnection dc = new DatabaseConnection();
		//			dc.insertExecutionDetails(prop1.getProperty("SuitType"),result,scenarioName);
		//		} catch (Exception e) {
		//			e.printStackTrace();
		//		}
	}

	@After
	public void updateEndExecutionTime() throws Exception
	{   
		System.out.println("modifying end date");
		Properties prop1= new Properties();
		FileInputStream fis1 =new FileInputStream(System.getProperty("user.dir")+"/src/test/java/resources/inputs.properties");
		prop1.load(fis1);

	}
	

	public void clickOnAdminSignIn() 
	{
		try
		{
			wait.until(ExpectedConditions.visibilityOf(adminSignIn));
			adminSignIn.click();
		}
		catch(Exception e)
		{
			
			adminSignIna.click();
			
		}
	}
	public void clickOnAdminSignInforadmin() 
	{
		try
		{
			wait.until(ExpectedConditions.visibilityOf(adminSignIna));
			adminSignIna.click();
		}
		catch(Exception e)
		{
			
			adminSignIn.click();
			
		}
	}
	public void clickOnAdminSignIna() 
	{
		try
		{
			wait.until(ExpectedConditions.visibilityOf(adminSignIn));
			adminSignIn.click();
		}
		catch(Exception e)
		{
			
			
		}
	}

	public void credentials(String userName, String pwd) 
	{
		if(!(driver.getCurrentUrl().contains("/admin/login")))
			clickOnAdminSignIna();
			
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(signIn));
		userEmail.clear();
		userEmail.sendKeys(userName);
		try
		{
			acceptBtn.click();	
		}
		catch(Exception e)
		{
			
		}
	
		userPwd.sendKeys(pwd);
		signIn.click();
	}

	public void selectUserRole() 
	{
		WebDriverWait wait = new WebDriverWait(driver, 50);
		try
		{
			Thread.sleep(4000);
			if(driver.getCurrentUrl().contains("/admin/organizations/chooseDashboard"))
				System.out.println("In the chooseDashboard ");
			else
				credentials(prop.getProperty("userEmailId"+prop.getProperty("environment")), prop.getProperty("userPassword"+prop.getProperty("environment")));
		
			wait.until(ExpectedConditions.visibilityOf(userRole));
			userRole.click();
			db = new DashBoard();
			db.selectOrgpanel();
		}
		catch(Exception e)
		{
			clickOnAdminSignIna();
			wait.until(ExpectedConditions.visibilityOf(userRole));
			userRole.click();
			db = new DashBoard();
			db.selectOrgpanel();
		}
	}

	 public void selectUserRoleOnly(String role)
	    {
	        WebDriverWait wait = new WebDriverWait(driver, 10);
	        try
	        {
	        	Thread.sleep(4000);
		    	
	        	if(driver.getCurrentUrl().contains("/admin/organizations/chooseDashboard"))
					System.out.println("In the chooseDashboard ");
				else
					credentials(prop.getProperty("userEmailId"+prop.getProperty("environment")), prop.getProperty("userPassword"+prop.getProperty("environment")));
		
	            switch(role)
	            {
	                case "super admin":
	                    wait.until(ExpectedConditions.visibilityOf(userRole));
	                    userRole.click();
	                    break;
	                case "rqi":
	                    wait.until(ExpectedConditions.visibilityOf(userRQIRole));
	                    userRQIRole.click();
	                    break;
	            	case "Super Implementer":
						wait.until(ExpectedConditions.visibilityOf(userSuperRole));
						userSuperRole.click();
						break;
	                default:
	            }            
	        }
	        catch (Exception e)
	        {
	            clickOnAdminSignIn();
	            if(driver.getCurrentUrl().contains("/admin/organizations/chooseDashboard"))
					System.out.println("In the chooseDashboard ");
				else
					credentials(prop.getProperty("userEmailId"+prop.getProperty("environment")), prop.getProperty("userPassword"+prop.getProperty("environment")));
		
	            switch(role)
	            {
	                case "super admin":
	                    wait.until(ExpectedConditions.visibilityOf(userRole));
	                    userRole.click();
	                    break;
	                case "rqi":
	                    wait.until(ExpectedConditions.visibilityOf(userRQIRole));
	                    userRQIRole.click();
	                default:
	            }  
	        }
	    }



	  
	public void selectUserRoleOnly() 
	{
		try 
		{
			Thread.sleep(6000);
			if(driver.getCurrentUrl().contains("/admin/organizations/chooseDashboard"))
				System.out.println("In the chooseDashboard ");
			else
				credentials(prop.getProperty("userEmailId"+prop.getProperty("environment")), prop.getProperty("userPassword"+prop.getProperty("environment")));
	
			wait.until(ExpectedConditions.visibilityOf(userRole));
			userRole.click();
		} 
		catch (Exception e) 
		{
			clickOnAdminSignIn();
			wait.until(ExpectedConditions.visibilityOf(userRole));
			userRole.click();
		}
	}
	
	public void selectUserRole(String role) 
	{
		WebDriverWait wait = new WebDriverWait(driver, 20);
		try 
		{
			if(driver.getCurrentUrl().contains("/admin/organizations/chooseDashboard"))
				System.out.println("In the chooseDashboard ");
			else
				credentials(prop.getProperty("userEmailId"+prop.getProperty("environment")), prop.getProperty("userPassword"+prop.getProperty("environment")));
	
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//span[text()='"+role+"']"))));
			driver.findElement(By.xpath("//span[text()='"+role+"']")).click();
		} 
		catch (Exception e) 
		{
			clickOnAdminSignIn();
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//span[text()='"+role+"']"))));
			driver.findElement(By.xpath("//span[text()='"+role+"']")).click();
		}
	}

	public void verfiy_the_home_page()
	{
		boolean flag = false;
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(homePage));
			flag = true;
			System.out.println("Successfully Login");
		}
		catch (Exception e) 
		{
			System.out.println("Issue in login");
			e.getMessage();
		}
		System.out.println(flag);

	}

	public void user_logout_from_application() 
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(menuOption));
		menuOption.click();
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(logOut));
		logOut.click();
//		driver.quit();
	}

	public void user_close_the_browser() 
	{
		driver.quit();
		Admin.email = null;
	}

	public void clickOnAdminSignInEndUser() {
		WebDriverWait wait = new WebDriverWait(driver, 5);
		wait.until(ExpectedConditions.visibilityOf(loginEndUser));
		loginEndUser.click();

	}

	public void credentialsEndUser(String userName, String pwd) 
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(signIn));
		endUserEmail.sendKeys(userName);
		endUserPwd.sendKeys(pwd);
		signIn.click();
	}

	public void user_logout_from_application_without_quit() 
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(menuOption));
		menuOption.click();
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(logOut));
		logOut.click();
	}

	public void selectUserAsRQI() 
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(userRQIRole));
			userRQIRole.click();
		}
		catch(Exception e)
		{
			
			clickOnAdminSignIn();
			selectUserAsRQI();
		}
	}
	
	public void selectUserAsSuperImplementer() 
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(userSuperRole));
			userSuperRole.click();
		}
		catch(Exception e)
		{
			
			clickOnAdminSignIn();
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(userSuperRole));
			userSuperRole.click();
		}
	}

	public void user_navigate_dashboard() 
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(menuOption));
		menuOption.click();
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(dashboard));
		dashboard.click();
	}

	public void user_logout_from_dashboard() 
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(dashboardMainMenu));
		dashboardMainMenu.click();
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(dashboardLogout));
		dashboardLogout.click();
		driver.quit();
	}

	public void selectOrgpanel1() {
		db = new DashBoard();
		db.selectOrgpanel();
		
	}
}
