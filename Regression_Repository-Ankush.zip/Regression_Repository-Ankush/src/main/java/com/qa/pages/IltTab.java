package com.qa.pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.util.TestBase;

public class IltTab extends TestBase
{

	@FindBy(xpath = "//a[text() = 'ILT']")
	WebElement iltTab;
	
	@FindBy(xpath = "//a[text() = 'Create Class']")
	WebElement createClassButton;
	
	@FindBy(xpath = "//input[@id = 'class_name']")
	WebElement className;
	
	@FindBy(xpath = "//select[@id = 'course_id']")
	WebElement selectCourseName;
	
	@FindBy(xpath = "//input[@id = 'class_start_date']")
	WebElement courseStartDate;
	
	@FindBy(xpath = "//input[@id = 'class_start_date']")
	WebElement courseStartDatePickUp;
	
	@FindBy(xpath = "//div[@class='datepicker-days']")
	WebElement calendarProduct;
	
	@FindBy(xpath = "//input[@id = 'class_start_time']")
	WebElement time;
	
	@FindBy(xpath = "//input[@id = 'submit_btn']")
	WebElement submitButton;
	
	@FindBy(xpath = "//a[@class = 'action_dropdown']//parent::div")
	WebElement classAction;
	
	@FindBy(xpath = "//a[text() = 'Class Details']")
	WebElement classDetails;
	
	@FindBy(xpath = "(//div[@class = 'skillChkBoxCls'])[1]")
	WebElement selectAllCheckbox;	
	
	@FindBy(xpath = "//button[@id = 'bulkActionButton']")
	WebElement bulkActionDropdown;	
	
	@FindBy(xpath = "//a[text() = 'Update Completion']")
	WebElement bulkActionCompleteClass;	
	
	@FindBy(xpath = "//input[@id = 'skill_update_date']")
	WebElement bulkCompletionDate;	
	
	@FindBy(xpath = "//td[@class = 'day']")
	WebElement bulkCompletionCalendar;	
	
	@FindBy(xpath = "//input[@id = 'updateBulkSkillsBtn']")
	WebElement updateCourseCompletion;	

	
	String datePick = "//td[contains(@class, 'day' ) and text() = ";
	String selectStudent = "(//div[@class = 'skillChkBoxCls']/label)";
	
	public static String createdClassName;
	
	public IltTab() 
	{
		PageFactory.initElements(driver, this);
	}
	
	public void clickIltTab()
	{
		WebDriverWait wait = new WebDriverWait(driver, 90);
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click()", iltTab);
		wait.until(ExpectedConditions.visibilityOf(createClassButton));
	}
	
	public void createClass()
	{
		WebDriverWait wait = new WebDriverWait(driver, 90);
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		wait.until(ExpectedConditions.visibilityOf(createClassButton));
		try
		{
		createClassButton.click();
		}
		catch(Exception e)
		{
			jse.executeScript("arguments[0].click()", createClassButton);
		}
	}
	
	public void enterClassDetails()
	{
		WebDriverWait wait = new WebDriverWait(driver, 90);
		wait.until(ExpectedConditions.visibilityOf(className));
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		className.click();
		className.clear();
		createdClassName = "class" + date;
		className.sendKeys(createdClassName);
		Select select = new Select(selectCourseName);
		select.selectByIndex(1);
		DateFormat dateFormat = new SimpleDateFormat("dd");
		Date dateCalendar = new Date();
		Calendar cal = Calendar.getInstance();
		String formattedStartDate = dateFormat.format(dateCalendar);
		String formattedEndDate = dateFormat.format(cal.getTime());
		System.out.println("Current date is " + formattedStartDate + " and end date is " + formattedEndDate);
		courseStartDate.click();
		wait.until(ExpectedConditions.visibilityOf(calendarProduct));
		WebElement reqDate = driver.findElement(By.xpath(datePick + formattedEndDate + " and not(contains(@class, 'disabled day' ))]"));
		reqDate.click();
		time.click();
		submitButton.click();
	}
	
	public void navigateClassDetails()
	{
		WebDriverWait wait = new WebDriverWait(driver, 90);
		wait.until(ExpectedConditions.visibilityOf(classAction));
		classAction.click();
		wait.until(ExpectedConditions.visibilityOf(classDetails));
		classDetails.click();
	}
	
	public void selectMultipleStudents(int studentCount)
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 90);
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			wait.until(ExpectedConditions.visibilityOf(selectAllCheckbox));
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(selectStudent + "[" + 1 + "]"))));
			Thread.sleep(2000);
			for(int i = 2; i <= studentCount + 1; i++)
			   {
				
				   WebElement student = driver.findElement(By.xpath(selectStudent + "[" + i + "]"));
				   jse.executeScript("arguments[0].click()", student);
			   }
		}
		catch (Exception e) 
		{
		
		}		
	}
	
	public void selectBulkCompletion()
	{
		WebDriverWait wait = new WebDriverWait(driver, 90);
		wait.until(ExpectedConditions.visibilityOf(bulkActionDropdown));
		bulkActionDropdown.click();
		wait.until(ExpectedConditions.visibilityOf(bulkActionCompleteClass));
		bulkActionCompleteClass.click();
		
	}

	public void enterCompletionDetails()
	{
		WebDriverWait wait = new WebDriverWait(driver, 90);
		wait.until(ExpectedConditions.visibilityOf(bulkCompletionDate));
		bulkCompletionDate.click();
		wait.until(ExpectedConditions.visibilityOf(bulkCompletionCalendar));
		bulkCompletionCalendar.click();
		wait.until(ExpectedConditions.visibilityOf(updateCourseCompletion));
		updateCourseCompletion.click();
		
	}
	
	public void enterClassDetailAsPerName(String courseName)
	{
		WebDriverWait wait = new WebDriverWait(driver, 90);
		wait.until(ExpectedConditions.visibilityOf(className));
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		className.click();
		className.clear();
		createdClassName = "class" + date;
		className.sendKeys(createdClassName);
		Select select = new Select(selectCourseName);
		select.selectByVisibleText(courseName);
		DateFormat dateFormat = new SimpleDateFormat("dd");
		Date dateCalendar = new Date();
		Calendar cal = Calendar.getInstance();
		String formattedStartDate = dateFormat.format(dateCalendar);
		String formattedEndDate = dateFormat.format(cal.getTime());
		System.out.println("Current date is " + formattedStartDate + " and end date is " + formattedEndDate);
		courseStartDate.click();
		wait.until(ExpectedConditions.visibilityOf(calendarProduct));
		WebElement reqDate = driver.findElement(By.xpath(datePick + formattedEndDate + " and not(contains(@class, 'disabled day' ))]"));
		reqDate.click();
		time.click();
		submitButton.click();
	}
	
}
