package com.qa.pages;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.qa.util.TestBase;


public class HLC_Migration extends TestBase
{
	@FindBy(xpath = "//a[text() = 'Import HLC Demographic']")
	WebElement hlcImport;
	
	@FindBy(xpath = "//a[@id = 'upload_link']")
	WebElement chooseFile;
	
	@FindBy(xpath = "//input[@id = 'upload']")
	WebElement importFile;
	
	@FindBy(xpath = "//h2[@id = 'filetouploadmsg']")
	WebElement uploadMsg;
	
	@FindBy(xpath = "//a[@id = 'validateCSVFile']")
	WebElement validateButton;	
	
	@FindBy(xpath = "//span[@id = 'uploadMsgDivSucc']")
	WebElement validateSuccess;
	
	@FindBy(xpath = "//a[@id = 'fileuploadcsv']")
	WebElement uploadFile;
	
	@FindBy(xpath = "//input[@id = 'orgname']")
	WebElement userSearch;
	
	@FindBy(xpath = "//button[@id = 'search']")
	WebElement searchButton;
	
	@FindBy(xpath = "//div[@role = 'status']")
	WebElement resultCount;
	
	@FindBy(xpath = "//table[@id = 'tablelisting']//td[2]")
	WebElement searchResult;
	
	@FindBy(xpath = "//label[@for = 'isHlctoHlc']")
	WebElement checkbox;
	
	@FindBy(xpath="//input[@id='org_id']")
	WebElement orgIDtxtfiled;
	
	@FindBy(xpath="(//tr[@class='odd'])[1]//td")
	WebElement ordID;
	
	@FindBy(xpath="(//span[text()='Select profile status'])[1]")
//	@FindBy(xpath="//select[@id='profilestatus']")
	WebElement selectprostatus;
	
	@FindBy(xpath="//span[text()='Completed']")
	WebElement Completed;
	
	@FindBy(xpath = "(//table[@aria-describedby = 'tablelisting_info']//a[@data-toggle='dropdown'])[1]")
	WebElement actionDropdown;
	
	@FindBy(xpath="(//a[text()='Organization Details'])[1]")
	WebElement OrganizationDetails;
	
	@FindBy(xpath="(//a[text()='Delete'])[1]")
	WebElement Delete;
	
	@FindBy(xpath="(//a[text()='Set Hierarchy'])[1]")
	WebElement SetHierarchy;
	
	@FindBy(xpath="(//a[text()='Download LMS IDs'])[1]")
	WebElement DownloadLMSIDs;
	
	@FindBy(xpath="(//a[text()='Import LMS Ids'])[1]")
	WebElement ImportLMSIds;
	
	@FindBy(xpath="(//a[text()='Access Organization'])[1]")
	WebElement AccessOrganization;
	
	@FindBy(xpath="(//a[text()='View Hierarchy'])[1]")
	WebElement ViewHierarchy;
	
	@FindBy(xpath="(//a[@title='Download Source File'])[1]")
	WebElement DownloadSourceFile;
	
	@FindBy(xpath="//a[text() = 'Migration Logs']")
	WebElement MigrationLogs;
	
	@FindBy(xpath="(//a[@title='Download Error Log File'])[1]")
	WebElement DownloadErrorFile;
	
	String file = System.getProperty("user.dir") +"\\src\\test\\java\\resources\\hlctxtfile.txt";
	String filetemplate = System.getProperty("user.dir") +"\\src\\test\\java\\resources\\hlctxtfileTemplate"+prop.getProperty("environment")+".txt";
	
	String validatingFile = "//img[@id = 'uploadLoader' and @class = 'hide']";
	public String orgName = "",childorgName = "";

	public HLC_Migration() 
	{
		PageFactory.initElements(driver, this);
	}

	public String editFile()
	{
		String unique = "";
		try 
		{
			String data = "";
			String lastLine = "";
			FileReader FR = new FileReader(filetemplate);
			BufferedReader BR = new BufferedReader(FR);
			data = BR.readLine();
			while(data != null)
			{
				lastLine = data;
				data = BR.readLine();
			}
			lastLine = lastLine.replace("^", " ");
			String line[] = lastLine.split(" ");
			String date = new java.util.Date().toString().replace(" ", "").replace(":", "");
			orgName = "Autoorg_"+date;
			
			String email = date + "@mailinator.com";
			TestBase.prop.setProperty("orgName", orgName);
			lastLine = lastLine.replace(line[26], email);
			unique = lastLine.replace(line[0], orgName).replace(" ", "^");
			BR.close();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return unique;
	}
	public String editFileChild()
	{
		String unique = "";
		try 
		{
			String data = "";
			String lastLine = "";
			FileReader FR = new FileReader(filetemplate);
			BufferedReader BR = new BufferedReader(FR);
			data = BR.readLine();
			while(data != null)
			{
				lastLine = data;
				data = BR.readLine();
			}
			lastLine = lastLine.replace("^", " ");
			String line[] = lastLine.split(" ");
			Thread.sleep(4000);
			String date = new java.util.Date().toString().replace(" ", "").replace(":", "");
			childorgName = "Autchild_"+date;
			String email = date+"child" + "@mailinator.com";
			lastLine = lastLine.replace(line[26], email);
			unique = lastLine.replace(line[0], childorgName).replace(" ", "^");
			BR.close();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return unique;
	}
	
	public void updateFile()
	{
		try
		{
			FileReader FR = new FileReader(file);
			@SuppressWarnings("resource")
			BufferedReader BR = new BufferedReader(FR);
			String firstLine = BR.readLine();
			String lastLine = editFile();
			System.out.println(firstLine);
			System.out.println(lastLine);
			FileWriter fw = new FileWriter(file,false);
			fw.write(firstLine);
			fw.write("\n");
			fw.write(lastLine);
		
			fw.close();
		}
		catch(Exception e)
		{
			
		}
	}

	public void updateFileupdatewithparentChildorg()
	{
		try
		{
			FileReader FR = new FileReader(file);
			@SuppressWarnings("resource")
			BufferedReader BR = new BufferedReader(FR);
			String firstLine = BR.readLine();
			String lastLine = editFile();
			System.out.println(firstLine);
			System.out.println(lastLine);
			FileWriter fw = new FileWriter(file,false);
			fw.write(firstLine);
			fw.write("\n");
			fw.write(lastLine);
			fw.write("\n");
			lastLine=editFileChild();
			System.out.println(lastLine);
			fw.write(lastLine);
			fw.write("\n");
			fw.write(lastLine);
			fw.write("\n");
			fw.write("^^^^^^^^ds^^");
			fw.write("\n");
			fw.close();
		}
		catch(Exception e)
		{
			
		}
	}

	public void clickImportButton()
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(hlcImport));
		hlcImport.click();
	}

	public void selectFileToUpload()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(chooseFile));
		importFile.sendKeys(file);
	}
	

	public void validateFle()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOf(uploadMsg));
			validateButton.click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(validatingFile)));
			Assert.assertTrue(validateSuccess.isDisplayed());
		} 
		catch (Exception e) 
		{
			selectFileToUpload();
			validateFle();
		}
	}

	public void uploadFile()
	{
		try
		{
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(uploadFile));
		uploadFile.click();
		Thread.sleep(7000);
		}
		catch(Exception e)
		{
			
		}
	}

	public void searchHLC()
	{
		try
		{
		wait.until(ExpectedConditions.invisibilityOf(uploadFile));
		wait.until(ExpectedConditions.elementToBeClickable(userSearch));
		userSearch.click();
		userSearch.sendKeys(orgName);
		searchButton.click();
		Thread.sleep(5000);
		wait.until(ExpectedConditions.visibilityOf(searchResult));
		Assert.assertTrue(resultCount.getText().contains("Showing 1 to 1"));
		wait.until(ExpectedConditions.visibilityOf(searchResult));
        Assert.assertEquals(orgName, searchResult.getText());
    	}
		catch(Exception e)
		{
			
		}
	}

	public void clickOnCheckbox()
	{
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(checkbox));
		checkbox.click();
	}


	public void Multiplesearch()
	{
		try
		{
		wait.until(ExpectedConditions.invisibilityOf(uploadFile));
		wait.until(ExpectedConditions.elementToBeClickable(userSearch));
		userSearch.click();
		userSearch.sendKeys(orgName);
		searchButton.click();
		Thread.sleep(5000);
		wait.until(ExpectedConditions.visibilityOf(searchResult));
		Assert.assertTrue(resultCount.getText().contains("Showing 1 to 1"));
		wait.until(ExpectedConditions.visibilityOf(searchResult));
        Assert.assertEquals(orgName, searchResult.getText());
        
        wait.until(ExpectedConditions.visibilityOf(ordID));
        String OrganID=ordID.getText();
        System.out.println("*************"+OrganID+"*************");
        wait.until(ExpectedConditions.visibilityOf(orgIDtxtfiled));
        orgIDtxtfiled.sendKeys(OrganID);
        searchButton.click();
        Assert.assertEquals(orgName, searchResult.getText());
        
    	}
		catch(Exception e)
		{
			
		}
	}
	
	
	public void ProfileStatusSearch()
	{
		
		wait.until(ExpectedConditions.visibilityOf(selectprostatus));
//		WebElement profilestatus = driver.findElement(By.xpath("//*[@id=\"customerList\"]/div/div[4]/div/button/span[1]"));
		selectprostatus.click();
		
		Completed.click();
		
//		 Select profstat=new Select(selectprostatus);
//		 profstat.selectByVisibleText("Pending");	
		 wait.until(ExpectedConditions.visibilityOf(searchButton));
		 searchButton.click();
		 
		
	}
	
	
	
	public void PendingActionDtls()
	{
		try
		{
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOf(actionDropdown));
			actionDropdown.click();
			
			if(OrganizationDetails.isDisplayed() && 
					Delete.isDisplayed() &&
					SetHierarchy.isDisplayed() &&
					DownloadLMSIDs.isDisplayed() && 
					ImportLMSIds.isDisplayed())
			{
				System.out.println("Pending Action items are Dispalyed" + OrganizationDetails+
						Delete+	SetHierarchy+DownloadLMSIDs+ImportLMSIds);
			}else
			{
				System.out.println("Pending Action items are not Dispalyed as Expected");
			}
		
		}
		catch(Exception e)
		{	wait.until(ExpectedConditions.visibilityOf(actionDropdown));
		actionDropdown.click();
		}
	}
	
	
	
	
	
	
	public void CompletedActionDtls()
	{
		try
		{
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOf(actionDropdown));
			actionDropdown.click();
			
			if(AccessOrganization.isDisplayed() &&
					OrganizationDetails.isDisplayed() && 
					Delete.isDisplayed() &&
					ViewHierarchy.isDisplayed() &&
					DownloadLMSIDs.isDisplayed() && 
					ImportLMSIds.isDisplayed())
			{
				System.out.println("Completed Action items are Dispalyed" + OrganizationDetails+
						Delete+	SetHierarchy+DownloadLMSIDs+ImportLMSIds);
			}else
			{
				System.out.println("Pending Action items are not Dispalyed as Expected");
			}
		
		}
		catch(Exception e)
		{	wait.until(ExpectedConditions.visibilityOf(actionDropdown));
		actionDropdown.click();
		}
	}
	
	
	
	
	
}
