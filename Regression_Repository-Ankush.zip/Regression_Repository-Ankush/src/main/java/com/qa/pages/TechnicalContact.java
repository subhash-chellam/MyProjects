package com.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.util.TestBase;

public class TechnicalContact extends TestBase
{
	@FindBy(xpath = "//a[text() = 'Technical Contacts']")
	WebElement contactTab;
	
	@FindBy(xpath = "//a[text() = 'Add Technical Contacts']")
	WebElement addContactButton;
	
	@FindBy(xpath = "//input[@name = 'firstname[]']")
	WebElement contactFirstName;
	
	@FindBy(xpath = "//input[@name = 'lastname[]']")
	WebElement contactlastName;
	
	@FindBy(xpath = "//input[@name = 'email[]']")
	WebElement contactEmail;
	
	@FindBy(xpath = "//button[@type = 'submit' and @name ='add']")
	WebElement addContact;
	
	@FindBy(xpath = "//a[@title = 'Edit Technical Contact']")
	WebElement editContactButton;
	
	@FindBy(xpath = "//input[@name = 'first_name']")
	WebElement editFirstName;
	
	@FindBy(xpath = "//input[@name = 'last_name']")
	WebElement editLastName;
	
	@FindBy(xpath = "//input[@name = 'email']")
	WebElement editEmail;
	
	@FindBy(xpath = "//input[@id = 'submitBtn']")
	WebElement editSubmit;
	
	@FindBy(xpath = "//a[@title = 'Delete Technical Contacts']")
	WebElement deleteContactButton;
	
	@FindBy(xpath = "//a[text() = 'Delete']")
	WebElement deleteConfirmButton;
	
	@FindBy(xpath = "//td[text() = 'No records are available']")
	WebElement noRecordFound;
	
	public TechnicalContact()
	{
		PageFactory.initElements(driver, this);
	}

	public void navigateToTechnicalContactsTab()
	{
		wait.until(ExpectedConditions.visibilityOf(contactTab));
		contactTab.click();
	}

	public void clickOnAddTechnicalContactsButton()
	{
		wait.until(ExpectedConditions.visibilityOf(addContactButton));
		addContactButton.click();
	}

	public void enterContactDetails()
	{
		wait.until(ExpectedConditions.visibilityOf(contactFirstName));
		String fName = "fname";
		String lName = "lname";
		contactFirstName.sendKeys(fName);
		contactlastName.sendKeys(lName);
		String email = fName + "." + lName + prop.getProperty("userDomain");
		contactEmail.sendKeys(email);
		addContact.click();
	}

	public void editTechnicalContact()
	{
		wait.until(ExpectedConditions.visibilityOf(editContactButton));
		editContactButton.click();
		wait.until(ExpectedConditions.visibilityOf(editFirstName));
		String name = editFirstName.getAttribute("value");
		editFirstName.click();
		editFirstName.clear();
		editFirstName.sendKeys(name + "_update");
		editSubmit.click();
	}

	public void deleteTechnicalContact()
	{
		wait.until(ExpectedConditions.visibilityOf(editContactButton));
		deleteContactButton.click();
		wait.until(ExpectedConditions.visibilityOf(deleteConfirmButton));
		deleteConfirmButton.click();
	}

	public void confirmNoRecord()
	{
		wait.until(ExpectedConditions.visibilityOf(noRecordFound));
		noRecordFound.click();
	}


}
