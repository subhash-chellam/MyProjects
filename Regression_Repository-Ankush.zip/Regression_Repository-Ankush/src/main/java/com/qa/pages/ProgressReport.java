package com.qa.pages;

import java.io.File;
import java.io.FileReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.python.modules.thread.thread;
import org.python.netty.util.internal.SystemPropertyUtil;

import com.opencsv.CSVReader;
import com.qa.util.TestBase;

import io.cucumber.datatable.DataTable;

public class ProgressReport extends TestBase
{
	public	static List<String> allassignmentoptions1 = new ArrayList<String>();
	@FindBy(xpath = "//a[contains(text(), 'Reports')]")
	WebElement reportLink;



	@FindBy(xpath = "//*[@id=\"exportbtn\"]")
	WebElement exportBtn;
	@FindBy(xpath = "//label[text() = 'Rows per page ']//select")
	WebElement rowPerPageSelect;

	@FindBy(xpath = "//*[@id='test_date']")
	WebElement test_date;

	
	
	@FindBy(xpath = "//a[contains(text(), 'Progress Report')]")
	WebElement progressReportLink;

	@FindBy(xpath = "//body")
	WebElement pageLoad;

	@FindBy(xpath = "//div[@id = 'progress_report_info']")
	WebElement reportTable;

	@FindBy(xpath="//h1[contains(text(),'Progress Report')]")
	WebElement Reportheader;



	@FindBy(xpath="//*[@id=\"reports\"]/tbody/tr/td[10]/a")
	WebElement ecardDownload;



	@FindBy(xpath="//div[2]/a")
	WebElement viewecard;

	@FindBy(xpath="(//div[@class=\"dataTables_info\"])[1]")
	WebElement Paginationinfoup;

	@FindBy(xpath="(//div[@class=\"dataTables_info\"])[2]")
	WebElement Paginationinfobottom;

	@FindBy(xpath="//div[@id='progress_report_length']//label")
	WebElement rowsperpageheader;

	@FindBy(xpath="//div[@id='progress_report_length']//label//select//option")
	WebElement rowsperpagevalues;

	@FindBy(xpath="//a[contains(text(),'Curriculum Filters')]")
	WebElement curriculumfilterslink;

	@FindBy(xpath="//div[@id='ms-list-7']//button")
	WebElement curriculamstatusdropdownCTC;

	@FindBy(xpath="//select[@id='curriculam_status']/following-sibling::div//button")
	WebElement curriculamstatusdropdownLMS;

	@FindBy(xpath="//div[@id='ms-list-7']//div//ul//li//label")
	List<WebElement> curriculamstatusdropdownvaluesCTC;

	@FindBy(xpath="//select[@id='curriculam_status']/following-sibling::div/div//ul//li//label")
	List<WebElement> curriculamstatusdropdownvaluesLMS;

	@FindBy(xpath="//a[contains(text(),'More Filters')]")
	WebElement morefilterslink;

	@FindBy(xpath="//select[@id='statusFilter']/following-sibling::div//button")
	WebElement userstatusfiltersdropdown;

	@FindBy(xpath="//select[@id='statusFilter']/following-sibling::div//ul//li//label")
	List<WebElement> userstatusdropdownvalues;

	@FindBy(xpath="(//li[@class='default selected'])[2]")
	WebElement activedefaultselected;

	@FindBy(xpath="(//select[@id='statusFilter']/following-sibling::div//ul//li//label)[2]")
	WebElement inactiveelement;

	@FindBy(xpath="(//li[@class='selected'])[2]")
	WebElement inactiveselected;

	@FindBy(xpath="//select[@id='assignments']/following-sibling::div//button")
	WebElement Assignmentdropdown;

	@FindBy(xpath="//select[@id='statusFilter']/following-sibling::div//ul//li//label")
	List<WebElement> userstatuscolumnvalues;

	@FindBy(xpath="(//a[contains(text(),'Unselect all')])[4]")
	WebElement UnselectAllAssignmentdropdown;

	@FindBy(xpath="//table[@id='progress_report']//tbody//tr[*]//td[5]")
	List<WebElement> allassignmentvalues;


	@FindBy(xpath="(//div[@id='progress_report_wrapper']//div[@class=\"DTFC_ScrollWrapper\"]//div[@class=\"DTFC_LeftWrapper\"]//div[@class=\"DTFC_LeftBodyWrapper\"]//div//table//tbody//tr[@class=\"cursor odd\"])[1]")
	WebElement handiconoddfirst;
	@FindBy(xpath="//div[@id='overLayBlock']//th")
	List<WebElement> coursedetailsheaders;

	@FindBy(xpath="//div[@id='overLayBlock']//div//div//a")
	WebElement closeiconwithinpopup;

	@FindBy(xpath="//div[@id='overLayBlock']//tbody//tr[1]//td")
	List<WebElement> coursedetailsdata;

	@FindBy(xpath="(//button[contains(text(),'Search')])[3]")
	WebElement Searchbutton;

	//button[contains(text(),'Search')])[1]
	@FindBy(xpath="(//button[contains(text(),'Search')])[1]")
	WebElement Searchbtn;

	@FindBy(xpath="//select[@id='courses']/following-sibling::div//button")
	WebElement Curriculumnamedropdown;
	@FindBy(xpath="(//a[contains(text(),'Unselect all')])[3]")
	WebElement UnselectAllcurriculumnamedropdown;

	@FindBy(xpath="//input[@id='from_available_date'][@placeholder=\"From\"]")
	WebElement Availabledatefrom;
	@FindBy(xpath="//input[@id='to_available_date'][@placeholder=\"To Date\"]")
	WebElement AvailabledateTo;
	@FindBy(xpath="//input[@id='from_launched_date'][@placeholder=\"From\"]")
	WebElement LaunchedDatefrom;
	@FindBy(xpath="//input[@id='to_launched_date'][@placeholder=\"To Date\"]")
	WebElement LaunchedDateTo;	
	@FindBy(xpath="//input[@id='from_available_date'][@placeholder=\"From\"]")
	WebElement fromDuedate;
	@FindBy(xpath="//input[@id='to_available_date'][@placeholder=\"To Date\"]")
	WebElement ToDuedate;
	@FindBy(xpath="//input[@id='to_completed_date'][@placeholder=\"To Date\"]")
	WebElement ToCompletedDate;

	@FindBy(xpath = "//table[@id = 'progress_report']/tbody/tr[1]")
	WebElement progressTableFirstRow;

	@FindBy(xpath = "//label[@id='inputSearch']")
	WebElement searchTextBox;

	@FindBy(xpath = "//*[text() = 'Showing 1 to 1 of 1 entries']")
	WebElement progressReportSearchResult;

	@FindBy(xpath = "//label[@class and text() = 'Search for Name, Email or User ID']")
	WebElement userSearchLabel;

	@FindBy(xpath = "//input[@id = 'searchbox_name_email']")
	WebElement userSearchInput;

	@FindBy(xpath = "//label[text() = 'Organization Level']")
	WebElement orgLevelLabel;

	@FindBy(xpath = "//select[@id = 'orgLevel']")
	WebElement orgLevelDropdown;

	@FindBy(xpath = "//a[text() = 'More Filters  ']")
	WebElement moreFilter;

	@FindBy(xpath = "//label[text() = 'Job Title']")
	WebElement jobTitleLabel;

	@FindBy(xpath = "//select[@id = 'job_title_id']")
	WebElement jobTitleDropdown;

	@FindBy(xpath = "//label[text() = 'Group']")
	WebElement groupLabel;

	@FindBy(xpath = "//select[@id = 'group_id']")
	WebElement groupDropdown;

	@FindBy(xpath = "//label[contains(text(), 'User Status')]")
	WebElement userStatusLabel;

	@FindBy(xpath = "//select[@id = 'statusFilter']")
	WebElement userStatusDropdown;

	@FindBy(xpath = "//a[text() = 'Curriculum Filters  ']")
	WebElement curriculumFilter;
	@FindBy(xpath = "//label[contains(text(), 'Available Date')]")
	WebElement avaialbleDateLabel;

	@FindBy(xpath = "//input[@id = 'from_available_date']")
	WebElement avaialbleDateFromInput;

	@FindBy(xpath = "//input[@id = 'to_available_date']")
	WebElement avaialbleDateToInput;

	@FindBy(xpath = "//label[contains(text(), 'Completed Date')]")
	WebElement completedDateLabel;

	@FindBy(xpath = "//input[@id = 'from_completed_date']")
	WebElement completedDateFromInput;

	@FindBy(xpath = "//input[@id = 'to_completed_date']")
	WebElement completedDateToInput;

	@FindBy(xpath = "//input[@type='search']")
	WebElement searchinputText;

	@FindBy(xpath = "//button[@id= 'searchbtn']")
	WebElement searchButton;

	@FindBy(xpath = "//a[@class = 'closebtn']/span")
	WebElement closeHeaderPopup;

	@FindBy(xpath = "//table[@id = 'progress_report']/tbody//td[15]")
	WebElement searchResultStudentEmail;
	@FindBy(xpath = "//table[@id = 'progress_report']/tbody//td[2]")
	WebElement searchResultUserId;

	String pagination = "(//div[@class = 'dataTables_paginate paging_simple_numbers'])";
	String table = "//table[@id = 'progress_report']/tbody/tr";	
	//input[@id='from_due_date'][@placeholder="From"]
	//input[@id='to_due_date'][@placeholder="To Date"]
	//input[@id='from_completed_date'][@placeholder="From"]
	//input[@id='to_completed_date'][@placeholder="To Date"]
	String activityList_table = "//table[@id = 'course_activity_listing']/tbody/tr";
	@FindBy(xpath = "//select[@id = 'statusFilter']//following-sibling::div/button")
	WebElement userStatusFilter;

	@FindBy(xpath = "//select[@id = 'statusFilter']//following-sibling::div//a")
	WebElement userSelectAll;

	@FindBy(xpath = "//label[contains(text(), 'Launched Date')]")
	WebElement launchedDateLabel;

	@FindBy(xpath = "//input[@id = 'from_launched_date']")
	WebElement launchedDateFromInput;

	@FindBy(xpath = "//input[@id = 'to_launched_date']")
	WebElement launchedDateToInput;

	@FindBy(xpath = "//label[text() = 'Curriculum Name']")
	WebElement curriculumNameLabel;

	@FindBy(xpath = "//select[@id = 'courses']")
	WebElement curriculumNameDropdown;

	@FindBy(xpath = "//div[@id = 'filter_due_date']/label")
	WebElement dueDateLabel;

	@FindBy(xpath = "//label[contains(text(), 'Curriculum Status')]")
	WebElement curriculumStatusLabel;

	@FindBy(xpath = "//select[@id = 'curriculam_status']")
	WebElement curriculumStatusDropdown;

	@FindBy(xpath = "//label[contains(text(), 'Assignment Name')]")
	WebElement assignmentStatusLabel;

	@FindBy(xpath = "//select[@id = 'assignments']")
	WebElement assignmentStatusDropdown;

	@FindBy(xpath = "//label[contains(text(), 'Assignment Name')]/following-sibling::div/button")
	WebElement assignmentStatusButton;

	@FindBy(xpath = "//label[contains(text(), 'Assignment Name')]/following-sibling::div//div[@class = 'ms-search']/input")
	WebElement assignmentStatusSearch;

	@FindBy(xpath = "(//label[contains(text(), 'Assignment Name')]/following-sibling::div//ul//input)[1]")
	WebElement assignmentStatusInput;
	By assignmentStatusFilter = By.xpath("//label[contains(text(), 'Assignment Name')]");

	public static String activityList[];
	String val;
	String tableRow = "//table[@id = 'progress_report']/tbody/tr[1]/td";
	String tableHeader = "(//table[@aria-describedby = 'progress_report_info'])[1]//th";
	String userStatusSelected = "(//label[contains(text(), 'User Status')]/following-sibling::div//ul//input)[1]";
	String curriculumStatusDropdownOption = "//label[contains(text(), 'Curriculum Status')]/following-sibling::div//li//label/input";
	String activityHeader = "(//table[@id = 'course_activity_listing'])[1]//th";
	String courselist="//div[@id='overLayBlock']//tbody";
	public ProgressReport() 
	{
		PageFactory.initElements(driver, this);
	}
	JavascriptExecutor js = (JavascriptExecutor)driver;

	public void clickOnReportLink()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;


		wait.until(ExpectedConditions.visibilityOf(reportLink));
		wait.until(ExpectedConditions.elementToBeClickable(reportLink));
		try {
			val = pageLoad.getAttribute("class");
			int m=0;
			while(val.contains("loading") || val.contains("loading_user") )
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			js.executeScript("arguments[0].scrollIntoView();",reportLink);

			reportLink.click();
		}
		catch (Exception e) 
		{
			js.executeScript("arguments[0].scrollIntoView();",reportLink);

			reportLink.click();
		}

	}
	public void compareTopicList()
	{
		System.out.println(Scrom.courseTopic);
		System.out.println(activityList);
		Assert.assertTrue(Arrays.equals(Scrom.courseTopic, activityList));

	}

	public void compareTopicListForCTC()
	{
		Assert.assertTrue(Arrays.equals(EndUser.courseTopic, activityList));

	}

	public void buttonExportBtn()
	{
		wait.until(ExpectedConditions.visibilityOf(reportLink));

		try {
			Thread.sleep(15000);
			exportBtn.click();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			System.out.println("Export is disabled ");;
		}


	}
	public void buttonExportBttn()
	{
		wait.until(ExpectedConditions.visibilityOf(reportLink));

		try {
			Thread.sleep(15000);
			exportBtn.click();
			Assert.fail("Export not disabled ");
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			System.out.println("Export is disabled ");;
		}


	}
	public void validatePaginationDropdown()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(rowPerPageSelect));
		Select select = new Select(rowPerPageSelect);
		List<WebElement> values = select.getOptions();
		for(int i = 0; i <= values.size() - 1; i++)
		{
			int value = Integer.parseInt(values.get(i).getText());
			System.out.print(value);
			Assert.assertTrue(value%25 == 0);
		}
	}

	public void getActivityCompletedDateAsCurrentDate()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(activityList_table))));
		List<WebElement> count = driver.findElements(By.xpath(activityList_table));
		Boolean flag=false;
		activityList = new String[count.size()];
		String date = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
		for(int i = 1; i <= count.size(); i++)
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(activityList_table + "[" + i + "]/td[6]"))));
			String text = driver.findElement(By.xpath(activityList_table + "[" + i + "]/td[5]")).getText();
			flag=true;
			Assert.assertTrue(text.equalsIgnoreCase(date));
		}
		if(flag == false)
			Assert.fail("Course Name not found");
	}
	
	public void getActivityStartDateAsCurrentDate()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(activityList_table))));
		Boolean flag=false;
		
		List<WebElement> count = driver.findElements(By.xpath(activityList_table));
		activityList = new String[count.size()];
		String date = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
		for(int i = 1; i <= count.size(); i++)
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(activityList_table + "[" + i + "]/td[6]"))));
			String text = driver.findElement(By.xpath(activityList_table + "[" + i + "]/td[3]")).getText();
		System.out.println();
			Assert.assertTrue(text.equalsIgnoreCase(date));
			flag=true;
			
		}
		if(flag == false)
			Assert.fail("Course Name not found");
	}
	public void OpenActivityPopUpWithNameForLMS(String courseName)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		if(courseListName.containsKey(courseName))
			courseName=courseListName.get(courseName).toString();

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[5]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().equals(courseText.toLowerCase().trim()))
			{
				String userID = driver.findElement(By.xpath(table + "[" + i + "]/td[2]")).getText().trim().toLowerCase();
				String lastName = driver.findElement(By.xpath(table + "[" + i + "]/td[3]")).getText().trim().toLowerCase();
				String firstName = driver.findElement(By.xpath(table + "[" + i + "]/td[4]")).getText().trim().toLowerCase();
				String courseNameText = driver.findElement(By.xpath(table + "[" + i + "]/td[5]")).getText().trim().toLowerCase();
				String popupTilteExpected = firstName + " " + lastName + " (" + userID + ")" + " - " + courseNameText;
				System.out.println(popupTilteExpected);
				try
				{
					if(driver.findElement(By.xpath(table + "[" + i + "]/td[6]/span")).isDisplayed())
						driver.findElement(By.xpath(table + "[" + i + "]/td[6]/span")).click();
				}
				catch (Exception e) 
				{
					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table + "[" + i + "]/td[7]/span"))));
					driver.findElement(By.xpath(table + "[" + i + "]/td[7]/span")).click();
				}
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//h4"))));
				String popupTilteActual = driver.findElement(By.xpath("//h4")).getText().trim();
				Assert.assertTrue(popupTilteExpected.equalsIgnoreCase(popupTilteActual.trim().toLowerCase()));
			}	else if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String userID = driver.findElement(By.xpath(table + "[" + i + "]/td[2]")).getText().trim().toLowerCase();
				String lastName = driver.findElement(By.xpath(table + "[" + i + "]/td[3]")).getText().trim().toLowerCase();
				String firstName = driver.findElement(By.xpath(table + "[" + i + "]/td[4]")).getText().trim().toLowerCase();
				String courseNameText = driver.findElement(By.xpath(table + "[" + i + "]/td[5]")).getText().trim().toLowerCase();
				String popupTilteExpected = firstName + " " + lastName + " (" + userID + ")" + " - " + courseNameText;
				System.out.println(popupTilteExpected);
				try
				{
					if(driver.findElement(By.xpath(table + "[" + i + "]/td[6]/span")).isDisplayed())
						driver.findElement(By.xpath(table + "[" + i + "]/td[6]/span")).click();
				}
				catch (Exception e) 
				{
					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table + "[" + i + "]/td[7]/span"))));
					driver.findElement(By.xpath(table + "[" + i + "]/td[7]/span")).click();
				}
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//h4"))));
				String popupTilteActual = driver.findElement(By.xpath("//h4")).getText().trim();
				Assert.assertTrue(popupTilteExpected.equalsIgnoreCase(popupTilteActual.trim().toLowerCase()));
			}			
		}	
	}

	public void getActivityStatusComplete()
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courselist))));

		int rowCount=0;
		int cont=0;
		while(rowCount==1)
		{
			List<WebElement> tableRows = driver.findElements(By.xpath(courselist));
			rowCount = tableRows.size();
			if(cont==120)
				break;

			cont++;
		}

		List<WebElement> allactivitydata = coursedetailsdata;
		List<String> coursedetailsdata1 = new ArrayList<String>();
		for( WebElement option : allactivitydata){
			String add1 = option.getText();
			coursedetailsdata1.add(add1.trim());
		}
		Assert.assertTrue("Course status is not complete",coursedetailsdata1.get(1).contains("Completed"));

	}

	public void getActivityStartDate(int quarterDate)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(activityList_table))));
		Boolean flag = false;
		List<WebElement> count = driver.findElements(By.xpath(activityList_table));
		activityList = new String[count.size()];
		for(int i = 1; i <= count.size(); i++)
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(activityList_table + "[" + i + "]/td[6]"))));
			String text = driver.findElement(By.xpath(activityList_table + "[" + i + "]/td[3]")).getText();
			String date = changeDate(quarterDate);
			Assert.assertTrue(text.equalsIgnoreCase(date));
			flag = true;
		
		}
		
		if(flag == false)
			Assert.fail("Course Name not found");
	}
	public void getActivityCompletedDate(int quarterDate)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(activityList_table))));
		List<WebElement> count = driver.findElements(By.xpath(activityList_table));
		activityList = new String[count.size()];
		for(int i = 1; i <= count.size(); i++)
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(activityList_table + "[" + i + "]/td[5]"))));
			String text = driver.findElement(By.xpath(activityList_table + "[" + i + "]/td[5]")).getText();
			String date = changeDate(quarterDate);
			Assert.assertTrue(text.equalsIgnoreCase(date));
		}
	}
	public void validateAvailableWithCourseNameAsQuarterForLMS(String courseName, int quarterDate)
	{
		if(courseListName.containsKey(courseName))
			courseName=courseListName.get(courseName).toString();

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[5]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().equals(courseText.toLowerCase().trim()))
			{
				String avaialableDate = table + "[" + i + "]/td[7]";
				String avaialableDateText = driver.findElement(By.xpath(avaialableDate)).getText();
				System.out.println(avaialableDateText);
				String date = firstDayAsperQuarter(quarterDate);
				Assert.assertTrue(avaialableDateText.equalsIgnoreCase(date));
				flag = true;
				break;
			}
			else if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String avaialableDate = table + "[" + i + "]/td[7]";
				String avaialableDateText = driver.findElement(By.xpath(avaialableDate)).getText();
				System.out.println(avaialableDateText);
				String date = firstDayAsperQuarter(quarterDate);
				Assert.assertTrue(avaialableDateText.equalsIgnoreCase(date));
				flag = true;
				break;
			}
		}	
		if(flag == false)
			Assert.fail("Course Name not found");
	}
	public void validateCurriculumStatusAsPerNameForLMS(String status,String courseName)
	{

		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		if(courseListName.containsKey(courseName))
			courseName=courseListName.get(courseName).toString();

		courseName=courseName.replace("Â","");

		JavascriptExecutor js = (JavascriptExecutor)driver;
		val = js.executeScript("return document.readyState").toString();
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
		}

		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[5]";
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(course))));

			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().equals(courseText.toLowerCase().trim()))
			{
				String statusVal = table + "[" + i + "]/td[6]/span";
				String statusValText = driver.findElement(By.xpath(statusVal)).getText();
				System.out.println(statusValText);
				Assert.assertTrue(statusValText.equalsIgnoreCase(status));
				flag = true;
				break;
			}
			else if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String statusVal = table + "[" + i + "]/td[6]/span";
				String statusValText = driver.findElement(By.xpath(statusVal)).getText();
				System.out.println(statusValText);
				Assert.assertTrue(statusValText.equalsIgnoreCase(status));
				flag = true;
				break;
			}
		}	
		if(flag == false)
			Assert.fail("Course Name not found");
	}

	public void scrollLeft()
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
		executor.executeScript("arguments[0].scrollLeft = -arguments[0].offsetWidth", scrollArea);
	}
	public void validateCurriculumStatusAsPerName(String status,String courseName)
	{	int m=0;
	try
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		if(courseListName.containsKey(courseName))
			courseName=courseListName.get(courseName).toString();



		courseName=courseName.replace("Â","");


		val = pageLoad.getAttribute("class");

		while(val.contains("loading") || val.contains("loading_user") )
		{
			val = pageLoad.getAttribute("class");
			try
			{
				String curriculum = reportTable + "[1]/td[4]";

				String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();

				wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(table))));


			}
			catch(Exception e)
			{

			}
			if(m==pagload)
				break;
			m++;
		}
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));

		int rowCount=0;
		int cont=0;
		while(rowCount==0)
		{
			List<WebElement> tableRows = driver.findElements(By.xpath(table));
			rowCount = tableRows.size();
			if(cont==150)
				break;

			cont++;
		}
		System.out.println("rowCount "+rowCount);
		System.out.println("courseName "+courseName);

		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[6]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			System.out.println("courseText "+courseText);

			if(courseName.trim().toLowerCase().equals(courseText.toLowerCase().trim()))
			{
				String statusVal = table + "[" + i + "]/td[7]/span";
				String statusValText = driver.findElement(By.xpath(statusVal)).getText();
				System.out.println(statusValText);
				Assert.assertTrue(statusValText.equalsIgnoreCase(status));
				flag = true;
				break;
			}else if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String statusVal = table + "[" + i + "]/td[7]/span";
				String statusValText = driver.findElement(By.xpath(statusVal)).getText();
				System.out.println(statusValText);
				Assert.assertTrue(statusValText.equalsIgnoreCase(status));
				flag = true;
				break;
			}
		}	
		if(flag == false)
			Assert.fail("Course Name not found");

	}
	catch(StaleElementReferenceException e)
	{
		m=0;
		validateCurriculumStatusAsPerName(status,courseName);
	}
	catch(NoSuchElementException e)
	{
		Assert.fail("Report is not loading");

	}		
	catch(Exception e)
	{
		Assert.fail("Issue in Application");

	}
	}

	public void validateCurriculumStatusForLMS(String status)
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		val = js.executeScript("return document.readyState").toString();
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
		}
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(reportTable));
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableRow + "[6]/span"))));
		String data = driver.findElement(By.xpath(tableRow + "[6]/span")).getText().trim().toLowerCase();
		System.out.println(data);
		Assert.assertTrue(data.equalsIgnoreCase(status.trim().toLowerCase()));
	}


	public String firstDayAsperQuarter(int quarter)
	{

		LocalDate localDate = LocalDate.now();
		LocalDate firstDayOfQuarter = localDate.with(localDate.getMonth().firstMonthOfQuarter()).with(TemporalAdjusters.firstDayOfMonth());
		LocalDate lastDayOfQuarter;
		lastDayOfQuarter = firstDayOfQuarter.plusMonths(quarter*3).with(TemporalAdjusters.firstDayOfMonth());
		String formattedDate = lastDayOfQuarter.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
		System.out.println(formattedDate);
		return formattedDate;
	}
	public void validateAvailableWithCourseName(String courseName, int quarterDate)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		if(courseListName.containsKey(courseName))
			courseName=courseListName.get(courseName).toString();

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[6]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().equals(courseText.toLowerCase().trim()))
			{
				String avaialableDate = table + "[" + i + "]/td[8]";
				String avaialableDateText = driver.findElement(By.xpath(avaialableDate)).getText();
				System.out.println(avaialableDateText);
				String date = firstDayAsperQuarter(quarterDate);
				Assert.assertTrue(avaialableDateText.equalsIgnoreCase(date));
				flag = true;
				break;
			}else if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String avaialableDate = table + "[" + i + "]/td[8]";
				String avaialableDateText = driver.findElement(By.xpath(avaialableDate)).getText();
				System.out.println(avaialableDateText);
				String date = firstDayAsperQuarter(quarterDate);
				Assert.assertTrue(avaialableDateText.equalsIgnoreCase(date));
				flag = true;
				break;
			}
		}	
		if(flag == false)
			Assert.fail("Course Name not found");
	}
	public void validateActivityPopupDisplay()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		val = js.executeScript("return document.readyState").toString();
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
		}
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(reportTable));
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableRow + "[2]"))));
		String userID = driver.findElement(By.xpath(tableRow + "[2]")).getText().trim().toLowerCase();
		System.out.println(userID);
		String lastName = driver.findElement(By.xpath(tableRow + "[3]")).getText().trim().toLowerCase();
		System.out.println(lastName);
		String firstName = driver.findElement(By.xpath(tableRow + "[4]")).getText().trim().toLowerCase();
		System.out.println(firstName);
		String courseName = driver.findElement(By.xpath(tableRow + "[5]")).getText().trim().toLowerCase();
		System.out.println(courseName);
		String popupTilteExpected = firstName + " " + lastName + " (" + userID + ")" + " - " + courseName;
		System.out.println(popupTilteExpected);
		try
		{
			if(driver.findElement(By.xpath(tableRow + "[6]/span")).isDisplayed())
				driver.findElement(By.xpath(tableRow + "[6]/span")).click();
		}
		catch (Exception e) 
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableRow + "[7]/span"))));
			driver.findElement(By.xpath(tableRow + "[7]/span")).click();
		}
		//*[@id="progress_report_wrapper"]/div[3]/div[3]/div[2]/div/table/tbody/tr/td[1]
		//*[@id="progress_report"]/tbody/tr/td[6]/span
		//		WebElement table=driver.findElement(By.xpath(tableRow + "[7]/span"));
		//		js.executeScript("arguments[0].click();",table );
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//h4"))));
		String popupTilteActual = driver.findElement(By.xpath("//h4")).getText().trim();
		Assert.assertTrue(popupTilteExpected.equalsIgnoreCase(popupTilteActual.trim().toLowerCase()));
	}
	public void getTopicList()
	{
		try
		{
			Thread.sleep(5000);	
		}
		catch(Exception e)
		{

		}
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(activityList_table))));
		List<WebElement> count = driver.findElements(By.xpath(activityList_table));
		activityList = new String[count.size()];
		for(int i = 1; i <= count.size(); i++)
		{
			String text = driver.findElement(By.xpath(activityList_table + "[" + i + "]/td[1]")).getText();
			System.out.println(text);
			activityList[i-1] = text;
		}
	}
	public void validateNoReportGenerated()
	{
		WebDriverWait wait = new WebDriverWait(driver, 60);
		//		wait.until(ExpectedConditions.visibilityOf(progressReportLink));
		//		progressReportLink.click();
		js.executeScript("arguments[0].click();", progressReportLink);
		val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading"))
		{
			val = pageLoad.getAttribute("class");
		}
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
		}
		wait.until(ExpectedConditions.visibilityOf(progressTableFirstRow));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tableRow)));
		List<WebElement> columnList = driver.findElements(By.xpath(tableRow));
		System.out.println("No of column available are: " + columnList.size());
		if(columnList.size()>1)
		{
			Assert.fail("Progress report generated");
		}		
	}


	public void userSearchWithoutClearVsimCourse(String searchText)
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		try 
		{
			Thread.sleep(5000);
			WebDriverWait wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.visibilityOf(searchTextBox));
			wait.until(ExpectedConditions.elementToBeClickable(searchTextBox));
			System.out.println("Search text is " + searchText);
			executor.executeScript("arguments[0].click();", searchTextBox);
			wait.until(ExpectedConditions.elementToBeClickable(searchinputText));
			searchinputText.sendKeys(searchText);
			executor.executeScript("arguments[0].click();", searchButton);
			String val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}
			System.out.println(val);
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOf(progressTableFirstRow));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tableRow)));
			List<WebElement> columnList = driver.findElements(By.xpath(tableRow));
			System.out.println("column visbile are " + columnList.size());
			while(columnList.size() > 1)
			{
				Thread.sleep(5000);
				columnList = driver.findElements(By.xpath(tableRow));
				System.out.println("waiting for columnList to display");
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	public void studentSearch(String searchText)
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		try {
			String result;
			wait.until(ExpectedConditions.visibilityOf(searchClear));
			wait.until(ExpectedConditions.elementToBeClickable(searchClear));
			searchClear.click();

			wait.until(ExpectedConditions.visibilityOf(searchTextBox));
			wait.until(ExpectedConditions.elementToBeClickable(searchTextBox));
			System.out.println("Search text is " + searchText);
			wait.until(ExpectedConditions.visibilityOf(searchClear));
			wait.until(ExpectedConditions.elementToBeClickable(searchClear));
			searchClear.click();


			executor.executeScript("arguments[0].click();", searchTextBox);
			wait.until(ExpectedConditions.elementToBeClickable(searchinputText));
			int rowCount=0;
			int cont=0;
			while(rowCount>=1)
			{
				List<WebElement> tableRows = driver.findElements(By.xpath(table));
				rowCount = tableRows.size();
				if(cont==150)
					break;

				cont++;
			}
			searchinputText.sendKeys(searchText);
			executor.executeScript("arguments[0].click();", searchButton);
			wait.until(ExpectedConditions.visibilityOf(progressReportSearchResult));
			String val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}
			System.out.println(val);
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOf(progressTableFirstRow));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tableRow)));
			List<WebElement> columnList = driver.findElements(By.xpath(tableRow));
			System.out.println("column visbile are " + columnList.size());
			while(columnList.size() < 15)
			{
				Thread.sleep(5000);
				columnList = driver.findElements(By.xpath(tableRow));
				System.out.println("waiting for columnList to display testtt" +columnList.size());
				if(columnList.size()==15)
					break;
			}
			if(searchText.toLowerCase().contains(prop.getProperty("userDomain")))
			{
				try {
					Thread.sleep(5000);
					WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
					js.executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", scrollArea);

				}
				catch (Exception e) 
				{
					WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
					js.executeScript("arguments[0].scrollRight = arguments[0].offsetWidth", scrollArea);

				}
				//wait.until(ExpectedConditions.visibilityOf(searchResultStudentEmail));
				result = searchResultStudentEmail.getText();
			}
			else 
			{
				wait.until(ExpectedConditions.visibilityOf(searchResultUserId));
				result = searchResultUserId.getText();
			}


			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			driver.manage().timeouts().implicitlyWait(14, TimeUnit.SECONDS);
			Thread.sleep(15000);

			int usercount=0;
			cont=0;
			while(rowCount!=usercount)
			{
				try
				{
					List<WebElement> tableRows = driver.findElements(By.xpath(table));
					usercount = tableRows.size();
				}
				catch(Exception e)
				{

				}
				if(cont==150)
					break;

				cont++;
			}
			//		Assert.assertEquals(searchText, result);
		}
		catch(Exception e)
		{

		}
	}
	public void studentSearchLMSWithoutClear(String searchText)
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		try {
			String result;
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchTextBox));
			wait.until(ExpectedConditions.elementToBeClickable(searchTextBox));
			System.out.println("Search text is " + searchText);

			executor.executeScript("arguments[0].click();", searchTextBox);
			wait.until(ExpectedConditions.elementToBeClickable(searchinputText));
			int rowCount=0;
			int cont=0;
			while(rowCount>=1)
			{
				List<WebElement> tableRows = driver.findElements(By.xpath(table));
				rowCount = tableRows.size();
				if(cont==150)
					break;

				cont++;
			}
			searchinputText.sendKeys(searchText);
			executor.executeScript("arguments[0].click();", searchButton);
			wait.until(ExpectedConditions.visibilityOf(progressReportSearchResult));
			String val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}
			executor.executeScript("arguments[0].click();", searchButton);
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}

			System.out.println(val);
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOf(progressTableFirstRow));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tableRow)));
			List<WebElement> columnList = driver.findElements(By.xpath(tableRow));
			System.out.println("column visbile are " + columnList.size());
			while(columnList.size() < 15)
			{
				Thread.sleep(5000);
				columnList = driver.findElements(By.xpath(tableRow));
				System.out.println("waiting for columnList to display testtt" +columnList.size());
				if(columnList.size()==15)
					break;
			}
			if(searchText.toLowerCase().contains( prop.getProperty("userDomain")))
			{
				try {
					Thread.sleep(5000);
					WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));

					js.executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", scrollArea);

				}
				catch (Exception e) 
				{
					//				WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
					//				js.executeScript("arguments[0].scrollRight = arguments[0].offsetWidth", scrollArea);

				}
				//wait.until(ExpectedConditions.visibilityOf(searchResultStudentEmail));
				result = searchResultStudentEmail.getText();
			}
			else 
			{
				wait.until(ExpectedConditions.visibilityOf(searchResultUserId));
				result = searchResultUserId.getText();
			}


			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			driver.manage().timeouts().implicitlyWait(14, TimeUnit.SECONDS);
			Thread.sleep(15000);

			int usercount=0;
			cont=0;
			while(rowCount!=usercount)
			{
				try
				{
					List<WebElement> tableRows = driver.findElements(By.xpath(table));
					usercount = tableRows.size();
				}
				catch(Exception e)
				{

				}
				if(cont==150)
					break;

				cont++;
			}
			//		Assert.assertEquals(searchText, result);
		}
		catch(Exception e)
		{

		}
	}
	public void clickonProgressReport()
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		try {
			String result;
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchTextBox));
			wait.until(ExpectedConditions.elementToBeClickable(searchTextBox));

//			executor.executeScript("arguments[0].click();", searchTextBox);
//			wait.until(ExpectedConditions.elementToBeClickable(searchinputText));
			int rowCount=0;
			int cont=0;
			while(rowCount>=1)
			{
				List<WebElement> tableRows = driver.findElements(By.xpath(table));
				rowCount = tableRows.size();
				if(cont==150)
					break;

				cont++;
			}
			executor.executeScript("arguments[0].click();", searchButton);
//			wait.until(ExpectedConditions.visibilityOf(progressReportSearchResult));
			String val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}
			executor.executeScript("arguments[0].click();", searchButton);
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}

			wait.until(ExpectedConditions.visibilityOf(progressTableFirstRow));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tableRow)));
			
			
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			driver.manage().timeouts().implicitlyWait(14, TimeUnit.SECONDS);
			Thread.sleep(15000);

			int usercount=0;
			cont=0;
			while(rowCount!=usercount)
			{
				try
				{
					List<WebElement> tableRows = driver.findElements(By.xpath(table));
					usercount = tableRows.size();
				}
				catch(Exception e)
				{

				}
				if(cont==150)
					break;

				cont++;
			}
			//		Assert.assertEquals(searchText, result);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void validaterow(int row)
	{
		int cont=0;
		int rowCount=0;
		while(row!=rowCount)
		{
			try
			{
				Thread.sleep(50);
				List<WebElement> tableRows = driver.findElements(By.xpath(table));
				rowCount = tableRows.size();
			}
			catch (Exception e) {
				// TODO: handle exception
			}
			if(cont==100)
				break;

			cont++;
		}

	}
	public void validatePageNumbers()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(rowPerPageSelect));
		int paginationOption = driver.findElements(By.xpath(pagination)).size();
		System.out.println("Pagination option available on progress report is " + paginationOption);
		Assert.assertTrue(paginationOption == 2);
	}

	public void updatetestdate(int quarterDate)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(test_date));
		String date = changeDate(quarterDate);
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", test_date,"value",date);
	}
	String searchTable = "//table[@aria-describedby='progress_report_info']//th"; 
	String row = "//table[@aria-describedby='progress_report_info' and @id='progress_report']//tbody//tr";

	public void validateProgressReportSortingEachColumn()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		for(int i = 1; i <= 16; i++)
		{
			ArrayList<String> obtainedList = new ArrayList<>(); 
			//div[@id="courseList_wrapper"]//th
			WebElement column = driver.findElement(By.xpath(searchTable + "[" + i + "]"));
			try
			{
				wait.until(ExpectedConditions.elementToBeClickable(column));
			}
			catch(Exception e)
			{
				WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
				js.executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", scrollArea);
				wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(searchTable + "[" + i + "]"))));
			}
			js.executeScript("arguments[0].click()", column);
			val = pageLoad.getAttribute("class");
			int m=0;
			while(val.toLowerCase().contains("loading"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			try
			{
				Thread.sleep(4000);
			}catch (Exception e) {
			}
			List<WebElement> elementList=null;
			if(column.getText().toLowerCase().contains("curriculum status"))
				elementList= driver.findElements(By.xpath(row + "/td[" + i + "]/span"));
			else
				elementList= driver.findElements(By.xpath(row + "/td[" + i + "]"));

			for(WebElement we:elementList)
			{
				obtainedList.add(we.getText());
			}
			ArrayList<String> sortedList = new ArrayList<>();   
			for(String s:obtainedList){
				sortedList.add(s);
			}
			Collections.sort(sortedList);

			System.out.println("Sorted list"+sortedList.toString());
			System.out.println("Obtainted list"+obtainedList);

			if(column.getText().toLowerCase().contains("launched date")||column.getText().toLowerCase().contains("completed date") )
			{

				System.out.println("====================================================================");
				List[] lists = split(sortedList);
				String list=lists[1].toString()+lists[0].toString();
				System.out.println(list);
				//				  System.err.println(lists[1].toString()+", "+lists[0].toString());
				Assert.assertTrue(column.getText()+"Obtainted lists", obtainedList.toString().equals(list.replace("][", ", ")));

			}
			else
				Assert.assertTrue(sortedList.equals(obtainedList));

			js.executeScript("arguments[0].click()", column);
			obtainedList.removeAll(obtainedList);
			val = pageLoad.getAttribute("class");
			m=0;
			while(val.toLowerCase().contains("loading"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			try
			{
				Thread.sleep(4000);
			}catch (Exception e) {
			}
			if(column.getText().toLowerCase().contains("curriculum status"))
				elementList= driver.findElements(By.xpath(row + "/td[" + i + "]/span"));
			else
				elementList= driver.findElements(By.xpath(row + "/td[" + i + "]"));

			for(WebElement we:elementList)
			{
				obtainedList.add(we.getText());
			}
			Collections.reverse(sortedList);
			if(column.getText().toLowerCase().contains("launched date")||column.getText().toLowerCase().contains("completed date") )
			{

				System.out.println("====================================================================");
				List[] lists = split(sortedList);
				String list=lists[0].toString()+lists[1].toString();
				System.out.println(list);
				//				  System.err.println(lists[1].toString()+", "+lists[0].toString());
				Assert.assertTrue(column.getText()+"Obtainted lists", obtainedList.toString().equals(list.replace("][", ", ")));

			}
			else
			{
				Assert.assertTrue(sortedList.equals(obtainedList));
			}

		}

	}
	public void navigateProgressReport()
	{
		try
		{
			wait.until(ExpectedConditions.visibilityOf(progressReportLink));
			progressReportLink.click();

			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

			if(!driver.getCurrentUrl().contains("progress_report"))
			{
				clickOnReportLink();
				wait.until(ExpectedConditions.visibilityOf(progressReportLink));
				progressReportLink.click();


			}
			Thread.sleep(18000);
		}
		catch(Exception e)
		{
			js.executeScript("arguments[0].scrollIntoView();",reportLink);

			reportLink.click();
			wait.until(ExpectedConditions.visibilityOf(progressReportLink));
			progressReportLink.click();

		}

	}
	public void verifyheaderforreportspage(String expected)
	{
		String ActualTitle = Reportheader.getText();
		Assert.assertEquals(ActualTitle,expected);
	}

	public static List[] split(List<String> list)
	{

		// Creating two empty lists
		List<String> first = new ArrayList<String>();
		List<String> second = new ArrayList<String>();

		// Getting size of the list
		// using size() method
		int size = list.size();

		// Step 1
		// (First size)/2 element copy into list
		// first and rest second list
		for (int i = 0; i < size; i++)
		{

			if(list.get(i).equals("NA"))
			{
				second.add(list.get(i));
			}
			else
				first.add(list.get(i));

		}
		// Step 2
		// (Second size)/2 element copy into list first and
		// rest second list

		// Returning a List of array
		return new List[] { first, second };
	}

	public void clickecardDownload()
	{
		wait.until(ExpectedConditions.visibilityOf(ecardDownload));
		ecardDownload.click();

		try
		{
			Thread.sleep(5000);
		}
		catch(Exception e)
		{

		}
		String currentHandle= driver.getWindowHandle();
		Set<String> handles=driver.getWindowHandles();
		for(int i=0;i<20;i++)
		{
			if(handles.size() == 1)
			{
				handles=driver.getWindowHandles();

			}
			else
				break;
		}
		int m=0;
		for(String actual: handles)
		{

			if(!actual.equalsIgnoreCase(currentHandle))
				driver.switchTo().window(actual);
			else
			{
				if(m==20)
					break;
				m++;

			}
		}

		Assert.assertTrue(driver.getCurrentUrl().contains("/certificate/ecard/"));
		try
		{
			Thread.sleep(5000);
			driver.switchTo().frame("examReaderFrame");
		}
		catch(Exception e)
		{

		}

		driver.findElement(By.xpath("//table/tr[2]/td[2]/img")).click();
		try
		{
			Thread.sleep(5000);
		}
		catch(Exception e)
		{

		}
		currentHandle= driver.getWindowHandle();
		handles=driver.getWindowHandles();

		Assert.assertTrue(driver.getWindowHandles().size()==3);

		handles=driver.getWindowHandles();


		driver.switchTo().window(handles.toArray()[2].toString()).close();
		driver.switchTo().window(handles.toArray()[1].toString()).close();
		driver.switchTo().window(handles.toArray()[0].toString());



	}

	public void viewecardDownload(String course)
	{
		if(courseListName.containsKey(course+"Ecard"))
			course=courseListName.get(course+"Ecard").toString();




		try
		{
			Thread.sleep(5000);
		}
		catch(Exception e)
		{

		}
		String currentHandle= driver.getWindowHandle();
		Set<String> handles=driver.getWindowHandles();
		for(int i=0;i<20;i++)
		{
			if(handles.size() == 1)
			{
				handles=driver.getWindowHandles();

			}
			else
				break;
		}
		int m=0;
		for(String actual: handles)
		{

			if(!actual.equalsIgnoreCase(currentHandle))
				driver.switchTo().window(actual);
			else
			{
				if(m==20)
					break;
				m++;

			}
		}

		Assert.assertTrue(driver.getCurrentUrl().contains("/certificate/ecard/"));
		try
		{
			Thread.sleep(5000);
			driver.switchTo().frame("examReaderFrame");
		}
		catch(Exception e)
		{

		}

		this.wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//table/tr//td[contains(text(),'"+course+"')]/following::td/img"))));

		driver.findElement(By.xpath("//table/tr//td[contains(text(),'"+course+"')]/following::td/img")).click();

		try
		{
			Thread.sleep(5000);
		}
		catch(Exception e)
		{

		}
		currentHandle= driver.getWindowHandle();
		handles=driver.getWindowHandles();

		Assert.assertTrue(driver.getWindowHandles().size()==3);

		handles=driver.getWindowHandles();


		driver.switchTo().window(handles.toArray()[2].toString()).close();
		driver.switchTo().window(handles.toArray()[1].toString()).close();
		driver.switchTo().window(handles.toArray()[0].toString());



	}
	public void viewecardDownload()
	{
		wait.until(ExpectedConditions.visibilityOf(viewecard));
		viewecard.click();

		try
		{
			Thread.sleep(5000);
		}
		catch(Exception e)
		{

		}
		String currentHandle= driver.getWindowHandle();
		Set<String> handles=driver.getWindowHandles();
		for(int i=0;i<20;i++)
		{
			if(handles.size() == 1)
			{
				handles=driver.getWindowHandles();

			}
			else
				break;
		}
		int m=0;
		for(String actual: handles)
		{

			if(!actual.equalsIgnoreCase(currentHandle))
				driver.switchTo().window(actual);
			else
			{
				if(m==20)
					break;
				m++;

			}
		}

		Assert.assertTrue(driver.getCurrentUrl().contains("/certificate/ecard/"));
		try
		{
			Thread.sleep(5000);
			driver.switchTo().frame("examReaderFrame");
		}
		catch(Exception e)
		{

		}

		driver.findElement(By.xpath("//table/tr[2]/td[2]/img")).click();
		try
		{
			Thread.sleep(5000);
		}
		catch(Exception e)
		{

		}
		currentHandle= driver.getWindowHandle();
		handles=driver.getWindowHandles();

		Assert.assertTrue(driver.getWindowHandles().size()==3);

		handles=driver.getWindowHandles();


		driver.switchTo().window(handles.toArray()[2].toString()).close();
		driver.switchTo().window(handles.toArray()[1].toString()).close();
		driver.switchTo().window(handles.toArray()[0].toString());



	}
	public void clickonfilter(String report)
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*/a[text()='"+report+"']"))));
		driver.findElement(By.xpath("//*/a[text()='"+report+"']")).click();
	}
	public void validateDueDateWithDaysFromTodayWithCourseName(String courseName, int days)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[6]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().equals(courseText.toLowerCase().trim()))
			{
				String launchDate = table + "[" + i + "]/td[10]";
				String launchDateText = driver.findElement(By.xpath(launchDate)).getText();
				System.out.println(launchDateText);
				DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
				Date date = new Date();
				Calendar cal = Calendar.getInstance();
				String formattedStartDate = dateFormat.format(date);
				cal.add(Calendar.DAY_OF_MONTH, days); 
				String formattedEndDate = dateFormat.format(cal.getTime());
				Assert.assertTrue(launchDateText.equalsIgnoreCase(formattedEndDate));
				flag = true;
				break;
			}
			else if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String launchDate = table + "[" + i + "]/td[10]";
				String launchDateText = driver.findElement(By.xpath(launchDate)).getText();
				System.out.println(launchDateText);
				DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
				Date date = new Date();
				Calendar cal = Calendar.getInstance();
				String formattedStartDate = dateFormat.format(date);
				cal.add(Calendar.DAY_OF_MONTH, days); 
				String formattedEndDate = dateFormat.format(cal.getTime());
				Assert.assertTrue(launchDateText.equalsIgnoreCase(formattedEndDate));
				flag = true;
				break;
			}			
		}	
		if(flag == false)
			Assert.fail("Course Name not found");
	}
	public void validateDueDateWithCourseName(String courseName)
	{
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[6]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().equals(courseText.toLowerCase().trim()))
			{
				String dueDate = table + "[" + i + "]/td[10]";
				String dueDateText = driver.findElement(By.xpath(dueDate)).getText();
				DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
				Calendar cal = Calendar.getInstance();
				cal.add(Calendar.DAY_OF_MONTH, 2); 
				String formattedEndDate = dateFormat.format(cal.getTime());
				System.out.println("Due date from progress report page is " + dueDateText + " and from assignment page is " + formattedEndDate);
				Assert.assertTrue(dueDateText.equalsIgnoreCase(formattedEndDate));
				flag = true;
				break;
			}	
			else if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String dueDate = table + "[" + i + "]/td[10]";
				String dueDateText = driver.findElement(By.xpath(dueDate)).getText();
				DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
				Calendar cal = Calendar.getInstance();
				cal.add(Calendar.DAY_OF_MONTH, 2); 
				String formattedEndDate = dateFormat.format(cal.getTime());
				System.out.println("Due date from progress report page is " + dueDateText + " and from assignment page is " + formattedEndDate);
				Assert.assertTrue(dueDateText.equalsIgnoreCase(formattedEndDate));
				flag = true;
				break;
			}			
		}	
		if(flag == false)
			Assert.fail("Course Name not found");
	}
	public String changeDate(int quarter)
	{

		LocalDate localDate = LocalDate.now();
		LocalDate firstDayOfQuarter = localDate.with(localDate.getMonth().firstMonthOfQuarter()).with(TemporalAdjusters.firstDayOfMonth());
		LocalDate lastDayOfQuarter;
		lastDayOfQuarter = firstDayOfQuarter.plusMonths(quarter*3).plusMonths(2).with(TemporalAdjusters.lastDayOfMonth());
		String formattedDate = lastDayOfQuarter.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
		System.out.println(formattedDate);
		return formattedDate;
	}
	public void closeActivityPopup()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(closeHeaderPopup));
		closeHeaderPopup.click();
	}
	public void OpenActivityPopUpWithName(String courseName)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		if(courseListName.containsKey(courseName))
			courseName=courseListName.get(courseName).toString();

		try
		{
			Thread.sleep(5000);	
		}
		catch(Exception e)
		{

		}

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[6]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().equals(courseText.toLowerCase().trim()))
			{
				String userID = driver.findElement(By.xpath(table + "[" + i + "]/td[2]")).getText().trim().toLowerCase();
				String lastName = driver.findElement(By.xpath(table + "[" + i + "]/td[3]")).getText().trim().toLowerCase();
				String firstName = driver.findElement(By.xpath(table + "[" + i + "]/td[4]")).getText().trim().toLowerCase();
				String courseNameText = driver.findElement(By.xpath(table + "[" + i + "]/td[6]")).getText().trim().toLowerCase();
				String popupTilteExpected = firstName + " " + lastName + " (" + userID + ")" + " - " + courseNameText;
				System.out.println(popupTilteExpected);
				try
				{
					WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
					js.executeScript("arguments[0].scrollLeft = 0", scrollArea);
					driver.findElement(By.xpath(table + "[" + i + "]/td[6]/span"));
					js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath(table + "[" + i + "]/td[6]/span")));
					js.executeScript("window.scrollBy(-3000,0)");
					if(driver.findElement(By.xpath(table + "[" + i + "]/td[6]/span")).isDisplayed())
						driver.findElement(By.xpath(table + "[" + i + "]/td[6]/span")).click();
				}
				catch (Exception e) 
				{


					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table + "[" + i + "]/td[7]/span"))));
					driver.findElement(By.xpath(table + "[" + i + "]/td[7]/span")).click();
				}
				try
				{
					Thread.sleep(5000);	
				}
				catch(Exception e)
				{

				}

				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//h4"))));
				String popupTilteActual = driver.findElement(By.xpath("//h4")).getText().trim();
				Assert.assertTrue(popupTilteExpected.equalsIgnoreCase(popupTilteActual.trim().toLowerCase()));
			}	
			else if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String userID = driver.findElement(By.xpath(table + "[" + i + "]/td[2]")).getText().trim().toLowerCase();
				String lastName = driver.findElement(By.xpath(table + "[" + i + "]/td[3]")).getText().trim().toLowerCase();
				String firstName = driver.findElement(By.xpath(table + "[" + i + "]/td[4]")).getText().trim().toLowerCase();
				String courseNameText = driver.findElement(By.xpath(table + "[" + i + "]/td[6]")).getText().trim().toLowerCase();
				String popupTilteExpected = firstName + " " + lastName + " (" + userID + ")" + " - " + courseNameText;
				System.out.println(popupTilteExpected);
				try
				{
					WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
					js.executeScript("arguments[0].scrollLeft = 0", scrollArea);
					driver.findElement(By.xpath(table + "[" + i + "]/td[6]/span"));
					js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath(table + "[" + i + "]/td[6]/span")));
					js.executeScript("window.scrollBy(-3000,0)");
					if(driver.findElement(By.xpath(table + "[" + i + "]/td[6]/span")).isDisplayed())
						driver.findElement(By.xpath(table + "[" + i + "]/td[6]/span")).click();
				}
				catch (Exception e) 
				{


					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table + "[" + i + "]/td[7]/span"))));
					driver.findElement(By.xpath(table + "[" + i + "]/td[7]/span")).click();
				}
				try
				{
					Thread.sleep(5000);	
				}
				catch(Exception e)
				{

				}

				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//h4"))));
				String popupTilteActual = driver.findElement(By.xpath("//h4")).getText().trim();
				Assert.assertTrue(popupTilteExpected.equalsIgnoreCase(popupTilteActual.trim().toLowerCase()));
			}			
		}	
	}
	public void validateCurriculumNameWithCourseName(String courseName)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		if(courseListName.containsKey(courseName))
			courseName=courseListName.get(courseName).toString();

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[6]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().equals(courseText.toLowerCase().trim()))
			{
				flag = true;
				break;
			}	else if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				flag = true;
				break;
			}			
		}	
		if(flag == false)
			Assert.fail("Course Name not found");
	}
	public void validateConsumedWithCourseName(String courseName, int quarterDate)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		if(courseListName.containsKey(courseName))
			courseName=courseListName.get(courseName).toString();

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[6]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().equals(courseText.toLowerCase().trim()))
			{
				String launchDate = table + "[" + i + "]/td[9]";
				String launchDateText = driver.findElement(By.xpath(launchDate)).getText();
				System.out.println(launchDateText);
				String date = changeDate(quarterDate);
				Assert.assertTrue(launchDateText.equalsIgnoreCase(date));
				flag = true;
				break;
			}else if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String launchDate = table + "[" + i + "]/td[9]";
				String launchDateText = driver.findElement(By.xpath(launchDate)).getText();
				System.out.println(launchDateText);
				String date = changeDate(quarterDate);
				Assert.assertTrue(launchDateText.equalsIgnoreCase(date));
				flag = true;
				break;
			}
		}	
		if(flag == false)
			Assert.fail("Course Name not found");
	}
	public void validateDueDateWithCourseName(String courseName, int quarterDate)
	{

		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		if(courseListName.containsKey(courseName))
			courseName=courseListName.get(courseName).toString();

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[6]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().equals(courseText.toLowerCase().trim()))
			{
				String launchDate = table + "[" + i + "]/td[10]";
				String launchDateText = driver.findElement(By.xpath(launchDate)).getText();
				System.out.println(launchDateText);
				String date = changeDate(quarterDate);
				Assert.assertTrue(launchDateText.equalsIgnoreCase(date));
				flag = true;
				break;
			}else if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String launchDate = table + "[" + i + "]/td[10]";
				String launchDateText = driver.findElement(By.xpath(launchDate)).getText();
				System.out.println(launchDateText);
				String date = changeDate(quarterDate);
				Assert.assertTrue(launchDateText.equalsIgnoreCase(date));
				flag = true;
				break;
			}			
		}	
		if(flag == false)
			Assert.fail("Course Name not found");
	}

	public void validateAvailableDateWithCourseNameCurrentDate(String courseName)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[6]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().equals(courseText.toLowerCase().trim()))
			{
				String launchDate = table + "[" + i + "]/td[8]";
				String launchDateText = driver.findElement(By.xpath(launchDate)).getText();
				System.out.println(launchDateText);
				LocalDate localDate = LocalDate.now();
				String date = localDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
				Assert.assertTrue(launchDateText.equalsIgnoreCase(date));
				flag = true;
				break;
			}
			else if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String launchDate = table + "[" + i + "]/td[8]";
				String launchDateText = driver.findElement(By.xpath(launchDate)).getText();
				System.out.println(launchDateText);
				LocalDate localDate = LocalDate.now();
				String date = localDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
				Assert.assertTrue(launchDateText.equalsIgnoreCase(date));
				flag = true;
				break;
			}			
		}	
		if(flag == false)
			Assert.fail("Course Name not found");
	}
	public void validateAvailableDateWithCourseNameCurrentDateLMS(String courseName)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		courseName=courseName.replace("Â","");
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[5]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().equals(courseText.toLowerCase().trim()))
			{
				String launchDate = table + "[" + i + "]/td[8]";
				String launchDateText = driver.findElement(By.xpath(launchDate)).getText();
				System.out.println(launchDateText);
				LocalDate localDate = LocalDate.now();
				String date = localDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
				System.out.println(date);
				Assert.assertTrue(launchDateText.equalsIgnoreCase(date));
				flag = true;
				break;
			}	else if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String launchDate = table + "[" + i + "]/td[8]";
				String launchDateText = driver.findElement(By.xpath(launchDate)).getText();
				System.out.println(launchDateText);
				LocalDate localDate = LocalDate.now();
				String date = localDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
				System.out.println(date);
				Assert.assertTrue(launchDateText.equalsIgnoreCase(date));
				flag = true;
				break;
			}			
		}	
		if(flag == false)
			Assert.fail("Course Name not found");
	}
	public void validateLaunchDateWithCourseNameCurrentDateLMS(String courseName)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		courseName=courseName.replace("Â","");
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[5]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().equals(courseText.toLowerCase().trim()))
			{
				String launchDate = table + "[" + i + "]/td[8]";
				String launchDateText = driver.findElement(By.xpath(launchDate)).getText();
				System.out.println(launchDateText);
				LocalDate localDate = LocalDate.now();
				String date = localDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
				System.out.println(date);
				Assert.assertTrue(launchDateText.equalsIgnoreCase(date));
				flag = true;
				break;
			}	else if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String launchDate = table + "[" + i + "]/td[8]";
				String launchDateText = driver.findElement(By.xpath(launchDate)).getText();
				System.out.println(launchDateText);
				LocalDate localDate = LocalDate.now();
				String date = localDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
				System.out.println(date);
				Assert.assertTrue(launchDateText.equalsIgnoreCase(date));
				flag = true;
				break;
			}			
		}	
		if(flag == false)
			Assert.fail("Course Name not found");
	}
	public void verifytableheaders(String Tableheaders) throws InterruptedException
	{
		String str = Tableheaders;
		List<String> headerList = Arrays.asList(str.split(","));
		Thread.sleep(2000);
		for(int i = 0; i < headerList.size(); i++) {
			WebElement header = driver.findElement(By.xpath("(//thead//tr//th["+(i+2)+"])[1]")); 
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView();", header);
			String actualheader = header.getText();
			//      System.out.println(i+2);
			System.out.println(actualheader);
			Assert.assertEquals(headerList.get(i).toUpperCase(),actualheader);
		}

	}
	public void verifypagination()
	{
		Boolean Display = Paginationinfoup.isDisplayed();
		System.out.println("Element displayed is :"+Display);
		System.out.println(rowsperpageheader.getText());
		Assert.assertEquals(rowsperpageheader.getText(),"Rows per page\n"
				+ "25\n"
				+ "50\n"
				+ "75\n"
				+ "100");
	}
	public void expandCurriculamfilters() throws InterruptedException
	{
		Thread.sleep(2000);
		curriculumfilterslink.click();
	}
	public void curriculamstatusoptionsCTC(String options) throws InterruptedException
	{
		Thread.sleep(2000);
		List<String> options1 = Arrays.asList(options.split(","));
		curriculamstatusdropdownCTC.click();
		List<WebElement> allstatusoption = curriculamstatusdropdownvaluesCTC;
		List<String> allstatusoptions1 = new ArrayList<String>();
		for( WebElement option : allstatusoption){
			String add1 = option.getText();
			allstatusoptions1.add(add1);
		}
		System.out.println(allstatusoptions1);
		Assert.assertEquals(allstatusoptions1,options1);
	}
	public void curriculamstatusoptionsLMS(String options) throws InterruptedException
	{
		Thread.sleep(3000);
		List<String> options1 = Arrays.asList(options.split(","));
		curriculamstatusdropdownLMS.click();
		List<WebElement> allstatusoption = curriculamstatusdropdownvaluesLMS;
		List<String> allstatusoptions1 = new ArrayList<String>();
		for( WebElement option : allstatusoption){
			String add1 = option.getText();
			allstatusoptions1.add(add1);
		}
		System.out.println(allstatusoptions1);
		Assert.assertEquals(options1,allstatusoptions1);
	}
	public void validateCurriculumStatusComplete()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		val = js.executeScript("return document.readyState").toString();
		int m=0;
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			m++;
		}
		wait.until(ExpectedConditions.visibilityOf(reportTable));
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableRow + "[7]/span"))));
		String data = driver.findElement(By.xpath(tableRow + "[7]/span")).getText().trim();
		System.out.println(data);
		//		Assert.assertTrue(data.equalsIgnoreCase("Completed"));
	}
	public void expandmorefilterslink() throws InterruptedException
	{
		Thread.sleep(2000);
		morefilterslink.click();
	}
	public void userstatusoptions(String options) throws InterruptedException
	{
		Thread.sleep(3000);
		List<String> options1 = Arrays.asList(options.split(","));
		userstatusfiltersdropdown.click();
		List<WebElement> allstatusoption = userstatusdropdownvalues;
		List<String> allstatusoptions1 = new ArrayList<String>();
		//				for( WebElement option : allstatusoption){
		//		String add1 = option.getText();
		//		allstatusoptions1.add(add1);
		//				}
		allstatusoption.forEach(ele -> allstatusoptions1.add(ele.getText()));
		System.out.println(allstatusoptions1);
		System.out.println(options1);
		Assert.assertEquals(allstatusoptions1,options1);
	}
	public void verifydefaultselected() throws InterruptedException
	{
		Assert.assertEquals(true,activedefaultselected.isDisplayed());
		inactiveelement.click();
		Thread.sleep(1000);
		Assert.assertEquals(true,inactiveselected.isDisplayed());	
	}
	public void presenceofassignmentname(String booleanvalue) throws InterruptedException
	{
		//		Assert.assertEquals(booleanvalue,Assignmentdropdown.isDisplayed());
		Thread.sleep(2000);
		Assignmentdropdown.click();
		Assert.assertEquals(Boolean.parseBoolean(booleanvalue),Assignmentdropdown.isDisplayed());
	}
	public void assignmentunselectall() throws InterruptedException
	{
		UnselectAllAssignmentdropdown.click();
		Thread.sleep(2000);
	}
	public void selectionofassignmentnames(Integer int1)
	{
		//		List<String> allassignmentoptions1 = new ArrayList<String>();
		for(int i=1;i<=int1;i++)
		{
			driver.findElement(By.xpath("//select[@id='assignments']/following-sibling::div//div//ul//li["+i+"]//label")).click();
			String assignmentoptiongettext = driver.findElement(By.xpath("//select[@id='assignments']/following-sibling::div//div//ul//li["+i+"]//label")).getText().trim();
			allassignmentoptions1.add(assignmentoptiongettext);
		}
		System.out.println(allassignmentoptions1);                                                                  
	}
	public void searchclick() throws InterruptedException
	{
		Searchbutton.click();
		Thread.sleep(2000);
	}
	public void recordsvalidationforassignmentnamefield()
	{                 
		System.out.println(allassignmentoptions1);
		List<WebElement> allstatusoption = allassignmentvalues;
		List<String> allstatusoptions1 = new ArrayList<String>();
		allstatusoption.forEach(ele -> allstatusoptions1.add(ele.getText()));
		System.out.println(allstatusoptions1);
		System.out.println(allassignmentoptions1);
		Assert.assertEquals(allstatusoptions1,allassignmentoptions1);
	}
	public void assertionforavailabledate()
	{
		Assert.assertEquals(true,Availabledatefrom.isDisplayed());
		Assert.assertEquals(true,AvailabledateTo.isDisplayed());
	}
	@FindBy(xpath="//*[@id=\"ms-list-5\"]/button")
	WebElement notificationFilter;

	@FindBy(xpath="//*[@id='assignment_search_filter']//h1")
	WebElement header;




	@FindBy(xpath="//*[@id=\"ms-list-5\"]/div/a[text()='Unselect all']")
	WebElement unselectAll;

	public void navigateReport(String report)
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*/a[text()='"+report+"']"))));
		driver.findElement(By.xpath("//*/a[text()='"+report+"']")).click();
		System.out.println(driver.getTitle());



	}

	public void selectNotificationFilter(String filter)
	{
		wait.until(ExpectedConditions.visibilityOf(notificationFilter));
		notificationFilter.click();

		unselectAll.click();
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//input[contains(@title,'"+filter+"')]"))));
		driver.findElement(By.xpath("//input[contains(@title,'"+filter+"')]")).click();

		driver.findElement(By.xpath("//*[@id=\"notification_log_filter\"]//button[text()='Search']")).click();
	}




	public void assertionforLauncheddate()
	{
		Assert.assertEquals(true,LaunchedDatefrom.isDisplayed());
		Assert.assertEquals(true,LaunchedDateTo.isDisplayed());
	}
	public void assertionduedateassertion()
	{
		Assert.assertEquals(true,fromDuedate.isDisplayed());
		Assert.assertEquals(true,ToDuedate.isDisplayed());
	}
	public void assertioncompletedate()
	{
		Assert.assertEquals(true,fromCompletedDate.isDisplayed());
		Assert.assertEquals(true,ToCompletedDate.isDisplayed());
	}
	public void clickhandicon() throws InterruptedException 
	{
		handiconoddfirst.click();
		Thread.sleep(2000);	
	}

	public void verifyactivityheaders(String headers) throws InterruptedException {
		Thread.sleep(3000);
		List<String> headers1 = Arrays.asList(headers.split(","));
		List<WebElement> allactivityheaders = coursedetailsheaders;
		List<String> coursedetailsheaders1 = new ArrayList<String>();
		for( WebElement option : allactivityheaders){
			String add1 = option.getText().replace("\n", " ");
			coursedetailsheaders1.add(add1.trim());
		}
		System.out.println(coursedetailsheaders1);
		System.out.println(headers1);
		Assert.assertEquals(headers1,coursedetailsheaders1);				
	}

	public void verifyactivitytabledata(String string) throws InterruptedException {
		Thread.sleep(3000);

		if(courseListName.containsKey(string.split(",")[0]))
			string=	string.replace(string.split(",")[0],courseListName.get(string.split(",")[0]).toString());



		List<String> headers1 = Arrays.asList(string.split(","));
		List<WebElement> allactivitydata = coursedetailsdata;
		List<String> coursedetailsdata1 = new ArrayList<String>();
		for( WebElement option : allactivitydata){
			String add1 = option.getText();
			coursedetailsdata1.add(add1.trim());
		}
		System.out.println(coursedetailsdata1);
		System.out.println(headers1);
		Assert.assertEquals(headers1,coursedetailsdata1);
	}
	public void selectthecurriculumname(String string) throws InterruptedException
	{
		Thread.sleep(1000);
		Curriculumnamedropdown.click();
		Thread.sleep(1000);
		UnselectAllcurriculumnamedropdown.click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//select[@id='courses']/following-sibling::div//div//ul//li//label[contains(text(),'"+string+"')]")).click();
		Thread.sleep(2000);
	}
	public void clickonclose() throws InterruptedException
	{
		closeiconwithinpopup.click();
		Thread.sleep(1000);
	}

	public void validateHeader()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		//        val = pageLoad.getAttribute("class");
		//        while(val.equalsIgnoreCase("loading_compliance"))
		//        {
		//            val = pageLoad.getAttribute("class");
		//        }
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableHeader + "[1]"))));
		List<WebElement> headerList = driver.findElements(By.xpath(tableHeader));

		String[] headerData = new String[headerList.size() - 1];
		for(int i = 2; i <= headerList.size(); i++)
		{
			headerData[i-2] = headerList.get(i-1).getText();
			if(i == 7)
				scrollRight();
		}
		String expectedHeader[] = {"User ID", "Last Name", "First Name", "Assignment Name", "Curriculum Name", "Curriculum Status", "Available Date",
				"Launched Date","Due Date", "Completed Date", "User Status", "Unit Level", "Unit Name", "Job Title", "Email"};
		for(int i = 0; i <= expectedHeader.length - 1; i++)
		{
			expectedHeader[i] = expectedHeader[i].toUpperCase();
		}
		boolean flag = Arrays.equals(headerData, expectedHeader);
		System.out.println(flag);
		Assert.assertTrue(flag);            
	}

	public void scrollRight()
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
		executor.executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", scrollArea);
	}
	public void validateCurriculumNameWithCourseNameForLMS(String courseName)
	{
		if(courseListName.containsKey(courseName))
			courseName=courseListName.get(courseName).toString();

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[5]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().equals(courseText.toLowerCase().trim()))
			{
				flag = true;
				break;
			}else if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				flag = true;
				break;
			}			
		}	
		if(flag == false)
			Assert.fail("Course Name not found");
	}
	public void validateConsumedWithCourseNameForLMS(String courseName, int quarterDate)
	{
		if(courseListName.containsKey(courseName))
			courseName=courseListName.get(courseName).toString();

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[5]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().equals(courseText.toLowerCase().trim()))
			{
				String launchDate = table + "[" + i + "]/td[8]";
				String launchDateText = driver.findElement(By.xpath(launchDate)).getText();
				System.out.println(launchDateText);
				String date = changeDate(quarterDate);
				Assert.assertTrue(launchDateText.equalsIgnoreCase(date));
				flag = true;
				break;
			}else if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String launchDate = table + "[" + i + "]/td[8]";
				String launchDateText = driver.findElement(By.xpath(launchDate)).getText();
				System.out.println(launchDateText);
				String date = changeDate(quarterDate);
				Assert.assertTrue(launchDateText.equalsIgnoreCase(date));
				flag = true;
				break;
			}
		}	
		if(flag == false)
			Assert.fail("Course Name not found");
	}
	public void validateNoCurriculumNameWithCourseNameForLMS(String courseName)
	{
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[5]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().equals(courseText.toLowerCase().trim()))
			{
				flag = true;
				break;
			}	else if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				flag = true;
				break;
			}			
		}	
		if(flag == true)
			Assert.fail("Course Name not found");
	}


	public void validateHeaderForLMS()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableHeader + "[1]"))));
		List<WebElement> headerList = driver.findElements(By.xpath(tableHeader));
		String[] headerData = new String[headerList.size() - 1];
		for(int i = 2; i <= headerList.size(); i++)
		{
			headerData[i-2] = headerList.get(i-1).getText();
			if(i == 7)
				scrollRight();
		}
		String expectedHeader[] = {"User ID", "Last Name", "First Name", "Curriculum Name", "Curriculum Status", "Available Date",
				"Launched Date","Due Date", "Completed Date", "User Status", "Unit Level", "Unit Name", "Job Title", "Email"};
		for(int i = 0; i <= expectedHeader.length - 1; i++)
		{
			expectedHeader[i] = expectedHeader[i].toUpperCase();
		}
		boolean flag = Arrays.equals(headerData, expectedHeader);
		System.out.println(flag);
		Assert.assertTrue(flag);			
	}
	public void validateAvailableDateWithCourseNameAsNAForLMS(String courseName)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[5]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().equals(courseText.toLowerCase().trim()))
			{
				String availableDate = table + "[" + i + "]/td[7]";
				String availableDateText = driver.findElement(By.xpath(availableDate)).getText();
				System.out.println(availableDateText);
				Assert.assertTrue(availableDateText.equalsIgnoreCase("NA"));
				flag = true;
				break;
			}else if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String availableDate = table + "[" + i + "]/td[7]";
				String availableDateText = driver.findElement(By.xpath(availableDate)).getText();
				System.out.println(availableDateText);
				Assert.assertTrue(availableDateText.equalsIgnoreCase("NA"));
				flag = true;
				break;
			}			
		}	
		if(flag == false)
			Assert.fail("Course Name not found");
	}
	public void validateAvailableDateWithCourseNameAsNA(String courseName)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[5]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().equals(courseText.toLowerCase().trim()))
			{
				String availableDate = table + "[" + i + "]/td[7]";
				String availableDateText = driver.findElement(By.xpath(availableDate)).getText();
				System.out.println(availableDateText);
				Assert.assertTrue(availableDateText.equalsIgnoreCase("NA"));
				flag = true;
				break;
			}	else if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String availableDate = table + "[" + i + "]/td[7]";
				String availableDateText = driver.findElement(By.xpath(availableDate)).getText();
				System.out.println(availableDateText);
				Assert.assertTrue(availableDateText.equalsIgnoreCase("NA"));
				flag = true;
				break;
			}			
		}	
		if(flag == false)
			Assert.fail("Course Name not found");
	}
	public void validateActivityPopupNotDisplay()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		val = js.executeScript("return document.readyState").toString();
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
		}
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(reportTable));
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableRow + "[2]"))));
		String userID = driver.findElement(By.xpath(tableRow + "[2]")).getText().trim().toLowerCase();
		System.out.println(userID);
		String lastName = driver.findElement(By.xpath(tableRow + "[3]")).getText().trim().toLowerCase();
		System.out.println(lastName);
		String firstName = driver.findElement(By.xpath(tableRow + "[4]")).getText().trim().toLowerCase();
		System.out.println(firstName);
		String courseName = driver.findElement(By.xpath(tableRow + "[5]")).getText().trim().toLowerCase();
		System.out.println(courseName);
		String popupTilteExpected = firstName + " " + lastName + " (" + userID + ")" + " - " + courseName;
		System.out.println(popupTilteExpected);
		try
		{
			if(driver.findElement(By.xpath(tableRow + "[6]/span")).isDisplayed())
				driver.findElement(By.xpath(tableRow + "[6]/span")).click();
		}
		catch (Exception e) 
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableRow + "[7]/span"))));
			driver.findElement(By.xpath(tableRow + "[7]/span")).click();
		}
		wait = new WebDriverWait(driver, 10);
		Assert.assertFalse(driver.findElement(By.xpath("//h4")).isDisplayed());
	}
	public void validateConsumedWithCourseNameCurrentDateForLMS(String courseName)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[5]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().equals(courseText.toLowerCase().trim()))
			{
				String launchDate = table + "[" + i + "]/td[8]";
				String launchDateText = driver.findElement(By.xpath(launchDate)).getText();
				System.out.println(launchDateText);
				LocalDate localDate = LocalDate.now();
				String date = localDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
				Assert.assertTrue(launchDateText.equalsIgnoreCase(date));
				flag = true;
				break;
			}else if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String launchDate = table + "[" + i + "]/td[8]";
				String launchDateText = driver.findElement(By.xpath(launchDate)).getText();
				System.out.println(launchDateText);
				LocalDate localDate = LocalDate.now();
				String date = localDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
				Assert.assertTrue(launchDateText.equalsIgnoreCase(date));
				flag = true;
				break;
			}
		}	
		if(flag == false)
			Assert.fail("Course Name not found");
	}
	public void validateConsumedWithCourseNameCurrentDate(String courseName)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[6]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().equals(courseText.toLowerCase().trim()))
			{
				String launchDate = table + "[" + i + "]/td[9]";
				String launchDateText = driver.findElement(By.xpath(launchDate)).getText();
				System.out.println(launchDateText);
				LocalDate localDate = LocalDate.now();
				String date = localDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
				Assert.assertTrue(launchDateText.equalsIgnoreCase(date));
				flag = true;
				break;
			}else if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String launchDate = table + "[" + i + "]/td[9]";
				String launchDateText = driver.findElement(By.xpath(launchDate)).getText();
				System.out.println(launchDateText);
				LocalDate localDate = LocalDate.now();
				String date = localDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
				Assert.assertTrue(launchDateText.equalsIgnoreCase(date));
				flag = true;
				break;
			}
		}	
		if(flag == false)
			Assert.fail("Course Name not found");
	}
	public void validateDueDateAsNAWithCourseName(String courseName)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[6]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().equals(courseText.toLowerCase().trim()))
			{
				String dueDate = table + "[" + i + "]/td[10]";
				String dueDateText = driver.findElement(By.xpath(dueDate)).getText();
				System.out.println("Due date from progress report page is " + dueDateText);
				Assert.assertTrue(dueDateText.equalsIgnoreCase("NA"));
				flag = true;
				break;
			}	else if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String dueDate = table + "[" + i + "]/td[10]";
				String dueDateText = driver.findElement(By.xpath(dueDate)).getText();
				System.out.println("Due date from progress report page is " + dueDateText);
				Assert.assertTrue(dueDateText.equalsIgnoreCase("NA"));
				flag = true;
				break;
			}			
		}	
		if(flag == false)
			Assert.fail("Course Name not found");
	}

	public void validateDueDateAsNAWithCourseNameForLMS(String courseName)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[5]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String dueDate = table + "[" + i + "]/td[9]";
				String dueDateText = driver.findElement(By.xpath(dueDate)).getText();
				System.out.println("Due date from progress report page is " + dueDateText);
				Assert.assertTrue(dueDateText.equalsIgnoreCase("NA"));
				flag = true;
				break;
			}			
		}	
		if(flag == false)
			Assert.fail("Course Name not found");
	}
	public void validateDueDateWithCourseNameForLMS(String courseName, int quarterDate)
	{
		if(courseListName.containsKey(courseName))
			courseName=courseListName.get(courseName).toString();

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[5]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String launchDate = table + "[" + i + "]/td[9]";
				String launchDateText = driver.findElement(By.xpath(launchDate)).getText();
				System.out.println(launchDateText);
				String date = changeDate(quarterDate);
				Assert.assertTrue(launchDateText.equalsIgnoreCase(date));
				flag = true;
				break;
			}			
		}	
		if(flag == false)
			Assert.fail("Course Name not found");
	}
	public void validateAssignmentNameFilterOptionsNotAvailable()
	{
		boolean flag = validateElementPresent(assignmentStatusFilter);
		Assert.assertFalse(flag == true);
	}
	public boolean validateElementPresent(By element)
	{
		try
		{
			Thread.sleep(5000);
			driver.findElement(element);
			return true;
		}
		catch(org.openqa.selenium.NoSuchElementException e)
		{
			return false;
		}
		catch(Exception ex)
		{
			Assert.fail(ex.getMessage());
			return false;
		}

	}

	public void validateUserSearchFilterOptions()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(userSearchLabel));
		wait.until(ExpectedConditions.visibilityOf(userSearchInput));
	}

	public void validateOrgLevelFilterOptions()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(orgLevelLabel));
		Select select = new Select(orgLevelDropdown);
		select.toString();
	}

	public void clickMoreFilter()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(moreFilter));
		moreFilter.click();    
		JavascriptExecutor js = (JavascriptExecutor)driver;
		val = js.executeScript("return document.readyState").toString();
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
		}
	}

	public void validateJobTitleFilterOptions()
	{
		try
		{
			Thread.sleep(5000);
			WebDriverWait wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.visibilityOf(jobTitleLabel));
			Select select = new Select(jobTitleDropdown);
			select.toString();
		}
		catch (Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void validateGroupFilterOptions()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(groupLabel));
		Select select = new Select(groupDropdown);
		select.toString();
	}

	public void validateUserStatusFilterOptions()
	{
		wait.until(ExpectedConditions.visibilityOf(userStatusLabel));
		Select select = new Select(userStatusDropdown);
		List<WebElement> selectOptions = select.getAllSelectedOptions();
		Assert.assertTrue(selectOptions.size() == 1);
		String value = driver.findElement(By.xpath(userStatusSelected)).getAttribute("title").replace("  ", "").trim();;

		System.out.println("ddd"+value.strip()+" "+value.strip()+" "+value.strip()+("Active").contains(value) );
		if(value.length()==7)
		{
			Assert.assertTrue(value.substring(1).equalsIgnoreCase("active"));	
		}
		else      	
			Assert.assertTrue(value.equalsIgnoreCase("Active"));
	}
	public void validateCurriculumStatusOptionsForLMS()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(curriculumStatusLabel));
		Select select = new Select(curriculumStatusDropdown);
		List<WebElement> statusElement = select.getOptions();
		Assert.assertTrue(statusElement.size() == 2);
		ArrayList<String> statusListAvaialble =new ArrayList<String>();
		ArrayList<String> statusListExpected =new ArrayList<String>();
		//String statusList[] = {};
		for(int i = 1; i <= statusElement.size(); i++)
		{
			String val = driver.findElement(By.xpath("(" + curriculumStatusDropdownOption + ")[" + i + "]")).getAttribute("title").replace(" ", "").trim();
			System.out.println(val);
			statusListAvaialble.add(val);
		}
		String statusExpected[] = {"In Progress", "Completed"};
		for(int i = 0; i <= statusExpected.length - 1; i++)
		{
			statusListExpected.add(statusExpected[i]);
		}
		List<List<String>> list_ui = new ArrayList<>();
		for (String expected : statusListExpected) {
			list_ui.add(Arrays.asList(expected));
		}

		List<List<String>> list_actual = new ArrayList<>();
		for (String actual : statusListAvaialble) {
			list_actual.add(Arrays.asList(actual));
		}

		List<List<String>> differences = new ArrayList<>(list_ui);
		differences.removeAll(list_actual);
		Assert.assertTrue(differences.size() == 0);
	}
	public void clickCurriculumFilter()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(curriculumFilter));
		curriculumFilter.click();    
	}

	public void validateAvailableDateFilterOptions()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(avaialbleDateLabel));
		wait.until(ExpectedConditions.visibilityOf(avaialbleDateFromInput));
		wait.until(ExpectedConditions.visibilityOf(avaialbleDateToInput));
	}

	public void validateCompletedDateFilterOptions()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(completedDateLabel));
		wait.until(ExpectedConditions.visibilityOf(completedDateFromInput));
		wait.until(ExpectedConditions.visibilityOf(completedDateToInput));
	}
	public void validateActivityHeader()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(activityHeader + "[1]"))));
		List<WebElement> headerList = driver.findElements(By.xpath(activityHeader));
		String[] headerData = new String[headerList.size()];
		for(int i = 1; i <= headerList.size(); i++)
		{
			String text = headerList.get(i-1).getText().replace("\n", " ").trim();
			headerData[i-1] = text;
		}
		String expectedHeader[] = {"Activity Name", "Activity Status", "Activity Start Date", "Activity Due Date", "Activity Completed Date", "Activity Score"};
		for(int i = 0; i <= expectedHeader.length - 1; i++)
		{
			expectedHeader[i] = expectedHeader[i].toUpperCase();
		}
		boolean flag = Arrays.equals(headerData, expectedHeader);
		System.out.println(flag);
		Assert.assertTrue(flag);            
	}





	public void notOpenActivityPopUpWithName(String courseName)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[6]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			courseName = courseName.replaceAll("registered", "\u00AE");
			if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String userID = driver.findElement(By.xpath(table + "[" + i + "]/td[2]")).getText().trim().toLowerCase();
				String lastName = driver.findElement(By.xpath(table + "[" + i + "]/td[3]")).getText().trim().toLowerCase();
				String firstName = driver.findElement(By.xpath(table + "[" + i + "]/td[4]")).getText().trim().toLowerCase();
				String courseNameText = driver.findElement(By.xpath(table + "[" + i + "]/td[6]")).getText().trim().toLowerCase();
				String popupTilteExpected = firstName + " " + lastName + " (" + userID + ")" + " - " + courseNameText;
				System.out.println(popupTilteExpected);
				try
				{
					if(driver.findElement(By.xpath(table + "[" + i + "]/td[6]")).isDisplayed())
						driver.findElement(By.xpath(table + "[" + i + "]/td[6]")).click();

				}
				catch (Exception e)
				{
					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table + "[" + i + "]/td[7]/span"))));
					driver.findElement(By.xpath(table + "[" + i + "]/td[7]/span")).click();
				}
				wait = new WebDriverWait(driver, 10);
				val = pageLoad.getAttribute("class");
				while(val.equalsIgnoreCase("loading_compliance"))
				{
					val = pageLoad.getAttribute("class");
				}
				Assert.assertFalse(driver.findElement(By.xpath("//h4")).isDisplayed());
			}            
		}    
	}

	public void clickSearchButton()
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			executor.executeScript("arguments[0].click();", searchButton);
			String val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}
			wait.until(ExpectedConditions.visibilityOf(progressTableFirstRow));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tableRow)));
			List<WebElement> columnList = driver.findElements(By.xpath(tableRow));
			System.out.println("column visbile are " + columnList.size());
			while(columnList.size() < 15)
			{
				Thread.sleep(5000);
				columnList = driver.findElements(By.xpath(tableRow));
				System.out.println("waiting for columnList to display");
			}
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
			}
			Thread.sleep(5000);
		}
		catch(Exception e)
		{

		}
	}



	public void validateUserStatusFilterAvailability()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(userStatusFilter));
		userStatusFilter.click();
	}

	public void selectAllStatus()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userSelectAll));
			userSelectAll.click();
		}
		catch(Exception e)
		{

		}
	}


	public void validateLaunchedDateFilterOptions()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(launchedDateLabel));
		wait.until(ExpectedConditions.visibilityOf(launchedDateFromInput));
		wait.until(ExpectedConditions.visibilityOf(launchedDateToInput));
	}


	public void validateCurriculumFilterOptions()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(curriculumNameLabel));
		wait.until(ExpectedConditions.visibilityOf(dueDateLabel));
		Select select = new Select(curriculumNameDropdown);
		select.toString();
	}

	public void validateCurriculumStatusOptions()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(curriculumStatusLabel));
		Select select = new Select(curriculumStatusDropdown);
		List<WebElement> statusElement = select.getOptions();
		Assert.assertTrue(statusElement.size() == 4);
		ArrayList<String> statusListAvaialble =new ArrayList<String>();
		ArrayList<String> statusListExpected =new ArrayList<String>();
		//String statusList[] = {};
		for(int i = 1; i <= statusElement.size(); i++)
		{
			String val = driver.findElement(By.xpath("(" + curriculumStatusDropdownOption + ")[" + i + "]")).getAttribute("title").trim();
			statusListAvaialble.add(val.substring(1));
		}
		String statusExpected[] = {"Not Activated", "Yet to Start", "In Progress", "Completed"};
		for(int i = 0; i <= statusExpected.length - 1; i++)
		{
			statusListExpected.add(statusExpected[i]);
		}
		List<List<String>> list_ui = new ArrayList<>();
		for (String expected : statusListExpected) {
			list_ui.add(Arrays.asList(expected));
		}

		List<List<String>> list_actual = new ArrayList<>();
		for (String actual : statusListAvaialble) {
			list_actual.add(Arrays.asList(actual));
		}
		System.out.println("list_actual : "+list_actual.toString());
		System.out.println("list_ui : "+list_ui.toString());

		List<List<String>> differences = new ArrayList<>(list_ui);
		differences.removeAll(list_actual);
		Assert.assertTrue(differences.size() == 0);
	}


	public void validateAssignmentNameFilterOptions()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(assignmentStatusLabel));
		Select select = new Select(assignmentStatusDropdown);
		select.toString();
	}



	public void verifySearchMultiSelectAssignmentName()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(assignmentStatusButton));
		assignmentStatusButton.click();
		wait.until(ExpectedConditions.visibilityOf(assignmentStatusSearch));
		wait.until(ExpectedConditions.visibilityOf(assignmentStatusInput));
	}
	public void validaterowcount(int count) {
		// TODO Auto-generated method stub
		int row;
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		row=tableRows.size();
		Assert.assertEquals(count, row);
	}

	/////////////////////////////////////////////// P2 Regression Cases //////////////////////////////////////////////

	@FindBy(xpath = "//div[@id]/a[text()= 'Clear Search']")
	WebElement searchClear;

	@FindBy(xpath = "//table[@id = 'progress_report']/tbody//td[4]")
	WebElement searchResultUserFirstName;

	@FindBy(xpath = "//label[text() = 'Organization (s) Name']")
	WebElement unitLevelLabel;

	@FindBy(xpath = "//select[@id = 'orgLevel']")
	WebElement selectOrgLevelDropdown;

	public void validateRecordAvailable()
	{
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			counter = 0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			String text = driver.findElement(By.xpath(table + "[1]/td[1]")).getText();
			System.out.println(text);
			Assert.assertFalse(text.equals("No reports data found."));
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}


	public void validateRecordNotAvailableCount()
	{
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 15);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableRow + "[1]"))));
			String text = driver.findElement(By.xpath(tableRow + "[1]")).getText();
			System.out.println(text);
			Assert.assertTrue(text.equalsIgnoreCase("No reports data found."));
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void clearSearchResult()	
	{
		js.executeScript("arguments[0].click();", searchClear);
	}

	public void userSearchWithoutClearWithoutColumnValidation(String searchText)
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		try 
		{
			Thread.sleep(5000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			//wait.until(ExpectedConditions.visibilityOf(searchTextBox));
			wait.until(ExpectedConditions.elementToBeClickable(searchTextBox));
			System.out.println("Search text is " + searchText);
			executor.executeScript("arguments[0].click();", searchTextBox);
			wait.until(ExpectedConditions.elementToBeClickable(searchinputText));
			searchinputText.sendKeys(searchText);
			executor.executeScript("arguments[0].click();", searchButton);
			String val = js.executeScript("return document.readyState").toString();
			int counter = 0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			wait.until(ExpectedConditions.visibilityOf(progressTableFirstRow));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tableRow)));
			List<WebElement> columnList = driver.findElements(By.xpath(tableRow));
			System.out.println("column visbile are " + columnList.size());
			counter = 0;
			while(columnList.size() < 1)
			{
				columnList = driver.findElements(By.xpath(tableRow));
				System.out.println("waiting for columnList to display");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}		
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	public void studentSearchLMSWithoutClearWithoutColumnValidation(String searchText)
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchTextBox));
			wait.until(ExpectedConditions.elementToBeClickable(searchTextBox));
			System.out.println("Search text is " + searchText);

			executor.executeScript("arguments[0].click();", searchTextBox);
			wait.until(ExpectedConditions.elementToBeClickable(searchinputText));
			searchinputText.sendKeys(searchText);
			executor.executeScript("arguments[0].click();", searchButton);
			String val = js.executeScript("return document.readyState").toString();
			int counter = 0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			wait.until(ExpectedConditions.visibilityOf(progressTableFirstRow));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tableRow)));
			List<WebElement> columnList = driver.findElements(By.xpath(tableRow));
			System.out.println("column visbile are " + columnList.size());
			counter = 0;
			while(columnList.size() < 1 && counter < 12)
			{
				columnList = driver.findElements(By.xpath(tableRow));
				System.out.println("waiting for columnList to display");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
		}
		catch(Exception e)
		{

		}
	}

	public void OpenActivityPopUpWithNameOnly(String courseName)
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = table + "[" + i + "]/td[6]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			courseName = courseName.replaceAll("registered", "\u00AE");
			if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String userID = driver.findElement(By.xpath(table + "[" + i + "]/td[2]")).getText().trim().toLowerCase();
				String lastName = driver.findElement(By.xpath(table + "[" + i + "]/td[3]")).getText().trim().toLowerCase();
				String firstName = driver.findElement(By.xpath(table + "[" + i + "]/td[4]")).getText().trim().toLowerCase();
				String courseNameText = driver.findElement(By.xpath(table + "[" + i + "]/td[6]")).getText().trim().toLowerCase();
				String popupTilteExpected = firstName + " " + lastName + " (" + userID + ")" + " - " + courseNameText;
				System.out.println(popupTilteExpected);
				try
				{
					WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
					executor.executeScript("arguments[0].scrollLeft = -arguments[0].offsetWidth", scrollArea);
					if(driver.findElement(By.xpath(table + "[" + i + "]/td[6]")).isDisplayed())
						driver.findElement(By.xpath(course)).click();
				}
				catch (Exception e) 
				{
					System.out.println(e.getMessage());
					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table + "[" + i + "]/td[7]/span"))));
					driver.findElement(By.xpath(table + "[" + i + "]/td[7]")).click();
				}
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//h4"))));
				String popupTilteActual = driver.findElement(By.xpath("//h4")).getText().trim();
				Assert.assertTrue(popupTilteExpected.equalsIgnoreCase(popupTilteActual.trim().toLowerCase()));
				break;
			}			
		}	
	}

	public void validateActivityScore(String score)
	{
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(activityList_table))));
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(5000);
			List<WebElement> count = driver.findElements(By.xpath(activityList_table));
			activityList = new String[count.size()];
			for(int i = 1; i <= count.size(); i++)
			{
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(activityList_table + "[" + i + "]/td[6]"))));
				String text = driver.findElement(By.xpath(activityList_table + "[" + i + "]/td[6]")).getText();
				System.out.println(text);
				Assert.assertTrue(text.equalsIgnoreCase(score));
			}
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void validateAtleastActivityStatus(String status)
	{
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(activityList_table))));
			int counter = 0;
			boolean flag = false;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(5000);
			List<WebElement> count = driver.findElements(By.xpath(activityList_table));
			activityList = new String[count.size()];
			for(int i = 1; i <= count.size(); i++)
			{
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(activityList_table + "[" + i + "]/td[2]"))));
				String text = driver.findElement(By.xpath(activityList_table + "[" + i + "]/td[2]")).getText();
				if(text.equalsIgnoreCase(status)) {
					flag = true;
					break;
				}
			}
			Assert.assertTrue(flag);
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void validateAtleastActivityStartDate(int quarter)
	{
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(activityList_table))));
			int counter = 0;
			boolean flag = false;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(5000);
			List<WebElement> count = driver.findElements(By.xpath(activityList_table));
			activityList = new String[count.size()];
			String date = changeDate(quarter);
			for(int i = 1; i <= count.size(); i++)
			{
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(activityList_table + "[" + i + "]/td[2]"))));
				String text = driver.findElement(By.xpath(activityList_table + "[" + i + "]/td[3]")).getText();
				if(text.equalsIgnoreCase(date)) {
					flag = true;
					break;
				}
			}
			Assert.assertTrue(flag);
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void validateAtleastActivityDueDate(int quarter)
	{
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(activityList_table))));
			int counter = 0;
			boolean flag = false;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(5000);
			List<WebElement> count = driver.findElements(By.xpath(activityList_table));
			activityList = new String[count.size()];
			String date = changeDate(quarter);
			for(int i = 1; i <= count.size(); i++)
			{
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(activityList_table + "[" + i + "]/td[2]"))));
				String text = driver.findElement(By.xpath(activityList_table + "[" + i + "]/td[4]")).getText();
				if(text.equalsIgnoreCase(date)) {
					flag = true;
					break;
				}
			}
			Assert.assertTrue(flag);
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
	}


	public void searchUserIDWithoutClear(String searchText)
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		try 
		{
			Thread.sleep(5000);
			String result;
			WebDriverWait wait = new WebDriverWait(driver, 30);
			//wait.until(ExpectedConditions.visibilityOf(searchTextBox));
			wait.until(ExpectedConditions.elementToBeClickable(searchTextBox));
			System.out.println("Search text is " + searchText);
			executor.executeScript("arguments[0].click();", searchTextBox);
			wait.until(ExpectedConditions.elementToBeClickable(searchinputText));
			searchinputText.sendKeys(searchText);
			executor.executeScript("arguments[0].click();", searchButton);
			String val = js.executeScript("return document.readyState").toString();
			int counter = 0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			System.out.println(val);
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOf(progressTableFirstRow));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tableRow)));
			List<WebElement> columnList = driver.findElements(By.xpath(tableRow));
			System.out.println("column visbile are " + columnList.size());
			counter = 0;
			while(columnList.size() < 15)
			{
				columnList = driver.findElements(By.xpath(tableRow));
				System.out.println("waiting for columnList to display");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}

			wait.until(ExpectedConditions.visibilityOf(searchResultUserId));
			result = searchResultUserId.getText();
			Assert.assertEquals(searchText, result);

		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	public void searchUserFirstNameWithoutClear(String searchText)
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		try 
		{
			Thread.sleep(5000);
			String result;
			WebDriverWait wait = new WebDriverWait(driver, 30);
			//wait.until(ExpectedConditions.visibilityOf(searchTextBox));
			wait.until(ExpectedConditions.elementToBeClickable(searchTextBox));
			System.out.println("Search text is " + searchText);
			executor.executeScript("arguments[0].click();", searchTextBox);
			wait.until(ExpectedConditions.elementToBeClickable(searchinputText));
			searchinputText.sendKeys(searchText);
			executor.executeScript("arguments[0].click();", searchButton);
			String val = js.executeScript("return document.readyState").toString();
			int counter = 0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			System.out.println(val);
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOf(progressTableFirstRow));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tableRow)));
			List<WebElement> columnList = driver.findElements(By.xpath(tableRow));
			System.out.println("column visbile are " + columnList.size());
			counter = 0;
			while(columnList.size() < 15)
			{
				columnList = driver.findElements(By.xpath(tableRow));
				System.out.println("waiting for columnList to display");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}

			wait.until(ExpectedConditions.visibilityOf(searchResultUserFirstName));
			result = searchResultUserFirstName.getText();
			Assert.assertEquals(searchText, result);

		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	public void validateUnitLevelFilterOptions()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(unitLevelLabel));
	}

	public void selectOrgLevelMainFilter(int level)
	{
		try
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int counter = 0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userSearchLabel));
			Select select = new Select(selectOrgLevelDropdown);
			select.selectByIndex(level - 1);
			val = pageLoad.getAttribute("class");
			counter = 0;
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(2000);
				counter++;
				if(counter>30)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			js.executeScript("arguments[0].click();", searchButton);
			counter = 0;
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(2000);
				counter++;
				if(counter>30)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	//////////////////////////////////////////////////////////////////More Filter ////////////////////////////////

	@FindBy(xpath = "(//button[text() = 'Search' and not(@id)])[1]")
	WebElement moreFilterSearchButton;

	@FindBy(xpath = "//a[@class = 'card-link']/parent::div/following-sibling::div//a[text() = 'Clear Search']")
	WebElement moreFilterClearSearch;

	@FindBy(xpath = "//select[@id = 'filterSelect_2']//following-sibling::div/button")
	WebElement orgLevelFilter;

	@FindBy(xpath = "//select[@id = 'filterSelect_2']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement orgLevelFilterUnSelectAll;

	@FindBy(xpath = "//select[@id = 'filterSelect_2']//following-sibling::div//a[text() = 'Select all']")
	WebElement orgLevelFilterSelectAll;

	@FindBy(xpath = "(//select[@id = 'filterSelect_2']//following-sibling::div)//input[@type= 'text']")
	WebElement orgLevelFilterFilterSearch;

	String orgFilterLabel = "//label[contains(text(), '";
	String unitLevelFilter = "(//select[@id = 'filterSelect_2']//following-sibling::div//ul//label)";

	public void validateOrgLevelFilterFilterAvailability()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(orgLevelFilter));
			orgLevelFilter.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void clickOnMoreFilterSearchButton()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("compliance_report_loader"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(moreFilterSearchButton));
		moreFilterSearchButton.click();
	}

	public void selectSingleOrgLevelFilter(String courseName)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitLevelFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(unitLevelFilter));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == true)
				driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]")).click();
		}
		driver.findElement(By.xpath(unitLevelFilter + "//input[contains(@title,'" + courseName + "')]")).click();
	}

	public void selectMultiOrgLevelFilter()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitLevelFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(unitLevelFilter));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == false) {
				driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]")).click();
				break;
			}
		}

	}

	public void unSelectAllOrgLevelFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			List<WebElement> statusList = driver.findElements(By.xpath(unitLevelFilter));
			for(int i = 1; i <= statusList.size(); i++)
			{
				WebElement elem = driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]"));
				boolean flag = elem.isSelected();
				if(flag == false)
					driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]")).click();
			}
			wait.until(ExpectedConditions.visibilityOf(orgLevelFilterUnSelectAll));
			orgLevelFilterUnSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void selectAllOrgLevelFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(orgLevelFilterSelectAll));
			orgLevelFilterSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void searchOrgLevelFilter(String courseName)
	{
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(orgLevelFilterFilterSearch));
			int counter = 0;
			orgLevelFilterFilterSearch.click();
			orgLevelFilterFilterSearch.clear();
			orgLevelFilterFilterSearch.sendKeys(courseName);
			List<WebElement> statusList = driver.findElements(By.xpath(unitLevelFilter + "/parent::li[not(contains(@class,'hidden'))]"));
			while(statusList.size() > 1)
			{
				statusList = driver.findElements(By.xpath(unitLevelFilter + "/parent::li[not(contains(@class,'hidden'))]"));
				Thread.sleep(2000);
				if(counter > 12)
					Assert.fail("Search functionality for user status is not working");
				counter++;
			}
			driver.findElement(By.xpath(unitLevelFilter + "//input[contains(@title,'" + courseName + "')]")).click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}

	}	

	////////////////////////////////////////////////////////JOB FILTER ////////////////////////////////////////////////////	

	@FindBy(xpath = "//select[@id = 'job_title_id']//following-sibling::div/button")
	WebElement jobFilter;

	@FindBy(xpath = "//select[@id = 'job_title_id']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement jobFilterUnSelectAll;

	@FindBy(xpath = "//select[@id = 'job_title_id']//following-sibling::div//a[text() = 'Select all']")
	WebElement jobFilterSelectAll;

	@FindBy(xpath = "(//select[@id = 'job_title_id']//following-sibling::div)//input[@type= 'text']")
	WebElement jobFilterFilterSearch;

	String userJobFilter = "(//select[@id = 'job_title_id']//following-sibling::div//ul//label)";

	public void validateJobFilterFilterAvailability()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(jobFilter));
			jobFilter.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void selectSingleJobFilter()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userJobFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userJobFilter));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userJobFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == true)
				driver.findElement(By.xpath("(" + userJobFilter + "/input)[" + i + "]")).click();
		}
		if(OrganizationSettings.titleName != null)
			driver.findElement(By.xpath(userJobFilter + "//input[contains(@title,'" + OrganizationSettings.titleName + "')]")).click();
		else
			driver.findElement(By.xpath("(" + userJobFilter + "//input)[1]")).click();
	}

	public void selectMultiJobFilter()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userJobFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userJobFilter));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userJobFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == false) {
				driver.findElement(By.xpath("(" + userJobFilter + "/input)[" + i + "]")).click();
				break;
			}
		}

	}

	public void unSelectAllJobFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			List<WebElement> statusList = driver.findElements(By.xpath(userJobFilter));
			for(int i = 1; i <= statusList.size(); i++)
			{
				WebElement elem = driver.findElement(By.xpath("(" + userJobFilter + "/input)[" + i + "]"));
				boolean flag = elem.isSelected();
				if(flag == false)
					driver.findElement(By.xpath("(" + userJobFilter + "/input)[" + i + "]")).click();
			}
			wait.until(ExpectedConditions.visibilityOf(jobFilterUnSelectAll));
			jobFilterUnSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void selectAllJobFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(jobFilterSelectAll));
			jobFilterSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void searchJobFilter()
	{
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(jobFilterFilterSearch));
			int counter = 0;
			jobFilterFilterSearch.click();
			jobFilterFilterSearch.clear();
			if(OrganizationSettings.titleName == null)
				OrganizationSettings.titleName = driver.findElement(By.xpath(userJobFilter + "[1]")).getText().trim();
			System.out.println(OrganizationSettings.titleName);
			jobFilterFilterSearch.sendKeys(OrganizationSettings.titleName);
			List<WebElement> statusList = driver.findElements(By.xpath(userJobFilter + "/parent::li[not(contains(@class,'hidden'))]"));
			while(statusList.size() > 1)
			{
				statusList = driver.findElements(By.xpath(userJobFilter + "/parent::li[not(contains(@class,'hidden'))]"));
				Thread.sleep(2000);
				if(counter > 12)
					Assert.fail("Search functionality for user status is not working");
				counter++;
			}
			driver.findElement(By.xpath(userJobFilter + "//input[contains(@title,'" + OrganizationSettings.titleName + "')]")).click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}

	}


	/////////////////////////////////////////////////////////////////////////////////////////////////////

	@FindBy(xpath = "//select[@id = 'group_id']//following-sibling::div/button")
	WebElement groupFilter;

	@FindBy(xpath = "//select[@id = 'group_id']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement groupFilterUnSelectAll;

	@FindBy(xpath = "//select[@id = 'group_id']//following-sibling::div//a[text() = 'Select all']")
	WebElement groupFilterSelectAll;

	@FindBy(xpath = "(//select[@id = 'group_id']//following-sibling::div)//input[@type= 'text']")
	WebElement groupFilterFilterSearch;

	String userGroupFilter = "(//select[@id = 'group_id']//following-sibling::div//ul//label)";

	public void validateGroupFilterFilterAvailability()
	{
		try{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(groupFilter));
			groupFilter.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}


	public void selectSingleUserGroupFilter()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userGroupFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userGroupFilter));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userGroupFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == true)
				driver.findElement(By.xpath("(" + userGroupFilter + "/input)[" + i + "]")).click();
		}
		driver.findElement(By.xpath(userGroupFilter + "//input[contains(@title,'" + OrganizationSettings.groupName + "')]")).click();
	}

	public void selectMultiUserGroupFilter()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userGroupFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userGroupFilter));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userGroupFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == false) {
				driver.findElement(By.xpath("(" + userGroupFilter + "/input)[" + i + "]")).click();
				break;
			}
		}

	}

	public void unSelectAllGroupFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			List<WebElement> statusList = driver.findElements(By.xpath(userGroupFilter));
			for(int i = 1; i <= statusList.size(); i++)
			{
				WebElement elem = driver.findElement(By.xpath("(" + userGroupFilter + "/input)[" + i + "]"));
				boolean flag = elem.isSelected();
				if(flag == false)
					driver.findElement(By.xpath("(" + userGroupFilter + "/input)[" + i + "]")).click();
			}
			wait.until(ExpectedConditions.visibilityOf(groupFilterUnSelectAll));
			groupFilterUnSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void selectAllGroupFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(groupFilterSelectAll));
			groupFilterSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void searchGroupFilter()
	{
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(groupFilterFilterSearch));
			counter = 0;
			groupFilterFilterSearch.click();
			groupFilterFilterSearch.clear();
			groupFilterFilterSearch.sendKeys(OrganizationSettings.groupName2);
			List<WebElement> statusList = driver.findElements(By.xpath(userGroupFilter + "/parent::li[not(contains(@class,'hidden'))]"));
			while(statusList.size() > 1)
			{
				statusList = driver.findElements(By.xpath(userGroupFilter + "/parent::li[not(contains(@class,'hidden'))]"));
				Thread.sleep(2000);
				if(counter > 12)
					Assert.fail("Search functionality for user status is not working");
				counter++;
			}
			driver.findElement(By.xpath(userGroupFilter + "//input[contains(@title,'" + OrganizationSettings.groupName2 + "')]")).click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}

	}

	///////////////////////////////////////////////////////////// USER STATUS ///////////////////////////////////////////////////	

	@FindBy(xpath = "//select[@id = 'statusFilter']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement userUnSelectAll;

	@FindBy(xpath = "(//select[@id = 'statusFilter']//following-sibling::div)//input[@type= 'text']")
	WebElement userFilterSearch;

	String userStatus = "(//select[@id = 'statusFilter']//following-sibling::div//ul//label)";

	public void selectSingleUserStatusFilter(String status)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userStatus + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userStatus));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userStatus + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == true)
				driver.findElement(By.xpath("(" + userStatus + "/input)[" + i + "]")).click();
		}
		driver.findElement(By.xpath(userStatus + "//input[contains(@title,'" + status + "')]")).click();
	}

	public void selectMultiUserStatusFilter(String status)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userStatus + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userStatus));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath(userStatus + "//input[contains(@title,'" + status + "')]"));
			boolean flag = elem.isSelected();
			if(flag == false)
				driver.findElement(By.xpath(userStatus + "//input[contains(@title,'" + status + "')]")).click();
		}

	}

	public void unSelectAllStatus()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userUnSelectAll));
			userUnSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void searchUserStatus(String status)
	{
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userFilterSearch));
			counter = 0;
			userFilterSearch.click();
			userFilterSearch.clear();
			userFilterSearch.sendKeys(status);
			List<WebElement> statusList = driver.findElements(By.xpath(userStatus + "/parent::li[not(contains(@class,'hidden'))]"));
			while(statusList.size() > 1)
			{
				statusList = driver.findElements(By.xpath(userStatus + "/parent::li[not(contains(@class,'hidden'))]"));
				Thread.sleep(2000);
				if(counter > 12)
					Assert.fail("Search functionality for user status is not working");
				counter++;
			}
			driver.findElement(By.xpath(userStatus + "//input[contains(@title,'" + status + "')]")).click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}

	}

	//////////////////////////////////////CUrriculum Filters //////////////////////////////////////////////////////////////////////////

	@FindBy(xpath = "//a[text() = 'Curriculum Filters  ']")
	WebElement courseFilter;

	@FindBy(xpath = "//select[@id = 'curriculam_status']//following-sibling::div/button")
	WebElement curriculamStatusFilter;

	@FindBy(xpath = "(//button[text() = 'Search' and not(@id)])[2]")
	WebElement courseFilterSearchButton;

	@FindBy(xpath = "//select[@id = 'curriculam_status']//following-sibling::div/button")
	WebElement assignmentStatusNameFilter;

	@FindBy(xpath = "//select[@id = 'curriculam_status']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement assignmentStatusFilterUnSelectAll;

	@FindBy(xpath = "//select[@id = 'curriculam_status']//following-sibling::div//a[text() = 'Select all']")
	WebElement assignmentStatusFilterSelectAll;

	@FindBy(xpath = "(//select[@id = 'curriculam_status']//following-sibling::div)//input[@type= 'text']")
	WebElement assignmentStatusFilterFilterSearch;

	String assignmentStatusFilterLabel = "//label[contains(text(), '";
	String userAssignmentStatusFilter = "(//select[@id = 'curriculam_status']//following-sibling::div//ul//label)";

	public void clickCourseFilter()
	{
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(courseFilter));
			courseFilter.click();	
			JavascriptExecutor js = (JavascriptExecutor)driver;
			val = js.executeScript("return document.readyState").toString();
			int counter = 0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
		}
		catch(Exception e) {

		}
	}

	public void clickOnCourseFilterSearchButton()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(courseFilterSearchButton));
		courseFilterSearchButton.click();
	}

	public void validateCurriculStatusFilterFilterAvailability()
	{
		try{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(curriculamStatusFilter));
			curriculamStatusFilter.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void selectSingleUserAssignmentStatusFilter(String status)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userAssignmentStatusFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userAssignmentStatusFilter));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userAssignmentStatusFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == true)
				driver.findElement(By.xpath("(" + userAssignmentStatusFilter + "/input)[" + i + "]")).click();
		}
		driver.findElement(By.xpath(userAssignmentStatusFilter + "//input[contains(@title,'" + status + "')]")).click();
	}

	public void selectMultiUserAssignmentStatusFilter()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userAssignmentStatusFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userAssignmentStatusFilter));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userAssignmentStatusFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == false) {
				driver.findElement(By.xpath("(" + userAssignmentStatusFilter + "/input)[" + i + "]")).click();
				break;
			}
		}

	}

	public void unSelectAllAssignmentStatusFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			List<WebElement> statusList = driver.findElements(By.xpath(userAssignmentStatusFilter));
			for(int i = 1; i <= statusList.size(); i++)
			{
				WebElement elem = driver.findElement(By.xpath("(" + userAssignmentStatusFilter + "/input)[" + i + "]"));
				boolean flag = elem.isSelected();
				if(flag == false)
					driver.findElement(By.xpath("(" + userAssignmentStatusFilter + "/input)[" + i + "]")).click();
			}
			wait.until(ExpectedConditions.visibilityOf(assignmentStatusFilterUnSelectAll));
			assignmentStatusFilterUnSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void selectAllAssignmentStatusFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(assignmentStatusFilterSelectAll));
			assignmentStatusFilterSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void searchAssignmentStatusFilter(String status)
	{
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(assignmentStatusFilterFilterSearch));
			int counter = 0;
			assignmentStatusFilterFilterSearch.click();
			assignmentStatusFilterFilterSearch.clear();
			assignmentStatusFilterFilterSearch.sendKeys(status);
			List<WebElement> statusList = driver.findElements(By.xpath(userAssignmentStatusFilter + "/parent::li[not(contains(@class,'hidden'))]"));
			while(statusList.size() > 1)
			{
				statusList = driver.findElements(By.xpath(userAssignmentStatusFilter + "/parent::li[not(contains(@class,'hidden'))]"));
				Thread.sleep(2000);
				if(counter > 12)
					Assert.fail("Search functionality for user status is not working");
				counter++;
			}
			driver.findElement(By.xpath(userAssignmentStatusFilter + "//input[contains(@title,'" + status + "')]")).click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}

	}

	public void validateAssignmentStatusFilterOptions()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userAssignmentStatusFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userAssignmentStatusFilter));
		for(int i = 1; i <= statusList.size(); i++)
		{
			flag = false;
			WebElement elem = driver.findElement(By.xpath(userAssignmentStatusFilter + "[" + i + "]"));
			String val = elem.getText().trim();
			System.out.println(val);
			if(val.equalsIgnoreCase("Not Activated") || val.equalsIgnoreCase("Yet to start") || val.equalsIgnoreCase("In progress")
					|| val.equalsIgnoreCase("Completed"))
				flag = true;
		}
		Assert.assertTrue(flag);
	}

	///////////////////////////////////////// Assignment Filter //////////////////////////////////////////

	@FindBy(xpath = "//select[@id = 'assignments']//following-sibling::div/button")
	WebElement assignmentNameFilter;

	@FindBy(xpath = "//select[@id = 'assignments']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement assignmentFilterUnSelectAll;

	@FindBy(xpath = "//select[@id = 'assignments']//following-sibling::div//a[text() = 'Select all']")
	WebElement assignmentFilterSelectAll;

	@FindBy(xpath = "(//select[@id = 'assignments']//following-sibling::div)//input[@type= 'text']")
	WebElement assignmentsFilterFilterSearch;

	String assignmentFilterLabel = "//label[contains(text(), '";
	String userAssignmentFilter = "(//select[@id = 'assignments']//following-sibling::div//ul//label)";

	public void validateCurriculNameFilterFilterAvailability()
	{
		try{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(assignmentNameFilter));
			assignmentNameFilter.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void selectSingleUserAssignmentFilter()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userAssignmentFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userAssignmentFilter));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userAssignmentFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == true)
				driver.findElement(By.xpath("(" + userAssignmentFilter + "/input)[" + i + "]")).click();
		}
		driver.findElement(By.xpath(userAssignmentFilter + "//input[contains(@title,'" + Assignments.titleName + "')]")).click();
	}

	public void selectMultiUserAssignmentFilter()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userAssignmentFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userAssignmentFilter));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userAssignmentFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == false) {
				driver.findElement(By.xpath("(" + userAssignmentFilter + "/input)[" + i + "]")).click();
				break;
			}
		}

	}

	public void unSelectAllAssignmentFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			List<WebElement> statusList = driver.findElements(By.xpath(userAssignmentFilter));
			for(int i = 1; i <= statusList.size(); i++)
			{
				WebElement elem = driver.findElement(By.xpath("(" + userAssignmentFilter + "/input)[" + i + "]"));
				boolean flag = elem.isSelected();
				if(flag == false)
					driver.findElement(By.xpath("(" + userAssignmentFilter + "/input)[" + i + "]")).click();
			}
			wait.until(ExpectedConditions.visibilityOf(assignmentFilterUnSelectAll));
			assignmentFilterUnSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void selectAllAssignmentFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(assignmentFilterSelectAll));
			assignmentFilterSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void searchAssignmentFilter()
	{
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(assignmentsFilterFilterSearch));
			int counter = 0;
			assignmentsFilterFilterSearch.click();
			assignmentsFilterFilterSearch.clear();
			assignmentsFilterFilterSearch.sendKeys(Assignments.titleName);
			List<WebElement> statusList = driver.findElements(By.xpath(userAssignmentFilter + "/parent::li[not(contains(@class,'hidden'))]"));
			while(statusList.size() > 1)
			{
				statusList = driver.findElements(By.xpath(userAssignmentFilter + "/parent::li[not(contains(@class,'hidden'))]"));
				Thread.sleep(2000);
				if(counter > 12)
					Assert.fail("Search functionality for user status is not working");
				counter++;
			}
			driver.findElement(By.xpath(userAssignmentFilter + "//input[contains(@title,'" + Assignments.titleName + "')]")).click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}

	}

	////////////////////////////////////////////////////Course NAME //////////////////////////////////////

	@FindBy(xpath = "//select[@id = 'courses']//following-sibling::div/button")
	WebElement courseNameFilter;

	@FindBy(xpath = "//select[@id = 'courses']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement courseFilterUnSelectAll;

	@FindBy(xpath = "//select[@id = 'courses']//following-sibling::div//a[text() = 'Select all']")
	WebElement courseFilterSelectAll;

	@FindBy(xpath = "(//select[@id = 'courses']//following-sibling::div)//input[@type= 'text']")
	WebElement courseFilterFilterSearch;

	String courseFilterLabel = "//label[contains(text(), '";
	String userCourseFilter = "(//select[@id = 'courses']//following-sibling::div//ul//label)";

	public void validateCourseNameFilterFilterAvailability()
	{
		try{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(courseNameFilter));
			courseNameFilter.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void selectSingleUserCourseFilter(String courseName)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		if(AssignmentReport. checkifParmeterAvailable(courseName))
			courseName=AssignmentReport.getParmeterAvailable(courseName);


		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userCourseFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userCourseFilter));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userCourseFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == true)
				driver.findElement(By.xpath("(" + userCourseFilter + "/input)[" + i + "]")).click();
		}
		driver.findElement(By.xpath(userCourseFilter + "//input[contains(@title,'" + courseName + "')]")).click();
	}

	public void selectMultiUserCourseFilter()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userCourseFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userCourseFilter));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath("(" + userCourseFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if(flag == false) {
				driver.findElement(By.xpath("(" + userCourseFilter + "/input)[" + i + "]")).click();
				break;
			}
		}

	}

	public void unSelectAllCourseFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			List<WebElement> statusList = driver.findElements(By.xpath(userCourseFilter));
			for(int i = 1; i <= statusList.size(); i++)
			{
				WebElement elem = driver.findElement(By.xpath("(" + userCourseFilter + "/input)[" + i + "]"));
				boolean flag = elem.isSelected();
				if(flag == false)
					driver.findElement(By.xpath("(" + userCourseFilter + "/input)[" + i + "]")).click();
			}
			wait.until(ExpectedConditions.visibilityOf(courseFilterUnSelectAll));
			courseFilterUnSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void selectAllCourseFilter()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(courseFilterSelectAll));
			courseFilterSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void searchCourseFilter(String courseName)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		if(AssignmentReport. checkifParmeterAvailable(courseName))
			courseName=AssignmentReport.getParmeterAvailable(courseName);

		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(courseFilterFilterSearch));
			int counter = 0;
			courseFilterFilterSearch.click();
			courseFilterFilterSearch.clear();
			courseFilterFilterSearch.sendKeys(courseName);
			List<WebElement> statusList = driver.findElements(By.xpath(userCourseFilter + "/parent::li[not(contains(@class,'hidden'))]"));
			while(statusList.size() > 1)
			{
				statusList = driver.findElements(By.xpath(userCourseFilter + "/parent::li[not(contains(@class,'hidden'))]"));
				Thread.sleep(2000);
				if(counter > 12)
					Assert.fail("Search functionality for user status is not working");
				counter++;
			}
			driver.findElement(By.xpath(userCourseFilter + "//input[contains(@title,'" + courseName + "')]")).click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}

	}

	////////////////////////////////////////////////////////DUE DATE //////////////////////////////////////

	@FindBy(xpath = "//input[@id = 'from_due_date']")
	WebElement fromDueDate;

	@FindBy(xpath = "//input[@id = 'to_due_date']")
	WebElement toDueDate;

	@FindBy(xpath = "(//a[text()= 'Clear Search'])[3]")
	WebElement searchClearCurriculumFilter;

	@FindBy(xpath = "//input[@id = 'from_available_date']")
	WebElement fromAvailableDate;

	@FindBy(xpath = "//input[@id = 'to_available_date']")
	WebElement toAvailableDate;

	@FindBy(xpath = "//input[@id = 'from_launched_date']")
	WebElement fromLaunchedDate;

	@FindBy(xpath = "//input[@id = 'to_launched_date']")
	WebElement toLaunchedDate;

	@FindBy(xpath = "//input[@id = 'from_completed_date']")
	WebElement fromCompletedDate;

	@FindBy(xpath = "//input[@id = 'to_completed_date']")
	WebElement toCompletedDate;

	public String changeDateAsPerTime(int num, String time)
	{
		LocalDate localDate = LocalDate.now();
		LocalDate requiredDate = null;
		if(time.equalsIgnoreCase("days"))
		{
			requiredDate = localDate.plusDays(num);
		}
		else if(time.equalsIgnoreCase("month"))
		{
			requiredDate = localDate.plusMonths(num);
		}
		else if(time.equalsIgnoreCase("year"))
		{
			requiredDate = localDate.plusYears(num);
		}
		return requiredDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd")).toString();
	}	

	public void enterFromAssignmentDueDate(int num, String time)
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(5000);
			String date = changeDateAsPerTime(num, time);
			System.out.println(date);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(fromDueDate));
			js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", fromDueDate,"value",date);
		}
		catch(Exception e)
		{
			Assert.fail("Issue in hire date selection");
		}
	}

	public void enterToAssignmentDueDateQuarterEnd(int quarter)
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(5000);
			String date = changeDate(quarter);
			System.out.println(date);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(fromDueDate));
			js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", toDueDate,"value",date);
		}
		catch(Exception e)
		{
			Assert.fail("Issue in hire date selection");
		}
	}

	public void clearSearchResultCurriculumFilter()	
	{
		js.executeScript("arguments[0].click();", searchClearCurriculumFilter);
	}

	public void enterFromAssignmentAvailableDate(int num, String time)
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(5000);
			String date = changeDateAsPerTime(num, time);
			System.out.println(date);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(fromDueDate));
			js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", fromAvailableDate,"value",date);
		}
		catch(Exception e)
		{
			Assert.fail("Issue in Available date selection");
		}
	}

	public void enterToAssignmentAvailableDateQuarterEnd(int quarter)
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(5000);
			String date = changeDate(quarter);
			System.out.println(date);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(fromDueDate));
			js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", toAvailableDate,"value",date);
		}
		catch(Exception e)
		{
			Assert.fail("Issue in hire date selection");
		}
	}

	public void enterFromAssignmentLaunchedDate(int num, String time)
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(5000);
			String date = changeDateAsPerTime(num, time);
			System.out.println(date);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(fromDueDate));
			js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", fromLaunchedDate,"value",date);
		}
		catch(Exception e)
		{
			Assert.fail("Issue in launched date selection");
		}
	}

	public void enterToAssignmentLaunchedDateQuarterEnd(int quarter)
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(5000);
			String date = changeDate(quarter);
			System.out.println(date);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(fromDueDate));
			js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", toLaunchedDate,"value",date);
		}
		catch(Exception e)
		{
			Assert.fail("Issue in launched date selection");
		}
	}

	public void enterFromAssignmentCompletedDate(int num, String time)
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(5000);
			String date = changeDateAsPerTime(num, time);
			System.out.println(date);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(fromDueDate));
			js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", fromCompletedDate,"value",date);
		}
		catch(Exception e)
		{
			Assert.fail("Issue in launched date selection");
		}
	}

	public void enterToAssignmentCompletedDateQuarterEnd(int quarter)
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(5000);
			String date = changeDate(quarter);
			System.out.println(date);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(fromDueDate));
			js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", toCompletedDate,"value",date);
		}
		catch(Exception e)
		{
			Assert.fail("Issue in launched date selection");
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////



	///////////////////////////////////////////////////////////////////////////////////////////////////////////////

	@FindBy(xpath = "//button[@id = 'exportbtn']")
	WebElement exportButton;
	
	
	@FindBy(xpath = "//button[@id='exportProgressButton']")
	WebElement exportProgressButton;
	

	@FindBy(xpath = "//*[@id='radioWithActivity']")
	WebElement selectexportwithcourseactivity;
	
	@FindBy(xpath = "//*[@value='without-activity']")
	WebElement selectexportwithoutcourseactivity;
	
	static int no_of_Record=0;
	
	@FindBy(xpath = "//*[@class='with-activity']")
	WebElement no_ofRecordswith_activity;

	@FindBy(xpath = "//*[@class='without-activity']")
	WebElement no_ofRecordswithout_activity;


	@FindBy(xpath = "//*[@id='modal-close']")
	WebElement closeButtonforExport;

	
	
	String enableExportButton = "//button[@id = 'exportbtn' and not(contains(@class, 'disabled'))]";
	String downloadPath = System.getProperty("user.dir") + prop.getProperty("downloadPath");
	List<List<String>> list_UI = new ArrayList<>();
	List<List<String>> list_report = new ArrayList<>();

	User usr;

	public void getLocationPageNumber()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(rowPerPageSelect));
		List<WebElement> statusList = driver.findElements(By.xpath(pagination));
		Point location1 = null, location2 = null;
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath(pagination + "[" + i + "]"));
			System.out.println(elem.getLocation());
			if(location1 == null)
				location1 = elem.getLocation();
			else if(location2 == null)
				location2 = elem.getLocation();	
		}
		Assert.assertFalse(location1 == location2);
		int x1 = location1.getX();
		int x2 = location2.getX();
		Assert.assertTrue(x1 == x2);
		int y1 = location1.getY();
		int y2 = location2.getY();
		Assert.assertFalse(y1 == y2);
	}

	public void selectPaginationDropdown()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(rowPerPageSelect));
		Select select = new Select(rowPerPageSelect);
		List<WebElement> values = select.getOptions();
		for(int i = 0; i <= values.size() - 1; i++)
		{
			int value = Integer.parseInt(values.get(i).getText());
			if(value == 50) {
				values.get(i).click();
				break;
			}
		}
		validateRowCount(50);

	}
	public void validateRowCount(int count)
	{
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(2000);
				counter++;
				if(counter>30)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
			List<WebElement> tableRows = driver.findElements(By.xpath(table));
			int rowCount = tableRows.size();
			if(rowCount == count)
				Assert.assertTrue(rowCount == count);
			else {
				List<WebElement> pageNumber = driver.findElements(By.xpath(pagination + "[1]/span/a"));
				Assert.assertTrue(pageNumber.size() == 1);
			}
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void validateCompletedDateWithCourseNameAsDate(String courseName, String date)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();
		if(courseListName.containsKey(courseName))
			courseName=courseListName.get(courseName).toString();


		try {
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			boolean flag = false;
			val = js.executeScript("return document.readyState").toString();
			int counter = 0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			scrollLeft();
			int columnCount = 0;
			columnCount = getHeaderPosition("Curriculum Name");
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
			List<WebElement> tableRows = driver.findElements(By.xpath(table));
			int rowCount = tableRows.size();
			for (int i= 1; i<= rowCount; i++)
			{
				String course = table + "[" + i + "]/td[" + columnCount +"]";
				String courseText = driver.findElement(By.xpath(course)).getText();
				courseName = courseName.replaceAll("registered", "\u00AE");
				if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
				{
					columnCount = getHeaderPosition("Completed Date");
					String launchDate = table + "[" + i + "]/td[" + columnCount +"]";
					String launchDateText = driver.findElement(By.xpath(launchDate)).getText();
					System.out.println(launchDateText);
					switch (date) {
					case "NA":
						Assert.assertTrue(launchDateText.equalsIgnoreCase(date));
						flag = true;
						break;
					case "Current Date":
						LocalDate localDate = LocalDate.now();
						String dateCalculated = localDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
						Assert.assertTrue(launchDateText.equalsIgnoreCase(dateCalculated));
						flag = true;
						break;
					default:
						break;
					}

				}
			}	
			if(flag == false)
				Assert.fail("Course Name not found");
		}
		catch(Exception e) {

		}
	}

	public void validateDateDetailsWithCourseNameAsDate(String courseName, String date, String header, int quarter)
	{
		try {
			if(courseListName.containsKey(courseName+"Option"))
				courseName=courseListName.get(courseName+"Option").toString();

			if(courseListName.containsKey(courseName))
				courseName=courseListName.get(courseName).toString();

			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			boolean flag = false;
			val = js.executeScript("return document.readyState").toString();
			int counter = 0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			scrollLeft();
			int columnCount = 0;
			columnCount = getHeaderPosition("Curriculum Name");
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
			List<WebElement> tableRows = driver.findElements(By.xpath(table));
			int rowCount = tableRows.size();
			System.out.println("Row count"+rowCount);
			for (int i= 1; i<= rowCount; i++)
			{
				String course = table + "[" + i + "]/td[" + columnCount +"]";
				String courseText = driver.findElement(By.xpath(course)).getText();
				courseName = courseName.replaceAll("registered", "\u00AE");
				System.out.println(course);
				System.out.println(courseName);
				System.out.println(courseText);
				if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
				{
					columnCount = getHeaderPosition(header);
					String elementDate = table + "[" + i + "]/td[" + columnCount +"]";
					String dateText = driver.findElement(By.xpath(elementDate)).getText();
					System.out.println(dateText);
					switch (date) {
					case "NA":
						Assert.assertTrue(dateText.equalsIgnoreCase(date));
						flag = true;
						break;
					case "Current Date":
						LocalDate localDate = LocalDate.now();
						String dateCalculated = localDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
						Assert.assertTrue(dateText.equalsIgnoreCase(dateCalculated));
						flag = true;
						break;
					case "quarter":
						String newDate = changeDate(quarter);
						Assert.assertTrue(dateText.equalsIgnoreCase(newDate));
						flag = true;
						break;
						
					case "first day quarter":
						LocalDate currentDate = LocalDate.now();
						LocalDate quarterDate = currentDate.with(currentDate.getMonth().firstMonthOfQuarter()).with(TemporalAdjusters.firstDayOfMonth());
						String firstDayOfQuarter = quarterDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd")).toString();
						Assert.assertTrue(dateText.equalsIgnoreCase(firstDayOfQuarter));
						flag = true;
						break;
					case "specific date":
						String specificDate = LocalDate.now().plusDays(quarter).format(DateTimeFormatter.ofPattern("yyyy/MM/dd")).toString();
						Assert.assertTrue(dateText.equalsIgnoreCase(specificDate));
						flag = true;
						break;
					case "relative date":
						String relativeDate = LocalDate.now().plusWeeks(quarter).format(DateTimeFormatter.ofPattern("yyyy/MM/dd")).toString();
						Assert.assertTrue(dateText.equalsIgnoreCase(relativeDate));
						flag = true;
						break;
					default:
						break;
					}

				}
			}	
			if(flag == false)
				Assert.fail("Course Name not found");
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void validateTextDetailsWithCourseName(String courseName, String text, String header)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		if(courseListName.containsKey(courseName))
			courseName=courseListName.get(courseName).toString();

		try {
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			boolean flag = false;
			val = js.executeScript("return document.readyState").toString();
			int counter = 0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			scrollLeft();
			int columnCount = 0;
			columnCount = getHeaderPosition("Curriculum Name");
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
			List<WebElement> tableRows = driver.findElements(By.xpath(table));
			int rowCount = tableRows.size();
			for (int i= 1; i<= rowCount; i++)
			{
				String course = table + "[" + i + "]/td[" + columnCount +"]";
				String courseText = driver.findElement(By.xpath(course)).getText();
				courseName = courseName.replaceAll("registered", "\u00AE");
				if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
				{
					columnCount = getHeaderPosition(header);
					String elementDate = "";
					if(header.equalsIgnoreCase("Curriculum Status")) {
						elementDate = table + "[" + i + "]/td[" + columnCount +"]/span";
					}
					else {
						elementDate = table + "[" + i + "]/td[" + columnCount +"]";
					}
					String textUI = driver.findElement(By.xpath(elementDate)).getText();
					System.out.println(textUI);
					Assert.assertTrue(textUI.equalsIgnoreCase(text));
					flag = true;
					break;			
				}
			}	
			if(flag == false)
				Assert.fail("Course Name not found");
		}
		catch(Exception e) {

		}
	}

	public void clickExportButton()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(exportButton));
			int counter = 0;
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			if(driver.findElements(By.xpath(enableExportButton)).size()>0)
				js.executeScript("arguments[0].click();", exportButton);
			else
				Assert.fail("Export button is diabled as no record is available");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	public void clickSelectExportButton(String exportType)
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(exportProgressButton));
			int counter = 0;
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			
			Thread.sleep(5000);
			
			if(exportType.contains("Report with course activity"))
			{
	
				wait.until(ExpectedConditions.visibilityOf(selectexportwithcourseactivity));
				
				selectexportwithcourseactivity.click();
				no_of_Record= Integer.parseInt(no_ofRecordswith_activity.getText());
			}
			else
			{
            wait.until(ExpectedConditions.visibilityOf(selectexportwithoutcourseactivity));
				
            selectexportwithoutcourseactivity.click();
				no_of_Record= Integer.parseInt(no_ofRecordswithout_activity.getText());
			}
			exportProgressButton.click();
			Thread.sleep(3000);
			
			wait.until(ExpectedConditions.visibilityOf(closeButtonforExport));
			
			closeButtonforExport.click();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		Assert.fail("Error progress report");
		}
	}
	
	

	public void verifyDownloadFile()
	{
		try 
		{
			usr = new User();
			int counter = 0;
			boolean dwnld = false;
			do 
			{
				Thread.sleep(5000);
				dwnld = usr.isFileDownloaded_Ext(downloadPath, ".csv");
				counter = counter +1;
				if(counter > 24)
					Assert.fail("Not able to download file");
			}
			while(dwnld == false);
		} 
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}
	}

	public void getAllCourseUIActivityList()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		val = js.executeScript("return document.readyState").toString();
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
		}
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRows = driver.findElements(By.xpath(table));
		scrollLeft();
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			try
			{
				if(driver.findElement(By.xpath(table + "[" + i + "]/td[6]/span")).isDisplayed())
					driver.findElement(By.xpath(table + "[" + i + "]/td[6]/span")).click();
			}
			catch (Exception e) 
			{
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table + "[" + i + "]/td[7]/span"))));
				driver.findElement(By.xpath(table + "[" + i + "]/td[7]/span")).click();
			}
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//h4"))));
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(activityList_table))));
			List<WebElement> count = driver.findElements(By.xpath(activityList_table));
			activityList = new String[count.size()];
			String[][] activityValues = new String[count.size()][6];
			for(int j = 1; j <= count.size(); j++)
			{
				for(int k = 1; k <= 6; k++)
				{
					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(activityList_table + "[" + j + "]/td[" + k +"]"))));
					wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(activityList_table + "[" + j + "]/td[" + k +"]"))));
					String text = driver.findElement(By.xpath(activityList_table + "[" + j + "]/td[" + k +"]")).getText();
					activityValues[j-1][k-1] = text;
				}			
			}	
			wait.until(ExpectedConditions.visibilityOf(closeHeaderPopup));
			closeHeaderPopup.click();
			for (String[] ints : activityValues) {
				list_UI.add(Arrays.asList(ints));
			}
		}
	}

	public void getAllCourseExcelActivityList()
	{
		try 
		{
			File file = new File(Students.filePath);
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			List<String[]> header = csvReader.readAll();
			System.out.println(header.size());
			String reportDetails[][] = new String[header.size() - 3][6];
			for(int i = 3; i <= header.size() - 1; i++)
			{
				String []excel = header.get(i);
				String excelData[] = excel[0].split(";");
				for(int j = 10; j <= excelData.length-6; j++)
				{
					reportDetails[i-3][j-10] = excelData[j].replace("\"", "");
				}
			}
			csvReader.close();
			for (String[] ints : reportDetails) {
				list_report.add(Arrays.asList(ints));
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	public void compareDetails()
	{
		try
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String  uiList[][];
			int counter = 0;
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
			List<WebElement> tableRows = driver.findElements(By.xpath(table));
			List<List<String>> list_UI = new ArrayList<>();
			List<List<String>> list_report = new ArrayList<>();
			File file = new File(User.filePath);
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			List<String[]> header = csvReader.readAll();
			int rowCount = tableRows.size();
			uiList = new String[rowCount][16];
			String reportDetails[][] = new String[header.size() - 2][16];
			for (int i= 1; i<= rowCount; i++)
			{
				for(int j = 1; j <= 16; j++)
				{
					String textValue = driver.findElement(By.xpath("(" + table + ")[" + i + "]/td[" + j + "]")).getText();
					uiList[i-1][j-1] = textValue;
				}
			}
			for (String[] ints : uiList) 
			{
				list_UI.add(Arrays.asList(ints));
			}
			for(int i = 1; i < header.size() - 2; i++)
			{
				String []excel = header.get(i+2);
				System.out.println(i);
				String []excelValues = excel[0].split(";");
				for(int j = 0; j <= 15; j++)
				{
					reportDetails[i-1][j] = excelValues[j].replace("\"", "").trim();
				}				
			}
			csvReader.close();
			for (String[] ints : reportDetails) {
				list_report.add(Arrays.asList(ints));
			}
			List<List<String>> differences = new ArrayList<>(list_UI);
			differences.removeAll(list_report);
			Assert.assertTrue(differences.size() == 0);
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void validateHeaderandRecords(DataTable excelHeader)
	{
		try
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String  uiList[][];
			int counter = 0;
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
			List<WebElement> tableRows = driver.findElements(By.xpath(table));
//			List<List<String>> list_UI = new ArrayList<>();
			List<List<String>> list_report = new ArrayList<>();
			File file = new File(User.filePath);
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			List<String[]> header = csvReader.readAll();
			int rowCount = tableRows.size();
			String reportDetails[][] = new String[header.size() - 2][excelHeader.width()];
			
			
			for(int i = 2; i < header.size() ; i++)
			{
//				System.out.println(header.get(0).);
				String []excel = header.get(i);
				System.err.println(excel[0].toString());
//				System.out.println(i);
				String []excelValues = excel[0].split(";");
				for(int j = 0; j <= excelHeader.width()-1; j++)
				{
					reportDetails[i-2][j] = excelValues[j].replace("\"", "").trim();
				}				
			}
			
			  System.out.println(reportDetails.length);
			
				   for(int j=0;j<excelHeader.width();j++)
				   {
					 System.out.println(excelHeader.column(j).get(0)); 
					 System.out.println(excelHeader.width());
					 System.out.println(reportDetails[0][j]);
					 Assert.assertTrue("Header doesnt match Excepted: "+excelHeader.column(j).get(0)+" Actual :"+reportDetails[0][j],excelHeader.column(j).get(0).contains(reportDetails[0][j]));
				     
				   }
			Assert.assertEquals("Record doesnt match Excepted: "+no_of_Record+" Actual :"+(reportDetails.length-1), reportDetails.length-1,no_of_Record);	 
			 
			csvReader.close();
			
	
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	public void compareActivityList()
	{
		List<List<String>> differences = new ArrayList<>(list_UI);
		differences.removeAll(list_report);
		Assert.assertTrue(differences.size() == 0);
	}

	////////////////////////////////////////////////////LMS CASES ////////////////////////////////////////////////////////

	public void validateHeaderLMS()
	{
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			val = pageLoad.getAttribute("class");
			int counter= 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableHeader + "[1]"))));
			List<WebElement> headerList = driver.findElements(By.xpath(tableHeader));

			String[] headerData = new String[headerList.size() - 1];
			for(int i = 2; i <= headerList.size(); i++)
			{
				headerData[i-2] = headerList.get(i-1).getText();
				if(i == 7)
					scrollRight();
			}
			String expectedHeader[] = {"User ID", "Last Name", "First Name", "Curriculum Name", "Curriculum Status", "Available Date",
					"Launched Date","Due Date", "Completed Date", "User Status", "Unit Level", "Unit Name", "Job Title", "Email"};
			for(int i = 0; i <= expectedHeader.length - 1; i++)
			{
				expectedHeader[i] = expectedHeader[i].toUpperCase();
			}
			boolean flag = Arrays.equals(headerData, expectedHeader);
			System.out.println(flag);
			Assert.assertTrue(flag);
		}
		catch(Exception e) {

		}
	}
	public int getHeaderPosition(String header)
	{

		int columnCount = 0;
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
			List<WebElement> tableHeaderRows = driver.findElements(By.xpath(tableHeader));
			for(int i = 1; i <=tableHeaderRows.size(); i++)
			{
				String headerName = driver.findElement(By.xpath(tableHeader + "[" + i +"]")).getText();
				if(headerName.equalsIgnoreCase(header))
				{
					columnCount = i;
					break;				
				}				
			}
			int counter = 0;
			while(columnCount == 0) {
				scrollRight();
				columnCount = getHeaderPosition(header);
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			System.out.println("The column position for " + header +" is " + columnCount);
		}
		catch(Exception e) {

		}
		return columnCount;
	}
}

