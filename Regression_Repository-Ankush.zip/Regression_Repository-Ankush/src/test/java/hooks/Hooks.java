package hooks;

import java.io.FileInputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.ClassUtils;


import com.qa.util.DatabaseConnection;

import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeStep;
import io.cucumber.java.Scenario;
import io.cucumber.plugin.event.EventPublisher;
import io.cucumber.plugin.event.Result;
import io.cucumber.plugin.event.TestCaseFinished;
import stepName.MyTestListener;
import stepName.StepDetails;




public class Hooks {



	DatabaseConnection dc = new DatabaseConnection();
	
	@Before
	public void getScenarioName(Scenario sc) throws Exception
	{   

		/*String scenarioName = sc.getName();
		String featureName = sc.getId();
		System.out.println("Feature file scenario is *********** " + scenarioName);
		String name = FilenameUtils.getName(featureName);
		String result = name.split(":")[0];
		System.out.println("Feature file scenario is *********** " + result);
				try {
			dc.insertExecutionDetails(fn.getValueFromInputPropertyFile("SuitType"),result,scenarioName);
		} catch (Exception e) {
			e.printStackTrace();
		}*/
		
	}


//	@BeforeStep
	public void getStepName(Scenario sc) throws Exception {
		Properties prop1= new Properties();
		FileInputStream fis1 =new FileInputStream(System.getProperty("user.dir")+"/src/test/java/resources/inputs.properties");
		prop1.load(fis1);
		String featureName = sc.getId();
		String name = FilenameUtils.getName(featureName);
		String moduleName = name.split(":")[0];
		try {
			dc.insertExecutionDetails(prop1.getProperty("SuitType"),moduleName,StepDetails.stepName,"");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//	@After
	public void updateScenario(Scenario sc) throws Exception {
		Properties prop1= new Properties();
		FileInputStream fis1 =new FileInputStream(System.getProperty("user.dir")+"/src/test/java/resources/inputs.properties");
		prop1.load(fis1);
		String featureName = sc.getId();
		String name = FilenameUtils.getName(featureName);
		String moduleName = name.split(":")[0];
		try {
			dc.UpdateExecutionEndDate(prop1.getProperty("SuitType"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


}
