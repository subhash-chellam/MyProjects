package runner;


import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;



import io.cucumber.java.After;
import com.qa.util.DatabaseConnection;


import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
//import cucumber.api.CucumberOptions;
import stepName.StepDetails;

//import cucumber.api.junit.Cucumber;

@CucumberOptions(
		features = "src\\test\\java\\features\\",
		glue = {"stepDefinitions"}, 
		monochrome = true,
		plugin= {"pretty","stepName.MyTestListener","stepName.StepDetails","html:target/cucumber.html","json:target/cucumber.json","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"},
		strict  = true,
		dryRun = false
		,	
//	tags ="(@prerequiestCTC or @(which tag to run)) and not (@subdomain)" 
	//-->CTC
//		tags ="(@prerequiestLMS and @(which tag to run)) and not (@subdomain)"
//		-->LMS
		
//	tags ="(@RQIPSmoke) and not (@subdomain)"
		tags ="@LLP-6182"
		)


public class TestRunner  extends AbstractTestNGCucumberTests  {

	@BeforeSuite
	public static void beforeSuite() {
		DatabaseConnection dc = new DatabaseConnection();
		try {
			dc.insertMasterTableDetails();
			//Thread.sleep(10000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@AfterSuite
	public static void afterSuite() {
		DatabaseConnection dc = new DatabaseConnection();
		try {
			dc.UpdateMasterExecutionEndDate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
			
	
	
			
	
}
