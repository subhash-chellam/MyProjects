package stepName;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.logging.FileHandler;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.aventstack.extentreports.ExtentTest;
import com.qa.pages.OrganizationHome;
import com.qa.util.DatabaseConnection;
import com.qa.util.TestBase;
import com.qa.util.TestUtils;

import io.cucumber.plugin.ConcurrentEventListener;
import io.cucumber.plugin.event.EventPublisher;
import io.cucumber.plugin.event.Result;
import io.cucumber.plugin.event.Status;
import io.cucumber.plugin.event.TestCase;
import io.cucumber.plugin.event.TestCaseFinished;


public class MyTestListener implements ConcurrentEventListener {



	@Override
	public void setEventPublisher(EventPublisher publisher) {
		publisher.registerHandlerFor(TestCaseFinished.class, this::handleTestCaseFinished);
	}

	private void handleTestCaseFinished(TestCaseFinished event) {
		TestCase testCase = event.getTestCase();
		Result result = event.getResult();
		Status status = result.getStatus();
		Throwable error = result.getError();
		String errorLog=error==null?"NA":error.toString();
		String scenarioName = testCase.getName();
		String id = "" + testCase.getUri() + "_"+testCase.getLine();
		System.out.println("Testcase " + id + " - " + status.name());
		//System.out.println("Testcase Error:: " + error);
		 boolean append = true;
	       String date = new java.util.Date().toString();
  		date = date.replace(" ", "");
  		date = date.replace(":", "");
  		  LocalDateTime myDateObj = LocalDateTime.now();
		    DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("yyyyMMMdd");

		    String formattedDate = myDateObj.format(myFormatObj);
			 FileHandler handler = null;
				String front="NA",back="NA";
//			 System.out.println(error.toString());
		DatabaseConnection dc = new DatabaseConnection();
		try {
			if(status.name().equalsIgnoreCase("FAILED")) {
				String[] errors = error.toString().split(":");
				handler = new FileHandler("ExceptionandOrgLogFolder\\Exception"+formattedDate+".log", append);
			       String sceanrio = id;
			       sceanrio = sceanrio.split("/")[ sceanrio.split("/").length-1].replace(".feature", "");
			      	 
				        Logger logger = Logger.getLogger("stepName.MyTestListener");
				        logger.setUseParentHandlers(false);
//				        System.setProperty(
//				                "java.util.logging.SimpleFormatter.format",
//				                "[%1$tF %1$tT] [%4$-7s] %5$s %n");    
//				        SimpleFormatter formatter = new SimpleFormatter();  
//				        handler.setFormatter(formatter);  
				        handler.setFormatter(new SimpleFormatter() {
				            private static final String format
				                = "[%1$tF %1$tT] [%2$-7s] %3$s %n";
				 
				            // Override format method
				            @Override
				            public synchronized String format(
				                LogRecord logRecord)
				            {
				                return String.format(
				                    format, new Date(logRecord.getMillis()),
				                    logRecord.getLevel().getLocalizedName(),
				                    logRecord.getMessage());
				            }
				        });
				 
				        logger.addHandler(handler);
						  
				 
				  logger.info("======================"+scenarioName+"======================");
				  if(!(OrganizationHome.exceptionid==null))
				  {
					  logger.info("Org ID: "+OrganizationHome.exceptionid);
					  logger.info("Org Name: "+OrganizationHome.exceptionorg);
				  }
				  logger.info("Exception occured:"+errors[0].trim());
//				  System.out.println(errors.);
				  JavascriptExecutor jse = (JavascriptExecutor)TestBase.driver;
				  jse.executeScript("window.scrollBy(0,-1250)");
				  front=TestBase.takeSnapShot(sceanrio+"Top");
				  logger.info("Screenshot Path Top: "+	front);
				  jse.executeScript("window.scrollBy(0,1250)");
				  back=	TestBase.takeSnapShot(sceanrio+"Bottom");
				  logger.info("Screenshot Path Bottom : "+back);
				  logger.info("==========================================================");
				
//				  final byte[] screenshot = ((TakesScreenshot) TestBase.driver).getScreenshotAs(OutputType.BYTES);
//				  TestBase.	scenario.attach(screenshot, "image/png", "image"); 
     			  TestBase.driver.quit();
				  handler.close();
//				  ExtentTest.
				  
				System.out.println(scenarioName);
				System.out.println(status.name().toString());
				System.out.println(errors[0].trim());
				if(errors.length==1)
				dc.insertExecutionScenarioStatus("Scenario: "+scenarioName.replace("'", ""),status.name().toString(),errors[0],"Error Occured");
				else
				{
					System.out.println(errors[1].trim());
					dc.insertExecutionScenarioStatus("Scenario: "+scenarioName.replace("'", ""),status.name().toString(),errors[0],errors[1]);
							
				}
				
			}else {
				System.out.println(scenarioName);
				System.out.println(status.name().toString());
				dc.insertExecutionScenarioStatus("Scenario: "+scenarioName.replace("'", ""),status.name().toString(),"","");
			}
			 String sceanrio = id;
		       sceanrio = sceanrio.split("/")[ sceanrio.split("/").length-1].split("_")[0];
		
		       if(TestBase.prop.getProperty("excelLog").equals("true"))
		       TestUtils.excel(scenarioName, status.name(), errorLog, sceanrio, OrganizationHome.exceptionid==null?"NA":OrganizationHome.exceptionid+OrganizationHome.exceptionorg, front+"\n"+back,TestBase.prop.getProperty("environment"));
			
		} catch (Exception e) {
			if(handler!=null)
			  handler.close();
			e.printStackTrace();
		}
	}


}
