package stepDefinitions;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.qa.pages.Admin;
import com.qa.pages.OrgMigration;
import com.qa.pages.OrganizationHome;
import com.qa.pages.Students;
import com.qa.pages.User;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class orgMigrationStep 
{
	 private static final Logger logger = LogManager.getLogger(orgMigrationStep.class);

	 OrgMigration orgm;
	OrganizationHome org;

	@Then("navigate to Organization Migration")
	public void navigate_to_OrganizationMigration() 
	{
		
		orgm = new OrgMigration();
		orgm.clickOrganizationMigrationTab();
	}

	@And("Verify the UI has the following columns in Organization Listing")
	 @And("Verify the UI has the following columns in Organization Migration")
		public void verify_the_columns_order_in_Organization(DataTable data) throws Exception 
		{
		 orgm.OrganizationMigrationColumnsValidation(data.asList(),"beforeSearch");
		}
	    
	
	@Then("click on View Report")
	public void clickonViewReport() 
	{
		
		orgm = new OrgMigration();
		orgm.clickviewReportTab();
	}
	
	@Then("click on Schedule Migration Btn")
	public void clickviewscheduleMigrationBtn() 
	{
		
		orgm = new OrgMigration();
		orgm.clickviewscheduleMigrationBtn();
	}
	
	@Then("Select Source Organization")
	public void selectSource() 
	{
		
		orgm = new OrgMigration();
		orgm.selectsourceOrganization();
	}
	@Then("Select Migration Type {string}")
	public void selectMigrationType(String MigrationType) 
	{
		
		orgm = new OrgMigration();
		orgm.selectmigration_type(MigrationType);
	}
	@Then("Select Target Organization")
	public void selecttarget() 
	{
		
		orgm = new OrgMigration();
		orgm.selecttargetOrganization();
	}

	@Then("Click on Migrate All User")
	public void clickonMigrateAllUser() 
	{
		
		orgm = new OrgMigration();
		orgm.migrateAllUsersclick();
	}
	
	

	@Then("Click on All Courses")
	public void clickonAllCourses() 
	{
		
		orgm = new OrgMigration();
		orgm.allcoursesclick();
	}
	@Then("Check if Submit is not disabled")
	public void clickonSubmit() 
	{
		
		orgm = new OrgMigration();
		orgm.clickonsubmitBtn();
	}
	
	
	@Then("Check if rollback is available")
	public void clickonrollback() 
	{
		
		orgm = new OrgMigration();
		orgm.clickonrollbackBtn();
	}
	
	
	@Then("Check if Cancel is not disabled")
	public void clickonCanceldisabled() 
	{
		
		orgm = new OrgMigration();
		orgm.clickonrollbackBtn();
	}
	@Then("Select units {string}")
	public void selectUnit(String unit) 
	{
		
		orgm = new OrgMigration();
		orgm.selectUnits(unit);
	}
	
	@Then("Select Courses {string}")
	public void selectCourse(String Course) 
	{
		
		orgm = new OrgMigration();
		orgm.selectCourse(Course);
	}

	@Then("Validate Data {string}")
	public void validatedata(String Course) 
	{
		
		orgm = new OrgMigration();
		orgm.validatedetails(Course);
	}
	
	@Then("Validate Organization")
	public void validatedOrganization() 
	{
		
		orgm = new OrgMigration();
		orgm.validateorg();
	}

	
}
