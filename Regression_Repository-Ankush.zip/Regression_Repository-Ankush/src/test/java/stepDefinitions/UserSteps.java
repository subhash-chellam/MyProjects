package stepDefinitions;

import java.util.Map;

import org.junit.Assert;

import com.qa.pages.AssignmentReport;
import com.qa.pages.Assignments;
import com.qa.pages.Compliance;
import com.qa.pages.OrganizationAccess;
import com.qa.pages.OrganizationHome;
import com.qa.pages.OrganizationSetting;
import com.qa.pages.OrganizationSettings;
import com.qa.pages.Student;
import com.qa.pages.Students;
import com.qa.pages.User;
import com.qa.util.TestBase;
import com.qa.util.reuseableCode;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class UserSteps
{
	
	User usr=new User();
	OrganizationHome org;
	OrganizationSettings orgSet;
	OrganizationAccess orgAcc;
	Students std;
	Assignments assign;
	Compliance comp;

	@Then("click on user create button")
	public void click_on_user_create_button() 
	{
		usr = new User();
		usr.clickCreateUser();
	}

	@Then("create and verify user {string} {string} {string} with alphabetic Email")
	public void create_and_verify_user_with_alphabetic_email(String fname, String lName, String id) 
	{
		if(usr == null)
			usr = new User();
		org = new OrganizationHome();
		usr.enterUserDetailsAlphabeticEmail(fname, lName, id);
	    usr.clickOnSubmit();
	    org.validateSucessMesssage();
	}
	

	@Then("view and edit the user email details")
	public void view_and_edit_the_user_email_details() 
	{
	    usr.viewAndEditUserEmail();
	}

	@Then("User create another group")
    public void user_create_another_group()
    {
        if(org == null)
        	org = new OrganizationHome();
        orgSet=new OrganizationSettings();
        orgSet.clickOnCreateGroup();
        orgSet.enterOtherGroupDetails();
        orgSet.clickOnCreate();
        org.validateSucessMesssage();
    }
    
    @Then("User search another group")
    public void user_search_another_group()
    {
        orgSet.searchOtherGroupName();
        orgSet.validateAnotherSearchResult();
    }
	@Then("create and verify user {string} {string} with unit level {int}")
    public void create_and_verify_user_with_unit_level(String fname, String lName, Integer level)
    {
        if(usr == null)
            usr = new User();
        org = new OrganizationHome();
        usr.enterUserDetailsWithUnitLevel(fname, lName, level);
        usr.clickOnSubmit();
        org.validateSucessMesssage();
    }
	
	@Then("create and verify user {string} {string} with unit level {int} and Hire Date")
    public void create_and_verify_user_with_unit_level_with_and_hire_date(String fname, String lName, Integer level)
    {
        if(usr == null)
            usr = new User();
        org = new OrganizationHome();
        usr.enterUserDetailsWithUnitLevel(fname, lName, level);
        usr.clickOnSubmit();
        org.validateSucessMesssage();
    }
	@Then("inactivate the searched user")
	public void inactivate_the_searched_user() 
	{
		if(usr == null)
		{
			usr = new User();
		}
		usr.applyMoreFilter();
		usr.setInactive();
	}
	
	@Then("inactivate the searched users")
	public void inactivate_the_searched_users() 
	{
		if(usr == null)
		{
			usr = new User();
		}
		usr.applyMoreFilter();
		usr.setInactives();
	}
	@Then("update the report with user count {int}")
	public void update_the_lms_report(int count) 
	{
		if(usr == null)
		{
			usr = new User();
		}
	    usr.addFileData_LMS(count);
	}
	@Then("get the user details from view user page")
	public void get_the_user_details_from_view_user_page() 
	{
		if(usr == null)
			usr = new User();
	    usr.viewUser();
	    usr.getUserDetails();
	}
	@Then("click on edit assignment link")
	public void click_on_edit_assignment_link() 
	{
	    usr.editSubAssignments();
	}

	@Then("navigate to assignment tab from user page")
	public void navigate_to_assignment_tab_from_user_page() 
	{
	    usr.clickAssignmentTabUserPage();
	}
	@Then("navigate to remove assignment popup")
	public void navigate_to_remove_assignment_popup()
	{
		if(usr == null)
			usr = new User();
		usr.checkAllUser();
		usr.clickAllActionItem();
		usr.selectRemoveAssignmentOption();
	}
	@Then("validate the assignment remove popup with {string} {int} {string}")
	public void validate_the_assignment_remove_popup_with(String message, Integer count, String courses) 
	{
	    usr.validateRemoveAssignmentPopupMessage(message);
	    usr.validateCourseCountRemoveAssignmentPopup(count);
	    if(courses.length() > 0)
	    {
	    	usr.validateCourseListRemoveAssignmentPopup(courses);
	    	usr.clickRemoveAssignmentButton();
	    }
	    usr.closeRemoveAssignmentButton();
	}
	@Then("add assignment to all user as per name {string}")
	public void add_assignment_to_all_user_as_per_name(String courseName) 
	{
		if(usr == null)
			usr = new User();
		String course[] = courseName.split(",");
		for(int i = 0; i <= course.length - 1; i++)
		{
			usr.checkAllUser();
			usr.clickAllActionItem();
			usr.selectAddAssignmentPerNameForAll(course[i]);
		}		
	}
	
	@Then("add assignment to searched user")
	public void add_assignment_to_all_useras_per_name() 
	{
		if(usr == null)
			usr = new User();
	
			usr.checkAllUser();
			usr.clickAllActionItem();
			usr.selectAddAssignmentPerNameForAll();
				
	}
	@Then("remove assignment from all user as per name {string} {string}")
	public void remove_assignment_from_all_user_as_per_name(String courseName, String expectedMessage) 
	{
		if(usr == null)
			usr = new User();
		usr.checkAllUser();
		usr.clickAllActionItem();
		usr.selectRemoveAssignmentForAll(courseName);
		usr.validateErrorMessageForActivatedCourse(expectedMessage);
	}
	@Then("validate action dropdown not displayed")
	public void validate_action_dropdown_not_displayed() 
	{
	    if(usr == null)
	    	usr = new User();
	    usr.validateActionDropdownNotDisplayed();
	}

	@Then("Clear Search in User")
	public void clearSearch_user() 
	{
	    usr.clearSearch();
	}
//	@Then("create and verify user {string} {string} {string}")
//	public void create_and_verify_user(String fname, String lName, String id) 
//	{
//		if(usr == null)
//			usr = new User();
//		org = new OrganizationHome();
//		
//		
//		usr.enterUserDetails(fname, lName, id);
//	    
//		usr.clickOnSubmit();
//	    org.validateSucessMesssage();
//	}
	@Then("click on edit user from view user page")
	public void click_on_edit_user_from_view_user_page() 
	{
	    usr.clickEditUserFromViewPage();
	}

	@SuppressWarnings("static-access")
	@Then("create and verify user {string} {string} {string}")
	public void create_and_verify_user(String fname, String lName, String id) 
	{
		if(usr == null)
			usr = new User();
		org = new OrganizationHome();
		
		
		usr.enterUserDetails(fname, lName, id+usr.getuserNumber());
		usr.clickOnSubmit();
	    org.validateSucessMesssage();
	    usr.usrEmail=null;
	}
	
	@Then("create same user {string} {string} {string} in another org")
	public void create_and_verify_usersame(String fname, String lName, String id) 
	{
		if(usr == null)
			usr = new User();
		org = new OrganizationHome();
		
		
		usr.enterUserDetailssameuser(fname, lName, id+usr.getuserNumber());
//		usr.clickOnSubmit();
	    org.validateexistMesssage();
	    usr.usrEmail=null;
	}
	
	@Then("create and verify user {string} {string} {string} level {string} unitlevel {string}")
	public void create_and_verify_user(String fname, String lName, String id,String level,String unitlevel) 
	{
		if(usr == null)
			usr = new User();
		org = new OrganizationHome();
		
		
		usr.enterUserDetails(fname, lName, id+usr.getuserNumber(),level,unitlevel);
		usr.clickOnSubmit();
	    org.validateSucessMesssage();
	   
	}
	
	@Then("create and verify user {string} {string} {string} level {string} save unitlevel {string}")
	public void create_and_verify_user_save_unitlevel(String fname, String lName, String id,String level,String unitlevel) 
	{
		if(usr == null)
			usr = new User();
		org = new OrganizationHome();
		if(AssignmentReport.checkifParmeterAvailable(unitlevel+TestBase.prop.get("environment")))
			unitlevel=AssignmentReport.getParmeterAvailable(unitlevel+TestBase.prop.get("environment"));
      
		
		System.out.println(unitlevel);
		
		reuseableCode.waitforsec(4);
		usr.enterUserDetails(fname, lName, id+usr.getuserNumber(),level,unitlevel);
		reuseableCode.waitforsec(3);
		usr.clickOnSubmit();
	    org.validateSucessMesssage();
	   
	}
	
	
	@Then("Get details Email Id")
	public void create_andverify_user() 
	{
		if(usr == null)
			usr = new User();
		org = new OrganizationHome();
		usr.existingEmailID();
		
	}
	
	

	@Then("Get details Admin Email Id")
	public void Get_details_Admin_Email_Id() 
	{
		if(usr == null)
			usr = new User();
		org = new OrganizationHome();
		
		
		usr.AdminOrgEmailid();
		
	}
	
	@Then("Get details Login Email Id")
	public void create_anerify_user() 
	{
		if(usr == null)
			usr = new User();
		org = new OrganizationHome();
		
		
		usr.loginEmailID();
		
	}
	
	
	@Then("Level should notlevel {string} unitlevel {string}")
	public void create_and_verify_user(String level,String unitlevel) 
	{
		if(usr == null)
			usr = new User();
		org = new OrganizationHome();
		
		
		usr.checklevelnotavalible(level,unitlevel);
		usr.clickOnSubmit();
	    org.validateSucessMesssage();
	    usr.usrEmail=null;
	}
	@Then("create and verify Existing user")
	public void create_and_verify_user() 
	{
		if(usr == null)
			usr = new User();
		org = new OrganizationHome();
		
		
		usr.enterUserDetail(Students.firstName, Students.lastName,Students.email);
		usr.clickOnSubmit();
	    org.validateSucessMesssage();
	    usr.usrEmail=null;
	}
	
	@Then("Existing user data")
	public void useremail() 
	{
		if(usr == null)
			usr = new User();
		org = new OrganizationHome();
		
		
	    usr.userEmail=usr.existingUser;
	}
	
	@Then("create and verify user with symbol {string} {string} {string} {string}")
	public void create_and_verify_user_with_symbol(String fname, String lName, String id, String symbol) 
	{
		if(usr == null)
			usr = new User();
		org = new OrganizationHome();
		usr.enterUserDetailsWithSymbols(fname, lName, id, symbol);
	    usr.clickOnSubmit();
	    org.validateSucessMesssage();
	}
	
	@Then("Delete the user")
	public void Delete_the_user()
	{
		usr.deleteUserDetails();
	}
	
	@Then("delete the multiple user {int}")
	public void Delete_the_multiple_user(int count)
	{
		if(usr == null)
			usr = new User();
		for(int i = 0; i <= count-1; i++)
		{
			usr.deleteUserDetailsWithoutAssertion();
		}
		
	}
	
	@Then("Delete the user if available")
	public void Delete_the_user_if_available()
	{
		if(usr == null)
			usr = new User();
		int count = usr.rowsAvailable();
		System.out.println("Rows avaialble on user page " + count);
		if(count >= 1)
		{
			for(int i = 0; i <= count-1; i++)
			{
				usr.deleteUserDetailsWithoutAssertion();
			}
		}
		
	}
	
	
	
	@Then("download report")
	public void download_report() 
	{
		if(usr == null)
		{
			usr = new User();
		}
		std = new Students();
		comp = new Compliance();
		boolean flag = comp.checkCSVFilePresent();
		if(flag == true)
			std.deleteFile(Students.filePath);
		usr.clickImportData();
		std.clickOnDownloadFile();
	}
	
	@Then("update the optional report with existing group {string}")
	public void update_the_optional_report_with_existing_group(String name) {
		std.updateOptionalReportExitingGroup(name);
	}
	
	  @Then("update the report with multiple validations for level {int}")
	    public void update_the_report_with_duplicate_data_for_level(Integer level)
	    {
	        if(usr == null)
	            usr = new User();
	        usr.prepareFileForMultipleValidation(level);
	    }
	  @Then("upload the report for multiple validations for lms")
	    public void upload_the_report_for_multiple_validationslms()
	    {
	        if(std == null)
	            std = new Students();
	        std.uploadFileForMultipleValidationslms();
	    }
	
	  
	  @Then("upload the report for multiple validations")
	    public void upload_the_report_for_multiple_validations()
	    {
	        if(std == null)
	            std = new Students();
	        std.uploadFileForMultipleValidations();
	    }
	@Then("search the created user")
	public void search_the_created_user() 
	{
		if(usr == null)
		{
			usr = new User();
		}
		usr.userSearch(User.userId);
	}
	
	@Then("search the saved user in file {string} activate the user")
	public void search_the_created_userinfile(String user) 
	{
		if(usr == null)
		{
			usr = new User();
		}
		   usr.applyMoreFilter();
	        
		usr.usersearchEmailwithoutclearing(AssignmentReport.getParmeterAvailable(user+TestBase.prop .get("environment")));
		usr.setActive();
	}
	@Then("Applying filter both active and inactive")
	public void applying_filter_both_active_and_inactive() {
		if(usr == null)
		{
			usr = new User();
		}
		usr.applyMoreFilter();
		
	}
	@Then("search the created user {string}")
	public void search_the_created_user(String userID) 
	{
		if(usr == null)
		{
			usr = new User();
		}
		usr.userSearchemail(userID);
	}
	@Then("edit the user email Id")
	public void edit_the_user_EmailId() 
	{
	    usr.editUserDetails();
		usr.editUserEmailId();
		org.validateSucessMesssage();
	}
	@Then("search the using email")
	public void search_the_using_email() 
	{
		if(usr == null)
		{
			usr = new User();
		}
//		usr.usersearchEmail("20221014123610010@yopmail.com");
//		User.userEmail="20221014123610010@yopmail.com";

		usr.usersearchEmail(User.userEmail);
	}
	@Then("search the using email without Clearing")
	public void search_the_using_email_withoutClearing() 
	{
		if(usr == null)
		{
			usr = new User();
		}
		usr.usersearchEmailwithoutclearing(User.userEmail);
	}
	
	
	@Then("Select Level {string} option {string} and Role {string}")
	public void edit_the_user_details(String leve,String option,String role) throws InterruptedException 
	{
		
	    usr.addAdminAccess(leve, option, role);;
	    
	}
	@Then("edit the user details")
	public void edit_the_user_details() 
	{
	    usr.editUserDetails();
	}
	
	
	
	@Then("Check if Add Admin Access not available")
	public void checkifAddAdmin() 
	{
		if(usr == null)
		{
			usr = new User();
		}
	    usr.addAdminAccessisnotAvailable();
	}
	@Then("edit the user details {string}")
	public void edit_the_userdetails(String space) 
	{
		if(usr == null)
		{
			usr = new User();
		}
	    usr.editUserDetails(space);
	}
	@Then("Click on Edit User")
	public void edit_the_user_detail() 
	{
	    usr.navigateandEditUser();
	}
	
	@Then("unenroll the Course")
	public void unenroll_the_Course() 
	{
	    usr.navigateandEditUser();
	    usr.navigateAssigmentUnenroll();
	    
	}
	@Then("unenroll all recurrence assignments")
	public void unenroll_all_recurrence_assignments() 
	{
		  usr.navigateandEditUser();
	    usr.unenrollAllRecurenceAssignments();
	}
	
	
	@Then("Validate assignment if assignment is not displayed")
	public void validateAssignment() 
	{
	     usr.validateifAssigmentNamedisplay();
	    
	}
	
	
	@Then("Validate if no record found")
	public void validatenoAssignment() 
	{
	     usr.validateifnorecordisplayed();
	    
	}
	
	@Then("unenroll the Course {string} for LMS org")
	public void unenroll_theCourse(String course) 
	{
	    usr.navigateandViewCourse();
	    usr.navigateAssigmentUnenrollLMS(course);
	    
	}
	
	@Then("unenroll button should not display for the Course {string} for LMS org")
	public void unenroll_heCourse(String course) 
	{
	    usr.navigateandViewCourse();
	    usr.Unenrollbtnshouldshouldbeavalble(course);
	    
	}
	
	
	
	@Then("Click on edit user details")
	public void edit_theuser_detail() 
	{
		usr=new User();
	    usr.navigateEditUser();
	}
	
	@Then("view and edit the user details")
	public void view_and_edit_the_user_details() 
	{
	    usr.viewAndEditUser();
	}
	
	@Then("view and edit the user detail validate the message {string}")
	public void view_and_edit_the_user_details(String msg) 
	{
	    usr.viewAndEditUser(msg);
	}
	@Then("view and validate user detail")
	public void view_and_edit_the_user_details(DataTable table) 
	{
	    usr.viewdetails();
	    for(int i=0;i<table.width();i++)
	    	usr.validateUserDetails(table.column(i).get(1));
			
	 
	}
	
	@Then("Edit button should not existing the user details page and in action drop down")
	public void viewand_editthe_user_details() 
	{
	    usr.viewUserBtn();
	}
	
	@Then("Delete Admin Access")
	public void delete_admin_access() throws InterruptedException {

		usr.deleteAdmin();
		
	}
	
	@Then("Delete all Access for {string}")
	public void delete_all_access(String levl) throws InterruptedException {

		if(usr == null)
		{
			usr = new User();
		}
		orgSet = new OrganizationSettings();
		orgSet.viewAutomatedUnit(levl);
			usr.deleteacess();
		
	}
	
	

	@Then("Click on Add Admin Access")
	public void Click_on_Add_Admin_Access() 
	{
	    usr.clickonaddAdmin();
	    
	    OrganizationSteps.name=usr.orid;
	    System.out.println( OrganizationSteps.name);
	}
	@Then("Click on Add Admin Access Btn")
	public void Click_on_Add_Admin_Access_Btn() 
	{
	    usr.clickonaddAdminBtn();
	    
	    OrganizationSteps.name=usr.orid;
	    System.out.println( OrganizationSteps.name);
	}
	
	
	
	@Then("activate and inactivate the user")
	public void activate_and_inactivate_the_user() 
	{
		if(usr == null)
		{
			usr = new User();
		}
		usr.applyMoreFilter();
		usr.setInactive();
		usr.setActive();
	}
	
	@Then("search user then activate validate the message {string} and inactivate validate the message {string}")
	public void search_user_activate_and_inactivate_the_user(String msg1,String msg2) 
	{
		if(usr == null)
		{
			usr = new User();
		}
		usr.applyMoreFilter();
		usr.usersearchEmailwithoutclearing(User.userEmail);
		usr.setInactive(msg1);
		usr.usersearchEmailwithoutclearing(User.userEmail);
		usr.setActive(msg2);
	}
	@Then("search user then activate validate the message {string} and inactivate validate the message {string} for lms")
	public void search_user_activate_and_inactivate_the_user_for_LMS(String msg1,String msg2) 
	{
		if(usr == null)
		{
			usr = new User();
		}
		usr.applyMoreFilter();
		usr.usersearchEmailwithoutclearing(User.userEmail);
		usr.setInactives(msg1);
		usr.usersearchEmailwithoutclearing(User.userEmail);
		usr.setActives(msg2);
	}
	
	@Then("inactivate the user")
	public void inactivate_the_user() 
	{
		if(usr == null)
		{
			usr = new User();
		}
		usr.applyMoreFilter();
		usr.setInactive();
	}
	
	@Then("add and remove from the group")
	public void add_and_remove_from_the_group() 
	{
		if(usr == null)
		{
			usr = new User();
		}
	    orgSet = new OrganizationSettings();
	    orgAcc = new OrganizationAccess();
	    orgAcc.navigateOrgSetting();
	    orgSet.navigateGroup();
	    orgSet.clickOnCreateGroup();
	    orgSet.enterGroupDetails();
	    orgSet.clickOnCreate();
	    usr.addGroup(OrganizationSettings.groupName);
	    usr.removeGroup();
	}
	
	@Then("add assignment to user")
	public void add_assignment_to_user() 
	{
		org =new OrganizationHome();
	    usr.addAssignment();
	    assign = new Assignments();
	    assign.assignmentFromUser();
	    assign.createAssignment();
	    org.validateSucessMesssage();
	    usr.validAssignmentAdded();
	}
	
	@Then("remove assignment from user")
	public void remove_assignment_from_user() 
	{
	    usr.removeAssignment();
	    usr.validAssignmentRemoved();
	    usr.deleteUserDetails();
	}
	
	@Then("remove assignment and Delete user also validate message {string}")
	public void remove_assignment_from_user(String msg) 
	{
	    usr.removeAssignment();
	    usr.validAssignmentRemoved();
	    usr.deleteUserDetails(msg);
	}
	
	@Then("Delete user also validate message {string}")
	public void Delete_from_user(String msg) 
	{
	    usr.deleteUserDetails(msg);
	}
	
	@Then("validate Action is not displayed for LMS")
	public void validate_Action_is_not_displayed_forLMS() 
	{
		if(usr == null)
		{
			usr = new User();
		}
	    usr.validateActionButton();
	   
	}
	
	@Then("remove group from user")
	public void add_and_removefrom_the_group() 
	{
		if(usr == null)
		{
			usr = new User();
		}
	   
	    usr.removeGroup();
	}

	@Then("add multiple assignment to user {int}")
	public void add_multiple_assignment_to_user(int count) 
	{
		if(usr == null)
		{
			usr = new User();
		}
		assign = new Assignments();
		usr.userMultipleAssgnment(org, assign, count);
	}
	
	@Then("add multi user with one assignment each {int}")
	public void add_multi_user_with_one_assignment_each(int count) 
	{
		assign = new Assignments();
		usr = new User();
		org = new OrganizationHome();
		usr.multiUserEachAssignment(org, assign, count);
	}
	

	@Then("validate the child functionality")
	public void validate_the_child_functionality() 
	{
	    if(usr == null)
	    	usr = new User();
	    usr.viewChildUser();
	    usr.viewTrainingCertificate();
	}

	@Then("view the user details")
	public void view_the_user_details() 
	{
		   if(usr == null)
		    	usr = new User();
		
	    usr.viewUser();
	}
	

	@Then("Edit btn is not available in the user details")
	public void view_the_ser_details() 
	{
	    usr.editisnotavailable();
	}
	
	@Then("Add Assigment btn is not available in the user details")
	public void view_the__details() 
	{
	    usr.addAdminAccessisnotAvailable();
	}

	@Then("Edit Assignment btn and unenroll is not available in the user details")
	public void view_thedetails() 
	{
	    usr.editandunenrolloption();
	}
	

	@Then("view Assignment btn and View Activity Details is available in the user details")
	public void view_hedetails() 
	{
	    usr.viewDetailViewAssigmentoption();
	}
	
	@Then("Click on View Activity Details for course {string} the user details")
	public void Click_on_View_Activity_Details_is_available_in_the_user_details(String course) 
	{
	    usr.viewDetailViewcourse(course);
	}
	
	@Then("Validate Activity Detail {string}")
	public void Validate_Activity_Detail(String course) throws InterruptedException 
	{
	    usr.validateDetailTable(course);
	}
	
	@Then("Validate Activity Detail {string} in Student Tab")
	public void Validate_Activity_Detail_Student_Tab(String course) throws InterruptedException 
	{
		  if(usr == null)
		    	usr = new User();
	
	    usr.validateDetailTableStudent(course);
	}
	@Then("Validate Assignments Detail {string}")
	public void Validate_Assignments_Detail(String course) throws InterruptedException 
	{
	    usr.validateDetailTable(course);
	}  
	
	@And("verify the columns order in Assignments Report")
	public void verify_the_columns_order_in_compliance_Report(DataTable data) throws Exception 
	{
		   if(usr == null)
		    	usr = new User();
		
		usr.assignmentReportColumnsValidation(data.asList(),"beforeSearch");
	}
	@Then("Validate Assignments Report in Table {string}")
	public void Validate_AssignmentsDetail(String table) throws InterruptedException 
	{
			OrganizationHome	orgHome = new OrganizationHome();
			   if(usr == null)
			    	usr = new User();
			   
			   
			for(int i=0;i<table.split(",").length;i++)
			{
			String	tabledata=table.split(",")[i];
				
				if(orgHome.getTableValidation(tabledata)==null)
			 usr.validateDetailAssignmentTable(tabledata);
			else
				usr.validateDetailAssignmentTable(orgHome.getTableValidation(tabledata));
			}
				
	}  
//	Paginationoptions
	
	@Then("Pagination Number {string} and align {string}")
	public void view_the_se_details(String number,String align) 
	{
		   if(usr == null)
		    	usr = new User();
	    usr.Paginationoptions(align,number);
	}
	@Then("Row per Number {string}")
	public void Row_per_Number(String number) 
	{
		   if(usr == null)
		    	usr = new User();
	    usr.RowperNumber(number);
	}
	@Then("navigate Assigment")
	public void view_the_se_details() 
	{
	    usr.navigateAssigment();
	}
	@Then("navigate Certificates")
	public void view_the_e_details() 
	{
	    usr.navigateCertificates();
	}
	@Then("validate the unit name {int}")
	public void validate_the_unit_name(int count) 
	{
	    usr.validateUnitName(count);
	}
	

	@Then("navigate group")
	public void viewthe_se_details() 
	{
	    usr.navigateGroup();
	}
	@Then("update the invalid report")
	public void update_the_invalid_report() 
	{
	    std.updateInvalidReport();
	}
	
	@Then("upload the invalid report")
	public void upload_the_invalid_report() 
	{
	    std.uploadInavlidFile();
	}

	@Then("update the optional report {int} without level")
	public void update_the_optional_report_level(int count) 
	{
	    std.updateOptionalReportwithoutlevel(count);
	}
	@Then("update the optional report {int} with same job title")
	public void update_the_optional_reportlevel(int count) 
	{
	    std.updateOptionalReportwithotlevel(count);
	}
	
	
	@Then("update the optional report with blank job title")
	public void update_the_optional_report_level() 
	{
	    std.updateOptionalReportwithoutlevelblankjobtitle(1);
	}
	@Then("update the optional report with hire date {int}")
	public void update_the_optional_report_with_hire_date(int count) 
	{
		if(std == null)
			std = new Students();
	    std.updateOptionalReportHireDate(count);
	}
	
	@Then("validate the Job Title {int}")
	public void validate_the_job_title(int count) 
	{
	    usr.validateJobTitle(count);
	}

	@Then("upload same file again")
	public void upload_same_file_again() 
	{
		if(usr == null)
		{
			usr = new User();
		}
		std = new Students();
		usr.clickImportData();
		
		std.readandUpdateFle();
		std.uploadFile();
	}
	
	@Then("validate the user count {int}")
	public void validate_the_user_count(int count) 
	{
		if(usr == null)
		{
			usr = new User();
		}
	    usr.getRowCount(count);
	}
	
	@Then("validate the user count {int} in Manage Students screen")
	public void validate_the_user_countlms(int count) 
	{
		if(usr == null)
		{
			usr = new User();
		}
	    usr.getRowCountLMS(count);
	}
	
	@Then("validate no record found in Manage Students screen")
	public void validate_the_usercountlms() 
	{
		if(usr == null)
		{
			usr = new User();
		}
	    usr.validatenorecordfound();
	}
	@Then("validate the group filter count as {int}")
	public void validate_the_group_filter_count_as(Integer count) 
	{
		if(usr == null)
	    	usr = new User();
		usr.validateGroupFilterAvailabilityCount(count);
	}
	@Then("validate all filters available on user page")
	public void validate_all_filters_available_on_user_page()
	{
		if(usr == null)
	    	usr = new User();
		usr.validateFiltersUserPage();
	}
	@Then("validate group filter is available with groups")
	public void validate_group_filter_is_available_with_groups() 
	{
		if(usr == null)
	    	usr = new User();
		usr.validateGroupFilterAvailable();
	}
	@Then("validate the text of group filter {string}")
	public void validate_the_text_of_group_filter(String message) 
	{
		if(usr == null)
	    	usr = new User();
		usr.validateGroupFilterText(message);
	}
	@Then("validate group filter is available")
	public void validate_group_filter_is_available() 
	{
		if(usr == null)
	    	usr = new User();
		usr.validateGroupFilterDisplayed();
	}
	@Then("validate the org name as per level {int} on main filter {int}")
	public void validate_the_org_name_as_per_level_on_main_filter(Integer level, int unit) 
	{
		if(usr == null)
	    	usr = new User();
		usr.validateUnitLevelMainFilter(level, unit);
	}
	@Then("validate the group remove popup with {string} {int} {string}")
	public void validate_the_group_remove_popup_with(String message, Integer count, String groups) 
	{
		usr.validateRemoveGroupPopupMessage(message);
	    usr.validateCourseCountRemoveGroupPopup(count);
	    if(groups.length() > 0)
	    {
	    	usr.validateCourseListRemoveGroupPopup(groups);
	    	usr.clickRemoveGroupButton();
	    }
	    usr.closeRemoveGroupButton();
	}
	
	@Then("remove group for all user")
	public void remove_group_for_all_user() 
	{
	    	usr.validateCourseListRemoveGroupPopup(OrganizationSettings.groupName);
	    	usr.clickRemoveGroupButton();
	}
	@Then("change the pagination to {string} and validate the user count")
	public void change_the_pagination_and_validate_the_count(String expectedCount) 
	{
		 if(usr == null)
		    	usr = new User();
	    usr.validatePaginationDropdown(expectedCount);
	    usr.validateUserCountPerPage(expectedCount);
	}
	
	@Then("navigate to add group popup")
	public void navigate_to_add_group_popup() 
	{
		if(usr == null)
			usr = new User();
		usr.checkAllUser();
		usr.clickAllActionItem();
		usr.selectAddGroupOption();
	}
	@Then("apply the select all filter for user status")
	public void apply_the_filter_for_inactive_user() 
	{
		if(usr == null)
		{
			usr = new User();
		}
		usr.applyMoreFilter();
	}
	
	@Then("validate the user report data")
	public void validate_the_user_report_data() 
	{
		if(usr == null)
			usr = new User();
	    usr.validateDetails();
	}

	@Then("click on next button on user page")
	public void click_on_next_button_on_user_page() 
	{
		if(usr == null)
	    	usr = new User();
		usr.clickNextButton();
	}
	@Then("sort user details by user Id")
	public void sort_user_details_by_user_id() 
	{
		if(usr == null)
	    	usr = new User();
		usr.clickUserIdHeader();
	}
	
	
	@Then("validate the user details with exported file from user page")
	public void validate_the_user_details_with_exported_file_from_user_page() 
	{
		if(usr == null)
	    	usr = new User();
		usr.getAllUserUIList();
		usr.getAllUserExcelList();
		usr.compareActivityList();
	}
	

	@Then("validate the user details with exported file from user page for lms")
	public void validate_the_user_details_with_exported_file_from_user_page_lms() 
	{
		if(usr == null)
	    	usr = new User();
		usr.getAllUserUIListlms();
		usr.getAllUserExcelList();
		usr.compareActivityList();
	}
	@Then("export report")
	public void export_report() 
	{
		std = new Students();
		if(usr == null)
			usr = new User();
		boolean flag = usr.checkCSVFilePresent();
		if(flag == true)
			std.deleteFile(Students.filePath);
		usr.clickExportButton();
		usr.verifyDownloadFile();
	}
	@Then("validate seach bar for each dropdown in more filter options")
	public void validate_seach_bar_for_each_dropdown_in_more_filter_options() 
	{
		if(usr == null)
	    	usr = new User();
		usr.validateUnitLevelFilterAvailability();
		usr.validateJobTitleFilterAvailability();
	}
	@Then("validate the unit level filter {int} validation {string}")
	public void validate_the_unit_level_filter_validation(int level,String unitName) 
	{
		if(usr == null)
	    	usr = new User();
		usr.searchUnitLevelFilter(level - 1,unitName);
		usr.clickMoreFilterSearch();
	}
	@Then("validate the user count applying user status {int}")
	public void validate_the_user_count_applying_user_status(int count) {
		if(usr == null)
	    	usr = new User();
		usr.validateUserCount(count);
		usr.clickMoreFilterClearSearch();
	}
	@Then("unselect the all unit from level {int} under more filter")
	public void unselect_the_all_unit_from_level_under_more_filter(Integer unit) 
	{
		if(usr == null)
	    	usr = new User();
	
		usr.unselectUnitLevelFromMoreFilter(unit - 1);
	}
	
	@Then("validate the job title filter {int} validation {string}")
	public void validate_the_job_title_filter_validation(int level,String unitName) throws InterruptedException 
	{
		if(usr == null)
	    	usr = new User();
		String name[] = unitName.split(",");
		for(int i = 0; i <= name.length - 1; i++)
		{
			usr.searchJobTitleFilter(level,name[i]);
		}
		
		usr.clickMoreFilterSearch();
	}
	@Then("validate the job title filter {int}")
	public void validate_the_job_title_filter_validation(int level) throws InterruptedException 
	{
		if(usr == null)
	    	usr = new User();
		 	
			usr.searchJobTitleFilter(level,OrganizationSettings.titleName);
		
		usr.clickMoreFilterSearch();
	}
	@Then("validate the group filter {int}")
	public void validate_the_group_title_filter_validation(int level) 
	{
		if(usr == null)
	    	usr = new User();
		 	
			usr.searchGroupFilter(level,OrganizationSettings.groupName);
		
		usr.clickMoreFilterSearch();
	}
	
	
	@Then("validate the from hire date as {string}")
	public void validate_the_from_hire_date_as(String date) 
	{
		if(usr == null)
	    	usr = new User();
		usr.validateFromHireDate(date);
	}
	
	@Then("validate the to hire date as {string}")
	public void validate_the_to_hire_date_as(String date) 
	{
		if(usr == null)
	    	usr = new User();
		usr.validateToHireDate(date);
	}
	@Then("click clear search on user page")
	public void click_clear_search_on_user_page() 
	{
		if(usr == null)
	    	usr = new User();
		usr.clickUserClearSearch();
	}
	@Then("click search button on user page")
	public void click_search_button_on_user_page() 
	{
		if(usr == null)
	    	usr = new User();
		usr.clickUserSearch();
	}
	@Then("enter the to hire date with {int} {string}")
	public void enter_the_to_hire_date_with(Integer num, String time) 
	{
		if(usr == null)
	    	usr = new User();
		usr.enterToHireDate(num, time);
	}
	
	@Then("enter the from hire date with {int} {string}")
	public void enter_the_from_hire_date_with(Integer num, String time) 
	{
		if(usr == null)
	    	usr = new User();
		usr.enterFromHireDate(num, time);
	}
	@Then("validate job filter is displayed in more filter options")
	public void validate_job_filter_is_displayed_in_more_filter_options() 
	{
		if(usr == null)
	    	usr = new User();
		usr.validateJobLevelFilterAvailable();
	}
	@Then("select the unit level {int} filter under more filter {string}")
	public void select_the_unit_level_filter_under_more_filter(Integer level, String unitName) 
	{
		if(usr == null)
	    	usr = new User();
		usr.searchUnitLevelFilter(level - 1,unitName);
	}
	@Then("unselect the all unit from level {int} under main filter")
	public void unselect_the_all_unit_from_level_under_main_filter(Integer level) 
	{
		if(usr == null)
	    	usr = new User();
		usr.unselectUnitLevelFromMainFilter(level - 1);
	}
	@Then("validate the unit level {int} filter available")
	public void validate_the_unit_level_filter_available(Integer unit) 
	{
		if(usr == null)
	    	usr = new User();
		usr.validateUnitLevelFilterAvailable(unit - 1);
	}
	
	@Then("validate the unit level {int} filter not available")
	public void validate_the_unit_level_filter_not_available(Integer unit) 
	{
		if(usr == null)
	    	usr = new User();
		usr.validateUnitLevelFilterNotAvailable(unit - 1);
	}
	@Then("select the org level {int} from main filter")
	public void select_the_org_level_from_main_filter(Integer level) 
	{
		if(usr == null)
	    	usr = new User();
		usr.selectOrgLevelMainFilter(level);
	}

	@Then("validate the user count applying unit level {int}")
	public void validate_the_user_count_applying_unit_level(int count) {
		if(usr == null)
	    	usr = new User();
		usr.validateUserCountUnitLevel(count);
		usr.clickMoreFilterClearSearch();
	}
	
	//*[@id="learnerTableList"]/tbody/tr/td[text()='2022-10-04 21:30:46']
	
	@Then("validate the user details {string}")
	public void validate_user_details(String data) {
		if(usr == null)
	    	usr = new User();
		for(int i=0;i<data.split(",").length;i++)
		{
			usr.validateusertable(data.split(",")[i]);
		}
	}
	@Then("validate the user details {string} for lms")
	public void validate_user_details_LMS(String data) {
		if(usr == null)
	    	usr = new User();
		for(int i=0;i<data.split(",").length;i++)
		{
			usr.validateusertablelms(data.split(",")[i]);
		}
	}
	@Then("validate the user status functionality on user page")
	public void validate_the_user_status_functionality_on_user_page() {
		if(usr == null)
	    	usr = new User();
		usr.validateUserStatusFilterAvailability();
		usr.validateUserStatusFilterFields();
	}
	
	@Then("click on more filter option")
	public void click_on_more_filter_option() 
	{
		if(usr == null)
	    	usr = new User();
		usr.clickMoreFilter();
	}
	@Then("validate the {string} filter not available on user page")
	public void validate_the_filter_not_available_on_user_page(String filterName) {
		if(usr == null)
			usr = new User();
		switch (filterName) {
		case "group filter":
			usr.validateUserGroupFilterNotAvailabile();
			break;
		default:
			break;
		}	    
	}

	
	@Then("validate group filter is not available")
	public void validate_group_filter_is_not_available() 
	{
		if(usr == null)
	    	usr = new User();
		usr.validateGroupFilterNotDisplayed();
	}
	
	@Then("validate action dropdown options {string}")
	public void validate_action_dropdown_options(String optionList) 
	{
	    if(usr == null)
	    	usr = new User();
	    usr.checkAllUser();
		usr.clickAllActionItem();
	    usr.validateActionDropdownOptions(optionList);
	}
	@Then("click on add group button and close popup")
	public void click_on_add_group_button_and_close_popup() 
	{
	    usr.clickAddGroupButton();
	    usr.closeAddGroupPopup();
	}
	@Then("select the group {string} from add assignment dropdown")
	public void select_the_group_from_add_assignment_dropdown(String course) 
	{
	    usr.selectGroupDropdown(course);
	}
	@Then("validate add group dropdown message {string}")
	public void validate_add_group_dropdown_message(String message) 
	{
	    usr.validateAddGroupPopupMessage(message);
	}
	@Then("validate the group add popup with {int} {string}")
	public void validate_the_group_add_popup_with(Integer count, String courses) 
	{
	    if(courses.length() > 0)
	    {
	    	usr.validateAddGroupNames(courses);
	    }
	    usr.validateCourseCountAddGroupPopup(count);
	}
	@Then("add group to all user as per name {string}")
	public void add_group_to_all_user_as_per_name(String groupNames) 
	{
		if(usr == null)
			usr = new User();
		String group[] = groupNames.split(",");
		for(int i = 0; i <= group.length - 1; i++)
		{
			usr.checkAllUser();
			usr.clickAllActionItem();
			usr.selectAddGroupPerNameForAll(group[i]);
		}
	}
	@Then("add group to all user")
	public void add_group_to_all_user_as_per_name() 
	{
		if(usr == null)
			usr = new User();
	
			usr.checkAllUser();
			usr.clickAllActionItem();
			usr.selectAddGroupPerNameForAll(OrganizationSettings.groupName);
	}
	@Then("navigate to remove group popup")
	public void navigate_to_remove_group_popup() 
	{
		if(usr == null)
			usr = new User();
		usr.checkAllUser();
		usr.clickAllActionItem();
		usr.selectRemoveGroupOption();
	}
	
	@Then("close add assignment popup")
	public void close_add_assignment_popup() 
	{
	    usr.closeAddAssignmentPopup();
	}
	@Then("click on add assignment button and close popup")
	public void click_on_add_assignment_button_and_close_popup() 
	{
	    usr.clickAddAssignmentButton();
	    usr.closeAddAssignmentPopup();
	}
	@Then("validate add assignment dropdown message {string}")
	public void validate_add_assignment_dropdown_message(String message) 
	{
	    usr.validateAddAssignmentPopupMessage(message);
	}
	@Then("validate add assignment dropdown duplicate message {string}")
	public void validate_add_assignment_dropdown_duplicate_message(String message) 
	{
	    usr.validateAddAssignmentDuplicatePopupMessage(message);
	}
	
	@Then("select the assignment {string} from add assignment dropdown")
	public void select_the_assignment_from_add_assignment_dropdown(String course) 
	{
	    usr.selectCourseAssignmentDropdown(course);
	}
	@Then("validate the assignment add popup with {int} {string}")
	public void validate_the_assignment_add_popup_with(Integer count, String courses) 
	{
	    if(courses.length() > 0)
	    {
	    	usr.validateAddAssignmentNames(courses);
	    }
	    usr.validateCourseCountAddAssignmentPopup(count);
	}
	
	@Then("navigate to add assignment popup")
	public void navigate_to_add_assignment_popup() 
	{
		if(usr == null)
			usr = new User();
		usr.checkAllUser();
		usr.clickAllActionItem();
		usr.selectAddAssignmentOption();
	}
	
	@Then("create multiple user {int} {string} {string}")
	public void create_multiple_user(Integer count, String first, String last) 
	{
		if(usr == null)
			usr = new User();
		if(org == null)
			org = new OrganizationHome();
	    usr.addMultiuser(count, org, first, last);
	}
	
	@Then("search the created user {int}")
	public void search_thecreated_user_by_user_id(int i) 
	{
		if(usr == null)
			usr = new User();
			usr.userssearchEmail(User.usrEmail[i-1]);
	}
	
	@Then("search the created user by user id")
	public void search_the_created_user_by_user_id() 
	{
		if(usr == null)
			usr = new User();
		if(User.userId != null)
			usr.userSearchById(User.userId.toLowerCase().trim());
		else
			usr.userSearchById(Students.email.toLowerCase().trim());
	}
	@Then("add available assignment to user")
	public void add_available_assignment_to_user() 
	{
		if(usr == null)
			usr = new User();
		usr.addAvailableAssignment();
	}
	
	@Then("add available assignment to user {int}")
	public void add_available_assignment_to_user(int i) 
	{
		if(usr == null)
			usr = new User();
		usr.addAvailableAssignment();
	}
	
	@Then("add assignment to all user")
	public void add_assignment_to_all_user() 
	{
		if(usr == null)
			usr = new User();
		usr.checkAllUser();
		usr.clickAllActionItem();
		usr.selectAddAssignmentForAll();
	}
	
	@Then("add assignments to all user")
	public void add_assignments_to_all_user() 
	{
		if(usr == null)
			usr = new User();
		usr.checkAllUser();
		usr.clickAllActionItem();
		usr.selectAddAssignmentForAll(Assignments.AssgnmentName);
	}
	
	@Then("Click on add assignment")
	public void add_assignmentto_all_user() 
	{
		if(usr == null)
			usr = new User();
		usr.clickonAddAssigment();
		
	}
	@Then("Click on Close button in add assignment tab")
	public void add_assignmenttoall_user() 
	{
		if(usr == null)
			usr = new User();
		usr.clickonAssigmentClose();
		
	}
	
	
	@Then("Click on Close btn in add assignment tab")
	public void add_assignmenttall_user() 
	{
		if(usr == null)
			usr = new User();
		usr.clickonAssigmentCloe();
		
	}
	@Then("add group {int} to all user if msg validation {string}")
	public void add_group_to_all_user(int group,String msg) 
	{
		if(usr == null)
			usr = new User();
		usr.checkAllUser();
		usr.clickAllActionItem();
		usr.selectAddGroupForAll(group, msg);;;;
		
	}
	@Then("remove group {int}")
	public void remove_group_to_all_user(int group) throws InterruptedException 
	{
		if(usr == null)
			usr = new User();
		usr.checkAllUser();
		usr.clickAllActionItem();
		usr.selectremoveGroupForAll(group);;;;
		
	}

	@Then("remove group all user")
	public void remove_group_to_all_user() throws InterruptedException 
	{
		if(usr == null)
			usr = new User();
		usr.checkAllUser();
		usr.clickAllActionItem();
		usr.selectremoveGroupForAll(OrganizationSettings.groupName);;;;
		usr.closeRemoveGroupButton();
		
		
	}@Then("remove Assignment {string}")
	public void removeassignment_to_all_user(String assignment) throws InterruptedException 
	{
		if(usr == null)
			usr = new User();
		usr.checkAllUser();
		usr.clickAllActionItem();
		usr.selectremoveAssigmentForAll(assignment);;;;
		
		
	}
	@Then("remove Assignment all user")
	public void removeassignment_o_all_user() throws InterruptedException 
	{
		if(usr == null)
			usr = new User();
		usr.checkAllUser();
		usr.clickAllActionItem();
		usr.selectremoveAssigmentForAll(Assignments.AssgnmentName);;;;
		usr.closeRemoveGroupButton();
		
	}
	

	@Then("Click on Group Tab")
	public void clickonGroupTab() 
	{
		if(usr == null)
			usr = new User();
		orgSet=new OrganizationSettings();
		orgSet.navigateGroup();
		
	
	}
	
	
	@Then("Validate the User count {string} for group {int}")
	public void clickonGroupTab(String user,int group) 
	{
		if(usr == null)
			usr = new User();
		orgSet=new OrganizationSettings();
		
		orgSet.searchGroupName(group);
	    orgSet.validateSearchResultUser(user);
		
	
	}
	@Then("Click on Close")
	public void clickonClose() 
	{
		if(usr == null)
			usr = new User();
	
		usr.clickonClose();
	}
	@Then("Click on addGroup")
	public void clickonaddGroup() 
	{
		if(usr == null)
			usr = new User();
	
		usr.clickAddGroup();
	}
	
	@Then("Validate Error Msg {string}")
	public void validateErrorMssg(String msg) 
	{
		if(usr == null)
			usr = new User();
	
		usr.errorMsg(msg);
	}
	@Then("add duplicate assignment to user")
	public void add_duplicate_assignment_to_user() 
	{
		if(usr == null)
			usr = new User();
		usr.checkAssignmentAlreadyPresent();
	}

	@Then("add assignment to all user without error")
	public void add_assignment_to_all_user_without_error() 
	{
		if(usr == null)
			usr = new User();
		usr.checkAllUser();
		usr.clickAllActionItem();
		usr.selectAddAssignmentForAllWithoutError();
	}
	
	@Then("add created assignment to all user without error")
	public void add_createdassignment_to_all_user_without_error() 
	{
		if(usr == null)
			usr = new User();
		usr.checkAllUser();
		usr.clickAllActionItem();
		usr.selectAddAssignmentForAllWithoutErrorCreatedassignment();
	}
	@Then("add assignment {int} to all user if msg validation {string}")
	public void add_assignmentto_all_user(int assig,String msg) 
	{
		if(usr == null)
			usr = new User();
		usr.checkAllUser();
		usr.clickAllActionItem();
		usr.selectAddAssignmentForAll(assig,msg);
	}
	
	@Then("add user {int} to group {int} already assigned user {int}")
	public void add_the_group_to_eachuser(int user,int group,int assign) 
	{
		if(usr == null)
			usr = new User();
		usr.addMutipleUserToGroup(group,user,assign);
	}
	@Then("add the assignment under user")
	public void add_the_assignment_under_user() 
	{
	    usr.clickOnAssignmentTabUnderUser();
	    usr.addAssignmentUnderUser();
	}

	@Then("add the group")
	public void add_the_group() 
	{
		if(usr == null)
		{
			usr = new User();
		}
	    orgSet = new OrganizationSettings();
	    orgAcc = new OrganizationAccess();
	    orgAcc.navigateOrgSetting();
	    orgSet.navigateGroup();
	    orgSet.clickOnCreateGroup();
	    orgSet.enterGroupDetails();
	    orgSet.clickOnCreate();
	    
System.out.println(OrganizationSettings.groupName);
	    usr.addGroup(OrganizationSettings.groupName);
	}
	@Then("add the group using user Action")
	public void add_the_group_user_action() 
	{
		if(usr == null)
		{
			usr = new User();
		}
	    orgSet = new OrganizationSettings();
	    orgAcc = new OrganizationAccess();
	    orgAcc.navigateOrgSetting();
	    orgSet.navigateGroup();
	    orgSet.clickOnCreateGroup();
	    orgSet.enterGroupDetails();
	    orgSet.clickOnCreate();
System.out.println(OrganizationSettings.groupName);
	    usr.addGroup(OrganizationSettings.groupName);
	}
	
	@Then("add the job title {int}")
	public void add_the_job_title(int i) 
	{
	    usr.addTitle(i-1);
	}

	@Then("add the job title")
	public void add_the_job_title() 
	{
	    usr.addTitle();
	}

	@Then("add the job title for specific title")
	public void add_the_job_title_for_specific_title() 
	{
	    usr.addSpecificTitle(OrganizationSettings.titleName);
	}
	@Then("add the job title for specific title {int}")
	public void add_the_job_title_forspecific_title(int i) 
	{
	    usr.addSpecificTitle(OrganizationSettings.titleName,i);
	}
	
	@Then("assign the user to groups {int} {int}")
	public void assign_the_user_to_groups(int groupCount, int userCount) 
	{
		if(usr == null)
			usr = new User();
		usr.addMutipleUserToGroup(groupCount, userCount);
	}
	
	@Then("add the group to each user {int}")
	public void add_the_group_to_each_user(int count) 
	{
		if(usr == null)
			usr = new User();
		usr.addMultipleUserSameGroup(count);
	}

	
	@Then("add the Assignment {int} to each user {int} already assigned user {int}")
	public void add_the_Assignment_to_eachuser(int group,int user,int assign) 
	{
		if(usr == null)
			usr = new User();
		usr.addMutipleUseAssigment(group,user,assign);
	}
	@Then("Click on Clear in User Page")
	public void clickonClearinUserPage() 
	{
		if(usr == null)
			usr = new User();
		usr.clickonClear();
	}
	
	
	
	@Then("add the group {int} user")
	public void add_the_group_to_eachuser(int count) 
	{
		if(usr == null)
			usr = new User();
		usr.addMultipleUserSamGroup(count);
	}
	@Then("create and verify user with hire date {string} {string} {string}")
	public void create_and_verify_user_with_hire_date(String fname, String lName, String id) 
	{
		if(usr == null)
			usr = new User();
		org = new OrganizationHome();
		usr.enterUserDetails(fname, lName, id);
		
		usr.selectHiredate();
	    usr.clickOnSubmit();
	    org.validateSucessMesssage();
	}
	
	@Then("create and verify user with hire date as {int} {string} {string} {string}")
	public void create_and_verify_userwith_hire_date(int days,String fname, String lName, String id) 
	{
		if(usr == null)
			usr = new User();
		org = new OrganizationHome();
		usr.enterUserDetails(fname, lName, id);
		
		usr.selectHiredate(days);
	    usr.clickOnSubmit();
	    org.validateSucessMesssage();
	}
	
	
	@Then("create and verify user with hire date {string} {string} {string} and validate message {string}")
	public void create_and_verify_user_with_hire_date(String fname, String lName, String id,String msg) 
	{
		if(usr == null)
			usr = new User();
		org = new OrganizationHome();
		usr.enterUserDetails(fname, lName, id);
//		usr.AddLevel();
		usr.selectHiredate();
		usr.clickOnSubmit();
	    org.validateSucessMesssage(msg);
	}
	
	@Then("add the organization level {int} {string}")
	public void add_the_organization_level(int level, String unitName) 
	{
		if(usr == null)
			usr = new User();
	    usr.addOrgLevel(level,unitName);
	}

	@Then("add the job title multiple user {int}")
	public void add_the_job_title_multiple_user(int count) 
	{
		if(usr == null)
			usr = new User();
		usr.addMultipleUserSameJobTitle(count);
	}
	
	@Then("create multiple user with hire date {int} {string} {string}")
	public void create_multiple_user_with_hire_date(Integer count, String first, String last) 
	{
		if(usr == null)
			usr = new User();
		usr.addMultiuserHireDate(count, first, last);
	}

	@Then("update the optional report with group {string}")
	public void update_the_optional_report_with_group(String name) 
	{
	    std.updateOptionalReportGroup(name);
	}

	@Then("create and verify user")
	public void create_and_verify_user(DataTable userDetails) throws Throwable 
	{
		for(Map<String, String> dataSet : userDetails.asMaps())
		{
			if(usr == null)
				usr = new User();
			org = new OrganizationHome();
			usr.clickCreateUser();
			usr.enterMultiUser(dataSet.get("First"), dataSet.get("Last"), dataSet.get("id"));
		    usr.clickOnSubmit();
		    org.validateSucessMesssage();
		}
	}

	@Then("get the userId from view user details page")
	public void get_the_user_id_from_view_user_details_page() 
	{
		if(usr == null)
			usr = new User();
		usr.getUserId_ViewPage();
	}
	
	@Then("validate the certificate from user module")
	public void validate_the_certificate_from_user_module() 
	{
		if(usr == null)
			usr = new User();
	    usr.viewTrainingCertificate();
	}

	@Then("Check the ecard the certificate for {string} from user module")
	public void validate_the_certificate_from_user_module(String course) 
	{
		if(usr == null)
			usr = new User();
	    usr.checkthecard(course);
	}

	
	
//=============================================================================================================================================	
	@Then ("Validate Duplicate Assignment message {string}")
	public void Validate_Duplicate_Assignment_message(String msg) 
	{
		if(usr == null)
			usr = new User();
	
		usr.DuplicteAssignmentError(msg);

	}
	
	@Then("User validates the RowsPerPage count") 
	public void Then_User_validates_the_RowsPerPage_count()
	{
		usr.RowsPerPage();
	}
	
	@Then("validate the fields on user page {string},{string}, {string}, {string}, {string}")
	public void validate_the_fields_on_user_page()
	{
		
	}
	
	@Then("inactivate the newly created user") 
	public void inactivate_the_newly_created_user() throws InterruptedException
	{
		if(usr == null)
		{
			usr = new User();
		}
		
		usr.UserMoreFileter();
	}
	
	@Then("update the optional report {int} with same job title for level {int}")
    public void update_the_optional_reportlevel(int count,int level)
    {
        std.updateOptionalReportwithotlevel(count,level);
    }
	
	@Then("update the optional report {int} with same Hire Date for level {int}")
    public void update_the_optionalreportlevel(int count,int level)
    {
        std.updateOptionalReportwithotlevelHire(count,level);
    }
	
	@Then("update the optional report with group {string} for level {int}")
	public void update_the_optional_report_with_group(String name,int level) 
	{
	    std.updateOptionalReportGroup(name,level);
	}

	
	@Then("add the job title {int} for created list")
	public void add_thejob_title(int i) 
	{
	    usr.addjobTitle(i-1);
	}

	@Then("add the group {int} for created list")
	public void add_thegroup_title(int i) 
	{
	    usr.addGroups(OrganizationSettings.groupNames[i-1]);
	}
	
	@Then("change the pagination to {string}")
	public void change_thepagination_and_validate_the_count(String expectedCount) 
	{
		 if(usr == null)
		    	usr = new User();
	    usr.validatePaginationDropdown(expectedCount);
//	   	  usr.validateUserCountPerPage(expectedCount);
	}
	
	@Then("search user then inactivate")
    public void search_user_nd_inactivate_the_user()
    {
        if(usr == null)
        {
            usr = new User();
        }
        usr.applyMoreFilter();
        usr.usersearchEmailwithoutclearing(User.userEmail);
        usr.setInactive();
    }
	
	@Then("Create Assignment through view user details")
	public void unenroll_he_Course() 
	{
	    usr.navigateandEditUser();
	    usr.navigateAssigmentViewEdit();
	    
	}
	
	@Then("validate the sorting of each column on user page")
	public void validate_the_sorting_of_each_column_on_user_page() 
	{
		if(usr == null)
			usr = new User();
	    usr.validateSortingEachColumn();
	}
	
	@Then("validate the page numbers on user page")
	public void validate_the_page_numbers_on_user_page() 
	{
		if(usr == null)
			usr = new User();
	    usr.validatePageNumbers();
	    usr.getLocationPageNumber();
	    usr.validatePaginationDropdown();
	    usr.selectPaginationDropdown();
	}

	@Then("validate the default sorting on user page")
	public void validate_the_default_sorting_on_user_page() 
	{
		if(usr == null)
			usr = new User();
	    usr.validateDefaultSortingUserPage("last");
	}
	@Then("create and verify user {string} {string} {string} with special characters")
	public void create_and_verify_user_with_special_characters(String fname, String lName, String id) 
	{
		if(usr == null)
			usr = new User();
		org = new OrganizationHome();
		usr.enterUserDetailsWithSpecialCharacter(fname, lName, id);
	    usr.clickOnSubmit();
	    org.validateSucessMesssage();
	}


	@Then("Verify the user search by first name picking up from given rows under user page")
	public void verify_the_user_search_by_first_name_user() 
	{
		if(usr == null)
			usr = new User();
		usr.clearSearch();
		int count = usr.rowsAvailable();
		usr.getUserDetailsCoursePage(count);
		usr.searchAndValidateUserDetailByUserFirstName();
	}
	
	@Then("Verify the user search by last name picking up from given rows under user page")
	public void verify_the_user_search_by_last_name_user() 
	{
		if(usr == null)
			usr = new User();
		usr.clearSearch();
		int count = usr.rowsAvailable();
		usr.getUserDetailsCoursePage(count);
		usr.searchAndValidateUserDetailByUserLastName();
	}
	
	@Then("Verify the user search by user id picking up from given rows under user page")
	public void verify_the_user_search_by_user_id_user() 
	{
		if(usr == null)
			usr = new User();
		usr.clearSearch();
		int count = usr.rowsAvailable();
		usr.getUserDetailsCoursePage(count);
		usr.searchAndValidateUserDetailByUserID();
	}

	@Then("create and verify user {string} {string} with another unit level {int}")
	public void create_and_verify_user_with_another_unit_level(String fname, String lName, Integer level) 
	{
		if(usr == null)
			usr = new User();
		org = new OrganizationHome();
		usr.enterUserDetailsWithAnotherUnitLevel(fname, lName, level);
		usr.clickOnSubmit();
	    org.validateSucessMesssage();
	}
	
	@Then("validate the {string} filter {int} on user page")
	public void validate_the_filter_on_user_page(String filterName, int level) {
		if(usr == null)
			usr = new User();
		switch (filterName) {
		case "org level filter":
			usr.validateOrgLevelFilterName(level);
			usr.validateOrgLevelFilterFilterAvailability();
			break;
		default:
			break;
		}	    
	}
	
	@Then("validate the records are available on user page")
	public void validate_the_records_are_available_on_user_page() {
		if(usr == null)
			usr = new User();
		usr.validateRecordAvailable();
	}
	
	@Then("validate the records are not available on user page")
	public void validate_the_records_are_not_available_on_user_page() {
		if(usr == null)
			usr = new User();
		usr.validateRecordNotAvailable();
	}
	@Then("validate the default value of hire dates")
	public void validate_the_default_value_of_hire_dates() {
		if(usr == null)
	    	usr = new User();
		usr.enterDefaultHireDate();
	}
////////////////////////////////////Org Level ////////////////////////////////////////////////	

	@Then("single select org level filter status on user page")
	public void single_select_org_level_filter_status_on_user_page() {
		if (usr == null)
			usr = new User();
		usr.selectSingleOrgLevelFilter();
		usr.validateOrgLevelFilterFilterAvailability();
		usr.clickUserSearch();
	}

	@Then("multi select org level filter status on user page {int}")
	public void multi_select_org_level_filter_status_on_user_page(int count) {
		if (usr == null)
			usr = new User();
		for (int i = 0; i < count; i++) {
			usr.selectMultiOrgLevelFilter();
		}
		usr.validateOrgLevelFilterFilterAvailability();
		usr.clickUserSearch();
	}

	@Then("unSelect all org level filter status on user page")
	public void un_select_all_org_level_filter_status_on_user_page() {
		if (usr == null)
			usr = new User();
		usr.unSelectAllOrgLevelFilter();
		usr.validateOrgLevelFilterFilterAvailability();
		usr.clickUserSearch();
	}

	@Then("select all org level filter status on user page")
	public void select_all_org_level_filter_status_on_user_page() {
		if (usr == null)
			usr = new User();
		usr.selectAllOrgLevelFilter();
		usr.validateOrgLevelFilterFilterAvailability();
		usr.clickUserSearch();
	}

	@Then("clear the selected org level filter status on user page")
	public void clear_the_selected_org_level_filter_status_on_user_page() {
		if (usr == null)
			usr = new User();
		usr.unSelectAllOrgLevelFilter();
	}

	@Then("search the org level filter on user page")
	public void search_the_course_filter_on_user_page() {
		if (usr == null)
			usr = new User();
		usr.searchOrgLevelFilter(OrganizationSettings.newUnitName);
		usr.validateOrgLevelFilterFilterAvailability();
		usr.clickUserSearch();
	}
////////////////////////////////////////////////Job Title /////////////////////////////////////////////

	@Then("validate the {string} filter on user page")
	public void validate_the_filter_on_user_page(String filterName) {
		if (usr == null)
			usr = new User();
		switch (filterName) {
		case "job filter":
			usr.validateJobFilterFilterAvailability();
			break;
		case "org level sub filter":
			usr.validateOrgLevelSubFilterAvailability();
			break;
		case "user status":
			usr.validateUserStatusFilterAvailability();
			break;
		case "group filter":
			usr.validateUserGroupFilterAvailability();
			break;
		default:
			break;
		}
	}

	@Then("single select job filter status on user page")
	public void single_select_job_filter_status_on_usrress_report_page() {
		if (usr == null)
			usr = new User();
		usr.selectSingleJobFilter();
		usr.validateJobFilterFilterAvailability();
		usr.clickMoreFilterSearch();
	}

	@Then("multi select job filter status on user page {int}")
	public void multi_select_job_filter_status_on_usrress_report_page(int count) {
		if (usr == null)
			usr = new User();
		for (int i = 0; i < count; i++) {
			usr.selectMultiJobFilter();
		}
		usr.validateJobFilterFilterAvailability();
		usr.clickMoreFilterSearch();
	}

	@Then("unSelect all job filter status on user page")
	public void un_select_all_job_filter_status_on_usrress_report_page() {
		if (usr == null)
			usr = new User();
		usr.unSelectAllJobFilter();
		usr.validateJobFilterFilterAvailability();
		usr.clickMoreFilterSearch();
	}

	@Then("select all job filter status on user page")
	public void select_all_job_filter_status_on_usrress_report_page() {
		if (usr == null)
			usr = new User();
		usr.selectAllJobFilter();
		usr.validateJobFilterFilterAvailability();
		usr.clickMoreFilterSearch();
	}

	@Then("clear the selected job filter status on user page")
	public void clear_the_selected_job_filter_status_on_usrress_report_page() {
		if (usr == null)
			usr = new User();
		usr.unSelectAllJobFilter();
	}

	@Then("search the job filter on user page")
	public void search_the_job_filter_on_usrress_report_page() {
		if (usr == null)
			usr = new User();
		usr.searchJobFilter();
		usr.validateJobFilterFilterAvailability();
		usr.clickMoreFilterSearch();
	}

///////////////////////////////////////// Org Level Sub Filter ///////////////////////////////////////////////////

	@Then("single select org level sub filter status on user page")
	public void single_select_org_level_sub_filter_status_on_user_page() {
		if (usr == null)
			usr = new User();
		usr.selectSingleOrgLevelSubFilter();
		usr.validateOrgLevelSubFilterAvailability();
		usr.clickMoreFilterSearch();
	}

	@Then("multi select org level sub filter status on user page {int}")
	public void multi_select_org_level_sub_filter_status_on_user_page(int count) {
		if (usr == null)
			usr = new User();
		for (int i = 0; i < count; i++) {
			usr.selectMultiOrgLevelSubFilter();
		}
		usr.validateOrgLevelSubFilterAvailability();
		usr.clickMoreFilterSearch();
	}

	@Then("unSelect all org level sub filter status on user page")
	public void un_select_all_org_level_sub_filter_status_on_user_page() {
		if (usr == null)
			usr = new User();
		usr.unSelectAllOrgLevelSubFilter();
		usr.validateOrgLevelSubFilterAvailability();
		usr.clickMoreFilterSearch();
	}

	@Then("select all org level sub filter status on user page")
	public void select_all_org_level_sub_filter_status_on_user_page() {
		if (usr == null)
			usr = new User();
		usr.selectAllOrgLevelSubFilter();
		usr.validateOrgLevelSubFilterAvailability();
		usr.clickMoreFilterSearch();
	}

	@Then("clear the selected org level sub filter status on user page")
	public void clear_the_selected_org_level_sub_filter_status_on_user_page() {
		if (usr == null)
			usr = new User();
		usr.unSelectAllOrgLevelSubFilter();
	}

	@Then("search the org level sub filter on user page")
	public void search_the_course_sub_filter_on_user_page() {
		if (usr == null)
			usr = new User();
		usr.searchOrgLevelSubFilter(OrganizationSettings.newUnitName);
		usr.validateOrgLevelSubFilterAvailability();
		usr.clickMoreFilterSearch();
	}
	

////////////////////////////////////////////////More Filter //////////////////////////////

@Then("validate the number of child levels in more filter")
public void validate_the_number_of_child_levels_in_more_filter() {
if(usr == null)
usr = new User();
usr.validateChildLevelCount();
}

///////////////////////////////////////////////// User Status ///////////////////////////////////

@Then("single select user filter status as {string} on user page")
public void single_select_user_filter_status_as_on_user_page(String filter) {
if(usr == null)
usr = new User();
usr.selectSingleUserStatusFilter(filter);
usr.validateUserStatusFilterAvailability();
usr.clickMoreFilterSearch();
}

@Then("multi select user filter status as {string} on user page")
public void multi_select_user_filter_status_as_on_user_page(String filter) {
if(usr == null)
usr = new User();
String[] filterList = filter.split(",");
for(int i = 0; i < filterList.length; i++) {
usr.selectMultiUserStatusFilter(filterList[i]);	
}
usr.validateUserStatusFilterAvailability();
usr.clickMoreFilterSearch();
}

@Then("unSelect all user status on user page")
public void unSelect_all_user_status_on_user_page() {
if(usr == null)
usr = new User();
usr.unSelectAllStatus();
usr.validateUserStatusFilterAvailability();
usr.clickMoreFilterSearch();
}

@Then("select all user status and search on user page")
public void select_all_user_status_and_search_on_user_page() {
if(usr == null)
usr = new User();
usr.selectAllStatus();
usr.validateUserStatusFilterAvailability();
usr.clickMoreFilterSearch();
}

@Then("clear the selected user status on user page")
public void clear_the_selected_user_status_on_user_page() {
if(usr == null)
usr = new User();
usr.unSelectAllStatus();
}

@Then("search the user by status {string} on user page")
public void search_the_user_by_status_on_user_page(String userStatus) {
if(usr == null)
usr = new User();
usr.searchUserStatus(userStatus);
usr.validateUserStatusFilterAvailability();
usr.clickMoreFilterSearch();
}

///////////////////////////////////////////// Group Filter /////////////////////////////////////////

@Then("single select group filter status on user page")
public void single_select_group_filter_status_on_user_page() {
if(usr == null)
usr = new User();
usr.selectSingleUserGroupFilter();
usr.validateUserGroupFilterAvailability();
usr.clickMoreFilterSearch();
}

@Then("multi select group filter status on user page {int}")
public void multi_select_group_filter_status_on_user_page(int count) {
if(usr == null)
usr = new User();
for(int i = 0; i < count; i++) {
usr.selectMultiUserGroupFilter();	
}
usr.validateUserGroupFilterAvailability();
usr.clickMoreFilterSearch();
}

@Then("unSelect all group filter status on user page")
public void un_select_all_group_filter_status_on_user_page() {
if(usr == null)
usr = new User();
usr.unSelectAllGroupFilter();
usr.validateUserGroupFilterAvailability();
usr.clickMoreFilterSearch();
}

@Then("select all group filter status on user page")
public void select_all_group_filter_status_on_user_page() {
if(usr == null)
usr = new User();
usr.selectAllGroupFilter();
usr.validateUserGroupFilterAvailability();
usr.clickMoreFilterSearch();
}

@Then("clear the selected group filter status on user page")
public void clear_the_selected_group_filter_status_on_user_page() {
if(usr == null)
usr = new User();
usr.unSelectAllGroupFilter();
}

@Then("search the group filter on user page")
public void search_the_group_filter_on_user_page() {
if(usr == null)
usr = new User();
usr.searchGroupFilter();
usr.validateUserGroupFilterAvailability();
usr.clickMoreFilterSearch();
}


@Then("validate the action item dropdowm")
public void validate_the_action_item_dropdowm() {
	if(usr == null)
        usr = new User();  
	usr.checkAllUser();
	usr.clickAllActionItem();
	usr.validateActionDropDown();
}
@Then("search user then activate and inactivate")
public void search_user_activate_and_inactivate_the_user()
{
    if(usr == null)
    {
        usr = new User();
    }
    usr.applyMoreFilter();
    if(User.userEmail != null)
    	 usr.usersearchEmailwithoutclearing(User.userEmail);
    else
    	usr.usersearchEmailwithoutclearing(Students.email);       
    usr.setInactive();   
    usr.setActive();
}
@Then("validate the view courses popup from user page")
public void validate_the_view_courses_popup_from_user_page() {
	if(usr == null)
    	usr = new User();
	usr.viewCourses();
	usr.validateViewCourseHeader();
}
@Then("add the selected user to assignment for user count {int}")
public void add_the_selected_user_to_assignment_for_user_count(Integer userCount) {
	if(usr == null)
        usr = new User();  
	usr.selectMultipleUser(userCount);
	 usr.clickAllActionItem();
     usr.selectAddAssignmentForAll(Assignments.AssgnmentName);
}
@Then("validate no common assignment message {string}")
public void validate_no_common_assignment_message(String message) 
{
    usr.validateNoCommonAssignmentPopupMessage(message);
}
@Then("validate add some assignment message {string}")
public void validate_add_some_assignment_message(String message) 
{
    usr.validateAddAssignmentSomePopupMessage(message);
}
@Then("validate add assignment duplicate message {string}")
public void validate_add_assignment_duplicate_message(String message) 
{
    usr.validateAddAssignmentDuplicatePopupMessage(message);
}

@Then("view and edit the user email update details")
public void view_and_edit_the_user_email_update_details() 
{
    usr.viewAndEditUserUpdateEmail();
}
@Then("validate the assignment remove popup with {string} {int}")
public void validate_the_assignment_remove_popup_with(String message, Integer count) 
{
    usr.validateRemoveAssignmentPopupMessage(message);
    usr.validateCourseCountRemoveAssignmentPopup(count);
    if(count >=1) {
    usr.validateCourseListRemoveAssignmentPopup();
    usr.clickRemoveAssignmentButton();
    }
    usr.closeRemoveAssignmentButton();
}
@Then("click on group close popup")
public void click_on_group_close_popup() 
{
    usr.closeAddGroupPopup();
}
@Then("validate remove group dropdown message {string}")
public void validate_remove_group_dropdown_message(String message) 
{
    usr.validateRemoveGroupPopupMessage(message);
}

@Then("validate the group add popup with count and group name")
public void validate_the_group_add_popup_with() 
{
	String courses = OrganizationSettings.groupName1;
    if(courses.length() > 0)
    {
    	usr.validateAddGroupNames(courses);
    }
    usr.validateCourseCountAddGroupPopup();
}

@Then("select the group from add assignment dropdown")
public void select_the_group_from_add_assignment_dropdown() 
{
    usr.selectGroupDropdown(OrganizationSettings.groupName1);
}

@Then("select the another group from add assignment dropdown")
public void select_the_another_group_from_add_assignment_dropdown() 
{
    usr.selectGroupDropdown(OrganizationSettings.groupName2);
}

@Then("add the selected user to another group for user count {int}")
public void add_the_selected_user_to_another_group_for_user_count(Integer userCount) {
	if(usr == null)
        usr = new User();  
	usr.selectMultipleUser(userCount);
	 usr.clickAllActionItem();
     usr.selectAddGroupPerNameForAll(OrganizationSettings.groupName2);
}
@Then("click on group cancel popup")
public void click_on_group_cancel_popup() 
{
    usr.cancelGroupPopup();
}



@Then("Validate the All Action Btn is not available")
public void navigate_to_add_group_available() 
{
	if(usr == null)
		usr = new User();
	usr.checkAllUserisnotavailable();
	
}

@Then("Validate the drop down All Action option {string} is {string} from user screen")
public void navigate_to_add_group_popup(String drop,String status) 
{
	if(usr == null)
		usr = new User();
	usr.checkAllUser();
	usr.clickAllActionItem();
	for(int i=0;i<drop.split(",").length;i++)
	usr.validateifActionitem(drop.split(",")[i],status);
}


@Then("Validate the drop down Action option {string} is {string} for user from user screen")
public void navigateto_add_group_popup(String drop,String status) 
{
	if(usr == null)
		usr = new User();
	usr.clickonActionDetail();
	for(int i=0;i<drop.split(",").length;i++)
	usr.validationifdropdown(drop.split(",")[i],status);
}

@Then("validated if create assignment not available in All Action Item")
public void add_assignmenttoll_user() 
{
	if(usr == null)
		usr = new User();
	usr.checkAllUser();
	usr.clickAllActionItem();
	usr.validateifcreateAssignment();
}

@Then("validated if create assignment not available in to user")
public void add_assignmentto_user() 
{
	org =new OrganizationHome();
    usr.validateifaddAssignment();
   
}

@Then("validated if create assignment not available in to view user")
public void add_assignmentto_viewuser() 
{
	org =new OrganizationHome();
    usr.validateifviewDetailsAssignment();
   
}

@Then("validate the user details with exported file for LMS from user page")
public void validate_the_user_details_with_exported_file_for_LMS_from_user_page() 
{
	if(usr == null)
    	usr = new User();
	usr.getAllUserUIListForLMS();
	usr.getAllUserExcelList();
	usr.compareActivityList();
}

@Then("search box Name Email")
public void searchboxNameEmail() {
	if (usr == null) {
		usr = new User();
	}
//	usr.usersearchEmail("20221014123610010@yopmail.com");
//	User.userEmail="20221014123610010@yopmail.com";

	usr.searchboxNameEmail(User.userEmail);
	System.out.println(" search box Name Email "+ User.userEmail);
}
@Then("search the using User id")
public void search_the_using_userId() {
	if (usr == null) {
		usr = new User();
	}
//	usr.usersearchEmail("20221014123610010@yopmail.com");
//	User.userEmail="20221014123610010@yopmail.com";

	usr.usersearchEmail(User.userId);
	System.out.println(" The updated user id"+ User.userId);
}
@Then("Clear The Search Field")
public void ClearTheSearchField() {
	if (usr == null) {
		usr = new User(); 
	}
	usr.ClearTheSearchField();
}
@Then("Search for the User {string}")
public void SearchForTheUser(String UserName) {
	if (usr == null) {
		usr = new User(); 
	}
	usr.searchUser(UserName);
}



}
