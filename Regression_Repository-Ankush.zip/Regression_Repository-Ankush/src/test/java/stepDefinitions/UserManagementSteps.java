package stepDefinitions;

import java.util.Set;

import org.testng.Assert;

import com.mysql.cj.jdbc.Driver;
import com.qa.pages.DashBoard;
import com.qa.pages.EndUser;
import com.qa.pages.OrganizationDetails;
import com.qa.pages.User;
import com.qa.pages.UserManagement;
import com.qa.util.TestBase;

import io.cucumber.java.en.Then;

public class UserManagementSteps 
{
	UserManagement usrMg;
	EndUser end;
	DashBoard db;

	@Then("search the user by email")
	public void search_the_user_by_email() 
	{
//		User.userEmail="20221109175554010@yopmail.com";
//		User.userId="2022-11-08 19:21:38";
//	
		usrMg = new UserManagement();
	    usrMg.searchByEmail(User.userEmail);
	 
//		usrMg.searchByEmail("20221108164910010@yopmail.com");
	    usrMg.clickSearch();
	}
	
	@Then("search the user by email {int} from list")
	public void search_the_user_by_email(int i) 
	{
//		User.userEmail="20221109175554010@yopmail.com";
//		User.userId="2022-11-08 19:21:38";
//	
		usrMg = new UserManagement();
	    usrMg.searchByEmail(User.usrEmail[i-1]);
	 
//		usrMg.searchByEmail("20221108164910010@yopmail.com");
	    usrMg.clickSearch();
	}


	@Then("launch the multiple course as per the name {string} with one topic left")
	public void launch_the_multiple_course_as_per_the_name_with_one_topic_left(String coursesName)
	{
		if(end == null)
			end = new EndUser();
	    usrMg.switchTab();
	    String name[] = coursesName.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	boolean flag = end.launchCourseWithName(name[i]);
	    	if(flag == true)
		    {
	    		 end.clickOnSubmitOnly();
	    		 int count = end.getNumberRows();
	    		 System.out.println("count is " + count);
	    		 if(count > 1)
	    		 {
	    		    while(count>1)
	    		    {
	    		    	end.startORResumeCourse();
	    		    	end.completeCourse();
	    			    end.onlyExitCourse();
	    			    count = end.getTopicAvaialble();
	    		    }
	    		 }
	    		 else
	 	    	{
	 	    		end.startORResumeCourse();
	 	    		end.onlyExitCourse();
	 		    }
	    		 end.clickEndUserMyCoursesLink();
		    }
	    	
	    }
		    usrMg.switchTab();
		    usrMg.closeOtherTab();
	}
	@Then("launch the multiple course as per the name {string} with only one topic")
	public void launch_the_multiple_course_as_per_the_name_with_only_one_topic(String coursesName)
	{
		if(end == null)
			end = new EndUser();
	    usrMg.switchTab();
	    String name[] = coursesName.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	boolean flag = end.launchCourseWithName(name[i]);
	    	if(flag == true)
		    {
	    		 end.clickOnSubmitOnly();
	    		 end.startORResumeCourse();
	    		 end.getVendorSharableId();
				 end.onlyExitCourse();

		    }
	    	
	    }
		    usrMg.switchTab();
		    usrMg.closeOtherTab();
	}

	@Then("Validate table details {string}")
	public void validate_table_details(String table) throws InterruptedException 
	{
		usrMg = new UserManagement();
	    usrMg.validateTable(table);
	
	    
	}
	@Then("switch and close other tab")
	public void switch_and_close_other_tab() 
	{
		if(usrMg == null)
			usrMg = new UserManagement();
		usrMg.switchTab();
		usrMg.closeOtherTab();
	}
	
	@Then("click on manage courses button")
	public void click_on_manage_courses_button() {
	  usrMg = new UserManagement();
	  usrMg.clickManagecoursesbutton();
	}
	@Then("Click on Add Course Button")
	public void ClickonAddCourse() {
	  usrMg = new UserManagement();
	  usrMg.clickaddcoursesbutton();
	}
	
	@Then("Select Course {string}")
	public void selectCourse(String course) {
	  usrMg = new UserManagement();
	  usrMg.selectCourse(course);
	}
@Then("click on topics and mark set as completed")
	public void click_on_topics_and_mark_set_as_completed() {
		 usrMg = new UserManagement();
		  usrMg.clickTopicsbutton();
		  usrMg.clicksetascompleted();
	}

@Then("click on topics for {string} and mark set as completed")
public void click_on_topics_and_mark_set_as_completed(String Course) {
	 usrMg = new UserManagement();
	  usrMg.clickTopicsbutton(Course);
	  usrMg.clicksetascompleted();
}

	@Then("enter the remediation review {string}")
	public void enter_the_remediation_review(String string) {
		 usrMg = new UserManagement();
		  usrMg.remediationreview(string);
	}
	@Then("complete the multiple whole courses online {string} as per the date {string}")
	public void complete_the_multiple_whole_course_as_per_the_date_online(String names, String courseDate) 
	{
		if(end == null)
			end = new EndUser();
	    usrMg.switchTab();
	    String name[] = names.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
//	    	end.runScriptForPastDate(courseDate);
		    boolean flag = end.launchCourseWithName(name[i]);
		    System.out.println(flag);
		    if(flag == true)
		    {
		    	end.clickOnSubmitOnlyWithDate();
//			    int count = end.getNumberRows();
//			    System.out.println("count is " + count);
//			    for(int j =1; j <= count; j++)
//			    {
			    	end.startORResumeCourseOnline();
//			    	end.completeCourse();
				    end.onlyExitCourse();
				    
			    }
			    end.clickEndUserProgramLink();
		    }
		    
	    }
	
	@Then("complete the multiple whole courses online {string} as per the date {string} as Student")
	public void complete_the_multiple_whole_course_as_per_the_date_online_as_Student(String names, String courseDate) 
	{
		if(end == null)
			end = new EndUser();
//	    usrMg.switchTab();
	    String name[] = names.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
//	    	end.runScriptForPastDate(courseDate);
		    boolean flag = end.launchCourseWithName(name[i]);
		    System.out.println(flag);
		    if(flag == true)
		    {
		    	end.clickOnSubmitOnlyWithDate();
//			    int count = end.getNumberRows();
//			    System.out.println("count is " + count);
//			    for(int j =1; j <= count; j++)
//			    {
			    	end.startORResumeCourseOnline();
//			    	end.completeCourse();
				    end.onlyExitCourse();
				    
			    }
			    end.clickEndUserProgramLinkonline();
		    }
		    
	    }
	@Then("navigate to proxy user page")
	@Then("navigate to end user page")
	public void navigate_to_end_user_page() 
	{
		if(usrMg == null)
			usrMg = new UserManagement();
	    usrMg.selectProxyUser();
	}
	
	@Then("Validate if No record found in End User Portal")
	public void check_no_() 
	{
		if(usrMg == null)
			usrMg = new UserManagement();
	    usrMg.endUser_Norecordsfound();
	}
	@Then("complete the course and get topic list")
	public void complete_the_course_and_topic_list() 
	{
	    end = new EndUser();
	    usrMg.switchTab();
	    end.launchUserCourse1();
	    end.clickOnSubmitOnly();
	    int count = end.getNumberRows();
	    System.out.println("count is " + count);
	    for(int i =1; i <= count; i++)
	    {
	    	end.startORResumeCourse();
	    	end.completeCourse();
		    end.onlyExitCourse();
		    
	    }
	    usrMg.switchTab();
	    usrMg.closeOtherTab();
	}
	@Then("launch the course with name {string}")
	public void launch_the_course_with_name(String name)
	{
	if(end == null)
	end = new EndUser();
	end.launchCourseWithName(name);
	end.clickOnSubmitOnly();
	}
	@Then("complete the course")
	public void complete_the_course() 
	{
	    end = new EndUser();
	    usrMg.switchTab();
	    end.launchUserCourse1();
	    end.clickOnSubmitOnly();
	    int count = end.getNumberRows();
	    System.out.println("count is " + count);
	    for(int i =1; i <= count; i++)
	    {
	    	end.startORResumeCourse();
	    	end.completeCourse();
		    end.onlyExitCourse();
		    
	    }
	    usrMg.switchTab();
	    usrMg.closeOtherTab();
	}
	
	@Then("complete the course name {string}")
	public void complete_the_course(String course) 
	{
	    end = new EndUser();
	    usrMg.switchTab();
	    end.launchCourseWithName(course);
	    end.clickOnSubmitOnly();
	    int count = end.getNumberRows();
	    System.out.println("count is " + count);
	    for(int i =1; i <= count; i++)
	    {
	    	end.startORResumeCourse();
	    	end.completeCourse();
		    end.onlyExitCourse();
		    
	    }
	    usrMg.switchTab();
	    usrMg.closeOtherTab();
	}
	
	@Then("Launch the course with {string} without exit the course with {string}")
	public void Launch_the_course_with_name_with_exit_course(String course,String courseDate) 
	{
	    end = new EndUser();
	    usrMg.switchTab();
	    end.launchCourseWithName(course);
	    end.clickOnSubmitOnlyWithDate(courseDate);
		
	    int count = end.getNumberRows();
	    System.out.println("count is " + count);
	   
	    	end.startORResumeCourse();

	}
	
	@Then("Exit from course")
	public void Exit_From_course() 
	{
		end = new EndUser();
	   
	      end.onlyExitCourse();
	}
	
	@Then("activate the course")
	public void activate_the_course() 
	{
		end = new EndUser();
	    usrMg.switchTab();
	    end.launchUserCourse1();
	    end.clickOnSubmitOnly();
	    usrMg.switchTab();
	    usrMg.closeOtherTab();
	}
	@Then("activate the course name {string}")
	public void activatethe_course(String course) 
	{
		end = new EndUser();
	    usrMg.switchTab();
	    end.launchCourseWithName(course);
	    end.clickOnSubmitOnly();
	    usrMg.switchTab();
	    usrMg.closeOtherTab();
	}
	
	@Then("navigate to organization page")
	public void navigate_to_organization_page() 
	{
		if(usrMg == null)
			usrMg = new UserManagement();
	    db = new DashBoard();
	    usrMg.navigateDashboard();
	    db.selectOrgpanel();
	}

	@Then("complete the course topics as per the date {string}")
	public void complete_the_course_topics_as_per_the_date(String courseDate) 
	{
		end = new EndUser();
	    usrMg.switchTab();
	    end.runScriptForPastDate(courseDate);
	    end.launchUserCourse1();
	    end.clickOnSubmitOnlyWithDate(courseDate);
	    int count = end.getAvailableTopicNumber();
	    System.out.println("count is " + count);
	    for(int i =1; i <= count; i++)
	    {
	    	end.startORResumeCourse();
	    	end.completeCourse();
		    end.onlyExitCourse();
		    
	    }
	    
	}
	@Then("Review the completed courses and ecard {string}")
	public void review_the_completedcourses(String q1) 
	{
		if(end == null)
			end = new EndUser();
	    end.navigateCompletedPrograms();
	    end.clickOnCompletedCourseReviews();
	    end.clickOnSubmitOnlyWithDate(q1);
	    end.clickOnCompletedCourseEcard();
	    end.clickEndUserProgramLink();
	}
	@Then("Review the completed courses {string} and ecard {int}")
	public void review_the_completed_courses(String course,int q1) 
	{
		if(end == null)
			end = new EndUser();
	    end.navigateCompletedPrograms();
	    end.clickOnCompletedCourseReviews(course);
	    String date = end.changeDate(q1);
	    end.clickOnSubmitOnlyWithDate(date);
	    end.clickOnCompletedCourseEcard(course);
	    end.clickEndUserProgramLink();
	}
	
	@Then("Review the completed {string} courses ecard and Certificate if applicable {int}")
	public void review_the_completedcourses(String course,int q1) 
	{
		if(end == null)
			end = new EndUser();
	    end.navigateCompletedPrograms();
	    end.clickOnCompletedCourseReviews(course);
	    String date = end.changeDate(q1);
	    end.clickOnSubmitOnlyWithDate(date);
	    end.clickOnCompletedCourseEcard(course);
	    end.clickOnCompletedCourseCertificate(course);
	    end.clickEndUserProgramLink();
	}
	
	@Then("Review the completed {string} courses Certificate {int}")
	public void review_the_Certificatecompletedcourses(String course,int q1) 
	{
		if(end == null)
			end = new EndUser();
	    end.navigateCompletedPrograms();
	    end.clickOnCompletedCourseReviews(course);
	    String date = end.changeDate(q1);
	    end.clickOnSubmitOnlyWithDate(date);
	    end.clickOnCompletedCourseCertificate(course);
	    end.clickEndUserProgramLink();
	}
	
	
	@Then("complete the whole course as per the date {string}")
	public void complete_the_whole_course_as_per_the_date(String courseDate) 
	{
		end = new EndUser();
	    usrMg.switchTab();
	    end.runScriptForPastDate(courseDate);
	    end.launchUserCourse1();
	    end.clickOnSubmitOnlyWithDate(courseDate);
	    int count = end.getNumberRows();
	    System.out.println("count is " + count);
	    for(int i =1; i <= count; i++)
	    {
	    	end.startORResumeCourse();
	    	end.completeCourse();
		    end.onlyExitCourse();
		    
	    }
	    usrMg.switchTab();
	    usrMg.closeOtherTab();
	}
	@Then("user activate course as name {string} with quarter {int}")
    public void click_on_activate_course_as_name(String courseName, int quarter)
    {
        if(end == null)
        	end = new EndUser();
        end.launchCourseWithName(courseName);
        String date = end.changeDate(quarter);
        end.runScriptForPastDate(date);
        end.clickOnSubmitOnlyWithDate(date);
        end.clickEndUserProgramLink();
    }
	@Then("switch the tab")
	public void switch_the_tab()
	{
		if(usrMg == null)
			usrMg = new UserManagement();
		usrMg.switchTab();
	   
	}
	
	@Then("switch the tab to user")
	public void switch_the_tab_to_user()
	{
		if(usrMg == null)
			usrMg = new UserManagement();
		usrMg.switchTab();
	}
	
	@Then("switch the tab to scrom")
	public void switch_the_tab_to_scrom()
	{
		if(usrMg == null)
			usrMg = new UserManagement();
		usrMg.switchTab();
	}
	
	@Then("navigate to user programs")
	public void navigate_to_user_programs() 
	{
		if(end == null)
			end = new EndUser();
	    end.clickEndUserProgramLink();
	}
	
	@Then("Give the date {string} for the course")
	public void give_the_date_for_the_course(String date) 
	{
		end = new EndUser();
		end.runScriptForPastDate(date);
	    end.launchUserCourse1();
	    end.clickOnSubmitOnlyWithDate(date);
	}
	
	@Then("Give the date {int} for the course")
	public void give_the_date_for_the_course(int q) 
	{
		end = new EndUser();
		 String date = end.changeDate(q);
		end.runScriptForPastDate(date);
	    end.launchUserCourse1();
	    end.clickOnSubmitOnlyWithDate(date);
	}
	

	@Then("Give the date {int} for the course {string}")
	public void give_the_date_for_the_course(int q,String course) 
	{
		end = new EndUser();
		 String date = end.changeDate(q);
		end.runScriptForPastDate(date);
	    end.launchCourseWithName(course);
	    end.clickOnSubmitOnlyWithDate(date);
	}
	@Then("activate the course as per the date {string}")
	public void activate_the_course_as_per_the_date(String date) 
	{
		if(end == null)
			end = new EndUser();
	    usrMg.switchTab();
	    end.runScriptForPastDate(date);
	    end.launchUserCourse1();
	    end.clickOnSubmitOnlyWithDate(date);
	    usrMg.switchTab();
	    usrMg.closeOtherTab();
	}
	@Then("view ecard from course topic page")
	public void view_ecard_from_course_topic_page() 
	{
    if(end == null)
    	end = new EndUser();
    end.clickEcardButton();
    end.switchToCertificatePage();
    end.clickviewCertficateButtonPage();
    end.switchToPDFPage();
	}
	@Then("switch to application tab and close other")
	public void switch_to_application_tab_and_close_other() 
	{
		end.switchToApplicationPage();
	}

	@Then("user launch course as name {string} with quarter {int}")
    public void click_on_launch_course_as_name_with_quarter(String courseName, int quarter)
    {
        if(end == null)
        	end = new EndUser();
        end.launchCourseWithName(courseName);
        String date = end.changeDate(quarter);
        end.runScriptForPastDate(date);
        end.clickOnSubmitOnlyWithDate(date);
        end.startORResumeCourse();
        end.onlyExitCourse();
        end.clickEndUserProgramLink();
    }
	@Then("validate the course {string} topics are locked as per the quarter date {int}")
    public void validate_the_course_topics_are_locked_as_per_the_quarter_date(String courses, Integer quarter)
    {
        if(end == null)
        	end = new EndUser();
        String name[] = courses.split(",");
        for(int i = 0; i <= name.length-1; i++)
        {
            String date = end.changeDate(quarter);
            end.runScriptForPastDate(date);
            boolean flag = end.launchCourseWithName(name[i]);
             if(flag == true)
                {
            	 end.clickOnSubmitOnlyWithDate(date);
                    int lockCount = end.validateAvailableTopicLocked();
                    System.out.println("count is " + lockCount);
                    Assert.assertTrue(lockCount >= 1);
                }
             end.clickEndUserProgramLink();
        }
    }

	@Then("complete the multiple whole courses {string} as per the date {string}")
	public void complete_the_multiple_whole_course_as_per_the_date(String names, String courseDate) 
	{
		if(end == null)
			end = new EndUser();
	    usrMg.switchTab();
	    String name[] = names.split(",");
	    
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	
	    	end.runScriptForPastDate(courseDate);
		    boolean flag = end.launchCourseWithName(name[i]);
		    System.out.println(flag);
		    if(flag == true)
		    {
		    	
		    	end.clickOnSubmitOnlyWithDate(courseDate);
			    int count = end.getNumberRows();
			    System.out.println("count is " + count);
			    for(int j =1; j <= count; j++)
			    {
			    	end.startORResumeCourse();
//			    	end.completeCourse();
			    	end.completeCourseTestCode();
				    end.onlyExitCourse();
				    
			    }
			    end.clickEndUserProgramLink();
		    }
		    
	    }
	}
	
	@Then("complete the multiple whole courses {string} as per the date {string} as Student")
	public void complete_themultiple_whole_course_as_per_the_date(String names, String courseDate) 
	{
		if(end == null)
			end = new EndUser();
//	    usrMg.switchTab();
	    String name[] = names.split(",");
	    
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	
	    	end.runScriptForPastDate(courseDate);
		    boolean flag = end.launchCourseWithName(name[i]);
		    System.out.println(flag);
		    if(flag == true)
		    {
		    	end.clickOnSubmitOnlyWithDate(courseDate);
			    int count = end.getNumberRows();
			    System.out.println("count is " + count);
			    for(int j =1; j <= count; j++)
			    {
			    	end.startORResumeCourse();
			    	end.completeCourseTestCode();
				    end.onlyExitCourse();
				    
			    }
			    end.cecmepopup(name[i]);
			    end.clickEndUserProgramLink();
		    }
		    
	    }
	}
	
	
	@Then("complete the multiple whole courses {string} as per the date {string} close {string}")
	public void complete_the_multiple_whole_course_as_per_the_date(String names, String courseDate,String close) 
	{
		if(end == null)
			end = new EndUser();
	    usrMg.switchTab();
	    String name[] = names.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	end.runScriptForPastDate(courseDate);
		    boolean flag = end.launchCourseWithName(name[i]);
		    System.out.println(flag);
		    if(flag == true)
		    {
		    	end.clickOnSubmitOnlyWithDate(courseDate);
			    int count = end.getNumberRows();
			    System.out.println("count is " + count);
			    for(int j =1; ;)
			    {
			    	end.startORResumeCourse();
			    	end.completeCourse();
			    	
			    	j++;
			    		if(j <= count)
			    		{
			    			  end.onlyExitCourse();
					 		
			    		}
			    		else
			    		{
			    			if(close.contains("closeWithoutExit"))
			    		{
			    					    			break;
			    		}
			    			else
			    			{
			    				end.onlyExitCourse();
			    				   break;
			    			}
			    		}
			    		
			    }
			    
			    if(close.contains("close"))
		    	{
	    		 TestBase.driver.close();
	    			Set <String> allWindowHandles = TestBase. driver.getWindowHandles();
	    			System.out.println(allWindowHandles.size());
	    			TestBase.driver.switchTo().window(allWindowHandles.toArray()[0].toString());
	    		
	    			
		    		break;
		    	}
	    	
	    	
			   
			    
			   
		    }
		    
	    }
	    
	   
	}
	
	@Then("complete the multiple courses {string} topics as per the date {string}")
	public void complete_the_multiple_course_topics_as_per_the_date(String names, String courseDate) 
	{
		if(end == null)
			end = new EndUser();
	    String name[] = names.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	end.runScriptForPastDate(courseDate);
		    boolean flag = end.launchCourseWithName(name[i]);
		    System.out.println(flag);
		    if(flag == true)
		    {
		    	end.clickOnSubmitOnlyWithDate(courseDate);
			    int count = end.getAvailableTopicNumber();
			    System.out.println("count is " + count);
			    for(int j =1; j <= count; j++)
			    {
			    	end.startORResumeCourse();
//			    	end.completeCourse();
			    	end.completeCourseTestCode();
				    end.onlyExitCourse();
				    
			    }
			    end.evaluateCourse();
			    end.clickEndUserProgramLink();
		    }
		    
	    }
	}
	@Then("Resume and complete the multiple courses {string} topics as per the date {string}")
	public void complete_themultiple_scourse_topics_as_per_the_date(String names, String courseDate) 
	{
		if(end == null)
			end = new EndUser();
//		usrMg.switchTab();
	    String name[] = names.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	end.runScriptForPastDate(courseDate);
		    boolean flag = end.launchCourseWithNameResume(name[i]);
		    System.out.println(flag);
		    if(flag == true)
		    {
		    	end.clickOnSubmitOnlyWithDate(courseDate);
			    int count = end.getAvailableTopicNumber();
			    System.out.println("count is " + count);
			    for(int j =1; j <= count; j++)
			    {
			    	end.startORResumeCourse();
			    	end.completeCourse();
				    end.onlyExitCourse();
				    
			    }
			    end.evaluateCourse();
			    end.clickEndUserProgramLink();
		    }
		    
	    }
	
	}
	@Then("activate the multiple course as per the name {string}")
	public void activate_the_multiple_course_as_per_name(String coursesName) 
	{
		if(end == null)
			end = new EndUser();
	    usrMg.switchTab();
	    String name[] = coursesName.split(",");
	    System.err.println("testttt");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	end.startCourseWithName(name[i]);
	    }
	    System.err.println("testttt");
		    usrMg.switchTab();
		    usrMg.closeOtherTab();
	}
	@Then("launch the multiple whole courses {string} as per the quarter date {int}")
	public void launch_the_multiple_whole_courses_as_per_the_quarter_date(String names, int quarter) 
	{
		if(end == null)
			end = new EndUser();
		String name[] = names.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	String date = end.changeDate(quarter);
	    	end.runScriptForPastDate(date);
	    	boolean flag = end.launchCourseWithName(name[i]);
		    System.out.println(flag);
		    if(flag == true)
		    {
		    	end.clickOnSubmitOnlyWithDate(date);
		    	int count = end.getAvailableTopicNumber();
			    System.out.println("count is " + count);
		    	end.startORResumeCourse();
			    end.onlyExitCourse();
			   }
			    end.clickEndUserProgramLink();
		    }
		    
	    }
	@Then("navigate to coure topic page as per name {string} with quarter {int}")
	public void navigate_to_coure_topic_page_as_per_name_with_quarter(String courses, Integer quarter) 
	{
		
		EndUser	proxy = new EndUser();
		String name[] = courses.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	String date = proxy.changeDate(quarter);
	    	proxy.runScriptForPastDate(date);
	    	boolean flag = proxy.launchCourseWithName(name[i]);
	    	 if(flag == true)
			    {
			    	proxy.clickOnSubmitOnlyWithDate(date);
			    }
	    }
	}
	@Then("give the date for completed course as per quarter {int}")
	public void give_the_date_for_completed_course(int quarter) 
	{
		String courseDate = end.changeDate(quarter);
		end.clickOnSubmitOnlyWithDate(courseDate);
	}
	@Then("navigate to manage course page")
	public void navigate_to_manage_course_page() 
	{
		if(end == null)
			end = new EndUser();
//		if(proxy == null)
//			proxy = new ProxyUser();
		end.clickEndUserProgramLink();
	}

	@Then("validate the error message for course launch as course name {string} with quarter {int}")
	public void validate_the_error_message_for_course_launch_as_course_name(String courseName, int quarter) 
	{
		
		EndUser	proxy = new EndUser();
		proxy.launchCourseWithName(courseName);
        String date = proxy.changeDate(quarter);
    	proxy.runScriptForPastDate(date);
        proxy.clickOnSubmitOnlyWithDate(date);
		proxy.validateCourseLaunchError();
	}
	 @Then("validate the UI details for proxy user")
		public void validate_the_ui_details_for_proxy_user() 
		{
		 if(end == null)
				end = new EndUser();
		 end.validateHeaderFooter();
		 end.validateMenuOption();
		 end.validateSupportOption();
		 end.validateWelcome();
		 end.validateSideMenuOption();
		}
	 
	 @Then("validate the links on page for proxy user")
		public void validate_the_links_on_page_for_proxy_user() 
		{
		 if(end == null)
				end = new EndUser();
		 end.validateResponseForLink();
		}

		@Then("validate the row count for active courses")
		public void validate_the_row_count_for_active_courses() 
		{
//			if(proxy == null)
//				proxy = new ProxyUser();
			end.courseNotAvaialble();
		}
		
	@Then("complete the multiple whole courses {string} as per the quarter date {int}")
	public void complete_the_multiple_whole_course_as_per_the_quarter_date(String names, int quarter)
	{
	if(end == null)
	end = new EndUser();
	if(usrMg == null)
		usrMg= new UserManagement();
	
	usrMg.switchTab();
	String name[] = names.split(",");
	for(int i = 0; i <= name.length-1; i++)
	{
	String date = end.changeDate(quarter);
	end.runScriptForPastDate(date);
	boolean flag = end.launchCourseWithName(name[i]);
	System.out.println(flag);
	if(flag == true)
	{
	end.clickOnSubmitOnlyWithDate(date);
	System.out.println(date);
	int count = end.getNumberRows();
	System.out.println("count is " + count);
	for(int j =1; j <= count; j++)
	{
	end.startORResumeCourse();
	end.completeCourseTestCode();
	end.onlyExitCourse();

	}
	end.clickEndUserProgramLink();
	}

	}
	}
	
	@Then("validate the error message for given course launch {string} with date {int}")
	public void validate_the_error_message_for_given_course_launch_with_date(String names, int quarter) 
	{
		if(end == null)
			end = new EndUser();
		String name[] = names.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	end.launchCourseWithName(name[i]);
	    	String date = end.changeDate(quarter);
		    end.clickOnSubmitOnlyWithDate(date);
		    end.validateCourseLaunchError();
		    end.clickEndUserProgramLink();
	    }
	}
	@Then("complete the multiple whole course {string} as per the quarter date {int}")
	public void complete_the_multiple_whole_cours_as_per_the_quarter_date(String names, int quarter)
	{
	if(end == null)
	end = new EndUser();
	if(usrMg == null)
		usrMg= new UserManagement();
	
	String name[] = names.split(",");
	for(int i = 0; i <= name.length-1; i++)
	{
	String date = end.changeDate(quarter);
	end.runScriptForPastDate(date);
	boolean flag = end.launchCourseWithName(name[i]);
	System.out.println(flag);
	if(flag == true)
	{
	end.clickOnSubmitOnlyWithDate(date);
	System.out.println(date);
	int count = end.getNumberRows();
	System.out.println("count is " + count);
	for(int j =1; j <= count; j++)
	{
	end.startORResumeCourse();
	end.completeCourseTestCode();
	end.onlyExitCourse();

	}
	  end.cecmepopup(name[i]);
	  if(OrganizationDetails.subDomain!=null)
	  if(names.toLowerCase().contains("entry")&& TestBase.driver.getCurrentUrl().contains(OrganizationDetails.subDomain))
	  {
		  end. cecmepopupforsub();
	  }
	  end.evaluateCourse(name[i]);
	end.clickEndUserProgramLink();
	}

	}
	}
	@Then("complete the multiple whole course {string} as per the quarter date {int} for TRcourse")
	public void complete_the_multiple_whole_cours_as_per_the_quarter_dateforTr(String names, int quarter)
	{
	if(end == null)
	end = new EndUser();
	if(usrMg == null)
		usrMg= new UserManagement();
	
	String name[] = names.split(",");
	for(int i = 0; i <= name.length-1; i++)
	{
	String date = end.changeDate(quarter);
	end.runScriptForPastDate(date);
	boolean flag = end.launchCourseWithName(name[i]);
	System.out.println(flag);
	if(flag == true)
	{
	end.clickOnSubmitOnlyWithDate(date);
	System.out.println(date);
	int count = end.getNumberRows();
	System.out.println("count is " + count);
	for(int j =1; j < count; j++)
	{
	end.startORResumeCourse();
	end.completeCourseTestCode();
	end.onlyExitCourse();

	}
	  end.cecmepopup(name[i]);
	  end.evaluateCourse(name[i]);
	end.clickEndUserProgramLink();
	}

	}
	}
	
	@Then("launch the course with name {string} as per the quarter date {int} and validate ecard")
	public void launch_the_course_with_name(String name,int q)
	{
	if(end == null)
	end = new EndUser();
	end.clickOnCurrentPrograms();
	end.launchCourseWithName(name);
	String date = end.changeDate(q);
	end.clickOnSubmitOnlyWithDate(date);
	end.clickOnCompletedCourseEcard(name);
	 end.clickEndUserProgramLink();
	}
	@Then("launch the course with name {string} as per the quarter date {int}")
	public void launch_the_course_with_name_Cme(String name,int q)
	{
	if(end == null)
	end = new EndUser();
	end.clickOnCurrentPrograms();
	end.launchCourseWithName(name);
	String date = end.changeDate(q);
	end.clickOnSubmitOnlyWithDate(date);
	}
	@Then("complete the multiple courses {string} topics as per the quarter date {int}")
	public void complete_the_multiple_course_topics_as_per_the_quarter_date(String names, int quarter) throws InterruptedException
	{
	if(end == null)
	end = new EndUser();
	String name[] = names.split(",");
	for(int i = 0; i <= name.length-1; i++)
	{
	String date = end.changeDate(quarter);
	end.runScriptForPastDate(date);
	boolean flag = end.launchCourseWithName(name[i]);
	System.out.println(flag);
	if(flag == true)
	{
	end.clickOnSubmitOnlyWithDate(date);
	int count = end.getAvailableTopicNumber();
	System.out.println("count is " + count);
	
	for(int j =1; j <= count; j++)
	{
		Thread.sleep(5000);
		end.startORResumeCourse();
	end.completeCourseTestCode();
	end.onlyExitCourse();
	}
	end.clickEndUserProgramLink();
	}

	}
	}
	@Then("Launch the multiple courses {string} topics as per the date {string} with one topic left")
	public void Launch_the_multiple_course_topics_as_per_the_date_with_one_topic_left(String names, String courseDate) 
	{
		if(end == null)
			end = new EndUser();
	    String name[] = names.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	end.runScriptForPastDate(courseDate);
		    boolean flag = end.launchCourseWithName(name[i]);
		    System.out.println(flag);
		    if(flag == true)
		    {
		    	end.clickOnSubmitOnlyWithDate(courseDate);
			    int count = end.getAvailableTopicNumber();
			    System.out.println("count is " + count);
			    if(count > 1)
			    {
			    	for(int j =1; j <= count-1; j++)
				    {
				    	end.startORResumeCourse();
				    	end.completeCourse();
					    end.onlyExitCourse();
					    
				    }
			    }
			    else
			    {
			    	end.startORResumeCourse();
			    	end.completeCourse();
				    end.onlyExitCourse();
			    }
			    
			    end.clickEndUserProgramLink();
		    }
		    
	    }
	}
	
	@Then("complete the multiple courses {string} in quarter {int} with one topic left")
	public void Launch_the_multiple_course_topics_as_per_the_date_with_one_topic_left(String names, int quarter) 
	{
		if(end == null)
			end = new EndUser();
	    String name[] = names.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	String date = end.changeDate(quarter);
	    	end.runScriptForPastDate(date);
		    boolean flag = end.launchCourseWithName(name[i]);
		    System.out.println(flag);
		    if(flag == true)
		    {
		    	end.clickOnSubmitOnlyWithDate(date);
			    int count = end.getAvailableTopicNumber();
			    System.out.println("count is " + count);
			    if(count > 1)
			    {
			    	for(int j =1; j <= count-1; j++)
				    {
				    	end.startORResumeCourse();
				    	end.completeCourseTestCode();
					    end.onlyExitCourse();
					    
				    }
			    }
			    else
			    {
			    	end.startORResumeCourse();
			    	end.completeCourseTestCode();
				    end.onlyExitCourse();
			    }
			    
			    end.clickEndUserProgramLink();
		    }
		    
	    }
	}

	@Then("delete the user on usermanagement screen")
	public void delete_the_user_on_usermanagement_screen() {
		if(usrMg == null)
			usrMg = new UserManagement();
		usrMg.deleteDearchedUser();
	}
	


}

