package stepDefinitions;

import com.qa.pages.manualTest;
import io.cucumber.java.en.Then;
public class manualTestSteps 
{
	manualTest test;

	@Then("navigate to report page")
	public void navigate_to_report_page() 
	{
		test = new manualTest();
		test.navigateConsumptionReport();
	}
	
	@Then("select the dates {string} {string}")
	public void select_the_dates(String from, String end) 
	{
		test.clickStartDate();
	    test.selectDate(from);
	    test.clickEndDate();
	    test.selectDate(end);
	}
	
	@Then("select the number of org {int}")
	public void select_the_number_of_org(Integer count) 
	{
	    test.clickSelectOrg();
	    test.selectOrgAsCount(count);
	}

	@Then("User read the data sheet")
	public void user_read_the_data_sheet() 
	{
		test = new manualTest();
	    test.readDataSheet();
	}
	
}
