package stepDefinitions;

import com.qa.pages.NotificationSettings;
import com.qa.pages.OrganizationHome;
import com.qa.pages.OrganizationSettings;
import com.qa.pages.SSOSetting;
import com.qa.pages.User;

import io.cucumber.java.en.Then;

public class NotificationSettingsSteps {

	OrganizationHome orgHome;
	SSOSetting sso;
	String orgID;
	SSOSetting ssoSettings = new SSOSetting();

	NotificationSettings notiSet = new NotificationSettings();

	@Then("Click on Dashboard Page")
	public void Click_on_Dashboardpage() {
		notiSet.ClickOnHomeButton();
	}

	@Then("Select the Organization Tab {string}")
	public void SelectOrganizationTab(String value) {
		notiSet.SelectOrgTab(value);
	}

	@Then("Select the navigation Tab {string}")
	public void SelectNavigationTab(String value) {
		notiSet.SelectNavTab(value);
		notiSet.checkwhetherStatusIsONorOFF();
	}

	@Then("Student Notifications {string}")
	public void StudentNotifications(String columnName) {
		notiSet.SelectStudentNotifications(columnName);
	}

	@Then("Select EventName From Student Notification {string} {int} {int}")
	public void selectEventNameFromStudentNotificationsTable(String cellValueToCompare, int ColumntoIterate,
			int ToGetvalueFromcolumn) {
		notiSet.selectEventNameFromStudentNotificationsTable(cellValueToCompare, ColumntoIterate, ToGetvalueFromcolumn);

	}
	
	@Then("Select EventName From Student Notification Off {string} {int} {int}")
	public void StudentNotificationsOff(String cellValueToCompare, int ColumntoIterate,
			int ToGetvalueFromcolumn) {
		notiSet.StudentNotificationsOff(cellValueToCompare, ColumntoIterate, ToGetvalueFromcolumn);
	}
	
	@Then("Select EventName From Admin Notification {string} {int} {int}")
	public void selectEventNameFromAdminNotificationsTable(String cellValueToCompare, int ColumntoIterate,
			int ToGetvalueFromcolumn) {
		notiSet.selectEventNameFromAdminNotificationsTable(cellValueToCompare, ColumntoIterate, ToGetvalueFromcolumn);
	}
	
	@Then("Select EventName Admin Notification off {string} {int} {int}")
	public void AdminNotificationsOff(String cellValueToCompare, int ColumntoIterate,
			int ToGetvalueFromcolumn) {
		notiSet.AdminNotificationsOff(cellValueToCompare, ColumntoIterate, ToGetvalueFromcolumn);
	}

	@Then("Admin Notifications {string}")
	public void AdminNotifications(String columnName) {
		notiSet.selectAdminNotifications(columnName);
	}
	
	
	@Then("Check whether Global Email Notifications Button {string}")
	public void SelectRadioButton(String radioValue) {
		notiSet.SelectRadioButton(radioValue);
	}

	public void SelectTabFromList(String tabValue) {
		notiSet.SelectTabFromList(tabValue);
	}

	@Then("Search the User By EmailId")
	public void SearchTheUserEmailId() throws InterruptedException {
		Thread.sleep(1000);
		notiSet.SearchUserByEmail(User.userEmail);
	}
	@Then("click On Notification Report Search Button")
	public void clickk_on_Notification() throws InterruptedException {
		Thread.sleep(1000);
		notiSet.NotificationSearchBtn();
	}

	
	
	@Then("Select User ViewDetails {string}")
	public void SelectViewDetails(String value) {
		notiSet.selectViewDetails(value);
	}

	@Then("Edit Template In Student Notifcations Table {string} {int} {int}")
	public void EditTemplateInStudentNotifcationsTable(String cellValueToCompare, int ColumntoIterate,
			int ToGetvalueFromcolumn) {
		notiSet.EditTemplateInStudentNotifcationsTable(cellValueToCompare, ColumntoIterate, ToGetvalueFromcolumn);
	}

	@Then("Edit the Email Content")
	public void EditContent() throws InterruptedException {
		notiSet.EditEmailContent();
	}

	@Then("check SSO Settings Is On")
	public void checkSSOSettingsIsOn() {

		if (orgHome == null) {
			orgHome = new OrganizationHome();
		}
		orgID = orgHome.clickSFTPSetting();
		ssoSettings.clickOnSSOTab();
		ssoSettings.CheckGenerateButton();
		ssoSettings.closeTab();
	}
	
	@Then("No reports data Found Message")
	public void NoReportsDataFound() {
		notiSet.NoRecordsFoundText();
	}
	
	@Then("This inbox is empty")
	public void ThisInboxisEmpty() {
		notiSet.InboxIsEmpty();
	}
	
	@Then("Select the value from notification log Table {string} {int} {int}")
	public void selectThevalueFromNotificationLogTable(String cellValueToCompare, int ColumntoIterate,
			int ToGetvalueFromcolumn) {
		notiSet.selectThevalueFromNotificationLogTable(cellValueToCompare, ColumntoIterate,
				 ToGetvalueFromcolumn);
	}
	
	@Then("Click On Notification link")
	public void ClickOnNotificationlink() {
		notiSet.ClickOnNotificationlink();
	}


	

	@Then("validate the notification event {string} status for student")
	public void validate_the_notification_event_status_student(String event) {
		notiSet.turnOnNotificationStudent(event);
	}
	
	@Then("validate the notification event {string} status for admin")
	public void validate_the_notification_event_status_admin(String event) {
		notiSet.turnOnNotificationAdmin(event);
	}
	
	@Then("turn off the notification event {string} for student")
	public void turn_off_the_notification_event_for_student(String event) {
		notiSet.turnOFFNotificationStudent(event);
	}
	
	@Then("turn off the notification event {string} for admin")
	public void turn_off_the_notification_event_for_admin(String event) {
		notiSet.turnOFFNotificationAdmin(event);
	}

	@Then("edit email template for notification event {string} for student")
	public void edit_email_template_for_notification_event_for_student(String event) {
		notiSet.editEmailTemplateNotificationStudent(event);
	}
	
	@Then("edit email template for notification event {string} for admin")
	public void edit_email_template_for_notification_event_for_admin(String event) {
		notiSet.editEmailTemplateNotificationAdmin(event);
	}
	@Then("validate no record display")
    public void validate_no_record_display()
    {
		notiSet.validateNoRecordDisplay();
    }
	
	

	@Then("export and validate the details on notification Settings report page")
	public void export_and_validate_the_details() 
	{
		if(notiSet == null)
			notiSet = new NotificationSettings();
		
		boolean flag = notiSet.checkCSVFilePresent();
		while(flag == true)
		{
			notiSet.deleteFile(User.filePath);
			flag = notiSet.checkCSVFilePresent();
		}			
		notiSet.clickExportButton();
		notiSet.verifyDownloadFile();
		notiSet.compareDetails();
	}
	
	/*
	 * @Then("create multiple user {int} {string} {string}") public void
	 * create_multiple_user(Integer count, String first, String last) { if (usr ==
	 * null) usr = new User(); if (org == null) org = new OrganizationHome();
	 * usr.addMultiuser(count, org, first, last); }
	 */

	@Then ("Search field")
	public void SearchField() {
		notiSet.SearchField();
	}

	@Then ("Success Message All Notifications")
	public void SuccessMessageAllNotifications() {
		notiSet.SuccessMessageAllNotifications();
	}
	
	@Then("Verify Reports Status {string} {string} {int} {int}")
	public void VerifyTheReportsStatus(String cellValueToCompare, String Status, int ColumntoIterate,
			int ToGetvalueFromcolumn ) {
		notiSet.VerifyTheReportsStatus(cellValueToCompare, ColumntoIterate, ToGetvalueFromcolumn, Status);

	}
	
	@Then("Verify and Click on CheckBox Reports Status {string} {string} {int} {int}")
	public void VerifyAndClickOnCheckBoxReportsStatus(String cellValueToCompare, String Status, int ColumntoIterate,
			int ToGetvalueFromcolumn ) {
	//	notiSet.VerifyAndClickOnCheckBoxReportsStatus(cellValueToCompare, ColumntoIterate, ToGetvalueFromcolumn, Status);
	//	notiSet.VerifyTheReportsStatusAndClickCheckBox(cellValueToCompare, Status, ColumntoIterate, ToGetvalueFromcolumn);
		notiSet.VerifyTheReportsStatusAndClickCheckBox(cellValueToCompare,Status, ColumntoIterate, ToGetvalueFromcolumn );
	}
	
	
	@Then("Click On CheckBox {string} {int} {int}")
	public void ClickOnCheckBox(String cellValueToCompare, int ColumntoIterate, int ToGetvalueFromcolumn ) {
		notiSet.ClickOnCheckBox(cellValueToCompare, ColumntoIterate, ToGetvalueFromcolumn);

	}

	@Then("Click on Notification Job Title Filter")
	public void click_on_job_title_filter() {
		if(notiSet == null)
			notiSet = new NotificationSettings();
		notiSet.clickOnJobTitle();
	}
	
	@Then("click On Notification Job Title Select All")
	public void click_On_Job_Title_Select_All() {
		if(notiSet == null)
			notiSet = new NotificationSettings();
		notiSet.clickOnJobTitleSelectAll();
	}
	
	@Then("click On Notification Job Title Un Select All")
	public void click_On_Job_Title_Un_Select_All() {
		if(notiSet == null)
			notiSet = new NotificationSettings();
		notiSet.clickOnJobTitleUnSelectAll();
	}
	
	
	@Then("Click on Notification Group Filter")
	public void click_on_group_filter() {
		if(notiSet == null)
			notiSet = new NotificationSettings();
		notiSet.clickOnGroup();
	}
	
	@Then("click On Notification Group Select All")
	public void click_On_Group_Select_All() {
		if(notiSet == null)
			notiSet = new NotificationSettings();
		notiSet.clickOnGroupSelectAll();
	}
	
	@Then("click On Notification Group Un Select All")
	public void click_On_Group_Un_Select_All() {
		if(notiSet == null)
			notiSet = new NotificationSettings();
		notiSet.clickOnGroupUnSelectAll();
	}
	
	@Then("click On Notification Button Org Name")
	public void click_On_Button_Org_Name() {
		if(notiSet == null)
			notiSet = new NotificationSettings();
		notiSet.SearchButtonOrgName();
	}
	
	@Then("click On Notification UnSelect Button Org Name")
	public void click_On_UnSelect_Org_Name() {
		if(notiSet == null)
			notiSet = new NotificationSettings();
		notiSet.SearchButtonUnSelectAll();
	}
	
	
	@Then("click On Notification Select Button Org Name")
	public void click_On_Select_Org_Name() {
		if(notiSet == null)
			notiSet = new NotificationSettings();
		notiSet.SearchButtonSelectAll();
	}
	
	@Then("click On Notification Course Filters")
	public void ClickOnNotiCourseFilters() {
		if(notiSet == null)
			notiSet = new NotificationSettings();
		notiSet.ClickOnNotiCourseFilters();
	}
	
	
	@Then("multi select course filter status on Notification report page {int}")
	public void multi_select_course_filter_status_on_learner_Activity_report_page(int count) {
		if(notiSet == null)
			notiSet = new NotificationSettings();
		for(int i = 0; i < count; i++) {
			notiSet.selectMultiUserCourseFilter();	
		}
		notiSet.clickOnCourseFilterSearchButton();
	}
	
	
	@Then("click On Course Notification UnselectAll Filters")
	public void clickOnUnselectAllFilters() {
		if(notiSet== null)
			notiSet = new NotificationSettings();
		notiSet.UnselectAllCourse();
	}
	
	
	@Then("click On Course Notification SelectAll Filters")
	public void clickOnSelectAllFilters() {
		if(notiSet== null)
			notiSet = new NotificationSettings();
		notiSet.selectAllCourse();
	}
	
	
	@Then("click On Notifications Course Filters")
	public void clickOnCourseFilters() {
		if(notiSet== null)
			notiSet = new NotificationSettings();
		notiSet.clickOnCourseFilters();
	}
	
	
	@Then("click On Notifications Course Button")
	public void Coure_Button() {
		if(notiSet== null)
			notiSet = new NotificationSettings();
		notiSet.Coure_Button();
	}
	
	
	
	
	
	@Then("click On Notification Search Button")
	public void click_On_Notification_Search_More_Filter() {
		if(notiSet == null)
			notiSet = new NotificationSettings();
	//	notiSet.SearchButtonMoreFilter();
		notiSet.clickOnCourseFilterSearchButton();
	}
	
	
	@Then("Search More Filter")
	public void click_On_Search_More_Filter() {
		if(notiSet == null)
			notiSet = new NotificationSettings();
		notiSet.SearchButtonMoreFilter();
	}
	
	@Then("click Notification Course Filter")
	public void clickCourseFilter() {
		if(notiSet== null)
			notiSet = new NotificationSettings();
		notiSet.SelectCourse();
	}
	
	
	@Then("multi select Job filter status on Notification page {int}")
	public void multi_select_job_filte_status_on_learner_report_page(int count) {
		if(notiSet == null)
			notiSet = new NotificationSettings();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(int i = 0; i < count; i++) {
			notiSet.selectMultiJobFilter();	
		}
	//	lactFailure.clickOnMoreFilterSearchButton();
	}
	
	@Then("multi select group filter status on notification report page {int}")
	public void multi_select_group_filter_status_on_learner_report_page(int count) {
		if(notiSet == null)
			notiSet = new NotificationSettings();
		for(int i = 0; i < count; i++) {
			notiSet.selectMultiGroupFilter();	
		}
	//	lactFailure.clickOnMoreFilterSearchButton();
	}
	
	//------------------------------------------------------------------------------------------------
	
//	Org level
	
	@Then("select Group By Search Filter")
	public void selectGroupBySearchFilter() {
		if(notiSet== null)
			notiSet = new NotificationSettings();
		notiSet.selectGroupBySearchFilter(OrganizationSettings.groupName);
	}
	
	
	@Then("click on Notification Org level Filter")
	public void Button_OrgLevel() {
		if(notiSet== null)
			notiSet = new NotificationSettings();
		notiSet.Button_OrgLevel();
	}
	
	@Then("click on Notification link")
	public void Link_Notification() {
		if(notiSet== null)
			notiSet = new NotificationSettings();
		notiSet.Link_Notification();
	}
	
	@Then("click on Notification Title")
	public void Button_NotificationTitle() {
		if(notiSet== null)
			notiSet = new NotificationSettings();
		notiSet.Button_NotificationTitle();
	}
	
	
	@Then("click on Notification Title Select All")
	public void NotificationSelectAll() {
		if(notiSet== null)
			notiSet = new NotificationSettings();
		notiSet.NotificationSelectAll();
	}
	
	
	@Then("click on Notification Title Unselect All")
	public void NotificationUnSelectAll() {
		if(notiSet== null)
			notiSet = new NotificationSettings();
		notiSet.NotificationUnSelectAll();
	}
	
	
	@Then("click on Notification Delivery Status")
	public void Button_DeliveryStatus() {
		if(notiSet== null)
			notiSet = new NotificationSettings();
		notiSet.Button_DeliveryStatus();
	}
	
	
	@Then("click on Delivery Status SelectAll")
	public void DeliveryStatus_SelectAll() {
		if(notiSet== null)
			notiSet = new NotificationSettings();
		notiSet.DeliveryStatus_SelectAll();
	}
	
	@Then("click on Delivery Status UnselectAll")
	public void DeliveryStatus_UnselectAll() {
		if(notiSet== null)
			notiSet = new NotificationSettings();
		notiSet.DeliveryStatus_UnselectAll();
	}
	
	
	@Then("click on Notification log search")
	public void Button_NotificationSearch() {
		if(notiSet== null)
			notiSet = new NotificationSettings();
		notiSet.Button_NotificationSearch();
	}
	
	
	@Then("Select Text From Org List {string}")
	public void SelectTextFromOrgList(String value) {
		if(notiSet== null)
			notiSet = new NotificationSettings();
		notiSet.SelectTextFromOrgList(value);
	}
	
	
	@Then("Select Text From DropDown Delivery Status {string}")
	public void SelectTextFromDropDownDeliveryStatus(String value) {
		if(notiSet== null)
			notiSet = new NotificationSettings();
		notiSet.SelectTextFromDropDownDeliveryStatus(value);
	}
	
	@Then("Select Text From DropDown Notifications {string}")
	public void SelectTextFromDropDownNotifications(String value) {
		if(notiSet== null)
			notiSet = new NotificationSettings();
		notiSet.SelectTextFromDropDownNotifications(value);
	}
	
	
	@Then("Select Row learner Table List {int} {int}")
	public void Row_learnerTableList(int rowvalue, int columnValue) {
		if(notiSet== null)
			notiSet = new NotificationSettings();
		notiSet.Row_learnerTableList(rowvalue, columnValue);
	}
	
	
	@Then("Select Drop Down Value {string}")
	public void DropDownValue(String value) {
		if(notiSet== null)
			notiSet = new NotificationSettings();
		notiSet.DropDownValue(value);
	}
	
	
	@Then("verify Resend Button and checkbox Disabled")
	public void ResendButtonDisabled() {
		if(notiSet== null)
			notiSet = new NotificationSettings();
		notiSet.ResendButtonDisabled();
	}
	
	@Then("Notification Clear Search")
	public void NotificationClearSearch() {
		if(notiSet==null)
			notiSet = new NotificationSettings();
		notiSet.NotificationClearSearch();
	}
	
	
	@Then("More Filter Button Clear Search")
	public void MoreFilterButtonClearSearch() {
		if(notiSet==null)
			notiSet = new NotificationSettings();
		notiSet.MoreFilterButtonClearSearch();
	}
	
	@Then("User Status Search {string}")
	public void SearchStatus(String value) {
		if(notiSet==null)
			notiSet = new NotificationSettings();
		notiSet.SearchStatusValue(value);
	}
	
	@Then("Click on User Status")
	public void userStatus() {
		if(notiSet==null)
			notiSet = new NotificationSettings();
		notiSet.userStatus();
	}

	@Then("UserStatus Select All")
	public void UserStatus_SelectAll() {
		if(notiSet==null)
			notiSet = new NotificationSettings();
		notiSet.UserStatus_SelectAll();
	}
	
	
	@Then("UserStatus Unselect All")
	public void UserStatus_UnselectAll() {
		if(notiSet==null)
			notiSet = new NotificationSettings();
		notiSet.UserStatus_UnselectAll();
	}
	
	
}
