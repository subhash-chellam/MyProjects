package stepDefinitions;

import com.qa.pages.Encryption;
import io.cucumber.java.en.Then;

public class EncryptionSteps {
	Encryption ep;
	
	@Then("click on Demographic template settings tab")
	public void click_on_demographic_template_settings_tab() {
		ep = new Encryption();   
		ep.demographiclinkclick();
	}

	@Then("Verify label displayed {string}")
	public void verify_label_displayed(String string) {
	    ep = new Encryption();
	    ep.labeldisplayedverification(string);
	}

	@Then("verify that {string} and {string} are disabled by default")
	public void verify_that_and_are_disabled_by_default(String string, String string2) {
		ep = new Encryption();
		ep.verifybuttonsdisabledbydefault(string);
		ep.verifybuttonsdisabledbydefault(string2);

	}
	@Then("verify that {string} and {string} are enable")
	public void verify_that_and_are_disabled_are_enable(String string, String string2) {
		ep = new Encryption();
		ep.verifybuttonsdisabledbyenable(string);
		ep.verifybuttonsdisabledbyenable(string2);

	}

	@Then("Select encryption method as {string}")
	public void select_encryption_method_as(String string) throws InterruptedException {
		ep = new Encryption();
	    ep.selectencryption(string);
	    
	}
	@Then("validate encryption method default value {string}")
	public void validate_encryption_method_as(String string) throws InterruptedException {
		ep = new Encryption();
	    ep.defaultselectedvalue(string);
	    
	}
	@Then("check if Remove Encryption button exists")
	public void checkIfRemovekeybuttonExists() throws InterruptedException {
		try {
			  ep = new Encryption();
			  ep.clickremovekeybutton();
		} catch (Exception e) {
			
		}
	
	}
	@Then("Verify that {string} and {string} are enabled")
	public void verify_that_and_are_enabled(String string, String string2) {
	   ep.verifybuttonsenabledafterverification(string);
	   ep.verifybuttonsenabledafterverification(string2);
	}
	@Then("click on upload key button")
	public void click_on_upload_key_button() throws InterruptedException {
	  ep = new Encryption();
	  ep.clickuploadkey();
	}
	
	@Then("click on Generate key button")
	public void click_on_Generate_key_button() throws InterruptedException {
	  ep = new Encryption();
	  ep.clickgeneratekeybutton();
	}
	@Then("click on Regenerate key button")
	public void click_on_ReGenerate_key_button() throws InterruptedException {
	  ep = new Encryption();
	  ep.clickregeneratekeybutton();
	}
	
	@Then("click on Remove Encryption button")
	public void clickon_Generate_key_button() throws InterruptedException {
	  ep = new Encryption();
	  ep.clickremovekeybutton();
	}


	@Then("click on View key button")
	public void click_on_View_key_button() throws InterruptedException {
	  ep = new Encryption();
	  ep.clickViewkeybutton();
	}


	@Then("verify the header within pop up {string}")
	public void verify_the_header_within_pop_up(String string) {
	    ep.verifyheaderwithinpopup(string);
	}

	@Then("verify that upload key is disabled within pop up")
	public void verify_that_upload_key_is_disabled_within_pop_up() {
	    ep.uploadkeydisabled();
	}

	@Then("verify the text area present")
	public void verify_the_text_area_present() {
	  ep.textareapresent();
	}

	@Then("enter the text {string}")
	public void enter_the_text(String string) {
	  ep.entertextwithintextarea(string);
	}
	@Then("validate Private Encryption Key {string}")
	public void view_Encryption_Key(String string) {
	  ep.validateprivatekey(string);
	}
	@Then("validate Public Encryption Key {string}")
	public void validate_Encryption_Key(String string) {
	  ep.validatepublickey(string);
	}

	@Then("verify that upload key is enabled within pop up")
	public void verify_that_upload_key_is_enabled_within_pop_up() {
	    ep.uploadkeyisenabled();
	}

	@Then("verify that {string} are disabled by default")
	public void verify_that_and_are_disabled_by_default(String string) {
		ep = new Encryption();
		ep.verifybuttonsdisabledbydefault(string);
	//	ep.verifybuttonsdisabledbydefault(string2);

	}
	
	
@Then("click on close within popup")
public void click_on_close_within_popup() throws InterruptedException{
   ep.closepopup();
}
@Then("Verify label {string} is not displayed")
public void verify_label_is_not_displayed(String string) {
	ep.labelsnotdisplayed(string);
}
}
