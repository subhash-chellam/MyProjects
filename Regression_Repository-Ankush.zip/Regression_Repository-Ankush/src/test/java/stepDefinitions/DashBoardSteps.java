package stepDefinitions;

import com.qa.pages.CourseManagement;
import com.qa.pages.DashBoard;
import com.qa.pages.EndUser;
import com.qa.pages.OrganizationAccess;
import com.qa.pages.User;
import com.qa.pages.UserManagement;
import com.qa.util.TestBase;

import io.cucumber.java.en.Then;

public class DashBoardSteps 
{
	DashBoard db;
	UserManagement usrMg;
	EndUser end;
	
	@Then("navigate to user management page")
	public void navigate_to_user_management_page() 
	{
		db = new DashBoard();
		db.clickUserMgmtDropDown();
		db.clickUserManagementOption();
	}
	
	@Then("wait for {int} minute")
	public void wait_for_1_minute(int i) 
	{
		db = new DashBoard();
		db.waitfor1min(i);
	
	}
	
	@Then("navigate to course management")
	public void navigate_to_course_management() 
	{
		db = new DashBoard();
		db.clickCourseMgmtDropDown();
		db.clickCourseManagementOption();
	}
	
	@Then("evaluate the course")
	public void evaluate_the_course() 
	{
	    if(CourseManagement.evaluationStatus.toLowerCase().equalsIgnoreCase("yes"))
	    {
	    	usrMg = new UserManagement();
	    	end = new EndUser();
	    	db.clickUserMgmtDropDown();
			db.clickUserManagementOption();
			usrMg.searchByEmail(User.userEmail);
			usrMg.clickSearch();
		    usrMg.selectProxyUser();
		    end = new EndUser();
		    usrMg.switchTab();		    
		    end.launchUserCourse1();
		    System.out.println("Value of end user flag is " + EndUser.flag);
		    if(EndUser.flag == false)
		    {
		    	end.clickOnCompletedPrograms();
		    	end.launchUserCourse1();
		    }		    
		    end.clickOnSubmitOnly();
		    end.evaluateCourse();
		    usrMg.switchTab();
		    usrMg.closeOtherTab();
	    }
	}
	
	@Then("evaluate the course from end user")
	public void evaluate_the_course_from_end_user() 
	{
		if(end == null)
			end = new EndUser();
		end.evaluateCourse();
	}

	@Then("Resume the course {string}")
	public void resume_the_course(String name) 
	{
		if(end == null)
			end = new EndUser();
		end.launchCourseWithNameResume(name);
    	
	}
	@Then("click on admin dashboard within profile link")
	public void click_on_admin_dashboard_within_profile_link() {
		OrganizationAccess orgAccess = new OrganizationAccess();
		orgAccess.gotoadmindashboard();
	}
	@Then("navigate to usercourse management manage user course page")
	public void navigate_to_usercourse_management_manage_user_course_page() {
		db = new DashBoard();
		db.clickUsercourseMgmtDropDown();
		db.clickManageusercourseOption(); 
	}
	@Then("navigate to insight management")
	public void navigate_to_insight_management() 
	{
		db = new DashBoard();
		db.clickCourseMgmtDropDown();
		db.clickInsightManagementOption();
	}

	@Then("click on organization panel")
	public void click_on_organization_panel() 
	{
		db = new DashBoard();
	    db.selectOrgpanel();
	}

	@Then("get the number of cycle")
	public void get_the_number_of_cycle() {
	    db.getNumberOfCycle();
	}
	
	

}

