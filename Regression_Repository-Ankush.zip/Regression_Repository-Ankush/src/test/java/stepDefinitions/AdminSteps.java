package stepDefinitions;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.qa.pages.Admin;
import com.qa.pages.OrganizationHome;
import com.qa.pages.Students;
import com.qa.pages.User;

import io.cucumber.java.en.Then;

public class AdminSteps 
{
	 private static final Logger logger = LogManager.getLogger(AdminSteps.class);

	Admin adm;
	OrganizationHome org;

	@Then("navigate to admin page")
	public void navigate_to_admin_page() 
	{
		User usr=new User();
		usr.pageLoad();
		adm = new Admin();
	   adm.clickManageAdmin();
	}

	@Then("create admin")
	public void create_admin() 
	{
		User usr=new User();
		usr.pageLoad();
		adm = new Admin();
		org = new OrganizationHome();
	    adm.enterDetails("Admin", "new");
	    adm.clickAdd();
	    org.validateSucessMesssage();
	    
	}
	@Then("Add creater user as admin")
	public void create_user_admin() throws InterruptedException 
	{
		User usr=new User();
		usr.pageLoad();
		org = new OrganizationHome();
	    adm.enterDetails(Students.firstName, Students.lastName,Students.email);
	    adm.clickAdd();
	    org.validateSucessMesssage();
	    
	}
	
	@Then("Add creater user as admin {string} {string}")
	public void create_user_admin(String first,String lastName) throws InterruptedException 
	{
		User usr=new User();
		usr.pageLoad();
		org = new OrganizationHome();
	    adm.enterDetails(first, lastName,User.userEmail);
	    adm.clickAdd();
	    org.validateSucessMesssage();
	    
	}
	@Then("click on Add Administrator")
	public void click_on_Add_Administrator() 
	{
		User usr=new User();
		usr.pageLoad();
		org = new OrganizationHome();
	    adm.clickAdd();
	 
	}
	@Then("Validate the error message {string}")
	public void validate_the_error(String msg) 
	{
		User usr=new User();
		usr.pageLoad();
		org = new OrganizationHome();
	    adm.errorMessage(msg);
	 
	}

	@Then("user delete the admin")
	public void user_delete_the_admin() 
	{
		User usr=new User();
		usr.pageLoad();
	    if(org == null)
	    	org = new OrganizationHome();
	    adm.deleteAdmin();
	    org.validateSucessMesssage();
	}

	
	@Then("create admin without email and validate the message") 
	public void create_admin_without_email_and_validate_the_message()
	{
		User usr=new User();
		usr.pageLoad();
		adm = new Admin();
		org = new OrganizationHome();
	    adm.EnterAdminDetails("Admin", "new");
	    adm.clickAdd();
	    org.validateErrorForEmptyEmail();
	}
	
	
	@Then("Create Admin with Long email and validate the Manage Admin page") 
	public void Create_Admin_with_Long_email_and_validate_the_Manage_Admin_page()
	{
		User usr=new User();
		usr.pageLoad();
		adm = new Admin();
		org = new OrganizationHome();
	    adm.enterDetails("Mohan", "Raju");
	    adm.clickAdd();
	    org.validateSucessMesssage();
	}
	
	

	
}
