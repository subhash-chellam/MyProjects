package stepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.qa.pages.Compliance;
import com.qa.pages.OrganizationSetting;
import com.qa.pages.OrganizationSettings;
import com.qa.pages.ProgressReport;
import com.qa.pages.Scrom;
import com.qa.pages.Student;
import com.qa.pages.Students;
import com.qa.pages.User;
import com.qa.util.TestBase;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
public class ProgressReportSteps 
{
	ProgressReport prog;
	
	@Then("navigate to progress report page")
	public void navigate_to_progress_report_page() 
	{
		
	    prog = new ProgressReport();
	    prog.clickOnReportLink();
	    prog.navigateProgressReport();
	}
	
	
	@Then("validate progress report sorting of each column")
	public void validate_LearnerActivity_sorting_of_each_column() {
		if (prog == null)
			prog = new ProgressReport();

		prog.validateProgressReportSortingEachColumn();
	}
	@Then("verify the activity popup is display")
	public void verify_the_activity_popup_is_display() 
	{
	    prog.validateActivityPopupDisplay();
	}
	@Then("get the activity names in popup and validate with end user topic list")
	public void get_the_activity_names_in_popup_and_validate_with_end_user_topic_list() 
	{
	    prog.getTopicList();
	    if(Scrom.courseTopic != null)
	    	prog.compareTopicList();
	    else
	    	prog.compareTopicListForCTC();
	}
	@Then("validate no records display on progress report page")
	public void validate_no_records_display_on_progress_report_page() 
	{
		prog.validateNoReportGenerated();
	}
	@Then("validate the avaialble date as per coursename {string} {int}")
	public void validate_the_avaialble_date_as_per_coursename(String courseName, Integer quarterDate) 
	{
	    prog.validateAvailableWithCourseName(courseName, quarterDate);
	}
	@Then("user scroll to left")
	public void user_scroll_to_left() 
	{ prog = new ProgressReport();
	    prog.scrollLeft();
	}
	@Then("validate curriculum status {string} as per name {string}")
	public void validate_curriculum_status_as_per_name(String status,String course) 
	{
	    prog.validateCurriculumStatusAsPerName(status, course);
	}
	
	
	@Then("validate curriculum status {string} as per name for LMS {string}")
	public void validate_curriculum_status_as_per_name_for_LMS(String status,String course) 
	{
	    prog.validateCurriculumStatusAsPerNameForLMS(status, course);
	}
	@Then("validate the avaialble date as per coursename {string} as quarter date {int} for LMS")
	public void validate_the_avaialble_date_as_per_coursename_as_quarter_date(String courseName, Integer quarterDate) 
	{
	    prog.validateAvailableWithCourseNameAsQuarterForLMS(courseName, quarterDate);
	}
	
	@Then("verify the activity popup is open as per name for LMS {string}")
	public void verify_the_activity_popup_is_open_as_per_name_for_LMS(String courseName) 
	{
		prog.OpenActivityPopUpWithNameForLMS(courseName);
	    
	}
	
	@Then("validate the activity start date as current date")
	public void validate_the_activity_start_date_as_current_date() 
	{
	    prog.getActivityStartDateAsCurrentDate();
	}
	
	@Then("validate the activity completed date as current date")
	public void validate_the_activity_completed_date_as_current_date() 
	{
	    prog.getActivityCompletedDateAsCurrentDate();
	}
	@Then("Validate the activity completed date as per quarter {int}")
	public void validate_the_activity_completed_date_as_per_quarter(Integer quarter) 
	{
	    prog.getActivityCompletedDate(quarter);
	}

	@Then("validate the activity start date as per quarter {int}")
	public void validate_the_activity_start_date_as_per_quarter(Integer quarter) 
	{
	    prog.getActivityStartDate(quarter);
	}
	@Then("validate the activity status for completed")
	public void validate_the_activity_status_for_completed() 
	{
	    prog.getActivityStatusComplete();
	}
	
	
	@Then("validate no records available")
	public void validate_no_records_available() 
	{
		if(prog == null)
			prog = new ProgressReport();
	    prog.validateNoReportGenerated();
	}
	@Then("clear the search result on progress report page")
	public void clear_the_search_result_on_progress_report_page() 
	{
	    prog.clearSearchResult();
	}
	@Then("validate number of rows display {int} in progress Report")
	public void validate_multiplecourse_isnot_available(int count)
	{
		prog.validaterow(count);
		
	}
	@Then("search the details by user email id on progress report without clear search")
	public void search_the_details_by_user_email_id_without_clear_search_for_vsim_course() 
	{
		if(prog == null)
			prog = new ProgressReport();
		System.out.println("user email for searching user email is " + User.userEmail);
//		if(User.userEmail != null)
//			prog.userSearchWithoutClearVsimCourse(User.userEmail);
//		else
//		User.userEmail="20230516160746010@laerdalblr.testinator.com";
			prog.studentSearchLMSWithoutClear(User.userEmail);
//		prog.studentSearchLMSWithoutClear("Ansh.J163226@yopmail.com");
	}
	
	@Then("search the details by user email id on progress report")
	public void search_the_details_by_user_email_id_without_clear_search() 
	{
		if(prog == null)
			prog = new ProgressReport();
		System.out.println("user email for searching user email is " + User.userEmail);
//		if(User.userEmail != null)
//			prog.userSearchWithoutClearVsimCourse(User.userEmail);
//		else
//		User.userEmail="Ansh.G153949@yopmail.com";
			prog.studentSearch(User.userEmail);;
//		prog.studentSearchLMSWithoutClear("Ansh.G220139@yopmail.com");
	}
	


	@Then("validate the page numbers")
	public void validate_the_page_numbers() 
	{
		if(prog == null)
			prog = new ProgressReport();
	    prog.validatePageNumbers();
	}
	

	@Then("Updated the test date {int} quarter")
	public void Updated_the_page_numbers(int quarter) 
	{
		if(prog == null)
			prog = new ProgressReport();
	    prog.updatetestdate(quarter);
	}

	
	
	@Then("validate the pagination dropdown")
	public void validate_the_pagination_dropdown() 
	{
		if(prog == null)
			prog = new ProgressReport();
	    prog.validatePaginationDropdown();
	}
	@Then("validate the curriculum status on progress report")
	public void validate_the_curriculum_status_on_progress_report() 
	{
	    prog.validateCurriculumStatusComplete();
	}
	
//Steps added by vinesha date: 4th April 2022
	
	@Then("click on reports tab")
	public void click_on_reports_tab() {
		prog = new ProgressReport();
	 prog.clickOnReportLink(); 
	}


	@Then("Export button disable")
	public void export_button_disable() {
		prog = new ProgressReport();
	 prog.buttonExportBttn(); 
	}
	@Then("Export button download")
	public void export_button_downloa() {
		prog = new ProgressReport();
	 prog.buttonExportBtn(); 
	}

	@Then("Select the {string}")
	public void select_the(String string) {
		prog = new ProgressReport();
	  prog.navigateProgressReport();
	}
	@Then("verify the header is displayed as {string}")
	public void verify_the_header_is_displayed_as(String string) {
	 prog.verifyheaderforreportspage(string);
}
	@Then("verify the report table headers being displayed {string}")
	public void verify_the_report_table_headers_being_displayed(String string) throws InterruptedException {
		prog = new ProgressReport();
		prog.verifytableheaders(string);
	  
	}
	@Then("verify the activity popup is open as per name {string}")
	public void verify_the_activity_popup_is_open_as_per_name(String courseName) 
	{
		prog.OpenActivityPopUpWithName(courseName);
	    
	}
	@Then("validate the launched date as per course name {string} {int}")
	public void validate_the_launched_date_as_per_course_name(String course, Integer quarter) 
	{
	    prog.validateConsumedWithCourseName(course, quarter);
	}

	@Then("validate the curriculum name {string} on progress report page")
	public void validate_the_curriculum_name_on_progress_report_page(String courseName) 
	{
	    prog.validateCurriculumNameWithCourseName(courseName);
	}
	
	@Then("validate the due date as per course name {string} {int}")
	public void validate_the_due_date_as_per_course_name(String course, Integer quarter) 
	{
	    prog.validateDueDateWithCourseName(course, quarter);
	}
	
	@Then("validate the due date as per course name {string}")
	public void validate_the_due_date_as_per_course_name(String courseName) 
	{
	    prog.validateDueDateWithCourseName(courseName);
	}
	@Then("validate the available date as per coursename {string} as current date")
	public void validate_the_avaialble_date_as_per_coursename_as_current_date(String courseName) 
	{
	    prog.validateAvailableDateWithCourseNameCurrentDate(courseName);
	}
	
	@Then("validate the launch date as per coursename {string} as current date for LMS")
	public void validate_the_avaialble_date_as_per_coursename_as_currentdate(String courseName) 
	{
	    prog.validateLaunchDateWithCourseNameCurrentDateLMS(courseName);
	}

	@Then("validate the row counts {int} in progress report")
	public void validate_the_compliance_ecard_with_date_and_course(int count) 
	{
		prog = new ProgressReport();
		prog.validaterowcount(count);
	}
	
	
	
	@Then("validate the due date with days from today and as per course name {string} {int}")
	public void validate_the_due_date_with_days_from_today_and_as_per_course_name(String course, Integer days) 
	{
	    prog.validateDueDateWithDaysFromTodayWithCourseName(course, days);
	}
	@Then("Verify pagination Functionality for report grid")
	public void verify_pagination_functionality_for_report_grid() {
		prog = new ProgressReport();
	prog.verifypagination();
	}
	@Then("click on the curriculam filters link")
	public void click_on_the_curriculam_filters_link() throws InterruptedException {
		prog = new ProgressReport();
	 prog.expandCurriculamfilters();
	}

	@Then("Verify the options available for curriculam status filters {string}")
	public void verify_the_options_available_for_curriculam_status_link(String string) throws InterruptedException {
		prog = new ProgressReport();
	prog.curriculamstatusoptionsCTC(string);
	}
	@Then("Verify the options available for curriculam status filters for LMS {string}")
	public void verify_the_options_available_for_curriculam_status_link_for_lms(String string) throws InterruptedException {
		prog = new ProgressReport();
		prog.curriculamstatusoptionsLMS(string);
	}
	@Then("click on more filters within progress report page")
	public void click_on_more_filters_within_progress_report_page() throws InterruptedException {
		prog = new ProgressReport();
		prog.expandmorefilterslink();
	}

	@Then("Verify the options available for user status filters {string}")
	public void verify_the_options_available_for_user_status_filters(String string) throws InterruptedException {
		prog = new ProgressReport();
		prog.userstatusoptions(string);
	}
	@Then("verify that active is default selected and select Inactive from userstatus dropdown")
	public void verify_that_active_is_default_selected_and_select_inactive_from_userstatus_dropdown() throws InterruptedException {
		prog = new ProgressReport();
		prog.verifydefaultselected();
	}
	@Then("verify the presence of Assignment Name filter {string}")
	public void verify_the_presence_of_assignment_name_filter(String string) throws InterruptedException {
		prog = new ProgressReport();
		prog.presenceofassignmentname(string);
	}
	@Then("unselect all selected assignments")
	public void unselect_all_selected_assignments() throws InterruptedException {
		prog = new ProgressReport();
		prog.assignmentunselectall();
	}


	@Then("select {int} assignments from the Assignment name filter")
	public void select_assignments_from_the_assignment_name_filter(Integer int1) {
        prog = new  ProgressReport();
        prog.selectionofassignmentnames(int1);
        
	}

	@Then("click on search")
	public void click_on_search() throws InterruptedException {
		prog = new ProgressReport();
		prog.searchclick();
	}
	@Then("user click on search button")
	public void click_on_searchs() throws InterruptedException {
		prog = new ProgressReport();
		prog.searchclick();
	}
	
	@Then("verify that values are displayed accordingly for assignment name")
	public void verify_that_values_are_displayed_accordingly_for_assignment_name() {
		prog = new ProgressReport();
		prog.recordsvalidationforassignmentnamefield();
	}
	@Then("verify presence of available date filter From and To  filters are {string}")
	public void verify_presence_of_available_date_filter_from_and_to_filters_are(String string) {
		prog = new ProgressReport();
		prog.assertionforavailabledate();
	}

	@Then("verify presence of Launched date filter From and To filters are {string}")
	public void verify_presence_of_launched_date_filter_from_and_to_filters_are(String string) {
		prog = new ProgressReport();
		prog.assertionforLauncheddate();
	}
	@Then("Select the {string} in Report")
	public void select_the_in_report(String string) {
		prog = new ProgressReport();
	  prog.navigateReport(string);
	}
	@Then("View Ecard Download")
	public void clik_report() {
		prog = new ProgressReport();
	  prog.viewecardDownload();
	}

	@Then("View Ecard Download {string}")
	public void clik_report(String course) {
		prog = new ProgressReport();
	  prog.viewecardDownload(course);
	}

	
	
	@Then("Download Ecard Download")
	public void click_report() {
		prog = new ProgressReport();
	  prog.clickecardDownload();
	}
	@Then("Click on {string} Btn")
	public void click_report(String string) {
		prog = new ProgressReport();
	  prog.clickonfilter(string);
	}
	@Then("Click on {string}")
	public void click_repor(String string) {
		prog = new ProgressReport();
	  prog.clickonfilter(string);
	}
	
	@Then("Select notification title {string}")
	public void selectnotification(String string) {
		prog = new ProgressReport();
	  prog.selectNotificationFilter(string);
	}
	@Then("verify presence of Due date filter From and To filters are {string}")
	public void verify_presence_of_due_date_filter_from_and_to_filters_are(String string) {
		prog = new ProgressReport();
		prog.assertionduedateassertion();
	}

	@Then("verify presence of Completed date filter From and filters are {string}")
	public void verify_presence_of_completed_date_filter_from_and_filters_are(String string) {
		prog = new ProgressReport();
		prog.assertioncompletedate();
	}


	@Then("click on the hand icon to load the details")
	public void click_on_the_hand_icon_to_load_the_details() throws InterruptedException {
		prog = new ProgressReport();
		prog.clickhandicon();
	}

	@Then("Verify the headers {string} within course details popup displayed")
	public void verify_the_headers_within_course_details_popup_displayed(String string) throws InterruptedException {
		prog = new ProgressReport();
	prog.verifyactivityheaders(string);
	}

   @Then("Verify table data displayed as {string}")
   public void verify_table_data_displayed_as(String string) throws InterruptedException {
		prog = new ProgressReport();
	prog.verifyactivitytabledata(string);
}
   @Then("select {string} from curriculum name filter")
	public void select_from_curriculum_name_filter(String string) throws InterruptedException {
		prog = new ProgressReport();
		prog.selectthecurriculumname(string);
	}
   @Then("close the details pop up")
	public void close_the_details_pop_up() throws InterruptedException {
	   prog = new ProgressReport();
	   prog.clickonclose();
	}

   @Then("validate the header on progress report page")
   public void validate_the_header_on_progress_report_page()
   {
       prog.validateHeader();
   }
   
   @Then("validate user search filter on progress report page")
   public void validate_user_search_filter_on_progress_report_page()
   {
       prog.validateUserSearchFilterOptions();
   }
   @Then("validate the more filters options for LMS on progress report page")
	public void validate_the_more_filters_options_for_LMS_on_progress_report_page() 
	{
		if(prog == null)
			prog = new ProgressReport();
	    prog.clickMoreFilter();
	    prog.validateJobTitleFilterOptions();
	    //prog.validateGroupFilterOptions();
	    prog.validateUserStatusFilterOptions();
	}
   @Then("validate curriculum status filter and its option for LMS on progress report page")
	public void validate_curriculum_status_filter_and_its_option_for_lms_on_progress_report_page() 
	{
		prog.validateCurriculumStatusOptionsForLMS();
	}
   @Then("validate the header for LMS org on progress report page")
	public void validate_the_header_for_LMS_org_on_progress_report_page() 
	{
	    prog.validateHeaderForLMS();
	}
   @Then("validate the curriculum name {string} on progress report page for LMS")
	public void validate_the_curriculum_name_on_progress_report_page_for_LMS(String courseName) 
	{
	    prog.validateCurriculumNameWithCourseNameForLMS(courseName);
	}
   @Then("validate the launched date as per course name {string} {int} for LMS")
	public void validate_the_launched_date_as_per_course_name_for_LMS(String course, Integer quarter) 
	{
	    prog.validateConsumedWithCourseNameForLMS(course, quarter);
	}
	@Then("validate the curriculum name not present {string} on progress report page for LMS")
	public void validate_the_curriculum_name_not_prsent_on_progress_report_page_for_LMS(String courseName) 
	{
	    prog.validateNoCurriculumNameWithCourseNameForLMS(courseName);
	}
	
   
   /*
	 * This method is to validate the due date in progress report with MOC rule
	 */
	@Then("validate the due date as per course name {string} {int} for LMS")
	public void validate_the_due_date_as_per_course_name_for_LMS(String course, Integer quarter) 
	{
	    prog.validateDueDateWithCourseNameForLMS(course, quarter);
	}
	/*
	 * This method is to validate the due date as NA in progress report for LMS
	 */
	@Then("validate the due date as NA as per course name {string} for LMS")
	public void validate_the_due_date_as_NA_as_per_course_name_for_LMS(String courseName) 
	{
	    prog.validateDueDateAsNAWithCourseNameForLMS(courseName);
	}
	@Then("validate the available date as per coursename {string} as NA for LMS")
	public void validate_the_avaialble_date_as_per_coursename_as_NA_for_LMS(String courseName) 
	{
	    prog.validateAvailableDateWithCourseNameAsNAForLMS(courseName);
	}
	@Then("validate the available date as per coursename {string} as NA")
	public void validate_the_avaialble_date_as_per_coursename_as_NA(String courseName) 
	{
	    prog.validateAvailableDateWithCourseNameAsNA(courseName);
	}
	
	@Then("validate the launched date as per course name {string} as current date")
	public void validate_the_launched_date_as_per_course_name_as_current_date(String course) 
	{
	    prog.validateConsumedWithCourseNameCurrentDate(course);
	}
	@Then("validate the launched date as per course name {string} as current date for LMS")
	public void validate_the_launched_date_as_per_course_name_as_current_date_for_LMS(String course) 
	{
	    prog.validateConsumedWithCourseNameCurrentDateForLMS(course);
	}

	@Then("validate the due date as NA as per course name {string}")
	public void validate_the_due_date_as_NA_as_per_course_name(String courseName) 
	{
	    prog.validateDueDateAsNAWithCourseName(courseName);
	}
	
	@Then("verify the activity popup is not display")
	public void verify_the_activity_popup_is_not_display() 
	{
	    prog.validateActivityPopupNotDisplay();
	}
   @Then("validate assignment filter for LMS under progress report page")
	public void validate_assignment_filter_for_lms_under_progress_report_page() 
	{
	    prog.validateAssignmentNameFilterOptionsNotAvailable();
	}
	
   @Then("validate org level filter on progress report page")
   public void validate_org_level_filter_on_progress_report_page()
   {
       prog.validateOrgLevelFilterOptions();
   }
   
   @Then("validate the more filters options on progress report page")
   public void validate_the_more_filters_options_on_progress_report_page()
   {
       prog.clickMoreFilter();
       prog.validateJobTitleFilterOptions();
       prog.validateGroupFilterOptions();
       prog.validateUserStatusFilterOptions();
   }
   
   @Then("validate the all curriculum name filter under progress report page")
   public void validate_the_all_curriculum_name_filter_under_progress_report_page()
   {
       prog.clickCurriculumFilter();
       prog.validateAvailableDateFilterOptions();
       prog.validateCompletedDateFilterOptions();
       prog.validateLaunchedDateFilterOptions();
   }
   
   @Then("validate curriculum status filter and its option on progress report page")
   public void validate_curriculum_status_filter_and_its_option_on_progress_report_page()
   {
       prog.validateCurriculumFilterOptions();
       prog.validateCurriculumStatusOptions();
   }
   
   @Then("validate assignment filter under progress report page")
   public void validate_assignment_filter_under_progress_report_page()
   {
       prog.validateAssignmentNameFilterOptions();
   }
   
   @Then("Verify search and multi select option inside Assignment name filter")
   public void verify_search_and_multi_select_option_inside_assignment_name_filter()
   {
       prog.verifySearchMultiSelectAssignmentName();
   }

   @Then("select all user status on progress report page")
   public void select_all_user_status_on_progress_report_page() {
       if(prog == null)
           prog = new ProgressReport();
       prog.validateUserStatusFilterAvailability();
       prog.selectAllStatus();
   }
 
   @Then("validate the activity header details")
   public void validate_the_activity_header_details()
   {
       prog.validateActivityHeader();
   }
   
   @Then("user close the activity popup")
   public void user_close_the_activity_popup()
   {
       prog.closeActivityPopup();
   }
   
   @Then("verify the activity popup is not open as per name {string}")
   public void verify_the_activity_popup_is_not_open_as_per_name(String courseName)
   {
       prog.notOpenActivityPopUpWithName(courseName);
   }
   
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   

/////////////////////////////////////////////////////// P2 Regression Cases //////////////////////////////////

   @Then("validate the records are available on progress report page")
   public void validate_the_records_are_available() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.validateRecordAvailable();
   }

   @Then("validate no records available on progress report page")
   public void validate_no_records_available_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.validateRecordNotAvailableCount();
   }

   @Then("user click on clear search button on progress report page")
   public void user_click_on_clear_search_button_on_progress_report_page() 
   {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.clearSearchResult();
   }

   @Then("search the user by email id on progress report without clear search and column validation")
   public void search_the_user_by_email_id_without_clear_search_and_column_validation() 
   {
	   if(prog == null)
		   prog = new ProgressReport();
	   System.out.println("user email for searching user email is " + User.userEmail);
	   if(User.userEmail != null)
		   prog.userSearchWithoutClearWithoutColumnValidation(User.userEmail);
	   else
		   prog.studentSearchLMSWithoutClearWithoutColumnValidation(Students.email);
   }

   @Then("open the activity popup as per course name {string} for the searched user")
   public void open_the_activity_popup_as_per_course_name_for_the_searched_user(String courseName) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.OpenActivityPopUpWithNameOnly(courseName);
   }

   @Then("validate the score in percentage for activity popup {string}")
   public void validate_the_score_in_percentage_for_activity_popup(String score) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.validateActivityScore(score);
   }

   @Then("validate atleast activity status {string} on progress report page")
   public void validate_atleast_activity_status_on_progress_report_page(String status) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.validateAtleastActivityStatus(status);
   }

   @Then("validate atleast activity start date on progress report page with quarter {int}")
   public void validate_atleast_activity_start_date_on_progress_report_page_with_quarter(Integer quarter) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.validateAtleastActivityStartDate(quarter);
   }

   @Then("validate atleast activity due date on progress report page with quarter {int}")
   public void validate_atleast_activity_due_date_on_progress_report_page_with_quarter(Integer quarter) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.validateAtleastActivityDueDate(quarter);
   }

   @Then("search the details by user id on progress report without clear search")
   public void search_the_details_by_user_id_without_clear_search() 
   {
	   if(prog == null)
		   prog = new ProgressReport();
	   System.out.println("user email for searching user email is " + User.userEmail);
	   if(User.userEmail != null)
		   prog.searchUserIDWithoutClear(User.userId);
	   else
		   prog.studentSearchLMSWithoutClear(Students.email);
   }

   /////////////////////////////////////// Report level steps //////////////////////////////////	

   @Then("search the details by user first name on progress report without clear search {string}")
   public void search_the_details_by_user_first_name_without_clear_search(String name) 
   {
	   if(prog == null)
		   prog = new ProgressReport();
	   System.out.println("user first name for searching user is " + name);
	   if(User.userEmail != null)
		   prog.searchUserFirstNameWithoutClear(name);
	   else
		   prog.studentSearchLMSWithoutClear(Students.email);
   }

   @Then("select the org level {int} from organization level dropdown on notification Report")
   @Then("select the org level {int} from organization level dropdown on progress report page")
   public void select_the_org_level_from_organization_level_dropdown_on_progress_report_page(Integer level) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.selectOrgLevelMainFilter(level);
   }

   
   
   @Then("click on more filter option on Learner report page")
   @Then("click on more filter option on progress report page")
   public void click_on_more_filter_option_on_progress_report_page() 
   {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.clickMoreFilter();
   }

   
   @Then("validate the {string} filter on Learner report page")
   @Then("validate the {string} filter on progress report page")
   public void validate_the_filter_on_progress_report_page(String filterName) {
	   if(prog == null)
		   prog = new ProgressReport();
	   try
	   {
		Thread.sleep(5000);   
	   }
	   catch(Exception e)
	   {
		   
	   }
	   switch (filterName) {
	   case "org level filter":
		   prog.validateOrgLevelFilterFilterAvailability();
		   break;
	   case "user status":
		   prog.validateUserStatusFilterAvailability();
		   break;
	   case "job filter":
		   prog.validateJobFilterFilterAvailability();
		   break;
	   case "group filter":
		   prog.validateGroupFilterFilterAvailability();
		   break;
	   case "curriculum status":
		   prog.validateCurriculStatusFilterFilterAvailability();
		   break;
	   case "Assignment":
		   prog.validateCurriculNameFilterFilterAvailability();
		   break;
	   case "Course":
		   prog.validateCourseNameFilterFilterAvailability();
		   break;		
	   default:
		   break;
	   }	    
   }

   @Then("single select org level filter status on progress report page {string}")
   public void single_select_org_level_filter_status_on_progress_report_page(String course) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.selectSingleOrgLevelFilter(course);
	   prog.validateOrgLevelFilterFilterAvailability();
	   prog.clickOnMoreFilterSearchButton();
   }

   @Then("multi select org level filter status on progress report page {int}")
   public void multi_select_org_level_filter_status_on_progress_report_page(int count) {
	   if(prog == null)
		   prog = new ProgressReport();
	   for(int i = 0; i < count; i++) {
		   prog.selectMultiOrgLevelFilter();	
	   }
	   prog.validateOrgLevelFilterFilterAvailability();
	   prog.clickOnMoreFilterSearchButton();
   }

   @Then("unSelect all org level filter status on progress report page")
   public void un_select_all_org_level_filter_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.unSelectAllOrgLevelFilter();
	   prog.validateOrgLevelFilterFilterAvailability();
	   prog.clickOnMoreFilterSearchButton();
   }

   @Then("select all org level filter status on progress report page")
   public void select_all_org_level_filter_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.selectAllOrgLevelFilter();
	   prog.validateOrgLevelFilterFilterAvailability();
	   prog.clickOnMoreFilterSearchButton();
   }

   @Then("clear the selected org level filter status on progress report page")
   public void clear_the_selected_org_level_filter_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.unSelectAllOrgLevelFilter();
   }

   @Then("search the org level filter")
   public void search_the_course_filter() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.searchOrgLevelFilter(OrganizationSettings.newUnitName);
	   
	   prog.validateOrgLevelFilterFilterAvailability();
	   prog.clickOnMoreFilterSearchButton();
   }
   
   @Then("search the org level filter {string}")
   public void search_the_course_filter(String level) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.searchOrgLevelFilter(level);
	   
	   prog.validateOrgLevelFilterFilterAvailability();
	   prog.clickOnMoreFilterSearchButton();
   }

   ///////////////////////////////////////// JOB TITLE //////////////////////////////////

   @Then("single select job filter status on progress report page")
   public void single_select_job_filter_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.selectSingleJobFilter();
	   prog.validateJobFilterFilterAvailability();
	   prog.clickOnMoreFilterSearchButton();
   }
   
   @Then("single select job filter status on progress report page {string}")
   public void single_select_job_filter_status_on_progress_report_page(String jobtitle) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.selectSingleJobFilter();
	   prog.validateJobFilterFilterAvailability();
	   prog.clickOnMoreFilterSearchButton();
   }


   @Then("multi select job filter status on progress report page {int}")
   public void multi_select_job_filter_status_on_progress_report_page(int count) {
	   if(prog == null)
		   prog = new ProgressReport();
	   for(int i = 0; i < count; i++) {
		   prog.selectMultiJobFilter();	
	   }
	   prog.validateJobFilterFilterAvailability();
	   prog.clickOnMoreFilterSearchButton();
   }

   
   @Then("unSelect all job filter status on Learner report page")
   @Then("unSelect all job filter status on progress report page")
   public void un_select_all_job_filter_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.unSelectAllJobFilter();
	   prog.validateJobFilterFilterAvailability();
	   prog.clickOnMoreFilterSearchButton();
   }

   
   @Then("select all job filter status on Learner report page")
   @Then("select all job filter status on progress report page")
   public void select_all_job_filter_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.selectAllJobFilter();
	   prog.validateJobFilterFilterAvailability();
	   prog.clickOnMoreFilterSearchButton();
   }

   
   @Then("clear the selected job filter status on Learner report page")
   @Then("clear the selected job filter status on progress report page")
   public void clear_the_selected_job_filter_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.unSelectAllJobFilter();
   }

   @Then("search the job filter on progress report page")
   public void search_the_job_filter_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.searchJobFilter();
	   prog.validateJobFilterFilterAvailability();
	   prog.clickOnMoreFilterSearchButton();
   }

   //////////////////////////////////////////Group Filter ////////////////////////////////
   @Then("single select group filter status on Learner report page")
   @Then("single select group filter status on progress report page")
   public void single_select_group_filter_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.selectSingleUserGroupFilter();
	   prog.clickOnMoreFilterSearchButton();
   }

   @Then("multi select group filter status on progress report page {int}")
   public void multi_select_group_filter_status_on_progress_report_page(int count) {
	   if(prog == null)
		   prog = new ProgressReport();
	   for(int i = 0; i < count; i++) {
		   prog.selectMultiUserGroupFilter();	
	   }
	   prog.clickOnMoreFilterSearchButton();
   }

   @Then("unSelect all group filter status on Learner report page")
   @Then("unSelect all group filter status on progress report page")
   public void un_select_all_group_filter_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.unSelectAllGroupFilter();
	   prog.clickOnMoreFilterSearchButton();
   }
   
   

   
   @Then("select all group filter status on Learner report page")
   @Then("select all group filter status on progress report page")
   public void select_all_group_filter_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.selectAllGroupFilter();
	   prog.clickOnMoreFilterSearchButton();
   }

   @Then("clear the selected group filter status on progress report page")
   public void clear_the_selected_group_filter_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.unSelectAllGroupFilter();
   }

   @Then("search the group filter on progress report page")
   public void search_the_group_filter_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.searchGroupFilter();
	   prog.clickOnMoreFilterSearchButton();
   }

   /////////////////////////////////////////////// USER STATUS FILTER ///////////////////////////////////

   @Then("single select user filter status as {string} on progress report page")
   public void single_select_user_filter_status_as_on_progress_report_page(String filter) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.selectSingleUserStatusFilter(filter);
	   prog.clickOnMoreFilterSearchButton();
   }
   
   @Then("multi select user filter status as {string} on progress report page")
   public void multi_select_user_filter_status_as_on_progress_report_page(String filter) {
	   if(prog == null)
		   prog = new ProgressReport();
	   String[] filterList = filter.split(",");
	   for(int i = 0; i < filterList.length; i++) {
		   prog.selectMultiUserStatusFilter(filterList[i]);	
	   }
	   
	   prog.clickOnMoreFilterSearchButton();
   }

   @Then("unSelect all user status on progress report page")
   public void unSelect_all_user_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.unSelectAllStatus();
	   prog.clickOnMoreFilterSearchButton();
   }

   @Then("select all user status and search on progress report page")
   public void select_all_user_status_and_search_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.selectAllStatus();
	   prog.clickOnMoreFilterSearchButton();
   }

   @Then("clear the selected user status on progress report page")
   public void clear_the_selected_user_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.unSelectAllStatus();
   }

   @Then("search the user by status {string} on progress report page")
   public void search_the_user_by_status_on_progress_report_page(String userStatus) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.searchUserStatus(userStatus);
	   prog.clickOnMoreFilterSearchButton();
   }

   /////////////////////////////////////// Curriculum filters ////////////////////////////////////////////	

   @Then("click on course filter option on progress report page")
   public void click_on_course_filter_option_on_progress_report_page() 
   {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.clickCourseFilter();
   }

   @Then("single select Assignment Status filter status on progress report page {string}")
   public void single_select_Assignment_Status_filter_status_on_progress_report_page(String status) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.selectSingleUserAssignmentStatusFilter(status);
	   prog.clickOnCourseFilterSearchButton();
   }

   @Then("multi select Assignment Status filter status on progress report page {int}")
   public void multi_select_Assignment_Status_filter_status_on_progress_report_page(int count) {
	   if(prog == null)
		   prog = new ProgressReport();
	   for(int i = 0; i < count; i++) {
		   prog.selectMultiUserAssignmentStatusFilter();	
	   }
	   prog.clickOnCourseFilterSearchButton();
   }

   @Then("unSelect all Assignment Status filter status on progress report page")
   public void un_select_all_Assignment_Status_filter_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.unSelectAllAssignmentStatusFilter();
	   prog.clickOnCourseFilterSearchButton();
   }

   @Then("select all Assignment Status filter status on progress report page")
   public void select_all_Assignment_Status_filter_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.selectAllAssignmentStatusFilter();
	   prog.clickOnCourseFilterSearchButton();
   }

   @Then("clear the selected Assignment Status filter status on progress report page")
   public void clear_the_selected_Assignment_Status_filter_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.unSelectAllAssignmentStatusFilter();
   }

   @Then("search the Assignment Status filter {string} on progress report page")
   public void search_the_Assignment_Status_filter_on_progress_report_page(String status) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.searchAssignmentStatusFilter(status);
	   prog.clickOnCourseFilterSearchButton();
   }

   ////////////////////////////////////////Assignment Status //////////////////////////////////////

   @Then("single select assignment filter status on progress report page")
   public void single_select_assignment_filter_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.selectSingleUserAssignmentFilter();
	   prog.clickOnCourseFilterSearchButton();
   }

   @Then("multi select assignment filter status on progress report page {int}")
   public void multi_select_assignment_filter_status_on_progress_report_page(int count) {
	   if(prog == null)
		   prog = new ProgressReport();
	   for(int i = 0; i < count; i++) {
		   prog.selectMultiUserAssignmentFilter();	
	   }
	   prog.clickOnCourseFilterSearchButton();
   }

   @Then("unSelect all assignment filter status on progress report page")
   public void un_select_all_assignment_filter_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.unSelectAllAssignmentFilter();
	   prog.clickOnCourseFilterSearchButton();
   }

   @Then("select all assignment filter status on progress report page")
   public void select_all_assignment_filter_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.selectAllAssignmentFilter();
	   prog.clickOnCourseFilterSearchButton();
   }

   @Then("clear the selected assignment filter status on progress report page")
   public void clear_the_selected_assignment_filter_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.unSelectAllAssignmentFilter();
   }

   @Then("search the assignment filter on progress report page")
   public void search_the_assignment_filter_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.searchAssignmentFilter();
	   prog.clickOnCourseFilterSearchButton();
   }

   //////////////////////////////////////////Assignment Name ///////////////////////////////////////////////

   @Then("single select course filter status on Learner report page {string}")
   @Then("single select course filter status on progress report page {string}")
   public void single_select_course_filter_status_on_progress_report_page(String course) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.selectSingleUserCourseFilter(course);
	   prog.clickOnCourseFilterSearchButton();
   }

   @Then("multi select course filter status on progress report page {int}")
   public void multi_select_course_filter_status_on_progress_report_page(int count) {
	   if(prog == null)
		   prog = new ProgressReport();
	   for(int i = 0; i < count; i++) {
		   prog.selectMultiUserCourseFilter();	
	   }
	   prog.clickOnCourseFilterSearchButton();
   }

   
   @Then("unSelect all course filter status on Learner report page")
   public void un_select_all_course_filter_status_on_Learnerreportpage() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.unSelectAllCourseFilter();
	   prog.clickOnCourseFilterSearchButton();
   }


   @Then("unSelect all course filter status on progress report page")
   public void un_select_all_course_filter_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.unSelectAllCourseFilter();
	   prog.clickOnCourseFilterSearchButton();
   }

   
   @Then("select all course filter status on Learner report page")
   @Then("select all course filter status on progress report page")
   public void select_all_course_filter_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.selectAllCourseFilter();
	   prog.clickOnCourseFilterSearchButton();
   }

   
   @Then("clear the selected course filter status on Learner report page")
   @Then("clear the selected course filter status on progress report page")
   public void clear_the_selected_course_filter_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.unSelectAllCourseFilter();
   }

   
   @Then("search the course filter {string} on Learner report page")
   @Then("search the course filter {string} on progress report page")
   public void search_the_course_filter_on_progress_report_page(String course) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.searchCourseFilter(course);
	   prog.clickOnCourseFilterSearchButton();
   }

   //////////////////////////////////////////////DUE DATE ///////////////////////////////////////////

   @Then("enter the from assignment due date with {int} {string} on progress report page")
   public void enter_the_from_assignment_due_date_with_on_progress_report_page(Integer num, String time) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.enterFromAssignmentDueDate(num, time);
   }

   @Then("enter the to assignment due date with quarter {int} on progress report page")
   public void enter_the_to_assignment_due_date_on_progress_report_page(int quarter) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.enterToAssignmentDueDateQuarterEnd(quarter);
   }

   @Then("user click on search button for course filter on progress report page")
   public void user_click_on_search_button_for_course_filter_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.clickOnCourseFilterSearchButton();
   }

   @Then("user click on clear search for curriculum filter on progress report page")
   public void user_click_on_clear_search_for_curriculum_filter_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.clearSearchResultCurriculumFilter();
   }

   @Then("enter the from assignment available date with {int} {string} on progress report page")
   public void enter_the_from_assignment_available_date_with_on_progress_report_page(Integer num, String time) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.enterFromAssignmentAvailableDate(num, time);
   }

   @Then("enter the to assignment available date with quarter {int} on progress report page")
   public void enter_the_to_assignment_available_date_on_progress_report_page(int quarter) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.enterToAssignmentAvailableDateQuarterEnd(quarter);
   }

   @Then("enter the from assignment launched date with {int} {string} on progress report page")
   public void enter_the_from_assignment_launched_date_with_on_progress_report_page(Integer num, String time) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.enterFromAssignmentLaunchedDate(num, time);
   }

   @Then("enter the to assignment launched date with quarter {int} on progress report page")
   public void enter_the_to_assignment_launched_date_on_progress_report_page(int quarter) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.enterToAssignmentLaunchedDateQuarterEnd(quarter);
   }

   @Then("enter the from assignment completed date with {int} {string} on progress report page")
   public void enter_the_from_assignment_completed_date_with_on_progress_report_page(Integer num, String time) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.enterFromAssignmentCompletedDate(num, time);
   }

   @Then("enter the to assignment completed date with quarter {int} on progress report page")
   public void enter_the_to_assignment_completed_date_on_progress_report_page(int quarter) {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.enterToAssignmentCompletedDateQuarterEnd(quarter);
   }

   ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

   @Then("validate the options of curriculum status on progress report page")
   public void validate_the_options_of_curriculum_status_on_progress_report_page() {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.validateAssignmentStatusFilterOptions();
   }

   ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

   User usr;

   @Then("validate the page numbers on progress report page")
   public void validate_the_page_numbers_on_progress_report_page() 
   {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.validatePageNumbers();
	   prog.getLocationPageNumber();
	   prog.validatePaginationDropdown();
	   prog.selectPaginationDropdown();
   }

   @Then("validate the completed date as per coursename {string} as date {string}")
   public void validate_the_completed_date_as_per_coursename_as_current_date(String course, String date) 
   {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.validateCompletedDateWithCourseNameAsDate(course, date);
   }

   @Then("validate the details of {string} header as per coursename {string} as date {string} with quarter range {int}")
   public void validate_the_details_of_header_as_per_coursename_as_date_with_quarter_range(String header,String course, String date, int quarter) 
   {
	   if(prog == null)
		   prog = new ProgressReport();
	   
		   prog.validateDateDetailsWithCourseNameAsDate(course, date, header,quarter);

   }

   @Then("validate the details of {string} header as per coursename {string} as text {string}")
   public void validate_the_details_of_header_as_per_coursename_as_text(String header, String courseName, String text) {
	   if(prog == null)
		   prog = new ProgressReport();
		   prog.validateTextDetailsWithCourseName(courseName, text, header);
	 
   }

   @Then("download progress report")
   public void download_progress_report() {
	   if(prog == null)
		   prog = new ProgressReport();
	   if(usr == null)
		   usr = new User();
	   boolean flag = usr.checkCSVFilePresent();
	   while(flag == true)
	   {
		   usr.deleteFile(User.filePath);
		   flag = usr.checkCSVFilePresent();
	   }			
	   prog.clickExportButton();
	   prog.verifyDownloadFile();
   }

   @Then("validate the activity list with exported file from progress report page")
   public void validate_the_activity_list_with_exported_file_from_progress_report_page() 
   {
	   if(prog == null)
		   prog = new ProgressReport();
	   prog.getAllCourseUIActivityList();
	   prog.getAllCourseExcelActivityList();
	   prog.compareActivityList();
   }

   @Then("export and validate the details on progress report page")
   public void export_and_validate_the_details() 
   {
	   if(prog == null)
		   prog = new ProgressReport();
	   if(usr == null)
		   usr = new User();
	   boolean flag = usr.checkCSVFilePresent();
	   while(flag == true)
	   {
		   usr.deleteFile(User.filePath);
		   flag = usr.checkCSVFilePresent();
	   }			
	   prog.clickExportButton();
	   prog.verifyDownloadFile();
	   //prog.compareDetails();
   }
   
   @Then("export {string} and validate Excel header")
   public void export_and_validate_the_details(String exportType,DataTable excelHeader) 
   {
	   if(prog == null)
		   prog = new ProgressReport();
	   if(usr == null)
		   usr = new User();
	   boolean flag = usr.checkCSVFilePresent();
	   int count=0;
	   while(flag == true)
	   {
		   usr.deleteFile(Students.filePath);
		   flag = usr.checkCSVFilePresent();
		   count++;
		   if(count>=30)
			   break;
	   }			
	   prog.clickExportButton();
	   prog.clickSelectExportButton(exportType);
	   
	   prog.verifyDownloadFile();
	   prog.validateHeaderandRecords(excelHeader);
   }

   @Then("export {string} and validate Excel details")
   public void export_and_validate_the_detail(String exportType,DataTable excelHeader) 
   {
	   if(prog == null)
		   prog = new ProgressReport();
	   if(usr == null)
		   usr = new User();
	   boolean flag = usr.checkCSVFilePresent();
	   int count=0;
	   while(flag == true)
	   {
		   usr.deleteFile(Students.filePath);
		   flag = usr.checkCSVFilePresent();
		   count++;
		   if(count>=30)
			   break;
	   }			
	   prog.clickExportButton();
	   prog.clickSelectExportButton(exportType);
	   
	   prog.verifyDownloadFile();
	   prog.validateHeaderandRecords(excelHeader);
	   prog.compareDetails();
   }
   ////////////////////////////////////////////LMS CASES ///////////////////////////////////////////////////////////

   @Then("validate the header on progress report page for LMS")
   public void validate_the_header_on_progress_report_page_for_LMS() 
   {
	   prog.validateHeaderLMS();
   }

   @Then("search the details by user first name on progress report without clear search for LMS")
   public void search_the_details_by_user_first_name_without_clear_search_for_LMS() 
   {
	   if(prog == null)
		   prog = new ProgressReport();
	   System.out.println("user first name for searching user is " + Student.firstName);
	   prog.studentSearchLMSWithoutClear(Student.firstName);
   }


   @Then("click on search button in progress report")
	public void search_the_details_without_clear_search_for_vsim_course() 
	{
		if(prog == null)
			prog = new ProgressReport();
			prog.clickonProgressReport();
	}
	



}
