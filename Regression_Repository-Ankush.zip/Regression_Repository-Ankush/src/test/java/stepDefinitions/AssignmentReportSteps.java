package stepDefinitions;

import com.qa.pages.AssignmentReport;
import com.qa.pages.Compliance;
import com.qa.pages.User;
import com.qa.util.TestBase;

import io.cucumber.java.en.Then;

public class AssignmentReportSteps 
{
	Compliance comp;
	AssignmentReport assign;

	@Then("navigate to assignment report page")
	public void navigate_to_assignment_report_page() 
	{User usr=new User();
	usr.pageLoad();
		comp = new Compliance();
		assign = new AssignmentReport();
	    comp.clickOnReportLink();
	    assign.selectAssignmentReportLink();
	}
	@Then("validate the assignment report due date as {string} for course {string}")
    public void validate_the_assignment_report_due_date_as_for_course(String dueDate, String courseName)
    {
		
        if(!dueDate.equalsIgnoreCase("na"))
            assign.validateAssignmentReportDueDateAsValue(comp.changeDate(Integer.parseInt(dueDate)).replace("-", "/"), courseName);
        else
            assign.validateAssignmentReportDueDateAsValue(dueDate, courseName);
            
    }
	@Then("user click on clear search button")
	public void user_click_on_clear_search_button() 
	{
	   assign.cearSearchResult();
	}
	@Then("validate the assignment report due date as {string} for multiple course {string}")
    public void validate_the_assignment_report_due_date_as_for_multiplecourse(String dueDate, String courseName)
    {
		for(int i=0;i<courseName.split(",").length;i++)
		{
        if(!dueDate.equalsIgnoreCase("na"))
            assign.validateAssignmentReportDueDateAsValue(comp.changeDate(Integer.parseInt(dueDate)).replace("-", "/"), courseName.split(",")[i]);
        else
            assign.validateAssignmentReportDueDateAsValue(dueDate, courseName.split(",")[i]);
		}
            
    }
	
	@Then("validate the column details as per the course {string}")
    public void validate_the_coulumn_details_as_per_the_course(String courseName)
    {
        assign.validateOtherdetailsInactiveCourse(courseName);
    }
    
    @Then("validate the assignment report activation date as {string} for course {string}")
    public void validate_the_assignment_report_activation_date_as_for_course(String dueDate, String courseName)
    {
         assign.validateAssignmentReportActivationDateAsValue(dueDate, courseName);    
    }
	
	 @Then("validate the assignment report status as {string} for course {string}")
	    public void validate_the_assignment_report_status_as(String status, String courseName)
	    {
			assign = new AssignmentReport();
			
	        assign.validateStatusWithValueAndCourse(status, courseName);
	    }
	 
	 @Then("validate the assignment report User status as {string} for course {string}")
	    public void validate_the_assignment_userreport_status_as(String status, String courseName)
	    {
			assign = new AssignmentReport();
			
	        assign.validateUserStatusWithValueAndCourse(status, courseName);
	    }
		@Then("validate number of rows display {int} in assignment Report")
		public void validate_multiplecourse_isnot_available(int count)
		{
			assign.validaterow(count);
			
		}
		
	 @Then("validate the assignment report status as {string} for multiple course {string}")
	    public void validate_the_assignment_report_statusmultiple_as(String status, String courseName)
	    {
			assign = new AssignmentReport();
			for(int i=0;i<courseName.split(",").length;i++)
			{
	        assign.validateStatusWithValueAndCourse(status, courseName.split(",")[i]);
			}
	    }
	    
	    @Then("validate the assignment report due date for course {string}")
	    public void validate_the_assignment_report_due_date(String courseName)
	    {
	        assign.validateAssignmentReportDueDate(courseName);
	    }

	
	@Then("validate the assignment status as {string}")
	public void validate_the_assignment_status_as(String status) 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new AssignmentReport();
		
	    assign.validateAssignmentStatus(status);
	}
	
	@Then("validate the assignment date as {string}")
	public void validate_the_assignment_date_as(String status) 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new AssignmentReport();
		
	    assign.validateAssignmentDate(status);
	}
	
	@Then("validate the Activation date as {string}")
	public void validate_the_Activation_date_as(String status) 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new AssignmentReport();
		
	    assign.validateActivationDate(status);
	}
	
	
	@Then("validate the due date as {string}")
	public void validate_the_due_date_as(String date) 
	{
		User usr=new User();
		usr.pageLoad();
	    assign.validateDueDate(date);
	}
	
	@Then("validate the job title as {string}")
	public void validate_the_job_title_as(String title) 
	{
		User usr=new User();
		usr.pageLoad();
	    assign.validateJobTitle(title);
	}
	
	@Then("validate the job title as {string} {int}")
	public void validate_the_job_title_as(String title,int i) 
	{
		User usr=new User();
		usr.pageLoad();
	    assign.validateJobTitle(title,i);
	}
	@Then("validate the userId")
	public void validate_the_userId() 
	{
		User usr=new User();
		usr.pageLoad();
	    assign.validateUserId();
	}
	
	@Then("validate the user status {string}")
	public void validate_the_user_status(String status) 
	{
		User usr=new User();
		usr.pageLoad();
	    assign.validateUserStatus(status);
	}
	
	@Then("search the details by user id")
	public void search_the_details_by_user_id() 
	{
		User usr=new User();
		usr.pageLoad();
	    assign.userSearch(User.userId);
	    }
	
	@Then("search the details by user email id")
	public void search_the_details_by_user_email_id() 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new AssignmentReport();
		
		assign.userSearch(User.userEmail);
	}
	
	@Then("check the row count as {int}")
	public void check_the_row_count_as(Integer count) 
	{
		User usr=new User();
		usr.pageLoad();
		assign.waitForUserRow(count);
	}
	
	@Then("search the record with {string}")
	public void search_the_record_with(String criteria) 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new AssignmentReport();
		
	    assign.clickMoreFilters();
	    assign.searchFilter(criteria);
	}
	
	@Then("search Assignment Date {string}")
	public void search_Assignment_Date(String criteria) 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new AssignmentReport();
		
	    assign.clickcourseFilters();
	    assign.searchFilterAssignmentDate(criteria);
	}
	
	@Then("Filter By Due Date {string} and {string}")
	public void FilterByDueDate(String todate,String fromdate) 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new AssignmentReport();

	    assign.clickcourseFilters();
	    assign.searchFilterDueDate(todate,fromdate);
	}
	@Then("Filter Assignment Name {string}")
	public void FilterAssignment_Name(String name) 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new AssignmentReport();

	    assign.clickcourseFilters();
	    assign.selectAssignmentNameFilter(name);
	}
	@Then("filter the record with {string}")
	public void filter_the_record_with(String criteria) 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new AssignmentReport();

	    assign.clickcourseFilters();
	    assign.selectAssignmentStatusFilter(criteria);
	}
	
	@Then("Course filter {string}")
	public void Course_filter_with(String criteria) 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new AssignmentReport();

	    assign.clickcourseFilters();
	    assign.selectCourseStatusFilter(criteria);
	}
	
	
	

	@Then("Level filter {string}")
	public void Level_filter_with(String criteria) 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new AssignmentReport();

	   
	    assign.selectLevelFilter(criteria);
	}
	
	@Then("clear the applied search")
	public void clear_the_applied_search() 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new AssignmentReport();

	    assign.clearSearch_more_filters();
	}
	
	@Then("clear search")
	public void clearthe_applied_search() 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new AssignmentReport();

	    assign.clearSearch();
	}
	
	@Then("search the user details {string}")
	public void clearthe_applied_search(String details) 
	{
		User usr=new User();
		usr.usersearchEmail(details);
		
	  
	}
	@Then("search the user email in Assignment Report")
	public void search_the_user_email() 
	{
		User usr=new User();
		assign = new AssignmentReport();
		assign.usersearchEmail(User.userEmail);
		
	  
	}
	
	
	
	@Then("clear the course filter applied search")
	public void clear_the_course_filter_applied_search() 
	{
		User usr=new User();
		usr.pageLoad();
		    assign.clearSearch_course_filters();
	}
	@Then("click on more filter option on assignment report page")
	public void click_on_more_filter_option_on_compliance_report_page() 
	{
		if(assign == null)
			assign = new AssignmentReport();
	    assign.clickMoreFilter();
	}
	@Then("validate the {string} filter on assignment report page")
	public void validate_the_filter_on_assignment_report_page(String filterName) {
		if(assign == null)
			assign = new AssignmentReport();
		switch (filterName) {
		case "user status":
			assign.validateUserStatusFilterAvailability();
			break;
		case "job filter":
			assign.validateJobFilterFilterAvailability();
			break;
		case "group filter":
			assign.validateGroupFilterFilterAvailability();
			break;
		default:
			break;
		}	    
	}
	
	@Then("single select user filter status as {string} on assignment report page")
	public void single_select_user_filter_status_as_on_assignment_report_page(String filter) throws InterruptedException {
		if(assign == null)
			assign = new AssignmentReport();
		assign.selectSingleUserStatusFilter(filter);
		assign.clickOnMoreFilterSearchButton();
	}
	@Then("validate the records are available")
	public void validate_the_records_are_available() {
		if(assign == null)
			assign = new AssignmentReport();
		assign.validateRecordAvailable();
	}
	@Then("multi select user filter status as {string} on assignment report page")
	public void multi_select_user_filter_status_as_on_assignment_report_page(String filter) throws InterruptedException {
		if(assign == null)
			assign = new AssignmentReport();
		String[] filterList = filter.split(",");
		for(int i = 0; i < filterList.length; i++) {
			assign.selectMultiUserStatusFilter(filterList[i]);	
		}
		assign.clickOnMoreFilterSearchButton();
	}

	@Then("unSelect all user status on assignment report page")
	public void unSelect_all_user_status_on_assignment_report_page() throws InterruptedException {
		if(assign == null)
			assign = new AssignmentReport();
		assign.unSelectAllStatus();
		assign.clickOnMoreFilterSearchButton();
	}

	@Then("select all user status on assignment report page")
	public void select_all_user_status_on_assignment_report_page() throws InterruptedException {
		if(assign == null)
			assign = new AssignmentReport();
		assign.selectAllStatus();
		assign.clickOnMoreFilterSearchButton();
	}
	@Then("clear the selected user status on assignment report page")
	public void clear_the_selected_user_status_on_assignment_report_page() {
		if(assign == null)
			assign = new AssignmentReport();
		assign.unSelectAllStatus();
	}
	
	@Then("search the user by status {string}")
	public void search_the_user_by_status(String userStatus) throws InterruptedException {
		if(assign == null)
			assign = new AssignmentReport();
		assign.searchUserStatus(userStatus);
		assign.clickOnMoreFilterSearchButton();
	}
	
	@Then("single select job filter status on assignment report page")
	public void single_select_job_filter_status_on_assignment_report_page() throws InterruptedException {
		if(assign == null)
			assign = new AssignmentReport();
		assign.selectSingleUserJobFilter();
		assign.clickOnMoreFilterSearchButton();
	}
	@Then("multi select job filter status on assignment report page {int}")
	public void multi_select_job_filte_status_on_assignment_report_page(int count) throws InterruptedException {
		if(assign == null)
			assign = new AssignmentReport();
		for(int i = 0; i < count; i++) {
			assign.selectMultiUserJobFilter();	
		}
		assign.clickOnMoreFilterSearchButton();
	}
	
	@Then("unSelect all job filter status on assignment report page")
	public void un_select_all_job_filter_status_on_assignment_report_page() throws InterruptedException {
		if(assign == null)
			assign = new AssignmentReport();
		assign.unSelectAllJobFilter();
		assign.clickOnMoreFilterSearchButton();
	}
	
	@Then("select all job filter status on assignment report page")
	public void select_all_job_filter_status_on_assignment_report_page() throws InterruptedException {
		if(assign == null)
			assign = new AssignmentReport();
		assign.selectAllJobFilter();
		assign.clickOnMoreFilterSearchButton();
	}
	
	@Then("search the job filter")
	public void search_the_job_filter() throws InterruptedException {
		if(assign == null)
			assign = new AssignmentReport();
		assign.searchJobFilter();
		assign.clickOnMoreFilterSearchButton();
	}

	
	@Then("clear the selected job filter status on assignment report page")
	public void clear_the_selected_job_filter_status_on_assignment_report_page() {
		if(assign == null)
			assign = new AssignmentReport();
		assign.unSelectAllJobFilter();
	}
	
	
	
	@Then("single select group filter status on assignment report page")
	public void single_select_group_filter_status_on_assignment_report_page() throws InterruptedException {
		if(assign == null)
			assign = new AssignmentReport();
		assign.selectSingleUserGroupFilter();
		assign.clickOnMoreFilterSearchButton();
	}
	
	@Then("multi select group filter status on assignment report page {int}")
	public void multi_select_group_filter_status_on_assignment_report_page(int count) throws InterruptedException {
		if(assign == null)
			assign = new AssignmentReport();
		for(int i = 0; i < count; i++) {
			assign.selectMultiUserGroupFilter();	
		}
		assign.clickOnMoreFilterSearchButton();
	}

	@Then("unSelect all group filter status on assignment report page")
	public void un_select_all_group_filter_status_on_assignment_report_page() throws InterruptedException {
		if(assign == null)
			assign = new AssignmentReport();
		assign.unSelectAllGroupFilter();
		assign.clickOnMoreFilterSearchButton();
	}

	@Then("select all group filter status on assignment report page")
	public void select_all_group_filter_status_on_assignment_report_page() throws InterruptedException {
		if(assign == null)
			assign = new AssignmentReport();
		assign.selectAllGroupFilter();
		assign.clickOnMoreFilterSearchButton();
	}

	@Then("clear the selected group filter status on assignment report page")
	public void clear_the_selected_group_filter_status_on_assignment_report_page() {
		if(assign == null)
			assign = new AssignmentReport();
		assign.unSelectAllGroupFilter();
	}

	@Then("search the group filter")
	public void search_the_group_filter() throws InterruptedException {
		if(assign == null)
			assign = new AssignmentReport();
		assign.searchGroupFilter();
		assign.clickOnMoreFilterSearchButton();
	}
	@Then("validate user search filter on assignment report page")
	public void validate_user_search_filter_on_assignment_report_page() 
	{
		if(assign == null)
			assign = new AssignmentReport();
		assign.validateUserSearchFilterOptions();
	}

	@Then("validate org level filter on assignment report page")
	public void validate_org_level_filter_on_assignment_report_page() 
	{
		if(assign == null)
			assign = new AssignmentReport();
		assign.validateOrgLevelFilterOptions();
		assign.validateUnitLevelFilterOptions();
	}
	
	@Then("select the org level {int} from organization level dropdown on assignment report page")
	public void select_the_org_level_from_organization_level_dropdown_on_assignment_report_page(Integer level) {
		if(assign == null)
			assign = new AssignmentReport();
		assign.selectOrgLevelMainFilter(level);
	}
	
//////////////////////////////////////////////////////////////
	
	@Then("click on course filter option on assignment report page")
	public void click_on_course_filter_option_on_compliance_report_page() 
	{
		if(assign == null)
			assign = new AssignmentReport();
	    assign.clickCourseFilter();
	}
	
	@Then("validate and click the {string} filter on assignment report page")
	public void validate_and_click_the_filter_on_assignment_report_page(String filterName) {
		if(assign == null)
			assign = new AssignmentReport();
		switch (filterName) {
		case "Course":
			assign.validateCourseStatusFilterAvailability(filterName);
			break;
		case "Assignment":
			assign.validateAssignmentNameFilterAvailability(filterName);
			break;
		case "Assignment Status":
			assign.validateAssignmentStatusFilterAvailability(filterName);
			break;
		case "Filter By Assignment Date":
			assign.validateAssignmentDateFilterAvailability(filterName);
			break;
		case "Filter By Due Date":
			assign.validateAssignmentDueDateFilterAvailability(filterName);
			break;
		default:
			break;
		}	    
	}
	
	@Then("single select course filter status on assignment report page {string}")
	public void single_select_course_filter_status_on_assignment_report_page(String course) {
		if(assign == null)
			assign = new AssignmentReport();
		assign.selectSingleUserCourseFilter(course);
		assign.clickOnCourseFilterSearchButton();
	}
	
	@Then("multi select course filter status on assignment report page {int}")
	public void multi_select_course_filter_status_on_assignment_report_page(int count) {
		if(assign == null)
			assign = new AssignmentReport();
		for(int i = 0; i < count; i++) {
			assign.selectMultiUserCourseFilter();	
		}
		assign.clickOnCourseFilterSearchButton();
	}
	
	@Then("unSelect all course filter status on assignment report page")
	public void un_select_all_course_filter_status_on_assignment_report_page() {
		if(assign == null)
			assign = new AssignmentReport();
		assign.unSelectAllCourseFilter();
		assign.clickOnCourseFilterSearchButton();
	}
	
	@Then("select all course filter status on assignment report page")
	public void select_all_course_filter_status_on_assignment_report_page() {
		if(assign == null)
			assign = new AssignmentReport();
		assign.selectAllCourseFilter();
		assign.clickOnCourseFilterSearchButton();
	}

	@Then("clear the selected course filter status on assignment report page")
	public void clear_the_selected_course_filter_status_on_assignment_report_page() {
		if(assign == null)
			assign = new AssignmentReport();
		assign.unSelectAllCourseFilter();
	}

	@Then("search the course filter {string}")
	public void search_the_course_filter(String course) {
		if(assign == null)
			assign = new AssignmentReport();
		assign.searchCourseFilter(course);
		assign.clickOnCourseFilterSearchButton();
	}
	@Then("validate the header on assignment report page")
	public void validate_the_header_on_assignment_report_page() 
	{
		if(assign == null)
			assign = new AssignmentReport();
		assign.validateHeader();
	}
	@Then("validate no records available on assignment report page")
	public void validate_no_records_available_on_assignment_report_page() {
		if(assign == null)
			assign = new AssignmentReport();
		assign.validateRecordNotAvailableCount();
	}
	@Then("single select assignment filter status on assignment report page")
	public void single_select_assignment_filter_status_on_assignment_report_page() {
		if(assign == null)
			assign = new AssignmentReport();
		assign.selectSingleUserAssignmentFilter();
		assign.clickOnCourseFilterSearchButton();
	}
	
	@Then("multi select assignment filter status on assignment report page {int}")
	public void multi_select_assignment_filter_status_on_assignment_report_page(int count) {
		if(assign == null)
			assign = new AssignmentReport();
		for(int i = 0; i < count; i++) {
			assign.selectMultiUserAssignmentFilter();	
		}
		assign.clickOnCourseFilterSearchButton();
	}
	
	@Then("unSelect all assignment filter status on assignment report page")
	public void un_select_all_assignment_filter_status_on_assignment_report_page() {
		if(assign == null)
			assign = new AssignmentReport();
		assign.unSelectAllAssignmentFilter();
		assign.clickOnCourseFilterSearchButton();
	}
	
	@Then("select all assignment filter status on assignment report page")
	public void select_all_assignment_filter_status_on_assignment_report_page() {
		if(assign == null)
			assign = new AssignmentReport();
		assign.selectAllAssignmentFilter();
		assign.clickOnCourseFilterSearchButton();
	}

	@Then("clear the selected assignment filter status on assignment report page")
	public void clear_the_selected_assignment_filter_status_on_assignment_report_page() {
		if(assign == null)
			assign = new AssignmentReport();
		assign.unSelectAllAssignmentFilter();
	}

	@Then("search the assignment filter")
	public void search_the_assignment_filter() {
		if(assign == null)
			assign = new AssignmentReport();
		assign.searchAssignmentFilter();
		assign.clickOnCourseFilterSearchButton();
	}

	
	
	@Then("validate the page numbers on assignment report page")
	public void validate_the_page_numbers() 
	{
		if(assign == null)
			assign = new AssignmentReport();
		assign.validatePageNumbers();
		assign.getLocationPageNumber();
		assign.validatePaginationDropdown();
		assign.selectPaginationDropdown();
	}

	@Then("export and validate the details on assignment report page")
	public void export_and_validate_the_details() 
	{
		if(assign == null)
			assign = new AssignmentReport();
		
		User	usr = new User();
		boolean flag = usr.checkCSVFilePresent();
		while(flag == true)
		{
			usr.deleteFile(User.filePath);
			flag = usr.checkCSVFilePresent();
		}			
		assign.clickExportButton();
		assign.verifyDownloadFile();
		assign.compareDetails();
	}
	
	@Then("validate default user filter status as {string} on assignment report page")
	public void validate_default_user_filter_status_as_on_assignment_report_page(String status) {
		if(assign == null)
			assign = new AssignmentReport();
		assign.validateDefaultUserStatusFilter(status);
	}
	@Then("validate the row counts {int} on assignment report page")
	public void validate_the_row_counts(Integer rowCount) 
	{
	    assign.validateRowCount(rowCount);
	}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
@Then("single select Assignment Status filter status on assignment report page {string}")
public void single_select_Assignment_Status_filter_status_on_assignment_report_page(String status) {
if(assign == null)
assign = new AssignmentReport();
assign.selectSingleUserAssignmentStatusFilter(status);
assign.clickOnCourseFilterSearchButton();
}

@Then("multi select Assignment Status filter status on assignment report page {int}")
public void multi_select_Assignment_Status_filter_status_on_assignment_report_page(int count) {
if(assign == null)
assign = new AssignmentReport();
for(int i = 0; i < count; i++) {
assign.selectMultiUserAssignmentStatusFilter();	
}
assign.clickOnCourseFilterSearchButton();
}

@Then("unSelect all Assignment Status filter status on assignment report page")
public void un_select_all_Assignment_Status_filter_status_on_assignment_report_page() {
if(assign == null)
assign = new AssignmentReport();
assign.unSelectAllAssignmentStatusFilter();
assign.clickOnCourseFilterSearchButton();
}

@Then("select all Assignment Status filter status on assignment report page")
public void select_all_Assignment_Status_filter_status_on_assignment_report_page() {
if(assign == null)
assign = new AssignmentReport();
assign.selectAllAssignmentStatusFilter();
assign.clickOnCourseFilterSearchButton();
}

@Then("clear the selected Assignment Status filter status on assignment report page")
public void clear_the_selected_Assignment_Status_filter_status_on_assignment_report_page() {
if(assign == null)
assign = new AssignmentReport();
assign.unSelectAllAssignmentStatusFilter();
}

@Then("search the Assignment Status filter {string}")
public void search_the_Assignment_Status_filter(String status) {
if(assign == null)
assign = new AssignmentReport();
assign.searchAssignmentStatusFilter(status);
assign.clickOnCourseFilterSearchButton();
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@Then("enter the from assignment due date with {int} {string}")
public void enter_the_from_assignment_due_date_with(Integer num, String time) {
if(assign == null)
assign = new AssignmentReport();
assign.enterFromAssignmentDueDate(num, time);
}

@Then("enter the to assignment due date with quarter {int}")
public void enter_the_to_assignment_due_date(int quarter) {
if(assign == null)
assign = new AssignmentReport();
assign.enterToAssignmentDueDateQuarterEnd(quarter);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@Then("enter the from assignment start date with {int} {string}")
public void enter_the_from_assignment_start_date_with(Integer num, String time) {
if(assign == null)
assign = new AssignmentReport();
assign.enterFromAssignmentStartDate(num, time);
}

@Then("enter the to assignment start date with quarter {int}")
public void enter_the_to_assignment_start_date(int quarter) {
if(assign == null)
assign = new AssignmentReport();
assign.enterToAssignmentStartDateQuarterEnd(quarter);
}

}
