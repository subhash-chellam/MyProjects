package stepDefinitions;

import com.qa.pages.AssignmentReport;
import com.qa.pages.KeyClock;

import com.qa.pages.LoginPage;
import com.qa.pages.OrganizationAccess;
import com.qa.pages.OrganizationHome;
import com.qa.pages.UserManagement;
import com.qa.pages.forgotPassword;
import com.qa.pages.mailinatorAPI;
import com.qa.util.TestBase;

import io.cucumber.java.en.Then;

public class KeyClockSteps 
{
	KeyClock key;	
	UserManagement usr;
	LoginPage login;
	forgotPassword fpassword=new forgotPassword();
	mailinatorAPI mail=new mailinatorAPI();
	
	@Then("navigate to yopmail and change password")
	public void navigate_to_yopmail_and_change_password() 
	{
	    key = new KeyClock();
	    usr = new UserManagement();
	    key.navigateYopmail();
	    key.clickOnPwdChangeLink();
	    usr.switchTab();
	    key.setNewPwd();
	    usr.switchTab();
	    usr.closeOtherTab();
	    
	}

	@Then("navigate to subdomain as user")
	public void navigate_to_subdomain_as_user() 
	{
		  key = new KeyClock();
		  usr = new UserManagement();
		  
	    key.navigateSubDomain();
	}
	
	@Then("navigate to ADFS subdomain as user")
	public void navigate_ADFS_to_subdomain_as_user() 
	{
		  key = new KeyClock();
		  usr = new UserManagement();
		  
	    key.navigateADFSSubDomain();
	}
	@Then("navigate to yopmail")
	public void navigate_to_yopmail() 
	{
		key = new KeyClock();
	    key.navigateYopmail();
	    key.loginYopmail();
	}
	@Then("validate mail title {string}")
	public void validatemail_title(String title) 
	{
		key = new KeyClock();
	    key.validatetitle(title);
	}
	
	@Then("validate mail body {string}")
	public void validatemaildata(String data) 
	{
		key = new KeyClock();
	    key.validatebody(data);
	}
	
	@Then("login to subdomain as user")
	public void login_to_subdomain_as_user() 
	{
	    key.clickLoginSubDomain();
	    key.loginToSubDomain();
	    key.handleFederalPopup();
	}
	
	@Then("login to subdomain as user validate Error msg {string}")
	public void login_to_subdomain_as_user(String errorMsg) 
	{
	    key.clickLoginSubDomain();
	    key.loginToSubDomain(errorMsg);
//	    key.handleFederalPopup();
	}
	
	@Then("login to ADFS subdomain as user")
	public void login_tosubdomain_as_user() 
	{
	   key.subDomainHomeLoginADFS();
		key.loginToADFSSubDomain();
//	    key.handleFederalPopup();
	}


	@Then("login to subdomain for student")
	public void login_to_subdomain_s_student() 
	{
	    key.clickLoginSubDomain();
	    key.loginToSubDomainStudent();
//	    key.handleFederalPopup();
	}
	@Then("user logout from subdomain")
	public void user_logout_from_subdomain() 
	{
	    key.logoutFromSubDomain();
	}

////////////////////////////////////////////////////////Admin//////////////////////////////////////////
	
	public void navigate_to_yopmail_and_change_password_for_admin() 
	{
	    key = new KeyClock();
	    usr = new UserManagement();
	    key.navigateYopmail();
	    key.clickOnPwdChangeLink_Admin();
	    usr.switchTab();
	    key.setNewPwd();
	    usr.switchTab();
	    usr.closeOtherTab();
	    
	}
	
	@Then("Change password")
	public void navigate_o_opmail_and_change_password_for_admin() 
	{
	    key = new KeyClock();
	    usr = new UserManagement();
	    key.setNewPwd();
//	    usr.switchTab();
//	    usr.closeOtherTab();
	    
	}
	 
	@Then("Perform Forgot password {int}")
	public void Perform_Forgot_password(int n) throws Exception 
	{
		if(login==null)
			login=new LoginPage();
		
		for(int i=0;i<n;i++)
		{
		key.navigateSubDomainAsAdmin();
		login.clickOnAdminSignIn();
		Thread.sleep(5000);
		fpassword.clickOnForgotPasswordLink();
		fpassword.sendemailForgot();
		 mail.clickOnPwdChangeLink_Admin("Change Password","Forgot Password");
		 key.setNewPwd2();
		 }
		
	}
	
	@Then("Perform Forgot password {int} same Password")
	public void Perform_Forgot_passwordsame(int n) throws Exception 
	{
		if(login==null)
			login=new LoginPage();
		
		for(int i=0;i<n;i++)
		{
		key.navigateSubDomainAsAdmin();
		login.clickOnAdminSignIn();
		Thread.sleep(5000);
		fpassword.clickOnForgotPasswordLink();
		fpassword.sendemailForgot();
		  key.navigateYopmail();
		  key. searching();
		  fpassword.sendemail();
		    usr.switchTab();
		    	key.setNewPwd();
		    usr.switchTab();
		    usr.closeOtherTab();
		 }
		
	}
	

	@Then("Perform Forgot password {int} same Password {string}")
	public void Perform_Forgot_passwordsame(int n,String password) throws Exception 
	{
		if(login==null)
			login=new LoginPage();
		
		for(int i=0;i<n;i++)
		{
		key.navigateSubDomainAsAdmin();
		login.clickOnAdminSignIn();
		Thread.sleep(5000);
		fpassword.clickOnForgotPasswordLink();
		fpassword.sendemailForgot();
		  key.navigateYopmail();
		  key. searching();
		  fpassword.sendemail();
		    usr.switchTab();
		    	key.setNewPwd(password);
		    usr.switchTab();
		    usr.closeOtherTab();
		 }
		
	}
	
	@Then("navigate to yopmail and change password {int}")
	public void navigate_to_yopmail_and_change_password(int n) 
	{
	    key = new KeyClock();
	    usr = new UserManagement();
	    key.navigateYopmail();
	    key.clickOnPwdChangeLink_Admin();
	    usr.switchTab();
	    key.setNewPwd();
	    usr.switchTab();
	    usr.closeOtherTab();
	    
	    for(int i=1;i<n;i++)
		{
	    key.clickOnPwdChange();
	    usr.switchTab();
	    key.setNewPwd2();
	    usr.switchTab();
	    usr.closeOtherTab();
		}
	    
	}
	
	

	@Then("Email updated mail")
	public void Email_password() throws Exception 
	{
	
//		key.navigateSubDomainAsAdmin();
//		login.clickOnAdminSignIn();
//		Thread.sleep(5000);
//		fpassword.clickOnForgotPasswordLink();
//		fpassword.sendemailForgot();
		
		 mail.clickOnPwdChangeLink_Admin("Change Password","Email Updated successfully.");
			
		
//		  fpassword.sendemail();
		   key.setNewPwd();
		
		
	}
	@Then("perform forgot password functionality")
	public void perform_forgot_password_functionality()
	{
		login = new LoginPage();
		login.clickOnAdminSignIna(); 
		
	 	fpassword.clickOnForgotPasswordLink();
		fpassword.enterEmail();
	}
	
	@Then("validate the error message for email")
	public void validate_the_error_message_for_email()
	{
		fpassword.clickOnForgotPasswordLink();
		fpassword.validateErrorForEmptyEmail();
	}
	
	@Then("Validate instruction {string}")
	public void validate_instruction(String instruction) 
	{
		  key = new KeyClock();
		key.checkinstruction(instruction);
	}
	@Then("navigate to yopmail and click on change password")
	public void navigate_toyopmail_and_change_password() 
	{
	    key = new KeyClock();
	    usr = new UserManagement();
	    key.navigateYopmail();
	    key.clickOnPwdChangeLink_Admin();
	    usr.switchTab();

	    
	}
	@Then("navigate to yopmail and change password for admin Error Msg {string}")
	public void navigate_to_yopmail_and_change_password_for_admin(String msg) 
	{
	    key = new KeyClock();
	    usr = new UserManagement();
	    key.navigateYopmail();
	    key.clickOnPwdChangeLink_Admin();
	    usr.switchTab();
	    key.setNewPwd();
	    OrganizationHome orgHome=new OrganizationHome();
		orgHome.errormsg(msg);
//	    usr.switchTab();
//	    usr.closeOtherTab();
//	    
	}

	@Then("navigate to subdomain as admin")
	public void navigate_to_subdomain_as_admin() 
	{

	    key = new KeyClock();
	     
	    key.navigateSubDomainAsAdmin();
	}
	@Then("login to subdomain as student Login page")
	public void login_to_subdomain_as_unitObserver() 
	{
		login = new LoginPage();
		login.clickOnAdminSignIn(); 
		key.loginToSubDomain_Admin();
	//	key.handleFederalPopup();
	//	key.clickOnAdminRole();
	    
	}
	@Then("navigate to subdomain from saved file")
	public void navigate_to_subdomain_as_adminsaved() 
	{

	    key = new KeyClock();
	     
	    key.navigateSubDomainAsAdmin(AssignmentReport.getParmeterAvailable("subdomain"+TestBase.prop.getProperty("environment")));
	}

	@Then("navigate to subdomain from saved file LMS")
	public void navigate_to_subdomain_as_adminsavedLMS() 
	{

	    key = new KeyClock();
	     
	    key.navigateSubDomainAsAdmin(AssignmentReport.getParmeterAvailable("subdomainLMS"+TestBase.prop.getProperty("environment")));
	}
	@Then("navigate to subdomain as student")
	public void navigate_to_subdomain_asadmin() 
	{

	    key = new KeyClock();
	     
	    key.navigateSubDomainAsStudent();
	}
	@Then("login to subdomain as admin")
	public void login_to_subdomain_as_admin() 
	{
		login = new LoginPage();
		login.clickOnAdminSignIn(); 
		key.loginToSubDomain_Admin();
//		key.handleFederalPopup();
		key.clickOnAdminRole();
	    
	}
	@Then("login to subdomain as org admin for federal org")
	public void login_to_subdomain_as_orgadmin() 
	{
		login = new LoginPage();
		login.clickOnAdminSignIn(); 
		key.loginToSubDomain_Admin();
		key.handleFederalPopup();
		key.clickOnOrgAdminRole();
	    
	}
	@Then("login to subdomain as org admin")
	public void login_to_subdomain_asorgadmin() 
	{
		login = new LoginPage();
		login.clickOnAdminSignIn(); 
		key.loginToSubDomain_Admin();
		key.clickOnOrgAdminRole();
	    
	}
	@Then("login to subdomain as {string} from saved filed")
	public void login_to_subdomain_from_admin(String role) 
	{
		login = new LoginPage();
		login.clickOnAdminSignInforadmin(); 
		key.loginToSubDomain_savedAdmin(AssignmentReport.getParmeterAvailable(role+"Email"+TestBase.prop.getProperty("environment")),AssignmentReport.getParmeterAvailable(role+"Password"+TestBase.prop.getProperty("environment")));
//		key.handleFederalPopup();
		if(role.contains("Admin"))
		key.clickOnAdminRole();
		else
			key.clickOnObserverRole();	
	}
	@Then("Click on Admin Role")
	public void loginto_subdomain_as_admin() 
	{
		
		key.clickOnAdminRole();
	    
	}
	
	@Then("login to subdomain admin")
	public void login_tosubdomain_as_admin() 
	{
		login = new LoginPage();
		login.clickOnAdminSignIn(); 
		key.loginToSubDomain_Admin();
		key.clickOnAdminRole();
	    
	}
	
	@Then("login to subdomain as admin for non federal Org")
	public void login_to_subdomain_as_adminfor_non_federal_Org() 
	{
		login = new LoginPage();
		login.clickOnAdminSignIn(); 
		key.loginToSubDomain_Admin();
		key.federalhandleFederalPopup();
		key.clickOnAdminRole();
	    
	}
	@Then("login to subdomain as admin and decline popup")
	public void login_to_subdomainas_admin() 
	{
		login = new LoginPage();
		login.clickOnAdminSignIn(); 
		key.loginToSubDomain_Admin();
		key.declinehandleFederalPopup();
	    
	}
	
	@Then("login to subdomain as student and decline popup")
	public void login_to_subdomainas_student() 
	{
		login = new LoginPage();
//		login.clickOnAdminSignIn(); 
		key.loginToSubDomain_Admin();
		key.declinehandleFederalPopup();
	    
	}
	@Then("login to subdomain as admin Error Msg {string}")
	public void login_to_subomain_as_admin(String msg) 
	{
		login = new LoginPage();
		login.clickOnAdminSignIn(); 
		key.loginToSubDomain_Admin();
		 OrganizationHome orgHome=new OrganizationHome();
			orgHome.errormsg(msg);
		
	}
/////////////////////////////////////////////////////////// Unit Observer ///////////////////////////	
	
	@Then("login to subdomain as observer")
	public void login_to_subdomain_as_observer() 
	{
		login = new LoginPage();
		login.clickOnAdminSignIn(); 
		key.loginToSubDomain_Admin();
		key.handleFederalPopup();
		key.clickOnObserverRole();
	    
	}
	@Then("login to subdomain as observer for non federal Org")
	public void login_to_subdomain_as_observefor_non_federal_Orgr() 
	{
		login = new LoginPage();
		login.clickOnAdminSignIn(); 
		key.loginToSubDomain_Admin();
		key.federalhandleFederalPopup();
		key.clickOnObserverRole();
	    
	}
	@Then("login to subdomain as observer and decline popup")
	public void login_to_subdomainas_decline() 
	{
		login = new LoginPage();
		login.clickOnAdminSignIn(); 
		key.loginToSubDomain_Admin();
		key.declinehandleFederalPopup();
	    
	}
	@Then("login to subdomain as student")
	public void login_to_subdomain_as_student() 
	{
		login = new LoginPage();
//		login.clickOnAdminSignIn(); 
		key.loginToSubDomain_Admin();
		key.handleFederalPopup();
//		key.clickOnObserverRole();
	    
	}
	
	@Then("login to subdomain")
	public void login_to_subdomain() 
	{
		login = new LoginPage();
//		login.clickOnAdminSignIn(); 
		key.loginToSubDomain_Student();
		key.handleFederalPopup();
//		key.clickOnObserverRole();
	    
		
	}
	
	@Then("login to subdomain check Federal Popup")
	public void login_to_subomain() 
	{
		
		login = new LoginPage();
//		login.clickOnAdminSignIn(); 
		key.loginToSubDomain_Student();
		key.handleFederalPopupyes();
//		key.clickOnObserverRole();
		
		
	}
	

	@Then("login to subdomain check should not show Federal Popup")
	public void login_to_ubomain() 
	{
		
		login = new LoginPage();
//		login.clickOnAdminSignIn(); 
		key.loginToSubDomain_Student();
		key.handlenotavalableFederalPopupyes();
//		key.clickOnObserverRole();
		
		
	}
	
	@Then("login to subdomain as observer check Federal Popup")
	public void login_to_subdomain_as_observercheck_Federal_Popup() 
	{
		login = new LoginPage();
		login.clickOnAdminSignIn(); 
		key.loginToSubDomain_Admin();
		key.handleFederalPopupyes();
		key.clickOnObserverRole();
	    
	}
	
	@Then("login to subdomain as admin check Federal Popup")
	public void login_to_subdomainas_admin_federal() 
	{
		login = new LoginPage();
		login.clickOnAdminSignIn(); 
		key.loginToSubDomain_Admin();
		key.handleFederalPopupyes();
		key.clickOnAdminRole();
	    
	}
	
	@Then("login to subdomain as student check Federal Popup")
	public void login_to_subdomain_as_student_Federal() 
	{
		login = new LoginPage();
//		login.clickOnAdminSignIn(); 
		key.loginToSubDomain_Admin();
		key.handleFederalPopupyes();
//		key.clickOnObserverRole();
	    
	}
	
	@Then("loggout subdomain")
	public void loggout_to_subdomain() 
	{
		login = new LoginPage();
//		login.clickOnAdminSignIn(); 
		key.logoutToSuddomain();
//		key.handleFederalPopup();
//		key.clickOnObserverRole();
	    
		
	}
	@Then("validate mail body text")
	public void validatemailbodytext() throws InterruptedException {
		key = new KeyClock();
		key.ValidatebodyText();
	}
	
	@Then("Perform Forgot password")
	public void Perform_Forgot_password() throws Exception 
	{
		if(login==null)
			login=new LoginPage();
		
		
		Thread.sleep(5000);
		fpassword.clickOnForgotPasswordLink();
		fpassword.sendemailForgot();
		mail.clickOnPwdChangeLink_Admin("Change Password","Forgot Password");
		
		
	}
	
	@Then("Perform Forgot password with same Password")
	public void Perform_Forgot_passwordsame() throws Exception 
	{
		if(login==null)
			login=new LoginPage();
		
		key.navigateSubDomainAsAdmin();
		login.clickOnAdminSignIn();
		Thread.sleep(5000);
		fpassword.clickOnForgotPasswordLink();
		fpassword.sendemailForgot();
		mail.clickOnPwdChangeLink_Admin("Change Password","Forgot Password");
		key.setSamePwd();
		
		
	}
	
	@Then("navigate to yopmail and validate the notifcation for forgot password by user")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_forgot_password_by_user() 
	{
		key = new KeyClock();
		key.navigateYopmail();
		key.loginYopmailForForgotPassword();
	}

	@Then("navigate to yopmail and count rows {int} for account created successfully")
	public void navigate_to_yopmail_and_count_rows_for_account_created_successfully(Integer count)
	{
		key = new KeyClock();
		
	    usr = new UserManagement();
	    key.navigateYopmail();
	    key.validateRowCount_Account_Creation(count);
	}
	
	@Then("navigate to yopmail and validate the notifcation for organization admin")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_organization_admin() 
	{
		key = new KeyClock();
		key.navigateYopmail();
		key.loginYopmailForOrgAdmin();
	}
	
	@Then("navigate to yopmail and validate the notifcation for unit admin as new user")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_unit_admin_as_new_user() 
	{
		key = new KeyClock();
		key.navigateYopmail();
		key.loginYopmailForUnitAdmin();
	}

	@Then("navigate to yopmail and validate the notifcation for student")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_student() 
	{
		key = new KeyClock();
		key.navigateYopmail();
		key.loginYopmailForStudentLMS();
	}
	@Then("navigate to yopmail and validate the notifcation for unit observer as new user")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_unit_observer_as_new_user() 
	{
		key = new KeyClock();
		key.navigateYopmail();
		key.loginYopmailForUnitObserver();
	}
	@Then("navigate to yopmail and validate the notifcation for assignment completed by user")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_assignment_completed_by_user() 
	{
		key = new KeyClock();
		key.navigateYopmail();
		key.loginYopmailForAssignmentCompleted();
	}
	@Then("navigate to yopmail and validate the notifcation for email update by student")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_email_update_by_student() 
	{
		key = new KeyClock();
		key.navigateYopmail();
		key.loginYopmailForEmailUpdatedStudent();
	}
	@Then("navigate to yopmail and validate the notifcation for unit admin as new user for CTC")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_unit_admin_as_new_user_for_CTC() 
	{
		key = new KeyClock();
		key.navigateYopmail();
		key.loginYopmailForUnitAdminForCTC();
	}
	
	@Then("navigate to yopmail and validate the notifcation for unit observer as new user for CTC")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_unit_observer_as_new_user_for_CTC() 
	{
		key = new KeyClock();
		key.navigateYopmail();
		key.loginYopmailForUnitObserverForCTC();
	}

	@Then("navigate to yopmail and validate the email content for account created successfully")
	public void navigate_to_yopmail_and_validate_the_email_content_for_account_created_successfully() {
		key = new KeyClock();
		key.navigateYopmail();
		key.validateEmailContentUserCreated();
	}
	
	@Then("navigate to yopmail and validate the email content for new assignment available")
	public void navigate_to_yopmail_and_validate_the_email_content_for_new_assignment_available() {
		key = new KeyClock();
		key.navigateYopmail();
		key.validateEmailContentAssignmentAvailable();
	}
	
	@Then("navigate to yopmail and validate the email content for unit admin as new user for CTC")
	public void navigate_to_yopmail_and_validate_the_the_email_content_for_unit_admin_as_new_user_for_CTC() 
	{
		key = new KeyClock();
		key.navigateYopmail();
		key.validateEmailContentUnitAdminForCTC();
	}
	
	@Then("navigate to yopmail and validate the email content for unit observer as new user for CTC")
	public void navigate_to_yopmail_and_validate_the_the_email_content_for_unit_observer_as_new_user_for_CTC() 
	{
		key = new KeyClock();
		key.navigateYopmail();
		key.validateEmailContentUnitObserverForCTC();
	}

	@Then("navigate to yopmail and validate the notifcation for assignment available by user")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_assignment_available_by_user() 
	{
		key = new KeyClock();
		key.navigateYopmail();
		key.loginYopmailForAssignmentAvailable();
	}
	@Then("navigate to yopmail and validate the notifcation for user")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_uer() 
	{
		key = new KeyClock();
		key.navigateYopmail();
		key.loginYopmailForUser();
	}
	
	
	
	
}
