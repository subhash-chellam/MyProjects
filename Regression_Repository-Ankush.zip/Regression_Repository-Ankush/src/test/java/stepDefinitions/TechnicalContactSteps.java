package stepDefinitions;

import com.qa.pages.OrganizationHome;
import com.qa.pages.TechnicalContact;
import io.cucumber.java.en.Then;

public class TechnicalContactSteps
{
	TechnicalContact tc;
	OrganizationHome orgHome;
	
	@Then("navigate to contact page")
	public void navigate_to_contact_page() 
	{
	   tc = new TechnicalContact();
	   tc.navigateToTechnicalContactsTab();
	}

	@Then("add the contact")
	public void add_the_contact() 
	{
		orgHome = new OrganizationHome();
	    tc.clickOnAddTechnicalContactsButton();
	    tc.enterContactDetails();
	    orgHome.validateSucessMesssage();
	}
	
	@Then("edit the contact")
	public void edit_the_contact() 
	{
	    tc.editTechnicalContact();
	    orgHome.validateSucessMesssage();
	}
	
	@Then("delete the contact")
	public void delete_the_contact() 
	{
	    tc.deleteTechnicalContact();
	    orgHome.validateSucessMesssage();
	    tc.confirmNoRecord();
	}
}
