package stepDefinitions;

import com.qa.pages.CourseManagement;
import com.qa.pages.UserManagement;
import io.cucumber.java.en.Then;

public class CourseManagementSteps 
{
	CourseManagement mgmt;
	UserManagement usrmgmt;
	
	@Then("search course by name {string}")
	public void search_course_by_name(String name) 
	{
		
		mgmt = new CourseManagement();
		usrmgmt = new UserManagement();
		mgmt.searchCourseByName(name);
		usrmgmt.clickSearch();
		
	}
	@Then("navigate to edit course {string} page")
	public void navigate_to_edit_course_page(String courseName) {
		mgmt.openCourseDetails(courseName);
	}

	@Then("search newly created course")
	public void search_course_by_name() 
	{
		
		mgmt = new CourseManagement();
		usrmgmt = new UserManagement();
		
//		mgmt.courseNameValue="course_MonMay0116:38:35IST2023";
		mgmt.searchCourseByName(mgmt.courseNameValue);
		usrmgmt.clickSearch();
		
	}
	

	@Then("edit course by name {string}")
	public void edit_course_by_name(String name) 
	{
		
		mgmt.editCourse(name);
	
		
	}
	

	@Then("edit newly created course by name")
	public void edit_course_by_name() 
	{
		
		mgmt.editCourse(mgmt.courseNameValue);
	
		
	}
	@Then("Update the course mode to {string}")
	public void update_the_course_mode_to(String mode) throws InterruptedException 
	{
		
		mgmt.coursemode(mode);;
	
		
	}
	
	
	
	@Then("check the course evaluation")
	public void check_the_course_evaluation() 
	{
	    mgmt.courseEvaluationStatus();
	}
	
	@Then("Search {string} and Add url {string} in Course Management")
	public void check_the_course_evaluation(String course,String url) 
	{
		mgmt = new CourseManagement();
		
	    mgmt.courseaddurl(course,url);
	}
	
	
	@Then("User Creates Course Primary Category as {string} and Course Module Type as {string}")
	public void check_thecourse_evaluation(String primaryCat,String courseModule) throws InterruptedException 
	{
		mgmt = new CourseManagement();
		
	    mgmt. createCourse(primaryCat,courseModule);
	}
	
	

	@Then("validate the course detail")
	public void check_thecourse_evaluation() 
	{
		mgmt = new CourseManagement();
		
	    mgmt. validateCourseDetails();
	}
	
	

	@Then("User updates Created Course")
	public void check_updatesthecourse_evaluation() 
	{
		mgmt = new CourseManagement();
		
	    mgmt. updateCourse();
	}
	

	@Then("validate the updated course detail")
	public void check_theupdatedcourse_evaluation() 
	{
		mgmt = new CourseManagement();
		
	    mgmt. validateCourseupdateDetails();
	}
	
	

	

}
