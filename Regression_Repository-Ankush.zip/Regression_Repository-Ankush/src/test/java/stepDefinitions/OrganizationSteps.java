package stepDefinitions;

import com.qa.util.TestBase;
import com.qa.util.reuseableCode;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.qa.pages.*;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;

public class OrganizationSteps
{
	OrganizationHome orgHome;
	NewOrganization newOrg;
	OrganizationDetails orgDetails;
	OrganizationAccess organAccess = new OrganizationAccess();;
	OrganizationSettings orgSet = new OrganizationSettings();
	Compliance comp;
	LoginPage login;
	forgotPassword fpassword=new forgotPassword();
	DemographicTemplateSetting dts;
	public static String name = "",organizationURl;
	String orgID;
	public static HashMap<String, String> Orids = new HashMap<String, String>();

	
	/*
	 * @Then("^Click on create organisation button$") public void
	 * click_on_create_organisation_button() { org = new Organization();
	 * org.clickCreateOrganisation(); org.selectOrgType(); }
	 * 
	 * @Then("^User enter mandatory fields$") public void
	 * user_enter_mandatory_fields() {
	 * 
	 * }
	 * 
	 * @Then("^User click on create organisation button$") public void
	 * user_click_on_create_organisation_button() {
	 * 
	 * }
	 */
		
	@Then("Click on create organisation button")
	public void click_on_create_organisation_button() 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		orgHome.clickCreateOrganisation();
		newOrg = new NewOrganization();
		newOrg.selectOrgType("CTC");
	}
	@Then("select the product type {string}")
	public void select_the_product_type(String type) 
	{
		newOrg.selectProductType(type);
	}
	
	
	
	@Then("Create or get Existing OrId {string}")
	public void create_or_get_existing_ID(String orId) throws InterruptedException 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	

		if(orgHome.checkifOrgid(orId))
		{
			TestBase.prop.setProperty("orgName", orgHome.getOrgid(orId));
			name=TestBase.prop.getProperty("orgName");
			System.out.println("organisation name is from property " + TestBase.prop.getProperty("orgName"));
				
		}
		else	
		{
			
			click_on_create_organisation_button();
			user_enter_mandatory_fields();
			user_add_another_level(3);
			user_add_the_salesforce_id();
			try {
				if(orId.contains("Child"))
					newOrg.selectParentOrganisation(ScromSteps.parentOrg);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			user_click_on_create_organisation_button();
			orgHome.createOrid(orId, name);
			Orids.put(orId,name);
			name=TestBase.prop.getProperty("orgName");
			System.out.println("organisation name is from property " + TestBase.prop.getProperty("orgName"));
		
		}
	}
	
	

	@Then("save the organization name in file {string}")
	public void save_the_organization_name_in_file(String orgType) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		orgHome.createOrid(orgType, name);
	}

	
	@Then("Create or get Existing OrId {string} level {int}")
	public void create_or_get_existing_ID_level(String orId,int i) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	

		if(orgHome.checkifOrgid(orId+i))
		{
			TestBase.prop.setProperty("orgName", orgHome.getOrgid(orId+i));
			name=TestBase.prop.getProperty("orgName");
			System.out.println("organisation name is from property " + TestBase.prop.getProperty("orgName"));
				
		}
		else	
		{
			click_on_create_organisation_button();
			user_enter_mandatory_fields();
			
			newOrg.addLevel(i);
			user_click_on_create_organisation_button();
			orgHome.createOrid(orId+i, name);
			Orids.put(orId+i,name);
			TestBase.prop.setProperty("orgName", name);
			System.out.println("organisation name is from property " + TestBase.prop.getProperty("orgName"));

		}
	}
	@Then("Create or get Existing OrId LMS {string} level {int}")
	public void create_or_get_existingID_lms(String orId,int i) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	
		
		if(orgHome.checkifOrgid(orId+i))
		{
			TestBase.prop.setProperty("orgName", orgHome.getOrgid(orId+i));
			System.out.println("organisation name is from property " + TestBase.prop.getProperty("orgName"));
				
		}
		else	
		{
			newOrg = new NewOrganization();
			
			click_on_create_organisation_button();
			newOrg.selectOrgType("LMS");
			
			user_enter_mandatory_fields_for_LMS();
			newOrg.addLevel(i);
			user_click_on_create_organisation_button();
			orgHome.createOrid(orId+i, name);
			Orids.put(orId+i,name);
			TestBase.prop.setProperty("orgName", name);
			System.out.println("organisation name is from property " + TestBase.prop.getProperty("orgName"));

		}
		
	}
	@Then("get organization name from file {string}")
	public void get_organization_name_from_file(String orgType) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		if(newOrg == null)
			newOrg = new NewOrganization();
		TestBase.prop.setProperty("orgName",  orgHome.getOrgid(orgType));
	}
	
	@Then("Create or get Existing OrId LMS {string}")
	public void create_or_get_existing_ID_lms(String orId) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	
		
		if(orgHome.checkifOrgid(orId))
		{
			TestBase.prop.setProperty("orgName", orgHome.getOrgid(orId));
			System.out.println("organisation name is from property " + TestBase.prop.getProperty("orgName"));
				
		}
		else	
		{
			newOrg = new NewOrganization();
			
			click_on_create_organisation_button();
			newOrg.selectOrgType("LMS");
			
			user_enter_mandatory_fields_for_LMS();
			newOrg.addLevel(3);
			user_click_on_create_organisation_button();
			orgHome.createOrid(orId, name);
			Orids.put(orId,name);
			TestBase.prop.setProperty("orgName", name);
			System.out.println("organisation name is from property " + TestBase.prop.getProperty("orgName"));

		}
	}
	
	@Then("User enter mandatory fields with customize name {string} for LMS")
	public void user_enter_mandatory_fields_with_customize_name_lms(String orgName) 
	{
		newOrg.selectOrgType("LMS");
		name = newOrg.entercustomizeOrgName(orgName);
		newOrg.selectProductType("RQI");
		newOrg.contactCustomPersonDetail("Ansh", "G", "1234567890");
		newOrg.companyDetails("187 s washington st", "Tiffin", "Ohio", "44883");
		newOrg.enterCustomSubDomain();
		newOrg.selectLang();
		newOrg.selectTimeZone();
		newOrg.enterCustomAdminDetails("Ansh", "G");
		newOrg.addLMSInformation(name.replace(orgName, ""));
		newOrg.selectHierarchy();
	}

	@Then("user add the salesforce id")
	public void user_add_the_salesforce_id() 
	{
	    if(newOrg == null)
	    	newOrg = new NewOrganization();
	    newOrg.addSalesforceId();
	}
	
	@Then("Create or get Existing OrId LMS {string} Self Register")
	public void create_or_get_existing_selfRe_lms(String orId) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	
		
		if(orgHome.checkifOrgid(orId))
		{
			TestBase.prop.setProperty("orgName", orgHome.getOrgid(orId));
			System.out.println("organisation name is from property " + TestBase.prop.getProperty("orgName"));
				
		}
		else	
		{
			newOrg = new NewOrganization();
			
			click_on_create_organisation_button();
			newOrg.selectOrgType("LMS");
			
			user_enter_mandatory_fields_for_LMS();
			 newOrg.clickSelfRegister();
			user_click_on_create_organisation_button();
			orgHome.createOrid(orId, name);
			Orids.put(orId,name);
			TestBase.prop.setProperty("orgName", name);
			System.out.println("organisation name is from property " + TestBase.prop.getProperty("orgName"));

		}
	}
	@Then("Click on create organisation button LMS")
	public void click_on_create_organisation_button_lms() 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		orgHome.clickCreateOrganisation();
		newOrg = new NewOrganization();
		newOrg.selectOrgType("LMS");
	}
	@Then("user add the duplicate salesforce id")
	public void user_add_the_duplicate_salesforce_id() 
	{
	    if(newOrg == null)
	    	newOrg = new NewOrganization();
	    newOrg.addDuplicateSalesforceId();
	}
	@Then("User enter mandatory fields")
	public void user_enter_mandatory_fields()
	{
		User usr=new User();
		
		name = newOrg.enterOrgName("CTC");
		newOrg.selectProductType("RQI");
		newOrg.contactPersonDetail("Ansh", "G", name, "1234567890");
		
		newOrg.companyDetails("187 s washington st", "Tiffin", "Ohio", "44883");
		newOrg.enterSubDomain(name);
		usr.pageLoad();
		newOrg.selectLang();
		usr.pageLoad();
		newOrg.selectTimeZone();
		newOrg.enterAdminDetails("Ansh", "G", name);
		newOrg.selectHierarchy();
	}
	
	@Then("User enter mandatory fields for org type {string} with level {int}")
	public void user_enter_mandatory_fields_for_org_type(String orgType, int level) 
	{
		newOrg = new NewOrganization();
		newOrg.selectOrgType(orgType);
		name = newOrg.enterOrgName(orgType);
		newOrg.selectProductType("RQI");
		newOrg.contactPersonDetail("Ansh", "G", name,"1234567890");
		newOrg.companyDetails("187 s washington st", "Tiffin", "Ohio", "44883");
		newOrg.enterSubDomain(name);
		newOrg.selectLang();
		newOrg.selectTimeZone();
		newOrg.enterAdminDetails("Ansh", "G", name);
		newOrg.selectHierarchyWithLevel(level);
		newOrg.turnOffNotification();
		if(orgType.equalsIgnoreCase("lms"))
			newOrg.addLMSInformation(name);		
	}

	@Then("delete the unit admin")
	public void delete_the_unit_admin()
	{
	orgSet.checkRowAvailable();
	orgSet.deleteUnitAdmin();
	orgHome.validateSucessMesssage();
	}

	@Then("delete the unit observer")
	public void delete_the_uit_observer()
	{
	orgSet.checkRowAvailable();
	orgSet.deleteUnitObserver();
	orgHome.validateSucessMesssage();
	}
	@Then("User enter mandatory fields for LMS")
	public void user_enter_mandatory_fields_for_LMS()
	{
		name = newOrg.enterOrgName("LMS");
		newOrg.selectProductType("RQI");
		newOrg.contactPersonDetail("Ansh", "G", name, "1234567890");
		newOrg.companyDetails("187 s washington st", "Tiffin", "Ohio", "44883");
		newOrg.enterSubDomain(name);
		newOrg.selectLang();
		newOrg.selectTimeZone();
		newOrg.enterAdminDetails("Ansh", "G", name);
		newOrg.addLMSInformation(name);
		newOrg.selectHierarchy();
	}
//	newOrg.selectLang();
//Elearning
	
	@Then("Create or get Existing OrId LMS {string} with product type {string}")
	public void create_or_get_existing_ID_lms(String orId,String product) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	
		
		if(orgHome.checkifOrgid(orId))
		{
			TestBase.prop.setProperty("orgName", orgHome.getOrgid(orId));
			System.out.println("organisation name is from property " + TestBase.prop.getProperty("orgName"));
				
		}
		else	
		{
			newOrg = new NewOrganization();
			
			click_on_create_organisation_button();
			newOrg.selectOrgType("LMS");
			
			name = newOrg.enterOrgName("LMS");
			newOrg.selectProductType(product.split(","));
			newOrg.contactPersonDetail("Ansh", "G", name, "1234567890");
			newOrg.companyDetails("187 s washington st", "Tiffin", "Ohio", "44883");
			newOrg.enterSubDomain(name);
			newOrg.selectLang();
			newOrg.selectTimeZone();
			newOrg.enterAdminDetails("Ansh", "G", name);
			newOrg.addLMSInformation(name);
			newOrg.selectHierarchy();
		
			user_click_on_create_organisation_button();
			orgHome.createOrid(orId, name);
			Orids.put(orId,name);
		}
	}
	
	@Then("Create or get Existing OrId LMS {string} Child org")
	public void create_or_get_existing__lms(String orId) throws InterruptedException 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	
		
		if(orgHome.checkifOrgid(orId))
		{
			TestBase.prop.setProperty("orgName", orgHome.getOrgid(orId));
			System.out.println("organisation name is from property " + TestBase.prop.getProperty("orgName"));
				
		}
		else	
		{
			newOrg = new NewOrganization();
			
			click_on_create_organisation_button();
			newOrg.selectOrgType("LMS");

			name = newOrg.enterOrgName("LMS");
			newOrg.selectProductType("RQI");
			newOrg.contactPersonDetail("Ansh", "G", name, "1234567890");
			newOrg.companyDetails("187 s washington st", "Tiffin", "Ohio", "44883");
			newOrg.enterSubDomain(name);
			newOrg.selectLang();
			newOrg.selectTimeZone();
			newOrg.enterAdminDetails("Ansh", "G", name);
			newOrg.addLMSInformation(name);
			newOrg.selectHierarchy();
		
			newOrg.selectParentOrganisation(ScromSteps.parentOrg);
			user_click_on_create_organisation_button();
			orgHome.createOrid(orId, name);
			Orids.put(orId,name);
			TestBase.prop.setProperty("orgName", name);
			System.out.println("organisation name is from property " + TestBase.prop.getProperty("orgName"));

		}
	}
	
	@Then("save detail in the file {string}")
	public void get_organization_ame_from_file(String orgType) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		switch(orgType)
		{
		case "subdomain": TestBase.	testUtils. saveDetailsinFile("subdomain",OrganizationDetails.subDomain);
		break;
		case "subdomainLMS": TestBase.	testUtils. saveDetailsinFile("subdomainLMS",OrganizationDetails.subDomain);
		break;
		
		case "unitAdminEmail": TestBase.	testUtils. saveDetailsinFile("unitAdminEmail",User.userEmail);	
		break;
		case "unitAdminPassword": TestBase.	testUtils. saveDetailsinFile("unitAdminPassword",KeyClock.pwd);	
		break;
		
		case "unitObserverEmail": TestBase.	testUtils. saveDetailsinFile("unitObserverEmail",User.userEmail);	
		break;
		case "unitObserverPassword": TestBase.	testUtils. saveDetailsinFile("unitObserverPassword",KeyClock.pwd);	
		break;
		
		case "unitAdminLMSEmail": TestBase.	testUtils. saveDetailsinFile("unitAdminLMSEmail",User.userEmail);	
		break;
		case "unitAdminLMSPassword": TestBase.	testUtils. saveDetailsinFile("unitAdminLMSPassword",KeyClock.pwd);	
		break;
		
		case "unitObserverLMSEmail": TestBase.	testUtils. saveDetailsinFile("unitObserverLMSEmail",User.userEmail);	
		break;
		case "unitObserverLMSPassword": TestBase.	testUtils. saveDetailsinFile("unitObserverLMSPassword",KeyClock.pwd);	
		break;
		case "unitNameCTC": TestBase.	testUtils. saveDetailsinFile("unitNameCTC",  OrganizationSettings.	newUnitName );
		
		break;
		case "unitNameLMS": TestBase.	testUtils. saveDetailsinFile("unitNameLMS",  OrganizationSettings.	newUnitName );	
		break;
		}
	
	}
	@Then("Create or get Existing OrId {string} with product type {string}")
	public void create_or_get_existing_ID(String orId,String product) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	

		if(orgHome.checkifOrgid(orId))
		{
			TestBase.prop.setProperty("orgName", orgHome.getOrgid(orId));
			name=TestBase.prop.getProperty("orgName");
			System.out.println("organisation name is from property " + TestBase.prop.getProperty("orgName"));
				
		}
		else	
		{
			click_on_create_organisation_button();
			name = newOrg.enterOrgName("CTC");
			newOrg.selectProductType(product.split(","));
			newOrg.contactPersonDetail("Ansh", "G", name, "1234567890");
			newOrg.companyDetails("187 s washington st", "Tiffin", "Ohio", "44883");
			newOrg.enterSubDomain(name);
			newOrg.selectLang();
			newOrg.selectTimeZone();
			newOrg.enterAdminDetails("Ansh", "G", name);
//			newOrg.addLMSInformation(name);
			newOrg.selectHierarchy();
		
			user_click_on_create_organisation_button();
			orgHome.createOrid(orId, name);
			Orids.put(orId,name);
			TestBase.prop.setProperty("orgName", name);
			System.out.println("organisation name is from property " + TestBase.prop.getProperty("orgName"));

		}
	}
	
	
	
	
	
	@Then("User click on create organisation button")
	public void user_click_on_create_organisation_button() 
	{
		newOrg.clickToCreate();
		TestBase.prop.setProperty("orgName", name);
		System.out.println("organisation name is from property " + TestBase.prop.getProperty("orgName"));
		orgHome.validateSucessMesssage();
		
	}
	@Then("User click on create organisation button and validate message {string}")
	public void user_click_on_create_organisation_button(String msg) 
	{
		newOrg.clickToCreate();
		TestBase.prop.setProperty("orgName", name);
		System.out.println("organisation name is from property " + TestBase.prop.getProperty("orgName"));
		orgHome.validateSucessMesssage(msg);
		
	}
	
	
	@Then("check on the elearning within products and Turn off the email notification")
	public void check_on_the_elearning_within_products_and_turn_off_the_email_notification() throws Exception {
		orgDetails = new OrganizationDetails();
		newOrg = new NewOrganization();
		
		if(newOrg.checkElearning())
		{
			orgDetails.clickEditOrganization();
			orgDetails.turnOffNotification();
			orgDetails.clickUpdateOrganization();
			orgHome.validateSucessMesssage();

		}
		else
		{
		orgDetails.clickEditOrganization();
//		newOrg.selectProductType("RQI");
	    newOrg.selectProductType("Elearning");
		orgDetails.turnOffNotification();
		orgDetails.clickUpdateOrganization();
		orgHome.validateSucessMesssage();
		}
	}

	@Then("search and verify the organisation by name")
	public void search_and_verify_the_organisation_by_name() 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		
		orgHome.searchOrgByName();
	}

	@Then("clear the search result")
	public void clear_the_search_result() 
	{
		orgHome.clearOrgSearch();
		orgHome.checkfieldareBlank();
	}
	
	@Then("check if field are blank")
	public void checkif_Field_Are_blank() 
	{
		orgHome.checkfieldareBlank();
	}
	
	@Then("search and verify the organisation by id")
	public void search_and_verify_the_organisation_by_id()
	{
		orgHome.searchOrgByID();
	}

	@Then("apply the search filter")
	public void apply_the_search_filter() 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		orgHome.seachOrgByTypeCTC();
	}
	
	@Then("navigate to organization detail page")
	public void navigate_to_organization_detail_page()
	{
		
		if(orgHome == null)
			orgHome = new OrganizationHome();
		orgHome.openOrgDetails();
		
		
	}
	
	@Then("edit and disable the self register the user")
	public void edit_and_disable_the_self_register_the_user() throws Exception
	{
		orgDetails = new OrganizationDetails();
		orgDetails.clickEditOrganization();
		orgDetails.disableSelfRegister();
		orgDetails.clickUpdateOrganization();
		orgHome.validateSucessMesssage();
	}
	
	@Then("user get the salesforceId")
    public void user_get_the_salesforceId()
    {
        if(orgDetails == null)
            orgDetails = new OrganizationDetails();
        orgDetails.getSalesforceId();
    }
	@Then("edit and verify the organization details")
	public void edit_and_verify_the_organization_details() throws Exception
	{
		orgDetails = new OrganizationDetails();
		orgDetails.getOrgDetails();
		orgDetails.clickEditOrganization();
		orgDetails.updateDetails();
		orgDetails.clickUpdateOrganization();
		orgHome.validateSucessMesssage();
		TestBase.prop.setProperty("orgName", name+"_update");
//		orgHome.createOrid("Assignment", name+"_update");

	}
	@Then("edit and verify the organization details and validate message {string}")
	public void edit_and_verify_the_organization_details(String msg) throws Exception
	{
		orgDetails = new OrganizationDetails();
		orgDetails.getOrgDetails();
		orgDetails.clickEditOrganization();
		orgDetails.updateDetails();
		orgDetails.clickUpdateOrganization();
		TestBase.prop.setProperty("orgName", name+"_update");
		name = name+"_update";
		orgHome.validateSucessMesssage(msg);
//		orgHome.createOrid("Assignment", name+"_update");

	}
	@Then("Add language {string}")
	public void validateif(String lag) throws Exception
	{
		orgDetails = new OrganizationDetails();
		orgDetails.validatelanguage(lag);
//		orgDetails.clickUpdateOrganization();
//		orgDetails.getOrgDetails();
//		
		
	}
	
	@Then("Self Registration {string}")
	public void SelfRegistration(String SelfReg) throws Exception
	{
		orgDetails = new OrganizationDetails();
		orgDetails.validateSelfRegistration(SelfReg);
		
		//*[@id="customerform"]/div[4]/span
//		orgDetails.clickUpdateOrganization();
//		orgDetails.getOrgDetails();
//		
		
	}
	
	@Then("Self Registration {string} and set email as optional")
	public void SelfRegistrations(String SelfReg) throws Exception
	{
		orgDetails = new OrganizationDetails();
		orgDetails.validateSelfRegistrationoptional(SelfReg);
		
		//*[@id="customerform"]/div[4]/span
//		orgDetails.clickUpdateOrganization();
//		orgDetails.getOrgDetails();
//		
		
	}
	
	
	
	@Then("Select Classification {string}")
	public void selectClassification(String classifi) throws Exception
	{
		orgDetails = new OrganizationDetails();
		orgDetails.validateClassification(classifi);
		
		//*[@id="customerform"]/div[4]/span
//		orgDetails.clickUpdateOrganization();
//		orgDetails.getOrgDetails();
//		
		
	}
	@Then("Validate if language is not changed {string}")
	public void validateiflanguageisnotchanged(String lag) throws Exception
	{
		orgDetails.getOrgDetails();
		orgDetails = new OrganizationDetails();
		orgDetails.checklanguage(lag);
//		orgDetails.getOrgDetails();
		
	}
	@Then("click on edit organization details")
	public void edit_the_organization_details() throws Exception
	{
		orgDetails = new OrganizationDetails();
		orgDetails.getOrgDetails();
		orgDetails.clickEditOrganization();
	}
	
	@Then("Turn off the email notification")
	public void turn_off_the_email_notification() throws Exception 
	{
		orgDetails = new OrganizationDetails();
		orgDetails.clickEditOrganization();
		orgDetails.turnOffNotification();
		orgDetails.clickUpdateOrganization();
		orgHome.validateSucessMesssage();
	}
	@Then("change Federal org to no")
	public void turn_Federal_off_the_email_notification() throws Exception 
	{
		orgDetails = new OrganizationDetails();
		orgDetails.clickEditOrganization();
		orgDetails.turnOffFederal();
		orgDetails.clickUpdateOrganization();
		orgHome.validateSucessMesssage();
	}
	@Then("change Federal org to yes")
	public void turn_Federal_yes_the_email_notification() throws Exception 
	{
		orgDetails = new OrganizationDetails();
		orgDetails.clickEditOrganization();
		orgDetails.turnyesFederal();
		orgDetails.clickUpdateOrganization();
		orgHome.validateSucessMesssage();
	}
	@Then("Turn on the email notification")
	public void turn_on_the_email_notification() throws Exception 
	{
		orgDetails = new OrganizationDetails();
		orgDetails.clickEditOrganization();
		orgDetails.turnONNotification();
		orgDetails.clickUpdateOrganization();
		orgHome.validateSucessMesssage();
	}
	@Then("Updated LMS url with moodle url")
	public void updated_LMS_url_with_Moodleurl() throws Exception 
	{
		orgDetails = new OrganizationDetails();
		orgDetails.clickEditOrganization();
		
//		orgDetails.u
		orgDetails.selecturl();
		orgDetails.clickUpdateOrganization();
		
	}
	
	@Then("Select LMS url with moodle url")
	public void updated_url_with_Moodleurl() throws Exception 
	{
		orgDetails = new OrganizationDetails();
		
//		orgDetails.u
		orgDetails.selecturl();
		
	}
	
	@Then("perform block and unblock organisation")
	public void perform_block_and_unblock_organisation() 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		orgHome.blockOrganization("test");
		orgHome.UnblockOrganization("test");
	}
	
	@Then("perform block organisation and validate message {string}")
	public void perform_block_organisation(String msg) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		orgHome.blockOrganization("test",msg);
	
	}
	
	@Then("perform unblock organisation and validate message {string}")
	public void perform_unblock_organisation(String msg) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		orgHome.UnblockOrganization("test");
	}
	@Then("perform delete organisation and validate message {string}")
	public void perform_delete_organisation(String msg) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		orgHome.deleteOrganization(msg);
		
	}
	

	@Then("click on access organization")
	public void click_on_access_organization() 
	{
		if(orgHome == null)
		{
			orgHome = new OrganizationHome();
		}
		orgID = orgHome.clickAccessOrganisation();
	}
	
	@Then("validate the access page is dispalyed")
	public void validate_the_access_page_is_dispalyed()
	{
		organAccess = new OrganizationAccess();
	    organAccess.validateOrgID(orgID);
	}

	@Then("Navigate to organisation settings")
	public void navigate_to_organisation_settings() 
	{
	    organAccess.navigateOrgSetting();
	}
	

	
@Then("Validate the Tab {string} is {string} in organisation settings")
public void navigate_to_add_group_popup(String drop,String status) 
{
	
	for(int i=0;i<drop.split(",").length;i++)
		organAccess.validateTabs(drop.split(",")[i],status);
}

@Then("Validate the Organisation Hierarchy {string} is {string} in organisation settings")
public void navigate_to_OrganisationHierarchy(String drop,String status) 
{
	
	for(int i=0;i<drop.split(",").length;i++)
		organAccess.validateOrganisationHierarchy(drop.split(",")[i],status);
}

@Then("Validate the Units {string} is {string} in organisation settings")
public void navigate_to_Units(String drop,String status) throws InterruptedException 
{
	
	for(int i=0;i<drop.split(",").length;i++)
		organAccess.validateUnit(drop.split(",")[i],status);
}


@Then("Validate if duplicate Units {string} are not create")
public void navigate_if_duplicate_Units(String drop) throws InterruptedException 
{
	
	for(int i=0;i<drop.split(",").length;i++)
		organAccess.validateifduplicateUnit(drop.split(",")[i]);
}

//*[contains(@id,"tablelisting")]//td
//div[@class="organization-tab-content"]//a
	@Then("get organisation url")
	public void get_organisation_url() 
	{
		organizationURl=TestBase.driver.getCurrentUrl();
		
	}
	
	@Then("Navigate organisation url")
	public void navigate_organisation_url() 
	{
		
		TestBase.driver.navigate().to(organizationURl);
		
	}
	

	@Then("Validate Hierarchy {string}")
	public void navigate_to_organisation_settings_validateHierarchy(String level) 
	{
	    organAccess.validateHierarchy(level);
	}
	
	

	@Then("Validate Hierarchy {string} in unit")
	public void navigate_to_organisationsettings_validateHierarchy(String level) 
	{
	    organAccess.validateHierarchyinunit(level);
	}
	

	@Then("click on Group tab")
	public void click_on_group_tab() 
	{
		orgSet = new OrganizationSettings();
	    orgSet.navigateGroup();
	}
	
	@Then("User create the group")
	public void user_create_the_group() 
	{
		orgSet.clickOnCreateGroup();
	    orgSet.enterGroupDetails();
	    orgSet.clickOnCreate();
	    orgHome.validateSucessMesssage();
	}
	
	@Then("User create the group and validate message {string}")
	public void user_create_the_group(String msg) 
	{
		orgSet.clickOnCreateGroup();
	    orgSet.enterGroupDetails();
	    orgSet.clickOnCreate();
	    orgHome.validateSucessMesssage(msg);
	}
	
	@Then("User search the group")
	public void user_search_the_group() 
	{
	    orgSet.searchGroupName();
	    orgSet.validateSearchResult();
	}
	
	@Then("User edit the group")
	public void user_edit_the_group() 
	{
	    orgSet.clickOnEditGroup();
	    orgSet.enterUpdatedGroupDetails();
	    orgSet.clickOnCreate();
	    orgHome.validateSucessMesssage();
	}
	@Then("User edit the group and validate message {string}")
	public void user_edit_the_group(String msg) 
	{
	    orgSet.clickOnEditGroup();
	    orgSet.enterUpdatedGroupDetails();
	    orgSet.clickOnCreate();
	    orgHome.validateSucessMesssage(msg);
	}
	@Then("view the group")
	public void view_the_group() 
	{
	    orgSet.clickOnViewGroup();
	    orgSet.validateGroup();
	  
	}
	
	@Then("validate if user is added in the group {string}")
	public void view_the_groupgr(String name) 
	{
//	    orgSet.clickOnViewGroup();
	    orgSet.validateUserGroup(name);
	  
	}
	
	@Then("validate if user is removed {string}")
	public void view_the_groupgre(String name) 
	{
//	    orgSet.clickOnViewGroup();
	    orgSet.validateUsernorecord(name);
	  
	}
	
	
	

	
	@Then("view the job")
	public void view_the_job() 
	{
	    orgSet.clickOnViewJob();
	    orgSet.validateJob();
	  
	}

	@Then("Add User to group")
	public void Adduser_edit_the_group() 
	{
	    orgSet.clickOnEditGroup();
	    orgSet.addusergroup(User.userEmail);
	    orgSet.clickOnCreate();
	    orgHome.validateSucessMesssage();
	}
	
	@Then("Remove User to group")
	public void Removeuser_edit_the_group() 
	{
	    orgSet.clickOnEditGroup();
	    orgSet.removeusergroup();
	    orgSet.clickOnCreate();
	    orgHome.validateSucessMesssage();
	}
	
	@Then("validate the count {string}")
	public void Removeuser_edit_the_group(String count) 
	{
	    orgSet.validatetheuser(count);
	   
	}
	
	
	
	@Then("user logout from organization")
	public void user_logout_from_organization() 
	{
		if(organAccess == null)
		{
			organAccess = new OrganizationAccess();
		}
	    organAccess.logout();
	}

	
	
	@Then("click on Title tab")
	public void click_on_title_tab() 
	{
		orgSet = new OrganizationSettings();
	    orgSet.navigateTitle();
	}
	
	@Then("click on Notifications tab")
	public void click_on_notifications_tab() 
	{
		orgSet = new OrganizationSettings();
	    orgSet.navigateNotifications();
	}
	@Then("Check Notification btn are disable")
	public void checl_notifications_disable() 
	{
		orgSet = new OrganizationSettings();
	    orgSet.Checkbuttonaredisable();
	}
	
	
	@Then("User create the Title")
	public void user_create_the_title() 
	{
		orgSet.clickOnCreateTitle();
	    orgSet.enterTitleDetails();
	    orgSet.clickOnCreateButton();
	    orgHome.validateSucessMesssage();
	}
	
	
	
	@Then("User create the Title and validate message {string}")
	public void user_create_the_title(String msg) 
	{
		orgSet.clickOnCreateTitle();
	    orgSet.enterTitleDetails();
	    orgSet.clickOnCreateButton();
	    orgHome.validateSucessMesssage(msg);
	}
	@Then("Not available create the Title")
	public void usercreate_the_title() 
	{
		orgSet.clickOnshouldnotavailableCreateTitle();
	   
	}
	@Then("User search the Title")
	public void user_search_the_title() 
	{
		orgSet.searchTitleName();
	    orgSet.validateSearchTitleResult();
	}
	
	@Then("check if duplicates are not created")
	public void check_if_duplicatesarenotcreated() 
	{
		orgSet.searchTitleName();
	    orgSet.validateifduplicateisnotcreated();
	}
	
	
	
	@Then("User edit the Title")
	public void user_edit_the_title() 
	{
		orgSet.clickOnEditTitle();
	    orgSet.enterUpdatedTitleDetails();
	    orgSet.clickOnSaveButton();
	    orgHome.validateSucessMesssage();
	}

	@Then("User edit the Title and validate message {string}")
	public void user_edit_the_title(String msg) 
	{
		orgSet.clickOnEditTitle();
	    orgSet.enterUpdatedTitleDetails();
	    orgSet.clickOnSaveButton();
	    orgHome.validateSucessMesssage(msg);
	}

	@Then("user add another level {int}")
	public void user_add_another_level(int i) 
	{
	    newOrg.addLevel(i);
	}
	
	

	@Then("create Test unit")
	public void create_level_unit() 
	{
		orgSet = new OrganizationSettings();
	    orgSet.navigateLevel2();
	    orgSet.deletetestUnit();
	    orgSet.clickOnCreateLevelButton();
	    orgSet.enterLevelTestDetails("187 s washington st", "Tiffin", "United States", "Ohio", "44883");
	    orgSet.clickCreateUnit();
	    orgHome.validateSucessMesssage();
	}
	@Then("create level unit")
	public void create_levelunit() 
	{
		orgSet = new OrganizationSettings();
	    orgSet.navigateLevel2();
	    orgSet.deleteAutomatedUnit();
	    orgSet.clickOnCreateLevelButton();
	    orgSet.enterLevelDetails("187 s washington st", "Tiffin", "United States", "Ohio", "44883");
	    orgSet.clickCreateUnit();
	    orgHome.validateSucessMesssage();
	}
	@Then("create level unit and validate message {string}")
	public void create_levelunitmsg(String msg) 
	{
		orgSet = new OrganizationSettings();
	    orgSet.navigateLevel2();
	    orgSet.deleteAutomatedUnit();
	    orgSet.clickOnCreateLevelButton();
	    orgSet.enterLevelDetails("187 s washington st", "Tiffin", "United States", "Ohio", "44883");
	    orgSet.clickCreateUnit();
	    orgHome.validateSucessMesssage(msg);
	}
	@Then("Navigate to 4 level unit")
	public void create4_level_unit() 
	{
		orgSet = new OrganizationSettings();
	    orgSet.navigateLevel4();
	   
	}
	
	

	@Then("Set SFTP Import Settings as {string}")
	public void set_SFTP_Import_Setting(String option) 
	{
		orgSet = new OrganizationSettings();
	    orgSet.clickSFTPImportoption(option);
	   
	}
	
	@Then("validate if SFTP Import Settings option is disable {int}")
	public void set_SFTP_Import_Setting(int count) 
	{
		orgSet = new OrganizationSettings();
	    orgSet.validateifoptionareDisable(count);
	   
	}
	
	@Then("validate if SFTP Import Settings option is disable")
	public void set_SFTP_Import_Setting() 
	{
		orgSet = new OrganizationSettings();
	    orgSet.validateifoptionareDisable();
	   
	}
	@Then("Navigate to Demographic Settings")
	public void Navigate_to_Demographic_Settings() 
	{
		orgSet = new OrganizationSettings();
	    orgSet.navigateDemographicSettings();
	   
	}
	
	@Then("create level 3 unit level {string}")
	public void create_level_3_unit(String levelname) 
	{
		orgSet = new OrganizationSettings();
	    orgSet.navigateLevel3();
	    orgSet.deleteAutomatedUnit();
	    orgSet.clickOnCreateLevel3Button();
	    orgSet.addlevel(levelname);
	    orgSet.enterLevelDetails("187 s washington st", "Tiffin", "United States", "Ohio", "44883");
	    orgSet.clickCreateUnit();
	    orgHome.validateSucessMesssage();
	}
	
	@Then("create level 4 unit level {string}")
	public void create_level_4_unit(String levelname) 
	{
		orgSet = new OrganizationSettings();
	    orgSet.navigateLevel4();
	    orgSet.deleteAutomatedUnit();
	    orgSet.clickOnCreateLevel4Button();
	    orgSet.add_2_level(levelname);
	    orgSet.enterLevelDetails("187 s washington st", "Tiffin", "United States", "Ohio", "44883");
	    orgSet.clickCreateUnit();
	    orgHome.validateSucessMesssage();
	}
	@Then("create level 3 button disable")
	public void create_level_3_unit() 
	{
		orgSet = new OrganizationSettings();
		  
		orgSet.create_buttondisable();
	}
//	@Then("create level {int} unit")
//	public void create_level_unit(int level) 
//	{
//		orgSet = new OrganizationSettings();
//	    orgSet.multiUnitSetup(level,"187 s washington st", "Tiffin", "United States", "Ohio", "44883");
//	}
	@Then("delete level unit {string}")
	public void create_level_unit(String level) 
	{
		orgSet = new OrganizationSettings();
	    orgSet.navigateLevel2();
	    orgSet.deleteAutomatedUnit(level);
	 
	}
	
	@Then("delete level unit {string} and validate the message {string}")
	public void create_level_unitand_validate_the_message(String level,String msg) 
	{
		orgSet = new OrganizationSettings();
	    orgSet.navigateLevel2();
	    orgSet.deleteAutomatedUnit(level,msg);
	 
	}
	

	

	@Then("delete user of unit name {string}")
	public void create_levelunit(String level) 
	{
		orgSet = new OrganizationSettings();
	 
	    orgSet.deleteAutomated(level);
	 
	}
	
	
	@Then("Select {string} for Role {string} , Name {string}")
	public void selectforRoleName(String dropdown,String Role,String Name) 
	{
		orgSet = new OrganizationSettings();
	    orgSet.selectforRoleName(dropdown,Role,Name);
	}
	
	@Then("Navigate Level 2 unit")
	public void navigateLevel2() 
	{
		orgSet = new OrganizationSettings();
	    orgSet.navigateLevel2();
		
	}
	@Then("Navigate Level 3 unit")
	public void navigateLevel3() 
	{
		orgSet = new OrganizationSettings();
	    orgSet.navigateLevel3();
		
	}
	@Then("create level {int} unit")
	public void create_level_unit(int level) 
	{
		orgSet = new OrganizationSettings();
	    orgSet.multiUnitSetup(level,"187 s washington st", "Tiffin", "United States", "Ohio", "44883");
	}
	
//	@Then("create level {int} unit")
//	public void create_level_unit(int level) 
//	{
//		orgSet = new OrganizationSettings();
//	    orgSet.multiUnitSetup(level,"187 s washington st", "Tiffin", "United States", "Ohio", "44883");
//	}
	
	@Then("edit the unit")
	public void edit_the_unit() 
	{
	    orgSet.clickActionButton();
	    orgSet.clickEditButton();
	    orgSet.editUnitDetails();
	    orgSet.clickCreateUnit();
	    orgHome.validateSucessMesssage();
	}
	
	@Then("edit the unit details")
	public void edit_the_unitdetails() 
	{
		orgSet = new OrganizationSettings();
		 
	    orgSet.clickActionButton();
	    orgSet.clickEditButton();
	    orgSet.editUnitDetail();
	    orgSet.clickCreateUnit();
	    orgHome.validateSucessMesssage();
	}
	
	@Then("edit the unit details and validate message {string}")
	public void edit_the_unitdetails(String msg) 
	{
		orgSet = new OrganizationSettings();
		 
	    orgSet.clickActionButton();
	    orgSet.clickEditButton();
	    orgSet.editUnitDetail();
	    orgSet.clickCreateUnit();
	    orgHome.validateSucessMesssage(msg);
	}
	
	@Then("view unit details {string}")
	public void view_unit_details(String level) 
	{
		
		orgSet.viewAutomatedUnit(level);
	}
	
	@Then("view unit details from saved files {string}")
	public void view_unit_details_from_saved_files(String level) 
	{
		
		orgSet.viewAutomatedUnit(AssignmentReport.getParmeterAvailable(level+TestBase.prop.getProperty("environment")));
	}
	
	@Then("view unit details {string} and validate the edited details")
	public void view_unit_details(String level,DataTable table) 
	{
		 
	            
		orgSet.viewAutomatedUnit(level);
		for(int i=0;i<table.width();i++)
		orgSet.validateUnitDetails(table.column(i).get(1));
		
		
		
	}
	@Then("view unit details")
	public void view_unit_details() 
	{
		orgSet = new OrganizationSettings();
		orgSet.viewAutomatedUnit();
	}
	
	@Then("validate the detail in unit details {string}")
	public void validateThedetail(String detail) 
	{
		orgSet = new OrganizationSettings();
		orgSet.validateDetail(detail);
	}


	@Then("Validate  drop down Action option {string} is {string} in organisation settings")
	public void navigateto_add_group_popup(String drop,String status) 
	{
		
		
		for(int i=0;i<drop.split(",").length;i++)
			orgSet.viewAutomatedUnit(drop.split(",")[i],status);
	}

	@Then("add the already available learner as unit admin")
	public void add_the_already_available_learner_as_unit_admin() 
	{
	    orgSet.clickOnUnitAdminButton();
	    orgSet.searchAvailableUser(User.userEmail);
	    orgSet.selectAvailableUser();
	    orgSet.clickAddUnitAdmin();
	    orgSet.checkRowAvailable();
	    orgHome.validateSucessMesssage();
	}

	@Then("add the already added learner as unit admin")
	public void addthe_already_available_learner_as_unit_admin() 
	{
	    orgSet.clickOnUnitAdminButton();
	    orgSet.searchAvailableUser(User.userEmail);
	    orgSet.selectAvailableUser();
	    orgSet.clickAddUnitAdmin();
	}
	
	@Then("add the new learner as unit admin")
	public void add_the_new_learner_as_unit_admin() 
	{
		reuseableCode.waitforsec(4);
		orgSet.clickOnUnitAdminButton();
	    orgSet.addLearnerDetailsManually();
	    orgSet.clickAddUnitAdminManually();
	    orgSet.checkRowAvailable();
	    orgHome.validateSucessMesssage();
	}
	
//	@Then("add  unit admin")
//	public void add_the_new_learner_as_unit_admin() 
//	{
//	    orgSet.clickOnUnitAdminButton();
//	    orgSet.addLearnerDetailsManually();
//	    orgSet.clickAddUnitAdminManually();
//	    orgSet.checkRowAvailable();
//	    orgHome.validateSucessMesssage();
//	}
	
	@Then("add the already available learner as unit observer")
	public void add_the_already_available_learner_as_unit_observer() 
	{
	    orgSet.clickOnUnitObserverButton();
	    orgSet.searchAvailableUser(User.userEmail);
	    
	    
	    		
	    orgSet.selectAvailableUser();
	    orgSet.clickAddUnitAdmin();
	    orgSet.checkRowAvailable();
	    orgHome.validateSucessMesssage();
	}
	

	@Then("add the inactive learner as unit observer should get 'No matching Users!' error")
	public void add_the_already_inactiveavailable_learner_as_unit_observer() 
	{
	    orgSet.clickOnUnitObserverButton();
	    orgSet.searchAvailableUser(User.userEmail);
	    
			
	    orgSet.noUserFound();
	 
	}
	

	@Then("add the inactive learner as unit Admin should get 'No matching Users!' error")
	public void add_the_already_inactiveavailable_learner_as_unit_admin() 
	{

	    orgSet.clickOnUnitAdminButton();
	    orgSet.searchAvailableUser(User.userEmail);
	    
	    orgSet.noUserFound();
	 
	}
	
	@Then("add the already available learner as unit observer {string}")
	public void add_the_already_available_learner_as_unit_observer(String email) 
	{
	    orgSet.clickOnUnitObserverButton();
	    orgSet.searchAvailableUser(email);
	    User.userEmail=email;
	    orgSet.selectAvailableUser();
	    orgSet.clickAddUnitAdmin();
	    orgSet.checkRowAvailable();
	    orgHome.validateSucessMesssage();
	}
	@Then("add the already available learner as unit admin {string}")
	public void add_the_already_available_learner_as_unit_admin(String email) 
	{
		   User.userEmail=email;
	    orgSet.clickOnUnitAdminButton();
	    orgSet.searchAvailableUser(User.userEmail);
	    orgSet.selectAvailableUser();
	    orgSet.clickAddUnitAdmin();
	    orgSet.checkRowAvailable();
	    orgHome.validateSucessMesssage();
	}

	@Then("add the new learner as unit observer")
	public void add_the_new_learner_as_unit_observer() 
	{
		reuseableCode.waitforsec(4);
	    orgSet.clickOnUnitObserverButton();
	    orgSet.addLearnerDetailsManually();
	    orgSet.clickAddUnitObserverManually();
	    orgSet.checkRowAvailable();
	    orgHome.validateSucessMesssage();
	}
	@Then("add the already added learner as unit observer")
	public void add_the_already_learner_as_unit_observer() 
	{
	    orgSet.clickOnUnitObserverButton();
	    orgSet.addalreadyLearnerDetailsManually();
	    orgSet.clickAddUnitObserverManually();
	    
	}
	@Then("add the already added learner as unit admin- Add Admin Manually")
	public void addthe_alread_available_learner_as_unit_admin() 
	{
	    orgSet.clickOnUnitAdminButton();
	    orgSet.addalreadyLearnerDetailsManually();
	    orgSet.clickAddUnitAdminManually();
	}
	
	
	@Then("delete the unit")
	public void delete_the_unit() 
	{
		orgSet.clickActionButton();
		orgSet.deleteUnit();
		orgHome.validateSucessMesssage();
	}

	@Then("download demographic report and verify")
	public void download_demographic_report_and_verify() 
	{
		comp = new Compliance();
		if(orgSet == null)
		{
			orgSet = new OrganizationSettings();
		}
		orgSet.navigateDemographicReport();
		orgSet.clickDownloadLink();
		comp.verifyDownloadFile();
	    
	}

	@Then("select the SFTP setting")
	public void select_the_SFTP_setting() 
	{
		if(orgHome == null)
		{
			orgHome = new OrganizationHome();
		}
		orgID = orgHome.clickSFTPSetting();
	}

	@Then("self register the user")
	public void self_register_the_user() 
	{
	    newOrg.clickSelfRegister();
	}

	@Then("Federal Organization select")
	public void selfregister_the_user() 
	{
	    newOrg.clickfederalyes();
	}

	@Then("user click on export csv and validate")
	public void user_click_on_export_csv_and_validate() 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	    orgHome.exportCSV();
	    orgHome.validateCSVFile();
	}
	
	@Then("user click on export excel and validate")
	public void user_click_on_export_excel_and_validate() 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	    orgHome.exportExcel();
	    orgHome.validateExcelFile();
	}
	
	@Then("validate if csv file downloaded {string}")
	public void user_click_on_export_excel_and_validate(String file) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	    orgHome.validateCSVFile(file);
	}
	
	@Then("navigate to HLC page")
	public void navigate_to_hlc_page() 
	{
	    if(orgHome == null)
	    	orgHome = new OrganizationHome();
	    orgHome.clickHLCMigration();
	}
	
	@Then("select the parent org")
	public void select_the_parent_org() throws InterruptedException 
	{
	    newOrg.selectParentOrganisation(ScromSteps.parentOrg);
	}

	@Then("Verify the Success Message {string}")
	public void verify_the_Sucess_Message(String msg) 
	{
		orgHome.successmsg(msg);
	}
	

	@Then("Verify the Error Msg {string}")
	public void verify_theSucess_Message(String msg) 
	{
		orgHome.errmsg(msg);
	}
	@Then("Verify the Error Message {string}")
	public void verify_the_Error_Message(String msg) 
	{
		orgHome.errormsg(msg);
	}

	@Then("search and verify the child organisation")
	public void search_and_verify_the_child_organisation() 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		orgHome.searchChildOrg(ScromSteps.childOrg);
	}

	@Then("search and verify the parent organisation")
	public void search_and_verify_the_parent_organisation() 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		orgHome.searchChildOrg(ScromSteps.parentOrg);
	}

	@Then("User enter invalid fields")
	public void user_enter_invalid_fields()
	{
		name = newOrg.enterOrgName("Not created");
		newOrg.selectProductType("RQI");
		newOrg.contactPersonDetail("Ansh", "G", name, "1234567890");
		newOrg.companyDetails("187 s washington st", "Tiffin", "Ohio", "44883");
		newOrg.selectLang();
		newOrg.enterAdminDetails("Ansh", "G", name);
		newOrg.selectHierarchy();
		newOrg.clickToCreate();
	}

	@Then("Click on Submit")
	public void click_on_submit()
	{
		orgSet = new OrganizationSettings();
		orgSet.clickTosubmit();
	}
	@Then("validate the error message")
	public void validate_the_error_message() 
	{
	    newOrg.validErrorMessageSubDomain();
	    newOrg.validErrorMessageTimeZone();
	}

	@Then("navigate to demographic template setting")
	public void navigate_to_demographic_template_setting() 
	{
	    dts = new DemographicTemplateSetting();
	    dts.clickDemographicSetting();
	}

	@Then("add the new column {string} {string} {string} {string}")
	public void add_the_new_column(String name, String type, String length, String validation) 
	{
		dts.deleterow();
	    dts.addNewColumn(name, type, length, validation);
	}

	@Then("remove the existing column")
	public void remove_the_existing_column() 
	{
		dts.deleterow();
//	    dts.addNewColumn(name, type, length, validation);
	}

	@Then("navigate to admin dashboard")
	public void navigate_to_admin_dashboard() 
	{
		login = new LoginPage();
	    login.user_navigate_dashboard();
	}

	@Then("switch the organization")
	public void switch_the_organization() 
	{
		OrganizationAccess orgAccess = new OrganizationAccess();
	    orgAccess.switchOrganisation();
	}

	@Then("User enter mandatory fields with customize name {string}")
	public void user_enter_mandatory_fields_with_customize_name(String orgName) 
	{
		name = newOrg.entercustomizeOrgName(orgName);
		newOrg.selectProductType("RQI");
		newOrg.contactCustomPersonDetail("Ansh", "G", "1234567890");
		newOrg.companyDetails("187 s washington st", "Tiffin", "Ohio", "44883");
		newOrg.enterCustomSubDomain();
		newOrg.selectLang();
		newOrg.selectTimeZone();
		newOrg.enterCustomAdminDetails("Ansh", "G");
		newOrg.selectHierarchy();
	}

	@Then("save the organization name in file")
	public void save_the_organization_name_in_file() 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		TestBase.prop.setProperty("orgName", name);
		orgHome.editOrgNameFile();
		orgHome.setOrgNameFromFile();
	}

	@Then("get organization name from file")
	public void get_organization_name_from_file() 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		orgHome.setOrgNameFromFile();
	}
	
	
	@Then("navigate to notification setting")
	public void navigate_to_notification_setting() 
	{
		if(orgSet == null)
			orgSet = new OrganizationSettings();
	    orgSet.navigateNotificationTab();
	}
	
	@Then("turn off the notification for field {string} and save")
	public void turn_off_the_notification_for_field_and_save(String field) 
	{
		if(orgSet == null)
			orgSet = new OrganizationSettings();
	    orgSet.turnOffNotification(field);
	    orgHome.validateSucessMesssage();
	}
	@Then("get the subdomain")
	public void get_the_subdomain() 
	{
		if(orgDetails == null)
			orgDetails = new OrganizationDetails();
		orgDetails.getSubdomainName();
	}
	@Then("get organization name from file for keyclock")
	public void get_organization_name_from_file_for_keyclock() 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		orgHome.setOrgNameFromFileKeyclock();
	}
	
	
	
	@Then("get LMS organization name from file for keyclock")
	public void get_lms_organization_name_from_file_for_keyclock() 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		orgHome.setLMSOrgNameFromFileKeyclock();
	}

	@Then("get Fed organization name from file for keyclock")
	public void get_fed_organization_name_from_file_for_keyclock() 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		orgHome.setFedOrgNameFromFileKeyclock();
	}
	
	
	
	@Then("get Fed LMS organization name from file for keyclock")
	public void get_fed_lms_organization_name_from_file_for_keyclock() 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		orgHome.setFedLMSOrgNameFromFileKeyclock();
	}

	
	@Then("search organization by name {string}")
	public void search_organization_by_name(String orgName) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		
		orgHome.searchOrganisation(orgName);
	}
	
	@Then("user check on the elearning within products and Turn off the email notification") 
	public void user_check_on_the_elearning_within_products_and_Turn_off_the_email_notification() throws Exception
	{
		orgDetails = new OrganizationDetails();
		orgHome =new OrganizationHome ();
		orgDetails.clickEditOrganization();
		orgDetails.ClickElearingChkbox();
		orgDetails.turnOffNotification();
		orgDetails.clickUpdateOrganization();
		orgHome.validateSucessMesssage();
	}
	@Then("Create multiple the Job Title {int}")
	public void user_create_the_title(int count) 
	{
		OrganizationSettings.jobTitle	= new String[count];
		for(int i=0;i<count;i++)
		{
		orgSet.clickOnCreateTitle();
	    orgSet.enterTitleDetails();
	    orgSet.clickOnCreateButton();
	    orgHome.validateSucessMesssage();
	    OrganizationSettings.jobTitle[i]=OrganizationSettings.titleName;
	    
		}
	}
	
	@Then("Create multiple group {int}")
	public void add_the_group(int count) 
	{
		OrganizationSettings.groupNames	= new String[count];
		for(int i=0;i<count;i++)
		{
	    orgSet = new OrganizationSettings();
	    orgSet.navigateGroup();
	    orgSet.clickOnCreateGroup();
	    orgSet.enterGroupDetails();
	    orgSet.clickOnCreate();
	    System.out.println(OrganizationSettings.groupName);
	    OrganizationSettings.groupNames[i]=OrganizationSettings.groupName;
		 
		}
		
	  
	 
	}
	
	@Then("add the Promote Existing Learner as unit observer")
	public void add_the_already_availablelearner_as_unit_observer() 
	{
	    orgSet.clickOnUnitObserverButton();
	    orgSet.searchAvailableUser(User.userEmail);
	    
	    
	    		
	    orgSet.selectAvailableUser();
	    orgSet.clickAddUnitAdmin();
//	    orgSet.checkRowAvailable();
//	    orgHome.validateSucessMesssage();
	}
	
	@Then("Click on Unit Observer Button")
	public void click_on_UnitObserverButton() 
	{
	 orgSet.clickOnUnitObserverButton();
	}
	
	@Then("Click on Unit Admin Button")
	public void click_on_UnitAdminButton() 
	{
	 orgSet.clickOnUnitAdminButton();
	}
	


    
	@Then("Click on Add Unit Observer")
	@Then("Click on Add Unit Admin")
	public void click_on_add_unit_admin() 
	{
	 orgSet.clickAddUnitAdmin();
	}
	@Then("validate if Add Unit Observer Disabled")
	@Then("validate if Add Unit Admin Disabled")
	public void click_on_add_unit_disabled() 
	{
	 orgSet.clickAddUnitAdmindisabled();
	}
	
	@Then("Click on Add Unit Admin Manually")
	public void click_on_add_unit_adminManually() 
	{
		  orgSet.clickAddUnitAdminManually();
		  
	}
	
	@Then("Click on Add Unit Observer Manually")
	public void click_on_add_unit_ObserverManually() 
	{
		  orgSet.clickAddUnitObserverManually();;
		  
	}
	
	@Then("validate if Add Unit Observer Manually Disabled")
	public void click_on_add_unit_ObserverManuallyDisabled() 
	{
		  orgSet.clickAddUnitObserverManuallydisabled();;
		  
	}
	
	@Then("validate if Add Unit Admin Manually Disabled")
	public void click_on_add_unit_Manuallydisabled() 
	{
	 orgSet.clickAddUnitAdminManuallydisabled();
	}
	
	@Then("Click on Manual Radio Button")
	public void add_Manually_Radio_Button() 
	{
	 orgSet.addManuallyRadioButton();
	}
	
	
	@Then("Validate error message in Add Unit Observer or Unit Admin screen {string}")
	public void add_Manually_Radio_Button(String msg) 
	{
	 orgSet.validateErrorMsg(msg);
	}
	
	@Then("Click on Cancel in Add unit admin or Observer")
	public void Click_on_Cancelinaddscreen() 
	{
	 orgSet.clickonCancel();
	}
	
	@Then("edit and self register the user")
	public void edit_and_self_register_the_user() throws Exception
	{
		orgDetails = new OrganizationDetails();
		orgDetails.clickEditOrganization();
		orgDetails.clickSelfRegister();
		orgDetails.clickUpdateOrganization();
		orgHome.validateSucessMesssage();
	}
	@Then("check {string} for Role {string}, Name {string} Exists")
	public void checkforRoleNameExists(String dropdown,String Role,String Name) {
		orgSet.checkforRoleNameExists(dropdown, Role, Name);
		
	//	orgHome.validateSucessMesssage();
	}
	

	@Then("navigate to MigrationLog page")
	public void navigate_to_MigrationLog_page() throws InterruptedException
	{
		 if(orgHome == null)
		    	orgHome = new OrganizationHome();
		 orgHome.clickHLCMigrationLog();
	}
	
	
	@Then("validate the Organization screen is displayed") 
	public void validate_the_Organization_screen_is_displayed()
	{
		orgHome= new OrganizationHome();
		orgHome.OrgScreen();
		
	}
	
	@Then("view Organization details and validate the edited details")
	public void view_Organization_details(DataTable table) 
	{
		 
	            
		for(int i=0;i<table.width();i++)
			orgHome.validateorgDetails(table.column(i).get(0),table.column(i).get(1));
			
		
	}
	
}
