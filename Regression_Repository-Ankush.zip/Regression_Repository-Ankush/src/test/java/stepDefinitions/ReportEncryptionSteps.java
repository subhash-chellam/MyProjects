package stepDefinitions;

import com.qa.pages.ReportEncryption;

import io.cucumber.java.en.Then;

public class ReportEncryptionSteps {

	ReportEncryption reportencryption = new ReportEncryption();
	
	@Then("Click on the SFTP Settings {string}")
	public void ClickonTheSFTPSettings(String value) {
		reportencryption.selectThevaluefromHeadContent(value);
	}
	
	
	@Then("Check Create SFTP Account Is Disabled {string}")
	public void checkCreateSFTPAccountIsDisabled(String value) {
		reportencryption.CheckCreateSFTPAccountIsDisabled(value);
	}
	
	
	
	
	
}
