package stepDefinitions;

import com.qa.pages.Compliance;
import com.qa.pages.Notification;
import com.qa.pages.ProgressReport;
import com.qa.pages.User;

import io.cucumber.java.en.Then;
public class NotificationSteps 
{
	Notification notif;
	Compliance comp;
	
	@Then("navigate to notification log report page")
	public void navigate_to_notification_log_report_page() 
	{
		comp = new Compliance();
		notif = new Notification();
	    comp.clickOnReportLink();
	    notif.selectNotificationReportLink();
	}
	
	@Then("verify the various fields are available")
	public void verify_the_various_fields_are_available() 
	{
	    notif.validateSearchFields();
	    notif.vaidateMoreFilterFields();
	    notif.vaidateCourseFilterFields();
	    notif.vaidateNotificationLogFields();
	    notif.validateExportButton();
	    notif.validateResendButton();
	}

	@Then("Verify the user search by name picking up from given rows {int}")
	public void verify_the_user_search_by_name(int number) 
	{
	    notif.getUserDetails(number);
	    notif.searchUserByName();
	}

	@Then("Verify the user search by user id picking up from given rows {int}")
	public void verify_the_user_search_by_user_id(int number) 
	{
		notif.getUserDetails(number);
		notif.searchUserByUserID();
	}
	
	@Then("Verify the user search by email id picking up from given rows {int}")
	public void verify_the_user_search_by_email_id(int number) 
	{
		notif.getUserDetails(number);
		notif.searchUserByEmail();
	}
	
	@Then("verify the default value for field {string}")
	public void verify_the_default_value_for_field(String fields) 
	{
	    String fieldName[] = fields.split(",");
	    for(int i = 0; i <= fieldName.length-1; i++)
	    {
	    	notif.validateFieldValues(fieldName[i]);
	    }
	}
	
	@Then("verify the search result for field {string} selected as {string}")
	public void verify_the_search_result_for_field_selected_as(String field, String value) 
	{
		notif.applySearchFilter(field, value);
	}
	
	@Then("validate the last column sorted by default")
	public void validate_the_last_column_sorted_by_default() 
	{
	    notif.validateSortingLastColum();
	}
	
	@Then("select the field {string} as {string}")
	public void select_the_field_as(String field, String value) 
	{
	    notif.selectFieldValue(field, value);
	}
	
	@Then("validate the count {string} of search results")
	public void validate_the_of_search_results(String value) 
	{
		if(notif==null)
			notif=new Notification();
	    notif.getTableRowCount(value);
	}
	
	@Then("clear the notification log search result for field {string}")
	public void clear_the_notification_log_search_result_for_field(String field) 
	{
	    notif.clearSearchResult(field);
	}
	
	@Then("validate no result display")
	public void validate_no_result_display() 
	{
	    notif.validateNoSearchResult();
	}
	
	@Then("verify the various table fields are available")
	public void verify_the_various_table_fields_are_available() 
	{
	    notif.validateTableFields();
	}
	
	@Then("validate the sorting of each column")
	public void validate_the_sorting_of_each_column() 
	{if(notif==null)
		notif=new Notification();
	  
	    notif.validateSortingEachColumn();
	}

	@Then("validate the rows per page")
	public void validate_the_rows_per_page() 
	{
	    notif.validateRowPerPage();
	}
	
	@Then("validate the pagination")
	public void validate_the_pagination() 
	{
	    notif.validatePaginationNotificationLog();
	}
	
	@Then("validate the session is retained for {string} selected as {string}")
	public void validate_the_session_is_retained_for_selected_as(String field, String name)
	{
		notif.selectFieldValue(field, name);
		int row = notif.totalRowsAvailable();
		comp.clickOnReportLink();
		comp.selectComplianceReportLink();
		comp.clickOnReportLink();
	    notif.selectNotificationReportLink();
	    notif.validateTheRowCount(row);
	}
	
	@Then("validate the session is retained for {string} selected {string}")
	public void validate_the_session_is_retained_for_selected(String field, String name)
	{
		notif.selectFieldValue(field, name);
		int row = notif.totalRowsAvailable();
		comp.clickOnReportLink();
		comp.selectComplianceReportLink();
		comp.clickOnReportLink();
	    notif.selectNotificationReportLink();
	    notif.validateTheRwCount(row);
	}
	
	@Then("export the csv and validate the records")
	public void export_the_csv_and_validate_the_records() 
	{
	    if(comp == null)
	    	comp = new Compliance();
	    comp.clickExportButton();
	    comp.verifyDownloadFile();
	    comp.validateDetails();
	}
	@Then("export the csv and validate the records user {int}")
	public void export_the_csv_and_validate_the_records(int i) 
	{
	    if(comp == null)
	    	comp = new Compliance();
	    User u =new User();
	    u.usersearchEmail(u.usrEmail[i-1]);
	    comp.clickExportButton();
	    comp.verifyDownloadFile();
	    comp.validateDetails();
	}
	
	@Then("validate the disability of resend button")
	public void validate_the_disability_of_resend_button() 
	{
	    notif.validateDisbaledResendButton();
	}
	
	@Then("select the {int} records from table")
	public void select_the_records_from_table(Integer row) 
	{
	    notif.selectRows(row);
	}
	
	@Then("select the {int} row from table")
	public void select_the_row_from_table(Integer row) 
	{
		notif.selectGivenRow(row);
	}


	@Then("validate resend button is enable")
	public void validate_resend_button_is_enable()
	{
	    notif.validateEnabledResendButton();
	}
	
	@Then("click on resend")
	public void click_on_resend() 
	{
	    notif.clickOnResendButton();
	}
	
	@Then("select all and click on resend button and confirm withing resend pop up")
	public void select_all_and_click_on_resend_button_and_confirm_withing_resend_pop_up() throws InterruptedException {
		notif = new Notification();
		notif.selectallnotifforresend();
		notif.clickOnResendButton();
		 notif.verifyResendPopup();
	     notif.clickOnResendConfirmButton();		
	}
	
	@Then("verify the popup and click on yes button")
	public void verify_the_popup_and_click_on_yes_button()
	{
	    notif.verifyResendPopup();
	    notif.clickOnResendConfirmButton();
	}

	@Then("validate the row count {int}")
	public void validate_the_row_count(int count) 
	{
	    notif.validateTheRowCount(count);
	}

	@Then("validate the value {string} for notification at row {int}")
	public void validate_the_value_for_notification_at_row(String field, Integer rowNumber) 
	{
	    notif.validateNotificationWithRow(field, rowNumber);
	}
	
	@Then("validate the Notification Title {string} for notification")
	public void validate_the_value_for_notification_at_row(String field) 
	{
	    notif.validateNotificationWithRow(field);
	}
	
	@Then("validate the Course {string} and validate Notification Title {string} for notification")
	public void validate_the_value_for_notification_at_row(String Course,String Title) 
	{
	    notif.validateNotificationWithRow(Course,Title);
	}
	@Then("validate the value {string} for resent status at row {int}")
	public void validate_the_value_for_resent_status_at_row(String field, Integer rowNumber) 
	{
	    notif.validateResentWithRow(field, rowNumber);
	}
	
	@Then("validate the disability of check box for inactive user")
	public void validate_the_disability_of_check_box_for_inactive_user()
	{
	    notif.disableCheckbox();
	}
	@Then("validate number of rows display {int} in Notification Report")
    public void validate_multiplecourse_isnot_available(int count)
    {
        notif.validaterow(count);
        
    }
	
	@Then("navigate to notification tab")
	public void navigate_to_notification_tab() {
		if(notif==null)
			notif=new Notification();
		notif.navigateNotificationTab();
	}
	
	@Then("validate the user count applying unit level {int} for notification Report")
	public void validate_the_user_count_applying_unit_level(int count) {
			User	usr = new User();
		usr.validateUserCountUnitLevel(count);
		notif.clickMoreFilterClearSearch();
	}
	
	@Then("click on course filters slide")
	public void click_on_course_filters_slide() {
		notif = new Notification();
	    notif.clickcoursefilterslide();
		
	}
	
	@Then("click on course filter option on notification Report")
	   public void click_on_course_filter_option_on_notificationReport() 
	   {
		 
		notif.clickCourseFilter();
	   }
	
	@Then("validate the Course filter on  notification Report")
	   public void validate_on_course_filter_option_on_notificationReport() 
	   {
		 
		notif.validateCourseNameFilterFilterAvailability();
	   }
	
	
	
	   @Then("search the course filter {string} on notification Report")
	   public void search_the_course_filter_on_progress_report_page(String course) {
		    notif.searchCourseFilter(course);
		   notif.clickOnCourseFilterSearchButton();
	   }

}
