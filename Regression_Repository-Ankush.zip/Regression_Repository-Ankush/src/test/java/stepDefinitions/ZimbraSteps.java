package stepDefinitions;


import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FilenameUtils;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.FluentWait;

import com.qa.pages.LoginPage;
import com.qa.pages.OrganizationHome;
import com.qa.pages.Products;
import com.qa.pages.User;
import com.qa.pages.ZimbraOps;
import com.qa.util.DatabaseConnection;
import com.qa.util.ScreenCapture;
import com.qa.util.TestBase;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ZimbraSteps extends TestBase {
	
	ZimbraOps zops;
	
	@Then("Invoke zambra url")
	public void Invoke_zambra_url() {
		zops = new ZimbraOps();
		zops.navigateZimbraAdmin();
		zops.zadminLogin();
	}
	
	@Then("Create mail end user {string} {string} {string}")
	public void Create_mail_end_user(String mailId,String lname, String password) {
		zops.zaddAccount(mailId, lname, password);
	}
	
	@Then("Create mail end user {string} {string} {string} for {int} uses")
	public void Create_mail_end_user(String mailId,String lname, String password,int n) {
		for(int i=1;i<=n;i++)
		{
		zops.zaddAccount(mailId, Integer.toString(i) , password);
		}
	}
	
	@Then("Create mail based on numbers from config file")
	public void Create_mail_based_on_numbers_from_config_file() {
		zops.zaddAccount();
	}
	
	@Then("Invoke zambra user url")
	public void Invoke_zambra_user_url() {
		zops.navigateZimbraUser();
		zops.zuserLogin("subhash02@rqimail.laerdalblr.in", "123456");
	}
	
	@Then("Change the users password")
	public void Change_the_users_password() {
		zops.zchangePassword();
	}
	
	@Then("Check for the new mail")
	public void Check_for_the_new_mail()
	{
		zops.zCheckMailCount("unit admin");
		
	}
}
	