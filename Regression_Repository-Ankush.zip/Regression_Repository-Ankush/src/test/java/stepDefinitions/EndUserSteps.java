package stepDefinitions;

import org.junit.Assert;

import com.qa.pages.CourseManagement;
import com.qa.pages.EndUser;
import com.qa.pages.OrganizationHome;
import com.qa.pages.User;
import com.qa.pages.UserManagement;
import io.cucumber.java.en.Then;

public class EndUserSteps 
{
	EndUser end;
	UserManagement usrMg;
	OrganizationHome orgHome;
	@Then("verify homepage displayed for end user")
	public void verify_homepage_displayed_for_end_user() 
	{
	    end = new EndUser();
	    end.verifyHomePage();
	}

	@Then("verify context items availability under page source")
	public void verify_context_items_availability_under_page_source() 
	{
		if(end == null)
			end = new EndUser();
		if(orgHome == null)
			orgHome = new OrganizationHome();
		
	    end.validateContextItems(orgHome.contextId,orgHome.contextLabel,orgHome.contextTitle);
	}
	@Then("Review the completed courses without exit")
	public void review_the_completed_courses_without_exit() 
	{
		if(end == null)
			end = new EndUser();
	    end.clickOnCompletedActivities();
	    end.clickOnCompletedCourseReview();
	}
	@Then("give the date for completed course")
	public void give_the_date_for_completed_course() 
	{
		if(end == null)
			end = new EndUser();
		end.clickOnSubmitOnlyWithDate();
	}
	@Then("validate the date shared for future assignments {int} {string}")
	public void validate_the_date_shared_for_future_assignments(Integer count, String dateType) 
	{
	    end.validateDateShared(count + 1, dateType);
	}
	@Then("validate the row count for future assignments {int}")
	public void validate_the_row_count_for_future_assignments(int expectedRowCount) 
	{
	    end.validateRowCountActiveCourses(expectedRowCount + 1);
	}

	@Then("validate the row count for assignments {int} course name {string}")
	public void validate_the_row_count_fo_assignments(int expectedRowCount,String course) 
	{	if(end == null)
		end = new EndUser();
	
	    end.validateRowCountActiveCourses(expectedRowCount,course);
	}
	
	@Then("validate the row count for assignments {int} current course name {string}")
	public void validate_the_row_count_fo_currnetassignments(int expectedRowCount,String course) throws InterruptedException 
	{	if(end == null)
		end = new EndUser();
	
	    end.validateRowCountCurrentCourses(expectedRowCount,course);
	}
	
	
	@Then("validate the row count for future assignments {int} course name {string}")
	public void validate_the_row_count_for_future_assignments(int expectedRowCount,String course) 
	{
	    end.validateRowCountActiveCourses(expectedRowCount + 1,course);
	}
	@Then("navigate to url for future assignments as per date {int} {string}")
	public void navigate_to_url_for_future_assignments_as_per_date(Integer numCount, String dateType) 
	{
		if(end == null)
			end = new EndUser();
	    end.launchFurtureAssignmentUrl(numCount, dateType);
	}
	@Then("survey the completed courses {string}")
	public void survey_the_completed_courses(String name) 
	{
		if(end == null)
			end = new EndUser();
		if(usrMg == null)
			usrMg = new UserManagement();
		end.launchCourseWithName(name);
		end.clickOnSubmitOnlyWithDate("");
		end.surveyCourse();
	   
	}
	
	@Then("evaluate the course {string}")
	public void evaluate_the_course(String name) 
	{
		if(end == null)
			end = new EndUser();
		if(usrMg == null)
			usrMg = new UserManagement();
		end.launchCourseWithName(name);
		end.clickOnSubmitOnlyWithDate("");
	    end.evaluateCourse();
	
	    
	}

	@Then("Validate Message {string} when Evaluation is not completed and trying to Claim CME CE")
	public void Complete_Claim_CME(String msg) 
	{
		if(end == null)
			end = new EndUser();
		if(usrMg == null)
			usrMg = new UserManagement();
			    end.validatemsgClaimCME(msg);
			    end.clickEndUserProgramLink();
	    
	}
	
	@Then("Complete Claim CME")
	public void Complete_Claim_CME() 
	{
		if(end == null)
			end = new EndUser();
		if(usrMg == null)
			usrMg = new UserManagement();
				end.clickOnSubmitOnlyWithDate();
			    end.claimCredit();
			
	    
	}
	
	@Then("navigate to my account page for end user")
	public void navigate_to_my_account_page_for_end_user() 
	{
	    end.clickMyAccount();
	}
	
	@Then("user launch and exit the course")
	public void user_launch_and_exit_the_course() 
	{
	    end.launchCourse();
	    end.startORResumeCourse();
	    end.exitCourse();
	}
	
	@Then("end user logout")
	public void end_user_logout() 
	{
	    end.clickLogOut();
	}
	
	
	@Then("validate if course is removed")
	public void end_user_logouts() 
	{
		if(end == null)
			end = new EndUser();
	
	    end.nocoursepresent();
	}
	
	
	
	@Then("user click on activate course")
	public void user_click_on_activate_course() 
	{
		if(end == null)
			end = new EndUser();
		usrMg = new UserManagement();
		usrMg.switchTab();
	    end.clickActivate();
	    usrMg.switchTab();
	    usrMg.closeOtherTab();
	}
	
	@Then("click on launch course")
	public void click_on_launch_course() 
	{
		if(end == null)
			end = new EndUser();
		usrMg = new UserManagement();
		usrMg.switchTab();
	    end.launchUserCourse1();
	    end.clickOnSubmitOnly();
	    end.startCourse();
		end.exitCourse();
	    usrMg.switchTab();
	    usrMg.closeOtherTab();
	}
	
	@Then("user launch course")
	public void user_launch_course() 
	{
		if(end == null)
			end = new EndUser();
		usrMg = new UserManagement();
	    usrMg.switchTab();
	    end.launchUserCourse1();
	    end.clickOnSubmitOnly();
		end.startCourse();
		end.exitCourse();
		usrMg.switchTab();
	    usrMg.closeOtherTab();
	}
	
	@Then("validate the course available")
	public void validate_the_course_available() 
	{
		end = new EndUser();
		int count = end.getNumberRows();
		Assert.assertTrue(count >= 1);
	}
	
	@Then("validate the courses available")
	public void validatethe_course_available() 
	{
		if(end == null)
			end = new EndUser();
		boolean flag = end.validateCourseAvailable();
		Assert.assertTrue(flag);
	}
	
	@Then("user launch course and validate the course available")
	public void user_launch_course_and_validate_the_course_available() 
	{
		if(end == null)
			end = new EndUser();
		usrMg = new UserManagement();
	    usrMg.switchTab();
	    end.launchUserCourse1();
	    end.clickOnSubmitOnly();
	    int count = end.getNumberRows();
		Assert.assertTrue(count >= 1);
		usrMg.switchTab();
	    usrMg.closeOtherTab();
	}
	
	@Then("navigate to complete programs and review the given course {string}")
	public void navigate_to_complete_programs_and_review_the_given_course(String course) 
	{
		if(end == null)
			end = new EndUser();
		if(usrMg == null)
			usrMg = new UserManagement();
		end.navigateCompletedPrograms();
		end.clickOnCompletedCourseReviews(course);
	}
	
	
	
	@Then("give the date for completed course {string}")
	public void give_the_date_for_completed_course(String date) 
	{
		if(end == null)
			end = new EndUser();
		
		end.clickOnSubmitOnlyWithDate(date);
	}
	
	@Then("give the date for completed course {int}")
	public void give_the_date_for_completed_course(int q) 
	{
		if(end == null)
			end = new EndUser();
		String date=end.changeDate(q);
		end.clickOnSubmitOnlyWithDate(date);
	}

	@Then("Review the completed courses")
	public void review_the_completed_courses() 
	{
		if(end == null)
			end = new EndUser();
	    end.clickOnCompletedActivities();
	    end.clickOnCompletedCourseReview();
	    end.onlyExitCourse();
	}
	
	@Then("validate the error message for course launch")
	public void validate_the_error_message_for_course_launch() 
	{
		if(end == null)
			end = new EndUser();
		end.validateCourseLaunchError();
	}
	
	@Then("validate the error message for given course launch {string} with date {string}")
	public void validate_the_error_message_for_given_course_launch_with_date(String names, String courseDate) 
	{
		if(end == null)
			end = new EndUser();
		String name[] = names.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	end.launchCourseWithName(name[i]);
		    end.clickOnSubmitOnlyWithDate(courseDate);
		    end.validateCourseLaunchError();
		    end.clickEndUserProgramLink();
	    }
	}
	
}
