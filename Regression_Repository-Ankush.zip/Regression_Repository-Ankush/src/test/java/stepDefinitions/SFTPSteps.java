package stepDefinitions;

import com.qa.pages.OrganizationHome;
import com.qa.pages.SFTP;
import io.cucumber.java.en.Then;

public class SFTPSteps 
{
	SFTP sftp;
	OrganizationHome org;
	
	@Then("navigate to SFTP Page")
	public void navigate_to_sftp_page() 
	{
	    sftp = new SFTP();
	    sftp.clickSFTP();
	}

	@Then("create default account validate message {string}")
	public void create_default_account(String msg) 
	{
	    sftp.enterPassword();
	    sftp.clickCreateAccount();
	    org=new OrganizationHome();
	    org.validateSucessMesssage(msg);
	    
	}
	
	@Then("activate the default account")
	public void activate_the_default_account() 
	{
	    sftp.clickActivateAccount();
	    sftp.clickActivateYes();
	}
	@Then("navigate Completion Report Settings tab")
	public void navigate_Completion_Report() 
	{  sftp = new SFTP();
	   
	    sftp.CompletionReportTab();
	   
	}
	
	  
	

		@Then("Configure Completion Report Settings validate message {string}")
		public void Configure_Completion_Report_Settings(String msg) 
		{
		    sftp.ConfigureCompletionReport("Auto123456","Autouser",sftp.sftp,"1122","\file","Automation.csv");
		    org.validateSucessMesssage(msg);

		    
		}
	@Then("Configure Completion Report Settings")
	public void Configure_Completion_Report_Settings() 
	{
	    sftp.ConfigureCompletionReport("Auto123456","Autouser",sftp.sftp,"1122","\file","Automation.csv");
	    
	}
	
	
	@Then("show\\/Hide Password")
	public void show_hide_password() 
	{
	    sftp.clickShowPassword();
	    sftp.closeTab();
	}
	@Then("show\\/Hide Passwords")
	public void show_hide_passwords() 
	{
	    sftp.clickShowPassword();
	}
}
