package stepDefinitions;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.openqa.selenium.JavascriptExecutor;
import com.mysql.cj.jdbc.Driver;
import com.qa.pages.Admin;
import com.qa.pages.EndUser;
import com.qa.pages.Products;
import com.qa.pages.Scrom;
import com.qa.pages.Students;

import com.qa.pages.User;
import com.qa.pages.UserManagement;
import com.qa.util.TestBase;

import io.cucumber.java.en.Then;

public class ScromSteps 
{
	Scrom scr= new Scrom();
	EndUser end=new EndUser();
	Products prod;
	static String parentOrg, packagePath, childOrg;
	String downloadPath = System.getProperty("user.dir") + "\\src\\test\\java\\resources";

	@Then("user navigate to scrom url")
	public void user_navigate_to_scrom_url() 
	{
	   scr = new Scrom();
	   scr.navigateToScromUrl();
	}
	@Then("switch the window to default")
	public void switch_the_window_to_default() 
	{
		if(scr == null)
			scr = new Scrom();
	    scr.switchWindowDefault();
	}
	
	@Then("close existing window")
	public void close_existing_window() 
	{
		if(scr == null)
			scr = new Scrom();
	    scr.closeexistingWindow();
	}

	@Then("Review the completed courses on scrom page")
	public void review_the_completed_courses_on_scrom_pages() 
	{
		if(scr == null)
			scr = new Scrom();
		scr.Acknowledge();
	    scr.clickOnCompletedActivities();
	    scr.clickOnCompletedCourseReview();
	    scr.onlyExitCourse();
	    scr.switchWindowDefault();
	}
	@Then("user import the package and navigate to topic page for courses per name {string}, quarter {int}")
	public void user_import_the_package_and_navigate_to_topic_page_for_courses_per_name_type_and_quarter(String courseName, int quarter) 
	{
		if(scr == null)
			scr = new Scrom();
		
		Products.filePath =System.getProperty("user.dir")+ TestBase. prop.getProperty("downloadPath") + "\\" + courseName + ".zip";
	    System.out.println(Products.filePath);
	    JavascriptExecutor jse = (JavascriptExecutor)TestBase.driver;
		  jse.executeScript("window.scrollBy(0,250)");
		
		scr.uploadPackage(Products.filePath);
		scr.clickUploadPackage();
		scr.clickOnLaunch();
		if(!courseName.contains("Vsim"))
		{
			if(Students.email == null)
	        	scr.switchWindowSelf(Scrom.email, "Ansh", "G");
	        else
	        	scr.switchWindowSelf(Students.email,Students.firstName, Students.lastName);
			end.clickOnSubmitOnlyWithDate(end.changeDate(quarter));
		}
			
	}
	
	@Then("validate the error message for course launch in scrom")
	public void validate_the_error_message_for_course_launch() 
	{
		if(end == null)
			end = new EndUser();
		scr.validateCourseLaunchError();
	}
	
	
	
	@Then("user import the package and Register as per date {int} and course name {string}")
    public void user_import_the_package_as_per_quarter_and_course_name(int date, String courseName)
    {
		Products.filePath =System.getProperty("user.dir")+ TestBase. prop.getProperty("downloadPath") + "\\" + courseName + ".zip";
		 scr.uploadPackage(Products.filePath);
        scr.clickUploadPackage();
        scr.clickOnLaunch();
        if(Students.email == null)
        	scr.switchWindowSelf("Test", "Ansh", "G");
        else
        	scr.switchWindowSelf(Students.email,Students.firstName, Students.lastName);
        String dateUpdate = end.changeDate(date);
        end.clickOnSubmitOnlyWithDate(dateUpdate);
    	int count = end.getAvailableTopicNumberscrom();
    	System.out.println(count);
    	while(count >= 1)
	    {
    		scr.	startORResumeCourse();
//	    	completeCourse();
    		scr.	completeCoursetestCode();
    		scr.   onlyExitCourse();	
    		count = end.getAvailableTopicNumberscrom();
	    }
//    	end.cecmepopup();
		    scr.switchWindowDefault();
    }
	

	@Then("user import the package and Register as per date {int} , course name {string} and accept CMECE popup")
    public void user_import_the_package_as_per_quarter_and_course_name_CMECE(int date, String courseName)
    {
		Products.filePath =System.getProperty("user.dir")+ TestBase. prop.getProperty("downloadPath") + "\\" + courseName + ".zip";
		 scr.uploadPackage(Products.filePath);
        scr.clickUploadPackage();
        scr.clickOnLaunch();
        if(Students.email == null)
        	scr.switchWindowSelf("Test", "Ansh", "G");
        else
        	scr.switchWindowSelf(Students.email,Students.firstName, Students.lastName);
        String dateUpdate = end.changeDate(date);
        end.clickOnSubmitOnlyWithDate(dateUpdate);
    	int count = end.getAvailableTopicNumberscrom();
    	System.out.println(count);
    	while(count >= 1)
	    {
    		scr.	startORResumeCourse();
//	    	completeCourse();
    		scr.	completeCoursetestCode();
    		scr.   onlyExitCourse();	
    		count = end.getAvailableTopicNumberscrom();
	    }
    	end.cecmepopup();
		    scr.switchWindowDefault();
    }
	
	@Then("register the end user")
	public void register_the_end_user() 
	{
		if(!TestBase.driver.getCurrentUrl().contains("sc/guest/SignInForm"))
		scr.logout_without_quit();
		 scr.navigateToScromUrl();
	    scr.clickSignUpLink();
	    scr.enterUserDetails(Students.email, Students.firstName, Students.lastName);
	    scr.clickSignIn();
	}
	@Then("user import and launch the package as per name {string}, type {string} and quarter {int}")
	public void user_import_and_launch_the_package_as_per_name_type_and_quarter(String packageName, String packageType, int quarter) 
	{
		Products.filePath = downloadPath + "\\" + packageName + ".zip";
		System.out.println(Products.filePath);
		scr.uploadPackage(Products.filePath);
		scr.clickUploadPackage();
		scr.clickOnLaunch();
		if(packageType.equalsIgnoreCase("elearning"))
	    {
	    	scr.switchWindowElearningOnlyStart(quarter);
	    }	    	
	    else if(packageType.equalsIgnoreCase("bhf") || packageType.equalsIgnoreCase("responder") || packageType.equalsIgnoreCase("bls provider") || packageType.equalsIgnoreCase("bls entry"))
	    {
	    	scr.switchWindowNoEmailAsPerQuarterOnlyStart(quarter);
	    }
	}
	@Then("open the tab")
	public void open_the_tab() 
	{
	   
		scr.openTab();
	}
	
	@Then("register the end user with already added user")
	public void register_the_end_user_with_already_added_user() 
	{
		if(!scr.prop.getProperty("scromUrl"+scr.prop.getProperty("environment")).contains(TestBase.driver.getCurrentUrl()))
		{
		scr.logout_without_quit();
		}
		 scr.navigateToScromUrl();
	    scr.clickSignUpLink();
	    if(Admin.email == null) 
	    {
	    	if(User.userEmail != null)
			{
				scr.enterUserDetails(User.userEmail, "Ansh", "G");
			}
			else
			{
				scr.enterUserDetails(Students.email, Students.firstName, Students.lastName);
			}	
	    }
	    	
	    else
	    	scr.enterUserDetails(Admin.email, "Ansh", "G");
	    scr.clickSignIn();
	}
	@Then("user import the package only as per course name {string}")
	public void user_import_the_package_only_as_per_course_name(String courseName) 
	{
//		Products.filePath = downloadPath + "\\" + TestBase.courseListName.get(courseName) + ".zip";
		end = new EndUser();
        scr.uploadPackage(Products.filePath);
        scr.clickUploadPackage();
	}
	
	@Then("validate the error message for self registration disabled")
	public void validate_the_error_message_for_self_registration_disabled() 
	{
		scr.switchMidWindow();
	    scr.validateSelfRegisterMessage();
	}

	@Then("register the end user {string} {string}")
	public void register_the_end_user(String first,String lastname) 
	{
		scr.logout_without_quit();
		 scr.navigateToScromUrl();
	    scr.clickSignUpLink();
	    
	    DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		Students.email=first+lastname+formattedEmail+TestBase. prop.getProperty("userDomain");;
		Students.firstName=first;
		Students.lastName=lastname;
		User.userEmail=Students.email;
		Scrom.email=email;
		System.out.println(User.userEmail);
	    scr.enterUserDetails(Students.email, Students.firstName, Students.lastName);
	    scr.clickSignIn();
	}
	@Then("user import the package and Register as per date {int}")
    public void user_import_the_package_as_per_quarter(int date)
    {
		//Products.filePath = downloadPath + "\\" + TestBase.courseProp.getProperty(courseName) + ".zip";
		end = new EndUser();
        scr.uploadPackage(Products.filePath);
        scr.clickUploadPackage();
        scr.clickOnLaunch();
        if(Students.email == Scrom.email)
        	scr.switchWindowSelf(Scrom.email, "Ansh", "G");
        else
        	scr.switchWindowSelf(Students.email,Students.firstName, Students.lastName);
        String dateUpdate = end.changeDate(date);
        end.clickOnSubmitOnlyWithDate(dateUpdate);
    	int count = end.getAvailableTopicNumberscrom();
    	while(count >= 1)
	    {
	    	end.startORResumeCourse();
	    	end.completeCourseTestCode();
	    	end.onlyExitCourse();
		    count = end.getAvailableTopicNumber();
	    }
        scr.switchWindowDefault();
    }
	@Then("user import the package and Register as per date {int} and launch course name {string}")
    public void user_import_the_package_as_per_quarter_and_launch_course_name(int date, String courseName)
    {
//		if(courseListName.containsKey( courseName+"Option"))
//			courseName=courseListName.get( courseName+"Option").toString();

//		Products.filePath = downloadPath + "\\" + TestBase.courseListName.get(courseName) + ".zip";
		end = new EndUser();
        scr.uploadPackage(Products.filePath);
        scr.clickUploadPackage();
        scr.clickOnLaunch();
        if(Students.email == Scrom.email)
        	scr.switchWindowSelf(Scrom.email, "Ansh", "G");
        else
        	scr.switchWindowSelf(Students.email,Students.firstName, Students.lastName);
        String dateUpdate = end.changeDate(date);
        end.clickOnSubmitOnlyWithDate(dateUpdate);
    	int count = end.getAvailableTopicNumberscrom();
    	if(count >= 1)
	    {
	    	end.startORResumeCourse();
	    	end.onlyExitCourse();
	    }
        scr.switchWindowDefault();
        try
        {
        Thread.sleep(5000);	
        }
        catch(Exception e)
        {
        	
        }
    }
	@Then("user login in scrom")
	public void use_login_for_scrom() 
	{
	    scr.enterUserDetail();
	  
	}
	
	@Then("user import the package with one topic left")
	public void user_mport_the_packagewith_one_topic_left() 
	{
		
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
		scr.complecourseoneTopic();
		
	}
	@Then("user import the package {string} with one topic left")
	public void user_mport_the_packagewith_one_topic_left(String date) 
	{
		
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
		scr.complecourseoneTopic(date);
		
	}
	
	@Then("user import the package and only launch")
	public void user_mport_the_packagewith_launch() 
	{
		
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
		scr.onlylaunch();
		
	}
	@Then("user import the package only")
	public void user_mport_the_packageonly() 
	{
		
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	   
		
	}
	@Then("user import the package {string} and only launch")
	public void user_import_the_packagewith_launch(String date) 
	{
		
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
		scr.onlylaunch(date);
		
	}
	@Then("user import the package {int} and only launch")
	public void user_import_the_packagewith_launch(int q) 
	{
		
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    String date=end.changeDate(q);
		scr.onlylaunch(date);
		
	}
	@Then("user import the package")
	public void user_import_the_package() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindow(Students.email);
	  
	}
	
	
	
	@Then("user import the package and validate the message {string}")
	public void user_import_thepackage(String msg) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchMessage(msg);
	  
	}
//	@Then("Complete Claim CME in scrom")
//	public void Complete_Claim_CME() 
//	{
//		
//		scr.claimCredit();
//	
//	    
//	}
	@Then("review the given course {string}")
	public void review_the_given_course(String course) throws InterruptedException 
	{
		prod = new Products();
	    scr.clickonHome();
	    scr.clickOnCourseLaunch(course);
	    scr.clickOnLaunch();
	    scr.switchWindowithoutExitng(Students.email);
		
	}
	
	@Then("user import the package and without exiting")
	public void user_import_the_package_without() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowithoutExiting(Students.email);
	  
	}
	@Then("user import the package closing directly")
	public void user_import_the_package_directly() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowdireclty();
	  
	}
	
	@Then("user import the package quarter {string} and without exiting")
	public void user_import_the_package_without(String i) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowithoutExiting(Students.email,i);
	  
	}
	
	
	@Then("Exiting from Scrom Screen")
	public void exiting_from_scrom_screen() 
	{
		prod = new Products();
	    scr.exitButton();
	   
	}

	@Then("user import the package and upload Package")
	public void user_import_the_package_uploadPackage() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    
	   
	}

	@Then("user Resume Course in Scrom {string}")
	public void userimport_the_package(String course) throws InterruptedException 
	{
		prod = new Products();
	    scr.clickonHome();
	    scr.clickOnCourseLaunch(course);
	    scr.clickOnLaunch();
	    scr.switchWindowResume(Students.email);
	    
	}
	@Then("Reset Course in Scrom {string}")
	public void reset_course_in_scrom(String course) throws InterruptedException 
	{
		prod = new Products();
	    scr.clickonHome();
	    scr.clickOnCourseLaunch(course);
	    scr.clickOnResetProgress();
	    
	}
	
	@Then("user Resume Course {string} in Scrom")
	public void userimport_thepackage(String course) throws InterruptedException 
	{
		prod = new Products();
	    scr.clickonHome();
	    scr.clickOnCourseLaunch(course);
	    scr.clickOnLaunch();
	    scr.changefouse(0);
	    
	}
	
	

	@Then("user import the package quater")
	public void user_import_the_packag() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindow(Students.email);
	}
	@Then("user import the package quarter {int} based on topic")
	public void user_import_the_package_based_on_topic(int i) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowquater(Students.email,i);
	}
	@Then("user import the package quarter {int}")
	public void user_import_the_package(int i) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindow(Students.email,i);
	}
	
	
	@Then("user import the package quarter {int} validate version is each screen {string}")
	public void user_import_the_packageversion(int i,String version) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindow(i,version);
	}
	
	
	@Then("validate scrom Status {string}")
	public void validate_scrom_Status(String status) 
	{
		prod = new Products();
	   
	    scr.validateStatus(status);
	}
	@Then("user import and validate console Log {string}")
	public void user_import_the_package_and_validate_console_log(String log) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowandvalidatelog(log);
	}
	
	@Then("user import the package quarter {int} check if the topic are not displayed")
	public void user_importthe_package(int i) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.checkiftopicnotlocked(Students.email,i);
	}
	
	@Then("user import the package quarter {int} validate message {string}")
	public void user_importthe_package(int i,String msg) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.validateMsg(msg,i);
	}
	
	@Then("re-launch package quarter {int}")
	public void re_launch_the_package(int i) 
	{
		prod = new Products();
	    scr.clickOnLaunch();
	    scr.switchWindow(Students.email,i);
	}
	
	@Then("user import the package quarter {int} with one topic left")
	public void user_mport_the_packagewith_one_topic_left(int i) 
	{
		
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
		scr.complecourseoneTopic(i);
		
	}
	
	@Then("Review the course in scrom for quarter {int}")
	public void user_mport_thepackagewith_one_topic_left(int i) 
	{
		
		prod = new Products();
	    scr.clickOnLaunch();
//		scr.complecourseoneTopic(i);
		scr.changefouse(i)
		;
		
	}
	
	@Then("Review the course in scrom for quarter {int} and")
	public void user_mport_thepackagewith_one_topic_left2(int i) 
	{
		
		prod = new Products();
	    scr.clickOnLaunch();
//		scr.complecourseoneTopic(i);
		scr.changefouse(i)
		;
		scr.Acknowledge();
		
	}
	
	
	
	@Then("Review the course in scrom")
	public void user_mport_thepackagewith_one_topic_left() 
	{
		
		prod = new Products();
	    scr.clickOnLaunch();
//		scr.complecourseoneTopic(i);
		scr.changefouse();
		scr.Acknowledge();
		;
		
	}
	
	@Then("Validate the message {string} and check if topic are in review status")
	public void validate_the_message_andcheck_iftopicareinreviewstatus(String msg) 
	
	{
		
		prod = new Products();
		scr.validatemessage(msg);
		scr.validatereviewButton();
		scr.closeTab();
//	    scr.clickOnLaunch();
//		scr.complecourseoneTopic(i);
//		scr.changefouse(i)
		;
		
	}
	
	@Then("check if topic are in review status")
	public void validate_tiftopicareinreviewstatus() 
	
	{
		
		prod = new Products();
	
		scr.validatereviewButton();
		scr.closeTab();
//	    scr.clickOnLaunch();
//		scr.complecourseoneTopic(i);
//		scr.changefouse(i)
		;
		
	}
	
	@Then("check if topic are not in review status")
	public void validate_tifopicareinreviewstatus() 
	
	{
		
		prod = new Products();
	
		scr.validateNotreviewButton();
		scr.closeTab();
//	    scr.clickOnLaunch();
//		scr.complecourseoneTopic(i);
//		scr.changefouse(i)
		;
		
	}
	@Then("Validate Message {string} in scrom when Evaluation is not completed and trying to Claim CME CE")
	public void Complete_Claim_CME(String msg) 
	{
		
		scr.validatemsgClaimCME(msg);
			   
	    
	}
	
	@Then("Validate ecard in scrom for {string}")
	public void user_mport_thepackagewith_one_topic_left(String course) 
	{
		
		prod = new Products();

	    scr.viewEcardandvalidate(course);
		;
		
	}
	@Then("Validate ecard and Certificate in scrom for {string}")
	public void user_Certificate_one_topic_left(String course) 
	{
		
		prod = new Products();

	    scr.viewCertificateandvalidate(course);
	    scr.viewEcardandvalidate(course);
		
		;
		
	}
	
	@Then("Validate Certificate in scrom for {string}")
	public void userCertificate_one_topic_left(String course) 
	{
		
		prod = new Products();

	    scr.viewCertificatevalidate(course);
	    
		;
		
	}
	
	@Then("Evaluate in scrom")
	public void evaluate() 
	{
		
		scr.evaluateCourse();
		scr.clickOnSubmit();

	    
	}
	
	@Then("Complete Claim CME in Scrom")
	public void Complete_Claim_CME() 
	{
		scr.clickOnSubmit();
		scr.claimCredit();
			
	    
	}
	@Then("Complete Claim CME Provider in Scrom")
	public void Complete_Claim_CME_pr() 
	{
		scr.clickOnSubmit();
		scr.claimCreditProvider();
			
	    
	}
	@Then("re-launch package quarter {int} with one topic left")
	public void re_launch_the_packageone(int i) 
	{
		prod = new Products();
	    scr.clickOnLaunch();
		scr.complecourseoneTopic(i);
		
	}
	@Then("user import the package quarter {int} Complete Course")
	public void userimport_the_package(int i) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindw(Students.email,i);
	}
	
	
	@Then("user import the package quarter {string} Complete Course")
	public void userimpor_the_package(String i) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindw(Students.email,i);
	}
	@Then("user import the package quarter {string} with one topic left")
	public void user_import_the_packagewith_one_topic_left(String i) 
	{
		
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.complecourseoneTopics(i);
		
	}
	
	@Then("user import the package quarter {string}")
	public void user_importthe_package(String i) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindow(Students.email,i);
	}
		
	@Then("user import the package quarter {int} close {string}")
	public void user_import_the_package(int i,String option) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowquit(Students.email,i,option);
	}
	@Then("user import the package quarter {int} and Register")
	public void user_import_the_packag(int i) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowSelf(Students.email,i);
	}
	@Then("user import the package and Register")
	public void user_import_the_ackag() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowSelf(Students.email);
	}
	@Then("user import the package and Register with one topic left")
	public void user_import_the_ckag() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowSelfone(Students.email);
	}
	@Then("user import the package and Register with optional email id")
	public void user_import_the_ackag_email() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowSelfwithoptional(Students.email);
	}
	@Then("user import the package and Register for Online")
	public void user_impor_the_ackag() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowonline(Students.email);
	}
	@Then("user import the package for Online")
	public void user_impor_theackag() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowoline(Students.email);
	}
	@Then("Should get error message Self Registration Error {string}")
	public void userimport_the_ackag(String msg) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.ValidateErrorMSg(msg);
	}
	
	@Then("user import the package {string}")
	public void user_import_the_package(String date) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindw(Students.email,date);
//	    scr.switchWindow(Students.email);
	}
	
	@Then("user import the package and exit")
	public void user_import_the_packageexit() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindows(Students.email);
	}
	
	@Then("Launch the course in Scrom url")
	public void launch_course_in_scrom_url() throws InterruptedException 
	{
		prod = new Products();
		scr.clickonCourse();
//	    scr.uploadPackage(Products.filePath);
//	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindow(Students.email);
	}
	
	@Then("Resume the course in Scrom {string}")
	public void launch_course_in_scrom_url(String course) throws InterruptedException 
	{
		prod = new Products();
		scr.clickOnCourseLaunch(course);
//	    scr.uploadPackage(Products.filePath);
//	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindow(Students.email);
	}
	
	
	@Then("user logout from scrom")
	public void user_logout_from_scrom() 
	{
		scr.logout();
	}
	@Then("user click on launch button")
	public void user_click_on_launch_button() {
		if(scr == null)
			scr = new Scrom();
		scr.clickOnLaunch();
	}

	@Then("user logout from scrom without quit")
	public void user_logout_from_application_without_quit() 
	{
		scr.logout_without_quit();
	}
	
	@Then("user delete the package")
	public void user_delete_the_package() 
	{
	    scr.deletePackage(Products.filePath);
	}
	
	@Then("user import the package without test date")
	public void user_import_the_packagewithout() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowwithout(Students.email);
	}

	@Then("get details of parent org")
	public void get_details_of_parent_org() 
	{
		parentOrg =TestBase.prop.getProperty("orgName");
	    packagePath = Products.filePath;
	}
	
	@Then("get details of child org")
	public void get_details_of_child_org() 
	{
	    childOrg = OrganizationSteps.name;
	}
	
	@Then("navigate to rqip url")
	public void navigate_to_rqip_url() 
	{
		scr.navigateToRQIPUrl();
	}
	@Then("get the topic list")
	public void get_the_topic_list() {
		if(scr == null)
			scr = new Scrom();
	    scr.getNumberRowsscr();
	}
	
	
	@Then("launch the topic and close the course window")
	public void launch_the_topic_and_close_the_course_window() {
		
		scr.startORResumeCourse();
		scr.onlyExitCourse();
    	scr.switchWindowDefault();
	}
	
	@Then("user import the package and validate consent notice")
	public void user_import_thepackage() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowConsentnotice(Students.email);
	  
	}
	
	@Then("user import the package Register and validate consent notice")
	public void user_import_the_package_Consent() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowConsentnoticeSelf(Students.email);
	}
	
	
	@Then("user import the package validate version is each screen {string}")
	public void user_import_the_pckage(String version) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowVersion(version);
	  
	}
	


	@Then("user import the package validate the message {string}")
	public void user_importthepackage(String msg) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchMessages(msg);
	  
	}
}
