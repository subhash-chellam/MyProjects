package stepDefinitions;

import java.io.IOException;

import com.qa.pages.OrganizationHome;
import com.qa.pages.OrganizationSetting;
import com.qa.pages.Products;
import com.qa.pages.Student;
import com.qa.pages.Students;
import com.qa.pages.User;
import com.qa.util.reuseableCode;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
public class StudentSteps 
{
	Students std;
	Student st;
	@Then("navigate to student page")
	public void navigate_to_student_page() 
	{
		std = new Students();
	    std.navigateToStudentTab();
	}

	@Then("download demographic report")
	public void download_demographic_report() 
	{
		std = new Students();
		 
		std.clickImportData();
	    std.clickOnDownloadFile();
	}
	@Then("update the lms report with each variation")
	public void update_the_lms_report_with_each_variation() 
	{
		if(std == null)
		{
			std = new Students();
		}
	    std.addFileDataVariations_LMS_Level2();
	}
	
	@Then("Click on import demographic report")
	public void download_demographi_report() 
	{
		std = new Students();
		 
		std.clickImportData();
		std.readandUpdateFile();
	}
	@Then("Not available import demographic report Btn")
	public void downloaddemographic_report() 
	{
		std = new Students();
		 
		std.notavalibleImportData();
	}
	
	

	@Then("validate table detail in student tab")
	public void validate_table_detail_in_student_tab(DataTable table) {
		
		st = new Student();
		for(int j=0;j<table.height();j++)
			std.validateStudentTable(table.column(0).get(j),table.column(1).get(j));
	
	}
	
	@Then("View Error Log failed {int} row and validated the error")
	public void view_error_log_failedrow_andvalidate(int count,DataTable table) {
		
		st = new Student();
		std.clickonFailedLink(count);
		for(int j=0;j<table.height();j++)
		for(int i=0;i<table.width();i++)
			std.validateErrorTable(j+1,i+1,table.column(i).get(j));
	
		std.clickclose();
//		orgSet.clickDemographicReport();
	}
	
	@Then("validate Table Data Manage Subscribed Courses Tab")
	public void cvalidate_Manage_Subscribed_Courses(DataTable table) 
	{
		for(int j=0;j<table.height();j++)
			for(int i=0;i<table.width();i++)
		std.validateDataforManageSubscribed(table.column(i).get(j),i);
		
	}
	
	@Then("validate Table Data for course topics")
	public void validate_Table_Data_For(DataTable table) 
	{
		std.viewActivities();
//	    
		reuseableCode.waitforsec(1);
		for(int j=1;j<table.height();j++)
			for(int i=0;i<table.width();i++)
			{
				String header=table.column(i).get(0);
				System.out.println(header);
		   std.validatetabledataviewtopic(header,table.column(i).get(j),j);
			}
		
	}
	@Then("validate Table Data in view course")
	public void validate_table_data_view_course(DataTable table) 
	{
		reuseableCode.waitforsec(1);
		for(int j=0;j<table.height();j++)
		std.validatetabledataviewcourse(table.column(0).get(j),table.column(1).get(j));
		
	}
	@Then("view the student and validate the data")
	public void view_the_student(DataTable table) 
	{
		std.viewStudentDetail();
		for(int j=0;j<table.height();j++)
      	    std.validate(table.column(0).get(j),table.column(1).get(j));
		std.cancelViewDetail();
	}
	@Then("Download and compare uploaded Report")
	public void downloaduploaddemographic_report() throws Exception 
	{
		std = new Students();
//		st = new Student();
		std.clickDownloadSourceFile();
	
		std.isFileDownloaded(std.downloadPath, ".csv");
		std.compareFile();
//		st.sourceFile;
	}
	
	@Then("Download and validated failed {int} Error log File")
	public void downloadandvalidateErrorLog(int row) throws Exception 
	{
		std = new Students();
//		std = new Student();
		Products.isFileDownloaded_Ext (std.downloadPath, ".csv");
		
		std.clickerrorLogFile();
	
		std.isFileDownloaded_Ext(std.downloadPath, ".csv");
		std.clickonFailedLink(row);
		
		std.readerfilendvalidate();
		
		std.clickclose();
//		st.sourceFile;
	}
	
	@Then("update the report {int}")
	public void update_the_report(int count) 
	{
		if(std == null)
		{
			std = new Students();
		}
	    std.prepareFile(count);
	}
	
		@Then("update the report {int} without level")
	public void update_the_reportwithout_level(int count) 
	{
		if(std == null)
		{
			std = new Students();
		}
	    std.prepareFileWitoutlevel(count);
	}
	@Then("update the optional report {int}")
	public void update_the_optional_report(int count) 
	{
		if(std == null)
			std = new Students();
	    std.updateOptionalReport(count);
	}
	@Then("update the report {int} with level")
	public void update_the_reportwith_level(int count) 
	{
		if(std == null)
		{
			std = new Students();
		}
	    std.prepareFileWitoutlevel(count);
	}
	
	@Then("update the report {int} with level and {string} First Name {string} Last")
	public void update_the_reportwith_level(int count,String first,String Last) 
	{
		if(std == null)
		{
			std = new Students();
		}
	    std.prepareFileWitoutlevel(count,first,Last);
	}
	
	
	@Then("update the report {int} with level and validate {string} input")
	public void update_the_reportwith_level(int count,String validate) 
	{
		if(std == null)
		{
			std = new Students();
		}
	    std.prepareFileWitoutlevel(count,validate);
	}
	
	@Then("update the report {int} with level and update the level")
	public void update_the_reportwith_levelupdate(int count) 
	{
		if(std == null)
		{
			std = new Students();
		}
	    std.prepareFileWitoutlevelupdate(count);
	}
	
	
	
	@Then("update existing user the report {int} with level")
	public void update_thereportwith_level(int count) 
	{
		if(std == null)
		{
			std = new Students();
		}
	    std.prepareFileeditlevel(count);
	}
	@Then("update the report {int} without level InActive User")
	public void update_the_reportwithout_level_inactive(int count) 
	{
		if(std == null)
		{
			std = new Students();
		}
	    std.prepareFileWitoutlevelactive(count);
	}
	
	@Then("update the lms report {int}")
	public void update_the_lms_report(int count) 
	{
		if(std == null)
		{
			std = new Students();
		}
	    std.addFileData_LMS(count);
	}
	
	@Then("upload the report")
	public void upload_the_report() 
	{
		if(std == null)
		{
			std = new Students();
		}
	    std.uploadFile();
	}
	@Then("upload the Demographic Report and validate {int} failure")
	public void upload_the_Demographicreport(int count) 
	{
		if(std == null)
		{
			std = new Students();
		}
	    std.uploadDemographicFile(count);
	}
	@Then("search the newly created student")
	public void search_the_newly_created_student() 
	{
		if(User.userEmail != null)
			std.studentSearch(User.userEmail);
		else
			std.studentSearch(Students.email);
	}
	
	@Then("search the deleted student")
	public void search_the_deleted_created_student() 
	{
		if(User.userEmail != null)
			std.studentSearchnoresult(User.userEmail);
		else
			std.studentSearchnoresult(Students.email);
	}
	
	
	@Then("click on clear button in student Tab")
	public void searchthe_newly_created_student() 
	{
			std.clear();
	}
	
	@Then("search the newly created student by {string} and value {string}")
	public void search_the_newly_created_student(String searchBy,String value) 
	{
		switch(searchBy)
		{
		case "Email":std.studentSearch(User.userEmail);
		break;
		case "First":std.studentFirstSearch(value);
		break;
		case "Last":std.studentLastSearch(value);
		break;
		case "UnitName":std.studentUnitSearch(value);
		break;

		}
		
	}
	@Then("view and unenroll the course for LMS")
	public void view_and_unenroll_the_course_for_lms() 
	{
		std.selectManageSubscribedCourses();
		std.unenrollCourseLMS();
	}
	
	@Then("click Manage Subscribed Courses")
	public void click_Manage_Subscribed_Courses() 
	{
		std.selectManageSubscribedCourses();
		
	}
	
	@Then("validate if no record found in Manage Subscribed Courses")
	public void validateifnorecordFound() 
	{
		std.validateNoRecordFound();
		
	}
	
//	DataTable table
	
	@Then("validate Table Header Manage Subscribed Courses Tab")
	public void click_Manage_Subscribed_Courses(DataTable table) 
	{
		std.validateHeaderforManageSubscribed(table.asList());
		
	}
	
	
	
	@Then("view and unenroll the course as per name for lms {string} validate Success Msg {string}")
	public void view_and_unenroll_the_course_for_lms(String courseName,String msg) 
	{
		std.selectManageSubscribedCourses();
		std.unenrollCourseWithNameLMS(courseName,msg);
	}
	
	@Then("view and unenroll the course as per name for lms {string} validate Success Msg {string} for recurrence")
	public void view_and_unenroll_the_coursefor_lms(String courseName,String msg) 
	{
		std.selectManageSubscribedCourses();
		std.unenrollCourseWithNameLMSrecurrence(courseName,msg);
	}
	
	@Then("unenroll Btn should not be available the course as per name for lms {string}")
	public void view_and_unenroll_thecourse_for_lms(String courseName) 
	{
		std.selectManageSubscribedCourses();
		std.unenrollCourseWithNameLMSnodisplay(courseName);
	}
	
	@Then("click on unenroll the course as per name {string} for lms")
	public void click_and_unenroll_the_course_as_per_nameforLMS(String courseName) 
	{
		std.selectManageSubscribedCourses();
		std.clickunenrollCourseWithNameLMS(courseName);
	}
	@Then("view and unenroll the course as per name {string} validate Success Msg {string}")
	public void view_and_unenroll_the_course_as_per_name(String courseName,String msg) 
	{
		std.selectManageSubscribedCourses();
		std.unenrollCourseWithName(courseName,msg);
	}
	
	//*[@id='common-modal-content']//p
	@Then("click on unenroll the course as per name {string}")
	public void click_and_unenroll_the_course_as_per_name(String courseName) 
	{
		std.selectManageSubscribedCourses();
		std.clickunenrollCourseWithName(courseName);
	}
	@Then("view and unenroll the course")
	public void view_and_unenroll_the_course() 
	{
		std.selectManageSubscribedCourses();
		std.unenrollCourse();
	}
	
	@Then("Validate the unenroll model {string} and content {string}")
	public void view_and_unenroll_the_course(String model,String content) 
	{
		std.validateunenrollmodel(model,content);
		
	}
	
	
	@Then("Close unenroll dialog box")
	public void close_unenrollbox() 
	{
	    std.closeonUnenroll();
	}
	
	@Then("delete the students")
	public void delete_the_studet() 
	{
	    std.deleteUserDetails();
	}
	
	@Then("delete the report")
	public void delete_the_report() 
	{
		if(std == null)
		{
			std = new Students();
		}
	    std.deleteFile(Students.filePath);
	}
	
	@Then("search the student")
	public void search_the_student() 
	{
	    std.userSearch(User.userEmail);
	}
	
	@Then("view the student")
	public void view_the_student() 
	{
	    std.viewStudentDetails();
	}
	
	
	
	@Then("Cancel Activity Details")
	public void Cancelview_the_student() 
	{
		if(std == null)
		{
			std = new Students();
		}
	    std.cancelViewDetail();
	}
	
	

	@Then("Close Activity Details")
	public void Closeview_the_student() 
	{
		if(std == null)
		{
			std = new Students();
		}
	    std.closeViewDetails();
	}
	@Then("Delete the student")
	public void delete_the_student() 
	{
	    std.deleteStudentDetails();;
	}
	@Then("Delete the student and validate message {string}")
	public void delete_the_student(String msg) 
	{
		OrganizationHome orgHome = new OrganizationHome();
	    std.deleteStudentDetails();;
	    std.clickonSubmitBtn();
	    orgHome.validateSucessMesssage(msg);
	    
	}
	@Then("Validate the message {string}")
	public void delete_the_students(String msg) 
	{
	    std.errorMsg(msg);;
	}
	
	@Then("Click on Submit button")
	public void ClickonSubmitButton() 
	{
	    std.clickonSubmitBtn();
	}
	@Then("edit the student")
	public void edit_the_student() 
	{
	    std.editStudentDetails();
	}

	@Then("edit the student email")
	public void email_the_student() 
	{
	    std.emailStudentDetails();
	}
	@Then("view and edit the student")
	public void view_and_edit_the_student() 
	{
	    std.viewEditDetails();
	}
	
	@Then("get Student Details")
	public void get_Student_Details() 
	{
	    std.getStudentDetails();
	}
	
	

	@Then("set Student Active")
	public void set_Student_active() 
	{
	    std.setStudentActive();
	}
	
	@Then("set Student Inactive")
	public void set_Student_Inactive() 
	{
	    std.setStudentInActive();
	}
	
	@Then("get Student Email {string}")
	public void get_StudentDetails(String level) 
	{
	    std.getStudentDetails(level);
	}
	@Then("get Student Details Inactive")
	public void get_Student_DetailsInactive() 
	{
	    std.getStudentDetailsInActive();
	}

	
	@Then("Student Filter for status {string}")
	public void get_Student_DetailsInactive(String status) throws InterruptedException 
	{
	    std.setFilterUserStatus(status);
	}

	@Then("view and complete the course")
	public void view_and_complete_the_course() 
	{
	    std.viewCourses();
	    std.viewActivities();
	    std.completeCourse();
	}
	@Then("view the course")
	public void view_the_course() 
	{
	    std.viewCourses();
	    std.viewActivities();
//	    std.completeCourse();
	}
	@Then("validate if No Course data available")
	public void validate() 
	{
	    std.validatenocourse();
//	    std.viewActivities();
//	    std.completeCourse();
	}
	
	
	@Then("Click on view the course")
	public void view_the_courses() 
	{
	    std.viewCourses();
//	    std.viewActivities();
//	    std.completeCourse();
	}
	@Then("Manage Subscribed the course and update")
	public void Manage_Subscribed_the_course() 
	{
	    std.ManageCourses();
	   
//	    std.completeCourse();
	}
	
	@Then("reset the password from student page")
	public void reset_the_password_from_student_page() 
	{
	    std.resetPassword();
	}

	@Then("update the lms report for scrom {int}")
	public void update_the_lms_report_for_scrom(int count) 
	{
		if(std == null)
		{
			std = new Students();
		}
	    std.addFileDataScrom_LMS(count);
	}
	@Then("select the value from dropdown {string}")
	public void select_the_value_from_dropdown(String dropDownValue) {
		
		std.clickOnActionButton();
		
		std.selectDropDownValueFromList(dropDownValue);
		std.clickOnPasswordResetLink();
	
	  //std.flashmessage();
	}

	@Then("select the value from dropdown {string} {string}")
	public void selectUserTabandNotificationTab( String user_tabs, String Notifications_tab) throws InterruptedException {
		std.Users_Tabs(user_tabs);
		std.Notifications_Tabs(Notifications_tab);
		
	}
	@Then("edit the student email with uppercase")
	public void edit_the_student_uppercase() 
	{
	std.emailStudentDetailsToUpperCase();
	}
	@Then("edit all student detail")
	public void alledit_the_student_uppercase() 
	{
	std.editallStudentDetails();
	}
	@Then("search the student by Email")
	public void search_the_studentByEmailId() {
		
	//	std.userStudentSearch(EmailId);
		std.searchStudentByEmailId(User.userEmail);
	}
	

	@Then("view and edit the email of student")
	public void view_and_edit_the_email_ofstudent() 
	{
	    std.viewEditEmailDetails();
	}
	
	@Then("click on Edit Details")
	public void click_onEditStudentDetails() 
	{
	    std.clickonEditStudentDetails();
	}
	
	@Then("update the level {string} with {string} unit")
	public void update_level(String level,String levelname) 
	{
	    std.updateLevel(level,levelname);
	}
	
	@Then("update the level {string} with {string} unit Also update Organization Structure {string}")
	public void update_level(String level,String levelname,String org) 
	{
		std.updateOrg("Organization Structure",org);
	    std.updatedLevel(level,levelname);
	}
	
	@Then("update the report for multiple user count {int} with org level {int}")
	public void update_the_report_for_multiple_user_count_with_level(int userCount, int levelCount) 
	{
		if(std == null)
			std = new Students();
		std.prepareFile(userCount,levelCount);
	}
	
	@Then("update the report for multiple user with special characters count {int} with org level {int}")
	public void update_the_report_for_multiple_user_with_special_characters_count_with_level(int userCount, int levelCount) 
	{
		if(std == null)
			std = new Students();
		std.prepareFileSpecialCharacter(userCount,levelCount);
	}
	//*[@id='unit_2']
	
	@Then("update the report for multiple user with each detail for org level {int}")
	public void update_the_report_for_multiple_user_with_each_detail_for_org_level(int levelCount) 
	{
		if(std == null)
			std = new Students();
		std.prepareFileEachDetail(levelCount);
	}
	@Then("update the report for multiple user count {int} and unit and job title with org level {int}")
	public void update_the_report_for_multiple_user_count_and_unit_and_job_title_with_level(int userCount, int levelCount) 
	{
		if(std == null)
			std = new Students();
		std.prepareFileUnitWithJobDetails(userCount,levelCount);
	}
	
	@Then("update the report for multiple user count {int} and job title with org level {int}")
	public void update_the_report_formultiple_user_count_and_unit_and_job_title_with_level(int userCount, int levelCount) 
	{
		if(std == null)
			std = new Students();
		std.prepareFileWithJobDetails(userCount,levelCount);
	}
	@Then("update the report for multiple user count {int} and unit with org level {int}")
	public void update_the_report_for_multiple_user_count_and_unit_with_level(int userCount, int levelCount) 
	{
		if(std == null)
			std = new Students();
		std.prepareFileUnitDetails(userCount,levelCount);
	}
}
