package stepDefinitions;

import java.time.LocalDate;

import org.junit.Assert;

import com.qa.pages.AssignmentReport;
import com.qa.pages.Compliance;
import com.qa.pages.EndUser;
import com.qa.pages.OrganizationSetting;
import com.qa.pages.OrganizationSettings;
import com.qa.pages.ProgressReport;
import com.qa.pages.Scrom;
import com.qa.pages.Student;
import com.qa.pages.Students;
import com.qa.pages.User;
import com.qa.pages.learneractivityfailure;
import com.qa.util.TestBase;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class ComplianceSteps 
{
	Compliance comp;
	Students std;
	EndUser end=new EndUser();
	@Then("navigate to compliance report page")
	public void navigate_to_compliance_report_page() 
	{
	    comp = new Compliance();
	    comp.clickOnReportLink();
	    comp.selectComplianceReportLink();
	    
	}
	
	
	@Then("search the using email in compliance report page")
	public void search_the_using_email() 
	{
		if(comp == null)
		{
			 comp = new Compliance();
		}
//		 User.userEmail="20221118191924010@yopmail.com";
//		 User.userId="Ansh.G021804@yopmail.com";
		comp.usersearchEmail(User.userEmail);
//		comp.usersearchEmail("Ansh.G192503@yopmail.com");
		
		
	}
	

	
	@Then("validate the compliant status as {string} for the course {string}")
    public void validate_the_compliant_status_as_per_quarter(String status,String course)
    {
        comp.validateCompliantStatusDateWithValueAndCourse(status, course);
    }
	@Then("validate the compliant status as {string} for multiple course {string}")
    public void validate_the_compliant_status_as_per_quartermultiple(String status,String course)
    {
		for(int i=0;i<course.split(",").length;i++)
		{
        comp.validateCompliantStatusDateWithValueAndCourse(status, course.split(",")[i]);
		}
    }
		
	@Then("validate the unit name as {string} for the course {string}")
    public void validate_the_unit_name_forthecourse(String status,String course)
    {
		for(int i=0;i<course.split(",").length;i++)
		{
        comp.validateunitnameAndCourse(status,  course.split(",")[i]);
		}
    }
	
	
	@Then("validate the unit name as saved {string} for the course {string}")
    public void validate_the_unit_name_savedforthecourse(String status,String course)
    {
		if(AssignmentReport.checkifParmeterAvailable(status+TestBase.prop.get("environment")))
			status=AssignmentReport.getParmeterAvailable(status+TestBase.prop.get("environment"));
      
	
		for(int i=0;i<course.split(",").length;i++)
		{
        comp.validateunitnameAndCourse(status,  course.split(",")[i]);
		}
    }
	
	@Then("validate the last activity as {string} for the course {string}")
    public void validate_the_last_forthecourse(String date,String course)
    {
		for(int i=0;i<course.split(",").length;i++)
		{
			if(date.contains("Today"))
			{
			LocalDate localDate = LocalDate.now();
			date=localDate.toString().replace("-", "/");
			}
			
			
        comp.validatelastactiveAndCourse(date,  course.split(",")[i]);
		}
    }
	
	@Then("validate the User Status as {string} for the course {string}")
    public void validate_the_status_forthecourse(String status,String course)
    {
		for(int i=0;i<course.split(",").length;i++)
		{
        comp.validateuserStatusAndCourse(status, course.split(",")[i]);
		}
    }
	
	@Then("validate the User Id for the course {string}")
    public void validatethe_userIdforthecourse(String course)
    {
		for(int i=0;i<course.split(",").length;i++)
		{
        comp.validateuserIDAndCourse(User.userId, course.split(",")[i]);
		}
    }
	
	@Then("validate the First Name {string} and Last Name {string} for the course {string}")
    public void validatethe_userIdforthecourse(String first,String Last,String course)
    {
		for(int i=0;i<course.split(",").length;i++)
		{
        comp.validateuserFirstLastNameAndCourse(first,Last,course.split(",")[i]);
		}
    }
	
	
	@Then("click on more filter option on compliance report page")
    public void click_on_more_filter_option_on_compliance_report_page()
    {
        if(comp == null)
            comp = new Compliance();
        comp.clickMoreFilter();
    }


	 @Then("select all user status on compliance report page")
	    public void select_all_user_status_on_compliance_report_page() {
	        if(comp == null)
	            comp = new Compliance();
	        comp.validateUserStatusFilterAvailability();
	        comp.selectAllStatus();
	    }
	 
		@Then("validate compliance report sorting of each column")
		public void validate_LearnerActivity_sorting_of_each_column() {
			if (comp == null)
				comp = new Compliance();

			comp.validatecomplianceSortingEachColumn();
		}

	
	 @Then("validate no records display on compliance report page")
	    public void validate_no_records_display_on_progress_report_page()
	    {
	        comp.validateNoReportGenerated();
	    }
	  @Then("validate the ecard date for the course {string} as per quarter {int}")
	    public void validate_the_ecard_date_as_per_quarter(String course, Integer quarter)
	    {
	        String date = comp.changeDate(quarter);
	        comp.validateEcardWithValueAndCourse(date.replace("-", "/"),course);
	    }
	  
	  @Then("validate the ecard date for multiple course {string} as per quarter {int}")
	    public void validate_the_ecard_date_as_multipleper_quarter(String course, Integer quarter)
	    {
		  for(int i=0;i<course.split(",").length;i++)
		  {
	        String date = comp.changeDate(quarter);
	        comp.validateEcardWithValueAndCourse(date.replace("-", "/"),course.split(",")[i]);
		  }
	    }
	  
	  
	  @Then("verify ecard and click on it course {string}")
	    public void validate_the_ecard_date_as_per_quarter(String course)
	    {
	         comp.validateeCardlinkverification(course);
	    }
	  
	  @Then("validate the compliance until for the course {string} as per quarter {int}")
		public void validate_the_compliance_until_with_date_andcourse(String course,int quarter) 
		{

	        String date = comp.changeDate(quarter);
	       
			comp.validateComplainceWithDateAndCourse(date.replace("-", "/"), course);
		}
	  @Then("validate the compliance until for multiple course {string} as per quarter {int}")
		public void validate_the_compliance_until_with_date_andmultiplecourse(String course,int quarter) 
		{

		  for(int i=0;i<course.split(",").length;i++)
		  {
	        String date = comp.changeDate(quarter);
	       
			comp.validateComplainceWithDateAndCourse(date.replace("-", "/"), course.split(",")[i]);
		  }
		}
		
	@And("Validate Available Fields and filters in compliance Report page")
	public void Validate_Available_Fields_and_filters_in_compliance_Report_page() throws Exception 
	{
	    comp = new Compliance();
	    comp.clickOnReportLink();
	    comp.validateFilters("Active");
	    comp.validateFilters("Inactive");
	    
	} 
	
	@Then("Validate clear search")
	public void Validate_clear_search() throws Exception 
	{
		 comp.clearSearch();
	}
	
	@And("Available Fields Compliance Status filters")
	public void Available_Fields_Compliance_Status_filters(DataTable data) throws Exception 
	{
		 comp.complianceStatusField(data.asList());
	}
	
	@And("verify the columns order in compliance Report")
	public void verify_the_columns_order_in_compliance_Report(DataTable data) throws Exception 
	{
		 comp.complianceStatusColumnsValidation(data.asList(),"beforeSearch");
	}
	
	@And("verify the columns order in compliance Report after search operation")
	public void verify_the_columns_order_in_compliance_Report_after_search_operation(DataTable data) throws Exception 
	{
		 comp.complianceStatusColumnsValidation(data.asList(),"afterSearch");
	}
	
	@Then("verify the message {string} displayed for search filter")
	public void verify_the_message_displayed_for_search_filter(String text) throws Exception 
	{
		comp.AfterSearchMessageValidation(text);
	}
	
	@Then("apply various search")
	public void apply_various_search() 
	{
		comp.searchByfirstName();
		comp.searchByLastName();
		comp.searchByUserID();
		comp.searchByEmail();
		
	}
	
	@Then("download compliance report")
	public void download_compliance_report() 
	{
		std = new Students();
		comp =new Compliance();
		boolean flag = comp.checkCSVFilePresent();
		if(flag == true)
			std.deleteFile(Students.filePath);
		comp.clickExportButton();
	    comp.verifyDownloadFile();
	}
	
	@Then("validate no records present")
	public void validate_no_records_present() 
	{
	    comp.noRecordsPresent();
	}

	
	@Then("validate child compliance")
	public void validate_child_compliance() 
	{
	    comp.recordsPresent();
	    comp.validateCourseName(User.childCourseName);
	}
	
	@Then("validate parent compliance")
	public void validate_parent_compliance() 
	{
		comp.noRecordsPresent();
	}
	
	@Then("validate the record is present")
	public void validate_the_record_is_present() 
	{
		comp.recordsPresent();
	}

	@Then("validate the Consumption report data")
	public void validate_the_Consumption_report_data() 
	{
	    comp.validateConsumptionDetails();
	}
	
	@Then("validate the compliance report data")
	public void validate_the_compliance_report_data() 
	{
	    comp.validateComplianceDetails();
	}
	
	@Then("valid the compliance status {string}")
	public void valid_the_compliance_status(String value) 
	{
		comp.validateComplaint(value);
	}

	@Then("valid the eCard status {string}")
	public void valid_the_e_card_status(String value) 
	{
		comp.validateEcard(value);
	}
	
	@Then("valid the eCard status {string} with course name {string}")
	public void valid_the_e_card_status(String value, String course) 
	{
		comp.validateEcard(value,course);
	}
	@Then("valid the eCard until date {string} with course name {string}")
	public void valid_the__card_status(String value, String course) 
	{
		comp.validateEcard(value,course);
	}
	
	@Then("valid the completion status {string}")
	public void valid_the_completion_status(String value) 
	{
		comp.validateCompletion(value);
	}
	
	@Then("valid the compliance until date {string} with course name {string}")
	public void valid_the_completionstatus_with_course(String value, String course) 
	{
		comp.validateComplainceWithDateAndCourse(value,course);
	}
	@Then("valid the completion status {string} with course name {string}")
	public void valid_the_completion_status_with_course(String value, String course) 
	{
		comp.validateCompletionWithCourse(value,course);
	}
	
	@Then("valid the last activity status {string}")
	public void valid_the_last_activity_status(String value) 
	{
		comp.validateLastActivity(value);
	}
	
	@Then("valid the last activity status {string} with course name {string}")
	public void valid_the_last_activity_status_with_course(String value, String course) 
	{
		comp.validateLastActivityWithCourse(value,course);
	}
	
	@Then("validate the ecard until with date {string}")
	public void validate_the_ecard_until_with_date(String date) 
	{
		comp.validateEcardWithDate(date);
	}
	
	
	@Then("validate the ecard until with date {string} and course {string}")
	public void validate_the_ecard_until_with_date_and_course(String date, String course) 
	{
		comp.validateEcardWithDateAndCourse(date, course);
	}

	@Then("validate the compliance until with date {string}")
	public void validate_the_compliance_until_with_date(String date) 
	{
		comp.validateComplaintWithDate(date);
	}
	
	@Then("validate the compliance until with date {string} and course {string}")
	public void validate_the_compliance_until_with_date_and_course(String date, String course) 
	{
		comp.validateComplainceWithDateAndCourse(date, course);
	}
	
	@Then("validate the compliance until with date for {int} year validity course {string}")
	public void validate_the_compliance_ecard_with_date_and_course(int date, String course) 
	{
		comp.validateComplainceWithDateAndCourse(comp.getdate(date), course);
	}
	
	@Then("validate the row counts {int}")
	public void validate_the_compliance_ecard_with_date_and_course(int count) 
	{
		comp.validaterowcount(count);
	}
	
	@Then("valid the eCard Valid until {int} year validity course name {string}")
	public void valid_the_ecard_status(int date, String course) 
	{
		comp.validateEcardWithDateAndCourse(comp.getdate(date),course);
	}
	
	@Then("validate the compliance until with date for {int} year validity course {string} when email id is optional")
	public void validate_the_compliance_ecard_with_date_and_course_email_id_is_optional(int date, String course) 
	{
		comp.validateComplaintWithDateAndCourseoptionalemail(comp.getdate(date), course);
	}
	
	@Then("valid the eCard Valid until {int} year validity course name {string} when email id is optional")
	public void valid_the_ecard_status_email_id_is_optional(int date, String course) 
	{
		comp.validateEcardWithDateAndCourseOptionalEmail(comp.getdate(date),course);
	}
	@Then("validate the compliant until date for the course {string} as per quarter {int}")
	public void validate_the_compliant_until_date_as_per_quarter(String course, Integer quarter) 
	{
		String date = comp.changeDate(quarter);
		comp.validateCompliantUntilDateWithValueAndCourse(date.replace("-", "/"), course);
	}
	@Then("get the new entry details as per course name {string}")
	public void get_the_new_entry_details_as_per_course_name(String courseName) 
	{
		comp.getNewEntryDetailsCourseName(courseName);
	}
	
	@Then("validate the entry details {int} {int} {int} {string}")
	public void validate_the_entry_details(int assignments, int compliant, int activations, String compliance) 
	{
	   comp.validateEntryDetails(assignments, compliant, activations, compliance);
	}
	@Then("get the old entry details as per course name {string}")
	public void get_the_old_entry_details_as_per_course_name(String courseName) 
	{
	    comp.getOldEntryDetailsCourseName(courseName);
	}
	@Then("validate the header on compliance report page")
	public void validate_the_header_on_progress_report_page() 
	{
	    comp.validateHeader();
	}
	@Then("validate course is available {string}")
	public void validate_course_is_available(String course) 
	{
	    boolean courseAvail = comp.validateCurriculumCourse(course);
	    System.out.println(courseAvail);
	    Assert.assertTrue("Staus is "+courseAvail,courseAvail);
	}
	@Then("validate the completion date for the course {string} as NA")
	public void validate_the_completion_date_as_NA(String course) 
	{
		comp.validateCompletionDateWithValueAndCourse("NA", course);
	}
	@Then("validate the launch date as per coursename {string} as current date on compliance report page")
	public void validate_the_launched_date_as_per_coursename_as_current_date(String course) 
	{
	    comp.validateConsumedWithCourseNameCurrentDate(course);
	}
	
	@Then("validate course is not available {string}")
	public void validate_course_is_not_available(String course)
	{
		boolean courseAvail = comp.validateCurriculumCourse(course);
		 System.out.println(courseAvail);
	    Assert.assertFalse(courseAvail);
	}

	@Then("validate multiple course is not available {string}")
	public void validate_multiplecourse_is_not_available(String course)
	{
		for(int i=0;i<course.split(",").length;i++)
		{
		boolean courseAvail = comp.validateCurriculumCourse(course.split(",")[i]);
		 System.out.println(courseAvail);
	    Assert.assertFalse(courseAvail);
		}
	}
	@Then("user view the ecard on compliance report page as per course name {string}")
	public void user_view_the_ecard_on_compliance_report_page_as_per_course_name(String courseName) 
	{
//		if(proxy == null)
//			proxy = new ProxyUser();
	    comp.viewEcardWithCourseName(courseName);
	    end.switchToCertificatePage();
	    end.clickviewCertficateButtonPage();
	    end.switchToPDFPage();
	}
	
	@Then("validate number of rows display {int} in Compliance Report")
	public void validate_multiplecourse_isnot_available(int count)
	{
		comp.validaterow(count);
		
	}
	
	@Then("validate the row counts {int} in Compliance report")
	public void validate_e_compliance_ecard_with_date_and_course(int count) 
	{
		comp.validaterowcount(count);
	}
	
	@Then("validate multiple course is available {string}")
	public void validate_multiplecourse_is_available(String course) 
	{
		for(int i=0;i<course.split(",").length;i++)
		{
	    boolean courseAvail = comp.validateCurriculumCourse(course.split(",")[i]);
	    System.out.println(courseAvail);
	    Assert.assertTrue("Status is "+courseAvail,courseAvail);
		}
	}
	@Then("validate the curriculum details with course name {string}")
	public void validate_the_curriculum_details_with_course_name(String reqCourse) 
	{
	    int row = comp.getCurriculumCourseName(reqCourse);
	    comp.validateActiveAssignmentCount(String.valueOf(row));
	    comp.validateIncompliantLearnersCount(String.valueOf(row));
	    comp.validateActivationNumberCount(String.valueOf(row));
	    comp.validateCompliancePercentCount(String.valueOf(row));
	}
	
	@Then("validate the compliance status with value {string} and course {string}")
	public void validate_the_compliance_status_with_value_and_course(String date, String course) 
	{
		comp.validateComplaintStatusWithValueAndCourse(date, course);
	}
	

////////////////////////////////////////////////P2 CASES /////////////////////////////////////////////////////////////

	User usr;

	@Then("validate the page numbers on compliance report page")
	public void validate_the_page_numbers_on_compliance_report_page() 
	{
		if(comp == null)
			comp = new Compliance();
		comp.validatePageNumbers();
		comp.getLocationPageNumber();
		comp.validatePaginationDropdown();
		comp.selectPaginationDropdown();
	}

	@Then("validate the {string} filter on compliance report page")
	public void validate_the_filter_on_compliance_report_page(String filterName) {
		if(comp == null)
			comp = new Compliance();
		switch (filterName) {
		case "user status":
			comp.validateUserStatusFilterAvailability();
			break;
		case "org level filter":
			comp.validateOrgLevelFilterFilterAvailability();
			break;
		case "compliance status":
			comp.validateComplianceStatusFilterAvailability();
			break;
		default:
			break;
		}	    
	}

	@Then("validate the default value for {string} as {string} on compliance report page")
	public void validate_the_default_value_for_as_on_compliance_report_page(String filterName, String value) {
		if(comp == null)
			comp = new Compliance();
		switch (filterName) {
		case "user status":
			comp.validateDefaultUserStatus(value);
			break;
		default:
			break;
		}	    
	}

	@Then("export and validate the details on compliance report page")
	public void export_and_validate_the_details_on_compliance_report_page() 
	{
		if(comp == null)
			comp = new Compliance();
		if(usr == null)
			usr = new User();
		boolean flag = usr.checkCSVFilePresent();
		while(flag == true)
		{
			usr.deleteFile(std.filePath);
			flag = usr.checkCSVFilePresent();
		}	
		System.out.println("All CSV files deleted");
		comp.clickExportButton();
		comp.verifyDownloadFile();
		comp.compareDetails();
	}

	@Then("single select user filter status as {string} on compliance report page")
	public void single_select_user_filter_status_as_on_compliance_report_page(String filter) {
		if(comp == null)
			comp = new Compliance();
		comp.selectSingleUserStatusFilter(filter);
		comp.clickOnMoreFilterSearchButton();
	}

	@Then("get the row count")
	public void get_the_row_count() {
		if(comp == null)
			comp = new Compliance();
		comp.getRowCount();
	}

	@Then("validate the search result remain intact by row count")
	public void validate_the_search_result_remain_intact_by_row_count() {
		if(comp == null)
			comp = new Compliance();
		comp.compareRowCount();
	}

	@Then("validate the default sorted column {string} on compliance report page")
	public void validate_the_default_sorted_column_on_compliance_report_page(String columnName) {
		if(comp == null)
			comp = new Compliance();
		comp.validateDefaultColumnSort(columnName);
	}

	@Then("click on cloumn {string} on compliance report page")
	public void click_on_cloumn_on_compliance_report_page(String columnName) {
		if(comp == null)
			comp = new Compliance();
		comp.clickOnColumnHeader(columnName);
	}

	////////////////////////////////////////////////////Filters /////////////////////////////////////////////////////

	@Then("user click on clear search button on compliance report page")
	public void user_click_on_clear_search_button_on_compliance_report_page() 
	{
		if(comp == null)
			comp = new Compliance();
		comp.clearSearchResult();
	}

	@Then("select the org level {int} from organization level dropdown on compliance report page")
	public void select_the_org_level_from_organization_level_dropdown_on_compliance_report_page(Integer level) {
		if(comp == null)
			comp = new Compliance();
		comp.selectOrgLevelMainFilter(level);
	}

	@Then("validate the records are available on compliance report page")
	public void validate_the_records_are_available_on_compliance_report_page() {
		if(comp == null)
			comp = new Compliance();
		comp.validateRecordAvailable();
	}

	@Then("single select org level filter status on compliance report page {string}")
	public void single_select_org_level_filter_status_on_compliance_report_page(String course) {
		if(comp == null)
			comp = new Compliance();
		comp.selectSingleOrgLevelFilter(course);
		comp.clickOnOrgFilterSearchButton();
	}

	@Then("multi select org level filter status on compliance report page {int}")
	public void multi_select_org_level_filter_status_on_compliance_report_page(int count) {
		if(comp == null)
			comp = new Compliance();
		comp.selectMultiOrgLevelFilter(count);	
		comp.clickOnOrgFilterSearchButton();
	}

	@Then("unSelect all org level filter status on compliance report page")
	public void un_select_all_org_level_filter_status_on_compliance_report_page() {
		if(comp == null)
			comp = new Compliance();
		comp.unSelectAllOrgLevelFilter();
		comp.clickOnOrgFilterSearchButton();
	}

	@Then("select all org level filter status on compliance report page")
	public void select_all_org_level_filter_status_on_compliance_report_page() {
		if(comp == null)
			comp = new Compliance();
		comp.selectAllOrgLevelFilter();
		comp.clickOnOrgFilterSearchButton();
	}

	@Then("clear the selected org level filter status on compliance report page")
	public void clear_the_selected_org_level_filter_status_on_compliance_report_page() {
		if(comp == null)
			comp = new Compliance();
		comp.unSelectAllOrgLevelFilter();
	}

	@Then("search the org level filter on compliance report page")
	public void search_the_course_filter_on_compliance_report_page() {
		if(comp == null)
			comp = new Compliance();
		comp.searchOrgLevelFilter(OrganizationSettings.newUnitName);
		comp.clickOnOrgFilterSearchButton();
	}

	////////////////////////////////////////////////USER FILTER/////////////////////////////////////////////

	@Then("multi select user filter status as {string} on compliance report page")
	public void multi_select_user_filter_status_as_on_compliance_report_page(String filter) {
		if(comp == null)
			comp = new Compliance();
		String[] filterList = filter.split(",");
		for(int i = 0; i < filterList.length; i++) {
			comp.selectMultiUserStatusFilter(filterList[i]);	
		}
		comp.clickOnMoreFilterSearchButton();
	}

	@Then("unSelect all user status on compliance report page")
	public void unSelect_all_user_status_on_compliance_report_page() {
		if(comp == null)
			comp = new Compliance();
		comp.unSelectAllStatus();
		comp.clickOnMoreFilterSearchButton();
	}

	@Then("select all user status and search on compliance report page")
	public void select_all_user_status_and_search_on_compliance_report_page() {
		if(comp == null)
			comp = new Compliance();
		comp.selectAllStatus();
		comp.clickOnMoreFilterSearchButton();
	}

	@Then("clear the selected user status on compliance report page")
	public void clear_the_selected_user_status_on_compliance_report_page() {
		if(comp == null)
			comp = new Compliance();
		comp.unSelectAllStatus();
	}

	@Then("search the user by status {string} on compliance report page")
	public void search_the_user_by_status_on_compliance_report_page(String userStatus) {
		if(comp == null)
			comp = new Compliance();
		comp.searchUserStatus(userStatus);
		comp.clickOnMoreFilterSearchButton();
	}

	///////////////////////////////////////////// COMPLIANCE STATUS /////////////////////////////////////

	@Then("single select compliance filter status as {string} on compliance report page")
	public void single_select_compliance_filter_status_as_on_compliance_report_page(String filter) {
		if(comp == null)
			comp = new Compliance();
		comp.selectSingleComplianceStatusFilter(filter);
		comp.clickOnMoreFilterSearchButton();
	}

	@Then("multi select compliance filter status as {string} on compliance report page")
	public void multi_select_compliance_filter_status_as_on_compliance_report_page(String filter) {
		if(comp == null)
			comp = new Compliance();
		String[] filterList = filter.split(",");
		for(int i = 0; i < filterList.length; i++) {
			comp.selectMultiComplianceStatusFilter(filterList[i]);	
		}
		comp.clickOnMoreFilterSearchButton();
	}

	@Then("unSelect all compliance status on compliance report page")
	public void unSelect_all_compliance_status_on_compliance_report_page() {
		if(comp == null)
			comp = new Compliance();
		comp.unSelectAllComplianceStatus();
		comp.clickOnMoreFilterSearchButton();
	}

	@Then("select all compliance status and search on compliance report page")
	public void select_all_compliance_status_and_search_on_compliance_report_page() {
		if(comp == null)
			comp = new Compliance();
		comp.selectAllComplianceStatus();
		comp.clickOnMoreFilterSearchButton();
	}

	@Then("clear the selected compliance status on compliance report page")
	public void clear_the_selected_compliance_status_on_compliance_report_page() {
		if(comp == null)
			comp = new Compliance();
		comp.unSelectAllComplianceStatus();
	}

	@Then("search the compliance by status {string} on compliance report page")
	public void search_the_compliance_by_status_on_compliance_report_page(String userStatus) {
		if(comp == null)
			comp = new Compliance();
		comp.searchComplianceStatus(userStatus);
		comp.clickOnMoreFilterSearchButton();
	}

	@Then("validate curriculum status filter and its option on compliance report page")
	public void validate_curriculum_status_filter_and_its_option_on_compliance_report_page() {
		if(comp == null)
			comp = new Compliance();
		comp.validateComplianceStatusFilterAvailability();
		comp.validateCurriculumStatusOptions();
	}

	@Then("validate the scroll bar count on compliance report page")
	public void validate_the_scroll_bar_count_on_compliance_report_page() {
		if(comp == null)
			comp = new Compliance();
		comp.scrollBarCount();
	}

	
	


}
