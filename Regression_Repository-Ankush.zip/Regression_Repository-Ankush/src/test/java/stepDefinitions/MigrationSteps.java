package stepDefinitions;

import com.qa.pages.HLC_Migration;
import com.qa.pages.NewOrganization;
import com.qa.pages.OrganizationDetails;
import com.qa.pages.OrganizationHome;
import com.qa.util.TestBase;
import io.cucumber.java.en.Then;

public class MigrationSteps 
{
	HLC_Migration hlc;
	OrganizationDetails orgDetails;
	NewOrganization newOrg;
	OrganizationHome orgHome;
	ScromSteps scrom;
	@Then("edit the file")
	public void edit_the_file() 
	{
	    hlc = new HLC_Migration();
	    hlc.updateFile();
	}
	
	@Then("edit the file and update with parent child org details")
	public void edit_the_file_withparentChildorg() 
	{
	    hlc = new HLC_Migration();
	    scrom=new ScromSteps();
	    hlc.updateFileupdatewithparentChildorg();
//	    scrom.parentOrg=hlc.orgName;
//	    scrom.childOrg=hlc.childorgName;
//	    hlc.orgName="Autoorg_MonOct17134559IST2022";
//	    TestBase.prop.setProperty("orgName", hlc.orgName);
//	    		hlc.childorgName=		"Autchild_MonOct17134603IST2022";
	    		scrom.parentOrg=hlc.orgName;
	    	    scrom.childOrg=hlc.childorgName;
	    	    newOrg = new NewOrganization();
	    		newOrg.Log_Organisation_Name(scrom.parentOrg, "HLC Parent");
	    	    newOrg.Log_Organisation_Name(scrom.childOrg, "HLC Child");
//	    scrom.parentOrg="Autchild_MonOct17134603IST2022";
	    
	}
	
	@Then("import the file")
	public void import_the_file()
	{
	    hlc.clickImportButton();
	    hlc.clickOnCheckbox();
	    hlc.selectFileToUpload();
	    hlc.validateFle();
	    hlc.uploadFile();
	}
	
	@Then("search the created HLC organisation")
	public void search_the_created_hlc_organisation() 
	{
	    hlc.searchHLC();
	}

	@Then("enter the mandatory fields for hlc organization and save")
	public void enter_the_mandatory_fields_for_hlc_organization_and_save() throws Exception 
	{
		orgDetails = new OrganizationDetails();
		orgDetails.clickEditOrganization();
		orgHome = new OrganizationHome();
		newOrg = new NewOrganization();
		String name = TestBase.prop.getProperty("orgName"); 
		newOrg.selectProductType("RQI");
		newOrg.contactPersonDetail("Ansh", "G", name, "1234567890");
		newOrg.companyDetails("187 s washington st", "Tiffin", "Ohio", "44883");
		newOrg.enterSubDomain(name);
		newOrg.selectLang();
		newOrg.selectTimeZone();
		newOrg.addLMSInformation(name);
		orgDetails.clickUpdateOrganization();
		orgHome.validateSucessMesssage();
	}
	@Then("enter the mandatory fields for Child hlc organization and save")
	public void enter_the_mandatory_fields_foChildr_hlc_organization_and_save() throws Exception 
	{
		orgDetails = new OrganizationDetails();
		orgDetails.clickEditOrganization();
		orgHome = new OrganizationHome();
		newOrg = new NewOrganization();
		String name =ScromSteps.childOrg; 
		newOrg.selectParentOrganisationhlc(ScromSteps.parentOrg);
		newOrg.selectProductType("RQI");
		newOrg.contactPersonDetail("Ansh", "G", name, "1234567890");
		newOrg.companyDetails("187 s washington st", "Tiffin", "Ohio", "44883");
		newOrg.enterSubDomain(name);
		newOrg.selectLang();
		newOrg.selectTimeZone();
		newOrg.addLMSInformation(name);
		orgDetails.clickUpdateOrganization();
		orgHome.validateSucessMesssage();
	}
	
	@Then("search the organisation with multiple search option")
	public void search_the_organisation_with_multiple_search_option()
	{
		hlc.Multiplesearch();
	}
	
	
	@Then("search the Organization with profile status pending")
	public void search_the_Organization_with_profile_status_pending()
	{
		hlc.ProfileStatusSearch();
		hlc.PendingActionDtls();

	}
	
	@Then("search the Organization with profile status completed")
	public void search_the_Organization_with_profile_status_completed()
	{
		
		hlc.ProfileStatusSearch();
		hlc.CompletedActionDtls();
	}
	
	
	
	
	
	@Then("import the file by {string}")
	public void import_the_file_by(String choice) 
	{
		switch (choice) {
		
		case "yes":
			hlc.clickImportButton();
		    hlc.clickOnCheckbox();
		    hlc.selectFileToUpload();
		    hlc.validateFle();
		    hlc.uploadFile();
			break;
			
		case "No":
			hlc.clickImportButton();
		    hlc.selectFileToUpload();
		    hlc.validateFle();
		    hlc.uploadFile();
			break;

		
		}
	}
	
}
