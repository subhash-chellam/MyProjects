package com.qa.pages;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Collections;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.collect.Ordering;
import com.qa.util.TestBase;

public class CE_Report  extends TestBase{
	
	@FindBy(xpath = "//h1")
	WebElement pageHeading;
	
	@FindBy(xpath = "//div[contains(@class, 'user_details')]//a[@data-toggle='dropdown']")
	WebElement menuOption;
	
	@FindBy(xpath = "//div[contains(@class, 'user_details')]//a[contains(text(),'Logout')]")
	WebElement logout;
	
	@FindBy(xpath = "//a[text() = 'Reports']")
	WebElement reportButton;
	
	@FindBy(xpath = "//input[@id = 'start_date']")
	WebElement fromDate;
	
	@FindBy(xpath = "//input[@id = 'end_date']")
	WebElement toDate;

	@FindBy(xpath = "//div[contains(@class, 'datepicker ')]")
	WebElement calendarMainBody;
	
	@FindBy(xpath = "//div[@class = 'datepicker-days']//th[contains(@class, 'datepicker-switch')]")
	WebElement calendarMonthYear;
	
	@FindBy(xpath = "//div[@class = 'datepicker-days']//td[contains(@class, 'active')]")
	WebElement calendarSelectedDay;
	
	@FindBy(xpath = "//div[@class = 'datepicker-months']//th[contains(@class, 'datepicker-switch')]")
	WebElement calendarSelectedYear;
	
	@FindBy(xpath = "//div[@class = 'datepicker-years']//th[@class = 'prev']")
	WebElement calendarRequiredYear;
		
	@FindBy(xpath = "//a[@id = 'reset_default']")
	WebElement clearResult;
	
	@FindBy(xpath = "//label[text() = 'CE Type']/following-sibling::div//button")
	WebElement ceFilterButton;
	
	@FindBy(xpath = "//label[text() = 'CE Type']/following-sibling::div//li//span[1]")
	List<WebElement> ceFilterAllValues;
	
	@FindBy(xpath = "//button[text() = 'Email Report']")
	WebElement exportButton;
	
	@FindBy(xpath = "//div[@role = 'document']/div")
	WebElement exportDialogue;
	
	@FindBy(xpath = "//div[@role = 'document']/div//h4")
	WebElement exportDialogueHeading;
	
	@FindBy(xpath = "//div[@role = 'document']/div//span")
	WebElement exportDialogueBody;
	
	@FindBy(xpath = "//div[@role = 'document']//div[3]/button")
	WebElement exportDialogueCloseButton;
	
	@FindBy(xpath = "//div//a[contains(text(),'Download Report')]")
	WebElement downloadReportButton;
	
	String reportOption = "(//ul[2]/li)";
	String reportDropdownOtherRoles = "(//a[text() = 'Reports']/following-sibling::ul/li/a)";
	String calendarDay = "(//div[@class = 'datepicker-days']//td[@class = 'day'])";
	String calendarMonthOptions = "//div[@class = 'datepicker-months']//td/span[contains(text(), '";
	String calendarYearOptions = "//div[@class = 'datepicker-years']//td/span[contains(text(), '";
	
	public CE_Report() 
	{
		PageFactory.initElements(driver, this);
	}
	
	public void ceReportHeading() {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(pageHeading));
		String actualText = pageHeading.getText().trim();
		Assert.assertTrue(actualText.equalsIgnoreCase("RQI for NRP CE Reports"));
	}
	
	public void validateReportOptionCount(int count) {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(reportOption + "[1]"))));
		int actualSize = driver.findElements(By.xpath(reportOption)).size();
		Assert.assertTrue(actualSize == count);
	}
	
	public void logout() {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click()", menuOption);
		wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(logout));
		logout.click();
	}

	public void ceReportHeadingNotAvailable() {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		try {
		wait.until(ExpectedConditions.visibilityOf(pageHeading));
		String actualText = pageHeading.getText().trim();
		Assert.assertFalse("CE Report is available on the page",actualText.equalsIgnoreCase("RQI for NRP CE Reports"));
	}
	catch(Exception e) {
		
	}
	}

	public void validateCE_ReportNotAvailable() {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		reportButton.click();
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(reportDropdownOtherRoles + "[1]"))));
		List<WebElement> reportOptions = driver.findElements(By.xpath(reportDropdownOtherRoles));
		for (WebElement element : reportOptions) {
			String optionValue = element.getText();
			if(optionValue.equalsIgnoreCase("RQI for NRP CE Reports"))
				Assert.fail("CE Report is available for other than AAP Admin role");
		}
	}
	
	public String getFirstDayQuarter(int quarter)
	{
		
		LocalDate localDate = LocalDate.now();
		LocalDate firstDayOfQuarter = localDate.with(localDate.getMonth().firstMonthOfQuarter()).plusMonths(quarter*3).with(TemporalAdjusters.firstDayOfMonth());
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd");		
		String formattedStartDate = firstDayOfQuarter.format(dateFormat);
		return formattedStartDate;
	}
	
	public String getLastDayQuarter(int quarter)
	{
		
		LocalDate localDate = LocalDate.now();
		LocalDate firstDayOfQuarter = localDate.with(localDate.getMonth().firstMonthOfQuarter()).with(TemporalAdjusters.firstDayOfMonth());
		LocalDate lastDayOfQuarter;
		lastDayOfQuarter = firstDayOfQuarter.plusMonths(quarter*3).plusMonths(2).with(TemporalAdjusters.lastDayOfMonth());
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd");		
		String formattedEndDate = lastDayOfQuarter.format(dateFormat);
		return formattedEndDate;
	}
	
	public void validateFromFilter_DefaultValues() {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(fromDate));
		String dateActual = fromDate.getAttribute("value");
		String dateExpected = getFirstDayQuarter(-1);
		System.out.println("Actual date in from date filter " + dateActual);
		System.out.println("Expected date in from date filter " + dateExpected);
		Assert.assertTrue(dateActual.equals(dateExpected));
	}
	
	public void validateToFilter_DefaultValues() {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(toDate));
		String dateActual = toDate.getAttribute("value");
		String dateExpected = getLastDayQuarter(-1);
		System.out.println("Actual date in end date filter" + dateActual);
		System.out.println("Expected date in end date filter" + dateExpected);
		Assert.assertTrue(dateActual.equals(dateExpected));
	}
	
	public void validFromDateValue() {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(fromDate));
		fromDate.click();
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd");	
		LocalDate date = LocalDate.parse("2021/07/15", dateFormat);
		System.out.println(date.format(dateFormat).toString() + " " + date.getMonth().toString() + " " + Integer.toString(date.getYear()) + " " + Integer.toString(date.getDayOfMonth()));
		pickCalendarDate(date.format(dateFormat).toString(), date.getMonth().toString(), Integer.toString(date.getYear()), Integer.toString(date.getDayOfMonth()));
		String dateActual = fromDate.getAttribute("value");
		Assert.assertTrue(dateActual.equals(date.format(dateFormat).toString()));
	}
	
	public void validEndDateValue() {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(toDate));
		toDate.click();
		LocalDate localDate = LocalDate.now();
		LocalDate addedDays = localDate.plusDays(-1);
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd");		
		String dateString = addedDays.format(dateFormat);
		LocalDate date = LocalDate.parse(dateString, dateFormat);
		System.out.println(date.format(dateFormat).toString() + " " + date.getMonth().toString() + " " + Integer.toString(date.getYear()) + " " + Integer.toString(date.getDayOfMonth()));
		pickCalendarDate(date.format(dateFormat).toString(), date.getMonth().toString(), Integer.toString(date.getYear()), Integer.toString(date.getDayOfMonth()));
		String dateActual = toDate.getAttribute("value");
		Assert.assertTrue(dateActual.equals(date.format(dateFormat).toString()));
	}
	
	public void pickCalendarDate(String date, String month, String year, String day) {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(calendarMainBody));
		wait.until(ExpectedConditions.visibilityOf(calendarMonthYear));
		month = month.toLowerCase();
		if(month.length() > 3) {
			month = month.substring(0, 3);
		}
		month = month.replace(month.split("")[0], month.split("")[0].toUpperCase());
		String currentMonth = calendarMonthYear.getText().split(" ")[0];
		String currentYear = calendarMonthYear.getText().split(" ")[1];
//		currentMonth.
		String currentDay = calendarSelectedDay.getText();
		if(currentYear.equals(year)) {
			if(currentMonth.contains(month)) {
				if(!currentDay.equals(day)) {
					driver.findElement(By.xpath(calendarDay + "[" + day + "]")).click();
				}
				String ifSelected = driver.findElement(By.xpath(calendarDay + "[" + day + "]")).getAttribute("class").trim().toLowerCase();
				Assert.assertTrue(ifSelected.contains("active"));
			}
			else {
				calendarMonthYear.click();
				WebElement requiredMonth = driver.findElement(By.xpath(calendarMonthOptions + month + "')]"));
				requiredMonth.click();
				currentMonth = calendarMonthYear.getText().split(" ")[0];
				Assert.assertTrue(currentMonth.contains(month));
				driver.findElement(By.xpath(calendarDay + "[" + day + "]")).click();
			}
		}
		else {
			calendarMonthYear.click();
			calendarSelectedYear.click();
			int yearInt = Integer.parseInt(year);
			if((2009 <= yearInt) && (yearInt <= 2018)){
				calendarRequiredYear.click();
			}
			WebElement requiredYear = driver.findElement(By.xpath(calendarYearOptions + year + "')]"));
			requiredYear.click();
			WebElement requiredMonth = driver.findElement(By.xpath(calendarMonthOptions + month + "')]"));
			requiredMonth.click();
			driver.findElement(By.xpath(calendarDay + "[" + day + "]")).click();
		}
	}
	
	public void clickClearButton() {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(clearResult));
		clearResult.click();
		validateFromFilter_DefaultValues();
		validateToFilter_DefaultValues();
	}
	
	public void validateCEFilter_DefaultValues() {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(ceFilterButton));
		String dateActual = ceFilterButton.getAttribute("title");
		Assert.assertEquals("Select CE Type", dateActual);	
	}
	
	public void validateCEFilterAllValues(String values) {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(ceFilterButton));
		ceFilterButton.click();
		String allValues[] = values.split(",");
		boolean flag= false;
		for (String val : allValues) {
			int counter = 1;
			for(int i = counter; i< ceFilterAllValues.size(); i++) {
				if(ceFilterAllValues.get(counter).getText().trim().contains(val.trim())) {
					System.out.println("Expected Value in filter is " +val);
					System.out.println("Actual Value in filter is " + ceFilterAllValues.get(counter).getText());
					flag = true;
					break;
				}
				
				counter++;
			}
			Assert.assertTrue(flag);
		}
	}
	
	public void validateDisableExportButton(String available) {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(exportButton));
		String isDisable = exportButton.getAttribute("disabled");
		if(available.equalsIgnoreCase("yes"))
			Assert.assertTrue(isDisable.equals("true"));
		else if(available.equalsIgnoreCase("no"))
			Assert.assertTrue(isDisable == null);
	}
	
	public void enterCEFilterValue(String value) {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(ceFilterButton));
		ceFilterButton.click();
		int counter = 1;
		for(int i = counter; i< ceFilterAllValues.size(); i++) {
			if(ceFilterAllValues.get(counter).getText().trim().contains(value.trim())) {
				ceFilterAllValues.get(counter).click();
				break;
			}
			counter++;
		}
	}
	
	public void clickExportButton() {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(exportButton));
		String isDisable = exportButton.getAttribute("disabled");
		Assert.assertTrue(isDisable == null);
		exportButton.click();
	}
	
	public void validateEmailDialogueBox(String email) {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(exportDialogue));
		String heading = exportDialogueHeading.getText();
		Assert.assertTrue(heading.equals("Notice!"));
		String expectedBody = "A link to this report will be sent to your email address (<email>) when it is ready for download.";
		String body = exportDialogueBody.getText();
		Assert.assertTrue(body.equals(expectedBody.replace("<email>", email)));
	}
	
	public void closeEmailDialogueBox() {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(exportDialogue));
		exportDialogueCloseButton.click();
	}

	public void validateSortingCEFilterValues() {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(ceFilterButton));
		ceFilterButton.click();
		List<String> originalValueList = new ArrayList<>();		
		int counter = 1;
			for(int i = counter; i< ceFilterAllValues.size(); i++) {
				String currentValue = ceFilterAllValues.get(counter).getText();
				originalValueList.add(currentValue);
				counter++;
			}
//			boolean sorted  = Ordering.natural().isOrdered(originalValueList);
//			System.out.println(sorted);
			boolean sorted  = originalValueList.stream().sorted().toList().equals(originalValueList);
			System.out.println(sorted);
			Assert.assertTrue(sorted);	
		}
	
	public void clickDownloadReport() {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(downloadReportButton));
		downloadReportButton.click();
	}
}
