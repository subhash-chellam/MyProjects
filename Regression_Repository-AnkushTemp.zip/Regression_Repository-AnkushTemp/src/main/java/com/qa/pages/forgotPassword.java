package com.qa.pages;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.util.TestBase;

import junit.framework.Assert;

public class forgotPassword  extends TestBase {
	
	@FindBy(xpath = "//input[@type = 'submit']")
	WebElement adminSignIn;

	@FindBy(xpath = "(//*/a[text()='Forgot password?'])[2]")
	WebElement forgot;
	
	
	@FindBy(xpath = "//*[@id='email']")
	WebElement email;
	
	@FindBy(xpath = "//*/input[@value='Send']")
	WebElement send;
	
	@FindBy(xpath = "//iframe[@id = 'ifmail']")
	WebElement frame;
	

	@FindBy(xpath = "//*[@id = 'email_error']")
	WebElement emailError;
	
	@FindBy(xpath = "//*[@id=\"mail\"]/div/p[3]/a")
	WebElement reset;
	
	@FindBy(xpath = "//*[@id='sentEmailForm']/div[1]")
	WebElement msg;
	
	String forgotPassword="//div[text()='Forgot Password']";
	
	public forgotPassword() 
	{
		PageFactory.initElements(driver, this);
		driver.manage().timeouts().pageLoadTimeout(300, TimeUnit.SECONDS);
	}

	public void clickOnForgotPasswordLink()
	{
		
		wait.until(ExpectedConditions.visibilityOf(forgot));
		forgot.click();
	
		
	}
	
	public void sendemailForgot() throws Exception
	{
//		User.userEmail="";
		Thread.sleep(5000);
		wait.until(ExpectedConditions.visibilityOf(email));
		email.sendKeys(User.userEmail);
		
		wait.until(ExpectedConditions.visibilityOf(send));
		send.click();
		Thread.sleep(5000);
       wait.until(ExpectedConditions.visibilityOf(msg));
		
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		String date = formatter.format(formatDate);
		String successMsg=null;
		if(AssignmentReport. checkifParmeterAvailable( "ResetSucessMsg"))
			successMsg=AssignmentReport.getParmeterAvailable( "ResetSucessMsg");
		System.out.println(msg.getText());
		Assert.assertTrue(msg.getText().contains(successMsg.replace("Date", date)));
	
	}
	
	
	public void enterEmail()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(email));
		email.click();
		email.sendKeys(User.userEmail);
		send.click();
		reuse.waitforsec(6);
	}
	
	public void validateErrorForEmptyEmail()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(email));
		send.click();
		wait.until(ExpectedConditions.visibilityOf(emailError));
		String message = emailError.getText();
		Assert.assertTrue(message.equals("The email is required and can't be empty"));
	}
	
	
	
	public void sendemail()
	{
//		User.userEmail="";
		
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifinbox");
		
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(forgotPassword))));
		
		
		List<WebElement> row1=driver.findElements(By.xpath(forgotPassword));
		
		row1.get(0).click();
		
		driver.switchTo().defaultContent();
		
		wait.until(ExpectedConditions.visibilityOf(frame));
		driver.switchTo().frame("ifmail");
		
		wait.until(ExpectedConditions.visibilityOf(reset));
		
		reset.click();
		
			
		driver.switchTo().defaultContent();
		
		
	}
	

}
