package com.qa.pages;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.python.modules.thread.thread;

import com.qa.util.TestBase;

public class Moodle extends TestBase{

	@FindBy(xpath = "//input[@id='username']")
	WebElement username;
	
	@FindBy(xpath = "//input[@id = 'password']")
	WebElement password;
		
	@FindBy(xpath = "//*[@id='loginbtn']")
	WebElement login;

	@FindBy(xpath = "(//a[contains(text(),'Site administration')])[1]")
	WebElement siteadmin;

	@FindBy(xpath = "//a[contains(text(),'Users') and @role='tab']")
	WebElement Users;

	@FindBy(xpath = "//a[text()='Add a new user']")
	WebElement adduser;

	@FindBy(xpath = "//input[@id='id_username']")
	WebElement usernme;
	
	 
	
	@FindBy(xpath = "//*[@title=\"Edit password\"]")
	WebElement passwrd;
	
	@FindBy(xpath = "//*[@id='id_newpassword']")
	WebElement newpasswrd;
	
	
	
	@FindBy(xpath = "//button[text()='Go']")
	WebElement go;
	
	@FindBy(xpath = "//*[@id=\"id_firstname\"]")
	WebElement firstname;
	
	@FindBy(xpath = "//*[@id='id_lastname']")
	WebElement lastname;
	
	@FindBy(xpath = "//*[@id='id_email']")
	WebElement emailId;
	
	@FindBy(xpath = "//*[@id='id_submitbutton']")
	WebElement userBtn;
	
	@FindBy(xpath = "//*[@id='id_saveanddisplay']")
	WebElement saveanddisplayBtn;
	
	@FindBy(xpath = "//*[@id='id_submitbutton']")
	WebElement savedisplayBtn;
	
	
	
	//*[@id="region-main"]/div/ul/li[3]/a
	
	@FindBy(xpath = "//a[contains(text(),'Courses') and @role='tab']")
	WebElement courses;
	
	@FindBy(xpath = "//a[@aria-controls='id_courseformathdrcontainer']")
	WebElement coursesformate;
	
	@FindBy(xpath = "//*[@id='id_format']")
	WebElement format;
	
	@FindBy(xpath = "//*[@id='id_activitytype']")
	WebElement activityType;
	
	@FindBy(xpath = "//*[@id='id_name']")
	WebElement scormName;
	
	
	
	@FindBy(xpath = "//*[@id=\"id_activitytype\"]/option[text()='SCORM package']")
	WebElement SCORMpackage;
	
	@FindBy(xpath = "//*[@id='id_format']/option[text()='Single activity format']")
	WebElement singleFormat;
	
	
	@FindBy(xpath = "//a[text()='Add a new course']")
	WebElement addcourses;
	
	@FindBy(xpath = "//input[@id='id_fullname']")
	WebElement fullname;
	
	@FindBy(xpath = "//input[@id='id_shortname']")
	WebElement shortname;
	
	@FindBy(xpath = "//*[@id='id_enddate_enabled']")
	WebElement endEnabled;
	
	
	@FindBy(xpath = "//*[@title='Add...']")
	WebElement addFile;
	
	@FindBy(xpath = "//*[@name='repo_upload_file']")
	WebElement uploadFile;
	@FindBy(xpath = "(//*[@value='Enrol users'])[1]")
	WebElement enrolUser;
	
	@FindBy(xpath = "(//*[contains(@id,'drop-down') and @role='menuitem'])[1]")
	WebElement courseDownDrop;
	

	@FindBy(xpath = "//a[contains(text(),'Participants')]")
	WebElement participantsOption;
	
	
	@FindBy(xpath = " //*[@placeholder=\"Search\" and @role='combobox']")
	WebElement search;
	
	
	@FindBy(xpath = " //form//div[2]//ul[@role='listbox']//li")
	WebElement select;
	
	@FindBy(xpath = "//button[text()='Enrol users']")
	WebElement enrlUser;
	
	
	
	
	
	@FindBy(xpath = "//button[text()='Upload this file']")
	WebElement uploadBtn;
	
	@FindBy(xpath = "//*[@id='coursesearchbox']")
	WebElement coursesearchbox;
	
	@FindBy(xpath = "//a[@aria-label=\"Courses\"]")
	WebElement coursedrop;
	
	
	
	@FindBy(xpath = "//*[@id='user-menu-toggle']")
	WebElement usermenu;
	
	@FindBy(xpath = "//*[@id='carousel-item-main']/a[contains(text(),'Log out')]")
	WebElement logout;
	
	
	
	@FindBy(xpath = "//button[text()='Enter']")
	WebElement Enterbtn;
	

	@FindBy(xpath = "(//a[contains(text(),'My courses')])[1]")
	WebElement mycourseTab;
	
	
			
	@FindBy(xpath = "//*[text()=' End tour ']")
	WebElement endTour;
	@FindBy(xpath = "//*/button[contains(text(),'Got it')]")
	WebElement gotit;
	
	
	static String courseName, usermoodle,passwordmoodle;; 
	RestApi rest;
	
	public void clickonLogout()
	{
		wait.until(ExpectedConditions.visibilityOf(usermenu));
		usermenu.click();
		wait.until(ExpectedConditions.visibilityOf(logout));
		logout.click();
	}
	
	
	public void clickOnaddcourses()
	{
		wait.until(ExpectedConditions.visibilityOf(addcourses));
		addcourses.click();
		
	}
	
	
	
	public void clickOncourses()
	{
		wait.until(ExpectedConditions.visibilityOf(courses));
		courses.click();
		
	}
	
	
	public Moodle() 
	{
		PageFactory.initElements(driver, this);
	}

	public void navigateToMoodleUrl()
	{
		reuse.waitforsec(4);
		driver.get(prop.getProperty("moodleurl"));
		
	}
	

	public void loginasStudent() throws InterruptedException
	{
//			
//			passwordmoodle="Test"+ "Ankuhs"+ "@1234567890";
		
		wait.until(ExpectedConditions.visibilityOf(username));
		username.clear();
		username.click();
		
		username.sendKeys(usermoodle);
		wait.until(ExpectedConditions.visibilityOf(password));
		password.click();
		password.sendKeys(passwordmoodle);
//		password.sendKeys("Ansh1G1@1234567890");
		login.click();
		Thread.sleep(5000);
		try {
			gotit.click();
		}
		catch(Exception e)
		{
			
		}
	}
	
	public  void selectCourse() throws InterruptedException
	{	
			Thread.sleep(5000);
			mycourseTab.click();
			Thread.sleep(5000);
			
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//span[@title]//span[contains(text(),'"+courseName+"')][2]"))));
		driver.findElement(By.xpath("//span[@title]//span[contains(text(),'"+courseName+"')][2]")).click();
//		driver.findElement(By.xpath("(//a/span[contains(text(),'HeartCode® Complete BLS(BLS)2216:49:00')])[2]")).click();
		
		Thread.sleep(5000);
		
		Enterbtn.click();
		
		
		Thread.sleep(5000);
		
//		driver.findElement(By.xpath("//a[@title='"+courseName+"']")).click();
//		Thread.sleep(5000);
//		
//		Enter.click();
		
		
		Thread.sleep(10000);
		
		

	}
	
	public  void selectCourse(String name) throws InterruptedException
	{	
			Thread.sleep(5000);
			mycourseTab.click();
			Thread.sleep(5000);
			
			String courseName=dataMap.get(name+"Moodle");
			
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//span[@title='"+courseName+"']//span[2]"))));
		driver.findElement(By.xpath("//span[@title='"+courseName+"']//span[2]")).click();
//		driver.findElement(By.xpath("(//a/span[contains(text(),'HeartCode® Complete BLS(BLS)2216:49:00')])[2]")).click();
		
		Thread.sleep(5000);
		
		Enterbtn.click();
		
		
		Thread.sleep(5000);
		
//		driver.findElement(By.xpath("//a[@title='"+courseName+"']")).click();
//		Thread.sleep(5000);
//		
//		Enter.click();
		
		
		Thread.sleep(10000);
		
		

	}
	
	public void loginasAdmin()
	{
		wait.until(ExpectedConditions.visibilityOf(username));
		
		
		username.click();
		username.sendKeys(prop.getProperty("moodleUserEmail"));
		wait.until(ExpectedConditions.visibilityOf(password));
		password.click();
		password.sendKeys(prop.getProperty("moodleUserPassword"));
		login.click();
	}
	
	
	public void clickOnSiteSetting()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(siteadmin));
		siteadmin.click();
		
	}
	

	public void clickOnuser()
	{
		wait.until(ExpectedConditions.visibilityOf(Users));
		Users.click();
	}
	public void clickOnadduser()
	{
		wait.until(ExpectedConditions.visibilityOf(adduser));
		adduser.click();
	}

	public void enterUserDetails(String email, String first, String last)
	{
		wait.until(ExpectedConditions.visibilityOf(usernme));
		usermoodle=email.toLowerCase();
		usernme.sendKeys(usermoodle);
		wait.until(ExpectedConditions.visibilityOf(passwrd));
		
		
		passwrd.click();
		
		newpasswrd.sendKeys(first + last + "@1234567890");
		
		passwordmoodle=first + last + "@1234567890";
		System.out.println("User "+usermoodle);
		System.out.println("Password "+passwordmoodle);
		wait.until(ExpectedConditions.visibilityOf(firstname));
		
		firstname.sendKeys(first);
		
       wait.until(ExpectedConditions.visibilityOf(lastname));
		
       lastname.sendKeys(last);
		
       emailId.sendKeys(email);
       
		
		userBtn.click();
	}
	
	
	public void enterCoursesDetails(String course) throws InterruptedException
	{
		String courseNme=course;
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();

		wait.until(ExpectedConditions.visibilityOf(fullname));
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("ddHH:mm:ss");
		String date = formatter.format(formatDate);
		System.out.println( date);
		courseName=course+date;
		fullname.sendKeys(course+date);
		wait.until(ExpectedConditions.visibilityOf(shortname));
		
		endEnabled.click();
		
		shortname.sendKeys(courseName);
		
	String enviroment=prop.getProperty("instance");
		
		
		driver.findElement(By.xpath("//*[contains(@id,'form_autocomplete_selection')]/span[text()='× ']")).click();
		
		
		driver.findElement(By.xpath("(//*/span[text()='▼' and contains(@id,'form_autocomplete_downarrow')])[1]")).click();
		
		reuse.waitforsec(4);
	   wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[contains(@id,'form_autocomplete_suggestions')]/li[text()='Preprod']"))));
	   
	   driver.findElement(By.xpath("//*[contains(@id,'form_autocomplete_suggestions')]/li[text()='Preprod']")).click();
	
		coursesformate.click();
		
		format.click();
	    singleFormat.click();
		
		
	    wait.until(ExpectedConditions.visibilityOf(activityType));
		activityType.click();
	    wait.until(ExpectedConditions.visibilityOf(SCORMpackage));
		
		SCORMpackage.click();
		
		saveanddisplayBtn.click();
wait.until(ExpectedConditions.visibilityOf(scormName));
		
    	scormName.sendKeys(course);
    	
    	wait.until(ExpectedConditions.visibilityOf(addFile));
		addFile.click();
		
		wait.until(ExpectedConditions.visibilityOf(uploadFile));
		
		uploadFile.sendKeys(Products.filePath);
		
		uploadBtn.click();
		
		Thread.sleep(5000);
		wait.until(ExpectedConditions.visibilityOf(savedisplayBtn));
		
		
	
		
		savedisplayBtn.click();
		
		
		
		wait.until(ExpectedConditions.visibilityOf(courseDownDrop));
		courseDownDrop.click();
		
		wait.until(ExpectedConditions.visibilityOf(participantsOption));
		participantsOption.click();
		wait.until(ExpectedConditions.visibilityOf(enrolUser));
		enrolUser.click();
	
		wait.until(ExpectedConditions.visibilityOf(search));
		search.sendKeys(Students.email);
		
		wait.until(ExpectedConditions.visibilityOf(select));
		select.click();
		
		Thread.sleep(3000);
		
		wait.until(ExpectedConditions.visibilityOf(enrlUser));
		
		enrlUser.click();
		
		Thread.sleep(3000);
		
//		courseNme
		dataMap.put(courseNme+"Moodle", courseName);
		
//		driver.findElement(By.xpath("//button[text()='Proceed to course content']")).click();
		
		
		
		
    	
	}
	
	public void courseSearchBox()
	{
	
		 ;
		 
		wait.until(ExpectedConditions.visibilityOf(coursesearchbox));
		coursesearchbox.sendKeys(courseName);
		
		wait.until(ExpectedConditions.visibilityOf(go));
		go.click();
		
		
		
	}
	
	
}
