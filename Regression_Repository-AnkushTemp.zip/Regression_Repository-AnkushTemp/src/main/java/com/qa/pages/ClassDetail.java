package com.qa.pages;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.qa.util.TestBase;

public class ClassDetail extends TestBase
{
	@FindBy(xpath = "//span[@class = 'fontRed']")
	WebElement licenseCount;
	
	@FindBy(xpath = "(//div[@id='licenseCount']//span[@class = 'fontRed'])[1]")
	WebElement assigningCountLocator;
	
	@FindBy(xpath = "(//div[@id='licenseCount']//span[@class = 'fontRed'])[2]")
	WebElement availableCountLocator;
	
	@FindBy(xpath = "//div[@id='licenseCount']")
	WebElement licenseMessage;
	
	@FindBy(xpath = "//a[text() = 'Add Student']")
	WebElement addStudentButton;

	@FindBy(xpath = "//input[@id = 'first_name']")
	WebElement studentFirstName;
	
	@FindBy(xpath = "//input[@id = 'last_name']")
	WebElement studentLastName;
	
	@FindBy(xpath = "//input[@id = 'email']")
	WebElement studentEmail;
	
	@FindBy(xpath = "//input[contains(@id , 'addStudent')]")
	WebElement addButton;
	
	@FindBy(xpath = "//*[text() = 'Showing 1 to 1 of 1 entries']")
	WebElement studentCount;
	
	@FindBy(xpath = "//a[@class = 'action_dropdown']//parent::div")
	WebElement StudentAction;
	
	@FindBy(xpath = "//a[text() = 'Update Completion' and not(@id)]")
	WebElement updateCompletion;
	
	@FindBy(xpath = "//input[@id = 'skill_update_date']")
	WebElement courseDateText;
	
	@FindBy(xpath = "//div[@class='datepicker-days']")
	WebElement calendarProduct;
	
	@FindBy(xpath = "//input[@id = 'updateBulkSkillsBtn' and not(@disabled)]")
	WebElement submitButton;	
	
	@FindBy(xpath = "(//span[@class = 'fontRed'])[1]")
	WebElement assignedLicenseCount;

	@FindBy(xpath = "//table[@id = 'assign_students_table']")
	WebElement assignStudentTable;
	
	@FindBy(xpath = "//table[@id = 'student_listing']")
	WebElement assignBulkStudentTable;
	
	@FindBy(xpath = "//a[text() = 'Import Student(s)']")
	WebElement importStudents;
	
	@FindBy(xpath = "//a[text() = 'Choose file']")
	WebElement chooseFileLink;
	
	@FindBy(xpath = "//a[@id = 'fileMsgDiv']")
	WebElement uploadedFile;
	
	@FindBy(xpath = "//*[text() = 'Upload']")
	WebElement uploadFileLink;
	
	@FindBy(xpath = "//div[@id = 'uploadedTable']//a")
	WebElement buttonFinish;
	
	@FindBy(xpath = "//div[@id = 'uploadedTable']//label")
	WebElement labelConfirm;
	
	public static int initialLicenseCount, laterLicenseCount,assigningCount,availableCount;
	public static String email, filePath;
	
	String datePick = "//td[contains(@class, 'day' ) and text() = ";
	String downloadPath = System.getProperty("user.dir") + prop.getProperty("downloadPath");
	String fileName;
	
	public ClassDetail() 
	{
		PageFactory.initElements(driver, this);
	}
	
	public void getInitialLicenseCount()
	{
		WebDriverWait wait = new WebDriverWait(driver, 60);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		try
		{
			Thread.sleep(5000);
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				Thread.sleep(5000);
			}
		wait.until(ExpectedConditions.visibilityOf(licenseCount));
		}
		catch(Exception e)
		{
			driver.navigate().refresh();
			getInitialLicenseCount();
		}
		String message = licenseMessage.getText();
		if(message.toLowerCase().contains("assigning"))
		{
			if(!(licenseCount.getText().trim().toLowerCase().equals("unlimited")))
				initialLicenseCount = Integer.parseInt(availableCountLocator.getText());
			else
				initialLicenseCount = 0;
		}
		else
		{
			if(!(licenseCount.getText().trim().toLowerCase().equals("unlimited")))
				initialLicenseCount = Integer.parseInt(assigningCountLocator.getText());
			else
				initialLicenseCount = 0;
		}
		
	}
	
	public void clickAddStudent()
	{
		WebDriverWait wait = new WebDriverWait(driver, 90);
		wait.until(ExpectedConditions.visibilityOf(addStudentButton));
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click()", addStudentButton);
		//addStudentButton.click();
		wait.until(ExpectedConditions.visibilityOf(studentFirstName));
	}
	
	public void enterStudentDetails()
	{
		WebDriverWait wait = new WebDriverWait(driver, 90);
		wait.until(ExpectedConditions.visibilityOf(studentFirstName));
		studentFirstName.click();
		studentFirstName.clear();
		studentFirstName.sendKeys("Std1");
		studentLastName.click();
		studentLastName.clear();
		studentLastName.sendKeys("last");
		studentEmail.click();
		studentEmail.clear();
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		date = date.replace(" ", "").replace(":", "").replace("-", "");
		email =User.getUserEmail( date);
		studentEmail.sendKeys(email);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", addButton);
	}
	
	public void validateStudentAdded()
	{
		WebDriverWait wait = new WebDriverWait(driver, 90);
		wait.until(ExpectedConditions.visibilityOf(studentCount));
	}
	
	public void getLaterLicenseCount()
	{
		WebDriverWait wait = new WebDriverWait(driver, 90);
		wait.until(ExpectedConditions.visibilityOf(licenseCount));
		laterLicenseCount = Integer.parseInt(licenseCount.getText());
	}
	
	public void clickStudentActionUpdateCompletion()
	{
		WebDriverWait wait = new WebDriverWait(driver, 90);
		wait.until(ExpectedConditions.visibilityOf(StudentAction));
		StudentAction.click();
		wait.until(ExpectedConditions.visibilityOf(updateCompletion));
		updateCompletion.click();
	}
	
	public void markComplete()
	{
		WebDriverWait wait = new WebDriverWait(driver, 90);
		wait.until(ExpectedConditions.visibilityOf(courseDateText));
		DateFormat dateFormat = new SimpleDateFormat("dd");
		Date dateCalendar = new Date();
		Calendar cal = Calendar.getInstance();
		String formattedStartDate = dateFormat.format(dateCalendar);
		String formattedEndDate = dateFormat.format(cal.getTime());
		System.out.println("Current date is " + formattedStartDate + " and end date is " + formattedEndDate);
		courseDateText.click();
		wait.until(ExpectedConditions.visibilityOf(calendarProduct));
		WebElement reqDate = driver.findElement(By.xpath(datePick + formattedEndDate + " and not(contains(@class, 'disabled day' ))]"));
		reqDate.click();		
	}
	
	public void clickUpdateButton()
	{
		WebDriverWait wait = new WebDriverWait(driver, 90);
		wait.until(ExpectedConditions.visibilityOf(submitButton));
		submitButton.click();
	}
	
	public void getAssignedLicenseCount()
	{
		try {
		WebDriverWait wait = new WebDriverWait(driver, 90);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		String val = js.executeScript("return document.readyState").toString();
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
		}
		Thread.sleep(5000);
		wait.until(ExpectedConditions.visibilityOf(assignedLicenseCount));
		laterLicenseCount = Integer.parseInt(assignedLicenseCount.getText());
		}
		catch(Exception e)
		{
			
		}
	}
	
	public void validateLicenseAssign()
	{
		WebDriverWait wait = new WebDriverWait(driver, 90);
		wait.until(ExpectedConditions.visibilityOf(assignStudentTable));
	}

	public void clickImportStudent()
	{
		WebDriverWait wait = new WebDriverWait(driver, 90);
		wait.until(ExpectedConditions.visibilityOf(importStudents));
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click()", importStudents);
	}
	
	public void prepareFile(int count)
	{
		int m=0;
		boolean dwnld = false;
		do 
		{
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			m++;
		}
		while(dwnld == false);
		addFileData(count); 
		readandUpdateFile();
		
	}
	
	public boolean isFileDownloaded_Ext(String dirPath, String ext){
		boolean flag=false;
	    File dir = new File(dirPath);
	    File[] files = dir.listFiles();
	    if (files != null)
	    {
	    	 for (int i = 0; i < files.length; i++) 
	 	    {
	 	    	if(files[i].getName().contains(ext)&& !(files[i].getName().contains(".crdownload"))) 
	 	    	{
	 	    		fileName = files[i].getName();
	 	    		filePath = files[i].getAbsolutePath();
	 	    		filePath = filePath.replace(".crdownload", "");
					flag=true;
	 	    		break;
	 	    	}
	 	    }
	    }
	    
	    return flag;
	}
	
	public void readandUpdateFile()
	{
		try 
		{
			String file ="";
			WebDriverWait wait = new WebDriverWait(driver, 30);
		int m=0;
		do 
		{
			wait.until(ExpectedConditions.visibilityOf(chooseFileLink));
			driver.findElement(By.xpath("//*[@id = 'customFile']")).sendKeys(filePath);
			file = driver.findElement(By.xpath("//*[@id = 'fileMsgDiv']//a")).getText();
			//file = uploadedFile.getText();
			System.out.println(file + " and file length is " + file.length());
			Thread.sleep(5000);
			if(m==pagload)
				break;
			m++;
		}
		while(file.length() == 0);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	public void addFileData(int userCount)
	{
		try 
		{
			boolean dwnld = false;
			int m=0;
			do 
			{
				dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
				if(m==pagload)
					break;
				else
				{
					try {
						Thread.sleep(550);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				m++;
			}
			while(dwnld == false);
			Thread.sleep(3000);
			File file = new File(filePath); 
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			CSVWriter writer = new CSVWriter(new FileWriter(filePath));
			DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
			Calendar cal = Calendar.getInstance();
			String email = dateFormat.format(cal.getTime());
			String formattedEmail = email.replace(":", "");
			List<String[]> list = new ArrayList<String[]>();
			list.add(header);
			for(int i=1; i<= userCount; i++)
			{
				String row[] = {"Ansh" + i, "G" + i, User.getUserEmail(  i + formattedEmail) };
				list.add(row);
			}
			writer.writeAll(list);
			writer.flush();
			writer.close();
			csvReader.close();
	} 
		catch (Exception e) 
		{
		e.printStackTrace();
		}
	}
	
	public void uploadFile(int count)
	{
		WebDriverWait wait = new WebDriverWait(driver, 180);
		wait.until(ExpectedConditions.visibilityOf(uploadFileLink));
		uploadFileLink.click();
		wait.until(ExpectedConditions.visibilityOf(labelConfirm));
		String labelCount = labelConfirm.getText().split(" ")[0].trim();
		Assert.assertTrue(labelCount.equalsIgnoreCase(String.valueOf(count)));
		buttonFinish.click();
	}
	
	public void deleteFile(String path)
	{
		try {
			System.out.println("delete file path is " + path);
			File file = new File(path);
			Thread.sleep(5000);
			file.delete();
			boolean dwnld = false;
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");	
			System.out.println(dwnld);
			int m=0;
			while(dwnld)
			{
				file = new File(filePath);
				file.delete();
				dwnld = isFileDownloaded_Ext(downloadPath, ".csv");	
				
				if(m==pagload)
					break;
				else
				{
					try {
						Thread.sleep(550);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				m++;
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	public void validateLicenseAssignBulk()
	{
		WebDriverWait wait = new WebDriverWait(driver, 90);
		wait.until(ExpectedConditions.visibilityOf(assignBulkStudentTable));
	}
	
	public void getAssigningLicenseCount()
	{
		WebDriverWait wait = new WebDriverWait(driver, 60);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		try
		{
			Thread.sleep(5000);
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				Thread.sleep(5000);
			}
		wait.until(ExpectedConditions.visibilityOf(assigningCountLocator));
		}
		catch(Exception e)
		{
			driver.navigate().refresh();
			getAssigningLicenseCount();
		}
		if(!(assigningCountLocator.getText().trim().toLowerCase().equals("unlimited")))
			assigningCount = Integer.parseInt(assigningCountLocator.getText());
		else
			assigningCount = 0;
	}

	public void getAvailableLicenseCount()
	{
		WebDriverWait wait = new WebDriverWait(driver, 60);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		try
		{
			Thread.sleep(5000);
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				Thread.sleep(5000);
			}
		wait.until(ExpectedConditions.visibilityOf(availableCountLocator));
		}
		catch(Exception e)
		{
			driver.navigate().refresh();
			getAvailableLicenseCount();
		}
		if(!(availableCountLocator.getText().trim().toLowerCase().equals("unlimited")))
			availableCount = Integer.parseInt(availableCountLocator.getText());
		else
			availableCount = 0;
	}
	
	public void validateAssignMessageAfterStudentAdd(int assignCount, int availCount)
	{
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOf(licenseMessage));
		String actualMessage = licenseMessage.getText();
		String expectedMessage = "Assigning " + (availCount - assignCount) + " from " + availCount + " available licenses";
		Assert.assertTrue(actualMessage.equals(expectedMessage));
	}

	
	

	


}
