package com.qa.pages;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.json.simple.parser.JSONParser;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;

import com.jayway.jsonpath.JsonPath;
import com.manybrain.mailinator.client.MailinatorClient;
import com.manybrain.mailinator.client.message.GetInboxRequest;
import com.manybrain.mailinator.client.message.GetMessageRequest;
import com.manybrain.mailinator.client.message.Inbox;
import com.manybrain.mailinator.client.message.Message;
import com.manybrain.mailinator.client.message.Sort;
import com.qa.util.TestBase;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class MailTrapAPI extends TestBase{

	MailinatorClient mailinatorClient = new MailinatorClient(prop.getProperty("APIToken"));
	String messageID;
	public static String email;

	String getMailBody(String messageID)
	{
    
		
		String api = "https://mailtrap.io/api/accounts/"+prop.getProperty("accountID")+"/inboxes/"+prop.getProperty("inboxes")+"/messages/"+messageID;


		
		RestAssured.baseURI= api;
		RequestSpecification httpRequest = RestAssured.given();
		//Passing the resource details .queryParam("account_id","1516123").queryParam("inboxes", "2150813")
		Response res = httpRequest.header("Content-Type", "application/json")
				  .header("Api-Token", prop.getProperty("APIToken")).get("/body.htmlsource");

		ResponseBody body = res.body();
		String rbdy = body.asString();
		return rbdy;
		
	}
	public void validatemailbody(String validate,String  subject)
	{
		if(AssignmentReport.checkifParmeterAvailable(subject))
			subject=AssignmentReport.getParmeterAvailable(subject);
     
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{
			
		}
		String messageid=getmessageId(subject,validate);

		System.out.println(messageid);
	    
		String body=getMailBody( messageid);
		
		Boolean flag=false;
		String[] contentRow = body.split("\n");
		for(int i = 0; i < contentRow.length; i++)
		{
			System.out.println(contentRow[i]);
			if(contentRow[i].contains(NotificationSettings.date))
			{
				flag = true;
				break;
			}
		}
		Assert.assertTrue(flag);
	}

	public void validatemailbodyDetails(String validate,String  subject,int plan)
	{
		if(AssignmentReport.checkifParmeterAvailable(subject))
			subject=AssignmentReport.getParmeterAvailable(subject);
     
		String course=subject.split(" - ")[1];
		System.out.println(course);
		if(courseListName.containsKey(course+"Option"))
		{
			subject=subject.replace(course, courseListName.get(course+"Option").toString()) 	;
			
		}
		if(courseListName.containsKey(course+"Option"))
			course= courseListName.get(course+"Option").toString();
		System.out.println(course);
	    
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{
			
		}
		String messageid=getmessageId(subject,validate);

		System.out.println(messageid);
	    
		String body=getMailBody( messageid);
		
		Boolean flag=false;
		String[] contentRow = body.split("\n");
		System.out.println(body);
		Assert.assertTrue(body.contains("Your payment was successful and the course has been added to your account.<br>"));
		Assert.assertTrue(body.contains("Please find the order and course details below:<br><br>"));
		Assert.assertTrue(body.contains("Course name: "+course));
		Assert.assertTrue(body.contains("Order number: "+EndUser.OrderID));
		Assert.assertTrue(body.contains("Transaction number: "+EndUser.TransactionRefNumber));
		Assert.assertTrue(body.contains("Amount paid: "+EndUser.Tpaid.split(" ")[1]+" "+EndUser.Tpaid.split(" ")[0]));
		Assert.assertTrue(body.contains("Please note that you will not be able to access or review the course after the above mentioned expiry date."));
		Assert.assertTrue(body.contains("Please note that you will not be able to access or review the course after the above mentioned expiry date."));
		Assert.assertTrue(body.contains("You can download the order receipt from <a href='"));
		Assert.assertTrue(body.contains("To access your course anytime, please login to "+OrganizationDetails.subDomain+" and go to the My Programs section.<br><br>"));
		
		Assert.assertTrue(body.contains(" If you need assistance please contact RQI Support using the information below:<br><br>"));
		 
		Assert.assertTrue(body.contains(" Thank you,<br>"));
		
		Assert.assertTrue(body.contains(" The RQI Partners and RQI1Stop Team"));
		Assert.assertTrue(body.contains("@rqipartners.com"));
		Assert.assertTrue(body.contains(" Email : "));
		
		Assert.assertTrue(body.contains("Phone :   1-800-594-9935 Option #4<br><br>"));
        

          
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, plan);
		String formattedStartDate = dateFormat.format(cal.getTime());
 System.out.println(formattedStartDate);
		Assert.assertTrue(body.contains("Course expiry date: "+formattedStartDate));
		
	
	}
	
	public void validatemailbodyDetailsLMS(String validate,String  subject,int plan)
	{
		if(AssignmentReport.checkifParmeterAvailable(subject))
			subject=AssignmentReport.getParmeterAvailable(subject);
     
		String course=subject.split(" - ")[1];
		System.out.println(course);
		if(courseListName.containsKey(course+"Option"))
		{
			subject=subject.replace(course, courseListName.get(course+"Option").toString()) 	;
			
		}
		if(courseListName.containsKey(course+"Option"))
			course= courseListName.get(course+"Option").toString();
		System.out.println(course);
	    
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{
			
		}
		String messageid=getmessageId(subject,validate);

		System.out.println(messageid);
	    
		String body=getMailBody( messageid);
		
		Boolean flag=false;
		String[] contentRow = body.split("\n");
		System.out.println(body);
		Assert.assertTrue(body.contains("Your payment was successful and the course has been added to your account.<br>"));
		Assert.assertTrue(body.contains("Please find the order and course details below:<br><br>"));
		Assert.assertTrue(body.contains("Course name: "+course));
		Assert.assertTrue(body.contains("Order number: "+EndUser.OrderID));
		Assert.assertTrue(body.contains("Transaction number: "+EndUser.TransactionRefNumber));
		Assert.assertTrue(body.contains("Amount paid: "+EndUser.Tpaid.split(" ")[1]+" "+EndUser.Tpaid.split(" ")[0]));
		Assert.assertTrue(body.contains("Please note that you will not be able to access or review the course after the above mentioned expiry date."));
		Assert.assertTrue(body.contains("Please note that you will not be able to access or review the course after the above mentioned expiry date."));
		Assert.assertTrue(body.contains("You can download the order receipt from <a href='"));
		Assert.assertTrue(body.contains("To access your course anytime, please login to your Organization's Learning Management System.<br><br>"));
		
		Assert.assertTrue(body.contains(" If you need assistance please contact RQI Support using the information below:<br><br>"));
		 
		Assert.assertTrue(body.contains(" Thank you,<br>"));
		
		Assert.assertTrue(body.contains(" The RQI Partners and RQI1Stop Team"));
		Assert.assertTrue(body.contains("@rqipartners.com"));
		Assert.assertTrue(body.contains(" Email : "));
		
		Assert.assertTrue(body.contains("Phone :   1-800-594-9935 Option #4<br><br>"));
        

          
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, plan);
		String formattedStartDate = dateFormat.format(cal.getTime());
 System.out.println(formattedStartDate);
		Assert.assertTrue(body.contains("Course expiry date: "+formattedStartDate));
		
	
	}
	
	public void validatemailbodyDetails(String validate,String  subject)
	{
		if(AssignmentReport.checkifParmeterAvailable(subject))
			subject=AssignmentReport.getParmeterAvailable(subject);
     
		String course=subject.split(" - ")[1];
		System.out.println(course);
		if(courseListName.containsKey(course+"Option"))
		{
			subject=subject.replace(course, courseListName.get(course+"Option").toString()) 	;
			
		}
		if(courseListName.containsKey(course+"Option"))
			course= courseListName.get(course+"Option").toString();
		System.out.println(course);
	    
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{
			
		}
		String messageid=getmessageId(subject,validate);

		System.out.println(messageid);
	    
		String body=getMailBody( messageid);
		
		Boolean flag=false;
		String[] contentRow = body.split("\n");
		System.out.println(body);
		
		System.out.println(body.split("You can download the order receipt from <a href='")[1].split("'>here</a>")[0]);
		links=body.split("You can download the order receipt from <a href='")[1].split("'>here</a>")[0];
		driver.navigate().to(links);;
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{
			
		}
		Boolean dflag=	Products.isFileDownloaded_Ext (Products.downloadPath , ".pdf");

	    Assert.assertTrue(dflag,"Error Order Receipt not found");;
		
		
			
	
	}
	String getmessageId(String subject,String validate)
	{
		String  messageID=null;
		
		String api = "https://mailtrap.io/api/accounts/"+prop.getProperty("accountID")+"/inboxes/"+prop.getProperty("inboxes");


		
		RestAssured.baseURI= api;
		RequestSpecification httpRequest = RestAssured.given();
		//Passing the resource details .queryParam("account_id","1516123").queryParam("inboxes", "2150813")
		Response res = httpRequest.header("Content-Type", "application/json")
				  .header("Api-Token", prop.getProperty("APIToken")).get("/messages");

		ResponseBody body = res.body();
		String rbdy = body.asString();
		
		System.out.println();
		//JSONParser jsonParser = new JSONParser();
		List<Object> mails=JsonPath.read(rbdy, "$.[?(@.to_email=='"+User.userEmail+"')]");
		rbdy=JsonPath.read(rbdy, "$.[?(@.to_email=='"+User.userEmail+"')]").toString();	  
		

		for (int i=0;i<mails.size();i++) {
			
			Object mail=mails.get(i);
			System.out.println("Email id "+fetchDetails(mail,"to_email"));
			System.out.println("Message id "+fetchDetails(mail,"id") );
			System.out.println("User Email "+User.userEmail);
			System.out.println("Subject id "+fetchDetails(mail,"subject"));
			
			
			if(User.userEmail.contains(fetchDetails(mail,"to_email"))&& fetchDetails(mail,"subject").contains(subject))
			{
				messageID =fetchDetails(mail,"id") ;
				System.out.println(messageID);
				break;
			}
		}

		if(messageID==null&&(!validate.contains("validate if not existing")))
		{
			Assert.fail("Mail is not found "+rbdy);
		}
		
		return messageID;
	}
	
	String links;
	void validatemail(String validate,String  subject)
	{
		String messageid=getmessageId(subject,validate);

		System.out.println(messageid);
//		Message m = mailinatorClient.request(new GetMessageRequest(
//				"laerdalonline.com", 
//				messageid.split("-")[0], 
//				messageid));
		String mailBody=getMailBody(messageid);;
		System.out.println("Mail body: "+mailBody);
		if(mailBody.split("<a href=\"").length>1)
		links=mailBody.split("<a href=\"")[1].split("\">click here</a>")[0];

	}

	
	
	void navigatechangePassword()
	{
		driver.navigate().to(links);
		KeyClock key=new KeyClock();
		key.setNewPwd();
	}

	public void validateifmail(String validate,String subject) throws InterruptedException
	{

		if(AssignmentReport.checkifParmeterAvailable(subject))
			subject=AssignmentReport.getParmeterAvailable(subject);
     
		switch(validate.toLowerCase())
		{
		case "change password": Thread.sleep(10000);
		validatemail(validate.toLowerCase(),subject);
		navigatechangePassword();
		break;
		case "validate if existing":validatemail(validate.toLowerCase(),subject);
		break;
		case "validate if not existing":validatemail(validate.toLowerCase(),subject);
		break;

		}

	}

	
	public void clickOnPwdChangeLink_Admin(String validate,String subject) throws InterruptedException
	{

		if(AssignmentReport.checkifParmeterAvailable(subject))
			subject=AssignmentReport.getParmeterAvailable(subject);
     
		validatemail(validate.toLowerCase(),subject);
		driver.navigate().to(links);
	
	}

	public void validatethnoemailisTriggred()
	{
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{
			
		}
		String  messageID=null;
		
	String api = "https://mailtrap.io/api/accounts/"+prop.getProperty("accountID")+"/inboxes/"+prop.getProperty("inboxes");


		
		RestAssured.baseURI= api;
		RequestSpecification httpRequest = RestAssured.given();
		//Passing the resource details .queryParam("account_id","1516123").queryParam("inboxes", "2150813")
		Response res = httpRequest.header("Content-Type", "application/json")
				  .header("Api-Token", prop.getProperty("APIToken")).get("/messages");

		ResponseBody body = res.body();
		String rbdy = body.asString();
		
		System.out.println();
		//JSONParser jsonParser = new JSONParser();
		List<Object> mails=JsonPath.read(rbdy, "$.[?(@.to_email=='"+User.userEmail+"')]");
		rbdy=JsonPath.read(rbdy, "$.[?(@.to_email=='"+User.userEmail+"')]").toString();	  
		

		int mailcount=0;
	
		 for (int i=0;i<mails.size();i++) {
				
				Object mail=mails.get(i);
				System.out.println("Email id "+fetchDetails(mail,"to_email"));
				System.out.println("Message id "+fetchDetails(mail,"id") );
				System.out.println("User Email "+User.userEmail);
				System.out.println("Subject id "+fetchDetails(mail,"subject"));
				
		
				if(User.userEmail.contains(fetchDetails(mail,"to_email")))
	     	{
					messageID =fetchDetails(mail,"id") ;
					
				mailcount++;
			}
		}

		
		
		if(mailcount!=0)
		{
			Assert.fail("Mail is  found "+rbdy);
		}
		
	}
	public void validatethemailcount(String subject,int count)
	{
		reuse.waitforsec(4);
		if(AssignmentReport.checkifParmeterAvailable(subject))
			subject=AssignmentReport.getParmeterAvailable(subject);
     
String  messageID=null;
String mailsubject=null;
	
		String api = "https://mailtrap.io/api/accounts/"+prop.getProperty("accountID")+"/inboxes/"+prop.getProperty("inboxes");


		
		RestAssured.baseURI= api;
		RequestSpecification httpRequest = RestAssured.given();
		//Passing the resource details .queryParam("account_id","1516123").queryParam("inboxes", "2150813")
		Response res = httpRequest.header("Content-Type", "application/json")
				  .header("Api-Token", prop.getProperty("APIToken")).get("/messages");

		ResponseBody body = res.body();
		String rbdy = body.asString();
		
		System.out.println();
		//JSONParser jsonParser = new JSONParser();
		List<Object> mails=JsonPath.read(rbdy, "$.[?(@.to_email=='"+User.userEmail+"')]");
		rbdy=JsonPath.read(rbdy, "$.[?(@.to_email=='"+User.userEmail+"')]").toString();	  
		

		int mailcount=0;
	
		 for (int i=0;i<mails.size();i++) {
				
				Object mail=mails.get(i);
				System.out.println("Email id "+fetchDetails(mail,"to_email"));
				System.out.println("Message id "+fetchDetails(mail,"id") );
				System.out.println("User Email "+User.userEmail);
				System.out.println("Subject id "+fetchDetails(mail,"subject"));
				
		
				if(User.userEmail.contains(fetchDetails(mail,"to_email"))&& fetchDetails(mail,"subject").contains(subject))
	     	{
					messageID =fetchDetails(mail,"id") ;
					
				mailcount++;
			}
		}

		
		if(mailcount!=count)
		{
			Assert.fail("Mail is not found "+rbdy);
		}
		
	}


	public String getmailsubject()
	{
		
String  messageID=null;
String mailsubject=null;
	
		String api = "https://mailtrap.io/api/accounts/"+prop.getProperty("accountID")+"/inboxes/"+prop.getProperty("inboxes");


		
		RestAssured.baseURI= api;
		RequestSpecification httpRequest = RestAssured.given();
		//Passing the resource details .queryParam("account_id","1516123").queryParam("inboxes", "2150813")
		Response res = httpRequest.header("Content-Type", "application/json")
				  .header("Api-Token", prop.getProperty("APIToken")).get("/messages");

		ResponseBody body = res.body();
		String rbdy = body.asString();
		
		System.out.println();
		//JSONParser jsonParser = new JSONParser();
		List<Object> mails=JsonPath.read(rbdy, "$.[?(@.to_email=='"+User.userEmail+"')]");
		rbdy=JsonPath.read(rbdy, "$.[?(@.to_email=='"+User.userEmail+"')]").toString();	  
		

	
      for (int i=0;i<mails.size();i++) {
			
			Object mail=mails.get(i);
			System.out.println("Email id "+fetchDetails(mail,"to_email"));
			System.out.println("Message id "+fetchDetails(mail,"id") );
			System.out.println("User Email "+User.userEmail);
			System.out.println("Subject id "+fetchDetails(mail,"subject"));
			

			
			if(User.userEmail.contains(fetchDetails(mail,"to_email")))
			{
				if(mailsubject==null)
				mailsubject=fetchDetails(mail,"subject");
				else
				mailsubject =mailsubject+","+fetchDetails(mail,"subject");
			}
		}

		if(mailsubject==null)
		{
			Assert.fail("Mails not found "+rbdy);
		}
		return mailsubject;
	}

	
	String fetchDetails(Object mail,String  key)
	{
		return JsonPath.parse(mail).read("$['"+key+"']").toString()	;
	}
	
	public String getupdatedSubjectTitle(String subject)
	{
		
		String course=subject.split(" - ")[1];
	System.out.println(course);
	if(courseListName.containsKey(course+"Option"))
	{
		subject=subject.replace(course, courseListName.get(course+"Option").toString()) 	;
		
	}
	return subject;
	}

	public String validateMailAsPerSubject(String subjectLine)
	{
		reuse.waitforsec(10);
		messageID = null;
		if(Scrom.orderSummaryCourse != null)
			subjectLine = subjectLine + Scrom.orderSummaryCourse;
		System.out.println(subjectLine);
		String emailID = getEmail();
		String inboxAPI = "https://mailtrap.io/api/accounts/" + TestBase.prop.getProperty("accountID") + "/inboxes/" + TestBase.prop.getProperty("inboxes");
		baseURI = inboxAPI;
		String response = given().header("Content-Type", "application/json").header("Api-Token", prop.getProperty("APIToken")).get("/messages").body().asString();
		List<Object> mails=JsonPath.read(response, "$.[?(@.to_email == '" + emailID + "')]");
		for(int i= 0; i < mails.size(); i++) {
			Object email = mails.get(i);
			String subject = fetchDetails(email, "subject").replace(" ", " ");
			System.out.println(subject);
			if(!(subject == null) && subject.equals(subjectLine)) {
				System.out.println(mails.get(i));
				messageID = fetchDetails(email, "id");
				break;
			}			
		}
		if(messageID==null && (!subjectLine.contains("validate if not existing")))
		{
			Assert.fail("Mail is not found ");
		}
		return messageID;
	}
	
	String getEmail() {
		if(User.userEmail != null) {
				email= User.userEmail;
			}
			else if(ClassDetail.email != null) {
				email = ClassDetail.email;
			}
			else {
				email = Students.email;
			}
		return email;
	}
	
	public void validateEmailContentCourseCancellation(String msgID)
	{
		String inboxAPI = "https://mailtrap.io/api/accounts/" + TestBase.prop.getProperty("accountID") + "/inboxes/" + TestBase.prop.getProperty("inboxes");
		baseURI = inboxAPI;
		String response = given().header("Content-Type", "application/json").header("Api-Token", prop.getProperty("APIToken")).
				get("/messages/" + msgID + "/body.html").body().asString();
		String expectedEmail = "Hello " + User.userFirstName + "," + System.lineSeparator() +
				"The cancellation and refund request has been initiated. Please find the order details below:" + System.lineSeparator() +
				"Course name: " + Scrom.orderSummaryCourse + System.lineSeparator() + 
				"Order number: " + Scrom.orderID + System.lineSeparator() + 
				"Transaction number: " + Scrom.orderTransaction + System.lineSeparator() + 
				"Refund transaction number: " + Scrom.transactionNumber + System.lineSeparator() + 
				"Refund amount: " + Scrom.orderAmount.split(" ")[1] + " " + Scrom.orderAmount.split(" ")[0] + System.lineSeparator() + System.lineSeparator() +
				"If you need assistance, please contact RQI Support using the information below:" + System.lineSeparator() + System.lineSeparator() +
				"Email: ProEdSupport@rqipartners.com" + System.lineSeparator() + System.lineSeparator() +
				"Phone: 1-800-594-9935 Option #4" + System.lineSeparator() + System.lineSeparator() +
				"Thank you," + System.lineSeparator() +
				"The RQI Partners and RQI1Stop Team";
		System.out.println(expectedEmail);
		String uiEmail[] = response.split("\n");
		String codeEmail[] = expectedEmail.split( System.lineSeparator());
		for(int i = 0; i < codeEmail.length; i++) {
			System.out.println(codeEmail[i].trim());
			System.out.println(uiEmail[i+1].replace("<br>","").replace(" ", " ").trim());
			Assert.assertEquals(codeEmail[i].trim(), uiEmail[i+1].replace("<br>","").replace(" ", " ").trim());
		}
		Assert.assertEquals(uiEmail.length - 2, codeEmail.length);
	}

	public String getEmailBody(String msgID) {
		String inboxAPI = "https://mailtrap.io/api/accounts/" + TestBase.prop.getProperty("accountID") + "/inboxes/" + TestBase.prop.getProperty("inboxes");
		baseURI = inboxAPI;
		String response = given().header("Content-Type", "application/json").header("Api-Token", prop.getProperty("APIToken")).
				get("/messages/" + msgID + "/body.html").body().asString();
		String url = response.split("href=\"")[1].split("\">click here")[0].toString();
		System.out.println(url);
		Assert.assertFalse(!(url.length() > 0));
		return url;
	}
	
	public void navigateURL(String url) {
		driver.navigate().to(url);
	}
	
	
	public void validatemailbodyText(String text,String  subject)
	{
		if(AssignmentReport.checkifParmeterAvailable(subject))
			subject=AssignmentReport.getParmeterAvailable(subject);
     
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{
			
		}
		String messageid=getmessageId(subject,"Validate If Existing");

		System.out.println(messageid);
	    
		String body=getMailBody( messageid);
		
		Boolean flag=false;
		String[] contentRow = body.split("\n");
		for(int i = 0; i < contentRow.length; i++)
		{
			System.out.println(contentRow[i]);
			if(contentRow[i].contains(text))
			{
				flag = true;
				break;
			}
		}
		Assert.assertFalse(flag);
	}
	
	public void validateEmailContentCE_Type(String msgID)
	{
		String inboxAPI = "https://mailtrap.io/api/accounts/" + TestBase.prop.getProperty("accountID") + "/inboxes/" + TestBase.prop.getProperty("inboxes");
		baseURI = inboxAPI;
		String response = given().header("Content-Type", "application/json").header("Api-Token", prop.getProperty("APIToken")).
				get("/messages/" + msgID + "/body.html").getBody().asString();
		String expectedEmail = "Hello " + User.userFirstName + "," + System.lineSeparator() +
				"The RQI for NRP CE Report that you requested is now ready for download." + System.lineSeparator() + "Please "+
				 System.lineSeparator() +"Click Here" + System.lineSeparator() +" to download the report." +
				 System.lineSeparator() + "Note: You may be required to login to RQI1Stop after clicking the link to" + 
				 System.lineSeparator() + "download the report." +
				 System.lineSeparator() + "Thank you," +System.lineSeparator() +
				 "The RQI Partners and RQI1Stop Team";
		System.out.println(expectedEmail);
		String codeEmail[] = expectedEmail.split( System.lineSeparator());
		for(int i = 0; i < codeEmail.length; i++) {
			Assert.assertTrue(response.contains(codeEmail[i]));
		}
	}
	
	public String getLink(String msgID) {
		String inboxAPI = "https://mailtrap.io/api/accounts/" + TestBase.prop.getProperty("accountID") + "/inboxes/" + TestBase.prop.getProperty("inboxes");
		baseURI = inboxAPI;
		String response = given().header("Content-Type", "application/json").header("Api-Token", prop.getProperty("APIToken")).
				get("/messages/" + msgID + "/body.html").body().asString();
		//String url = response.split("href=\"")[1].split("\">click here")[0].toString();
		System.out.println(response);
		String url = response.split("href=")[1].split(">")[0].toString();;
		System.out.println(url);
		Assert.assertFalse(!(url.length() > 0));
		return url;
	}

	public void 	validateEmailContentUtilizationReport(String msgID)
	{
		String inboxAPI = "https://mailtrap.io/api/accounts/" + TestBase.prop.getProperty("accountID") + "/inboxes/" + TestBase.prop.getProperty("inboxes");
		baseURI = inboxAPI;
		String response = given().header("Content-Type", "application/json").header("Api-Token", prop.getProperty("APIToken")).
				get("/messages/" + msgID + "/body.html").getBody().asString();
		String expectedEmail = "Hello " + User.userFirstName + "," + System.lineSeparator() +
				"The Utilization Report that you requested is now ready for download." + System.lineSeparator() + "Please "+
				 System.lineSeparator() +"Click Here" + System.lineSeparator() +" to download the report." +
				 System.lineSeparator() + "Note: You may be required to login to RQI1Stop after clicking the link to" + 
				 System.lineSeparator() + "download the report." +
				 System.lineSeparator() + "Thank you," +System.lineSeparator() +
				 "The RQI Partners and RQI1Stop Team";
		System.out.println(expectedEmail);
		String codeEmail[] = expectedEmail.split( System.lineSeparator());
		for(int i = 0; i < codeEmail.length; i++) {
			Assert.assertTrue(response.contains(codeEmail[i]));
		}
		if(response.split("<a href=\"").length>1)
			links=response.split("<a href=\"")[1].split("\">Click here</a>")[0];
		openTab();
				UserManagement	usrMg = new UserManagement();
		usrMg.switchTab();
	   driver.navigate().to(links);;
		
	}

	public void openTab()
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.open('');");
		} 
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}
	}


}
