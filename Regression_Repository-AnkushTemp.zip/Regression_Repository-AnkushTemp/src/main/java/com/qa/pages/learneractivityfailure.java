package com.qa.pages;

import java.io.File;
import java.io.FileReader;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.json.simple.JSONObject;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.opencsv.CSVReader;
import com.qa.util.TestBase;

public class learneractivityfailure extends TestBase
{

	@FindBy(xpath = "//a[contains(text(), 'Reports')]")
	WebElement reportLink;
	
	@FindBy(xpath = "//a[text()='learner activity failure log']")
	WebElement learnerFailureLog;

	@FindBy(xpath = "//body[@class]")
	WebElement pageLoad;

	@FindBy(xpath = "//div[@class='dataTables_scroll']/div[1]/div/table/thead//th")
	List<WebElement> LearnerLogHeader;
	
	@FindBy(xpath = "(//select[@id = 'job_title_id']//following-sibling::div)//input[@type= 'text']")
	WebElement jobFilterFilterSearch;

	String userJobFilter = "(//select[@id = 'job_title_id']//following-sibling::div//ul//label)";

	@FindBy(xpath = "(//select[@id = 'group_id']//following-sibling::div)//input[@type= 'text']")
	WebElement groupFilterFilterSearch;

	String userGroupFilter = "(//select[@id = 'group_id']//following-sibling::div//ul//label)";

	@FindBy(xpath = "//*[@id='failure_count_wrapper']//table//td")
	List<WebElement> LearnerLogdata;
	
	@FindBy(xpath = "//label[@id='inputSearch']")
	WebElement searchText2;
	
	@FindBy(xpath = "//input[@type='search']")
	WebElement searchinputText;
	
	@FindBy(xpath = "//div[@id]/a[text()= 'Clear Search']")
	WebElement searchClear;
	
	@FindBy(xpath = "//button[@id = 'searchbtn']")
	WebElement searchButton;
	
	@FindBy(xpath = "//a[@data-target = '#unitdiv']")
	WebElement[] searchResultUnitName;
	
	@FindBy(xpath = "//table[@id = 'learnerTableList']//td[4]")
	WebElement searchResultFirstName;

	String val;
	String reportTable = "//table[@aria-describedby='failure_count_info' and @id='failure_count']//tbody/tr";

	
//	(//table[@aria-describedby='failure_count_info' and @id='failure_count']//tbody/tr)
	public learneractivityfailure() 
	{
		PageFactory.initElements(driver, this);
		
	}
	
	public void clickOnReportLink()
	{
		wait.until(ExpectedConditions.visibilityOf(reportLink));
		wait.until(ExpectedConditions.elementToBeClickable(reportLink));
		try {
			Thread.sleep(2000);
			val = pageLoad.getAttribute("class");
			while(val.contains("loading") || val.contains("loading_user") )
			{
				val = pageLoad.getAttribute("class");
			}
			reportLink.click();
		}
		catch (Exception e) 
		{
			reportLink.click();
		}

	}
	
	public void selectlearnerFailureLogLink()
	{
		wait.until(ExpectedConditions.visibilityOf(learnerFailureLog));
		learnerFailureLog.click();
		val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_compliance"))
		{
			val = pageLoad.getAttribute("class");
		}
		
      driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
	  	
		if(!driver.getCurrentUrl().contains("course_failure_report"))
		{
			clickOnReportLink();
			wait.until(ExpectedConditions.visibilityOf(learnerFailureLog));
			learnerFailureLog.click();
			

		}
	}
	static int count=0;
	public void ValidationtheColumnDetail(String key)
	{
		try
		{
		
			ArrayList<Object> text = new ArrayList<Object>();  
		      
			Map<String,String> map = reuse.getjsonObject(key);
		int count = 0,row=1;
		wait.until(ExpectedConditions.visibilityOfAllElements(LearnerLogdata));
		Thread.sleep(5000);
		for(WebElement tt : LearnerLogHeader){
			
				
			if(tt.getAttribute("innerText").contains("USER STATUS"))	
			{
				System.out.println("Excepted Data "+driver.findElement(By.xpath("(//*[@id='failure_count_wrapper']//table//td)["+row+"]")).getText());
				System.out.println("UI Header "+tt.getAttribute("innerText").replace("\n"," "));
				System.out.println("UI Data "+map.get(tt.getAttribute("innerText").replace("\n"," ").toUpperCase()));
			
				
				Assert.assertTrue(map.get(tt.getAttribute("innerText").replace("\n"," ").toUpperCase()).contains("Active")||map.get(tt.getAttribute("innerText").replace("\n"," ").toUpperCase()).contains("Inactive"));
			}
			else
			{
				System.out.println("Excepted Data "+driver.findElement(By.xpath("(//*[@id='failure_count_wrapper']//table//td)["+row+"]")).getText());
				System.out.println("UI Header "+tt.getAttribute("innerText").replace("\n"," "));
				System.out.println("UI Data "+map.get(tt.getAttribute("innerText").replace("\n"," ").toUpperCase()));
				
				
				Assert.assertEquals("Validation failed !!",map.get(tt.getAttribute("innerText").replace("\n"," ").toUpperCase()),driver.findElement(By.xpath("(//*[@id='failure_count_wrapper']//table//td)["+row+"]")).getText());
				
			}
		    count++;
			row++;
		}
		
		
		
		
		}
		catch (Exception e) 
		{
			count++;
			if(count<=3)
			 ValidationtheColumnDetail(key);
			
		}

	}

	public void searchJobFilter(String titleName)
	{
		try {
			if(AssignmentReport. checkifParmeterAvailable(titleName))
				OrganizationSettings.titleName=AssignmentReport.getParmeterAvailable(titleName);
	
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(jobFilterFilterSearch));
			int counter = 0;
			jobFilterFilterSearch.click();
			jobFilterFilterSearch.clear();
			if(OrganizationSettings.titleName == null)
				OrganizationSettings.titleName = driver.findElement(By.xpath(userJobFilter + "[1]")).getText().trim();
			System.out.println(OrganizationSettings.titleName);
			jobFilterFilterSearch.sendKeys(OrganizationSettings.titleName);
			List<WebElement> statusList = driver.findElements(By.xpath(userJobFilter + "/parent::li[not(contains(@class,'hidden'))]"));
			while(statusList.size() > 1)
			{
				statusList = driver.findElements(By.xpath(userJobFilter + "/parent::li[not(contains(@class,'hidden'))]"));
				Thread.sleep(2000);
				if(counter > 12)
					Assert.fail("Search functionality for user status is not working");
				counter++;
			}
			driver.findElement(By.xpath(userJobFilter + "//input[contains(@title,'" + OrganizationSettings.titleName + "')]")).click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}

	}

	public void searchGroupFilter(String groupName)
	{
		try {
			if(AssignmentReport. checkifParmeterAvailable(groupName))
				OrganizationSettings.groupName=AssignmentReport.getParmeterAvailable(groupName);
	
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(groupFilterFilterSearch));
			counter = 0;
			groupFilterFilterSearch.click();
			groupFilterFilterSearch.clear();
			groupFilterFilterSearch.sendKeys(OrganizationSettings.groupName);
			List<WebElement> statusList = driver.findElements(By.xpath(userGroupFilter + "/parent::li[not(contains(@class,'hidden'))]"));
			while(statusList.size() > 1)
			{
				statusList = driver.findElements(By.xpath(userGroupFilter + "/parent::li[not(contains(@class,'hidden'))]"));
				Thread.sleep(2000);
				if(counter > 12)
					Assert.fail("Search functionality for user status is not working");
				counter++;
			}
			driver.findElement(By.xpath(userGroupFilter + "//input[contains(@title,'" + OrganizationSettings.groupName + "')]")).click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}

	}
	public void usersearchEmail(String userEmail)
	{
		try 
		{
				if(AssignmentReport. checkifParmeterAvailable(userEmail))
					userEmail=AssignmentReport.getParmeterAvailable(userEmail);
		
			
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchClear));
			wait.until(ExpectedConditions.elementToBeClickable(searchClear));
			searchClear.click();
			wait.until(ExpectedConditions.visibilityOf(searchText2));
			wait.until(ExpectedConditions.elementToBeClickable(searchText2));
			System.out.println("unit name is " + userEmail);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", searchText2);
			wait.until(ExpectedConditions.elementToBeClickable(searchinputText));
			
				searchinputText.sendKeys(userEmail);
				
			executor.executeScript("arguments[0].click();", searchButton);
//			wait.until(ExpectedConditions.visibilityOf(searchResultUnitName[searchResultUnitName.length-1]));
//			String result = searchResultUnitName[searchResultUnitName.length-1].getText();
//			Assert.assertEquals(userEmail, result);

      		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
      		int rowCount=0;
    		int cont=0;
    		while(rowCount==1)
    		{
            List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
             rowCount = tableRows.size();
             if(cont==150)
            	 break;
             
             cont++;
        	}
    		Thread.sleep(7000);
		} 
		catch (Exception e) 
		{
		e.printStackTrace();	
		}
	}
	@FindBy(xpath = "//a[@class='card-link']")
	WebElement moreFilter;

	// a[@class='card-link']

	@FindBy(xpath = "//div[@class='dataTables_scroll']/div[1]/div/table/thead//th")
	List<WebElement> LearnerActivityColumns;

	@FindBy(xpath = "//button[@name='exportbtn']")
	WebElement exportCSVButton;

	public void learnerActivityColumnsValidation(List<String> text, String tc) {
		// TODO Auto-generated method stub
		wait.until(ExpectedConditions.visibilityOf(moreFilter));
		moreFilter.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (tc.equalsIgnoreCase("afterSearch")) {

			searchButton.click();
		}
		int count = 0;
		for (WebElement tt : LearnerActivityColumns) {
			System.out.println(tt.getAttribute("innerText"));
			Assert.assertEquals(text.get(count).toUpperCase(), tt.getAttribute("innerText").replace("\n", " "));
			count++;
		}
	}

	@FindBy(xpath = "//table[@id='courseList']//tbody//tr/td")
	WebElement Text_NoReportsDataFound;

	@FindBy(xpath = "//table[@id='failure_count']//tbody//tr/td")
	WebElement NoRecordsFound;
	
//	String val;
//	String searchTable = "//div[@class='DTFC_ScrollWrapper']//div[@class='DTFC_LeftWrapper']/div/table/thead/tr/th"; 
	String searchTable = "//table[@summary='failure count management']/thead/tr/th";
//	String row = "//table[contains(@id,'courseList')]//tbody//tr";
	String row = "//table[@aria-describedby='failure_count_info' and @id='failure_count']//tbody/tr";

	public void verifylearnerActivityNoReportsDataFound() {
		// TODO Auto-generated method stub
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(Text_NoReportsDataFound));
		String value = Text_NoReportsDataFound.getText();
		Assert.assertEquals(value, "No records present.");

	}
	
	public void verifylearnerActivityNoRecordsArePresent() throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriverWait wait = new WebDriverWait(driver, 30);
		Thread.sleep(4000);
		wait.until(ExpectedConditions.visibilityOf(NoRecordsFound));
		String value = NoRecordsFound.getText();
		Assert.assertEquals(value, "No records are present.");

	}


	public void validateLearnerActivitySortingEachColumn() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		for (int i = 1; i <= 13; i++) {
			ArrayList<String> obtainedList = new ArrayList<>();
			// div[@id="courseList_wrapper"]//th
			WebElement column = driver.findElement(By.xpath(searchTable + "[" + i + "]"));
			try {
				wait.until(ExpectedConditions.elementToBeClickable(column));
			} catch (Exception e) {
				WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
				js.executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", scrollArea);
				wait.until(ExpectedConditions
						.elementToBeClickable(driver.findElement(By.xpath(searchTable + "[" + i + "]"))));
			}
			js.executeScript("arguments[0].click()", column);
			val = pageLoad.getAttribute("class");
			int m = 0;
			while (val.toLowerCase().contains("loading")) {
				val = pageLoad.getAttribute("class");
				if (m == pagload)
					break;
				m++;
			}

			List<WebElement> elementList = driver.findElements(By.xpath(row + "/td[" + i + "]"));
			for (WebElement we : elementList) {
				obtainedList.add(we.getText());
			}
			ArrayList<String> sortedList = new ArrayList<>();
			for (String s : obtainedList) {
				sortedList.add(s);
			}
			Collections.sort(sortedList);

			System.out.println("Sorted list" + sortedList.toString());
			System.out.println("Obtainted list" + obtainedList);

			Assert.assertTrue(sortedList.equals(obtainedList));

			js.executeScript("arguments[0].click()", column);
			obtainedList.removeAll(obtainedList);
			val = pageLoad.getAttribute("class");
			m = 0;
			while (val.toLowerCase().contains("loading")) {
				val = pageLoad.getAttribute("class");
				if (m == pagload)
					break;
				m++;
			}
			elementList = driver.findElements(By.xpath(row + "/td[" + i + "]"));
			for (WebElement we : elementList) {
				obtainedList.add(we.getText());
			}
			Collections.reverse(sortedList);
			Assert.assertTrue(sortedList.equals(obtainedList));

		}

	}

	public void exportCSV() {
		try {
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(exportCSVButton));
			wait.until(ExpectedConditions.elementToBeClickable(exportCSVButton));
			exportCSVButton.click();
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public void deleteFile() {
		Students std = new Students();
		std.deleteFile(Students.filePath);
	}

	public void validateCSVFile() {
		// TODO Auto-generated method stub
		Students std = new Students();
		boolean dwnld = false;
		do {
			dwnld = std.isFileDownloaded_Ext(Students.downloadPath, ".csv");
		} while (dwnld == false);
		deleteFile();
	}

	@FindBy(xpath = "//select[@id = 'statusFilter']//following-sibling::div/button")
	WebElement userStatusFilter;

	@FindBy(xpath = "//select[@id = 'job_title_id']//following-sibling::div/button")
	WebElement jobFilter;

	@FindBy(xpath = "//select[@id = 'group_id']//following-sibling::div/button")
	WebElement groupFilter;

	@FindBy(xpath = "//a[@class = 'card-link assignment_filter']")
	WebElement courseFilter;

	@FindBy(xpath = "//a[@class='card-link']")
	WebElement Link_MoreFilters;
	
	@FindBy(xpath = "//a[@class='card-link collapsed']")
	WebElement MoreFilters;
	//div[@class='card-header']/a[text()='More Filters  ']
	
	
	@FindBy(xpath = "//a[@class='card-link assignment_filter']")
	WebElement Link_CourseFilters;

	@FindBy(xpath = "//select[@id='courses']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement courseFilterUnSelectAll;

	@FindBy(xpath = "//select[@id='courses']//following-sibling::div/div/a[text()='Select all']")
	WebElement courseFilterSelectAll;

	@FindBy(xpath = "//select[@id='courses']//parent::div//div/button")
	WebElement Button_Course;

	public void validateUserStatusFilterAvailability() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(userStatusFilter));
		userStatusFilter.click();
	}

	
	public void validateMoreFiltersAvailability() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(MoreFilters));
			MoreFilters.click();
		}catch (Exception e) {
			// TODO: handle exception
			Assert.fail(e.getMessage());
		}
		
	}
	
	
	
	public void validateJobFilterFilterAvailability() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(jobFilter));
		jobFilter.click();
	}

	public void validateGroupFilterFilterAvailability() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(groupFilter));
		groupFilter.click();
	}

	public void clickCourseFilter() {
		try {
			Thread.sleep(2000);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(courseFilter));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", courseFilter);
			Thread.sleep(2000);
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void clickOnMoreFilters() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			Link_MoreFilters.click();
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail(e.getMessage());
		}
	}

	public void clickOnCourseFilters() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 20);
			Link_CourseFilters.click();
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail(e.getMessage());
		}
	}

	public void UnselectAllCourse() {
		try {
			Thread.sleep(1000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			courseFilterUnSelectAll.click();
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail(e.getMessage());
		}
	}

	public void selectAllCourse() {
		try {
			Thread.sleep(1000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			courseFilterSelectAll.click();
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail(e.getMessage());
		}
	}

	public void SelectCourse() {
		try {
			Thread.sleep(1000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			Button_Course.click();
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail(e.getMessage());
		}
	}

	String userCourseFilter = "(//select[@id = 'courses']//following-sibling::div//ul//label)";

	@FindBy(xpath = "(//button[text() = 'Search' and not(@id)])[2]")
	WebElement courseFilterSearchButton;

	public void selectMultiUserCourseFilter() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userCourseFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userCourseFilter));
		for (int i = 1; i <= statusList.size(); i++) {
			WebElement elem = driver.findElement(By.xpath("(" + userCourseFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if (flag == false) {
				driver.findElement(By.xpath("(" + userCourseFilter + "/input)[" + i + "]")).click();
				break;
			}
		}

	}

	public void clickOnCourseFilterSearchButton() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(courseFilterSearchButton));
		courseFilterSearchButton.click();
	}

	JavascriptExecutor js = (JavascriptExecutor) driver;

	public void validatelearnerActivityRecordAvailable() {
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while (val.equalsIgnoreCase("loading_compliance")) {
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if (counter > 12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			counter = 0;
			while (!(val.equalsIgnoreCase("complete"))) {
				val = js.executeScript("return document.readyState").toString();
				Thread.sleep(5000);
				counter++;
				if (counter > 12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			String text = driver.findElement(By.xpath(reportTable + "[1]/td[1]")).getText();
			System.out.println(text);
			Assert.assertFalse(text.equals("No reports data found."));
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	String CourseFilter = "(//select[@id = 'courses']//following-sibling::div//ul//label)";

	public void selectMultiCourseFilter() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(CourseFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(CourseFilter));
		for (int i = 1; i <= statusList.size(); i++) {
			WebElement elem = driver.findElement(By.xpath("(" + CourseFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if (flag == false) {
				driver.findElement(By.xpath("(" + CourseFilter + "/input)[" + i + "]")).click();
				break;
			}
		}

	}
	
	String JobFilter = "(//select[@id=\"job_title_id\"]//following-sibling::div//ul//label)";
	
	public void selectMultiJobFilter() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
//		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(JobFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(JobFilter));
		for (int i = 1; i <= statusList.size(); i++) {
			WebElement elem = driver.findElement(By.xpath("(" + JobFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if (flag == false) {
				driver.findElement(By.xpath("(" + JobFilter + "/input)[" + i + "]")).click();
				break;
			}
		}

	}

	String GroupFilter = "(//select[@id=\"group_id\"]//following-sibling::div//ul//label)";
	
	public void selectMultiGroupFilter() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
//		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(JobFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(GroupFilter));
		for (int i = 1; i <= statusList.size(); i++) {
			WebElement elem = driver.findElement(By.xpath("(" + GroupFilter + "/input)[" + i + "]"));
			System.out.println( " elem " + elem);
			boolean flag = elem.isSelected();
			if (flag == false) {
				driver.findElement(By.xpath("(" + GroupFilter + "/input)[" + i + "]")).click();
				break;
			}
		}

	}
	
	
	@FindBy(xpath = "(//button[text()='Search'])[3]")
	WebElement moreFilterSearchButton;
	// button[text() = 'Search' and not(@id)]

	public void clickOnMoreFilterSearchButton() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(moreFilterSearchButton));
		moreFilterSearchButton.click();
	}

	@FindBy(xpath = "(//a[text()='Clear Search'])[3]")
	WebElement Button_ClearSearch;
	
	@FindBy (xpath = "(//a[text()='Clear Search'])[2]")
	WebElement Button_MoreFilterClearSearch;
	
	public void clickOnCourseClearSearch() {
		try {
			Thread.sleep(2000);
			Button_ClearSearch.click();

		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	public void clickOnMoreFilterClearSearch() {
		try {
			Thread.sleep(2000);
			Button_MoreFilterClearSearch.click();

		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail(e.getMessage());
		}

	}

	
	@FindBy (xpath = "//table[@id='failure_count']/tbody/tr/td")
	WebElement Text_NoRecordsPresent;
	
	public void NoRecordsFound() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver,20);
			String value = Text_NoRecordsPresent.getText();
			Assert.assertEquals(value, "No records are present.");
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail(e.getMessage());
		}

	}
	
	
	@FindBy (xpath = "//div[@id='job_select']//div/button")
	WebElement Button_JobTitle;
	
	@FindBy (xpath = "//select[@id='job_title_id']//following-sibling::div//a[text()='Select all']")
	WebElement JobTitle_SelectAll;
	
	@FindBy (xpath = "//select[@id='job_title_id']//following-sibling::div//div/a[text()='Unselect all']")
	WebElement JobTitle_unSelectAll;
	
	@FindBy (xpath = "//select[@id='group_id']//following-sibling::div/button")
	WebElement Button_Group;
	//button[@type='button']/span[text()='Select options']
	
	@FindBy (xpath = "//select[@id='group_id']//following-sibling::div//a[text()='Select all']")
	WebElement Group_SelectAll;
	
	@FindBy (xpath = "//select[@id='group_id']//following-sibling::div//div/a[text()='Unselect all']")
	WebElement Group_UnSelectAll;
	
	
	public void clickOnJobTitle() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver,20);
			Button_JobTitle.click();
		
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail(e.getMessage());
		}

	}
	
	public void clickOnJobTitleSelectAll() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver,20);
			JobTitle_SelectAll.click();
		
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail(e.getMessage());
		}
	}
	
	public void clickOnJobTitleUnSelectAll() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver,20);
			JobTitle_unSelectAll.click();
		
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail(e.getMessage());
		}
	}
	
	
	public void clickOnGroup() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver,20);
			Button_Group.click();
		
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail(e.getMessage());
		}
	}


	public void clickOnGroupSelectAll() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver,20);
			Group_SelectAll.click();
		
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail(e.getMessage());
		}
	}
	
	public void clickOnGroupUnSelectAll() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver,20);
			Group_UnSelectAll.click();
		
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail(e.getMessage());
		}
	}


	@FindBy(xpath = "(//button[@value='Search'])[2]")
	WebElement Button_MoreFilter;
	
	public void SearchButtonMoreFilter() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver,20);
			Button_MoreFilter.click();
		
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail(e.getMessage());
		}
	}

	String userStatus = "(//select[@id = 'statusFilter']//following-sibling::div//ul//label)";

	public void selectMultiUserStatusFilter(String status)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userStatus + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userStatus));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath(userStatus + "//input[contains(@title,'" + status + "')]"));
			boolean flag = elem.isSelected();
			if(flag == false)
				driver.findElement(By.xpath(userStatus + "//input[contains(@title,'" + status + "')]")).click();
		}

	}
	
	//button[@title="Organization"]
	//div[@role="combobox"]/ul/li/a[@role="option"]
	//div[@class="filterPanelDiv "]/div/button
	
	@FindBy (xpath = "//select[@id=\"filterSelect_1\"]//following-sibling::div/button")
	WebElement Button_OrgName;
	
	@FindBy(xpath = "//select[@id='filterSelect_1']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement OrgNameUnSelectAll;
	
	@FindBy (xpath = "//select[@id='filterSelect_1']//following-sibling::div//div//a[text()='Select all']")
	WebElement OrgNameSelectAll;
	
	public void SearchButtonOrgName() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver,20);
			Button_OrgName.click();
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail(e.getMessage());
		}
	}
	
	public void SearchButtonUnSelectAll() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver,20);
			OrgNameUnSelectAll.click();
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail(e.getMessage());
		}
	}

	public void SearchButtonSelectAll() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver,20);
			OrgNameSelectAll.click();
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail(e.getMessage());
		}
	}
	
	
	@FindBy (xpath = "//button[@data-id='orgLevel']")
	WebElement Button_OrgLevel;
	
	public void SearchButtonOrgLevel() {
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver,20);
			Button_OrgLevel.click();
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail(e.getMessage());
		}
	}
	
	@FindBy(xpath = "//div[@role='combobox']/ul/li/a")
	List<WebElement> DropDown_OrgLevel;
	
	public static void selectFromTheList(List<WebElement> element, String value) {
		Iterator<WebElement> itr = element.iterator();
		boolean flg = false;
		while (itr.hasNext()) {
			WebElement clickelement = itr.next();
			if (clickelement.getText().equalsIgnoreCase(value)) {
				clickelement.click();
				flg = true;
				
				break;
			} else {
				// System.out.println("Element with value '" + value + "' not present in list");
			}
		}
		Assert.assertTrue(flg);
	}
	
	String fileName;
	public static String userEmail, userId, filePath, email,userId1;
	
	public boolean isFileDownloaded_Ext(String dirPath, String ext){
		boolean flag=false;
	    File dir = new File(dirPath);
	    File[] files = dir.listFiles();
	    if (files != null)
	    {
	    	 for (int i = 0; i < files.length; i++) 
	 	    {
	 	    	if(files[i].getName().contains(ext)&& !(files[i].getName().contains(".crdownload"))) 
	 	    	{
	 	    		fileName = files[i].getName();
	 	    		filePath = files[i].getAbsolutePath();
	 	    		filePath = filePath.replace(".crdownload", "");
	 	//FileReader reader = new FileReader( System.getProperty("user.dir")+prop.getProperty("downloadPath")+"\\coursesName"+prop.getProperty("environment")+".json", StandardCharsets.UTF_8))    		
					flag=true;
	 	    		break;
	 	    	}
	 	    }
	    }
	    
	    return flag;
	}
	
	String downloadPath = System.getProperty("user.dir") + prop.getProperty("downloadPath");
	public boolean checkCSVFilePresent()
	{
		boolean dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
		return dwnld;
	}
	
	
	public void deleteFile(String path)
	{
		try {
			System.out.println("delete file path is " + path);
			File file = new File(path);
			Thread.sleep(5000);
			file.delete();
			boolean dwnld = false;
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");	
			int counter = 0;
			while(dwnld)
			{
				file = new File(filePath);
				file.delete();
				dwnld = isFileDownloaded_Ext(downloadPath, ".csv");	
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to delete after waiting for 1 minute");
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	String enableExportButton = "//button[@id = 'exportbtn' and not(contains(@class, 'disabled'))]";
	@FindBy(xpath = "//button[@id = 'exportbtn']")
	WebElement exportButton;
	
	public void clickExportButton()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(exportButton));
			int counter = 0;
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			if(driver.findElements(By.xpath(enableExportButton)).size()>0)
				js.executeScript("arguments[0].click();", exportButton);
			else
				Assert.fail("Export button is diabled as no record is available");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
		
	}
	
	
	public void verifyDownloadFile()
	{
		try 
		{
		//	usr = new User();
			int counter = 0;
			boolean dwnld = false;
			do 
			{
				Thread.sleep(5000);
				dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
				counter = counter +1;
				if(counter > 24)
					Assert.fail("Not able to download file");
			}
			while(dwnld == false);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
			System.out.println(e.getMessage());
		}
	}

	public void compareDetails()
	{
		try
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String  uiList[][];
			int counter = 0;
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(reportTable))));
			List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
			List<List<String>> list_UI = new ArrayList<>();
			List<List<String>> list_report = new ArrayList<>();
			File file = new File(learneractivityfailure.filePath);
			FileReader filereader = new FileReader(file,StandardCharsets.UTF_8);
			CSVReader csvReader = new CSVReader(filereader); 
			List<String[]> header = csvReader.readAll();
			int rowCount = tableRows.size();
			uiList = new String[rowCount][13];
			String reportDetails[][] = new String[header.size() - 2][13];
			for (int i= 1; i<= rowCount; i++)
			{
				for(int j = 1; j <= 13; j++)
				{
					String textValue = driver.findElement(By.xpath("(" + reportTable + ")[" + i + "]/td[" + j + "]")).getText();
					System.out.println("textvalue"+ textValue);
					if(textValue.equals("Failed")) {
					uiList[i-1][j-1] = textValue.toUpperCase();
					}
					else {
						uiList[i-1][j-1] = textValue;
					}
				}
			}
			for (String[] ints : uiList) 
			{
				list_UI.add(Arrays.asList(ints));
				
			}
			System.err.println(header.size());
			for(int i = 1; i <=header.size() - 2; i++)
			{
				String []excel = header.get(i+1);
				System.out.println(i);
				System.out.println(header.get(i+1).toString());
				System.out.println(Arrays.toString(header.get(i+1)));
				System.out.println();
				String []excelValues = excel;
				System.out.println("UI List " +Arrays.toString(list_UI.toArray()));
				for(int j = 0; j <= 12; j++)
				{
					System.out.println("execlvalues : "+excelValues[j].replace("\"", "").trim());
					
					reportDetails[i-1][j] = excelValues[j].replace("\"", "").trim();
				}				
			}
			csvReader.close();
			for (String[] ints : reportDetails) {
				list_report.add(Arrays.asList(ints));
			}
			System.out.println("UI List " +Arrays.toString(list_report.toArray()));
			
			List<List<String>> differences = new ArrayList<>(list_UI);
			differences.removeAll(list_report);
			System.out.println(Arrays.toString(differences.toArray()));
			Assert.assertTrue(differences.size() == 0);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	@FindBy (xpath = "//div[@class='card-header']//a[@class='card-link notification_log_filter']")
	WebElement TabLinks_Activity;
	
	
	//input[@id='activity_from_date']
	@FindBy (xpath = "//div[@id=\"datepicker\"]//div[@class='input-daterange']//input[@placeholder='From']")
	WebElement ActivityDateFrom;
	
	//div[@class='input-daterange']//input[@placeholder="To Date"]
	@FindBy (xpath = "//input[@id='activity_to_date']")
	WebElement ActivityToDate;
	
	//div[@class='datepicker-days']/table[@class=' table-condensed']//tbody/tr//td[@class='day' and text()='4']
	String DateStartFrom = "//div[@class='datepicker-days']/table[@class=' table-condensed']//tbody/tr//td[@class='day' and text()='";
	String AfterXpath = "']";
	String DateEndTo = "//div[@class=\"datepicker-days\"]//table[@class=\" table-condensed\"]/tbody/tr/td[@class=\"day\" and text()='";
	
	//div[@class="datepicker-months"]//table[@class="table-condensed"]/thead/tr[2]/th[@class="datepicker-switch" and text()='2023'] ==> Not required
	//div[@class=\"datepicker-months\"]//table[@class=\"table-condensed\"]/tbody/tr/td/span[@class=\"month\" and text()='Jan']
	String Month = "//div[@class=\"datepicker-months\"]//table[@class=\"table-condensed\"]/tbody/tr/td/span[@class=\"month\" and text()='";
	//div[@class=\"datepicker-years\"]//table[@class=\"table-condensed\"]/tbody/tr/td/span[@class=\"year\" and text()='2022']
	String Year = "//div[@class=\"datepicker-years\"]//table[@class=\"table-condensed\"]/tbody/tr/td/span[@class=\"year\" and text()='";
	
	public void ClickOnActivitylink() {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(TabLinks_Activity));
			Thread.sleep(5000);
			
			TabLinks_Activity.click();
		//	ActivityDateFrom.click();
			
		//	ActivityToDate.click();
			
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	
	public void ClickonFromButton() {
		try {
			Thread.sleep(5000);
			wait.until(ExpectedConditions.elementToBeClickable(ActivityDateFrom));
			ActivityDateFrom.click();
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	@FindBy (xpath = "//input[@id='activity_from_date']")
	WebElement FromDateRange;
	
	@FindBy (xpath = "//input[@id='activity_to_date']")
	WebElement TODateRange;
	
	public void selectStartDateMonthAndYear(String year,String month, String date) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
		//	TabLinks_Activity.click();
		//	ActivityDateFrom.click();
			Thread.sleep(2000);
				String yymddvalue = year+"/"+month+"/"+date;
				System.out.println( "  The value of startDATE "+ yymddvalue);
	//		js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", FromDateRange,"value","2022/10/10");		
			js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", FromDateRange,"value", yymddvalue );		
	//		String selectYear = Year + year + AfterXpath;
	//		WebElement selectedYear =   driver.findElement(By.xpath(selectYear));
	//		selectedYear.click();
			
	//		String selectMonth = Month + month + AfterXpath;
	//		WebElement selectedMonth =   driver.findElement(By.xpath(selectMonth));
	//		selectedMonth.click();
			
	//		String selectDate = DateStartFrom + date + AfterXpath;
	//		WebElement selectedDate =   driver.findElement(By.xpath(selectDate));
	//		selectedDate.click();
			
		}catch (Exception e) {
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	public void selectStartDateMonthAndYear(String UserID,int add) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
		//	TabLinks_Activity.click();
		//	ActivityDateFrom.click();
			Thread.sleep(2000);
			   
				Map<String,String> map = reuse.getjsonObject(UserID);
				String date=map.get("ACTIVITY DATE");  
				  
				
				   
				   SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");  
			       
//					  System.out.println(date.);
					  Calendar cal = Calendar.getInstance();  
				        try{  
				           cal.setTime(sdf.parse(date));  
				        }catch(Exception e){  
				            e.printStackTrace();  
				         }  
				             
				        // use add() method to add the days to the given date  
				        cal.add(Calendar.DAY_OF_MONTH, add);  
				        date = sdf.format(cal.getTime());  

//				        System.out.println(dateAfter);
				        String d=date.toString().split(" ")[0].split("/")[2];

						   String m=date.toString().split(" ")[0].split("/")[1];
						   String y=date.toString().split(" ")[0].split("/")[0];

			  String yymddvalue = y+"/"+m+"/"+d;
				System.out.println( "  The value of startDATE "+ yymddvalue);
	//		js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", FromDateRange,"value","2022/10/10");		
			js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", FromDateRange,"value", yymddvalue );		
	//		String selectYear = Year + year + AfterXpath;
	//		WebElement selectedYear =   driver.findElement(By.xpath(selectYear));
	//		selectedYear.click();
			
	//		String selectMonth = Month + month + AfterXpath;
	//		WebElement selectedMonth =   driver.findElement(By.xpath(selectMonth));
	//		selectedMonth.click();
			
	//		String selectDate = DateStartFrom + date + AfterXpath;
	//		WebElement selectedDate =   driver.findElement(By.xpath(selectDate));
	//		selectedDate.click();
			
		}catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}
	
	public void selectEndDateMonthAndYear(String UserID,int add) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
		//	TabLinks_Activity.click();
			
		//	ActivityToDate.click();
			wait.until(ExpectedConditions.elementToBeClickable(ActivityToDate));
			Thread.sleep(2000);
			Map<String,String> map = reuse.getjsonObject(UserID);
			String date=map.get("ACTIVITY DATE");  
			  
			
			   
			   SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");  
		       
//				  System.out.println(date.);
				  Calendar cal = Calendar.getInstance();  
			        try{  
			           cal.setTime(sdf.parse(date));  
			        }catch(Exception e){  
			            e.printStackTrace();  
			         }  
			             
			        // use add() method to add the days to the given date  
			        cal.add(Calendar.DAY_OF_MONTH, add);  
			        date = sdf.format(cal.getTime());  

//			        System.out.println(dateAfter);
			        String d=date.toString().split(" ")[0].split("/")[2];

					   String m=date.toString().split(" ")[0].split("/")[1];
					   String y=date.toString().split(" ")[0].split("/")[0];

		      String yymddvalue = y+"/"+m+"/"+d;
			
			System.out.println( "  The value of enddate "+ yymddvalue);
			js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", TODateRange,"value", yymddvalue );
			
		//	String selectYear = Year + year + AfterXpath;
		//	WebElement selectedYear =   driver.findElement(By.xpath(selectYear));
		//	selectedYear.click();
			
		//	String selectMonth = Month + month + AfterXpath;
		//	WebElement selectedMonth =   driver.findElement(By.xpath(selectMonth));
		//	selectedMonth.click();
			
		//	String selectDate = DateStartFrom + date + AfterXpath;
		//	WebElement selectedDate =   driver.findElement(By.xpath(selectDate));
		//	selectedDate.click();
			
		}catch (Exception e) {
			Assert.fail(e.getMessage());
			
		}
	}

	public void selectEndDateMonthAndYear(String year,String month, String date) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
		//	TabLinks_Activity.click();
			
		//	ActivityToDate.click();
			wait.until(ExpectedConditions.elementToBeClickable(ActivityToDate));
			Thread.sleep(2000);
			String yymddvalue = year+"/"+month+"/"+date;
			System.out.println( "  The value of enddate "+ yymddvalue);
			js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", TODateRange,"value", yymddvalue );
			
		//	String selectYear = Year + year + AfterXpath;
		//	WebElement selectedYear =   driver.findElement(By.xpath(selectYear));
		//	selectedYear.click();
			
		//	String selectMonth = Month + month + AfterXpath;
		//	WebElement selectedMonth =   driver.findElement(By.xpath(selectMonth));
		//	selectedMonth.click();
			
		//	String selectDate = DateStartFrom + date + AfterXpath;
		//	WebElement selectedDate =   driver.findElement(By.xpath(selectDate));
		//	selectedDate.click();
			
		}catch (Exception e) {
			Assert.fail(e.getMessage());

		}
	}
	
	@FindBy (xpath = "(//button[@class='btn btn-default white_btn search_submit'])[2]")
	WebElement ActivitySearchButton;
	
	public void ActivityFilterSearchButton() {
		try {
			ActivitySearchButton.click();
		}catch (Exception e) {
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	
	
	
	List<List<String>> list_UI = new ArrayList<>();
	List<List<String>> list_report = new ArrayList<>();

	public static String uiList[][];
	String userRows = "//table[@id = 'learnerTableList']//tr[@class]";

	public void ValidateHeaderOfCSVFile() {

		{
			list_UI.clear();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			val = js.executeScript("return document.readyState").toString();
			while (!(val.equalsIgnoreCase("complete"))) {
				val = js.executeScript("return document.readyState").toString();
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userRows))));
			List<WebElement> tableRows = driver.findElements(By.xpath(userRows));
			int rowCount = tableRows.size();
			uiList = new String[rowCount][7];
			for (int i = 1; i <= rowCount; i++) {
				for (int j = 2; j <= 8; j++) {
					String textValue = driver.findElement(By.xpath("(" + userRows + ")[" + i + "]/td[" + j + "]"))
							.getText();
					uiList[i - 1][j - 2] = textValue;
				}
			}
			for (String[] ints : uiList) {
				list_UI.add(Arrays.asList(ints));
			}
		}

	}
	
	

}
