package com.qa.pages;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.qa.util.TestBase;

public class manualTest extends TestBase
{
	UserManagement usrMg;
	EndUser end;
	
	@FindBy(xpath = "//a[contains(text(), 'Reports')]")
	WebElement reportLink;
	
	@FindBy(xpath = "//a[contains(text(), 'Consumption Report')]")
	WebElement consumptionReportLink;
	
	@FindBy(xpath = "//input[@name = 'from_start_date']")
	WebElement fromDate;
	
	@FindBy(xpath = "//*[@class = ' table-condensed']//th[@class = 'datepicker-switch']")
	WebElement datePickerSwitch;
	
	@FindBy(xpath = "(//*[@class = 'table-condensed']//th[@class = 'datepicker-switch'])[1]")
	WebElement monthPickerSwitch;
	
	@FindBy(xpath = "(//*[@class = 'table-condensed']//th[@class = 'prev'])[1]")
	WebElement yearPickerSwitch;
	
	@FindBy(xpath = "//input[@name = 'to_start_date']")
	WebElement toDate;
	
	@FindBy(xpath = "//span[text() = 'Select Organization(s)']")
	WebElement orgDropdown;
	
	
	
	@FindBy(xpath = "//body[@class]")
	WebElement pageLoad;

	String val;
	public static String runningStatus;
	String datePick = "//td[contains(@class, 'day' ) and text() = ";
	String monthSwitch = "//span[@class= 'month'";
	String orgSelect = "((//div[@class = 'ms-options'])[2]//li/label)";
	String courseTable = "(//table[@class]//tbody/tr)";
	String topicTable = "(//table[@class = 'table panel panel-default referencePanel']//tbody/tr)";
	
	public manualTest() 
	{
		PageFactory.initElements(driver, this);
	}

	public void navigateConsumptionReport()
	{
		wait.until(ExpectedConditions.visibilityOf(reportLink));
		wait.until(ExpectedConditions.elementToBeClickable(reportLink));
		reportLink.click();
		wait.until(ExpectedConditions.visibilityOf(consumptionReportLink));
		consumptionReportLink.click();
		JavascriptExecutor js = (JavascriptExecutor)driver;
		String pageValue = js.executeScript("return document.readyState").toString();
		int m=0;
		while(!(pageValue.equalsIgnoreCase("complete")))
		{
			pageValue = js.executeScript("return document.readyState").toString();
			if(m==12)
				break;
			m++;
		}
	}
	
	public void clickStartDate()
	{
		wait.until(ExpectedConditions.visibilityOf(fromDate));
		fromDate.click();
	}
	
	public void clickEndDate()
	{
		wait.until(ExpectedConditions.visibilityOf(toDate));
		toDate.click();
	}
	
	public void selectDate(String startDate)
	{
		String dateAttribute[] = startDate.split(" ");
		wait.until(ExpectedConditions.visibilityOf(datePickerSwitch));
		String current = datePickerSwitch.getText();
		if(current.equalsIgnoreCase(dateAttribute[1] + " " + dateAttribute[0]))
			{
				String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
				WebElement reqDate = driver.findElement(By.xpath(datePick + "'" + dateAttribute[2] + "'" + x));
				wait.until(ExpectedConditions.visibilityOf(reqDate));
				reqDate.click();
			}
		else
			{
			datePickerSwitch.click();
			wait.until(ExpectedConditions.visibilityOf(monthPickerSwitch));
			current = monthPickerSwitch.getText();
			if(current.equalsIgnoreCase(dateAttribute[0]))
			{
				
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(monthSwitch + "]"))));
				driver.findElement(By.xpath(monthSwitch + " and text() = '" + dateAttribute[1] + "']")).click();
				String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
				WebElement reqDate = driver.findElement(By.xpath(datePick + "'" + dateAttribute[2] + "'" + x));
				wait.until(ExpectedConditions.visibilityOf(reqDate));
				reqDate.click();
			}
			else
			{
				while(!current.equalsIgnoreCase(dateAttribute[0]))
				{
					yearPickerSwitch.click();
					current = monthPickerSwitch.getText();
				}
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(monthSwitch + "]"))));
				driver.findElement(By.xpath(monthSwitch + " and text() = '" + dateAttribute[1] + "']")).click();
				String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
				WebElement reqDate = driver.findElement(By.xpath(datePick + "'" + dateAttribute[2] + "'" + x));
				reqDate.click();
			}
			
		}
	}
	
	public void clickSelectOrg()
	{
		wait.until(ExpectedConditions.visibilityOf(orgDropdown));
		orgDropdown.click();
	}

	public void selectOrgAsCount(int count)
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(orgSelect))));
		List<WebElement> element = driver.findElements(By.xpath(orgSelect));
		System.out.println(element.size());
		System.out.println(element.size());
		for(int i = 1; i <= count; i++)
		{
			driver.findElement(By.xpath(orgSelect + "[" + i + "]")).click();
			val = pageLoad.getAttribute("class");
			int m=0;
			while(val.equalsIgnoreCase("loading_consumption"))
			{
				val = pageLoad.getAttribute("class");
				if(m==12)
					break;
				m++;
			}
		}
	}
	
	public void readDataSheet() 
	{
		try
		{
			usrMg = new UserManagement();
			end = new EndUser();
			boolean flag = false;
		
		FileInputStream ExcelFile = new FileInputStream(System.getProperty("user.dir") + "/src/test/java/resources/CourseFalseCompletionData.xlsx");
		XSSFWorkbook ewb = new XSSFWorkbook(ExcelFile);
		XSSFSheet sheet = ewb.getSheet("Sheet1");
		int last_row = sheet.getLastRowNum();
		for(int i = 1; i<= last_row; i++)
		{
			XSSFRow current_row = sheet.getRow(i);
			String userEmail = current_row.getCell(0).toString();
			String courseName = current_row.getCell(1).toString();
			String topicTitle = current_row.getCell(2).toString();
			String topicStatus = current_row.getCell(3).toString();
			usrMg.searchByEmail(userEmail);
			usrMg.clickSearch();
			usrMg.selectProxyUser();
			usrMg.switchTab();
			startCourseWithName(courseName);
			end.clickOnSubmitOnly();
		    int count = end.getAvailableTopicNumber();
		    if(count == 0)
		    {
		    	runningStatus = "Fail: As the topics are not available";
		    	current_row.createCell(5).setCellValue(runningStatus);
		    	usrMg.switchTab();
		    	usrMg.closeOtherTab();
		    	FileOutputStream fos = new FileOutputStream(System.getProperty("user.dir") + "/src/test/java/resources/CourseFalseCompletionData.xlsx");
				ewb.write(fos);
				fos.close();
		    	continue;
		    }
		    if(topicStatus.trim().equalsIgnoreCase("start"))
		    {
			    flag = startCourseTopicsWithName(topicTitle, topicStatus);
			    if(flag == false)
			    {
			    	runningStatus = "Fail: As the topic " + topicTitle + " and its status " + topicStatus + " is not matching";
			    	current_row.createCell(5).setCellValue(runningStatus);
			    	usrMg.switchTab();
			    	usrMg.closeOtherTab();
			    	FileOutputStream fos = new FileOutputStream(System.getProperty("user.dir") + "/src/test/java/resources/CourseFalseCompletionData.xlsx");
					ewb.write(fos);
					fos.close();
			    	continue;
			    }
			    else
			    {
			    	runningStatus = "Pass";
			    	current_row.createCell(5).setCellValue(runningStatus);
			    	usrMg.switchTab();
			    	usrMg.closeOtherTab();
			    	FileOutputStream fos = new FileOutputStream(System.getProperty("user.dir") + "/src/test/java/resources/CourseFalseCompletionData.xlsx");
					ewb.write(fos);
					fos.close();
			    	continue;
			    }			    	
			}
		    else
		    {
		    	runningStatus = "Pass as the topic status is in Resume/Review ";
		    	current_row.createCell(5).setCellValue(runningStatus);
		    	usrMg.switchTab();
		    	usrMg.closeOtherTab();
		    	FileOutputStream fos = new FileOutputStream(System.getProperty("user.dir") + "/src/test/java/resources/CourseFalseCompletionData.xlsx");
				ewb.write(fos);
				fos.close();
		    	continue;
		    }
		}
		ewb.close();
		
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
	}
	
	public boolean startCourseWithName(String courseName)
	{
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseTable + "[1]"))));
		List<WebElement> rowCount = driver.findElements(By.xpath(courseTable));
		for(int i = 1; i <= rowCount.size(); i++)
		{
			String courseAvailable = driver.findElement(By.xpath(courseTable + "[" + i + "]/td[1]")).getText();
			courseAvailable = courseAvailable.replace("New!", "");
			if(courseName.trim().equalsIgnoreCase(courseAvailable.trim()))
			{
				if(driver.findElements(By.xpath(courseTable + "[" + i + "]/td[5]")).size() > 0)
				{
					driver.findElement(By.xpath(courseTable + "[" + i + "]/td[5]")).click();
					flag = true;
					break;
				}
				else if(driver.findElements(By.xpath(courseTable + "[" + i + "]/td[4]")).size() > 0)
				{
					driver.findElement(By.xpath(courseTable + "[" + i + "]/td[4]")).click();
					flag = true;
					break;
				}
				else if(driver.findElements(By.xpath(courseTable + "[" + i + "]/td[3]")).size() > 0)
				{
					driver.findElement(By.xpath(courseTable + "[" + i + "]/td[3]//a")).click();
					flag = true;
					break;
				}
			}
			
		}
		return flag;
	}

	public boolean startCourseTopicsWithName(String topicName, String status) throws Exception
	{
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(topicTable + "[1]"))));
		List<WebElement> rowCount = driver.findElements(By.xpath(topicTable));
		for(int i = 1; i <= rowCount.size(); i++)
		{
			String topicAvailable = driver.findElement(By.xpath(topicTable + "[" + i + "]/td[1]")).getText();
			String topicStatus = "";
			if(driver.findElements(By.xpath(topicTable + "[" + i + "]/td[4]/a")).size() > 0)
			{
				topicStatus = driver.findElement(By.xpath(topicTable + "[" + i + "]/td[4]/a")).getText();			
			}				
			if(topicName.trim().equalsIgnoreCase(topicAvailable.trim()) && status.trim().equalsIgnoreCase(topicStatus))
			{
				if(driver.findElements(By.xpath(courseTable + "[" + i + "]/td[4]/a")).size() > 0)
				{
					driver.findElement(By.xpath(courseTable + "[" + i + "]/td[4]/a")).click();
					Thread.sleep(10000);
					end.onlyExitCourse();
					flag = true;
					break;
				}
			}
			
		}
		return flag;
	}


}
	

