package com.qa.pages;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.qa.util.TestBase;

public class OrgMigration extends TestBase{
	
	@FindBy(xpath = "//*[@id='bs-example-navbar-collapse-1']//li/a[text()='Organization Migration']")
	WebElement OrganizationMigrationTab;
	
	@FindBy(xpath = "//li//a[text()='Organization Migration']/preceding::li[3]/a[text()='Reports']")
	WebElement validateifReportisNexttoOrgM;
	
	@FindBy(xpath = "//table[@id='table_listing']/thead//th")
	List<WebElement> MigrationColumns;
	
	@FindBy(xpath = "//*[@id='table_listing']//a[contains(text(),'View Report')]")
	WebElement viewReport;
	
	@FindBy(xpath = "//a[text()=' Schedule Migration ']")
	WebElement  scheduleMigrationBtn ;
	
	@FindBy(xpath = "//*[@id='select2-source_org_id-container']")
	WebElement  sourceOrganization ;
	
	@FindBy(xpath = "//*[@id='select2-target_org_id-container']")
	WebElement  targetOrganization ;
	
	@FindBy(xpath = "//*[@id='migrate_all_users']")
	WebElement  migrateAllUsers ;
	
	@FindBy(xpath = "//*[@name='all_courses']")
	WebElement  allcourses ;
	
	
	
	@FindBy(xpath = "//input[@aria-controls='select2-source_org_id-results']")
	WebElement  inputsourceOrganization ;
	
	@FindBy(xpath = "//input[@aria-controls='select2-target_org_id-results']")
	WebElement  inputstargetOrganization ;
	
	@FindBy(xpath = "(//*[@id='org_migration']//ul[@class='select2-selection__rendered'])[1]")
	WebElement  selectUnit ;
	
	@FindBy(xpath = "(//*[@id='org_migration']//ul[@class='select2-selection__rendered'])[2]")
	WebElement  selectcourses ;
	
	@FindBy(xpath = "//*[@id='org_migration']//button[text()='Submit'  and not(contains(@class,'disabled')) ]")
	WebElement  submitBtn ;
	
	@FindBy(xpath = "//*[@id='org_migration']//a[text()='Cancel']")
	WebElement  cancelBtn ;
	
	
	
	@FindBy(xpath = "//*[@id='rollback']")
	WebElement  rollback ;
	
	
	@FindBy(xpath = "//*[@id='migration_type']")
	WebElement  migration_type ;
	
	
	public OrgMigration() 
	{
		PageFactory.initElements(driver, this);
		
	}
	
	public void clickOrganizationMigrationTab()
	{
		wait.until(ExpectedConditions.visibilityOf(OrganizationMigrationTab));
		OrganizationMigrationTab.click();
		
		Assert.assertEquals("Reports tab is not next to Organization Migration",validateifReportisNexttoOrgM.getText(), "Reports");
	}

	public void scheduleMigrationBtn()
	{
		try
		{
		wait.until(ExpectedConditions.visibilityOf(scheduleMigrationBtn));
		scheduleMigrationBtn.click();
		}
		catch(NoSuchElementException e)
		{
			Assert.fail("Schedule Migration Missing");
		}
	}

	public void OrganizationMigrationColumnsValidation(List<String> text, String tc) throws Exception
	{
		Thread.sleep(3000);
		
		int count = 0;
		for(WebElement col : MigrationColumns){
			System.out.println(col.getAttribute("innerText"));
			Assert.assertEquals(text.get(count).toUpperCase(), col.getAttribute("innerText"));
			count++;
		}

	}
	
	public void clickviewReportTab()
	{
		try
		{
		wait.until(ExpectedConditions.visibilityOf(viewReport));
		viewReport.click();
		}
		catch(NoSuchElementException e)
		{
			Assert.fail("No Records found in Organization Migration");
		}
	}
	
	public void clickviewscheduleMigrationBtn()
	{
		try
		{
		wait.until(ExpectedConditions.visibilityOf(scheduleMigrationBtn));
		scheduleMigrationBtn.click();
		}
		catch(NoSuchElementException e)
		{
			Assert.fail("Schedule Migration Missing");
		}
	}
	
	
	public void selectmigration_type(String selectoption)
	{
		try
		{
			wait.until(ExpectedConditions.visibilityOf(migration_type));
			
			Select migrationtypedropDown = new Select(migration_type);
			migration_type.click();
			migrationtypedropDown.selectByVisibleText(selectoption);
			Assert.assertEquals(migrationtypedropDown.getFirstSelectedOption().getText(), selectoption);
			
		}
		catch(NoSuchElementException e)
		{
			Assert.fail("Migration type Missing");
		}
	}
	
	public void selectsourceOrganization()
	{
		try
		{
			wait.until(ExpectedConditions.visibilityOf(sourceOrganization));
			
			sourceOrganization.click();
			inputsourceOrganization.sendKeys(TestBase.prop.getProperty("orgName"));
		
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//li[contains(text(),'"+TestBase.prop.getProperty("orgName")+"')]"))));
			
			driver.findElement(By.xpath("//li[contains(text(),'"+TestBase.prop.getProperty("orgName")+"')]")).click();
		}
		catch(NoSuchElementException e)
		{
			Assert.fail("Migration type Missing");
		}
	}
	
	public void selecttargetOrganization()
	{
		try
		{
			wait.until(ExpectedConditions.visibilityOf(targetOrganization));
			
			targetOrganization.click();
			inputstargetOrganization.sendKeys(TestBase.prop.getProperty("orgName"));
		
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//li[contains(text(),'"+TestBase.prop.getProperty("orgName")+"')]"))));
			
			driver.findElement(By.xpath("//li[contains(text(),'"+TestBase.prop.getProperty("orgName")+"')]")).click();
		}
		catch(NoSuchElementException e)
		{
			Assert.fail("Migration type Missing");
		}
	}
	
	public void migrateAllUsersclick()
	{
		try
		{
			wait.until(ExpectedConditions.visibilityOf(migrateAllUsers));
			
			migrateAllUsers.click();
			}
		catch(NoSuchElementException e)
		{
			Assert.fail("migrate All Users check box Missing");
		}
	}
	
	
	public void selectUnits(String unit)
	{
		try
		{
			Thread.sleep(6000);
			wait.until(ExpectedConditions.visibilityOf(selectUnit));
			selectUnit.click();
			
		
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//li[contains(text(),'"+unit+"')]"))));
			
			driver.findElement(By.xpath("//li[contains(text(),'"+unit+"')]")).click();
		}
		catch(NoSuchElementException e)
		{
			Assert.fail("select Units Missing");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	
	public void selectCourse(String course)
	{
		try
		{
			if(courseListName.containsKey(course+"Option"))
				course=courseListName.get(course+"Option").toString();
			
			Thread.sleep(4000);
			wait.until(ExpectedConditions.visibilityOf(selectcourses));
			
			selectcourses.click();
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//li[contains(text(),'"+course+"')]"))));
			
			driver.findElement(By.xpath("//li[contains(text(),'"+course+"')]")).click();
		}
		catch(NoSuchElementException e)
		{
			e.printStackTrace();
			Assert.fail("select Course Missing");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	public void allcoursesclick()
	{
		try
		{
			wait.until(ExpectedConditions.visibilityOf(allcourses));
			
			allcourses.click();
			}
		catch(NoSuchElementException e)
		{
			Assert.fail("All Courses check box Missing");
		}
	}
	public void clickonsubmitBtn()
	{
		try
		{
			wait.until(ExpectedConditions.visibilityOf(submitBtn));
			
//			submitBtn.click();
			}
		catch(NoSuchElementException e)
		{
			Assert.fail("submit Btn Missing");
		}
	}

	public void clickonCancel()
	{
		try
		{
			wait.until(ExpectedConditions.visibilityOf(cancelBtn));
			
//			submitBtn.click();
			}
		catch(NoSuchElementException e)
		{
			Assert.fail("submit Btn Missing");
		}
	}
	public void clickonrollbackBtn()
	{
		try
		{
			wait.until(ExpectedConditions.visibilityOf(rollback));
			
//			submitBtn.click();
			}
		catch(NoSuchElementException e)
		{
			Assert.fail("rollback Btn Missing");
		}
	}

	
	public void validateorg()
	{
		try
		{
			wait.until(ExpectedConditions.visibilityOf(targetOrganization));
			
			
			driver.findElement(By.xpath("//span[contains(text(),'"+TestBase.prop.getProperty("orgName")+"')]"));
			
			Assert.assertTrue(driver.findElement(By.xpath("//span[contains(text(),'"+TestBase.prop.getProperty("orgName")+"')]")).getText().contains(TestBase.prop.getProperty("orgName")));
		}
		catch(NoSuchElementException e)
		{
			Assert.fail("Migration type Missing");
		}
	}
	
	public void validatedetails(String data)
	{
		try
		{
			if(courseListName.containsKey(data+"Option"))
				data=courseListName.get(data+"Option").toString();
		
			wait.until(ExpectedConditions.visibilityOf(targetOrganization));
			
			
			driver.findElement(By.xpath("//li[contains(text(),'"+data+"')]"));
			
			System.out.println(driver.findElement(By.xpath("//li[contains(text(),'"+data+"')]")).getText());

			System.out.println(data);
			Assert.assertTrue(driver.findElement(By.xpath("//li[contains(text(),'"+data+"')]")).getText().contains( data.replace("  ", " ")));
		}
		catch(NoSuchElementException e)
		{
			Assert.fail("Migration type Missing");
		}
	}
}
