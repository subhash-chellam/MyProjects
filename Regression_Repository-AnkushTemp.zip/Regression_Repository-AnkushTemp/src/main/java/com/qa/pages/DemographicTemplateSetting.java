package com.qa.pages;

import java.util.List;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.qa.util.TestBase;

public class DemographicTemplateSetting extends TestBase
{
	@FindBy(xpath = "//a[contains(text(),'Demographic Template Settings')]")
	WebElement demographicTemplateSettingsLink;

	@FindBy(xpath = "//select[@id=\"encryption-method\"]")
	WebElement encryptionMethod;

	@FindBy(xpath = "//select[@id=\"encryption-method\"]/option")
	WebElement defaultEncryptionMethod;

	@FindBy(xpath = "//option[contains(text(),'PGP Encryption - 2048')]")
	WebElement pgpEncryption2048;

	@FindBy(xpath = "//button[contains(text(),'Upload Key')]")
	WebElement uploadKeyBtn;

	@FindBy(xpath = "//button[contains(text(),'Generate Key')]")
	WebElement generateKeyBtn;

	@FindBy(xpath = "//div[contains(@class,'alert-success')]")
	WebElement encryptionKeySuccessMsg;

	@FindBy(xpath = "(//*[@class = 'close'])[1]")
	WebElement successMsgCloseButton;

	@FindBy(xpath = "//a[contains(@title,'Delete Column')]")
	WebElement deleteColumnIcon;

	@FindBy(xpath = "//h4[contains(text(),'Delete Column')]")
	WebElement deleteColumnPopupHeader;

	@FindBy(xpath = "//button[contains(text(),'Delete')]")
	WebElement deleteBtnPopup;

	@FindBy(xpath = "//div[contains(@class,'alert-success')]")
	WebElement columnDeletedSuccessMsg;

	@FindBy(xpath = "//span[contains(text(),'View Key')]")
	WebElement viewKeyBtn;

	@FindBy(xpath = "//strong[contains(text(),'Encryption Key - View')]")
	WebElement encryptionKeyPopupHeader;

	@FindBy(xpath = "//button[contains(text(),' Close')]")
	WebElement encryptionKeyCloseBtn;

	@FindBy(xpath = "//button[contains(text(),'Remove Encryption')]")
	WebElement removeEncryptionBtn;

	@FindBy(xpath = "//div[contains(@class,'alert-success')]")
	WebElement encryptionKeyRemovedSuccessMsg;

	@FindBy(xpath = "//div[contains(@class,'alert-success')]")
	WebElement columnAddedSuccessMsg;

	@FindBy(xpath = "//div[contains(@class,'alert-success')]")
	WebElement columnRemovedSuccessMsg;

	@FindBy(xpath = "//button[contains(text(),'Generate New Key ')]")
	WebElement generateNewKeyBtn;

	@FindBy(xpath = "//select[@id=\"encryption-method\"]")
	WebElement disableEncryptionMethod;

	@FindBy(xpath = "//input[@id=\"column_name\"]")
	WebElement columnHeaderName;

	@FindBy(xpath = "//select[@id=\"datatype\"]")
	WebElement selectDataType;

	@FindBy(xpath = "//input[@id=\"column_max_length\"]")
	WebElement maxAllowedChars;

	@FindBy(xpath = "//select[@id=\"validation\"]")
	WebElement selectValidation;

	@FindBy(xpath = "//button[contains(text(),'Add Column')]")
	WebElement addColumnBtn;

	//////////////////////////////////////////

	@FindBy(xpath = "//a[text() = 'Organization Settings']")
	WebElement OrganizationSettingsTab;

	@FindBy(xpath = "//a[contains(text(), 'Demographic Settings')]")
	WebElement DemographicSettingsTab;

	@FindBy(xpath = "//a[@class='action_dropdown']")
	WebElement actionsBtn;

	@FindBy(xpath = "//a[contains(text(),'Demographic Settings')]")
	WebElement demographicSettingslink;

	@FindBy(xpath = "//label[@id='deltachangetext']")
	WebElement fullFeed;

	@FindBy(xpath = "//button[@id='submitBtn']")
	WebElement demographicSettingsSaveBtn;

	@FindBy(xpath = "//div[contains(@class,'alert-success')]")
	WebElement demographicSettingsSuccessMsg;

	
	String downloadPath = System.getProperty("user.dir") + prop.getProperty("downloadPath");
	public static String titleName, groupName1, groupName2, filePath;
	String fileName;


	@FindBy(xpath = "//a[text() = 'Demographic Template Settings']")
	WebElement templateLink;

	@FindBy(xpath = "//input[@name = 'column_name']")
	WebElement columnName;
	
	
	@FindBy(xpath = "//input[@name = 'column_max_length']")
	WebElement columnLength;
	
	
	@FindBy(xpath = "//button[text() = 'Add Column']")
	WebElement addButton;
	
	@FindBy(xpath = "//table[@id = 'customer-admin-list']")
	WebElement columnTable;
	
	
	@FindBy(xpath = "//*/a[@title=\"Delete Column\"]")
	WebElement deleterow;
	
	
	
	@FindBy(xpath = "//button[text()='Delete']")
	WebElement deleteBtn;
	
	By row = By.xpath("//table[@id = 'customer-admin-list']/tbody/tr");
	
	public DemographicTemplateSetting()
	{
		PageFactory.initElements(driver, this);
	}
	
	public void clickDemographicTemplateSetting() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(demographicTemplateSettingsLink));
		demographicTemplateSettingsLink.click();
	}

	public void selectEncryptionMethod() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(encryptionMethod));
		encryptionMethod.click();
		wait.until(ExpectedConditions.visibilityOf(pgpEncryption2048));
		pgpEncryption2048.click();
	}

	public void verifySelectEncryptionMethod() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean value = wait.until(ExpectedConditions.visibilityOf(defaultEncryptionMethod)).isDisplayed();
		Assert.assertTrue(value);
	}

	public void verifyUploadKeyDisabled() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		boolean value1 = wait.until(ExpectedConditions.visibilityOf(uploadKeyBtn)).isEnabled();
		Assert.assertFalse(value1);
	}

	public void selectValueAndUploadEnabled() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(encryptionMethod));
		encryptionMethod.click();
		wait.until(ExpectedConditions.visibilityOf(pgpEncryption2048));
		pgpEncryption2048.click();
		boolean value2 = wait.until(ExpectedConditions.visibilityOf(uploadKeyBtn)).isEnabled();
		Assert.assertTrue(value2);
	}

	public void generateKeyAndVerifySuccessMsg(String msg) {
		try {
			 if(AssignmentReport. checkifParmeterAvailable(msg))
				 msg=AssignmentReport.getParmeterAvailable(msg);
		
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(generateKeyBtn));
			generateKeyBtn.click();
			System.out.println("Validate Message " + msg);
			wait.until(ExpectedConditions.visibilityOf(encryptionKeySuccessMsg));
			System.out.println("Message in UI " + encryptionKeySuccessMsg.getText());
			Assert.assertTrue(encryptionKeySuccessMsg.getText().contains(msg));
			wait.until(ExpectedConditions.visibilityOf(successMsgCloseButton));
			successMsgCloseButton.click();
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Error while generating key");
		}
	}

	public void verifyViewKeyLinkAndClosePopup() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(viewKeyBtn));
		viewKeyBtn.click();
		wait.until(ExpectedConditions.visibilityOf(encryptionKeyPopupHeader)).isDisplayed();
		wait.until(ExpectedConditions.visibilityOf(encryptionKeyCloseBtn));
		encryptionKeyCloseBtn.click();
	}

	public void regenerateKeyAndVerifySuccessMsg(String msg) {
		try {
			 if(AssignmentReport. checkifParmeterAvailable(msg))
				 msg=AssignmentReport.getParmeterAvailable(msg);
		
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(generateNewKeyBtn));
			generateNewKeyBtn.click();
			System.out.println("Validate Message " + msg);
			wait.until(ExpectedConditions.visibilityOf(encryptionKeySuccessMsg));
			System.out.println("Message in UI " + encryptionKeySuccessMsg.getText());
			Assert.assertTrue(encryptionKeySuccessMsg.getText().contains(msg));
			wait.until(ExpectedConditions.visibilityOf(successMsgCloseButton));
			successMsgCloseButton.click();
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Error occurred during the generation of encryption key. Please try again");
		}
	}

	public void removeEncryptionKeyAndVerifyMsg(String msg) {
		try {
			 if(AssignmentReport. checkifParmeterAvailable(msg))
				 msg=AssignmentReport.getParmeterAvailable(msg);
		
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(removeEncryptionBtn));
			removeEncryptionBtn.click();
			System.out.println("Validate Message " + msg);
			wait.until(ExpectedConditions.visibilityOf(encryptionKeyRemovedSuccessMsg));
			System.out.println("Message in UI " + encryptionKeyRemovedSuccessMsg.getText());
			Assert.assertTrue(encryptionKeyRemovedSuccessMsg.getText().contains(msg));
			wait.until(ExpectedConditions.visibilityOf(successMsgCloseButton));
			successMsgCloseButton.click();
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Error while removing the encryption key");
		}
	}

	/*
	 * public void addColumn() {
	 * 
	 * WebDriverWait wait = new WebDriverWait(driver, 30);
	 * wait.until(ExpectedConditions.visibilityOf(columnHeaderName)).sendKeys(
	 * "Auto_Test"); Select select = new Select(selectDataType);
	 * select.selectByVisibleText("Text");
	 * wait.until(ExpectedConditions.visibilityOf(maxAllowedChars)).sendKeys("100");
	 * Select s = new Select(selectValidation); s.selectByVisibleText("Mandatory");
	 * wait.until(ExpectedConditions.visibilityOf(addColumnBtn));
	 * addColumnBtn.click();
	 * wait.until(ExpectedConditions.visibilityOf(columnAddedSuccessMsg));
	 * System.out.println("Message in UI " + columnAddedSuccessMsg.getText());
	 * Assert.assertTrue(columnAddedSuccessMsg.getText().contains(message));
	 * wait.until(ExpectedConditions.visibilityOf(successMsgCloseButton));
	 * successMsgCloseButton.click(); }
	 */

	public void addColumn(String message) {
		try {
			 if(AssignmentReport. checkifParmeterAvailable(message))
				 message=AssignmentReport.getParmeterAvailable(message);
		
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(columnHeaderName)).sendKeys("Auto_Test");
			Select select = new Select(selectDataType);
			select.selectByVisibleText("Text");
			wait.until(ExpectedConditions.visibilityOf(maxAllowedChars)).sendKeys("100");
			Select s = new Select(selectValidation);
			s.selectByVisibleText("Optional");
			wait.until(ExpectedConditions.visibilityOf(addColumnBtn));
			addColumnBtn.click();
			wait.until(ExpectedConditions.visibilityOf(columnAddedSuccessMsg));
			System.out.println("Message in UI " + columnAddedSuccessMsg.getText());
			Assert.assertTrue(columnAddedSuccessMsg.getText().contains(message));
			wait.until(ExpectedConditions.visibilityOf(successMsgCloseButton));
			successMsgCloseButton.click();
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Error while adding column");
		}

	}

	public void deleteColumn(String message) {
		try {
			 if(AssignmentReport. checkifParmeterAvailable(message))
				 message=AssignmentReport.getParmeterAvailable(message);
		
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(deleteColumnIcon));
			deleteColumnIcon.click();
			wait.until(ExpectedConditions.visibilityOf(deleteColumnPopupHeader)).isDisplayed();
			wait.until(ExpectedConditions.visibilityOf(deleteBtnPopup)).click();
			wait.until(ExpectedConditions.visibilityOf(columnRemovedSuccessMsg));
			System.out.println("Message in UI " + columnRemovedSuccessMsg.getText());
			Assert.assertTrue(columnRemovedSuccessMsg.getText().contains(message));
			wait.until(ExpectedConditions.visibilityOf(successMsgCloseButton));
			successMsgCloseButton.click();
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Error while deleting column");
		}

	}

	
	
	public void clickDemographicSetting()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(templateLink));
		templateLink.click();
	}

	
	public void deleterow()
	{
	
		try
		{
			deleterow.click();
		
		Thread.sleep(5000);
		deleteBtn.click();
		Thread.sleep(5000);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[contains(@class,'alert alert-success')]"))));
				
		}
		catch(NoSuchElementException | InterruptedException e)
		{
			
		}
	}
	
	public void addNewColumn(String name, String type, String length, String validation)
	{
		wait.until(ExpectedConditions.visibilityOf(columnName));
		columnName.sendKeys(name);
		Select select = new Select(selectDataType);
		select.selectByVisibleText(type);
		columnLength.sendKeys(length);
		select = new Select(selectValidation);
		select.selectByVisibleText(validation);
		addButton.click();
		validateAddedRow();
	}

	public void validateAddedRow()
	{
		wait.until(ExpectedConditions.visibilityOf(columnTable));
		List<WebElement> rows = driver.findElements(row);
		Assert.assertEquals(1, rows.size());
	}

}
