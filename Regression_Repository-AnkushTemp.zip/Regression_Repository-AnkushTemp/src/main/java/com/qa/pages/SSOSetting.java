package com.qa.pages;

import java.util.ArrayList;

import org.junit.Assert;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.util.TestBase;

public class SSOSetting extends TestBase
{
	@FindBy(xpath = "//a[contains(text(), 'SSO Settings')]")
	WebElement ssoSettingTab;
	
	@FindBy(xpath = "//button[text()= 'Generate SSO Settings']")
	WebElement generateButton;
	
	@FindBy(xpath = "//label[text() = 'Keycloak Settings']")
	WebElement keyClockLabel;

	String oldTab, newTab;
	
	public SSOSetting() 
	{
		PageFactory.initElements(driver, this);
	}
	
	public void clickOnSSOTab()
	{
		ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
		oldTab = tabs.get(0);
		newTab = tabs.get(1);
	    driver.switchTo().window(newTab);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(ssoSettingTab));
		ssoSettingTab.click();
	}
	public void CheckGenerateButton() {
		try {
			Thread.sleep(2000);
				WebDriverWait wwait = new WebDriverWait(driver, 120);
				wwait.until(ExpectedConditions.visibilityOf(generateButton));
				generateButton.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	
	}
	public void clickOnGenerateButton()
	{
		WebDriverWait wait = new WebDriverWait(driver, 120);
		wait.until(ExpectedConditions.visibilityOf(generateButton));
		generateButton.click();
		

	}
	
	public void closeTab()
	{
		driver.close();
		driver.switchTo().window(oldTab);
	}

}
