package com.qa.pages;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.opencsv.CSVReader;
import com.qa.util.TestBase;

public class IltReports extends TestBase
{
	
	@FindBy(xpath = "//a[text() = 'ILT Reports']")
	WebElement iltReportsTab;
	
	@FindBy(xpath = "//a[text() = 'Classes']")
	WebElement iltReportsClassTab;
	
	@FindBy(xpath = "//button[@id = 'export-btn']")
	WebElement exportButton;
	
	String val;
	String table = "//table[@id = 'table_ilt_report_listing']/tbody";
	String classTable = "//table[@id = 'classTablelisting']/tbody";
	String enableExportButton = "//button[@id = 'export-btn' and not(contains(@class, 'disabled'))]";
	
	public static String oldAvailableLicenseCount, oldNumberEcard,newAvailableLicenseCount,newNumberEcard,oldEcardClass,newEcardClass; 
	
	String downloadPath = System.getProperty("user.dir") + prop.getProperty("downloadPath");
	JavascriptExecutor js = (JavascriptExecutor)driver;
	User usr;

	public IltReports() 
	{
		PageFactory.initElements(driver, this);
	}
	
	public void navigateILtReport()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", iltReportsTab);
	}
	
	public void getDetails(String courseName)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRow = driver.findElements(By.xpath(table + "/tr"));
		while(!(tableRow.size() >= 1))
			tableRow = driver.findElements(By.xpath(table + "/tr"));
		for(int i = 1; i <= tableRow.size(); i++)
		{
			String course = driver.findElement(By.xpath(table + "/tr[" + i + "]/td[1]")).getText();
			if(course.equalsIgnoreCase(courseName))
			{
				oldAvailableLicenseCount = driver.findElement(By.xpath(table + "/tr[" + i + "]/td[2]")).getText();
				oldNumberEcard = driver.findElement(By.xpath(table + "/tr[" + i + "]/td[3]")).getText();
			}
		}
	}
	
	public void getNewDetails(String courseName)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table))));
		List<WebElement> tableRow = driver.findElements(By.xpath(table + "/tr"));
		while(!(tableRow.size() >= 1))
			tableRow = driver.findElements(By.xpath(table + "/tr"));
		for(int i = 1; i <= tableRow.size(); i++)
		{
			String course = driver.findElement(By.xpath(table + "/tr[" + i + "]/td[1]")).getText();
			if(course.equalsIgnoreCase(courseName))
			{
				newAvailableLicenseCount = driver.findElement(By.xpath(table + "/tr[" + i + "]/td[2]")).getText();
				newNumberEcard = driver.findElement(By.xpath(table + "/tr[" + i + "]/td[3]")).getText();
			}
		}
	}
	
	public void validateLicenseCountDifference(int diff)
	{
		Assert.assertTrue(Integer.parseInt(oldAvailableLicenseCount) - Integer.parseInt(newAvailableLicenseCount) == diff);
	}
	
	public void validateEcardCountDifference(int diff)
	{
		Assert.assertTrue(Integer.parseInt(newNumberEcard) - Integer.parseInt(oldNumberEcard) == diff);
	}

////////////////////////////////////////////////////////////////////////////////////	
	
	public void navigateILtReportClassPage()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", iltReportsClassTab);
	}
	
	public void getClassDetails(String courseName)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(classTable))));
		List<WebElement> tableRow = driver.findElements(By.xpath(classTable + "/tr"));
		while(!(tableRow.size() >= 1))
			tableRow = driver.findElements(By.xpath(classTable + "/tr"));
		for(int i = 1; i <= tableRow.size(); i++)
		{
			String className = driver.findElement(By.xpath(classTable + "/tr[" + i + "]/td[1]")).getText();
			String course = driver.findElement(By.xpath(classTable + "/tr[" + i + "]/td[2]")).getText();
			if(className.equalsIgnoreCase(IltTab.createdClassName) && course.equalsIgnoreCase(courseName))
			{
				oldEcardClass = driver.findElement(By.xpath(classTable + "/tr[" + i + "]/td[3]")).getText();
			}
		}
	}
	
	public void getNewClassDetails(String courseName)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(classTable))));
		List<WebElement> tableRow = driver.findElements(By.xpath(classTable + "/tr"));
		while(!(tableRow.size() >= 1))
			tableRow = driver.findElements(By.xpath(classTable + "/tr"));
		for(int i = 1; i <= tableRow.size(); i++)
		{
			String className = driver.findElement(By.xpath(classTable + "/tr[" + i + "]/td[1]")).getText();
			String course = driver.findElement(By.xpath(classTable + "/tr[" + i + "]/td[2]")).getText();
			if(className.equalsIgnoreCase(IltTab.createdClassName) && course.equalsIgnoreCase(courseName))
			{
				newEcardClass = driver.findElement(By.xpath(classTable + "/tr[" + i + "]/td[3]")).getText();
			}
		}
	}
	
	public void validateEcardCountDifferenceClass(int diff)
	{
		Assert.assertTrue(Integer.parseInt(newNumberEcard) - Integer.parseInt(oldNumberEcard) == diff);
	}
	
	public void clickExportButton()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(exportButton));
			int counter = 0;
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				val = js.executeScript("return document.readyState").toString();
				counter = counter +1;
				if(counter > 24)
					break;
			}
			if(driver.findElements(By.xpath(enableExportButton)).size()>0)
				js.executeScript("arguments[0].click();", exportButton);
			else
				Assert.fail("Export button is diabled as no record is available");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	public void verifyDownloadFile()
	{
		try 
		{
			usr = new User();
			int counter = 0;
			boolean dwnld = false;
			do 
			{
				Thread.sleep(5000);
				dwnld = usr.isFileDownloaded_Ext(downloadPath, ".csv");
				counter = counter +1;
				if(counter > 24)
					break;
			}
			while(dwnld == false);
		} 
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}
	}
	
	
	public void validateClassDetails()
	{
		try 
		{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(classTable))));
		File file = new File(User.filePath); 
		List<WebElement> rows = driver.findElements(By.xpath(classTable));		
		Thread.sleep(5000);
		FileReader filereader = new FileReader(file);
		CSVReader csvReader = new CSVReader(filereader); 
		List<String[]> header = csvReader.readAll();
		ArrayList<String> rowData =new ArrayList<String>();
		ArrayList<String> reportData =new ArrayList<String>();
		String []excel = header.get(header.size() - 1);
		String data[] = excel[0].split(";");
		for(int i = 1; i <= rows.size(); i++)
		{
			String text = driver.findElement(By.xpath(classTable + "[" + i + "]")).getText();
			System.out.println(text);
			if(!(text.length() == 0))
			{
				if(text.contains("sess="))
				{
					text= text.split("sess=")[0];
				}
				rowData.add(text);
			}
			else
			{
				text = driver.findElement(By.xpath(classTable + "[" + i + "]/a")).getAttribute("href");
				if(text.contains("sess="))
				{
					text= text.split("sess=")[0];
				}
				if(text.length()>0)
				{
					rowData.add(text);
				}
			}
		}
		for (int i = 0; i<=data.length-1; i++) 
		{
			if(data[i].contains("sess="))
			{
				data[i]= data[i].split("sess=")[0];
			}
			reportData.add(data[i].replace("\"", ""));
		}
		
		System.out.println(rowData);
		System.out.println(reportData);
		for(int i = 0; i<= rowData.size()-1; i++)
		{
			Assert.assertEquals(reportData.get(i).trim().toLowerCase(), rowData.get(i).trim().toLowerCase());
		}
		csvReader.close();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	public void compareDetails()
	{
		try
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String  uiList[][];
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(table + "/tr"))));
			List<WebElement> tableRows = driver.findElements(By.xpath(table + "/tr"));
			List<List<String>> list_UI = new ArrayList<>();
			List<List<String>> list_report = new ArrayList<>();
			File file = new File(User.filePath);
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			List<String[]> header = csvReader.readAll();
			int rowCount = tableRows.size();
			uiList = new String[rowCount][3];
			String reportDetails[][] = new String[header.size() - 1][3];
			for (int i= 1; i<= rowCount; i++)
			{
				for(int j = 1; j <= 3; j++)
				{
					String textValue = driver.findElement(By.xpath("(" + table + "/tr" + ")[" + i + "]/td[" + j + "]")).getText();
					uiList[i-1][j-1] = textValue;
				}
			}
			for (String[] ints : uiList) 
			{
				list_UI.add(Arrays.asList(ints));
			}
			for(int i = 1; i <= header.size() - 1; i++)
			{
				String []excel = header.get(i);
				for(int j = 0; j <= 2; j++)
				{
					reportDetails[i-1][j] = excel[j].replace("\"", "").trim();
				}				
			}
			csvReader.close();
			for (String[] ints : reportDetails) {
				list_report.add(Arrays.asList(ints));
			}
			List<List<String>> differences = new ArrayList<>(list_UI);
			differences.removeAll(list_report);
			Assert.assertTrue(differences.size() == 0);
		}
		catch(Exception e)
		{
			
		}
	}

	public void compareClassDetails()
	{
		try
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String  uiList[][];
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(classTable + "/tr"))));
			List<WebElement> tableRows = driver.findElements(By.xpath(classTable + "/tr"));
			List<List<String>> list_UI = new ArrayList<>();
			List<List<String>> list_report = new ArrayList<>();
			File file = new File(User.filePath);
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			List<String[]> header = csvReader.readAll();
			int rowCount = tableRows.size();
			uiList = new String[rowCount][3];
			String reportDetails[][] = new String[header.size() - 1][3];
			for (int i= 1; i<= rowCount; i++)
			{
				for(int j = 1; j <= 3; j++)
				{
					String textValue = driver.findElement(By.xpath("(" + classTable + "/tr" + ")[" + i + "]/td[" + j + "]")).getText();
					uiList[i-1][j-1] = textValue;
				}
			}
			for (String[] ints : uiList) 
			{
				list_UI.add(Arrays.asList(ints));
			}
			for(int i = 1; i <= header.size() - 1; i++)
			{
				String []excel = header.get(i);
				for(int j = 0; j <= 2; j++)
				{
					reportDetails[i-1][j] = excel[j].replace("\"", "").trim();
				}				
			}
			csvReader.close();
			for (String[] ints : reportDetails) {
				list_report.add(Arrays.asList(ints));
			}
			List<List<String>> differences = new ArrayList<>(list_UI);
			differences.removeAll(list_report);
			Assert.assertTrue(differences.size() == 0);
		}
		catch(Exception e)
		{
			
		}
	}
	
	
}
