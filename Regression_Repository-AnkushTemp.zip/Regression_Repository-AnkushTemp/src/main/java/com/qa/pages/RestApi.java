package com.qa.pages;

import java.nio.file.Files;
import java.nio.file.Paths;

import com.qa.util.TestBase;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class RestApi extends TestBase {

	String api = "https://cs3n-staging.contentservice.net/op_lis_endpoint";
	String orgBody = "";
	String filepath = System.getProperty("user.dir") +"\\src\\test\\java\\resources\\RestApi.txt";
	public void getResponse(String value)
	{
	  try 
	  {
		  String api=prop.getProperty("Endpoint"+prop.getProperty("environment"));
					
		  orgBody = new String(Files.readAllBytes(Paths.get(filepath)));
		  int start = orgBody.indexOf("<sourcedId>");
		  int last = orgBody.indexOf("</sourcedId>");
		  orgBody = orgBody.replace(orgBody.substring(start+11, last), value);
		  System.out.println(orgBody);
		  RestAssured.baseURI = api;
		  Response res = RestAssured.given().contentType(ContentType.XML).
				  		body(orgBody).when().post().then().
				  		assertThat().statusCode(200).and().extract().response();
//		  System.out.println(res);
		  }
		  catch(Exception e)
		  {
			  System.out.println(e.getMessage());
		  }		
	}
}
