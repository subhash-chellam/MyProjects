package com.qa.pages;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.util.TestBase;

public class Healthcheck  extends TestBase {
	
	@FindBy(xpath = "//input[@role=\"searchbox\"]")
	WebElement searchbox;

	@FindBy(xpath = "//a[text()='Clear Search']")
	WebElement clearSearch;

	
	

	@FindBy(xpath = "//td[text()='No records present.']")
	WebElement noRecords;

	@FindBy(xpath = "//*[@id=\"select2-courseId-container\"]")
	WebElement search;

	@FindBy(xpath = "//ul[@id=\"select2-courseId-results\"]/li")
	WebElement searchresult;


	@FindBy(xpath = "//*[@id=\"search\"]")
	WebElement searchbutton;

	String val;
	String searchTable = "//table[contains(@id,'courseList')]//th"; 
	String row = "//table[contains(@id,'courseList')]//tbody//tr";
	
	@FindBy(xpath = "//body//div[@class='content body-content']")
	WebElement pageLoad;
	
	@FindBy(xpath = "//table[@id='courseList']//tbody//tr/td")
	WebElement Text_NoReportsDataFound;
	
	public Healthcheck() 
	{
		PageFactory.initElements(driver, this);
	}

	public void searchCourse(String Course)
	{
		try 
		{
			if(courseListName.containsKey(Course+"Option"))
				Course=courseListName.get(Course+"Option").toString();
			
			Course = Course.replace("Â", "");
			
			
			
			wait.until(ExpectedConditions.visibilityOf(search));
			search.click();
		
			wait.until(ExpectedConditions.visibilityOf(searchbox));
			searchbox.sendKeys(Course);

			wait.until(ExpectedConditions.visibilityOf(searchresult));
			searchresult.click();

			wait.until(ExpectedConditions.visibilityOf(searchbutton));

			searchbutton.click();
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
	}
	
	public void Clearsearch()
	{
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(clearSearch));

			clearSearch.click();
			wait.until(ExpectedConditions.visibilityOf(noRecords));
			
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
		
	}
	
	public void validateDetailsTable(String text) throws InterruptedException
	{
		
		
		if(AssignmentReport. checkifParmeterAvailable(text.split(",")[1]))
		{
			String parameter=text.split(",")[1];
			text=text.replaceAll(parameter,AssignmentReport.getParmeterAvailable(parameter));
		}

		 if(courseListName.containsKey(text.split(",")[0]+"Option"))
		 {
			 String parameter=text.split(",")[0];
			 text=text.replaceAll(parameter,courseListName.get(parameter+"Option").toString());
		 }	
		 text = text.replace("Â", "");
			
		Thread.sleep(5000);
		String[] rowvalue=text.split(",");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)");
		for(int i=1;i<rowvalue.length;i++)
		{
				
//			js.executeScript("arguments[0].scrollIntoView();",select);
			Assert.assertEquals(rowvalue[i], driver.findElement(By.xpath("//table[@id=\"courseList\"]//tbody/tr/td[text()='"+text.split(",")[0]+"']/following::td[text()='"+text.split(",")[i]+"'][1]")).getText());
		}
	}
	
	public void validateHeaderTable(String text) throws InterruptedException
	{
		Thread.sleep(5000);
		String[] rowvalue=text.split(",");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)");
		for(int i=1;i<rowvalue.length;i++)
		{
			
//			js.executeScript("arguments[0].scrollIntoView();",select);
			Assert.assertEquals(rowvalue[i-1], driver.findElement(By.xpath("//*[@id=\"courseList\"]/thead/tr/th["+i+"]")).getText());
		}
	}
	public void validateHealthCheckSortingEachColumn()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		for(int i = 1; i <= 3; i++)
		{
			ArrayList<String> obtainedList = new ArrayList<>(); 
			//div[@id="courseList_wrapper"]//th
			WebElement column = driver.findElement(By.xpath(searchTable + "[" + i + "]"));
			try
			{
				wait.until(ExpectedConditions.elementToBeClickable(column));
			}
			catch(Exception e)
			{
				WebElement scrollArea = driver.findElement(By.className("courseList"));
				js.executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", scrollArea);
				wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(searchTable + "[" + i + "]"))));
			}
			js.executeScript("arguments[0].click()", column);
			val = pageLoad.getAttribute("class");
			int m=0;
			while(val.toLowerCase().contains("loading"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
		
			List<WebElement> elementList= driver.findElements(By.xpath(row + "/td[" + i + "]"));
			for(WebElement we:elementList)
			{
			   obtainedList.add(we.getText());
			}
			ArrayList<String> sortedList = new ArrayList<>();   
			for(String s:obtainedList){
			sortedList.add(s);
			}
			Collections.sort(sortedList);
			
			System.out.println("Sorted list"+sortedList.toString());
			System.out.println("Obtainted list"+obtainedList);
			
			
			Assert.assertTrue(sortedList.equals(obtainedList));
			
			js.executeScript("arguments[0].click()", column);
			obtainedList.removeAll(obtainedList);
			val = pageLoad.getAttribute("class");
			m=0;
			while(val.toLowerCase().contains("loading"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			elementList= driver.findElements(By.xpath(row + "/td[" + i + "]"));
			for(WebElement we:elementList)
			{
			   obtainedList.add(we.getText());
			}
			Collections.reverse(sortedList);
			Assert.assertTrue(sortedList.equals(obtainedList));
			
		}
		
	}
	
	public void verifyHealthCheckNoReportsDataFound() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(Text_NoReportsDataFound));
		String value = Text_NoReportsDataFound.getText();
		Assert.assertEquals(value, "No records present.");
				
	}
	
}
