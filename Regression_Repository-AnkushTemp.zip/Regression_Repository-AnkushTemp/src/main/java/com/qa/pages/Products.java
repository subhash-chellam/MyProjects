package com.qa.pages;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime; 

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.beust.jcommander.Strings;
import com.qa.util.TestBase;
import com.qa.util.TestUtils;

public class Products extends TestBase
{
	@FindBy(xpath = "//a[text() = 'Products']")
	WebElement productTab;

	@FindBy(xpath = "//a[text() = 'Add Product']")
	WebElement addProductButton;

	@FindBy(xpath = "//select[@id = 'selected_course']")
	WebElement selectProduct;


	@FindBy(xpath = "//*[@id='customer-admin-list']")
	WebElement productTable;

	
	


	@FindBy(xpath = "(//*[@class=\"analytics_slider round\"])[1]")
	WebElement Organization;

	@FindBy(xpath = "(//*[@class='analytics_slider round'])[2]")
	WebElement studentPay;


	@FindBy(xpath = "//button[@title='Select Product']")
	WebElement Product;






	@FindBy(xpath = "//*[@id=\"scrollProduct\"]/li[2]/a/span[1]")
	WebElement Productselct;


	@FindBy(xpath = "//select[@name='retake_duration']")
	WebElement retakeDuration;

	@FindBy(xpath = "//*[@id='start_date']")
	WebElement start_date;

	

	@FindBy(xpath = "//*[@id=\"autocompleteProduct\"]")
	WebElement searchProduct;


	@FindBy(xpath = "//select[@id = 'selected_course']//parent::div//small")
	WebElement selectProductValid;

	@FindBy(xpath = "//div[@class='datepicker-days']")
	WebElement calendarProduct;

	@FindBy(xpath = "//input[@name = 'start_date']")
	WebElement startDate;

	@FindBy(xpath = "//input[@name = 'end_date']")
	WebElement endDate;

	@FindBy(xpath = "//input[@name = 'license_limit_type' and @id = 'unlimited']")
	WebElement unlimited;

	@FindBy(xpath = "//*[@id='todolistDiv']//input[@value='N']")
	WebElement partofCourse;


	@FindBy(xpath = "//*//input[@value='N' and @name='todolist_in_cdp']")
	WebElement partofCourse2;
	
	

	@FindBy(xpath = "//*[@id=\"retakeSelectConfigureDiv\"]//input[@value='1' and @name=\"course_retake\"]")
	WebElement retakeyes;

	
	
	@FindBy(xpath = "//*[@id=\"retakeConfigureDiv\"]//input[@value='1' and @name=\"course_retake\"]")
	WebElement retakeyes2;

	

	@FindBy(xpath = "//*[@id=\"recurrenceConfigureDiv\"]//input[@name=\"allow_recurrence\" and @value=\"0\"]")
	WebElement recurrenceNo;


	@FindBy(xpath = "//*[@id=\"recurrenceConfigureDiv\"]//input[@name=\"allow_recurrence\" and  @value=\"1\"]")
	WebElement recurrenceYes;


	@FindBy(xpath = "//*[@id=\"allow_recurrence_after\"]")
	WebElement recurrenceCheckYes;

	@FindBy(xpath = "//select[@id='allow_recurrence_after_interval']")
	WebElement recurrenceSelect;


	@FindBy(xpath = "//select[@id='allow_recurrence_after_condition']")
	WebElement recurreneSelect;

	
	
	@FindBy(xpath = "//*[@id='allow_recurrence_after_number']")
	WebElement recurrenceNumber;

	@FindBy(xpath = "//*[@id='scorm_version_SCORM_2004']")
	WebElement version;
	

	@FindBy(xpath = "//*[@id='scorm_version_SCORM_12']")
	WebElement version12;
	
	@FindBy(xpath = "//select[@id = 'allow_recurrence_after_interval']")
	WebElement recurrenceTime;
	
	@FindBy(xpath = "//select[@id = 'allow_recurrence_after_condition']")
	WebElement recurrenceCriteria;

	@FindBy(xpath = "//*[@id=\"package_type_1\"]")
	WebElement packagetype_1;

	@FindBy(xpath = "//*[@id='package_type_2']")
	WebElement packagetype_2;

	@FindBy(xpath = "//input[@name = 'license_limit']")
	WebElement quantity;

	@FindBy(xpath = "//input[@name = 'course_retake' and @value = 0]")
	WebElement retakeNo;

	@FindBy(xpath = "//button[@id = 'submitBtn']")
	WebElement addProduct;

	@FindBy(xpath = "//*[@id='ms-list-1']/button")
	WebElement SubscriptionPlan;

	@FindBy(xpath = "//*[@id='ms-list-1']/div/div/input")
	WebElement SubscriptionPlanSearch;
	
	
	
	@FindBy(xpath = "(//input[@id = 'redeem_limit'])[2]")
	WebElement redeemQuantity;
	
	@FindBy(xpath = "//a[@title = 'Edit Product']")
	WebElement editProductButton;

	@FindBy(xpath = "(//td[contains(@class, 'new day' )])[1]")
	WebElement editProductDate;

	@FindBy(xpath = "//a[@title = 'Download Dispatch package']")
	WebElement downloadProduct;

	@FindBy(xpath = "//a[text() = 'Show in folder']")
	WebElement downloadSuccess;

	@FindBy(xpath = "//a[text() = 'Organizations']")
	WebElement organizationLink;

	@FindBy(xpath = "//table[@id = 'customer-admin-list']//tr[1]//td[3]")
	WebElement courseUsage;

	

	@FindBy(xpath = "//a[text()='Purchase History']")
	WebElement PurchaseHistory;

	@FindBy(xpath = "//div[@class=\"input-daterange\"]//input[@id=\"eBook_end_date\"]")
	WebElement LMSenddate;
	@FindBy(xpath = "//th[contains(text(),'Contract Quantity')]")
	WebElement tableheadercntrctqnty;

	@FindBy(xpath = "//table[@id='customer-admin-list']//tbody//tr[1]//td[5]//a")
	WebElement editproductlinkCTC;

	@FindBy(xpath = "//table[@id='customer-admin-list']//tbody//tr[1]//td[5]//a[3]")
	WebElement editproductlinkLMS;

	@FindBy(xpath = "//a[contains(text(),'Purchase History')]")
	WebElement purchasehistorylink;

	@FindBy(xpath = "//th[contains(text(),'Contract Quantity Change')]")
	WebElement headercntrctqntychange;

	@FindBy(xpath = "	//th[contains(text(),'Total Contract Quantity')]")
	WebElement headertotalcntrctqnty;

	@FindBy(xpath = "(//div[@id=\"licenseLimitDiv\"]//label)[3]")
	WebElement cntrctqntylabeladd;

	@FindBy(xpath = "//div[@id=\"licenseLimitDiv\"]//label")
	WebElement cntrctqntylabeledit;

	@FindBy(xpath = "//input[@id='start_date']")
	WebElement LMSstartdateinput;

	@FindBy(xpath = "//td[@class=\"active selected range-start range-end day\"]")
	WebElement LMSsettocurrentdate;

	
	@FindBy(xpath = "//label[contains(text(), 'Recurrence type')]//following-sibling::div/input[@name = 'allow_recurrence']")
	 WebElement enableRecurrence;
	
	@FindBy(xpath = "//button[@data-id = 'selected_course']")
	WebElement productDropdown;
	
	@FindBy(xpath = "//input[@id = 'autocompleteProduct']")
	WebElement productSearch;
	String productSearchResult = "//ul[@id = 'scrollProduct']/li//span[1]";

	@FindBy(xpath = "//input[@value = 'Old']")
	WebElement selectCourseInventory;	
	
	@FindBy(xpath = "//label[contains(text(), 'Allow recurrence after')]//preceding-sibling::input[@name = 'allow_recurrence_after']")
	WebElement recurrenceAfterCheckbox;
	
	@FindBy(xpath = "//*[@id='customScoreConfigureDiv']//input[@checked='checked']//following::label[1]")
	WebElement completionScore;
	
	@FindBy(xpath = "//*[@id='todolistDiv']//input[@checked='checked']//following::label[1]")
	WebElement modulesList;
	
	@FindBy(xpath = "//*[@id='skillsessionDiv']//input[@checked='checked']//following::label[1]")
	WebElement skillSession;
	
	@FindBy(xpath = "//*[@id='completion_criteria_4' and @checked='checked']//following::label[1]")
	WebElement completionStatus;
	
	@FindBy(xpath = "//input[@name='course_retake' and @checked='checked']//following::label[1]")
	WebElement retakestatus;
	
	@FindBy(xpath = "//*[@id='licenseLimit_content']/span")
	WebElement licenseLimit_content;
	
	
	@FindBy(xpath = "//*[@id='limited' and @checked='checked']/following::label[1]")
	WebElement limited_content;
	
	@FindBy(xpath = "//input[@name='completion_scoring_type' and @value='3']")
	WebElement CourseScorePercentage;
	
	
	
	@FindBy(xpath = "//*[@id=\"updatelicense\"]//label[text()='Passed/Incomplete']")
	WebElement PassedStatus;
	
	
	
	@FindBy(xpath = "//*[@id='skillsessionDiv']//label[contains(text(),'Show Find Training Center Widget')]")
	WebElement findTrainingCenterWidget;
	
	@FindBy(xpath = "//a[text()='Download Here']")
	WebElement DownloadHere;
	
	@FindBy(xpath = "//*[@id='customer-admin-list_next']")
	WebElement next;
	
	
	@FindBy(xpath = "//div[@class='unlimited-warning']")
	WebElement ProductSubScriptionUnlimitedToLimited;

	// div[@id='customer-admin-list_wrapper']//table[@id='customer-admin-list']/thead//tr/th
	@FindBy(xpath = "//div[@id='customer-admin-list_wrapper']//table[@id='customer-admin-list']/thead//tr/th")
	List<WebElement> Table_headers;

	@FindBy(xpath = "//tr[@role='row']")
	List<WebElement> RowCount;
	
	@FindBy (xpath = "//button[@class='btn btn-primary red_btn ']")
	WebElement Button_YesBlock;
	
	@FindBy (xpath = "//div[@id='successbox']//p")
	WebElement Alert_ProductSubscription;
	
	@FindBy(xpath = "//label[contains(text(),'Multi SCORM')]/preceding-sibling::input")
	WebElement multiScromRecurrenceType;
	
	
	@FindBy (xpath = "//*[@id='licenseLimit_content']//label[text()='Limited']")
	WebElement verifyiflimite;
	
	
	// table[@id=\"customer-admin-list\"]//tbody//tr[3]//td[6]

	@FindBy(xpath = "//label[text() = 'Student Pay']/preceding-sibling::label")
	WebElement payment_type_Org;

	@FindBy(xpath = "//div[@id = 'subscription']/select")
	WebElement subscriptionDropdown;

	@FindBy(xpath = "//a[@class = 'paginate_button next']")
	WebElement productListNextPage;

	@FindBy(xpath = "//a[@class = 'paginate_button previous']")
	WebElement productListPreviousPage;

	@FindBy(xpath = "//div[@id = 'customer-admin-list_info']")
	WebElement productListResult;
	
	
	String productListCode = "//table[@id = 'customer-admin-list']//td[1]";
	String productLcodeTable = "//table[@id = 'customer-admin-list']//td[1]";
	String productPaymentModeTable = "//table[@id = 'customer-admin-list']//td[3]";
	String pageCount = "//div[@id = 'customer-admin-list_paginate']/span/a";
	public static String productCode;

	
	Students std;
  

	String quantityListTable = "//table[@id = 'customer-admin-list']//td[4]";
	String editMultiProduct = "//a[@title = 'Edit Product']";
	
	String enddispatchDownload="']//following-sibling::td//a[@target='_blank']";
	
	
	String forntdispatchDownload="//*[@id=\"customer-admin-list\"]//td[text()='";
	//	/html/body/div[2]/div[1]/div/ul/li[5]/a
	String productListTable = "//table[@id = 'customer-admin-list']//td[2]";
	String downloadProductByName = "//a[@title = 'Download Dispatch package']";
	String packageList = "//h3[text() = 'Organization pay packages']/following-sibling::div//label";
	
	String datePick = "//td[contains(@class, 'day' ) and text() = ";
	public static String downloadPath = System.getProperty("user.dir") + prop.getProperty("downloadPath");
	String productOption = "//option[text() = '";
	public static String filePath;
	public String productType, productName;
	TestUtils testutils = new TestUtils();
	public int license;

	JavascriptExecutor js = (JavascriptExecutor)driver;

	public Products()
	{
		PageFactory.initElements(driver, this);
	}
	
	public void validateRecurrenceFrequencyAvailability(String availability)
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		String pageValue = js.executeScript("return document.readyState").toString();
		while(!(pageValue.equalsIgnoreCase("complete")))
		{
			pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
		}
		switch(availability.toLowerCase().trim())
		{
			case "yes":
				Assert.assertTrue(enableRecurrence.isDisplayed());
				break;
			case "no":
				Assert.assertFalse("Enable frequency is available on the page",enableRecurrence.isDisplayed());
				break;
		}		
	}
	public void editproduct(String course) throws InterruptedException
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();

		try {
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(forntdispatchDownload+course+enddispatchDownload))));
		}
		catch(Exception e) {
		}
		driver.findElement(By.xpath("//*[@id=\"customer-admin-list\"]//td[text()='"+course+"']//following-sibling::td//a[@title='Edit Product']")).click();
		Thread.sleep(5000);

	}
	
	public void validateDownloadFileName(String cycleNumber) {
		System.out.println("File path is " + filePath);
		System.out.println("scorm_dispatcher_"+ OrganizationHome.exceptionid + "__"+ productCode + "_"+cycleNumber);
		Assert.assertTrue(filePath.contains("scorm_dispatcher_"+ OrganizationHome.exceptionid + "__"+ productCode + "_"+cycleNumber));
}
	
	public void changetoStudentPaymodeOnly()
	{

		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(5000);
			
	
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(Organization));
		
			
			try
			{
				quantity.clear();;	
				Organization.click();
			}
			catch (Exception e) {
			
			}
			
				
			addProduct.click();


			
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}
	
	public void changetoOrgPaymodeOnly()
	{

		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(5000);
			
	
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(Organization));
		
			
			try
			{
				quantity.clear();;	
				
			}
			catch (Exception e) {
				Organization.click();
			}
			
			addProduct.click();


			
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}
	
	public void changetoOrganizationPaymodeOnly( String name)
	{
		if(courseListName.containsKey(name))
			name=courseListName.get(name).toString();

		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(5000);
			name = name.replace("Â", "");
			
			productName = name;
	
		
				
			addProduct.click();


			
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}
	public void validateCycleNumber(String name) throws Exception
    {
			UserManagement		usrMg = new UserManagement();
			if(courseListName.containsKey(name+"Option"))
				name=courseListName.get(name+"Option").toString();

		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(editProductButton));
		List<WebElement> list = driver.findElements(By.xpath(productListTable));
		for(int i=1; i<= list.size(); i++)
		{
			name = name.replaceAll("registered", "\u00AE");
			String text = driver.findElement(By.xpath("(" + productListTable + ")[" + i + "]")).getText();
			if(name.trim().toLowerCase().contains(text.trim().toLowerCase()))
			{
				JavascriptExecutor js = (JavascriptExecutor)driver;
				WebElement productDownload = 		driver.findElement(By.xpath(forntdispatchDownload+name+enddispatchDownload));
				wait.until(ExpectedConditions.elementToBeClickable(productDownload));
				try {
					js.executeScript("arguments[0].click();", productDownload);
					switchTab();	
				}
				catch(Exception e)
				{
					wait = new WebDriverWait(driver, 10);
					wait.until(ExpectedConditions.visibilityOf(productDownload));
					productDownload.click();
					switchTab();
				}
				 break;
			}
		}
		List<WebElement> packageListCount = driver.findElements(By.xpath(packageList));
		int number = packageListCount.size();
		Assert.assertTrue(number == DashBoard.cycleNumber);
		usrMg.switchTab();
		usrMg.closeOtherTab();
    }
	public void switchTab()
	{
		
		Set<String> handles=driver.getWindowHandles();
		int counter = 0;
		try {
		while(handles.size() == 1)
		{
			handles=driver.getWindowHandles();
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load page after waiting for 1 minute");
		}
	}
	catch(Exception e) {}
		
		System.out.println("Number of tabs open " + handles.size());
        for(String actual: handles)
        {
            String url = driver.switchTo().window(actual).getCurrentUrl();
         if(url.toLowerCase().contains("downloaddispatchlist"))
         {
        	 driver.switchTo().window(actual);
        	 break;
         }
             
        }
	}
	
	public void nextbutton() throws InterruptedException
	{
		try
		{
		wait.until(ExpectedConditions.visibilityOf(next));

		next.click();
		}
		catch(Exception e)
		{
			
		}
		

	}
	
	public void editproducts(String course) throws InterruptedException
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
System.out.println(course);
		course = course.replace("Â", "");
		course = course.replace("Â", "");	

		driver.findElement(By.xpath("//*[@id=\"customer-admin-list\"]//td[text()='"+course+"']//following-sibling::td//a[@title='Edit Product']")).click();
		Thread.sleep(5000);

	}
	
	public void enterRecurrenceDetails(String number, String time, String criteria)
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		String pageValue = js.executeScript("return document.readyState").toString();
		while(!(pageValue.equalsIgnoreCase("complete")))
		{
			pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
		}
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(recurrenceNumber));
		recurrenceNumber.click();
		recurrenceNumber.clear();
		recurrenceNumber.sendKeys(number);
		Select select = new Select(recurrenceTime);
		select.selectByVisibleText(time);
		select = new Select(recurrenceCriteria);
		select.selectByVisibleText(criteria);
	}
	
	public void enterRecurrenceDetailsshouldbedisable(String number, String time, String criteria)
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		String pageValue = js.executeScript("return document.readyState").toString();
		while(!(pageValue.equalsIgnoreCase("complete")))
		{
			pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
		}
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(recurrenceNumber));
		
		Assert.assertEquals(recurrenceNumber.getAttribute("disabled"), "true");
		Assert.assertEquals(recurrenceTime.getAttribute("disabled"), "true");
		Assert.assertEquals(recurrenceCriteria.getAttribute("disabled"), "true");

		
	}
	

	public void clickonProductHistoryTab() throws InterruptedException
	{

		wait.until(ExpectedConditions.visibilityOf(PurchaseHistory));
		PurchaseHistory.click();
		Thread.sleep(5000);

	}

	public void editversion() throws InterruptedException
	{

		wait.until(ExpectedConditions.visibilityOf(version));
		version.click();
		
		addProduct.click();
		Thread.sleep(5000);


	}
	public void editversion12() throws InterruptedException
	{

		wait.until(ExpectedConditions.visibilityOf(version12));
		version12.click();
		
		addProduct.click();
		Thread.sleep(5000);


	}

	public void editpackage(String type) throws InterruptedException
	{

		wait.until(ExpectedConditions.visibilityOf(packagetype_1));

		switch(type)
		{
		case "Single" :packagetype_1.click();
		break;
		case "Session" :packagetype_2.click();
		break;

		}

		Thread.sleep(5000);

		addProduct.click();
		Thread.sleep(5000);


	}
	public void clickOnDownloadLinkByName(String delete, String course) throws Exception
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();

		course = course.replace("Â", "");
		//*[@id="customer-admin-list"]//td[text()='RQI 2025 Healthcare Provider Entry Assignment - CAEN']//following-sibling::td//a[@target='_blank']
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(forntdispatchDownload+course+enddispatchDownload))));

		driver.findElement(By.xpath(forntdispatchDownload+course+enddispatchDownload)).click();
		Thread.sleep(5000);
		String currentHandle= driver.getWindowHandle();
		
		Set<String> allWindowHandles = driver.getWindowHandles();
		
		driver.switchTo().window(allWindowHandles.toArray()[1].toString());
		DownloadHere.click();
		driver.close();
		driver.switchTo().window(currentHandle);
		Thread.sleep(5000);
		
		if(delete.equalsIgnoreCase("yes"))
			Assert.assertTrue(isFileDownloaded_Ext(downloadPath, ".zip"));
		else
			Assert.assertTrue(isFileDownloaded_Ext_withoutDelete(downloadPath, ".zip"));
	}
	public void verifyDownloadFile(String extension)
	{
	std = new Students();
	boolean dwnld = false;
	int counter = 1;
	try {
		do
		{
			Thread.sleep(5000);
			dwnld = std.isFileDownloaded_Ext(downloadPath, extension);
			System.out.println(Students.filePath);
			counter = counter + 1;
		}
		while(dwnld == false && counter < 12);
	} 
	catch (Exception e) 
	{
		e.printStackTrace();
	}
	}
	public void clickToAddProduct()
	{
		try {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(addProduct));
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
			}
			Thread.sleep(3000);
			addProduct.click();
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}		
	}
	public void changeFileName(String newName, String ext)
	{
		isFileDownloaded_Ext_withoutDelete(downloadPath, ext);
		File oldFile = new  File(filePath);
		System.out.println("Old file path is "+filePath);
		File newFile = new File(downloadPath + "\\" + newName + ext);
		oldFile.renameTo(newFile);
		filePath = downloadPath + "\\" + newName + ext;
		System.out.println("New file path is " + filePath);
	}
	public void clickOnProductsTab()
	{
		wait.until(ExpectedConditions.visibilityOf(productTab));
		productTab.click();
	}
	public void enterProductDetailsByNameAndRecurrence(String type, String name)
	{
		if(courseListName.containsKey(name))
			name=courseListName.get(name).toString();

		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			name = name.replaceAll("registered", "\u00AE");
			name = name.replace("Â", "");
			Thread.sleep(3000);
			productType = type;	
			productName = name;
		wait.until(ExpectedConditions.visibilityOf(productDropdown));
		
		Thread.sleep(5000);
		//js.executeScript("arguments[0].click();", productDropdown);
		productDropdown.click();	
		wait.until(ExpectedConditions.visibilityOf(productSearch));
		productSearch.click();
		productSearch.sendKeys(name);
		//Thread.sleep(5000);
		List<WebElement> options = driver.findElements(By.xpath(productSearchResult));
		while(!(options.size() == 2))
		{
			options = driver.findElements(By.xpath(productSearchResult));
		}
		for(int i = 1; i <= options.size(); i++)
		{
			String element = "(" + productSearchResult + ")[" + i + "]";
			String value = driver.findElement(By.xpath(element)).getText();
			if(value.toLowerCase().trim().equalsIgnoreCase(name.toLowerCase().trim()))
			{
				driver.findElement(By.xpath(element)).click();
				break;
			}
		}

		DateFormat dateFormat = new SimpleDateFormat("dd");
		Date date = new Date();
		String formattedStartDate = dateFormat.format(date);
		startDate.click();
		wait.until(ExpectedConditions.visibilityOf(calendarProduct));
		String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
		WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
		reqDate.click();
		if(type.equalsIgnoreCase("manual"))
		{
			quantity.sendKeys("1");
		}
		else if(type.equalsIgnoreCase("automatic"))
		{
			
			unlimited.click();
		}
		else
		{
			quantity.sendKeys("1");
		}
		wait.until(ExpectedConditions.visibilityOf(enableRecurrence));
		Thread.sleep(3000);
		enableRecurrence.click();
		Thread.sleep(3000);	
		addProduct.click();
	}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println(ex.getMessage());
			enterProductDetailsByName(productType, productName);
		} catch (Exception e) 
		{
			Assert.fail("Issue with app");
		}
	}
	public void clickOnAddProductsButton()
	{
		try
		{
			Thread.sleep(5000);
		}
		catch(Exception e)
		{

		}
		wait.until(ExpectedConditions.visibilityOf(addProductButton));
		addProductButton.click();
		JavascriptExecutor js = (JavascriptExecutor)driver;
		String pageValue = js.executeScript("return document.readyState").toString();
		while(!(pageValue.equalsIgnoreCase("complete")))
		{
			pageValue = js.executeScript("return document.readyState").toString();
		}
		try
		{
			Organization.click();
		}
		catch(Exception e)
		{
 
		}
	}

	
	public void clickOnAddProductsNLNButton()
	{
		try
		{
			Thread.sleep(5000);
		}
		catch(Exception e)
		{

		}
		wait.until(ExpectedConditions.visibilityOf(addProductButton));
		addProductButton.click();
		JavascriptExecutor js = (JavascriptExecutor)driver;
		String pageValue = js.executeScript("return document.readyState").toString();
		while(!(pageValue.equalsIgnoreCase("complete")))
		{
			pageValue = js.executeScript("return document.readyState").toString();
		}
		try
		{
			studentPay.click();
		}
		catch(Exception e)
		{
 
		}
	}

	public void clickOnEditProductsButton(String course)
	{
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{

		}
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
		course = course.replace("Â", "");
		
		String locator="//*[@id=\"customer-admin-list\"]//td[text()='"+course+"']//following-sibling::td//a[@title = 'Edit Product']";
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(locator))));
		driver.findElement(By.xpath(locator)).click();
		JavascriptExecutor js = (JavascriptExecutor)driver;
		String pageValue = js.executeScript("return document.readyState").toString();
		while(!(pageValue.equalsIgnoreCase("complete")))
		{
			pageValue = js.executeScript("return document.readyState").toString();
		}
		
	}
	public void viewtheproduct(String header,String data)
	{
		if(header.contains("Completion Score"))
		Assert.assertEquals( data,completionScore.getText().trim());
		else if(header.contains("Modules List (To Do List)"))
			Assert.assertEquals( data,modulesList.getText().trim());
		else if(header.contains("Skill Session Widgets"))
			Assert.assertEquals( data,skillSession.getText().trim());
		else if(header.contains("Completion Status Criteria"))
			Assert.assertEquals( data,completionStatus.getText().trim());
		else if(header.contains("Allow Retake"))
			Assert.assertEquals( data,retakestatus.getText().trim());
		else if(header.contains("Contract Quantity"))
			Assert.assertEquals( data,quantity.getAttribute("value"));
		
		else if(header.contains("Retake Duration (Months)"))
		{
			Select retakeDur = new Select(retakeDuration);
			Assert.assertEquals( data,retakeDur.getFirstSelectedOption().getText());
		}
		else if(header.contains("Subscription Type"))
		{
			if(data.contains("Unlimited"))
			Assert.assertEquals( data,licenseLimit_content.getText());
			else
				Assert.assertEquals( data,limited_content.getText());
			
				
		}
		else if(header.contains("Start Date on LMS"))
		{
			  LocalDateTime myDateObj = LocalDateTime.now().plusDays(Integer.parseInt("2"));
			    System.out.println("Before formatting: " + myDateObj);
			    DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("MM/dd/yyyy");

			    String formattedStartDate = myDateObj.format(myFormatObj);
				Assert.assertEquals( formattedStartDate,start_date.getAttribute("value"));

		}
		else
			Assert.fail("Header issues");
			
		
			
			
		
	}

	public int countTotalQuantityProductByName(String name)
    {

    	if(courseListName.containsKey(name+"Option"))
    		name=courseListName.get(name+"Option").toString();
		
        int count = 0;
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.visibilityOf(editProductButton));
        List<WebElement> list = driver.findElements(By.xpath(productListTable));
        name = name.replaceAll("registered", "\u00AE");
        for(int i=1; i<= list.size(); i++)
        {
            String text = driver.findElement(By.xpath("(" + productListTable + ")[" + i + "]")).getText();
            if(name.trim().toLowerCase().contains(text.trim().toLowerCase()))
            {
                count = Integer.parseInt(driver.findElement(By.xpath("(" + quantityListTable + ")[" + i + "]")).getText().trim());
                break;
            }
        }
        return count;
    }
    
    public void editProductQuantityByName(String name, int count)
    {
    	if(courseListName.containsKey(name+"Option"))
    		name=courseListName.get(name+"Option").toString();
			
    	name=name.replace("Â","");
	
        wait.until(ExpectedConditions.visibilityOf(editProductButton));
        List<WebElement> list = driver.findElements(By.xpath(productListTable));
        for(int i=1; i<= list.size(); i++)
        {
            String text = driver.findElement(By.xpath("(" + productListTable + ")[" + i + "]")).getText();
            name = name.replaceAll("registered", "\u00AE");
            if(name.trim().toLowerCase().contains(text.trim().toLowerCase()))
            {
            	
            	try
            	{
            	Thread.sleep(5000);	
            	}
            	catch(Exception e)
            	{
            		
            	}
            	
                JavascriptExecutor js = (JavascriptExecutor)driver;
                WebElement productEdit = driver.findElement(By.xpath("(" + editMultiProduct.toString() + ")[" + i + "]"));
                js.executeScript("arguments[0].click();", productEdit);
                break;
            }
        }        
        wait.until(ExpectedConditions.visibilityOf(quantity));
        
        quantity.clear();
        quantity.sendKeys(String.valueOf(count));
        addProduct.click();
    }
	
	public void AddProductInventoryByNameAndCount(String name, int licenseCount)
	{
		if(courseListName.containsKey(name))
			name=courseListName.get(name).toString();

	
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			name = name.replaceAll("registered", "\u00AE");
			name = name.replace("Â", "");
			Thread.sleep(3000);
			license = licenseCount;
			productName = name;
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(selectCourseInventory));
		wait.until(ExpectedConditions.elementToBeClickable(selectCourseInventory));
		selectCourseInventory.click();
		boolean selected = selectCourseInventory.isSelected();
		int counter = 1;
		while(selected == false || counter >= 20)
		{
			selected = selectCourseInventory.isSelected();
			Thread.sleep(5000);
			counter++;
		}
		Thread.sleep(5000);
		wait.until(ExpectedConditions.visibilityOf(productDropdown));
		
		Thread.sleep(5000);
		wait.until(ExpectedConditions.elementToBeClickable(productDropdown));
		//js.executeScript("arguments[0].click();", productDropdown);
		productDropdown.click();	
		wait.until(ExpectedConditions.visibilityOf(productSearch));
		productSearch.click();
		for(int i=0;i<name.length();i++)
		productSearch.sendKeys(String.valueOf(name.charAt(i)));
		Thread.sleep(5000);
	
		Productselct.click();
//		List<WebElement> options = driver.findElements(By.xpath(productSearchResult));
//		while(!(options.size() == 2))
//		{
//			options = driver.findElements(By.xpath(productSearchResult));
//		}
//		for(int i = 1; i <= options.size(); i++)
//		{
//			String element = "(" + productSearchResult + ")[" + i + "]";
//			String value = driver.findElement(By.xpath(element)).getText();
//			if(value.toLowerCase().trim().equalsIgnoreCase(name.toLowerCase().trim()))
//			{
//				driver.findElement(By.xpath(element)).click();
//				break;
//			}
//		}
		redeemQuantity.sendKeys(String.valueOf(licenseCount));
		Thread.sleep(3000);	
		addProduct.click();
	}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println(ex.getMessage());
			AddProductInventoryByNameAndCount(productName, license);
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}
	
	public void validateproduct(String name)
	{
		try
		{
			Thread.sleep(5000);
			if(courseListName.containsKey(name+"Option"))
				name=courseListName.get(name+"Option").toString();
			name = name.replace("Â", "");
			

			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='customer-admin-list']//td[text()='"+name+"']"))));
			

		}
		catch(Exception e)
		{
			Assert.fail("Product not added ");
		}
	}
	public boolean validateifproductisadded(String name)
	{
		boolean flag=false;
		
		try
		{
			Thread.sleep(5000);
			if(courseListName.containsKey(name+"Option"))
				name=courseListName.get(name+"Option").toString();
			name = name.replace("Â", "");
			

			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='customer-admin-list']//td[text()='"+name+"']"))));
			flag=true;
			
			return flag;

		}
		catch(Exception e)
		{
			 flag=false;
			 return flag;
		}
		
		
	}

	public void enterProductDetails(String type)
	{
		try 
		{

			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
			}
			Thread.sleep(3000);
			//			wait.until(ExpectedConditions.visibilityOf(selectProduct));
			//			Select product = new Select(selectProduct);
			//			selectProduct.click();

			Product.click();
			for(int i=0;i<courseListName.get("T_MOCEntryCourse").toString().length();i++)
				searchProduct.sendKeys(String.valueOf(courseListName.get("T_MOCEntryCourse").toString().charAt(i)));
			Thread.sleep(7000);
			//			
			Productselct.click();
			DateFormat dateFormat = new SimpleDateFormat("dd");
			Date date = new Date();
			String formattedStartDate = dateFormat.format(date);
			startDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
			WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
			reqDate.click();
			if(type.equalsIgnoreCase("manual"))
			{
				quantity.sendKeys("1");
			}
			else if(type.equalsIgnoreCase("automatic"))
			{

				unlimited.click();
			}
			else
				quantity.sendKeys("1");
			addProduct.click();

			try
			{
				if(!type.equalsIgnoreCase("automatic"))	
					if(driver.findElement(By.xpath("//*[@id=\"errorbox\"]/ul/li")).getText().contains("Please update the inventory."))
					{
						driver.findElement(By.xpath("//*[@id='purchaseType']/div[2]/input")).click();
						Thread.sleep(3000);

						//			 product = new Select(selectProduct);
						//				selectProduct.click();
						Product.click();

						for(int i=0;i<courseListName.get("T_MOCEntryCourse").toString().length();i++)
							searchProduct.sendKeys(String.valueOf(courseListName.get("T_MOCEntryCourse").toString().charAt(i)));

						Thread.sleep(7000);
						//				
						Productselct.click();

						Thread.sleep(3000);
						driver.findElement(By.xpath("//input[@name=\"updated_license_limit\"]")).sendKeys("1");
						addProduct.click();

					}
			}	
			catch(NoSuchElementException e)
			{

			}

		} 
		catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}

	public void editProduct()
	{
		wait.until(ExpectedConditions.visibilityOf(editProductButton));
		editProductButton.click();
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_MONTH, 14); 
		wait.until(ExpectedConditions.visibilityOf(startDate));
		startDate.click();
		wait.until(ExpectedConditions.visibilityOf(calendarProduct));
		editProductDate.click(); 				// This is a change in UI
		addProduct.click();
	}

	public void clickOnDownloadLink(String delete) throws Exception
	{
		wait.until(ExpectedConditions.visibilityOf(downloadProduct));
		downloadProduct.click();
		Thread.sleep(5000);
		if(delete.equalsIgnoreCase("yes"))
			Assert.assertTrue(isFileDownloaded_Ext(downloadPath, ".zip"));
		else
			Assert.assertTrue(isFileDownloaded_Ext_withoutDelete(downloadPath, ".zip"));
	}

	public void clickOnDownloadLink(String delete,String course) throws Exception
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();

		course = course.replace("Â", "");
		//*[@id="customer-admin-list"]//td[text()='RQI 2025 Healthcare Provider Entry Assignment - CAEN']//following-sibling::td//a[@target='_blank']
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(forntdispatchDownload+course+enddispatchDownload))));

		driver.findElement(By.xpath(forntdispatchDownload+course+enddispatchDownload)).click();
		Thread.sleep(5000);
		String currentHandle= driver.getWindowHandle();
		
		Set<String> allWindowHandles = driver.getWindowHandles();
		
		driver.switchTo().window(allWindowHandles.toArray()[1].toString());
		DownloadHere.click();
		driver.close();
		driver.switchTo().window(currentHandle);
		Thread.sleep(5000);
		
		if(delete.equalsIgnoreCase("yes"))
			Assert.assertTrue(isFileDownloaded_Ext(downloadPath, ".zip"));
		else
			Assert.assertTrue(isFileDownloaded_Ext_withoutDelete(downloadPath, ".zip"));
	}

	public void clickOnDownloadLink(String delete,String course,String type) throws Exception
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(forntdispatchDownload+course+enddispatchDownload))));

		driver.findElement(By.xpath(forntdispatchDownload+course+enddispatchDownload)).click();
		
      
		Thread.sleep(5000);
        String currentHandle= driver.getWindowHandle();
		
		Set<String> allWindowHandles = driver.getWindowHandles();
		
		driver.switchTo().window(allWindowHandles.toArray()[1].toString());
	

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("	//label[text()='"+type+"']//following::span[1]"))));
		driver.findElement(By.xpath("//label[text()='"+type+"']//following::span[1]")).click();

		driver.close();
		driver.switchTo().window(currentHandle);
	
		Thread.sleep(10000);

		if(delete.equalsIgnoreCase("yes"))
			Assert.assertTrue(isFileDownloaded_Ext(downloadPath, ".zip"));
		else
			Assert.assertTrue(isFileDownloaded_Ext_withoutDelete(downloadPath, ".zip"));
	}

	public static boolean isFileDownloaded_Ext(String dirPath, String ext){
		boolean flag=false;
		System.out.println(dirPath);
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			flag = false;
		}

		for (int i = 0; i < files.length; i++) 
		{
			if(files[i].getName().contains(ext)) 
			{
				System.out.println(files[i].getName());
				files[i].delete();
				flag=true;
			}
		}
		return flag;
	}

	public void navigateOrgList()
	{
		JavascriptExecutor jse = (JavascriptExecutor)TestBase.driver;
		  jse.executeScript("window.scrollBy(0,250)");
	
		wait.until(ExpectedConditions.visibilityOf(organizationLink));
		
		wait.until(ExpectedConditions.elementToBeClickable(organizationLink));
		organizationLink.click();
		//js.executeScript("arguments[0].click();", organizationLink);
	}

	public int getnumberProduct()
	{
		return driver.findElements(By.xpath("//*[@id=\"customer-admin-list\"]/tbody/tr")).size();
	}

	public void enterMultipleProductDetails(String type, int count, int existing)
	{
		try {
			for(int i=existing; i<= count; i++)
			{
				clickOnAddProductsButton();
				wait.until(ExpectedConditions.visibilityOf(selectProduct));
				Thread.sleep(3000);
				Select product = new Select(selectProduct);
				product.selectByIndex(i);
				String dataType = selectProductValid.getAttribute("data-fv-result");
				if(dataType.equalsIgnoreCase("invalid"))
				{
					product.selectByIndex(i);
				}
				DateFormat dateFormat = new SimpleDateFormat("dd");
				Date date = new Date();
				String formattedStartDate = dateFormat.format(date);
				startDate.click();
				wait.until(ExpectedConditions.visibilityOf(calendarProduct));
				String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
				WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
				reqDate.click();
				if(type.equalsIgnoreCase("manual"))
				{
					quantity.sendKeys("1");
				}
				else if(type.equalsIgnoreCase("automatic"))
				{

					unlimited.click();
				}
				else
					quantity.sendKeys("1");
				addProduct.click();
			}
		} 
		catch (InterruptedException e) 
		{
			Assert.fail("Issue with app");
		}

	}


	public void enterMultipleProductDetails(String type, int count)
	{
		try {
			for(int i=1; i<= count; i++)
			{
				clickOnAddProductsButton();
				WebDriverWait wait = new WebDriverWait(driver, 30);
				//				wait.until(ExpectedConditions.visibilityOf(selectProduct));
				Thread.sleep(3000);
				//				Select product = new Select(selectProduct);
				//				product.selectByIndex(i);
				Product.click();

				driver.findElement(By.xpath("//*[@id=\"scrollProduct\"]//li[@data-original-index='"+i+"']/a")).click();

				Thread.sleep(7000);
				//				

				//				String dataType = selectProductValid.getAttribute("data-fv-result");
				//				if(dataType.equalsIgnoreCase("invalid"))
				//				{
				//					product.selectByIndex(i);
				//				}
				DateFormat dateFormat = new SimpleDateFormat("dd");
				Date date = new Date();
				String formattedStartDate = dateFormat.format(date);
				startDate.click();
				wait.until(ExpectedConditions.visibilityOf(calendarProduct));
				String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
				WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
				reqDate.click();
				if(type.equalsIgnoreCase("manual"))
				{
					quantity.sendKeys("1");
				}
				else if(type.equalsIgnoreCase("automatic"))
				{

					unlimited.click();
				}
				else
					quantity.sendKeys("1");
				addProduct.click();

				try
				{
					if(driver.findElement(By.xpath("//*[@id=\"errorbox\"]/ul/li")).getText().contains("Please update the inventory."))
					{
						driver.findElement(By.xpath("//*[@id='purchaseType']/div[2]/input")).click();
						Thread.sleep(3000);

						Product.click();

						driver.findElement(By.xpath("//*[@id=\"scrollProduct\"]//li[@data-original-index='"+i+"']/a")).click();

						Thread.sleep(7000);
						//				
						driver.findElement(By.xpath("//input[@name=\"updated_license_limit\"]")).sendKeys("1");
						addProduct.click();

					}
				}
				catch(ElementNotInteractableException|NoSuchElementException e)
				{

				}
			}
		} 
		catch (InterruptedException e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}

	}

	public static boolean isFileDownloaded_Ext_withoutDelete(String dirPath, String ext){
		boolean flag=false;
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			flag = false;
		}

		for (int i = 1; i < files.length; i++) 
		{
			if(files[i].getName().contains(ext)) 
			{
				filePath = files[i].getAbsolutePath();
				flag=true;
			}
		}
		return flag;
	}

	public void productUsageCount(int usage)
	{
		wait.until(ExpectedConditions.visibilityOf(courseUsage));
		int count = Integer.parseInt(courseUsage.getText());
		Assert.assertTrue(usage == count);
	}

	
	public void enterElearningProductDetailsByName(String type, String name)
	{
		if(courseListName.containsKey(name))
			name=courseListName.get(name).toString();

		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(5000);
			name = name.replace("Â", "");
			
			productType = type;	
			productName = name;
			//		wait.until(ExpectedConditions.visibilityOf(selectProduct));
			//		Select product = new Select(selectProduct);
			//		List<WebElement> options = product.getOptions();
			//		System.out.println(options.size());
			//		for (WebElement element : options) 
			//		{
			//			if(element.getText().toLowerCase().trim().equalsIgnoreCase(name.toLowerCase().trim()))
			//			{
			//				element.click();
			//				break;
			//			}
			//		}
			//		
			Product.click();
			for(int i=0;i<name.length();i++)
				searchProduct.sendKeys(String.valueOf(name.charAt(i)));
			Thread.sleep(7000);
			//			
			Productselct.click();
			DateFormat dateFormat = new SimpleDateFormat("dd");
			Date date = new Date();
			String formattedStartDate = dateFormat.format(date);
			startDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
			WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
			reqDate.click();
			if(type.equalsIgnoreCase("manual"))
			{
				quantity.sendKeys("1");

			}
			else if(type.equalsIgnoreCase("automatic"))
			{

				unlimited.click();
			}
			else
			{
				quantity.sendKeys("1");
			}
			Thread.sleep(3000);	
			wait.until(ExpectedConditions.visibilityOf(partofCourse2));
			
			partofCourse2.click();
			addProduct.click();


			try
			{
				if(driver.findElement(By.xpath("//*[@id=\"errorbox\"]/ul/li")).getText().contains("Please update the inventory."))
				{
					driver.findElement(By.xpath("//*[@id='purchaseType']//label[text()='Add to Course Inventory']//preceding::input[1]")).click();
					Thread.sleep(3000);


					Product.click();

					for(int i=0;i<name.length();i++)
						searchProduct.sendKeys(String.valueOf(name.charAt(i)));
					Thread.sleep(7000);
					//			
					Productselct.click();
					Thread.sleep(3000);
					try {
						driver.findElement(By.xpath("//input[@name=\"updated_license_limit\"]")).sendKeys("1");
					} catch (Exception e) {
						// TODO Auto-generated catch block
					}
					addProduct.click();

				}
			}
			catch(NoSuchElementException e)
			{

			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
			enterProductDetailsByName(productType, productName);
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}
	
	

	public void enterProductDetailsByName_with_multiple(String type, String name)
	{
		if(courseListName.containsKey(name))
			name=courseListName.get(name).toString();

		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(5000);
			name = name.replace("Â", "");
			
			productType = type;	
			productName = name;
			//		wait.until(ExpectedConditions.visibilityOf(selectProduct));
			//		Select product = new Select(selectProduct);
			//		List<WebElement> options = product.getOptions();
			//		System.out.println(options.size());
			//		for (WebElement element : options) 
			//		{
			//			if(element.getText().toLowerCase().trim().equalsIgnoreCase(name.toLowerCase().trim()))
			//			{
			//				element.click();
			//				break;
			//			}
			//		}
			//		
			Product.click();
			for(int i=0;i<name.length();i++)
				searchProduct.sendKeys(String.valueOf(name.charAt(i)));
			Thread.sleep(7000);
			//			
			Productselct.click();
			DateFormat dateFormat = new SimpleDateFormat("dd");
			Date date = new Date();
			String formattedStartDate = dateFormat.format(date);
			startDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
			WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
			reqDate.click();
			wait.until(ExpectedConditions.visibilityOf(packagetype_2));
			packagetype_2.click();
			if(type.equalsIgnoreCase("manual"))
			{
				quantity.sendKeys("1");
				
				try
				{
					recurrenceYes.click();
					Assert.fail("Recurrence button is available");	
				}
				catch (Exception e) {

					System.out.println("Recurrence button is not  available");	;
				}
				

			}
			else if(type.equalsIgnoreCase("automatic"))
			{

				unlimited.click();
			}
			else
			{
				quantity.sendKeys("1");
			}
			Thread.sleep(3000);	
			addProduct.click();


			try
			{
				if(driver.findElement(By.xpath("//*[@id=\"errorbox\"]/ul/li")).getText().contains("Please update the inventory."))
				{
					driver.findElement(By.xpath("//*[@id='purchaseType']//label[text()='Add to Course Inventory']//preceding::input[1]")).click();
					Thread.sleep(3000);


					Product.click();

					for(int i=0;i<name.length();i++)
						searchProduct.sendKeys(String.valueOf(name.charAt(i)));
					Thread.sleep(7000);
					//			
					Productselct.click();
					Thread.sleep(3000);
					try {
						driver.findElement(By.xpath("//input[@name=\"updated_license_limit\"]")).sendKeys("1");
					} catch (Exception e) {
						// TODO Auto-generated catch block
					}
					addProduct.click();

				}
			}
			catch(NoSuchElementException e)
			{

			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
			enterProductDetailsByName(productType, productName);
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}
	
	public void enterProductDetailsByName(String type, String name)
	{
		if(courseListName.containsKey(name))
			name=courseListName.get(name).toString();

		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(5000);
			name = name.replace("Â", "");
			
			productType = type;	
			productName = name;
			//		wait.until(ExpectedConditions.visibilityOf(selectProduct));
			//		Select product = new Select(selectProduct);
			//		List<WebElement> options = product.getOptions();
			//		System.out.println(options.size());
			//		for (WebElement element : options) 
			//		{
			//			if(element.getText().toLowerCase().trim().equalsIgnoreCase(name.toLowerCase().trim()))
			//			{
			//				element.click();
			//				break;
			//			}
			//		}
			//		
			Product.click();
			for(int i=0;i<name.length();i++)
				searchProduct.sendKeys(String.valueOf(name.charAt(i)));
			Thread.sleep(7000);
			//			
			Productselct.click();
			DateFormat dateFormat = new SimpleDateFormat("dd");
			Date date = new Date();
			String formattedStartDate = dateFormat.format(date);
			startDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
			WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
			reqDate.click();
			if(type.equalsIgnoreCase("manual"))
			{
				quantity.sendKeys("1");
				
				try
				{
					recurrenceYes.click();
					Assert.fail("Recurrence button is available");	
				}
				catch (Exception e) {

					System.out.println("Recurrence button is not  available");	;
				}
				

			}
			else if(type.equalsIgnoreCase("automatic"))
			{

				unlimited.click();
			}
			else
			{
				quantity.sendKeys("1");
			}
			Thread.sleep(3000);	
			addProduct.click();


			try
			{
				if(driver.findElement(By.xpath("//*[@id=\"errorbox\"]/ul/li")).getText().contains("Please update the inventory."))
				{
					driver.findElement(By.xpath("//*[@id='purchaseType']//label[text()='Add to Course Inventory']//preceding::input[1]")).click();
					Thread.sleep(3000);


					Product.click();

					for(int i=0;i<name.length();i++)
						searchProduct.sendKeys(String.valueOf(name.charAt(i)));
					Thread.sleep(7000);
					//			
					Productselct.click();
					Thread.sleep(3000);
					try {
						driver.findElement(By.xpath("//input[@name=\"updated_license_limit\"]")).sendKeys("1");
					} catch (Exception e) {
						// TODO Auto-generated catch block
					}
					addProduct.click();

				}
			}
			catch(NoSuchElementException e)
			{

			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
			enterProductDetailsByName(productType, productName);
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
			
		}
	}
	public void enterProductNLNDetailsByNames(String name,String type)
	{
		if(courseListName.containsKey(name))
			name=courseListName.get(name).toString();

		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(5000);
			name = name.replace("Â", "");
			
			productName = name;
		
			Product.click();
			searchProduct.clear();
			for(int i=0;i<name.length();i++)
				searchProduct.sendKeys(String.valueOf(name.charAt(i)));
			Thread.sleep(7000);
			
			Productselct.click();
			DateFormat dateFormat = new SimpleDateFormat("dd");
			Date date = new Date();
			String formattedStartDate = dateFormat.format(date);
			startDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
			WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
			reqDate.click();
			
			Thread.sleep(5000);
//			wait.until(ExpectedConditions.visibilityOf(SubscriptionPlanSearch));
//			SubscriptionPlanSearch.sendKeys(Subscription);
			wait.until(ExpectedConditions.visibilityOf(Organization));
			Organization.click();
			
			if(type.equalsIgnoreCase("limited"))
			{
				quantity.sendKeys("1");
			}
			else if(type.equalsIgnoreCase("Unlimited"))
			{
				
				unlimited.click();
			}
			else
			{
				quantity.sendKeys("1");
			}
			Thread.sleep(3000);	
		
			addProduct.click();

		
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
			enterProductDetailsByName(productType, productName);
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
			
		}
	}
	
	public void enterProductNLNDetailsByName(String Subscription, String name,String type)
	{
		if(courseListName.containsKey(name))
			name=courseListName.get(name).toString();

		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(5000);
			name = name.replace("Â", "");
			
			productType = Subscription;	
			productName = name;
		
			Product.click();
			searchProduct.clear();
			for(int i=0;i<name.length();i++)
				searchProduct.sendKeys(String.valueOf(name.charAt(i)));
			Thread.sleep(7000);
			
			Productselct.click();
			DateFormat dateFormat = new SimpleDateFormat("dd");
			Date date = new Date();
			String formattedStartDate = dateFormat.format(date);
			startDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
			WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
			reqDate.click();
			
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOf(Organization));
			Organization.click();
			
			if(type.equalsIgnoreCase("limited"))
			{
				quantity.sendKeys("1");
			}
			else if(type.equalsIgnoreCase("Unlimited"))
			{
				
				unlimited.click();
			}
			else
			{
				quantity.sendKeys("1");
			}
			Thread.sleep(3000);	
			

//			wait.until(ExpectedConditions.visibilityOf(SubscriptionPlanSearch));
//			SubscriptionPlanSearch.clear();
			SubscriptionPlan.click();
			Thread.sleep(3000);
			
			String[] Subscriptions=Subscription.split(",");
			
			for(int i=0;i<Subscriptions.length;i++)
			{
				SubscriptionPlanSearch.clear();
				for(int j=0;j<Subscriptions[i].length();j++)
				{
					Thread.sleep(1000);
					
					SubscriptionPlanSearch.sendKeys( toString().valueOf(Subscriptions[i].charAt(j)));
				}
				Thread.sleep(3000);
				
				driver.findElement(By.xpath("//input[contains(@title,'"+Subscriptions[i]+"')]")).click();
			}
			
//			wait.until(ExpectedConditions.visibilityOf(SubscriptionPlanSearch));
//			SubscriptionPlanSearch.sendKeys(Subscription);
			
			Thread.sleep(3000);	
			addProduct.click();

		
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
			enterProductDetailsByName(productType, productName);
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
			
		}
	}
	public void enterProductNLNDetailsByName(String Subscription, String name)
	{
		if(courseListName.containsKey(name))
			name=courseListName.get(name).toString();

		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(5000);
			name = name.replace("Â", "");
			
			productType = Subscription;	
			productName = name;
		
			Product.click();
			searchProduct.clear();
			for(int i=0;i<name.length();i++)
				searchProduct.sendKeys(String.valueOf(name.charAt(i)));
			Thread.sleep(7000);
			
			Productselct.click();
			DateFormat dateFormat = new SimpleDateFormat("dd");
			Date date = new Date();
			String formattedStartDate = dateFormat.format(date);
			startDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
			WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
			reqDate.click();
			
			Thread.sleep(5000);
			
//			wait.until(ExpectedConditions.visibilityOf(SubscriptionPlanSearch));
//			SubscriptionPlanSearch.clear();
			SubscriptionPlan.click();
			Thread.sleep(3000);
			
			String[] Subscriptions=Subscription.split(",");
			
			for(int i=0;i<Subscriptions.length;i++)
			{
				SubscriptionPlanSearch.clear();
				for(int j=0;j<Subscriptions[i].length();j++)
				{
					Thread.sleep(1000);
					SubscriptionPlanSearch.sendKeys( toString().valueOf(Subscriptions[i].charAt(j)));
				}
				Thread.sleep(3000);
				
				driver.findElement(By.xpath("//input[contains(@title,'"+Subscriptions[i]+"')]")).click();
			}
			
//			wait.until(ExpectedConditions.visibilityOf(SubscriptionPlanSearch));
//			SubscriptionPlanSearch.sendKeys(Subscription);
			
			Thread.sleep(3000);	
			addProduct.click();

		
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
			enterProductDetailsByName(productType, productName);
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
			
		}
	}
	public void enterProductNLNDetailsByNames(String name)
	{
		if(courseListName.containsKey(name))
			name=courseListName.get(name).toString();

		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(5000);
			name = name.replace("Â", "");
			
			productName = name;
		
			Product.click();
			searchProduct.clear();
			for(int i=0;i<name.length();i++)
				searchProduct.sendKeys(String.valueOf(name.charAt(i)));
			Thread.sleep(7000);
			
			Productselct.click();
			DateFormat dateFormat = new SimpleDateFormat("dd");
			Date date = new Date();
			String formattedStartDate = dateFormat.format(date);
			startDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
			WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
			reqDate.click();
			
			Thread.sleep(5000);
//			wait.until(ExpectedConditions.visibilityOf(SubscriptionPlanSearch));
//			SubscriptionPlanSearch.sendKeys(Subscription);
			
			Thread.sleep(3000);	
			addProduct.click();

		
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
			enterProductDetailsByName(productType, productName);
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
			
		}
	}
	
	public void editctcProductDetailsByName(String type, String name)
	{
		if(courseListName.containsKey(name))
			name=courseListName.get(name).toString();

		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(5000);
			name = name.replace("Â", "");
			
			productType = type;	
			productName = name;
	
		
			Thread.sleep(3000);

			wait.until(ExpectedConditions.visibilityOf(CourseScorePercentage));
			CourseScorePercentage.click();
			wait.until(ExpectedConditions.visibilityOf(partofCourse));
			partofCourse.click();
			
		
			
			wait.until(ExpectedConditions.visibilityOf(findTrainingCenterWidget));
			findTrainingCenterWidget.click();
			try
			{
			Product.click();
			Assert.fail("Product should be disable");
			}
			catch(Exception e)
			{
				
			}
			
			Thread.sleep(7000);
			//			
		
			

			  LocalDateTime myDateObj = LocalDateTime.now().plusDays(Integer.parseInt("2"));
			    System.out.println("Before formatting: " + myDateObj);
			    DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd");

			    String formattedStartDate = myDateObj.format(myFormatObj);
		
			startDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
			WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
			reqDate.click();
			
			
			if(type.equalsIgnoreCase("manual"))
			{
				quantity.clear();;
				
				quantity.sendKeys("12");
				

			}
			else if(type.equalsIgnoreCase("automatic"))
			{
		
				
				try
				{
					unlimited.click();
				Assert.fail("Product Type should be disable");
				}
				catch(Exception e)
				{
					
				}
			}
			
			Thread.sleep(3000);	

				
			addProduct.click();


			
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}
	
	public void editProductDetailsByName(String type, String name)
	{
		if(courseListName.containsKey(name))
			name=courseListName.get(name).toString();

		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(5000);
			name = name.replace("Â", "");
			
			productType = type;	
			productName = name;
	
			retakeyes2.click();
			wait.until(ExpectedConditions.visibilityOf(retakeDuration));
			Select retakeDur = new Select(retakeDuration);
			retakeDuration.click();
			Thread.sleep(3000);

			retakeDur.selectByValue("1");
			Thread.sleep(3000);

			wait.until(ExpectedConditions.visibilityOf(CourseScorePercentage));
			CourseScorePercentage.click();
			wait.until(ExpectedConditions.visibilityOf(partofCourse));
			partofCourse.click();
			
			wait.until(ExpectedConditions.visibilityOf(PassedStatus));
			
			PassedStatus.click();
			
			
			
			wait.until(ExpectedConditions.visibilityOf(findTrainingCenterWidget));
			findTrainingCenterWidget.click();
			try
			{
			Product.click();
			Assert.fail("Product should be disable");
			}
			catch(Exception e)
			{
				
			}
			
			Thread.sleep(7000);
			//			
		
			

			  LocalDateTime myDateObj = LocalDateTime.now().plusDays(Integer.parseInt("2"));
			    System.out.println("Before formatting: " + myDateObj);
			    DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd");

			    String formattedStartDate = myDateObj.format(myFormatObj);
		
			startDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
			WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
			reqDate.click();
			
			
			if(type.equalsIgnoreCase("manual"))
			{
				quantity.clear();;
				
				quantity.sendKeys("12");
				

			}
			else if(type.equalsIgnoreCase("automatic"))
			{
		
				
				try
				{
					unlimited.click();
				Assert.fail("Product Type should be disable");
				}
				catch(Exception e)
				{
					
				}
			}
			
			Thread.sleep(3000);	

				
			addProduct.click();


			
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}
	public void editsProducttypeDetailsByName()
	{
	
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOf(quantity));
			
		    quantity.clear();
		    wait.until(ExpectedConditions.visibilityOf(unlimited));
			
			unlimited.click();
			Thread.sleep(3000);	


			addProduct.click();



		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}
	public void onlyEnterProductDetailsByName(String type, String name)
	{
		if(courseListName.containsKey(name))
			name=courseListName.get(name).toString();

		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			name = name.replaceAll("registered", "\u00AE");
			name = name.replace("Â", "");
			
			Thread.sleep(3000);
			productType = type;	
			productName = name;
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(productDropdown));
		String attributeValue = productDropdown.getAttribute("style");
		while(!attributeValue.contains("pointer"))
		{
			attributeValue = productDropdown.getAttribute("style");
		}
		Thread.sleep(5000);
		//js.executeScript("arguments[0].click();", productDropdown);
		productDropdown.click();	
		wait.until(ExpectedConditions.visibilityOf(productSearch));
		productSearch.click();
		productSearch.sendKeys(name);
		//Thread.sleep(5000);
		List<WebElement> options = driver.findElements(By.xpath(productSearchResult));
		while(!(options.size() == 2))
		{
			options = driver.findElements(By.xpath(productSearchResult));
		}
		for(int i = 1; i <= options.size(); i++)
		{
			String element = "(" + productSearchResult + ")[" + i + "]";
			String value = driver.findElement(By.xpath(element)).getText();
			if(value.toLowerCase().trim().equalsIgnoreCase(name.toLowerCase().trim()))
			{
				driver.findElement(By.xpath(element)).click();
				break;
			}
		}

		DateFormat dateFormat = new SimpleDateFormat("dd");
		Date date = new Date();
		String formattedStartDate = dateFormat.format(date);
		startDate.click();
		wait.until(ExpectedConditions.visibilityOf(calendarProduct));
		String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
		WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
		reqDate.click();
		if(type.equalsIgnoreCase("manual"))
		{
			quantity.sendKeys("1");
		}
		else if(type.equalsIgnoreCase("automatic"))
		{
			
			unlimited.click();
		}
		else
		{
			quantity.sendKeys("1");
		}
		Thread.sleep(3000);	
	}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println(ex.getMessage());
			enterProductDetailsByName(productType, productName);
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}

	public void onlyEnterElearningProductDetailsByName(String type, String name)
	{
		if(courseListName.containsKey(name))
			name=courseListName.get(name).toString();

		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			name = name.replaceAll("registered", "\u00AE");
			name = name.replace("Â", "");
			
			Thread.sleep(3000);
			productType = type;	
			productName = name;
		wait.until(ExpectedConditions.visibilityOf(productDropdown));
		
		Thread.sleep(5000);
		//js.executeScript("arguments[0].click();", productDropdown);
		productDropdown.click();	
		wait.until(ExpectedConditions.visibilityOf(productSearch));
		productSearch.click();
		
		for(int i=0;i<name.length();i++)
			searchProduct.sendKeys(String.valueOf(name.charAt(i)));
		Thread.sleep(7000);
		//			
		Productselct.click();
	
		//Thread.sleep(5000);
		
		DateFormat dateFormat = new SimpleDateFormat("dd");
		Date date = new Date();
		String formattedStartDate = dateFormat.format(date);
		startDate.click();
		wait.until(ExpectedConditions.visibilityOf(calendarProduct));
		String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
		WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
		reqDate.click();
		if(type.equalsIgnoreCase("manual"))
		{
			quantity.sendKeys("1");
		}
		else if(type.equalsIgnoreCase("automatic"))
		{
			
			unlimited.click();
		}
		else
		{
			quantity.sendKeys("1");
		}
		Thread.sleep(3000);	
		try
		{
		partofCourse.click();
		} catch (Exception e) 
		{
			partofCourse2.click();
		}
	}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println(ex.getMessage());
			enterProductDetailsByName(productType, productName);
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}
	public void onlyEnterProductDetailsByName(String type, String name,String date)
	{
		if(courseListName.containsKey(name))
			name=courseListName.get(name).toString();

		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			name = name.replaceAll("registered", "\u00AE");
			name = name.replace("Â", "");
			
			Thread.sleep(3000);
			productType = type;	
			productName = name;
		wait.until(ExpectedConditions.visibilityOf(productDropdown));
		
		Thread.sleep(5000);
		//js.executeScript("arguments[0].click();", productDropdown);
		productDropdown.click();	
		wait.until(ExpectedConditions.visibilityOf(productSearch));
		productSearch.click();
		
		for(int i=0;i<name.length();i++)
			searchProduct.sendKeys(String.valueOf(name.charAt(i)));
		Thread.sleep(7000);
		//			
		Productselct.click();
	
		//Thread.sleep(5000);
		
		  LocalDateTime myDateObj = LocalDateTime.now().plusDays(Integer.parseInt(date));
		    System.out.println("Before formatting: " + myDateObj);
		    DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd");

		    String formattedStartDate = myDateObj.format(myFormatObj);
	
		startDate.click();
		wait.until(ExpectedConditions.visibilityOf(calendarProduct));
		String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
		WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
		reqDate.click();
		if(type.equalsIgnoreCase("manual"))
		{
			quantity.sendKeys("1");
		}
		else if(type.equalsIgnoreCase("automatic"))
		{
			
			unlimited.click();
		}
		else
		{
			quantity.sendKeys("1");
		}
		Thread.sleep(3000);	
	}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println(ex.getMessage());
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}
	public void clickRecurrenceCheckbox()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		String pageValue = js.executeScript("return document.readyState").toString();
		while(!(pageValue.equalsIgnoreCase("complete")))
		{
			pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
		}
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(recurrenceAfterCheckbox));
		recurrenceAfterCheckbox.click();
		
	}
	
	public void allowRecurrence()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		
		
		wait.until(ExpectedConditions.visibilityOf(enableRecurrence));
		enableRecurrence.click();	
		
		
	}
	public void enterProductDetailsByName(String type, String name,int limit)
	{
		if(courseListName.containsKey(name))
			name=courseListName.get(name).toString();

		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(5000);
			productType = type;	
			productName = name;
			//		wait.until(ExpectedConditions.visibilityOf(selectProduct));
			//		Select product = new Select(selectProduct);
			//		List<WebElement> options = product.getOptions();
			//		System.out.println(options.size());
			//		for (WebElement element : options) 
			//		{
			//			if(element.getText().toLowerCase().trim().equalsIgnoreCase(name.toLowerCase().trim()))
			//			{
			//				element.click();
			//				break;
			//			}
			//		}
			//		
			Product.click();
			for(int i=0;i<name.length();i++)
				searchProduct.sendKeys(String.valueOf(name.charAt(i)));
			Thread.sleep(7000);
			//			
			Productselct.click();
			DateFormat dateFormat = new SimpleDateFormat("dd");
			Date date = new Date();
			String formattedStartDate = dateFormat.format(date);
			startDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
			WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
			reqDate.click();
			if(type.equalsIgnoreCase("manual"))
			{
				quantity.sendKeys(String.valueOf(limit));

			}
			else if(type.equalsIgnoreCase("automatic"))
			{

				unlimited.click();
			}
			else
			{
				quantity.sendKeys(String.valueOf(limit));
			}
			Thread.sleep(3000);	
			addProduct.click();


			try
			{
				if(driver.findElement(By.xpath("//*[@id=\"errorbox\"]/ul/li")).getText().contains("Please update the inventory."))
				{
					driver.findElement(By.xpath("//*[@id='purchaseType']//label[text()='Add to Course Inventory']//preceding::input[1]")).click();
					Thread.sleep(3000);

					//			product = new Select(selectProduct);
					//			 options = product.getOptions();
					//				System.out.println(options.size());
					//				for (WebElement element : options) 
					//				{
					//					if(element.getText().toLowerCase().trim().equalsIgnoreCase(name.toLowerCase().trim()))
					//					{
					//						element.click();
					//						break;
					//					}
					//				}

					Product.click();

					for(int i=0;i<name.length();i++)
						searchProduct.sendKeys(String.valueOf(name.charAt(i)));
					Thread.sleep(7000);
					//			
					Productselct.click();
					Thread.sleep(3000);
					try {
						driver.findElement(By.xpath("//input[@name=\"updated_license_limit\"]")).sendKeys(String.valueOf(limit));
					} catch (Exception e) {
						// TODO Auto-generated catch block
					}
					addProduct.click();

				}
			}
			catch(NoSuchElementException e)
			{

			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
			enterProductDetailsByName(productType, productName);
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}

	public void enterProductDetailsdontsave(String type, String name,String option)
	{

		try 
		{
			if(courseListName.containsKey(name))
				name=courseListName.get(name).toString();
			name = name.replace("Â", "");
			
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(5000);

			productType = type;	
			productName = name;

			Product.click();

			for(int i=0;i<name.length();i++)
				searchProduct.sendKeys(String.valueOf(name.charAt(i)));
			Thread.sleep(7000);
			//			
			Productselct.click();

			DateFormat dateFormat = new SimpleDateFormat("dd");
			Date date = new Date();
			String formattedStartDate = dateFormat.format(date);
			startDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
			WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
			reqDate.click();
			if(type.equalsIgnoreCase("manual"))
			{
				quantity.sendKeys("1");

				if(option.contains("retake_yes"))
				{
					retakeyes.click();
					wait.until(ExpectedConditions.visibilityOf(retakeDuration));
					Select retakeDur = new Select(retakeDuration);
					retakeDuration.click();
					Thread.sleep(3000);

					retakeDur.selectByValue(option.split(";")[1].split("_")[1]);
					try
					{
						recurrenceYes.click();
						Assert.fail("Recurrence button  should avaible");	
					}
					catch (Exception e) {

						System.out.println("recurrence button is not  avaible");	;
					}
					;
				}
				else if(option.contains("recussion_yes"))
				{

					try
					{
						recurrenceYes.click();
						Assert.fail("Recurrence button  should avaible");	
					}
					catch (Exception e) {

						System.out.println("recurrence button is not  avaible");	;
					}

					;
					;
				}


			}
			else if(type.equalsIgnoreCase("automatic"))
			{

				unlimited.click();
				
				if(option.contains("recussion_yes"))
				{
					recurrenceYes.click();

					Thread.sleep(3000);
					recurrenceCheckYes.click();
					recurrenceNumber.clear();
					Thread.sleep(3000);

					recurrenceNumber.sendKeys(option.split(";")[1].split("_")[1]);;

					try
					{
						retakeyes.click();
						Assert.fail("Retake button  should avaible");	
					}
					catch (Exception e) {

						System.out.println("Retake button is not  avaible");	;
					}
					;
				}
				else if(option.contains("retake_yes"))
				{
					retakeyes.click();
					wait.until(ExpectedConditions.visibilityOf(retakeDuration));
					Select retakeDur = new Select(retakeDuration);
					retakeDuration.click();
					Thread.sleep(3000);

					retakeDur.selectByValue(option.split(";")[1].split("_")[1]);

					try
					{
						recurrenceYes.click();

						Assert.fail("Recurrence button not should avaible");	
					}
					catch (Exception e) {

						System.out.println("Recurrence button is not avaible");	;
					}
					;
				}
			}
			else
			{
				quantity.sendKeys("1");
			}
//			Thread.sleep(3000);	
//			addProduct.click();


			
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
			enterProductDetailsByName(productType, productName);
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
//			e.printStackTrace();
		}
	
	}
	public void enterProductDetails(String type, String name,String option)
	{
		try 
		{
			if(courseListName.containsKey(name))
				name=courseListName.get(name).toString();
			name = name.replace("Â", "");
			
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(5000);

			productType = type;	
			productName = name;

			Product.click();

			for(int i=0;i<name.length();i++)
				searchProduct.sendKeys(String.valueOf(name.charAt(i)));
			Thread.sleep(7000);
			//			
			Productselct.click();

			DateFormat dateFormat = new SimpleDateFormat("dd");
			Date date = new Date();
			String formattedStartDate = dateFormat.format(date);
			startDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
			WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
			reqDate.click();
			if(type.equalsIgnoreCase("manual"))
			{
				quantity.sendKeys("1");

				if(option.contains("retake_yes"))
				{
					retakeyes.click();
					wait.until(ExpectedConditions.visibilityOf(retakeDuration));
					Select retakeDur = new Select(retakeDuration);
					retakeDuration.click();
					Thread.sleep(3000);
					System.out.println(option.split(";")[1].split("_")[1]);
					retakeDur.selectByVisibleText(option.split(";")[1].split("_")[1]);;
				
					try
					{
						recurrenceYes.click();
						Assert.fail("Recurrence button  should avaible");	
					}
					catch (Exception e) {

						System.out.println("recurrence button is not  avaible");	;
					}
					;
				}
				else if(option.contains("recussion_yes"))
				{

					try
					{
						recurrenceYes.click();
						Assert.fail("Recurrence button  should avaible");	
					}
					catch (Exception e) {

						System.out.println("recurrence button is not  avaible");	;
					}

					;
					;
				}


			}
			else if(type.equalsIgnoreCase("automatic"))
			{

				unlimited.click();
				
				if(option.contains("recussion_yes"))
				{
					recurrenceYes.click();

					Thread.sleep(3000);
					recurrenceCheckYes.click();
					recurrenceNumber.clear();
					Thread.sleep(3000);

					recurrenceNumber.sendKeys(option.split(";")[1].split("_")[1]);;

					try
					{
						retakeyes.click();
						Assert.fail("Retake button  should avaible");	
					}
					catch (Exception e) {

						System.out.println("Retake button is not  avaible");	;
					}
					;
				}
				else if(option.contains("retake_yes"))
				{
					retakeyes.click();
					wait.until(ExpectedConditions.visibilityOf(retakeDuration));
					Select retakeDur = new Select(retakeDuration);
					retakeDuration.click();
					Thread.sleep(3000);

					retakeDur.selectByVisibleText(option.split(";")[1].split("_")[1]);

					try
					{
						recurrenceYes.click();

						Assert.fail("Recurrence button not should avaible");	
					}
					catch (Exception e) {

						System.out.println("Recurrence button is not avaible");	;
					}
					;
				}
			}
			else
			{
				quantity.sendKeys("1");
			}
			Thread.sleep(3000);	
			addProduct.click();


			try
			{
				if(driver.findElement(By.xpath("//*[@id=\"errorbox\"]/ul/li")).getText().contains("Please update the inventory."))
				{
					if(driver.findElement(By.xpath("//*[@id=\"errorbox\"]/ul/li")).getText().contains("Please update the inventory."))
					{
						driver.findElement(By.xpath("//*[@id='purchaseType']/div[2]/input")).click();
						Thread.sleep(3000);

						Product.click();

						for(int i=0;i<name.length();i++)
							searchProduct.sendKeys(String.valueOf(name.charAt(i)));
						Thread.sleep(7000);
						//				
						Productselct.click();

						Thread.sleep(3000);
						try {
							driver.findElement(By.xpath("//input[@name=\"updated_license_limit\"]")).sendKeys("1");
						} catch (Exception e) {
							// TODO Auto-generated catch block
						}
						addProduct.click();

					}
				}
			}
			catch(NoSuchElementException e)
			{

			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
			enterProductDetailsByName(productType, productName);
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}
	
	
	public void enterProductDetailsdont(String type, String name)
	{
		try 
		{
			if(courseListName.containsKey(name))
				name=courseListName.get(name).toString();
			name = name.replace("Â", "");
			
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(5000);

			productType = type;	
			productName = name;

			Product.click();

			for(int i=0;i<name.length();i++)
				searchProduct.sendKeys(String.valueOf(name.charAt(i)));
			Thread.sleep(7000);
			//			
			Productselct.click();

			DateFormat dateFormat = new SimpleDateFormat("dd");
			Date date = new Date();
			String formattedStartDate = dateFormat.format(date);
			startDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
			WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
			reqDate.click();
			if(type.equalsIgnoreCase("manual"))
			{
				quantity.sendKeys("1");

			}
			else if(type.equalsIgnoreCase("automatic"))
			{

				unlimited.click();
				
				
			}
			else
			{
				quantity.sendKeys("1");
			}
			Thread.sleep(3000);	
//			addProduct.click();


			
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
			enterProductDetailsByName(productType, productName);
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}
	
	
	public void enterProductDetailsCTC(String type, String name,String option)
	{
		try 
		{
			if(courseListName.containsKey(name))
				name=courseListName.get(name).toString();
			name = name.replace("Â", "");
			
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(5000);

			productType = type;	
			productName = name;

			Product.click();

			for(int i=0;i<name.length();i++)
				searchProduct.sendKeys(String.valueOf(name.charAt(i)));
			Thread.sleep(7000);
			//			
			Productselct.click();

			DateFormat dateFormat = new SimpleDateFormat("dd");
			Date date = new Date();
			String formattedStartDate = dateFormat.format(date);
			startDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
			WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
			reqDate.click();
			
			
			if(type.equalsIgnoreCase("manual"))
			{
				quantity.sendKeys("1");

				if(option.contains("retake_No"))
				{
					
					try
					{
						retakeNo.click();
						
						Thread.sleep(3000);

						Assert.fail("Retake button not be should avaible");	
					}
					catch (Exception e) {

						System.out.println("Retake button is not  avaible");	;
					}
					;
				}
				else
				{

					try
					{
						recurrenceNo.click();
						Assert.fail("Recurrence button  should avaible");	
					}
					catch (Exception e) {

						System.out.println("recurrence button is not  avaible");	;
					}

					;
					;
				}


			}
			else if(type.equalsIgnoreCase("automatic"))
			{
				unlimited.click();
				
				if(option.contains("recussion_no"))
				{

					Thread.sleep(5000);

					recurrenceNo.click();

					
				
					try
					{
						retakeNo.click();

						Assert.fail("Retake button not should avaible");	
					}
					catch (Exception e) {

						System.out.println("Recurrence button is not avaible");	;
					}
					;
				
					
					
					;
				}
				else if(option.contains("recussion_yes"))
				{

					Thread.sleep(5000);

					recurrenceYes.click();

					
				
					try
					{
						retakeNo.click();

						Assert.fail("Retake button not should avaible");	
					}
					catch (Exception e) {

						System.out.println("Recurrence button is not avaible");	;
					}
					;
				
					
					
					;
				}
				else if(option.contains("retake_no"))
				{
					
					try
					{
						retakeNo.click();
						Assert.fail("Retake button  should avaible");	
					}
					catch (Exception e) {

						System.out.println("Retake button is not  avaible");	;
					}
					;
				}
			}
			else
			{
				quantity.sendKeys("1");
			}
			Thread.sleep(3000);	
			addProduct.click();


			try
			{
				if(driver.findElement(By.xpath("//*[@id=\"errorbox\"]/ul/li")).getText().contains("Please update the inventory."))
				{
					if(driver.findElement(By.xpath("//*[@id=\"errorbox\"]/ul/li")).getText().contains("Please update the inventory."))
					{
						driver.findElement(By.xpath("//*[@id='purchaseType']/div[2]/input")).click();
						Thread.sleep(3000);

						Product.click();

						for(int i=0;i<name.length();i++)
							searchProduct.sendKeys(String.valueOf(name.charAt(i)));
						Thread.sleep(7000);
						//				
						Productselct.click();

						Thread.sleep(3000);
						try {
							driver.findElement(By.xpath("//input[@name=\"updated_license_limit\"]")).sendKeys("1");
						} catch (Exception e) {
							// TODO Auto-generated catch block
						}
						addProduct.click();

					}
				}
			}
			catch(NoSuchElementException e)
			{

			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
			enterProductDetailsByName(productType, productName);
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}
	public void entereditProductDetailsCTC(String type, String name,String option)
	{
		try 
		{
			if(courseListName.containsKey(name))
				name=courseListName.get(name).toString();

			
			Thread.sleep(5000);



			
			if(type.equalsIgnoreCase("manual"))
			{
				quantity.sendKeys("1");

				if(option.contains("retake_No"))
				{
					
					try
					{
						retakeNo.click();
						
						Thread.sleep(3000);

						Assert.fail("Retake button not be should avaible");	
					}
					catch (Exception e) {

						System.out.println("Retake button is not  avaible");	;
					}
					;
				}
				else
				{

					try
					{
						recurrenceNo.click();
						Assert.fail("Recurrence button  should avaible");	
					}
					catch (Exception e) {

						System.out.println("recurrence button is not  avaible");	;
					}

					;
					;
				}


			}
			else if(type.equalsIgnoreCase("automatic"))
			{

				if(option.contains("recussion_no"))
				{

				
					
				
					try
					{
						Thread.sleep(5000);

						recurrenceNo.click();

						Assert.fail("Retake button not should avaible");	
					}
					catch (Exception e) {

						System.out.println("Recurrence button is not avaible");	;
					}
					;
				
					
					
					;
				}
				else if(option.contains("recussion_yes"))
				{

					Thread.sleep(5000);

					recurrenceYes.click();

					
				
					try
					{
						retakeNo.click();

						Assert.fail("Retake button not should avaible");	
					}
					catch (Exception e) {

						System.out.println("Recurrence button is not avaible");	;
					}
					;
				
					
					
					;
				}
				else if(option.contains("retake_no"))
				{
					
					try
					{
						retakeNo.click();
						Assert.fail("Retake button  should avaible");	
					}
					catch (Exception e) {

						System.out.println("Retake button is not  avaible");	;
					}
					;
				}
			}
			else
			{
				quantity.sendKeys("1");
			}
			Thread.sleep(3000);	
			addProduct.click();


			try
			{
				if(driver.findElement(By.xpath("//*[@id=\"errorbox\"]/ul/li")).getText().contains("Please update the inventory."))
				{
					if(driver.findElement(By.xpath("//*[@id=\"errorbox\"]/ul/li")).getText().contains("Please update the inventory."))
					{
						driver.findElement(By.xpath("//*[@id='purchaseType']/div[2]/input")).click();
						Thread.sleep(3000);

						Product.click();

						for(int i=0;i<name.length();i++)
							searchProduct.sendKeys(String.valueOf(name.charAt(i)));
						Thread.sleep(7000);
						//				
						Productselct.click();

						Thread.sleep(3000);
						try {
							driver.findElement(By.xpath("//input[@name=\"updated_license_limit\"]")).sendKeys("1");
						} catch (Exception e) {
							// TODO Auto-generated catch block
						}
						addProduct.click();

					}
				}
			}
			catch(NoSuchElementException e)
			{

			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
			enterProductDetailsByName(productType, productName);
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}

	public void entereditProductDetailschangestatus(String option)
	{
		try 
		{
			Thread.sleep(4000);




			wait.until(ExpectedConditions.visibilityOf(recurrenceYes));

			recurrenceYes.click();

			wait.until(ExpectedConditions.visibilityOf(recurrenceYes));

			recurrenceCheckYes.click();

			recurrenceNumber.clear();
			Thread.sleep(3000);

			recurrenceNumber.sendKeys(option.split(";")[1].split("_")[1]);;

			addProduct.click();




		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
			entereditProductDetailschangestatus(option);
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}
	public void entereditProductDetailschangestatus(String option,String duration,String number)
	{
		try 
		{
				
			

			   wait.until(ExpectedConditions.visibilityOf(recurrenceYes));
			
						recurrenceYes.click();

						   wait.until(ExpectedConditions.visibilityOf(recurrenceYes));
						recurrenceCheckYes.click();
						Select select = new Select(recurreneSelect);
						
						   recurreneSelect.click();
						   select.selectByVisibleText(option);
							
						 select = new Select(recurrenceSelect);
						 recurrenceSelect.click();
						   wait.until(ExpectedConditions.visibilityOf(recurrenceSelect));
						   select.selectByVisibleText(number);
						      
					recurrenceNumber.clear();
					Thread.sleep(3000);
					recurrenceNumber.sendKeys(duration);;

				
			


		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
			entereditProductDetailschangestatus(option);
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}

	public void entereditProductDetails(String type, String name,String option)
	{
		try 
		{
			if(courseListName.containsKey(name))
				name=courseListName.get(name).toString();

			
			Thread.sleep(5000);



			
			if(type.equalsIgnoreCase("manual"))
			{
				quantity.sendKeys("1");

				if(option.contains("retake_No"))
				{
					retakeNo.click();
					
					Thread.sleep(3000);

					try
					{
						recurrenceYes.click();
						Assert.fail("Recurrence button  should avaible");	
					}
					catch (Exception e) {

						System.out.println("recurrence button is not  avaible");	;
					}
					;
				}
				else if(option.contains("recussion_No"))
				{

					try
					{
						recurrenceNo.click();
						Assert.fail("Recurrence button  should avaible");	
					}
					catch (Exception e) {

						System.out.println("recurrence button is not  avaible");	;
					}

					;
					;
				}


			}
			else if(type.equalsIgnoreCase("automatic"))
			{

				if(option.contains("recussion_no"))
				{

					Thread.sleep(5000);

					recurrenceNo.click();

					
					Thread.sleep(5000);
					wait.until(ExpectedConditions.visibilityOf(retakeyes2));
					retakeyes2.click();
					wait.until(ExpectedConditions.visibilityOf(retakeDuration));
					Select retakeDur = new Select(retakeDuration);
					retakeDuration.click();
					Thread.sleep(3000);

					retakeDur.selectByValue(option.split(";")[1].split("_")[1]);

					try
					{
						recurrenceYes.click();

						Assert.fail("Recurrence button not should avaible");	
					}
					catch (Exception e) {

						System.out.println("Recurrence button is not avaible");	;
					}
					;
				
					
					
					;
				}
				else if(option.contains("retake_no"))
				{
					retakeNo.click();
					Thread.sleep(3000);
					recurrenceYes.click();

					Thread.sleep(3000);
					recurrenceCheckYes.click();
					recurrenceNumber.clear();
					Thread.sleep(3000);

					recurrenceNumber.sendKeys(option.split(";")[1].split("_")[1]);;

					
					try
					{
						retakeyes.click();
						Assert.fail("Retake button  should avaible");	
					}
					catch (Exception e) {

						System.out.println("Retake button is not  avaible");	;
					}
					;
				}
			}
			else
			{
				quantity.sendKeys("1");
			}
			Thread.sleep(3000);	
			addProduct.click();


			try
			{
				if(driver.findElement(By.xpath("//*[@id=\"errorbox\"]/ul/li")).getText().contains("Please update the inventory."))
				{
					if(driver.findElement(By.xpath("//*[@id=\"errorbox\"]/ul/li")).getText().contains("Please update the inventory."))
					{
						driver.findElement(By.xpath("//*[@id='purchaseType']/div[2]/input")).click();
						Thread.sleep(3000);

						Product.click();

						for(int i=0;i<name.length();i++)
							searchProduct.sendKeys(String.valueOf(name.charAt(i)));
						Thread.sleep(7000);
						//				
						Productselct.click();

						Thread.sleep(3000);
						try {
							driver.findElement(By.xpath("//input[@name=\"updated_license_limit\"]")).sendKeys("1");
						} catch (Exception e) {
							// TODO Auto-generated catch block
						}
						addProduct.click();

					}
				}
			}
			catch(NoSuchElementException e)
			{

			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
			enterProductDetailsByName(productType, productName);
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}

	public void entereditProductDetailselearing(String type, String name,String option)
	{
		try 
		{
			if(courseListName.containsKey(name))
				name=courseListName.get(name).toString();

			
			Thread.sleep(5000);



			
			if(type.equalsIgnoreCase("manual"))
			{
				quantity.sendKeys("1");

				if(option.contains("retake_No"))
				{
					retakeNo.click();
					
					Thread.sleep(3000);

					try
					{
						recurrenceYes.click();
						Assert.fail("Recurrence button  should avaible");	
					}
					catch (Exception e) {

						System.out.println("recurrence button is not  avaible");	;
					}
					;
				}
				else if(option.contains("recussion_No"))
				{

					try
					{
						recurrenceNo.click();
						Assert.fail("Recurrence button  should avaible");	
					}
					catch (Exception e) {

						System.out.println("recurrence button is not  avaible");	;
					}

					;
					;
				}


			}
			else if(type.equalsIgnoreCase("automatic"))
			{

				if(option.contains("recussion_no"))
				{

					Thread.sleep(5000);

					recurrenceNo.click();

					
					Thread.sleep(5000);
					wait.until(ExpectedConditions.visibilityOf(retakeyes2));
					retakeyes2.click();
					wait.until(ExpectedConditions.visibilityOf(retakeDuration));
					Select retakeDur = new Select(retakeDuration);
					retakeDuration.click();
					Thread.sleep(3000);

					retakeDur.selectByValue(option.split(";")[1].split("_")[1]);

					try
					{
						recurrenceYes.click();

						Assert.fail("Recurrence button not should avaible");	
					}
					catch (Exception e) {

						System.out.println("Recurrence button is not avaible");	;
					}
					;
				
					
					
					;
				}
				else if(option.contains("retake_no"))
				{
					retakeNo.click();
					Thread.sleep(3000);
					recurrenceYes.click();

					Thread.sleep(3000);
					recurrenceCheckYes.click();
					recurrenceNumber.clear();
					Thread.sleep(3000);

					recurrenceNumber.sendKeys(option.split(";")[1].split("_")[1]);;

					
					try
					{
						retakeyes.click();
						Assert.fail("Retake button  should avaible");	
					}
					catch (Exception e) {

						System.out.println("Retake button is not  avaible");	;
					}
					;
				}
			}
			else
			{
				quantity.sendKeys("1");
			}
			Thread.sleep(3000);	
			wait.until(ExpectedConditions.visibilityOf(partofCourse));
			partofCourse.click();

			addProduct.click();


			try
			{
				if(driver.findElement(By.xpath("//*[@id=\"errorbox\"]/ul/li")).getText().contains("Please update the inventory."))
				{
					if(driver.findElement(By.xpath("//*[@id=\"errorbox\"]/ul/li")).getText().contains("Please update the inventory."))
					{
						driver.findElement(By.xpath("//*[@id='purchaseType']/div[2]/input")).click();
						Thread.sleep(3000);

						Product.click();

						for(int i=0;i<name.length();i++)
							searchProduct.sendKeys(String.valueOf(name.charAt(i)));
						Thread.sleep(7000);
						//				
						Productselct.click();

						Thread.sleep(3000);
						try {
							driver.findElement(By.xpath("//input[@name=\"updated_license_limit\"]")).sendKeys("1");
						} catch (Exception e) {
							// TODO Auto-generated catch block
						}
						addProduct.click();

					}
				}
			}
			catch(NoSuchElementException e)
			{

			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
			enterProductDetailsByName(productType, productName);
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}

	public void enterProductDetailsByName(String type, String name,String option)
	{
		try 
		{
			if(courseListName.containsKey(name))
				name=courseListName.get(name).toString();

			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(5000);
			name = name.replace("Â", "");
			
			productType = type;	
			productName = name;
			//		wait.until(ExpectedConditions.visibilityOf(selectProduct));
			//		Select product = new Select(selectProduct);
			//		List<WebElement> options = product.getOptions();
			//		System.out.println(options.size());
			//		for (WebElement element : options) 
			//		{
			//			if(element.getText().toLowerCase().trim().equalsIgnoreCase(name.toLowerCase().trim()))
			//			{
			//				element.click();
			//				break;
			//			}
			//		}
			//		
			Product.click();

			for(int i=0;i<name.length();i++)
				searchProduct.sendKeys(String.valueOf(name.charAt(i)));
			Thread.sleep(7000);
			//			
			Productselct.click();

			DateFormat dateFormat = new SimpleDateFormat("dd");
			Date date = new Date();
			String formattedStartDate = dateFormat.format(date);
			startDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
			WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
			reqDate.click();
			if(type.equalsIgnoreCase("manual"))
			{
				quantity.sendKeys("1");

				if(option.contains("retake_yes"))
				{
					retakeyes.click();
					wait.until(ExpectedConditions.visibilityOf(retakeDuration));
					Select retakeDur = new Select(retakeDuration);
					retakeDuration.click();
					Thread.sleep(3000);

					retakeDur.selectByValue(option.split(";")[1].split("_")[1]);
					;
				}

				if(option.contains("recussion_yes"))
				{
					try
					{
						recurrenceYes.click();
						Assert.fail("Recussion Failed");
						//					wait.until(ExpectedConditions.visibilityOf(retakeDuration));
						//					Select retakeDur = new Select(retakeDuration);
						//					retakeDuration.click();
					}
					catch(Exception e)
					{
						System.out.println("Recussion is not available ");
					}
					;
				}


			}
			else if(type.equalsIgnoreCase("automatic"))
			{

				unlimited.click();
				if(option.contains("recussion_yes"))
				{
					recurrenceYes.click();

					//				wait.until(ExpectedConditions.visibilityOf(retakeDuration));
					//				Select retakeDur = new Select(retakeDuration);
					//				retakeDuration.click();
					Thread.sleep(3000);
					recurrenceCheckYes.click();
					recurrenceNumber.clear();
					Thread.sleep(3000);

					recurrenceNumber.sendKeys(option.split(";")[1].split("_")[1]);;
					;
				}
				if(option.contains("retake_yes"))
				{
					retakeyes.click();
					wait.until(ExpectedConditions.visibilityOf(retakeDuration));
					Select retakeDur = new Select(retakeDuration);
					retakeDuration.click();
					Thread.sleep(3000);

					retakeDur.selectByValue(option.split(";")[1].split("_")[1]);
					;
				}
			}
			else
			{
				quantity.sendKeys("1");
			}
			Thread.sleep(3000);	
			addProduct.click();


			try
			{
				if(driver.findElement(By.xpath("//*[@id=\"errorbox\"]/ul/li")).getText().contains("Please update the inventory."))
				{
					if(driver.findElement(By.xpath("//*[@id=\"errorbox\"]/ul/li")).getText().contains("Please update the inventory."))
					{
						driver.findElement(By.xpath("//*[@id='purchaseType']/div[2]/input")).click();
						Thread.sleep(3000);

						Product.click();

						for(int i=0;i<name.length();i++)
							searchProduct.sendKeys(String.valueOf(name.charAt(i)));
						Thread.sleep(7000);
						//				
						Productselct.click();

						Thread.sleep(3000);
						try {
							driver.findElement(By.xpath("//input[@name=\"updated_license_limit\"]")).sendKeys("1");
						} catch (Exception e) {
							// TODO Auto-generated catch block
						}
						addProduct.click();

					}
				}
			}
			catch(NoSuchElementException e)
			{
				
			}
		}
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			System.out.println("In catch");
			enterProductDetailsByName(productType, productName);
		} catch (Exception e) 
		{
			Assert.fail("Issues while add product"+e.getMessage());
		}
	}

	public void verifyenddatepresence() {
		Boolean Display = LMSenddate.isDisplayed();
		System.out.println("Element displayed is :"+Display);
		Assert.assertEquals(false,Display);

	}
	public void validatetableheader(String string) {
		Assert.assertEquals(tableheadercntrctqnty.getText(),string);

	}
	public void validatelabelinaddandeditscreen(String string) {

		Assert.assertEquals(cntrctqntylabeladd.getText(),string);

	}
	public void editProductclickCTC() throws InterruptedException {
		editproductlinkCTC.click();
		Thread.sleep(2000);

	}
	public void editProductclickLMS() throws InterruptedException {
		editproductlinkLMS.click();
		Thread.sleep(2000);

	}
	public void verifypurchasehistory(String string,String string2) throws InterruptedException {
		purchasehistorylink.click();
		Thread.sleep(2000);
		Assert.assertEquals(headercntrctqntychange.getText(),string);
		Assert.assertEquals(headertotalcntrctqnty.getText(),string2);
	}
	public void validatelabelinaddandeditscreen1(String string) {
		Assert.assertEquals(cntrctqntylabeledit.getText(),string);

	}
	public void startdatetocurrentdate() {
		LMSstartdateinput.click();
		String currentdate=LMSsettocurrentdate.getText();
		System.out.println(currentdate);

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd");
		LocalDateTime now = LocalDateTime.now();
		System.out.println(dtf.format(now));
		Assert.assertEquals(dtf.format(now),currentdate);
		LMSsettocurrentdate.click();
	}
	public void startdatesettoselecteddate(String string) {
		LMSstartdateinput.click();
		String setdate=LMSsettocurrentdate.getText();
		System.out.println(setdate);
		Assert.assertEquals(setdate,string);

	}


	public void editProductandChangeIntoUnlimted(String type, String name) {
		if (courseListName.containsKey(name))
			name = courseListName.get(name).toString();

		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while (!(pageValue.equalsIgnoreCase("complete"))) {
				Thread.sleep(5000);
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(5000);
			name = name.replace("Â", "");

			productType = type;
			productName = name;

			// retakeyes2.click();
			// wait.until(ExpectedConditions.visibilityOf(retakeDuration));
			// Select retakeDur = new Select(retakeDuration);
			// retakeDuration.click();
			// Thread.sleep(3000);

			// retakeDur.selectByValue("1");
			Thread.sleep(3000);

			wait.until(ExpectedConditions.visibilityOf(CourseScorePercentage));
			CourseScorePercentage.click();
			wait.until(ExpectedConditions.visibilityOf(partofCourse));
			partofCourse.click();

			// wait.until(ExpectedConditions.visibilityOf(PassedStatus));

			// PassedStatus.click();

			wait.until(ExpectedConditions.visibilityOf(findTrainingCenterWidget));
			findTrainingCenterWidget.click();
			try {
				Product.click();
				Assert.fail("Product should be disable");
			} catch (Exception e) {

			}

			Thread.sleep(7000);
			//

			LocalDateTime myDateObj = LocalDateTime.now().plusDays(Integer.parseInt("2"));
			System.out.println("Before formatting: " + myDateObj);
			DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd");

			String formattedStartDate = myDateObj.format(myFormatObj);

			startDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
			WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
			reqDate.click();

			if (type.equalsIgnoreCase("manual")) {
				quantity.clear();
				;

				unlimited.click();

			} else if (type.equalsIgnoreCase("automatic")) {

				try {
					unlimited.click();
					Assert.fail("Product Type should be disable");
				} catch (Exception e) {

				}
			}

			Thread.sleep(3000);

			addProduct.click();

		} catch (org.openqa.selenium.StaleElementReferenceException ex) {
			editProductandChangeIntoUnlimted(type,name);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}

	public String getProductSubscription() {
		return ProductSubScriptionUnlimitedToLimited.getText();
	}

	
	public void VerifyclickonUnlimitedtolimited() {
//		wait.until(ExpectedConditions.visibilityOf(verifyiflimite));
		
	System.err.println(	wait.until(ExpectedConditions.invisibilityOf(verifyiflimite)));
		
	}


	
	public void ActivateProfile() {

	}

	public List<WebElement> GetAllElements() {
		return Table_headers;

	}

	/*
	 * public void ClickOnElement() { driver. }
	 * 
	 * public void SelectFromTheList(String value, List<WebElement> GetAllElements)
	 * { if(GetAllElements.contains(value)) { driver. } }
	 */

	public void SelectFromTable(String value) {
		// testutils.SelectTheElementFromTable(Table_headers,value);
		SelectTheElementFromTable(Table_headers, value);
	}

	public void SelectTheElementFromTable(List<WebElement> listvalue, String value) {
		boolean flag = false;
		for (int i = 0; i < listvalue.size(); i++) {
			if (listvalue.get(i).getText().equals(value.toUpperCase())) {
				listvalue.get(i).click();
				String quantity = listvalue.get(i).getText();
				System.out.println(" The clicked element : " + listvalue.get(i).getText());
				//System.out.println(" The clicked element" + quantity);
				Assert.assertEquals(quantity, value.toUpperCase());
				flag =true;
				break;
			}
		}
		Assert.assertTrue(flag);
	}

	public void getValueFromColumn(String cellValueToCompare, int ColumntoIterate, int ToGetvalueFromcolumn, String contractQuantity) {
		
		if(courseListName.containsKey(cellValueToCompare+"Option"))
			cellValueToCompare=courseListName.get(cellValueToCompare+"Option").toString();
	
		String value = testutils.SelectTheValueFromTheTable(RowCount, cellValueToCompare, ColumntoIterate,
				ToGetvalueFromcolumn);
		Assert.assertEquals(value, contractQuantity);
	}

	
	
	public void selectvalueFromActions(String cellValueToCompare, int ColumntoIterate, int ToGetvalueFromcolumn, int selectActionsFromColumns) {
	
		if(courseListName.containsKey(cellValueToCompare+"Option"))
			cellValueToCompare=courseListName.get(cellValueToCompare+"Option").toString();
		
		testutils.SelectActionsForProduct(RowCount, cellValueToCompare, ColumntoIterate,
				ToGetvalueFromcolumn, selectActionsFromColumns);
	}
	
	
	public void ClickOnBlockButton() {
		wait.until(ExpectedConditions.elementToBeClickable(Button_YesBlock));
		Button_YesBlock.click();
	}
	
	public String getAlertMessage() {
		wait.until(ExpectedConditions.visibilityOf(Alert_ProductSubscription));
		return Alert_ProductSubscription.getText();
	}
	
	public void ActionColumn(String expectedvalue) {
		ClickOnBlockButton();
		String value = getAlertMessage();
		Assert.assertEquals(value, expectedvalue);
	}
	
	public void editMultiScromProductByName(String name)
	{
		try {
			if(courseListName.containsKey(name+"Option"))
				name=courseListName.get(name+"Option").toString();
	
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(editProductButton));
			List<WebElement> list = driver.findElements(By.xpath(productListTable));
			for(int i=1; i<= list.size(); i++)
			{
				name = name.replaceAll("registered", "\u00AE");
				String text = driver.findElement(By.xpath("(" + productListTable + ")[" + i + "]")).getText();
				if(name.trim().toLowerCase().contains(text.trim().toLowerCase()))
				{
					JavascriptExecutor js = (JavascriptExecutor)driver;
					System.out.println(editMultiProduct.toString());
					WebElement productEdit = driver.findElement(By.xpath("(" + editMultiProduct.toString() + ")[" + i + "]"));
					js.executeScript("arguments[0].click();", productEdit);
					break;
				}
			}		
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOf(multiScromRecurrenceType));
			multiScromRecurrenceType.click(); 				// This is a change in UI
			addProduct.click();
		}
		catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}
	
	public boolean validateProductAvailability(String name)
    {
        boolean flag = false;
            int lastPositionPage = Integer.parseInt(productListResult.getText().split(" to ")[1].split(" of ")[0]);
            int totalPositrionPage = Integer.parseInt(productListResult.getText().split(" to ")[1].split(" of ")[1].split(" ")[0]);
            List<WebElement> list = driver.findElements(By.xpath(productLcodeTable));
            name = name.replaceAll("registered", "\u00AE");
            String courseCode = name.split("\\(")[1];
            courseCode = courseCode.substring(0, courseCode.length() - 1);
            for(int i=1; i<= list.size(); i++)
            {
                String text = driver.findElement(By.xpath("(" + productLcodeTable + ")[" + i + "]")).getText();
                if(courseCode.trim().toLowerCase().equals(text.trim().toLowerCase()))
                { 
                    flag= true;
                    break;
                }
            }
            if(lastPositionPage < totalPositrionPage  && flag == false) {
                productListNextPage.click();
                flag = validateProductAvailability(name);
            }
        return flag;
    }

	public void enterProductDetailsByNameWithStudentPurchase(String type, String name, String Subscriptions)
    {
        try 
        {
            JavascriptExecutor js = (JavascriptExecutor)driver;
            String pageValue = js.executeScript("return document.readyState").toString();
            int counter = 0;
            while(!(pageValue.equalsIgnoreCase("complete")))
            {
                pageValue = js.executeScript("return document.readyState").toString();
                Thread.sleep(5000);
                counter++;
                if(counter>12)
                    Assert.fail("Not able to load product after waiting for 1 minute");
            }
            Organization.click();
            name = name.replaceAll("registered", "\u00AE");
            Thread.sleep(3000);
            productType = type;    
            productName = name;
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.visibilityOf(productDropdown));
        Thread.sleep(5000);
        //js.executeScript("arguments[0].click();", productDropdown);
        productDropdown.click();    
        wait.until(ExpectedConditions.visibilityOf(productSearch));
        productSearch.click();
        System.out.println(name);
        productSearch.sendKeys(name);
        //Thread.sleep(5000);
        List<WebElement> options = driver.findElements(By.xpath(productSearchResult));
        counter = 0;
        while(!(options.size() == 2))
        {
            options = driver.findElements(By.xpath(productSearchResult));
            Thread.sleep(5000);
            counter++;
            if(counter>12)
                Assert.fail("Not able to search product after waiting for 1 minute");
        }
        for(int i = 1; i <= options.size(); i++)
        {
            String element = "(" + productSearchResult + ")[" + i + "]";
            String value = driver.findElement(By.xpath(element)).getText();
            if(value.toLowerCase().trim().equalsIgnoreCase(name.toLowerCase().trim()))
            {
                Thread.sleep(2000);
                driver.findElement(By.xpath(element)).click();
                break;
            }
        }

 

        DateFormat dateFormat = new SimpleDateFormat("dd");
        Date date = new Date();
        String formattedStartDate = dateFormat.format(date);
        startDate.click();
        wait.until(ExpectedConditions.visibilityOf(calendarProduct));
        String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
        WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
        reqDate.click();
        Thread.sleep(3000);
        if(!subscriptionDropdown.isDisplayed()) {
            js.executeScript("arguments[0].click();", payment_type_Org);
            if(productName.contains("Entry") || productName.contains("Ready") || productName.contains("Prep")) {
            SubscriptionPlan.click();
            for(int j=0;j<Subscriptions.length();j++)
            {
                Thread.sleep(1000);                
                SubscriptionPlanSearch.sendKeys( String.valueOf(Subscriptions.charAt(j)));
            }
            Thread.sleep(3000);            
            driver.findElement(By.xpath("//input[contains(@title,'"+Subscriptions+"')]")).click();
            }
        }
        Thread.sleep(3000);    
        addProduct.click();
    }
        catch(org.openqa.selenium.StaleElementReferenceException ex)
        {
            System.out.println(ex.getMessage());
            enterProductDetailsByName(productType, productName);
        } catch (Exception e) 
        {
            e.printStackTrace();
            Assert.fail("Error");
        }
    }

	public void getProductCodeByName(String name)
	{
		try {
			if(courseListName.containsKey(name+"Option"))
				name=courseListName.get(name+"Option").toString();
	
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(editProductButton));
			List<WebElement> list = driver.findElements(By.xpath(productListTable));
			for(int i=1; i<= list.size(); i++)
			{
				name = name.replaceAll("registered", "\u00AE");
				String text = driver.findElement(By.xpath("(" + productListTable + ")[" + i + "]")).getText();
				if(name.trim().toLowerCase().contains(text.trim().toLowerCase()))
				{
					productCode = driver.findElement(By.xpath(productListCode)).getText();
					break;
				}
			}		
			Thread.sleep(5000);
		}
		catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}
	
	/*
	 * public void SelectFromTable(List<WebElement> listvalue, String value ) {
	 * for(int i=0; i<listvalue.size(); i++) {
	 * if(listvalue.get(i).toString().equals(value)) { listvalue.get(i).click();
	 * 
	 * System.out.println(" The clicked element"+listvalue.get(i)); } }
	 * 
	 * }
	 */
	
	public boolean validateProductAvailabilityWithBothPayType(String name)
    {
        boolean flag = false;
            int lastPositionPage = Integer.parseInt(productListResult.getText().split(" to ")[1].split(" of ")[0]);
            int totalPositrionPage = Integer.parseInt(productListResult.getText().split(" to ")[1].split(" of ")[1].split(" ")[0]);
            List<WebElement> list = driver.findElements(By.xpath(productLcodeTable));
            name = name.replaceAll("registered", "\u00AE");
            String courseCode = name.split("\\(")[1];
            courseCode = courseCode.substring(0, courseCode.length() - 1);
            for(int i=1; i<= list.size(); i++)
            {
                String text = driver.findElement(By.xpath("(" + productLcodeTable + ")[" + i + "]")).getText();
                String type = driver.findElement(By.xpath("(" + productPaymentModeTable + ")[" + i + "]")).getText();
                if(courseCode.trim().toLowerCase().equals(text.trim().toLowerCase()) &&
                		type.equalsIgnoreCase("Organization, Student"))
                { 
                    flag= true;
                    break;
                }
            }
            if(lastPositionPage < totalPositrionPage  && flag == false) {
                productListNextPage.click();
                flag = validateProductAvailabilityWithBothPayType(name);
            }
        return flag;
    }
	
	public void enterProductDetailsByNameWithBothPurchase(String type, String name, String Subscriptions)
    {
        try 
        {
            JavascriptExecutor js = (JavascriptExecutor)driver;
            String pageValue = js.executeScript("return document.readyState").toString();
            int counter = 0;
            while(!(pageValue.equalsIgnoreCase("complete")))
            {
                pageValue = js.executeScript("return document.readyState").toString();
                Thread.sleep(5000);
                counter++;
                if(counter>12)
                    Assert.fail("Not able to load product after waiting for 1 minute");
            }
            Organization.click();
            name = name.replaceAll("registered", "\u00AE");
            Thread.sleep(3000);
            productType = type;    
            productName = name;
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.visibilityOf(productDropdown));
        Thread.sleep(5000);
        //js.executeScript("arguments[0].click();", productDropdown);
        productDropdown.click();    
        wait.until(ExpectedConditions.visibilityOf(productSearch));
        productSearch.click();
        System.out.println(name);
        productSearch.sendKeys(name);
        //Thread.sleep(5000);
        List<WebElement> options = driver.findElements(By.xpath(productSearchResult));
        counter = 0;
        while(!(options.size() == 2))
        {
            options = driver.findElements(By.xpath(productSearchResult));
            Thread.sleep(5000);
            counter++;
            if(counter>12)
                Assert.fail("Not able to search product after waiting for 1 minute");
        }
        for(int i = 1; i <= options.size(); i++)
        {
            String element = "(" + productSearchResult + ")[" + i + "]";
            String value = driver.findElement(By.xpath(element)).getText();
            if(value.toLowerCase().trim().equalsIgnoreCase(name.toLowerCase().trim()))
            {
                Thread.sleep(2000);
                driver.findElement(By.xpath(element)).click();
                break;
            }
        }
        DateFormat dateFormat = new SimpleDateFormat("dd");
        Date date = new Date();
        String formattedStartDate = dateFormat.format(date);
        startDate.click();
        wait.until(ExpectedConditions.visibilityOf(calendarProduct));
        String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
        WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + x));
        reqDate.click();
        Thread.sleep(3000);
        if(!quantity.isDisplayed())
			js.executeScript("arguments[0].click();", payment_type_Org);
		if(type.equalsIgnoreCase("manual"))
		{
			quantity.sendKeys("1");
		}
		else if(type.equalsIgnoreCase("automatic"))
		{
			
			unlimited.click();
		}
		else
		{
			quantity.sendKeys("1");
		}
		Thread.sleep(3000);        
        if(!subscriptionDropdown.isDisplayed()) {
            js.executeScript("arguments[0].click();", payment_type_Org);
            if(productName.contains("Entry") || productName.contains("Ready") || productName.contains("Prep")) {
            SubscriptionPlan.click();
            for(int j=0;j<Subscriptions.length();j++)
            {
                Thread.sleep(1000);                
                SubscriptionPlanSearch.sendKeys( String.valueOf(Subscriptions.charAt(j)));
            }
            Thread.sleep(3000);            
            driver.findElement(By.xpath("//input[contains(@title,'"+Subscriptions+"')]")).click();
            }
        }
        Thread.sleep(3000);    
        addProduct.click();
    }
        catch(org.openqa.selenium.StaleElementReferenceException ex)
        {
            System.out.println(ex.getMessage());
            enterProductDetailsByName(productType, productName);
        } catch (Exception e) 
        {
            e.printStackTrace();
            Assert.fail("Error");
        }
    }

	public String getProductAvailablePaymentType(String name)
    {
			String payment_Type = "";
            List<WebElement> list = driver.findElements(By.xpath(productLcodeTable));
            name = name.replaceAll("registered", "\u00AE");
            String courseCode = name.split("\\(")[1];
            courseCode = courseCode.substring(0, courseCode.length() - 1);
            for(int i=1; i<= list.size(); i++)
            {
                String text = driver.findElement(By.xpath("(" + productLcodeTable + ")[" + i + "]")).getText();
                String type = driver.findElement(By.xpath("(" + productPaymentModeTable + ")[" + i + "]")).getText();
                if(courseCode.trim().toLowerCase().equals(text.trim().toLowerCase()))
                { 
                	payment_Type = type;
                    break;
                }
            }           
        return payment_Type;
    }

	public void editProduct_Add_StudentPay(String name,String Subscriptions) {
		 try 
	        {
	            JavascriptExecutor js = (JavascriptExecutor)driver;
	            String pageValue = js.executeScript("return document.readyState").toString();
	            int counter = 0;
	            while(!(pageValue.equalsIgnoreCase("complete")))
	            {
	                pageValue = js.executeScript("return document.readyState").toString();
	                Thread.sleep(5000);
	                counter++;
	                if(counter>12)
	                    Assert.fail("Not able to load product after waiting for 1 minute");
	            }
			Thread.sleep(3000);    
			productName = name;
	        if(!subscriptionDropdown.isDisplayed()) {
	            js.executeScript("arguments[0].click();", payment_type_Org);
	            if(productName.contains("Entry") || productName.contains("Ready") || productName.contains("Prep")) {
	            SubscriptionPlan.click();
	            for(int j=0;j<Subscriptions.length();j++)
	            {
	                Thread.sleep(1000);                
	                SubscriptionPlanSearch.sendKeys( String.valueOf(Subscriptions.charAt(j)));
	            }
	            Thread.sleep(3000);            
	            driver.findElement(By.xpath("//input[contains(@title,'"+Subscriptions+"')]")).click();
	            }
	        }
	        Thread.sleep(3000);    
	        addProduct.click();
	    }
	    catch (Exception e) 
	        {
	            e.printStackTrace();
	            Assert.fail("Error");
	        }
	}

	public void editProduct_Add_OrgPay(String type) {
		 try 
	        {
	            JavascriptExecutor js = (JavascriptExecutor)driver;
	            String pageValue = js.executeScript("return document.readyState").toString();
	            int counter = 0;
	            while(!(pageValue.equalsIgnoreCase("complete")))
	            {
	                pageValue = js.executeScript("return document.readyState").toString();
	                Thread.sleep(5000);
	                counter++;
	                if(counter>12)
	                    Assert.fail("Not able to load product after waiting for 1 minute");
	            }
	            Organization.click();
	            Thread.sleep(3000);  
	        if(!quantity.isDisplayed())
				js.executeScript("arguments[0].click();", payment_type_Org);
			if(type.equalsIgnoreCase("manual"))
			{
				quantity.sendKeys("1");
			}
			else if(type.equalsIgnoreCase("automatic"))
			{
				
				unlimited.click();
			}
			else
			{
				quantity.sendKeys("1");
			}   
	        Thread.sleep(3000);    
	        addProduct.click();
	    }
	    catch (Exception e) 
	        {
	            e.printStackTrace();
	            Assert.fail("Error");
	        }
	}




	public void getlistoffproduct()
	{
		try 
		{

			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(productTable));
//			wait.until(ExpectedConditions.visibilityOf(studentManageTable));
			int count=0;
			while(productTable.getText().contains("Processing"))
			{
				if(count>=pagload)
					break;
				Thread.sleep(100);
				count++;
			}

			try
			{
				productTable.findElements(By.xpath(".//tbody//tr")).get(0);
			}
			catch(Exception e)
			{
				reuse.waitforsec(4);
			}
			
			
			
			List<WebElement> page=driver.findElements(By.xpath("//div[@id='customer-admin-list_paginate']//span//a"));;
			
			int productLenght=0;
			for(int j=0;j<page.size();j++)			
			{
				page.get(j).click();
				reuse.waitforsec(4);
				List<WebElement> row=productTable.findElements(By.xpath(".//tbody//tr"));

			for(int i=0;i<row.size();i++)
			{
				
			String productCode=row.get(i).findElements(By.xpath(".//td")).get(0).getText();
			String productName=row.get(i).findElements(By.xpath(".//td")).get(1).getText();
			String productContractQuantity=row.get(i).findElements(By.xpath(".//td")).get(3).getText();
			String productStatus=row.get(i).findElements(By.xpath(".//td")).get(4).getText();
			
			if(productStatus.contains("Blocked"))
			{
				dataMap.put(OrganizationHome.exceptionid+"BlockedproductName",productName)  ;	
			}
			else
			{
			productLenght++;
			dataMap.put(OrganizationHome.exceptionid+"product"+i+"productCode",productCode)  ;
	 		dataMap.put(OrganizationHome.exceptionid+"product"+i+"productName",productName)  ;
	 		dataMap.put(OrganizationHome.exceptionid+"product"+i+"productContractQuantity",productContractQuantity)  ;
	 		dataMap.put(OrganizationHome.exceptionid+"product"+i+"productStatus",productStatus)  ;
			}
	 		
	 		
	 		
			}
			
			}
			
			dataMap.put(OrganizationHome.exceptionid+"productCount",String.valueOf(productLenght))  ;
			
			System.out.println(dataMap.keySet().toString());
			System.out.println(dataMap.values().toString());
						

		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}

	}
	
}
