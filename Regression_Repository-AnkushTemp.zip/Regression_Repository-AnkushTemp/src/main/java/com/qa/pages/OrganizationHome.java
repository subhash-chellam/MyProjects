package com.qa.pages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.python.antlr.PythonParser.assert_stmt_return;
import org.python.icu.text.SimpleDateFormat;

import com.qa.util.TestBase;

public class OrganizationHome extends TestBase
{
	
	OrganizationHome orgHome;
		
	@FindBy(xpath = "//a[text()='Create Organization']")
	WebElement orgCreate;
	
	@FindBy(xpath = "//input[@name = 'orgname']")
	WebElement txtOrgName;
	
	@FindBy(xpath = "(//table[@aria-describedby = 'tablelisting_info']//td[2])[1]")
	WebElement resultOrgName;
	
	@FindBy(xpath = "//*[@id='customerList']//div[3]//button/span[1]")
	WebElement OrgTyp;
	
	@FindBy(xpath = "//*[@id='customerList']//div[4]//button/span[1]")
	WebElement OrgSttus;
	
	
	
	

	
	@FindBy(xpath = "//input[@name = 'org_id']")
	WebElement txtOrgID;
	
	@FindBy(xpath = "(//table[@aria-describedby = 'tablelisting_info']//td[1])[1]")
	WebElement resultOrgID;
	
	@FindBy(xpath = "//button[@id = 'search']")
	WebElement orgSearch;
	
	@FindBy(xpath = "//body[@class]")
	WebElement pageLoad;
	
	@FindBy(xpath = "//a[text() = 'Clear Search']")
	WebElement clearSearch;
	
	@FindBy(xpath = "(//table[@aria-describedby = 'tablelisting_info']//a[@data-toggle='dropdown'])[1]")
	WebElement actionDropdown;
	
	@FindBy(xpath = "(//table[@aria-describedby = 'tablelisting_info']//a[text()=\"Organization Details\"])[1]")
	WebElement orgDetails;
	
	@FindBy(xpath = "(//table[@aria-describedby = 'tablelisting_info']//a[text()=\"Block\"])[1]")
	WebElement orgBlock;
	
	@FindBy(xpath = "(//table[@aria-describedby = 'tablelisting_info']//a[text()=\"unblock\"])[1]")
	WebElement orgUnBlock;
	
	
	
	@FindBy(xpath = "(//table[@aria-describedby = 'tablelisting_info']//a[text()='Delete'])[1]")
	WebElement orgDelete;
					
	@FindBy(xpath = "//textarea[@name = 'reason']")
	WebElement blockReason;
	
	@FindBy(xpath = "//button[text() = 'Yes']")
	WebElement buttonYes;
	
	@FindBy(xpath = "(//table[@aria-describedby = 'tablelisting_info']//a[text() = 'Access Organization'])[1]")
	WebElement orgAccess;
	
	@FindBy(xpath = "(//table[@aria-describedby = 'tablelisting_info']//li//a[text()='Integrations '])[1]")
	WebElement orgSFTP;
	
	@FindBy(xpath = "//div[contains(@class,'alert-success')]")
	WebElement verifyOrg;
	
	@FindBy(xpath = "//div[contains(@class,'error-message')]")
	WebElement errormsg;
	
	@FindBy(xpath = "//div[contains(@class,'alert-dismissable')]")
	WebElement erormsg;
	
	
	@FindBy(xpath = "(//*[@class = 'close'])[1]")
	WebElement successCloseButton;
	
	@FindBy(xpath = "//button[@title = 'Select Org Type']")
	WebElement orgType;
	
	@FindBy(xpath = "//span[text() = 'Customer Training Center']")
	WebElement typeCTC;
	
	@FindBy(xpath = "//tr[1]//td[text() = 'Customer Training Center']")
	WebElement searchResultCTC;
	
	@FindBy(xpath = "//button[@name = 'exportcsv']")
	WebElement exportCSVButton;
	
	@FindBy(xpath = "//button[@name = 'exportexcel']")
	WebElement exportExcelButton;
	
	@FindBy(xpath = "//a[text() = 'HLC Migration']")
	WebElement hlcLink;
	
	@FindBy(xpath = "//table[@id = 'tablelisting']/tbody/tr[1]")
	WebElement orgList;
	
	@FindBy(xpath = "//div[text() = 'Showing 1 to 1 of 1 entries']")
	WebElement searchedOrgList;
	@FindBy(xpath="//*[@id=\"customerform\"]//small[text()='Email already exists.']")
	WebElement existEmail;
	
	@FindBy(xpath="(//a[@title='Download Source File'])[1]")
	WebElement DownloadSourceFile;
	
	@FindBy(xpath="//a[text() = 'Migration Logs']")
	WebElement MigrationLogs;
	
	@FindBy(xpath="(//a[@title='Download Error Log File'])[1]")
	WebElement DownloadErrorFile;
	
	Students std;
	String val;
	String filepath = System.getProperty("user.dir") +"\\src\\test\\java\\resources\\SetOrganizationName.txt";
	String keyclockFile = System.getProperty("user.dir") +"\\src\\test\\java\\resources\\KeyClockOrg"+prop.get("environment")+".txt";
	JavascriptExecutor js ;
	String filepth = System.getProperty("user.dir") +"\\src\\test\\java\\resources\\OrgId.txt";

	static public String contextId,contextLabel,contextTitle,exceptionorg=null,exceptionid=null;
	//Initialize Page objects
	public OrganizationHome()
	{
		PageFactory.initElements(driver, this);
		
	
		js= (JavascriptExecutor)driver;
		
      
	}
	
	public void clickCreateOrganisation()
	{
//		
//		wait.until(ExpectedConditions.visibilityOf(orgCreate));
//		orgCreate.click();
		
		js.executeScript("arguments[0].click();", orgCreate);
	}
	
	public void searchOrgByName()
	{
		 System.out.println(driver.getCurrentUrl());
		
		
		wait.until(ExpectedConditions.visibilityOf(resultOrgName));
		String orgName = TestBase.prop.getProperty("orgName");
		if(orgName.isEmpty())
		{
			orgName = resultOrgName.getText();
			System.out.println(orgName);
			
			TestBase.prop.setProperty("orgName", orgName);
		}
		//wait.until(ExpectedConditions.visibilityOf(txtOrgName));
		js.executeScript("arguments[0].click();", txtOrgName);
		//txtOrgName.click();
		txtOrgName.clear();
		txtOrgName.sendKeys(orgName);
		js.executeScript("arguments[0].click();", orgSearch);
		//orgSearch.click();
		JavascriptExecutor js = (JavascriptExecutor)driver;
		String pageValue = js.executeScript("return document.readyState").toString();
		int m=0;
		while(!(pageValue.equalsIgnoreCase("complete")))
		{
			pageValue = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			m++;
		}
		wait.until(ExpectedConditions.visibilityOf(searchedOrgList));
		String searchResult = resultOrgName.getText();
		Assert.assertEquals(orgName, searchResult);		
		
		exceptionorg=resultOrgName.getText();
		exceptionid=resultOrgID.getText();
		contextId=resultOrgID.getText();
		contextLabel=resultOrgName.getText();
		contextTitle=resultOrgName.getText();
			
	}
	
	public void checkfieldareBlank()
	{
		Assert.assertEquals(txtOrgName.getText(), "");
		Assert.assertEquals(txtOrgID.getText(), "");
		Assert.assertEquals(OrgTyp.getText(), "Select Org Type");
		
		Assert.assertEquals(OrgSttus.getText(), "Select Org Status");
		
		
	}
	public void clearOrgSearch()
	{
		wait.until(ExpectedConditions.visibilityOf(clearSearch));
		clearSearch.click();
	}

	public void searchOrgByID()
	{	
		wait.until(ExpectedConditions.visibilityOf(resultOrgID));
		String orgID = resultOrgID.getText();
		txtOrgID.sendKeys(orgID);
		orgSearch.click();
		wait.until(ExpectedConditions.visibilityOf(searchedOrgList));
		String searchResult = resultOrgID.getText();
		Assert.assertEquals(orgID, searchResult);
	}

	public void seachOrgByTypeCTC()
	{
		wait.until(ExpectedConditions.visibilityOf(orgType));
		orgType.click();
		wait.until(ExpectedConditions.visibilityOf(typeCTC));
		typeCTC.click();
		orgSearch.click();
		wait.until(ExpectedConditions.visibilityOf(searchResultCTC));
		
	}
	
	public void openOrgDetails()
	{
		try
		{
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOf(actionDropdown));
			actionDropdown.click();
		
		wait.until(ExpectedConditions.visibilityOf(orgDetails));
		orgDetails.click();
		}
		catch(Exception e)
		{	wait.until(ExpectedConditions.visibilityOf(actionDropdown));
		actionDropdown.click();
		
			wait.until(ExpectedConditions.visibilityOf(orgDetails));
			orgDetails.click();

		}
		
	}

	public void blockOrganization(String reason)
	{
		wait.until(ExpectedConditions.visibilityOf(actionDropdown));
		actionDropdown.click();
		if(orgBlock.isDisplayed())
		{
			wait.until(ExpectedConditions.visibilityOf(orgBlock));
			orgBlock.click();
			wait.until(ExpectedConditions.visibilityOf(blockReason));
			blockReason.sendKeys(reason);
			buttonYes.click();
			validateSucessMesssage();
		}		
	}
	
	public void blockOrganization(String reason,String msg)
	{
		wait.until(ExpectedConditions.visibilityOf(actionDropdown));
		actionDropdown.click();
		if(orgBlock.isDisplayed())
		{
			wait.until(ExpectedConditions.visibilityOf(orgBlock));
			orgBlock.click();
			wait.until(ExpectedConditions.visibilityOf(blockReason));
			blockReason.sendKeys(reason);
			buttonYes.click();
			validateSucessMesssage(msg);
		}		
	}
	
	public void deleteOrganization(String msg)
	{
		wait.until(ExpectedConditions.visibilityOf(actionDropdown));
		actionDropdown.click();
		if(orgDelete.isDisplayed())
		{
			wait.until(ExpectedConditions.visibilityOf(orgDelete));
			
			orgDelete.click();
			wait.until(ExpectedConditions.visibilityOf(buttonYes));
			
			buttonYes.click();
			validateSucessMesssage(msg);
		}		
	}
	public void successmsg(String msg)
	{
		try
		{
			System.out.println(verifyOrg.getText());
			System.out.println(msg);
		Assert.assertEquals(verifyOrg.getText().contains(msg),true);
	
		}
		catch(Exception e)
		{
			wait.until(ExpectedConditions.visibilityOf(verifyOrg));
			System.out.println(verifyOrg.getText());
			System.out.println(msg);
			Assert.assertEquals(verifyOrg.getText().contains(msg),true);
			
		}
	}
	public void errmsg(String msg)
	{
		System.out.println(erormsg.getText());
		Assert.assertEquals(erormsg.getText().contains(msg),true);
	}
	
	
	public void errormsg(String msg)
	{
		try
		{
		Thread.sleep(15000);	
		Assert.assertEquals(driver.findElement(By.xpath("//*[contains(text(),'"+msg+"')]")).getText().contains(msg),true);

		}
		catch(NoSuchElementException | InterruptedException e)
		{
			Assert.fail("Error message not found "+msg);
		}
		}
	public void UnblockOrganization(String reason)
	{
		wait.until(ExpectedConditions.visibilityOf(actionDropdown));
		actionDropdown.click();
		if(orgUnBlock.isDisplayed())
		{
			wait.until(ExpectedConditions.visibilityOf(orgUnBlock));
			orgUnBlock.click();
			wait.until(ExpectedConditions.visibilityOf(blockReason));
			blockReason.sendKeys(reason);
			buttonYes.click();
			validateSucessMesssage();
		}
		
	}

	public void UnblockOrganization(String reason,String msg)
	{
		wait.until(ExpectedConditions.visibilityOf(actionDropdown));
		actionDropdown.click();
		if(orgUnBlock.isDisplayed())
		{
			wait.until(ExpectedConditions.visibilityOf(orgUnBlock));
			orgUnBlock.click();
			wait.until(ExpectedConditions.visibilityOf(blockReason));
			blockReason.sendKeys(reason);
			buttonYes.click();
			validateSucessMesssage(msg);
		}
		
	}

	public String clickAccessOrganisation()
	{
		String orgId = "";
		try
		{
		Thread.sleep(3000);
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(orgList));
		wait.until(ExpectedConditions.visibilityOf(actionDropdown));
		orgId = resultOrgID.getText();
		actionDropdown.click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOf(orgAccess));
		wait.until(ExpectedConditions.elementToBeClickable(orgAccess));
		orgAccess.click();
		System.out.println("Searched organisation is " + orgId);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
		return orgId;
	}
	
	public String clickSFTPSetting()
	{
		
		wait.until(ExpectedConditions.visibilityOf(actionDropdown));
		String orgId = resultOrgID.getText();
		actionDropdown.click();
		wait.until(ExpectedConditions.visibilityOf(orgSFTP));
		orgSFTP.click();
		return orgId;
	}
	
	
	public void validateexistMesssage()
	{
	try
	{
		wait.until(ExpectedConditions.visibilityOf(existEmail));
	}
	catch(Exception e)
	{
		Assert.fail("Email Exists");
	}
	}
	public void validateSucessMesssage()
	{
		
		try
		{
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		val = js.executeScript("return document.readyState").toString();
		int m=0;
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			m++;
		}
		wait.until(ExpectedConditions.visibilityOf(verifyOrg));
		System.out.println(verifyOrg.getText());
		wait.until(ExpectedConditions.visibilityOf(successCloseButton));
		successCloseButton.click();
		}
		catch(Exception e)
		{
			
			
		}
		
	}
	
	public void validateSucessMesssage(String msg)
	{
		if(AssignmentReport.checkifParmeterAvailable(msg))
			msg=AssignmentReport.getParmeterAvailable(msg);
        
		try
		{
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		System.out.println("Validate Message "+msg);
		wait.until(ExpectedConditions.visibilityOf(verifyOrg));
		System.out.println("Message in UI"+verifyOrg.getText());
		Assert.assertTrue(verifyOrg.getText().contains(msg));
		wait.until(ExpectedConditions.visibilityOf(successCloseButton));
		successCloseButton.click();
		}
		catch(Exception e)
		{
			
//			Assert.fail("Message not display "+msg);
		}
		
	}

	public void exportCSV()
	{
		try 
		{
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(exportCSVButton));
			wait.until(ExpectedConditions.elementToBeClickable(exportCSVButton));
			exportCSVButton.click();
		} 
		catch (Exception e) {
			
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	public void validateCSVFile()
	{
		std = new Students();
		int m=0;
		boolean dwnld = false;
		do 
		{
			dwnld = std.isFileDownloaded_Ext(Students.downloadPath, ".csv");
			m++;
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		while(dwnld == false);
		deleteFile();
	}
	public void validateCSVFile(String filename)
	{
		std = new Students();
		int m=0;
		boolean dwnld = false;
		do 
		{
			dwnld = std.isFileDownloaded_Ext(Students.downloadPath, ".csv");
			m++;
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		while(dwnld == false);
		
		Assert.assertTrue(std.fileName.contains(filename));
		Compliance comp =new Compliance();
		comp.validatExcelDetails();
		deleteFile();
	}
	
	public void exportExcel()
	{
		wait.until(ExpectedConditions.visibilityOf(exportExcelButton));
		exportExcelButton.click();
	}
	
	public void validateExcelFile()
	{
		std = new Students();
		int m=0;
		boolean dwnld = false;
		do 
		{
			dwnld = std.isFileDownloaded_Ext(Students.downloadPath, ".xls");
			m++;
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		while(dwnld == false);
		deleteFile();
	}
	
	public void deleteFile()
	{
		std.deleteFile(Students.filePath);
	}

	public void clickHLCMigration() 
	{
		wait.until(ExpectedConditions.visibilityOf(hlcLink));
		hlcLink.click();
	}

	public void searchChildOrg(String orgName)
	{
		try {
			wait.until(ExpectedConditions.visibilityOf(orgList));
			clearOrgSearch();
			System.out.println("Org Name is " + orgName);
			wait.until(ExpectedConditions.visibilityOf(txtOrgName));
			txtOrgName.sendKeys(orgName);
			orgSearch.click();
			wait.until(ExpectedConditions.visibilityOf(orgList));
			Thread.sleep(3000);
			String searchResult = resultOrgName.getText();
			Assert.assertEquals(orgName, searchResult);
		} 
		catch (Exception e) 
		{
			
		}
	}

	public void editOrgNameFile()
	{
		try 
		{
			
			FileWriter fw = new FileWriter(filepath,false);
			fw.write("Organization = " + TestBase.prop.getProperty("orgName"));
			fw.close();
		} 
		catch (Exception e) 
		{
			
		}
	}
	
	public boolean checkifOrgid(String Orgid)
	{
		try {
			 PropertiesConfiguration properties = new PropertiesConfiguration(System.getProperty("user.dir") +"\\src\\test\\java\\resources\\OrgId"+prop.get("environment")+".properties");
	       
			 
		 return properties.containsKey(Orgid);
		 
		 } catch (Exception e) {
			System.out.println("Exception: " + e);
		} finally {
		}
		return false;
	}
	
	public String getOrgid(String Orgid)
	{
		try {
			 PropertiesConfiguration properties = new PropertiesConfiguration(System.getProperty("user.dir") +"\\src\\test\\java\\resources\\OrgId"+prop.get("environment")+".properties");
	       
			 
		 return properties.getString(Orgid);
		 
		 } catch (Exception e) {
			System.out.println("Exception: " + e);
		} finally {
		}
		return null;
	}
	
	
	public void createOrid(String key,String id)
	{
		InputStream inputStream = null;
		
		try {
			 PropertiesConfiguration properties = new PropertiesConfiguration(System.getProperty("user.dir") +"\\src\\test\\java\\resources\\OrgId"+prop.get("environment")+".properties");
				properties.setProperty(key, id);
					
			// get the property value and print it out
			properties.save();
			
		} catch (Exception e) {
			System.out.println("Exception: " + e);
		} finally {
		}
//		try 
//		{
//			FileWriter fw = new FileWriter(filepath,false);
//			fw.write("Organization = " + TestBase.prop.getProperty("orgName"));
//			fw.close();
//			
//			
//		} 
//		catch (Exception e) 
//		{
//			
//		}
	}
	
	public String getTableValidation(String Orgid)
	{
		try {
			 PropertiesConfiguration properties = new PropertiesConfiguration(System.getProperty("user.dir") +"\\src\\test\\java\\resources\\TableValidation"+prop.get("environment")+".properties");
	       
			 
		 return properties.getString(Orgid);
		 
		 } catch (Exception e) {
			System.out.println("Exception: " + e);
		} finally {
		}
		return null;
	}
	
	
	
	public void setOrgNameFromFile()
	{
		try
		{
			FileReader FR = new FileReader(filepath);
			@SuppressWarnings("resource")
			BufferedReader BR = new BufferedReader(FR);
			String firstLine = BR.readLine();
			String lines[] = firstLine.split("=");
			TestBase.prop.setProperty("orgName", lines[1].trim());
			System.out.println(TestBase.prop.getProperty("orgName"));
		}
		catch(Exception e)
		{
			
		}
	}

	public void setOrgNameFromFileKeyclock()
	{
		try
		{
			FileReader FR = new FileReader(keyclockFile);
			@SuppressWarnings("resource")
			BufferedReader BR = new BufferedReader(FR);
			String firstLine = BR.readLine();
			String lines[] = firstLine.split("=");
			TestBase.prop.setProperty("orgName", lines[1].trim());
			System.out.println(TestBase.prop.getProperty("orgName"));
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void setLMSOrgNameFromFileKeyclock()
	{
		try
		{
			FileReader FR = new FileReader(keyclockFile);
			@SuppressWarnings("resource")
			BufferedReader BR = new BufferedReader(FR);
			String firstLine = BR.readLine();
			firstLine = BR.readLine();
			String lines[] = firstLine.split("=");
			TestBase.prop.setProperty("orgName", lines[1].trim());
			System.out.println(TestBase.prop.getProperty("orgName"));
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	public void setFedOrgNameFromFileKeyclock()
	{
		try
		{
			FileReader FR = new FileReader(keyclockFile);
			@SuppressWarnings("resource")
			BufferedReader BR = new BufferedReader(FR);
			String firstLine = BR.readLine();
			firstLine = BR.readLine();
			firstLine = BR.readLine();
			String lines[] = firstLine.split("=");
			TestBase.prop.setProperty("orgName", lines[1].trim());
			System.out.println(TestBase.prop.getProperty("orgName"));
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void setFedLMSOrgNameFromFileKeyclock()
	{
		try
		{
			FileReader FR = new FileReader(keyclockFile);
			@SuppressWarnings("resource")
			BufferedReader BR = new BufferedReader(FR);
			String firstLine = BR.readLine();
			firstLine = BR.readLine();
			firstLine = BR.readLine();
			firstLine = BR.readLine();
			String lines[] = firstLine.split("=");
			TestBase.prop.setProperty("orgName", lines[1].trim());
			System.out.println(TestBase.prop.getProperty("orgName"));
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	
	public void searchOrganisation(String name)
	{
		wait.until(ExpectedConditions.visibilityOf(txtOrgName));
		txtOrgName.sendKeys(name);
		orgSearch.click();
	}
	
	public void clickHLCMigrationLog() throws InterruptedException
	{
		wait.until(ExpectedConditions.visibilityOf(MigrationLogs));
		MigrationLogs.click();
		
		
		File filelocation=new File(System.getProperty("user.dir") +"\\src\\test\\java\\resources");
		File[] listoffiles=filelocation.listFiles();
		
		for (File file : listoffiles)
		if(file.getName().equals("hlctxtfile") && file.getName().equals("Error_log_hlctxtfile"))
		{
			file.delete();
		}
		
		wait.until(ExpectedConditions.visibilityOf(DownloadSourceFile));
		DownloadSourceFile.click();
		wait.until(ExpectedConditions.visibilityOf(DownloadErrorFile));
		DownloadErrorFile.click();
		
			
		Thread.sleep(5000);		
		
		for (File file : listoffiles) 
		{
			
			if(file.getName().equals("hlctxtfile") && file.getName().equals("Error_log_hlctxtfile"))
				System.out.println(" Files successfully downloaded");
			break;
		}
		
	}
	
	@FindBy(xpath="//div/h1[text()='Organizations']")
	WebElement Orgscreen;
	
	public void OrgScreen()
	{
		
		try {
			wait.until(ExpectedConditions.visibilityOf(Orgscreen));
			
			String orgtext = Orgscreen.getText();
			String Orgtitile=Orgscreen.getText();
			Assert.assertEquals(Orgtitile, orgtext);
		} 
		catch (Exception e) 
		{
			
		}
		
	}
	
	@FindBy(xpath = "//button[text()='Add Administrator']")
	WebElement AddAdmin;
	
	@FindBy(xpath = "//div[@class='form-group has-feedback has-error']")
	WebElement emailError;
	
	@FindBy(xpath = "//*[@id='email']")
	WebElement email;
	
	public void validateErrorForEmptyEmail()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(email));
		AddAdmin.click();
		wait.until(ExpectedConditions.visibilityOf(emailError));
		String message = emailError.getText();
		Assert.assertTrue(message.equals("The email id is required and can't be empty"));
	}
	
	public void validateorgDetails(String header,String data)
	{
		if(AssignmentReport.checkifParmeterAvailable(data))
			data=AssignmentReport.getParmeterAvailable(data);

		
		if(data.contains("orgname"))
		{
			data =TestBase.prop.getProperty("orgName");
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("	//div[contains(@class,'form-group')]//label[contains(text(),'"+header+"')]//parent::div//span[contains(text(),'"+data+"')]"))));
			System.out.println("Validate the Details "+data+" Actual:"+ driver.findElement(By.xpath("	//div[contains(@class,'form-group')]//label[contains(text(),'"+header+"')]//parent::div//span[contains(text(),'"+data+"')]")).getText());
			Assert.assertEquals( driver.findElement(By.xpath("	//div[contains(@class,'form-group')]//label[contains(text(),'"+header+"')]//parent::div//span[contains(text(),'"+data+"')]")).getText(),data);
					
		}
		else if (data.contains("ContactEmail"))
		{

			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("	//div[contains(@class,'form-group')]//label[contains(text(),'"+header+"')]//parent::div//span[contains(text(),'"+ OrganizationDetails. contactEmail+"')]"))));
			System.out.println("Validate the Details "+data+" Actual:"+ driver.findElement(By.xpath("	//div[contains(@class,'form-group')]//label[contains(text(),'"+header+"')]//parent::div//span[contains(text(),'"+OrganizationDetails. contactEmail+"')]")).getText());
		
			if(!driver.findElement(By.xpath("	//div[contains(@class,'form-group')]//label[contains(text(),'"+header+"')]//parent::div//span[contains(text(),'"+OrganizationDetails. contactEmail+"')]")).getText().contains("*"))
				Assert.assertEquals( driver.findElement(By.xpath("	//div[contains(@class,'form-group')]//label[contains(text(),'"+header+"')]//parent::div//span[contains(text(),'"+OrganizationDetails. contactEmail+"')]")).getText(),OrganizationDetails. contactEmail);
			else			
			Assert.assertEquals( driver.findElement(By.xpath("	(//div[contains(@class,'form-group')]//label[contains(text(),'"+header+"')]//parent::div//span[contains(text(),'"+OrganizationDetails. contactEmail+"')])[2]")).getText(),OrganizationDetails. contactEmail);
			
		}
		else 
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("	//div[contains(@class,'form-group')]//label[contains(text(),'"+header+"')]//parent::div//span[contains(text(),'"+data+"')]"))));
			System.out.println("Validate the Details "+data+" Actual:"+ driver.findElement(By.xpath("	//div[contains(@class,'form-group')]//label[contains(text(),'"+header+"')]//parent::div//span[contains(text(),'"+data+"')]")).getText());
			if(!driver.findElement(By.xpath("	//div[contains(@class,'form-group')]//label[contains(text(),'"+header+"')]//parent::div//span[contains(text(),'"+data+"')]")).getText().contains("*"))
				Assert.assertEquals( driver.findElement(By.xpath("	//div[contains(@class,'form-group')]//label[contains(text(),'"+header+"')]//parent::div//span[contains(text(),'"+data+"')]")).getText(),data);
			else			
			Assert.assertEquals( driver.findElement(By.xpath("	(//div[contains(@class,'form-group')]//label[contains(text(),'"+header+"')]//parent::div//span[contains(text(),'"+data+"')])[2]")).getText(),data);
				
		}
		
	}
	
	
	
}
