package com.qa.pages;

import java.io.File;
import java.io.FileReader;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.python.modules.thread.thread;

import com.opencsv.CSVReader;
import com.qa.util.TestBase;

public class ConsumptionReport extends TestBase {

	@FindBy(xpath = "//*[@id='from_start_date']")
	WebElement fromDate;
	
	@FindBy(xpath = "//*[@id='to_start_date']")
	WebElement toDate;
	@FindBy(xpath = "//*[@class = ' table-condensed']//th[@class = 'datepicker-switch']")
	WebElement datePickerSwitch;
	@FindBy(xpath = "//*[@id=\"ms-list-1\"]/button")
	WebElement SFID;  
	@FindBy(xpath = "//select[@id = 'products']//following-sibling::div/button")
	WebElement productNameFilter;
	@FindBy(xpath = "//p[text() = 'Please select the filters to view the report.']")
    WebElement labelSearch;
    
    @FindBy(xpath = "//span[@id = 'total_quantity']/ancestor::p")
    WebElement totalContractLabel;
    
    @FindBy(xpath = "//span[@id = 'total_consumption']/ancestor::p")
    WebElement totalConsumedLabel;
    
    @FindBy(xpath = "//body[@class]")
    WebElement pageLoad;
	
	@FindBy(xpath = "//select[@id = 'products']//following-sibling::div//a")
	WebElement selectAllFilter;
	
	@FindBy(xpath = "//button[@value= 'Search']")
	WebElement buttonSearch;
	
	@FindBy(xpath = "//select[@name = 'products[]']")
	WebElement productDropdownSelect;
	

	@FindBy(xpath = "//select[@name = 'orgIdSingle']")
	WebElement organizationDropdownSelect;
	
	@FindBy(xpath = "//select[@name = 'sfIdSingle']")
	WebElement salesForceDropdown;
	
	@FindBy(xpath = "//select[@id = 'orgLevel']")
	WebElement orgLevelDropdownSelect;

	@FindBy(xpath = "//*[@id=\"ms-list-1\"]/div/div/input")
	WebElement SFIDinput;
	
	@FindBy(xpath = "//*[@id=\"orgListDetails\"]//button")
	WebElement orgID;
	
	@FindBy(xpath = "//*[@id='orgListDetails']//input")
	WebElement orgIDinput;
	
	@FindBy(xpath = "//*[@id='consumption_report_length']/label/select")
	WebElement select;
	
	
	@FindBy(xpath = "//*[@id='product_list']//button")
	WebElement productName;
	
	@FindBy(xpath = "//*[@id='product_list']//div[@class=\"ms-search\"]//input")
	WebElement productNameinput;

	@FindBy(xpath = "//a[contains(text(), 'Reports')]")
	WebElement reportLink;
	
	
	@FindBy(xpath = "(//input[@placeholder = 'Search'])[1]")
	WebElement salesforceSearchBox;
	
	@FindBy(xpath = "(//a[text() = 'Select all'])[1]")
	WebElement salesforceSelectAll;
	@FindBy(xpath = "//h1[text() = 'Consumption Report']")
	WebElement consumptionReport;
	
	@FindBy(xpath = "//label[contains(text(),'SF ID')]//following-sibling::div/button[@title= 'Select SFID']/span[contains(@class,'filter')]")
    WebElement salesforceDropdown;

	@FindBy(xpath = "//span[text() = 'Select options']")
	WebElement organizationDropdown;
	
	@FindBy(xpath = "(//input[@placeholder = 'Search'])[2]")
	WebElement organizationSearchBox;

	@FindBy(xpath = "//span[text() = 'Select Product(s)']")
	WebElement productDropdown;
	
	@FindBy(xpath = "//*[@id=\"timesIconSearch\"]")
	WebElement searchbutton;


	@FindBy(xpath = "(//input[@placeholder = 'Search'])[3]")
	WebElement productSearchBox;
	
	@FindBy(xpath = "(//a[text() = 'Select all'])[1]")
	WebElement productSelectAll;
	
	
	@FindBy(xpath = "(//a[text() = 'Select all'])[1]")
	WebElement organizationSelectAll;

	@FindBy(xpath = "//a[contains(text(), 'Consumption Report')]")
	WebElement consumptionReportLink;
	
	@FindBy(xpath = "//*[@id=\"clear_search\"]")
	WebElement clear;
	@FindBy(xpath = "//*[@id=\"total_quantity\"]")
	WebElement total;
	
	@FindBy(xpath="//div[@id='consumption_report_length']//label")
	WebElement rowsperpageheader;
	@FindBy(xpath="(//div[@class=\"dataTables_info\"])[1]")
	WebElement Paginationinfoup;
	
	@FindBy(xpath = "//span[@id = 'total_quantity']")
	WebElement totalContractQuantity;
	
	@FindBy(xpath = "//span[@id = 'total_consumption']")
	WebElement totalConsumedQuantity;

	@FindBy(xpath = "//*[@id='consumption_report']//tr/td[@class='dataTables_empty']")
	WebElement norecord;
	 
	@FindBy(xpath = "//div[@class='dataTables_scroll']/div[1]/div/table/thead//th")
	List<WebElement> consumptionColumns;
	
	  
	@FindBy(xpath = "//div[@class = 'container-fluid']//h5")
	WebElement popupHeading;
	
	@FindBy(xpath = "//div[@class = 'container-fluid']/button")
	WebElement popupClose;
	
	@FindBy(xpath = "//*[@data-id='orgLevel']")
	WebElement orgLevel;
	
	@FindBy(xpath = "//div[@id = 'mainLevelFilter']//button")
	WebElement unitLevel;

	@FindBy(xpath = "//button[@id = 'exportbtn']")
	WebElement exportButton;
	String datePick = "//td[@class='day'  and text() = ";
	String datePickglobl = "//td[contains(@class, 'day' ) and text() = ";
	
	
	
	
	String tableRow = "//table[@id = 'customer-admin-list']/tbody/tr";
	public static String email;
	String SFIDa="//*[@id=\"ms-list-1\"]/div/a";
	String orgLevelNameList= "//*[@data-id='orgLevel']/following-sibling::div[@class= 'dropdown-menu open']/ul[@aria-expanded = 'true']/li";
	String unitLevelNameList= "//div[@id = 'mainLevelFilter']//button/following-sibling::div[@class= 'dropdown-menu open']/ul[@aria-expanded = 'true']/li";

	String orgIDa="//div[@id='orgListDetails']//div/a";
	String productNamea="//*[@id='product_list']//div/a";
	String reportTable = "//table[@id = 'consumption_report']//tbody/tr";
	String enableExportButton = "//button[@id = 'exportbtn' and not(contains(@class, 'disabled'))]";
	String downloadPath = System.getProperty("user.dir") + prop.getProperty("downloadPath");
	String result = "//div[@class = 'dataTables_info']";
    String pagination= "//div[@id = 'consumption_report_paginate']//span/a";
    String reportHeader = "//table[@aria-describedby='consumption_report_info' and not (@id)]//thead//th";
   public static int oldTotalCount, oldTotalConsumed;
	public static String filePath, fileName,checkproduct;
	String salesForceIdSearch = "(//span[text() = 'Select SFID']/parent::button)/following-sibling::div//ul[@class = 'dropdown-menu inner']//li";
	String val;
	String tableRows = "//table[@aria-describedby='consumption_report_info' and @id]//tbody/tr";

	public ConsumptionReport() 
	{
		PageFactory.initElements(driver, this);
	}
	public void selectproductName(String text)
	{
		try
		{
			if(courseListName.containsKey(text+"Option"))
				text=courseListName.get(text+"Option").toString();

		
		if(text.contains("Select all"))
		{
			wait.until(ExpectedConditions.visibilityOf(productName));
			productName.click();
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(productNamea+"[text()='Select all']"))));
			driver.findElement(By.xpath(productNamea+"[text()='Select all']")).click();
			productName.click();
			
		}
		else if(text.contains("Unselect all"))
		{
			productName.click();
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(productNamea+"[text()='Unselect all']"))));
			driver.findElement(By.xpath(productNamea+"[text()='Unselect all']")).click();
			productName.click();
		}
		else
		{
		wait.until(ExpectedConditions.visibilityOf(productName));
		productName.click();
		wait.until(ExpectedConditions.visibilityOf(productNameinput));
		productNameinput.sendKeys(text);
		try
		{
		Thread.sleep(4000);	
		}
	catch(Exception e)
		{
		
		}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[contains(@title,'"+text+"')]"))));
		//*[@title="10001"]
		driver.findElement(By.xpath("//*[contains(@title,'"+text+"')]")).click();
		productName.click();
		}
		}
		catch(Exception e)
		{
			System.out.println("No product ava");
		}
	}
	
	public void selectSFID(String text)
	{
		try
		{
		Thread.sleep(4000);	
		}
	catch(Exception e)
		{
		
		}
		if(text.contains("Select all"))
		{
			SFID.click();
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(SFIDa+"[text()='Select all']"))));
			SFIDinput.sendKeys("sales");
			driver.findElement(By.xpath(SFIDa+"[text()='Select all']")).click();
			int m=0;
			val = pageLoad.getAttribute("class");
	        while(val.contains("loader"))
	        {
	            val = pageLoad.getAttribute("class");
	            
	            if(m==pagload)
	            	break;
	            m++;
	        }
	        
			SFID.click();
			
		}
		else if(text.contains("Unselect all"))
		{
			SFID.click();
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(SFIDa+"[text()='Unselect all']"))));
			driver.findElement(By.xpath(SFIDa+"[text()='Unselect all']")).click();
			int m=0;
			val = pageLoad.getAttribute("class");
	        while(val.contains("loader"))
	        {
	            val = pageLoad.getAttribute("class");
	            
	            if(m==pagload)
	            	break;
	            m++;
	        }
	    	try
			{
			Thread.sleep(3000);	
			}
		catch(Exception e)
			{
			
			}
	        
			SFID.click();
		}
		else
		{
			wait.until(ExpectedConditions.visibilityOf(SFID));
		SFID.click();
		wait.until(ExpectedConditions.visibilityOf(SFIDinput));
		SFIDinput.sendKeys(OrganizationDetails. SalesforceName);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@title='"+OrganizationDetails. SalesforceName+"']"))));
		//*[@title="10001"]
		driver.findElement(By.xpath("//*[@title='"+OrganizationDetails. SalesforceName+"']")).click();
		int m=0;
		val = pageLoad.getAttribute("class");
        while(val.contains("loader"))
        {
            val = pageLoad.getAttribute("class");
            
            if(m==pagload)
            	break;
            m++;
        }
        try
		{
		Thread.sleep(3000);	
		}
	catch(Exception e)
		{
		
		}
		SFID.click();
		}
	}
	public void getTotalContract()
	{
		try
		{
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

			int m=0;
			val = pageLoad.getAttribute("class");
	        while(val.equalsIgnoreCase("loader"))
	        {
	            val = pageLoad.getAttribute("class");
	            
	            if(m==pagload)
	            	break;
	            m++;
	        }
	        
	
		
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(checkproduct))));
		wait.until(ExpectedConditions.visibilityOf(totalContractQuantity));
		Thread.sleep(5000);
		if(totalContractQuantity.getText().equals("NA"))
			oldTotalCount = 0;
		else
		oldTotalCount = Integer.parseInt(totalContractQuantity.getText());
		
		System.out.println("Contract Quantity available " + oldTotalCount);
		}
		catch(Exception e)
		{
			oldTotalCount = 0;	
			System.out.println("Contract Quantity available " + oldTotalCount);
			
		}
	}
	public void getTotalContractAllproduct()
	{
		try
		{
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

			int m=0;
			val = pageLoad.getAttribute("class");
	        while(val.equalsIgnoreCase("loader"))
	        {
	            val = pageLoad.getAttribute("class");
	            
	            if(m==pagload)
	            	break;
	            m++;
	        }
	        Thread.sleep(3000);
	
		
		wait.until(ExpectedConditions.visibilityOf(totalContractQuantity));
		if(totalContractQuantity.getText().equals("NA"))
			oldTotalCount = 0;
		else
		oldTotalCount = Integer.parseInt(totalContractQuantity.getText());
		
		System.out.println("Contract Quantity available " + oldTotalCount);
		}
		catch(Exception e)
		{
			oldTotalCount = 0;	
			System.out.println("Contract Quantity available " + oldTotalCount);
			
		}
	}
	public void getTotalContract(String course)
	{
		try
		{
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

			int m=0;
			val = pageLoad.getAttribute("class");
	        while(val.equalsIgnoreCase("loading"))
	        {
	            val = pageLoad.getAttribute("class");
	            
	            if(m==pagload)
	            	break;
	            m++;
	        }
	        
		   if(courseListName.containsKey(course+"Option"))
			   course=courseListName.get(course+"Option").toString();

	
		String contract="//tbody//td[2][text()='"+course+"']//following-sibling::td[2]";
		
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(contract))));
		wait.until(ExpectedConditions.visibilityOf(totalContractQuantity));
		if(totalContractQuantity.getText().equals("NA"))
			oldTotalCount = 0;
		else
		oldTotalCount = Integer.parseInt(totalContractQuantity.getText());
		
		System.out.println("Contract Quantity available " + oldTotalCount);
		}
		catch(Exception e)
		{
			oldTotalCount = 0;
			System.out.println("Contract Quantity available " + oldTotalCount);
			
				
		}
	}
	
	public void getTotalConsumed(String course)
	{
		try
		{
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

			int m=0;
			val = pageLoad.getAttribute("class");
	        while(val.equalsIgnoreCase("loading"))
	        {
	            val = pageLoad.getAttribute("class");
	            
	            if(m==pagload)
	            	break;
	            m++;
	        }
	        
		   if(courseListName.containsKey(course+"Option"))
			   course=courseListName.get(course+"Option").toString();

	
		   String contract="//tbody//td[2][text()='"+course+"']//following-sibling::td[2]";
			
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(contract))));
		
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(totalConsumedQuantity));
		if(totalConsumedQuantity.getText().equals("NA"))
			oldTotalConsumed = 0;
		else
		oldTotalConsumed = Integer.parseInt(totalConsumedQuantity.getText());
		System.out.println("Total consumed Quantity " + oldTotalConsumed);
		System.out.println("Contract Quantity available " + oldTotalCount);
		}
		catch(Exception e)
		{
			oldTotalConsumed = 0;
	
			System.out.println("Total consumed Quantity " + oldTotalConsumed);
			System.out.println("Contract Quantity available " + oldTotalCount);
		
		}
	}
	public void compareTotalContract()
	{
		
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(totalContractQuantity));
		int actualCount;
		if(totalContractQuantity.getText().equals("NA"))
		 actualCount = 0;	
		else
		 actualCount = Integer.parseInt(totalContractQuantity.getText());
		
		System.out.println(actualCount);
		Assert.assertTrue("Contract count is not changed",actualCount >= oldTotalCount);
	
	}
	
	public void compareTotalConsumed(int number)
	{
		try
		{
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(totalConsumedQuantity));
		
		int actualCount = Integer.parseInt(totalConsumedQuantity.getText());
		System.out.println(actualCount);
		Assert.assertTrue(actualCount - oldTotalConsumed == number);
		}
		catch(Exception e)
		{
		Assert.assertTrue("Consumption count is not changed",0 == number);
				
		}
	}
	public void getTotalConsumed()
	{
		try
		{
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

			int m=0;
			val = pageLoad.getAttribute("class");
	        while(val.equalsIgnoreCase("loading"))
	        {
	            val = pageLoad.getAttribute("class");
	            
	            if(m==pagload)
	            	break;
	            m++;
	        }
	        
			
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(checkproduct))));
	
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(totalConsumedQuantity));
		if(totalConsumedQuantity.getText().equals("NA"))
			oldTotalConsumed = 0;
		else
		oldTotalConsumed = Integer.parseInt(totalConsumedQuantity.getText());
		System.out.println("Total consumed Quantity " + oldTotalConsumed);
		}
		catch(Exception e)
		{
			oldTotalConsumed = 0;
			System.out.println("Total consumed Quantity " + oldTotalConsumed);
			System.out.println("Contract Quantity available " + oldTotalCount);
		
		}
	}
	public void getTotalConsumedallproduct()
	{
		try
		{
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

			int m=0;
			val = pageLoad.getAttribute("class");
	        while(val.equalsIgnoreCase("loading"))
	        {
	            val = pageLoad.getAttribute("class");
	            
	            if(m==pagload)
	            	break;
	            m++;
	        }
	        
			
	        Thread.sleep(4000);
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(totalConsumedQuantity));
		if(totalConsumedQuantity.getText().equals("NA"))
			oldTotalConsumed = 0;
		else
		oldTotalConsumed = Integer.parseInt(totalConsumedQuantity.getText());
		System.out.println("Total consumed Quantity " + oldTotalConsumed);
		}
		catch(Exception e)
		{
			oldTotalConsumed = 0;
			System.out.println("Total consumed Quantity " + oldTotalConsumed);
			System.out.println("Contract Quantity available " + oldTotalCount);
		
		}
	}

	public void selectOrgid(String text)
	{
		if(AssignmentReport. checkifParmeterAvailable(text))
			text=AssignmentReport.getParmeterAvailable(text);

		if(text.contains("Select all"))
		{
			wait.until(ExpectedConditions.visibilityOf(orgID));
			
			orgID.click();
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(orgIDa+"[text()='Select all']"))));
			orgIDinput.sendKeys("Auto");
			driver.findElement(By.xpath(orgIDa+"[text()='Select all']")).click();
			int m=0;
			val = pageLoad.getAttribute("class");
	        while(val.equalsIgnoreCase("loading"))
	        {
	            val = pageLoad.getAttribute("class");
	            
	            if(m==pagload)
	            	break;
	            m++;
	        }
	        
			orgID.click();
			
		}
		else if(text.contains("Unselect all"))
		{
			orgID.click();
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(orgIDa+"[text()='Unselect all']"))));
			driver.findElement(By.xpath(orgIDa+"[text()='Unselect all']")).click();
			int m=0;
			val = pageLoad.getAttribute("class");
	        while(val.equalsIgnoreCase("loading"))
	        {
	            val = pageLoad.getAttribute("class");
	            
	            if(m==pagload)
	            	break;
	            m++;
	        }
	        
			orgID.click();
		}
		else
		{
		wait.until(ExpectedConditions.visibilityOf(orgID));
		orgID.click();
		


		wait.until(ExpectedConditions.visibilityOf(orgIDinput));
        JavascriptExecutor jse = ((JavascriptExecutor)driver);        	
        jse.executeScript("arguments[0].value='';", orgIDinput);
		
		orgIDinput.sendKeys(TestBase.prop.getProperty("orgName"));
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='orgListDetails']//span[contains(text(),'"+TestBase.prop.getProperty("orgName")+"')]"))));
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='orgListDetails']//span[contains(text(),'"+TestBase.prop.getProperty("orgName")+"')]"))));
	
		int m=0;
//		wait.until(ExpectedConditions.(driver.findElement(By.xpath("//*[@id='orgListDetails']//span[contains(text(),'"+TestBase.prop.getProperty("orgName")+"')]"))));
			
		
//		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//div[@class='consumption_report_loader']"))));
//		val = pageLoad.getAttribute("class");
        while(m<=pagload)
        {
//            val = pageLoad.getAttribute("class");
            try
            {
            	Thread.sleep(250);
            	driver.findElement(By.xpath("//div[@class='consumption_report_loader']"));
            }
            catch(Exception e)
            {
            	break;
            }
            
            if(m==pagload)
            	break;
            m++;
        }
//        
        try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
		driver.findElement(By.xpath("//*[@id='orgListDetails']//span[contains(text(),'"+TestBase.prop.getProperty("orgName")+"')]")).click();
		m=0;
		while(m<=pagload)
	        {
//	            val = pageLoad.getAttribute("class");
	            try
	            {
	            	Thread.sleep(250);
	            	driver.findElement(By.xpath("//div[@class='consumption_report_loader']"));
	            }
	            catch(Exception e)
	            {
	            	break;
	            }
	            
	            if(m==pagload)
	            	break;
	            m++;
	        }
			
		
		}
		
	}
	public void validateDetailTable(String text) throws InterruptedException
	{
		
		if(AssignmentReport. checkifParmeterAvailable(text))
			text=AssignmentReport.getParmeterAvailable(text);

		Thread.sleep(5000);
		String[] rowvalue=text.split(",");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)");
		for(int i=0;i<rowvalue.length;i++)
		{
			
//			js.executeScript("arguments[0].scrollIntoView();",select);
			Assert.assertEquals(rowvalue[i], driver.findElement(By.xpath("//*[@id='consumption_report']//td[contains(text(),'"+rowvalue[i]+"')]")).getText());
		}
		
		
	}
	
	public void clickonClear()
	{
      val =  pageLoad.getAttribute("class");
		 int counter=0;
		 System.out.println(val);
	        while(val.contains("loading_consumption") )
	        {
	        	val = pageLoad.getAttribute("class");
	        	try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        	counter++;
	        	if(counter>12)
	        		Assert.fail("Not able to load page after waiting for 1 minute");
	        }
	    	wait.until(ExpectedConditions.visibilityOf(clear));
	    	
		clear.click();
	}
	
	public void printContract() throws InterruptedException
	{
		Thread.sleep(5000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", total);
		System.out.println("Print Contract Quantity"+total.getText());
	}
	public void validateConsumedWithCourseName(String courseName, int count)
	{
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();
	
		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(reportTable))));
		List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
		int rowCount = tableRows.size();
		for (int i= 1; i<= rowCount; i++)
		{
			String course = reportTable + "[" + i + "]/td[2]";
			String courseText = driver.findElement(By.xpath(course)).getText();
			if(courseName.trim().toLowerCase().contains(courseText.toLowerCase().trim()))
			{
				String consumed = reportTable + "[" + i + "]/td[4]";
				String consumedCount = driver.findElement(By.xpath(consumed)).getText();
				System.out.println(consumedCount);
				Assert.assertTrue(count == Integer.parseInt(consumedCount));
				break;
			}
			
		}		
	}
	public void clickExportButton()
	{
		wait.until(ExpectedConditions.visibilityOf(exportButton));
		val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_compliance"))
		{
			val = pageLoad.getAttribute("class");
		}
		exportButton.click();
	}
	public void validateReportData(int productCount)
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(reportTable))));
			File file = new File(filePath); 
			List<WebElement> rows = driver.findElements(By.xpath(reportTable));		
			Thread.sleep(5000);
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			List<String[]> header = csvReader.readAll();
			int rowsCountUI = rows.size();
			String uiDetails[][] = new String[rowsCountUI][productCount];
			for(int i = 1; i <= rowsCountUI; i++)
			{
				for(int j = 1; j <= productCount; j++)
				{
					uiDetails[i-1][j-1] = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[" + j + "]")).getText();
				}
				
			}
			String reportDetails[][] = new String[header.size() - 2][productCount];
			for(int i = 2; i <= header.size() - 1; i++)
			{
				String []excel = header.get(i);
				for(int j = 3; j <= excel.length-1; j++)
				{
					reportDetails[i-2][j-3] = excel[j];
				}
			}
			List<List<String>> list_ui = new ArrayList<>();
			for (String[] ints : uiDetails) {
			    list_ui.add(Arrays.asList(ints));
			}
			
			List<List<String>> list_excel = new ArrayList<>();
			for (String[] ints : reportDetails) {
			    list_excel.add(Arrays.asList(ints));
			}
			
			List<List<String>> differences = new ArrayList<>(list_ui);
			differences.removeAll(list_excel);
			Assert.assertTrue(differences.size() == 0);
			csvReader.close();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			Assert.fail(e.getMessage());
			
		}
	}
	
	public void verifyDownloadFile()
	{
		try 
		{
			int counter = 0;
			boolean dwnld = false;
			do 
			{
				Thread.sleep(5000);
				dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
				counter = counter +1;
				if(counter==pagload)
					break;
				else
				{
					try {
						Thread.sleep(550);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			while(dwnld == false);
		} 
		catch (InterruptedException e) 
		{
			System.out.println(e.getMessage());
			Assert.fail(e.getMessage());
			
		}
	}
	public boolean isFileDownloaded_Ext(String dirPath, String ext){
		boolean flag=false;
	    File dir = new File(dirPath);
	    File[] files = dir.listFiles();
	    if (files != null)
	    {
	    	 for (int i = 0; i < files.length; i++) 
	 	    {
	 	    	if(files[i].getName().contains(ext)&& !(files[i].getName().contains(".crdownload"))) 
	 	    	{
	 	    		fileName = files[i].getName();
	 	    		filePath = files[i].getAbsolutePath();
	 	    		filePath = filePath.replace(".crdownload", "");
					flag=true;
	 	    		break;
	 	    	}
	 	    }
	    }
	    
	    return flag;
	}
	public void navigateConsumptionReport()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		
		try
		{
		wait.until(ExpectedConditions.visibilityOf(reportLink));
		wait.until(ExpectedConditions.elementToBeClickable(reportLink));
		js.executeScript("window.scrollBy(0,-250)", "");
		
		reportLink.click();
		wait.until(ExpectedConditions.visibilityOf(consumptionReportLink));
		consumptionReportLink.click();
		String pageValue = js.executeScript("return document.readyState").toString();
		while(!(pageValue.equalsIgnoreCase("complete")))
		{
			pageValue = js.executeScript("return document.readyState").toString();
		}
		
		 driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		  	
			if(!driver.getCurrentUrl().contains("consumption_report"))
			{
				  js.executeScript("arguments[0].click();", reportLink);
					
				wait.until(ExpectedConditions.visibilityOf(consumptionReportLink));
				consumptionReportLink.click();
				

			}
		}
		catch(Exception e)
		{
			  js.executeScript("arguments[0].click();", reportLink);
			  wait.until(ExpectedConditions.visibilityOf(consumptionReportLink));
				consumptionReportLink.click();
				
		}
	}
	public boolean checkCSVFilePresent()
	{
		boolean dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
		return dwnld;
	}
	
	public void validateTotalContract(int count)
	{
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(totalContractQuantity));
		int actualCount = Integer.parseInt(totalContractQuantity.getText());
		Assert.assertTrue(actualCount == count);
	}
	
	public void validateTotalConsumed(int count)
	{
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(totalConsumedQuantity));
		int actualCount = Integer.parseInt(totalConsumedQuantity.getText());
		Assert.assertTrue(actualCount == count);
	}
	
	public void validateTotalContract(String count)
	{
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(totalContractQuantity));
		String actualCount = totalContractQuantity.getText();
		Assert.assertTrue(actualCount.equalsIgnoreCase(count));
	}
	
	public void clickStartDate()
	{
		int counter=0;
		try
		{
			Thread.sleep(5000);
		}
		catch(Exception e)
		{
				
		}
		 val =  pageLoad.getAttribute("class");
		 
		 System.out.println(val);
	        while(val.contains("loading_consumption") )
	        {
	        	val = pageLoad.getAttribute("class");
	        	try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        	counter++;
	        	if(counter>12)
	        		Assert.fail("Not able to load page after waiting for 1 minute");
	        }
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(fromDate));
		fromDate.click();
	}
	 public void selectDate(int date)
	    {
	        WebDriverWait wait = new WebDriverWait(driver, 15);
	        wait.until(ExpectedConditions.visibilityOf(datePickerSwitch));
	        String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old disabled day' ))]";
	        System.out.println(datePick + "'" + date + "'" + x);
	        WebElement reqDate = driver.findElement(By.xpath(datePick + "'" + date + "'" + x));
	        
	        wait.until(ExpectedConditions.visibilityOf(reqDate));
	        reqDate.click();
	    }
	 
	 public void selectDateGlobl(int date)
		{
			WebDriverWait wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.visibilityOf(datePickerSwitch));
			String x = " and not(contains(@class, 'disabled day' ))]";
			WebElement reqDate = driver.findElement(By.xpath(datePickglobl + "'" + date + "'" + x));
			wait.until(ExpectedConditions.visibilityOf(reqDate));
			reqDate.click();
		}
		
	 
	 public void selectSalesForceIDByName()
	    {
	        try
	        {
	            val = js.executeScript("return document.readyState").toString();
//	            System.out.println(val);
//	            while(!(val.equalsIgnoreCase("complete")))
//	            {
//	                System.out.println(val);
//	                val = js.executeScript("return document.readyState").toString();
//	            }
	            Thread.sleep(2000);
	            WebDriverWait wait = new WebDriverWait(driver, 30);
	            wait.until(ExpectedConditions.visibilityOf(salesforceDropdown));
	            salesforceDropdown.click();    
	            wait.until(ExpectedConditions.visibilityOf(salesforceSearchBox));
	            salesforceSearchBox.click();
	            salesforceSearchBox.sendKeys(OrganizationDetails.SalesforceName);
	            //salesforceSearchBox.sendKeys("salesFMonFeb2112:03:27IST2022");
	            Thread.sleep(5000);
//	            salesforceSelectAll.click();
	            
	            List<WebElement> options = driver.findElements(By.xpath(salesForceIdSearch));
	            int  counter = 0;
	            while(!(options.size() == 1))
	            {
	            	options = driver.findElements(By.xpath(salesForceIdSearch + "[@class= 'active']"));
	            	Thread.sleep(5000);
	            	counter++;
	            	if(counter>12)
	            		Assert.fail("Not able to search product after waiting for 1 minute");
	            }
	            for(int i = 1; i <= options.size(); i++)
	            {
	            	String element = "(" + salesForceIdSearch + "[@class= 'active'])[" + i + "]";
	            	String value = driver.findElement(By.xpath(element)).getText();
	            	if(value.toLowerCase().trim().equalsIgnoreCase(OrganizationDetails.SalesforceName.toLowerCase().trim()))
	            	{
	            		Thread.sleep(2000);
	            		driver.findElement(By.xpath(element)).click();
	            		break;
	            	}
	            }
	            counter = 0;
	            while(val.contains("loading_consumption") )
	            {
	            	val = pageLoad.getAttribute("class");
	            	Thread.sleep(5000);
	            	counter++;
	            	if(counter>12)
	            		Assert.fail("Not able to load page after waiting for 1 minute");
	            }
	            Thread.sleep(5000);
	            consumptionReport.click();
	            
//	            val = pageLoad.getAttribute("class");
//	            while(val.contains("loading_consumption") )
//	            {
//	                val = pageLoad.getAttribute("class");
//	           
	        }
	        catch (Exception e)
	        {
	            e.printStackTrace();
	        }
	        
	    }
public int getDay(int range, String duration)
{
    int day = 0;
    try
    {
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.visibilityOf(exportButton));
        LocalDate localDate = LocalDate.now();
        switch(duration.toLowerCase().trim())
        {
        case "days":
            localDate = localDate.plusDays(range);
            day = localDate.getDayOfMonth();
            break;
        case "months":
            localDate = localDate.plusMonths(range);
            day = localDate.getMonthValue();
            break;
        case "week":
            localDate = localDate.plusWeeks(range);
            day = localDate.getDayOfMonth();
            break;        
        }
    }
    catch(Exception e)
    {
        
    }
    return day;
}
	
	public void clickEndDate()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(toDate));
		toDate.click();
	}
	
	public void selecftDate()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(datePickerSwitch));
		DateFormat dateFormat = new SimpleDateFormat("d");
		Date date = new Date();
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_MONTH, -1); 
		String formattedStartDate = dateFormat.format(cal.getTime());
		
		String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
		WebElement reqDate ;
		try
		{
		 reqDate = driver.findElement(By.xpath(datePick + "'" + formattedStartDate + "'" + x));
		wait.until(ExpectedConditions.visibilityOf(reqDate));
	    }
	   catch(Exception e)
     	{
		    cal = Calendar.getInstance();
			 formattedStartDate = dateFormat.format(cal.getTime());
			  reqDate = driver.findElement(By.xpath(datePick + "'" + formattedStartDate + "'" + x));
				wait.until(ExpectedConditions.visibilityOf(reqDate));
			    	
	    }
		try
		{
		reqDate.click();
		}
		catch(Exception e)
		{
			reqDate.click();
				
		}
	}
	public void clickEndDateinglobal()
	{
	    try
				{
					Thread.sleep(7000);
				}
				catch(Exception e)
				{
						
				}
	   
		wait.until(ExpectedConditions.visibilityOf(toDate));
		wait.until(ExpectedConditions.elementToBeClickable(toDate));
		
		toDate.click();
	}
	public void selectDateinglobal() throws InterruptedException
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(datePickerSwitch));
		int date = LocalDate.now().getDayOfMonth();
		String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
		WebElement reqDate = driver.findElement(By.xpath(datePick + "'" + date + "'" + x));
		wait.until(ExpectedConditions.visibilityOf(reqDate));
		int counter = 0;
			
        
		try
		{
			Thread.sleep(9000);
		reqDate.click();
		}
		catch(Exception e)
		{
			Thread.sleep(7000);
			reqDate.click();
				
		}
	}
	public void clickStartDateinglobal()
	{
		int counter=0;
		 try
			{
				Thread.sleep(7000);
			}
			catch(Exception e)
			{
					
			}
		
	       
		wait.until(ExpectedConditions.visibilityOf(fromDate));
		wait.until(ExpectedConditions.elementToBeClickable(fromDate));
		
		fromDate.click();
		
	}
	public void selectDate() throws InterruptedException
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(datePickerSwitch));
		int date = LocalDate.now().getDayOfMonth();
		String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
		WebElement reqDate = driver.findElement(By.xpath(datePick + "'" + date + "'" + x));
		wait.until(ExpectedConditions.visibilityOf(reqDate));
		int counter = 0;
		 val = js.executeScript("return document.readyState").toString();
        while(val.contains("loading_consumption") )
        {
        	val = pageLoad.getAttribute("class");
        	Thread.sleep(5000);
        	counter++;
        	if(counter>12)
        		Assert.fail("Not able to load page after waiting for 1 minute");
        }
		try
		{
			Thread.sleep(4000);
		reqDate.click();
		}
		catch(Exception e)
		{
			Thread.sleep(6000);
			reqDate.click();
				
		}
	}
	public void selectDate(String dat)
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(datePickerSwitch));
		int date = LocalDate.now().getDayOfMonth();
		String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
		WebElement reqDate = driver.findElement(By.xpath(datePick + "'" + date + "'" + x));
		wait.until(ExpectedConditions.visibilityOf(reqDate));
		reqDate.click();
	}
	public void selectAllProducts()
	{
		try {
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			wait.until(ExpectedConditions.visibilityOf(productNameFilter));
			productNameFilter.click();
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(selectAllFilter));
			Thread.sleep(2000);
			selectAllFilter.click();
			wait.until(ExpectedConditions.visibilityOf(buttonSearch));
			Thread.sleep(2000);
			productName.click();
			Thread.sleep(3000);
		
			
		}		
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
	}
	public void selectSalesForceID()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(salesforceDropdown));
			salesforceDropdown.click();	
			wait.until(ExpectedConditions.visibilityOf(salesforceSearchBox));
			salesforceSearchBox.click();
			salesforceSearchBox.sendKeys(NewOrganization.SalesforceName);
			//salesforceSearchBox.sendKeys("salesFMonFeb2112:03:27IST2022");
			Thread.sleep(5000);
			salesforceSelectAll.click();
			consumptionReport.click();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void selectOrganizationID()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(organizationDropdown));
			organizationDropdown.click();	
			wait.until(ExpectedConditions.visibilityOf(organizationSearchBox));
			Thread.sleep(5000);
			organizationSelectAll.click();	
			consumptionReport.click();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void clickOnsearchbutton() throws InterruptedException {
		searchbutton.click();
		Thread.sleep(4000);
	}
	
	public void validateLabel(String label)
	{
		
		
		try {
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[text()='"+label+"']"))));
		}
		catch (NoSuchElementException e) {
		Assert.fail(label);
		
		}
	}
	public void selectfromdate(String date,String toate)
	{
		if(AssignmentReport. checkifParmeterAvailable(date))
			date=AssignmentReport.getParmeterAvailable(date);

	
		if(AssignmentReport. checkifParmeterAvailable(toate))
			toate=AssignmentReport.getParmeterAvailable(toate);

		if(courseListName.containsKey(date))
		{
			date=courseListName.get(date).toString();
			date=date.replace("-", "/");
		}

		if(courseListName.containsKey(toate))
		{
			toate=courseListName.get(toate).toString();
			toate=toate.replace("-", "/");
		}

		
		try {
		wait.until(ExpectedConditions.visibilityOf(fromDate));
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		
				js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", fromDate,"value",date);
				if(toate.contains("disable"))
				{
					toDate.click();
					;
					Assert.assertTrue(driver.findElement(By.xpath("(//div[1]/table/tbody/tr/td[text()='"+toate.split("/")[2]+"'])[1]")).getAttribute("class").contains("disabled day"));
				}
				else if(!(toate.equals("")))
				{
					
					js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", toDate,"value",toate);
				}
				else
				{
					  LocalDateTime myDateObj = LocalDateTime.now().plusDays(1);
					    System.out.println("Before formatting: " + myDateObj);
					    DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd/MM/yyyy");

					    String formattedDate = myDateObj.format(myFormatObj);
					    
					toate=formattedDate;
					js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", toDate,"value",toate);
				}
				
				//		fromDate.ge
		}
		catch (NoSuchElementException e) {
		
		}
	}
	
   public 	String  getContractQty(String course)
	{
	   try
	   {
			int m=0;
			val = pageLoad.getAttribute("class");
			Thread.sleep(4000);
	        while(val.equalsIgnoreCase("loader"))
	        {
	            val = pageLoad.getAttribute("class");
	            
	            if(m==pagload)
	            	break;
	            else
	            {
	            	System.out.println(1);
	            	Thread.sleep(250);
	            }
	            m++;
	        }
	        
		   if(courseListName.containsKey(course+"Option"))
			   course=courseListName.get(course+"Option").toString();

		 //*//th[text()='Contract Quantity Change']
		String contract="//tbody//tr//*[text()='"+course+"']//following-sibling::td[1]";
		checkproduct="//tbody//tr//*[text()='"+course+"']";
		
		System.out.println(checkproduct);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(contract))));
		
		return driver.findElement(By.xpath(contract)).getText() ;
	   }
	   catch(Exception e)
	   {

//		   e.printStackTrace();
		   return "0";
	   }
	}
   
   public 	String  getContractQtyproduct(String course)
  	{
  	   try
  	   {
  			int m=0;
  			
  		   if(courseListName.containsKey(course+"Option"))
  			   course=courseListName.get(course+"Option").toString();

  		 //*//th[text()='Contract Quantity Change']
  		String contract="//tbody//tr//td[text()='"+course+"']//following-sibling::td[2]";
  		checkproduct="//tbody//tr//*[text()='"+course+"']";
  		
  		System.out.println(checkproduct);
  		driver.findElement(By.xpath(contract));
  	 	wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(contract))));
 	  	
  		return driver.findElement(By.xpath(contract)).getText() ;
  	   }
  	   catch(Exception e)
  	   {
e.printStackTrace();
  		   return "0";
  	   }
  	}
   public 	String  getConsumedContractQty(String course)
  	{
  	   try
  	   {
  		 if(courseListName.containsKey(course+"Option"))
  			course=courseListName.get(course+"Option").toString();
  		int m=0;
		val = pageLoad.getAttribute("class");
        while(val.equalsIgnoreCase("loading"))
        {
            val = pageLoad.getAttribute("class");
            
            if(m==pagload)
            	break;
            m++;
        }
        
  		 //*//th[text()='Contract Quantity Change']
  		   Assert.assertEquals(driver.findElement(By.xpath("//thead/tr/th[3]")).getText(), "CONTRACT QUANTITY");
  		String contract="//tbody//td[2][text()='"+course+"']//following-sibling::td[2]";
  		return driver.findElement(By.xpath(contract)).getText() ;
  	   }
  	   catch(Exception e)
  	   {
  		   return "0";
  	   }
  	}
   
   public 	String  getContractQtyproductHistory(String course)
	{
	   try
	   {
		   if(courseListName.containsKey(course+"Option"))
	  			course=courseListName.get(course+"Option").toString();

		   
		 //*//th[text()='Contract Quantity Change']
		   Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"purchage-code-report\"]/thead/tr/th[6]")).getText(), "CONTRACT QUANTITY CHANGE");
		   Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"purchage-code-report\"]/thead/tr/th[7]")).getText(), "TOTAL CONTRACT QUANTITY");
			
		   String contract="(//td[text()='"+course+"'][1]/following-sibling::td[5])[1]";
		return driver.findElement(By.xpath(contract)).getText() ;
	   }
	   catch(Exception e)
	   {
		   return "0";
	   }
	}
  
   
   
   public 	String  getContractQtyConsumptionReport(String course)
  	{
  	   try
  	   { 
  		 if(courseListName.containsKey(course+"Option"))
   			course=courseListName.get(course+"Option").toString();

  		   Assert.assertTrue(driver.getPageSource().contains("Total Contract Quantity"));
  		   Assert.assertTrue(driver.getPageSource().contains("Total Consumed"));
  		 	
  			
  		   String contract="//tbody//td[3][text()='"+course+"']//following-sibling::td[1]";
  		 wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(contract))));
	 	  	
  		   System.out.println("Contact number"+driver.findElement(By.xpath(contract)).getText());
  		   return driver.findElement(By.xpath(contract)).getText();
  	   }
  	   catch(Exception e)
  	   {
  		   return "0";
  	   }
  	}
   
   public 	String  getContractQtyGlobalConsumptionReport(String course)
 	{
 	   try
 	   { 
 	      
 		 if(courseListName.containsKey(course+"Option"))
  			course=courseListName.get(course+"Option").toString();
 		  reuse. scrollLeft();
 	 		
 		   Assert.assertTrue(driver.getPageSource().contains("Total Contract Quantity"));
 		   Assert.assertTrue(driver.getPageSource().contains("Total Consumed"));
 			
 		   String contract="//tbody//td[6][text()='"+course+"']//following-sibling::td[1]";
 		 	wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(contract))));
 	  		  
 		   System.out.println("Contact number "+driver.findElement(By.xpath(contract)).getText());
 		   return driver.findElement(By.xpath(contract)).getText();
 	   }
 	   catch(Exception e)
 	   {
 		   return "0";
 	   }
 	}
   
   public 	void  getContractQtyGlobalConsumptionReport(String coursename,String course)
  	{
  	   try
  	   { 
  	      
  		 if(courseListName.containsKey(course+"Option"))
   			course=courseListName.get(course+"Option").toString();
  		  reuse. scrollLeft();
  	 		
  		   
  		   String contract="//tbody//td[6][text()='"+course+"']//following-sibling::td[1]";
  		 	wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(contract))));
  	  		  
  		   System.out.println("Contact number "+driver.findElement(By.xpath(contract)).getText());
  			dataMap.put(coursename+"GlobalContract",driver.findElement(By.xpath(contract)).getText())  ;
  		 	
  	   }
  	   catch(Exception e)
  	   {
  			dataMap.put(coursename+"GlobalContract","0")  ;
  	  		
  	   }
  	   
  	  System.out.println("GlobalConsumption "+course+" :"+dataMap.get(coursename+"GlobalContract"));
  	    
  	}
 //tbody//td[text()='RQI® Responder(test)']//following-sibling::td[2]
   
   public 	String  getQtyGlobalConsumptionReport(String course)
 	{
 	   try
 	   { 

			if(courseListName.containsKey(course+"Option"))
				course=courseListName.get(course+"Option").toString();

			course = course.replace("Â", "");
			
 		Thread.sleep(5000);
 		   
 	  String contract="//tbody//td[6][text()='"+course+"']//following-sibling::td[2]";
		 	wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(contract))));
 		
 		return driver.findElement(By.xpath(contract)).getText() ;
 	   }
 	   catch(Exception e)
 	   {
 		   System.out.println("Consumed is zero");
 		   return "0";
 	   }
 	}
   
   public 	void  getQtyGlobalConsumptionReport(String coursename,String course)
	{
	   try
	   { 

			if(courseListName.containsKey(course+"Option"))
				course=courseListName.get(course+"Option").toString();

			course = course.replace("Â", "");
			
		Thread.sleep(5000);
		   
	  String contract="//tbody//td[6][text()='"+course+"']//following-sibling::td[2]";
		 	wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(contract))));
		
			dataMap.put(coursename+"GlobalConsumption",driver.findElement(By.xpath(contract)).getText())  ;
	  		
		
	   }
	   catch(Exception e)
	   {
		   System.out.println("Consumed is zero");
			dataMap.put(coursename+"GlobalConsumption","0")  ;
		  	
	   }
	   System.out.println("Consumption "+course+" :"+dataMap.get(coursename+"GlobalConsumption"));
	 	
	}

   
   public 	String  getMapGlobalConsumptionReport(String course)
	{
	   return dataMap.get(course+"GlobalConsumption");
	}
   public 	String  getQtyConsumptionReport(String course)
  	{
  	   try
  	   { 

			if(courseListName.containsKey(course+"Option"))
				course=courseListName.get(course+"Option").toString();

			course = course.replace("Â", "");
			
  		Thread.sleep(5000);
  		   
  	  String contract="//tbody//td[3][text()='"+course+"']//following-sibling::td[2]";
		 	wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(contract))));
  		
  		return driver.findElement(By.xpath(contract)).getText() ;
  	   }
  	   catch(Exception e)
  	   {
  		   System.out.println("Consumed is zero");
  		   return "0";
  	   }
  	}
   
   
   public 	String  getMapConsumptionReport(String course)
 	{
 	   return dataMap.get(course+"Consumption");
 	}
  
   
  

   public 	void  getQtyConsumptionReport(String coursename,String course)
 	{
 	   try
 	   { 

			if(courseListName.containsKey(course+"Option"))
				course=courseListName.get(course+"Option").toString();

			course = course.replace("Â", "");
			
 		Thread.sleep(5000);
 		   
 	  String contract="//tbody//td[3][text()='"+course+"']//following-sibling::td[2]";
		 	wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(contract))));
 		
 		dataMap.put(coursename+"Consumption",driver.findElement(By.xpath(contract)).getText())  ;
 	   }
 	   catch(Exception e)
 	   {
 		   System.out.println("Consumed is zero");
 			dataMap.put(coursename+"Consumption","0")  ;
 		 	
 		    ;
 	   }
 	   System.out.println("Consumption "+course+" :"+dataMap.get(coursename+"Consumption"));
 	}
   public void verifypagination_consumptionreport() throws InterruptedException
	{
		Thread.sleep(2000); 
		     JavascriptExecutor js = (JavascriptExecutor) driver;
		     js.executeScript("arguments[0].scrollIntoView();", rowsperpageheader);
		Boolean Display = Paginationinfoup.isDisplayed();
		System.out.println("Element displayed is :"+Display);
		
	  Assert.assertEquals(rowsperpageheader.getText(),"Rows per page\n"
	  		+ "25\n"
	  		+ "50\n"
	  		+ "75\n"
	  		+ "100");
	}
	 JavascriptExecutor js = (JavascriptExecutor) driver;
		
	public void selectAllOrganizationID()
    {
        try
        {
            val = js.executeScript("return document.readyState").toString();
            System.out.println(val);
            while(!(val.equalsIgnoreCase("complete")))
            {
                System.out.println(val);
                val = js.executeScript("return document.readyState").toString();
            }
            WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(ExpectedConditions.visibilityOf(organizationDropdown));
            organizationDropdown.click();    
            wait.until(ExpectedConditions.visibilityOf(organizationSearchBox));
            organizationSearchBox.sendKeys(TestBase.prop.getProperty("orgName"));
            Thread.sleep(5000);
            organizationSelectAll.click();    
            val = pageLoad.getAttribute("class");
            while(val.contains("loading_consumption") )
            {
                val = pageLoad.getAttribute("class");
            }
            val = js.executeScript("return document.readyState").toString();
            System.out.println(val);
            while(!(val.equalsIgnoreCase("complete")))
            {
                System.out.println(val);
                val = js.executeScript("return document.readyState").toString();
            }
            consumptionReport.click();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        
    }
    
    public void selectProduct()
    {
        try
        {
            val = pageLoad.getAttribute("class");
            while(val.contains("loading_consumption") )
            {
                val = pageLoad.getAttribute("class");
            }
            WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(ExpectedConditions.visibilityOf(productDropdown));
            Thread.sleep(5000);
            productDropdown.click();    
            wait.until(ExpectedConditions.visibilityOf(productSelectAll));
            Thread.sleep(5000);
            productSelectAll.click();    
            consumptionReport.click();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }        
    }



   public void clickSearchButton()
    {
        try
        {
        
        	int counter = 0;
        	while(val.contains("loading_consumption") )
        	{
        	val = pageLoad.getAttribute("class");
        	Thread.sleep(5000);
        	counter++;
        	if(counter>12)
        	Assert.fail("Not able to load page after waiting for 1 minute");
        	}
            WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(ExpectedConditions.visibilityOf(buttonSearch));
            buttonSearch.click();
            wait.until(ExpectedConditions.invisibilityOf(labelSearch));
            JavascriptExecutor js = (JavascriptExecutor)driver;
            val = js.executeScript("return document.readyState").toString();
            System.out.println(val);
            while(!(val.equalsIgnoreCase("complete")))
            {
                System.out.println(val);
                val = js.executeScript("return document.readyState").toString();
            }
            Thread.sleep(2000);
            try {
                Alert alert = driver.switchTo().alert();
                alert.accept();
            }
            catch(UnhandledAlertException e)
            {
                
            }
            val = pageLoad.getAttribute("class");
            while(val.contains("loading_consumption") )
            {
                val = pageLoad.getAttribute("class");
            }
            val = js.executeScript("return document.readyState").toString();
            System.out.println(val);
            while(!(val.equalsIgnoreCase("complete")))
            {
                System.out.println(val);
                val = js.executeScript("return document.readyState").toString();
            }
        }
        catch (Exception e)
        {
        	
        }
    }
   public void validateSummary()
   {
       try
       {
           Thread.sleep(5000);
           WebDriverWait wait = new WebDriverWait(driver, 30);
           wait.until(ExpectedConditions.visibilityOf(consumptionReport));
           String contractLabel = totalContractLabel.getText().trim();
           Assert.assertTrue(contractLabel.contains("Total Contract Quantity :"));
           String consumedLabel = totalConsumedLabel.getText().trim();
           Assert.assertTrue(consumedLabel.contains("Total Consumed :"));
           String info =driver.findElement(By.xpath("(//p)[6]")).getText();
           Assert.assertEquals(info, "Products listed with no contract quantity are not included in the 'Total Contract Quantity'");
           
       }
       catch(Exception e)
       {
           Assert.fail("Summary not displayed as expected");
       }
   }
   
   public void validateEntries()
   {
       try
       {
           WebDriverWait wait = new WebDriverWait(driver, 30);
           wait.until(ExpectedConditions.visibilityOf(consumptionReport));
           List<WebElement> rows = driver.findElements(By.xpath(result));
           Assert.assertEquals(rows.size(), 2);
           String text = driver.findElement(By.xpath("(" + result + ")[1]" )).getText();
           Assert.assertTrue(text.toLowerCase().contains("showing"));
           Assert.assertTrue(text.toLowerCase().contains("to"));
           Assert.assertTrue(text.toLowerCase().contains("of"));
           Assert.assertTrue(text.toLowerCase().contains("entries"));
       }
       catch(Exception e)
       {
    	   Assert.fail(e.getMessage());
			   
       }
   }
   
   public void pagination()
   {
       try {
           WebDriverWait wait = new WebDriverWait(driver, 30);
           wait.until(ExpectedConditions.visibilityOf(consumptionReport));
           List<WebElement> rows = driver.findElements(By.xpath(pagination));
           Assert.assertTrue(rows.size() >= 1);
       }
       catch(Exception e)
       {
    	   Assert.fail(e.getMessage());
			   
       }
   }
   public void validateHeaderOrgAdmin()
   {
       WebDriverWait wait = new WebDriverWait(driver, 30);
       wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(reportHeader + "[1]"))));
       List<WebElement> headerList = driver.findElements(By.xpath(reportHeader));
       String[] headerData = new String[headerList.size()];
       for(int i = 1; i <= headerList.size(); i++)
       {
           headerData[i-1] = headerList.get(i-1).getText();
       }
       String expectedHeader[] = {"Org Unit","Product Code", "Product Name", "Contract Quantity", "Consumed"};
       for(int i = 0; i <= expectedHeader.length - 1; i++)
       {
           expectedHeader[i] = expectedHeader[i].toUpperCase();
       }
       boolean flag = Arrays.equals(headerData, expectedHeader);
       System.out.println(flag);
       Assert.assertTrue(flag);            
   }
   public void validateHeader()
   {
       WebDriverWait wait = new WebDriverWait(driver, 30);
       wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(reportHeader + "[1]"))));
       List<WebElement> headerList = driver.findElements(By.xpath(reportHeader));
       String[] headerData = new String[headerList.size()];
       for(int i = 1; i <= headerList.size(); i++)
       {
    	  
    		if(i == 7)
			{
				JavascriptExecutor executor = (JavascriptExecutor)driver;
				WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
				executor.executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", scrollArea);
			}
    	   System.out.println( headerList.get(i-1).getText());
           headerData[i-1] = headerList.get(i-1).getText();
   		
    	   try
    	   {
    		Thread.sleep(4000);   
    	   }
    	   catch (Exception e) {
			// TODO: handle exception
		}
       }
       String expectedHeader[] = {"SF ID", "Org ID", "ORG Name","Org Unit", "Product Code", "Product Name", "Contract Quantity", "Consumed"};
       for(int i = 0; i <= expectedHeader.length - 1; i++)
       {
    	   expectedHeader[i].toUpperCase();
    	   System.out.println(expectedHeader[i].toUpperCase());
           expectedHeader[i] = expectedHeader[i].toUpperCase();
       }
       boolean flag = Arrays.equals(headerData, expectedHeader);
       System.out.println(flag);
       Assert.assertTrue(flag);            
   }
   
   public void validateDisableDate(int date)
   {
       WebDriverWait wait = new WebDriverWait(driver, 15);
       wait.until(ExpectedConditions.visibilityOf(datePickerSwitch));
       String x = " and not(contains(@class, 'disabled day' )) and not( @class='new disabled day') and not(contains(@class, 'old day' ))]";
       int dateAvailability = driver.findElements(By.xpath(datePick + "'" + date + "'" + x)).size();
       System.out.println(datePick + "'" + date + "'" + x);
       Assert.assertFalse(dateAvailability > 0);
   }
   
	public void validateNoReportGenerated()
	{
		WebDriverWait wait = new WebDriverWait(driver, 60);
		val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading"))
		{
			val = pageLoad.getAttribute("class");
		}
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
		}
		wait.until(ExpectedConditions.visibilityOf(norecord));
		Assert.assertEquals("Validate","No reports data found.", norecord.getText());
	}

	public void consumptionStatusColumnsValidation(List<String> text, String tc) throws Exception
	{
		  wait.until(ExpectedConditions.visibilityOf(productName));
		Thread.sleep(3000);
		
		int count = 0;
		for(WebElement tt : consumptionColumns){
			System.out.println(tt.getAttribute("innerText"));
			Assert.assertEquals(text.get(count).toUpperCase(), tt.getAttribute("innerText"));
			count++;
		}

	}
	public void validaterow(int row)
	{
	int cont=0;
		int rowCount=0;
		while(row!=rowCount)
		{
		try
		{
			Thread.sleep(250);
			List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
            rowCount = tableRows.size();
//            System.out.println(rowCount);
		}
		catch (Exception e) {
			// TODO: handle exception
		}
         if(cont==650)
        	 break;
         
         cont++;
    	}
		
	}
	public void clickonClearGlobal()
	{
		int counter=0;
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    	wait.until(ExpectedConditions.visibilityOf(clear));
	     	wait.until(ExpectedConditions.elementToBeClickable(clear));
	 	   	
		clear.click();
	}
	public void clickUnitLinkAndValidatePopup() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		try {
			int position = getHeaderPosition("org unit");
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("((" + tableRows + ")/td[" + position + "]//a)[1]"))));
		//List<WebElement> rows = driver.findElements(By.xpath(tableRows));
		ArrayList<WebElement> rowList =  new ArrayList<WebElement>(driver.findElements(By.xpath("(" + tableRows + ")/td[" + position + "]//a")).size());
		rowList.addAll(driver.findElements(By.xpath("(" + tableRows + ")/td[" + position + "]//a")));
		for(int i = 1; i<= rowList.size(); i++) {
			rowList.get(i-1).click();
			wait.until(ExpectedConditions.visibilityOf(popupHeading));
			String text = popupHeading.getText();
			Assert.assertTrue(text.contains(" - Organization Hierarchy"));
			popupClose.click();
			wait.until(ExpectedConditions.invisibilityOf(popupHeading));
		}
		}
		catch (Exception e) {
		Assert.fail(e.getMessage());		
		}
	}
	public int getHeaderPosition(String header)
	{
		
		int columnCount = 0;
		try {
		//WebDriverWait wait = new WebDriverWait(driver, 30);
		//wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableLabel))));
		List<WebElement> tableHeaderRows = driver.findElements(By.xpath(reportHeader));
		for(int i = 1; i <=tableHeaderRows.size(); i++)
		{
			String headerName = driver.findElement(By.xpath(reportHeader + "[" + i +"]")).getText();
			if(headerName.equalsIgnoreCase(header))
			{
				columnCount = i;
				break;				
			}				
		}
		System.out.println("The column position for " + header +" is " + columnCount);
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return columnCount;
	}
	
	 public void clickSearchButtonGlobalConsumptionReport()
	    {
	        try
	        {
	        
	            wait.until(ExpectedConditions.visibilityOf(buttonSearch));
	            buttonSearch.click();
	            wait.until(ExpectedConditions.invisibilityOf(labelSearch));
	            Thread.sleep(5000);
	        }
	        catch (Exception e)
	        {
	        	
	        }
	    }
	 
	 public void validateProductMultipleSelect()
		{
			try 
			{
				val = js.executeScript("return document.readyState").toString();
				System.out.println(val);
				int counter = 0;
				while(!(val.equalsIgnoreCase("complete")))
				{
					val = js.executeScript("return document.readyState").toString();
					Thread.sleep(2000);
					counter++;
					if(counter>30)
						Assert.fail("Not able to load page after waiting for 1 minute");
				}
				Thread.sleep(2000);
				Select select = new Select(productDropdownSelect);
				boolean result = select.isMultiple();
				Assert.assertTrue(result == true);
			}
			catch(Exception e) {
				Assert.fail(e.getMessage());
			}
		}
	 
		public void validateOrganizationSingleSelect()
		{
			try 
			{
				val = js.executeScript("return document.readyState").toString();
				System.out.println(val);
				int counter = 0;
				while(!(val.equalsIgnoreCase("complete")))
				{
					val = js.executeScript("return document.readyState").toString();
					Thread.sleep(2000);
					counter++;
					if(counter>30)
						Assert.fail("Not able to load page after waiting for 1 minute");
				}
				Thread.sleep(2000);
				Select select = new Select(organizationDropdownSelect);
				boolean result = select.isMultiple();
				Assert.assertTrue(result == false);
			}
			catch(Exception e) {
				Assert.fail(e.getMessage());
			}
		}

		public void validateSalesForceIDSingleSelect()
		{
			try 
			{
				val = js.executeScript("return document.readyState").toString();
				System.out.println(val);
				int counter = 0;
				while(!(val.equalsIgnoreCase("complete")))
				{
					val = js.executeScript("return document.readyState").toString();
					Thread.sleep(2000);
					counter++;
					if(counter>30)
						Assert.fail("Not able to load page after waiting for 1 minute");
				}
				Thread.sleep(2000);
				Select select = new Select(salesForceDropdown);
				boolean result = select.isMultiple();
				Assert.assertTrue(result == false);
			}
			catch(Exception e) {
				Assert.fail(e.getMessage());
			}
		}
		
		public void validateOrgLevelSingleSelect()
		{
			try 
			{
				val = js.executeScript("return document.readyState").toString();
				System.out.println(val);
				int counter = 0;
				while(!(val.equalsIgnoreCase("complete")))
				{
					val = js.executeScript("return document.readyState").toString();
					Thread.sleep(2000);
					counter++;
					if(counter>30)
						Assert.fail("Not able to load page after waiting for 1 minute");
				}
				Thread.sleep(2000);
				Select select = new Select(orgLevelDropdownSelect);
				boolean result = select.isMultiple();
				Assert.assertTrue(result == false);
			}
			catch(Exception e) {
				Assert.fail(e.getMessage());
			}
		}
		public void selectOrgLevelDropdown() {
			wait.until(ExpectedConditions.visibilityOf(orgLevel));
			orgLevel.click();
			List<WebElement> list = driver.findElements(By.xpath(orgLevelNameList));
			Assert.assertEquals(list.size(), OrganizationSetting.map.size());
			for(int i = 1; i <= list.size(); i++) {
				String actualValue = null;
				String actualKey = driver.findElement(By.xpath(orgLevelNameList + "[" + i + "]")).getText();
				String expectedKey = (OrganizationSetting.map.keySet().toArray()[i-1]).toString();
				Assert.assertEquals(expectedKey, actualKey);
				driver.findElement(By.xpath(orgLevelNameList + "[" + i + "]")).click();	
				try {
				String val = pageLoad.getAttribute("class");
				int counter = 0;
				while(val.equalsIgnoreCase("loading_consumption"))
				{
					val = pageLoad.getAttribute("class");
					Thread.sleep(5000);
					counter++;
					if(counter>12)
						Assert.fail("Not able to load page after waiting for 1 minute");
				}
				}
				catch(Exception e) {
					
				}
				String expectedValue = OrganizationSetting.map.get(actualKey);
				unitLevel.click();
				List<WebElement> unitList = driver.findElements(By.xpath(unitLevelNameList));
				for(int j = 1; j <= unitList.size(); j++)
				{
					String text =  driver.findElement(By.xpath(unitLevelNameList + "[" + j + "]")).getText().trim();
					if(actualValue == null)
						actualValue = text;
					else
						actualValue = actualValue + "," + text;
				}
				Assert.assertEquals(expectedValue, actualValue);
				orgLevel.click();
			}
		}
		
		public void compareDetails()
		{
			try
			{
				JavascriptExecutor js = (JavascriptExecutor)driver;
				String  uiList[][];
				int counter = 0;
				val = js.executeScript("return document.readyState").toString();
				while(!(val.equalsIgnoreCase("complete")))
				{
					val = js.executeScript("return document.readyState").toString();
					counter++;
					if(counter>12)
						Assert.fail("Not able to load page after waiting for 1 minute");
				}
				driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
				WebDriverWait wait = new WebDriverWait(driver, 30);
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(reportTable))));
				List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
				List<List<String>> list_UI = new ArrayList<>();
				List<List<String>> list_report = new ArrayList<>();
				File file = new File(filePath);
				FileReader filereader = new FileReader(file,StandardCharsets.UTF_8);
				CSVReader csvReader = new CSVReader(filereader); 
				List<String[]> header = csvReader.readAll();
				int rowCount = tableRows.size();
				uiList = new String[rowCount][5];
				String reportDetails[][] = new String[header.size() - 2][5];
				String textValue = null;
				for (int i= 1; i<= rowCount; i++)
				{
					for(int j = 1; j <= 5; j++)
					{
						textValue = driver.findElement(By.xpath("(" + reportTable + ")[" + i + "]/td[" + j + "]")).getText();
						uiList[i-1][j-1] = textValue;
					}
				}
				for (String[] ints : uiList) 
				{
					list_UI.add(Arrays.asList(ints));
				}
				for(int i = 0; i < header.size() - 2; i++)
				{
					String []excel = header.get(i+2);
					for(int j = 0; j <= 4; j++)
					{
						reportDetails[i][j] = excel[j].replace("\"", "").trim();
					}				
				}
				csvReader.close();
				for (String[] ints : reportDetails) {
					list_report.add(Arrays.asList(ints));
				}
				List<List<String>> differences = new ArrayList<>(list_UI);
				differences.removeAll(list_report);
				System.out.println(list_report);
				System.out.println(list_UI);
				Assert.assertTrue(differences.size() == 0);
			}
			catch(Exception e)
			{
				e.printStackTrace();
				Assert.fail(e.getMessage());
			}
		}
		public void getTotalContractAllproduct(String data)
		{
			
				driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

				int m=0;
				val = pageLoad.getAttribute("class");
		        while(val.equalsIgnoreCase("loader"))
		        {
		            val = pageLoad.getAttribute("class");
		            
		            if(m==pagload)
		            	break;
		            m++;
		        }
		        reuse.waitforsec(3);
		
			
			wait.until(ExpectedConditions.visibilityOf(totalContractQuantity));
				Assert.assertEquals(totalContractQuantity.getText(), data);
		}
		public void getTotalConsumedallproduct(String data)
		{
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

			int m=0;
			val = pageLoad.getAttribute("class");
	        while(val.equalsIgnoreCase("loader"))
	        {
	            val = pageLoad.getAttribute("class");
	            
	            if(m==pagload)
	            	break;
	            m++;
	        }
	        reuse.waitforsec(3);
	    	wait.until(ExpectedConditions.visibilityOf(totalConsumedQuantity));
			Assert.assertEquals(totalConsumedQuantity.getText(), data);
		
			
		}

}
