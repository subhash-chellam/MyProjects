package com.qa.pages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.opencsv.CSVReader;
import com.qa.util.TestBase;

public class studentPurchaseHistoryPage  extends TestBase {
	
	@FindBy(xpath = "//*[@id='bs-example-navbar-collapse-1']//a[text()=' Student Purchase History ']")
	WebElement studentPurchaseHistoryPage;

	@FindBy(xpath = "//a[text()='Clear Search']")
	WebElement clearSearch;

	@FindBy(xpath = "//button[@id= 'searchbtn']")
	WebElement searchButton;

	
	@FindBy(xpath = "//a[contains(text(), 'Reports')]")
	WebElement reportLink;

	@FindBy(xpath = "//*[@class = ' table-condensed']//th[@class = 'datepicker-switch']")
	WebElement datePickerSwitch;


	@FindBy(xpath = "//td[text()='No records present.']")
	WebElement noRecords;

	@FindBy(xpath = "//select[@id = 'products']//following-sibling::div/button")
	WebElement productStatusFilter;

	@FindBy(xpath = "//select[@id = 'statusFilter']//following-sibling::div/button")
	WebElement userStatusFilter;

	@FindBy(xpath = "//select[@id = 'purchaseStatus']//following-sibling::div/button")
	WebElement purchaseStatusFilter;
	
	@FindBy(xpath = "//select[@id = 'purchaseFilter']//following-sibling::div/button")
	WebElement purchaseTypeStatusFilter;
	
	@FindBy(xpath = "//*[@id=\"select2-courseId-container\"]")
	WebElement search;

	@FindBy(xpath = "//ul[@id=\"select2-courseId-results\"]/li")
	WebElement searchresult;


	@FindBy(xpath = "//*[@id=\"search\"]")
	WebElement searchbutton;

	@FindBy(xpath = "//input[@id = 'searchbox_name_email']")
	WebElement userSearchInput;
	
	@FindBy(xpath = "//label[@id='inputSearch']")
	WebElement searchText2;

	@FindBy(xpath = "//*[@id='from_start_date']")
	WebElement fromDate;

	@FindBy(xpath = "//div[@id]/a[text()= 'Clear Search']")
	WebElement searchClear;

	@FindBy(xpath = "//*[@id='to_start_date']")
	WebElement toDate;

	@FindBy(xpath = "(//button[@value='Search'])[2]")
	WebElement Button_MoreFilter;
	
	@FindBy(xpath = "//a[text() = 'More Filters ']")
	WebElement moreFilter;

	@FindBy(xpath = "//select[@id = 'statusFilter']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement userUnSelectAll;

	
	@FindBy(xpath = "//label[text() = 'Rows per page ']//select")
	WebElement rowPerPageSelect;

	String pagination = "(//div[@class = 'dataTables_paginate paging_simple_numbers'])";
	
	
	
	String purchaseTableRow = "//table[@id = 'purchase_history_report']//tbody/tr";
	
	String showing = "//*[@class='dataTables_info']";
	
	
	@FindBy(xpath = "//button[@id = 'exportbtn']")
	WebElement exportButton;
	public String downloadPath = System.getProperty("user.dir") + prop.getProperty("downloadPath");
	String fileName,filePath;
	String datePick = "//td[@class='day'  and text() = ";
	
	String reportTable = "//table[@id = 'purchase_history_report']//tbody/tr";
	
	String val;
	String searchTable = "//table[@aria-describedby='purchase_history_report_info']//th"; 
	String row = "//table[@id = 'purchase_history_report']//tbody/tr";
	String userStatus = "(//select[@id = 'statusFilter']//following-sibling::div//ul//label)";
	String purchaseStatus="(//select[@id = 'purchaseStatus']//following-sibling::div//ul//label)";
	String productsStatus="(//select[@id = 'products']//following-sibling::div//ul//label)";
	String purchaseFilter="(//select[@id = 'purchaseFilter']//following-sibling::div//ul//label)";
	String headerxpth="(//*[@aria-describedby='purchase_history_report_info']//tr[@role='row'])[1]/";
	String table="(//*[@id='purchase_history_report']//tr[@role='row'])";
	String tablesmultiple="(//*[@id='purchase_history_report']//tbody//tr[@role='row'])";

	@FindBy(xpath = "//body//div[@class='content body-content']")
	WebElement pageLoad;
	
	@FindBy(xpath = "//table[@id='courseList']//tbody//tr/td")
	WebElement Text_NoReportsDataFound;
	
	JavascriptExecutor js = (JavascriptExecutor)driver;

	public studentPurchaseHistoryPage() 
	{
		PageFactory.initElements(driver, this);
	}

	public void clickOnReportLink()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;


		wait.until(ExpectedConditions.visibilityOf(reportLink));
		wait.until(ExpectedConditions.elementToBeClickable(reportLink));
		try {
			val = pageLoad.getAttribute("class");
			int m=0;
			while(val.contains("loading") || val.contains("loading_user") )
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			js.executeScript("arguments[0].scrollIntoView();",reportLink);

			reportLink.click();
		}
		catch (Exception e) 
		{
			js.executeScript("arguments[0].scrollIntoView();",reportLink);

			reportLink.click();
		}

	}
	
	public void navigatetostudentPurchaseHistoryPage()
	{
		try
		{
			wait.until(ExpectedConditions.visibilityOf(studentPurchaseHistoryPage));
			studentPurchaseHistoryPage.click();

			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

			if(!driver.getCurrentUrl().contains("purchase_history_report"))
			{
				clickOnReportLink();
				wait.until(ExpectedConditions.visibilityOf(studentPurchaseHistoryPage));
				studentPurchaseHistoryPage.click();


			}
			Thread.sleep(18000);
		}
		catch(Exception e)
		{
			js.executeScript("arguments[0].scrollIntoView();",reportLink);

			reportLink.click();
			wait.until(ExpectedConditions.visibilityOf(studentPurchaseHistoryPage));
			studentPurchaseHistoryPage.click();

		}

	}
	public void deleteFile(String path)
	{
		try {
			System.out.println("delete file path is " + path);
			File file = new File(path);
			Thread.sleep(5000);
			file.delete();
			boolean dwnld = false;
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");	
			int counter = 0;
			while(dwnld)
			{
				file = new File(Products.filePath);
				file.delete();
				dwnld = isFileDownloaded_Ext(downloadPath, ".csv");	
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to delete after waiting for 1 minute");
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
	}
	public void clickonClear()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(searchClear));
		searchClear.click();
	}
	public void usersearchEmail(String userEmail)
	{
		try 
		{
			

			//			navigateUserModule();
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchClear));
			wait.until(ExpectedConditions.elementToBeClickable(searchClear));
//			searchClear.click();
			wait.until(ExpectedConditions.visibilityOf(searchText2));
			wait.until(ExpectedConditions.elementToBeClickable(searchText2));
			System.out.println("unit name is " + userEmail);
//			searchText2.sendKeys(userEmail);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", searchText2);
			userSearchInput.sendKeys(userEmail);
			executor.executeScript("arguments[0].click();", searchButton);
			
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			Thread.sleep(10000);
			

		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
	}
	
	public void clickStartDate()
	{
		int counter=0;
		 try
			{
				Thread.sleep(7000);
			}
			catch(Exception e)
			{
					
			}
		
	       
		wait.until(ExpectedConditions.visibilityOf(fromDate));
		wait.until(ExpectedConditions.elementToBeClickable(fromDate));
		
		fromDate.click();
		
	}
	public void selecfromDate()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(datePickerSwitch));
		DateFormat dateFormat = new SimpleDateFormat("d");
		Date date = new Date();
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_MONTH, -14); 
		String formattedStartDate = dateFormat.format(cal.getTime());
		
		String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
		WebElement reqDate ;
		try
		{
		 reqDate = driver.findElement(By.xpath(datePick + "'" + formattedStartDate + "'" + x));
		wait.until(ExpectedConditions.visibilityOf(reqDate));
	    }
	   catch(Exception e)
     	{
		    cal = Calendar.getInstance();
			 formattedStartDate = dateFormat.format(cal.getTime());
			  reqDate = driver.findElement(By.xpath(datePick + "'" + formattedStartDate + "'" + x));
				wait.until(ExpectedConditions.visibilityOf(reqDate));
			    	
	    }
		try
		{
		reqDate.click();
		}
		catch(Exception e)
		{
			reqDate.click();
				
		}
	}
	
	public void clickEndDate()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(toDate));
		toDate.click();
	}
	
	public void selectDate() throws InterruptedException
	{
		WebDriverWait wait = new WebDriverWait(driver, 35);
		wait.until(ExpectedConditions.visibilityOf(datePickerSwitch));
		int date = LocalDate.now().getDayOfMonth();
		String x = " and not(contains(@class, 'disabled day' )) and not(contains(@class, 'old day' ))]";
		WebElement reqDate = driver.findElement(By.xpath(datePick + "'" + date + "'" + x));
		wait.until(ExpectedConditions.visibilityOf(reqDate));
		int counter = 0;
			
        
		try
		{
			Thread.sleep(9000);
		reqDate.click();
		}
		catch(Exception e)
		{
			Thread.sleep(7000);
			reqDate.click();
				
		}
	}
	
	public void Clearsearch()
	{
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(clearSearch));

			clearSearch.click();
			wait.until(ExpectedConditions.visibilityOf(noRecords));
			
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
		
	}
	
	public void validateUserStatusFilterAvailability() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(userStatusFilter));
		userStatusFilter.click();
	}
	
	public void validateProductFilterAvailability() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(productStatusFilter));
		productStatusFilter.click();
	}
	
	
	public void validatepurchaseStatusFilterAvailability() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(purchaseStatusFilter));
		purchaseStatusFilter.click();
	}
	
	public void validatepurchaseTypeFilterAvailability() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(purchaseTypeStatusFilter));
		purchaseTypeStatusFilter.click();
	}

	public void selectMultiUserStatusFilter(String status)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userStatus + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userStatus));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath(userStatus + "//input[contains(@title,'" + status + "')]"));
			boolean flag = elem.isSelected();
			if(flag == false)
				driver.findElement(By.xpath(userStatus + "//input[contains(@title,'" + status + "')]")).click();
		}

	}
	
	public void clickMoreFilter()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(moreFilter));
		moreFilter.click();    
		JavascriptExecutor js = (JavascriptExecutor)driver;
		val = js.executeScript("return document.readyState").toString();
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
		}
	}
	public void selectMultipurchaseStatusFilter(String status)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(purchaseStatus + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(purchaseStatus));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath(purchaseStatus + "//input[contains(@title,'" + status + "')]"));
			boolean flag = elem.isSelected();
			if(flag == false)
				driver.findElement(By.xpath(purchaseStatus + "//input[contains(@title,'" + status + "')]")).click();
		}

	}
	
	public void selectMultipurchaseTypeFilter(String status)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(purchaseFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(purchaseFilter));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath(purchaseFilter + "//input[contains(@title,'" + status + "')]"));
			boolean flag = elem.isSelected();
			if(flag == false)
				driver.findElement(By.xpath(purchaseFilter + "//input[contains(@title,'" + status + "')]")).click();
		}

	}

	public void selectMultiProductFilter(String status)
	{
		if(courseListName.containsKey( status+"Option"))
			status=courseListName.get( status+"Option").toString();

		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(productsStatus + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(productsStatus));
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath(productsStatus + "//input[contains(@title,'" + status + "')]"));
			boolean flag = elem.isSelected();
			if(flag == false)
				driver.findElement(By.xpath(productsStatus + "//input[contains(@title,'" + status + "')]")).click();
		}

	}


	public void SearchButtonMoreFilter() {
		try {
			Thread.sleep(2000);
			Button_MoreFilter.click();
		
		} catch (Exception e) {
		}
	}
	public void unSelectAllStatus()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userUnSelectAll));
			userUnSelectAll.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	public void validateStudentPurchaseHistoryTable(String header,String value)
	{
		System.out.println(header);
		System.out.println(value);
		if(AssignmentReport. checkifParmeterAvailable(value))
			value=AssignmentReport.getParmeterAvailable(value);

		 
		if(header.contains("Transaction Reference Number"))
			value=EndUser.TransactionRefNumber;
		else if(header.contains("User ID"))
			value=User.userId;
		else if(header.contains("Purchase Date & Time"))
		{
			String date=EndUser.OrderDate.split(",")[0].split("/")[2]+"/"+EndUser.OrderDate.split(",")[0].split("/")[0]+"/"+EndUser.OrderDate.split(",")[0].split("/")[1];
			value=date+","+EndUser.OrderDate.split(",")[1];	
		}
	   validatethedetails(header, headerxpth+"th", value, table+"//td","Order ID");
	}
	
	public void validatethedetails(String header,String tableHeader,String value,String tablerow,String EmailHeader)
	{
//		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(tableHeader))));
		List<WebElement> tableRows = driver.findElements(By.xpath(tablerow));
//		System.out.println(tableRows.get(getHeaderPosition(header,tableHeader)-1).getText());
	
		Assert.assertEquals(tableRows.get(getHeaderPosition(EmailHeader,tableHeader)-1).getText(),EndUser.OrderID);
		Assert.assertEquals(tableRows.get(getHeaderPosition(header,tableHeader)-1).getText(), value);
	}

	
	public void validateStudentPurchaseHistoryTablemultiple(String header,String value,String course)
	{
		System.out.println(header);
		System.out.println(value);
		if(AssignmentReport. checkifParmeterAvailable(value))
			value=AssignmentReport.getParmeterAvailable(value);

		 
		if(header.contains("Transaction Reference Number"))
		{
			if(dataMap.containsKey(course+"TransactionRefNumber"))
			{
				value=dataMap.get(course+"TransactionRefNumber")	;
			}
			else
			value=EndUser.TransactionRefNumber;
		}
		else if(header.contains("User ID"))
		{
			value=User.userId;
		}
		else if(header.contains("Purchase Date & Time"))
		{
			String date=EndUser.OrderDate.split(",")[0].split("/")[2]+"/"+EndUser.OrderDate.split(",")[0].split("/")[0]+"/"+EndUser.OrderDate.split(",")[0].split("/")[1];
			value=date+","+EndUser.OrderDate.split(",")[1];	
		}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tablesmultiple))));
		List<WebElement> tableRows = driver.findElements(By.xpath(tablesmultiple));
		boolean flag=false;
		for(int i=1;i<=tableRows.size();i++)
		{
			if(validatethedetailstablesmultiple(header, headerxpth+"th", value, tablesmultiple+"["+i+"]//td","Order ID",course)==true)
			{
				flag=true;
				break;
			}
		}
		Assert.assertTrue("Unable to find transaction"+flag,flag);
		
	}
	
	public boolean validatethedetailstablesmultiple(String header,String tableHeader,String value,String tablerow,String EmailHeader,String course)
	{
//		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(tableHeader))));
		List<WebElement> tableRows = driver.findElements(By.xpath(tablerow));
		boolean flag=false;
//		System.out.println(tableRows.get(getHeaderPosition(header,tableHeader)-1).getText());
		dataMap.get(course+"OrderID");
		if(tableRows.get(getHeaderPosition(EmailHeader,tableHeader)-1).getText().contains(dataMap.get(course+"OrderID")))
		{
		Assert.assertEquals(tableRows.get(getHeaderPosition(EmailHeader,tableHeader)-1).getText(),dataMap.get(course+"OrderID"));
		Assert.assertEquals(tableRows.get(getHeaderPosition(header,tableHeader)-1).getText(), value);
		flag=true;
		
		}
		
		return flag;
	}
	
	
	public void scrollRight()
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
		executor.executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", scrollArea);
	}
	public void scrollLeft()
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
		executor.executeScript("arguments[0].scrollLeft = -arguments[0].offsetWidth", scrollArea);
	}
	
	
	public int getHeaderPosition(String header,String tableHeader)
	{
		

		scrollLeft();
		
		int columnCount = 0;
		try {
			
//			try
//			{			
//		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(tableHeader))));
//			}
//			catch(Exception e)
//			{
//				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableHeader))));
//						
//			}
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableHeader))));
		List<WebElement> tableHeaderRows = driver.findElements(By.xpath(tableHeader));
		for(int i = 1; i <=tableHeaderRows.size(); i++)
		{
			String headerName = driver.findElement(By.xpath(tableHeader + "[" + i +"]")).getText();
			if(headerName.trim().equalsIgnoreCase(header))
			{
				columnCount = i;
				break;				
			}				
		}
		int counter = 0;
		
		while(columnCount == 0) {
			scrollRight();
			Thread.sleep(4000);
//			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableHeader))));
			
	       tableHeaderRows = driver.findElements(By.xpath(tableHeader));
			for(int i = 1; i <=tableHeaderRows.size(); i++)
			{
				String headerName = driver.findElement(By.xpath(tableHeader + "[" + i +"]")).getText();
				if(headerName.trim().equalsIgnoreCase(header))
				{
					columnCount = i;
					break;				
				}				
			}
//			columnCount = getHeaderPosition(header,tableHeader);
			Thread.sleep(2000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load page after waiting for 1 minute"+header);
		}
		System.out.println("The column position for " + header +" is " + columnCount);
		}
		catch(Exception e) {
			e.printStackTrace();
			Assert.fail(tableHeader);
		}
		return columnCount;
	}
	public boolean checkCSVFilePresent()
	{
		boolean dwnld =isFileDownloaded_Ext(downloadPath, ".csv");
		return dwnld;
	}String enableExportButton = "//button[@id = 'exportbtn' and not(contains(@class, 'disabled'))]";
		
	public boolean isFileDownloaded_Ext(String dirPath, String ext){
		boolean flag=false;
	    File dir = new File(dirPath);
	    File[] files = dir.listFiles();
	    if (files != null)
	    {
	    	 for (int i = 0; i < files.length; i++) 
	 	    {
	 	    	if(files[i].getName().contains(ext)&& !(files[i].getName().contains(".crdownload"))) 
	 	    	{
	 	    		fileName = files[i].getName();
	 	    		filePath = files[i].getAbsolutePath();
	 	    		filePath = filePath.replace(".crdownload", "");
	 	//FileReader reader = new FileReader( System.getProperty("user.dir")+prop.getProperty("downloadPath")+"\\coursesName"+prop.getProperty("environment")+".json", StandardCharsets.UTF_8))    		
					flag=true;
	 	    		break;
	 	    	}
	 	    }
	    }
	    
	    return flag;
	}
	public void clickExportButton()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(exportButton));
			int counter = 0;
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			JavascriptExecutor js = (JavascriptExecutor)driver;
			Thread.sleep(5000);


			js.executeScript("arguments[0].click();", exportButton);
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	public void verifyDownloadFile()
	{
		try 
		{
		//	usr = new User();
			int counter = 0;
			boolean dwnld = false;
			do 
			{
				Thread.sleep(5000);
				dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
				counter = counter +1;
				if(counter > 24)
					Assert.fail("Not able to download file");
			}
			while(dwnld == false);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
			System.out.println(e.getMessage());
		}
	}
	public void validatePageNumbers()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(rowPerPageSelect));
		int paginationOption = driver.findElements(By.xpath(pagination)).size();
		System.out.println("Pagination option available on progress report is " + paginationOption);
		Assert.assertTrue(paginationOption == 2);
	}
	
	public void getLocationPageNumber()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(rowPerPageSelect));
		List<WebElement> statusList = driver.findElements(By.xpath(pagination));
		Point location1 = null, location2 = null;
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath(pagination + "[" + i + "]"));
			System.out.println(elem.getLocation());
			if(location1 == null)
				location1 = elem.getLocation();
			else if(location2 == null)
				location2 = elem.getLocation();	
		}
		Assert.assertFalse(location1 == location2);
		int x1 = location1.getX();
		int x2 = location2.getX();
		System.out.println(x1);
		System.out.println(x2);
		
		Assert.assertTrue(x1 == x2);
		
		int y1 = location1.getY();
		int y2 = location2.getY();
		
		System.out.println(y1);
		System.out.println(y2);
		
		Assert.assertFalse(y1 == y2);
	}

	public void validatePaginationDropdown()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(rowPerPageSelect));
		Select select = new Select(rowPerPageSelect);
		List<WebElement> values = select.getOptions();
		for(int i = 0; i <= values.size() - 1; i++)
		{
			int value = Integer.parseInt(values.get(i).getText());
			Assert.assertTrue(value%25 == 0);
		}
	}
	

	public void validateRowCount(int count)
	{
		try {
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		int counter = 0;
		val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_compliance loading_user"))
		{
			val = pageLoad.getAttribute("class");
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load page after waiting for 1 minute");
		}
		Thread.sleep(5000);
		List<WebElement> tableRows = driver.findElements(By.xpath(purchaseTableRow));
		int rowCount = tableRows.size();
		System.out.println(rowCount);
		List<WebElement> showentries = driver.findElements(By.xpath(showing));
		Assert.assertEquals(showentries.size(),2);
		
		Assert.assertEquals("Showing 1 to "+tableRows.size()+" of "+tableRows.size()+" entries",showentries.get(0).getText());
		Assert.assertEquals("Showing 1 to "+tableRows.size()+" of "+tableRows.size()+" entries",showentries.get(1).getText());
		
		
		Assert.assertTrue(rowCount == count || rowCount < count);
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
	}
	
	public void validatefilterdata(String coln,String filterData)
	{
		List<WebElement> showentries = driver.findElements(By.xpath(showing));
		//table[@id = 'purchase_history_report']//tbody/tr//td[text()='Active']
		
		Assert.assertEquals(showentries.size(),2);
		String row=null;	
		int rowcount=0;
		if(coln.contains("USER STATUS"))
		{
			WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
			js.executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", scrollArea);

			for(int i=0;i<filterData.split(",").length;i++)
			{
			row="//table[@id = 'purchase_history_report']//thead//th//following::tbody[1]//tr//td[8][text()='"+filterData.split(",")[i]+"']";;
			reuse.waitforsec(4);
			List<WebElement> elementList= driver.findElements(By.xpath(row));
				if(rowcount==0)
					rowcount=elementList.size();
				else
					rowcount=rowcount+elementList.size();
					
			}
		}
		else if(coln.contains("PRODUCT NAME"))
		{
			for(int i=0;i<filterData.split(",").length;i++)
			{
				String data=filterData.split(",")[i];
				if(courseListName.containsKey( data+"Option"))
					data=courseListName.get( data+"Option").toString();

			row="//table[@id = 'purchase_history_report']//thead//th//following::tbody[1]//tr//td[2][text()='"+data+"']";;
			reuse.waitforsec(4);
			List<WebElement> elementList= driver.findElements(By.xpath(row));
				if(rowcount==0)
					rowcount=elementList.size();
				else
					rowcount=rowcount+elementList.size();
					
			}
		}
		else if(coln.contains("PURCHASE TYPE"))
		{
			WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
			js.executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", scrollArea);


			for(int i=0;i<filterData.split(",").length;i++)
			{
			row="//table[@id = 'purchase_history_report']//thead//th//following::tbody[1]//tr//td[9][text()='"+filterData.split(",")[i]+"']";;
			reuse.waitforsec(4);
			List<WebElement> elementList= driver.findElements(By.xpath(row));
				if(rowcount==0)
					rowcount=elementList.size();
				else
					rowcount=rowcount+elementList.size();
					
			}
		}
		else if(coln.contains("ORDER STATUS"))
		{
			for(int i=0;i<filterData.split(",").length;i++)
			{
			row="//table[@id = 'purchase_history_report']//thead//th//following::tbody[1]//tr//td[12][text()='"+filterData.split(",")[i]+"']";;
			reuse.waitforsec(4);
			List<WebElement> elementList= driver.findElements(By.xpath(row));
				if(rowcount==0)
					rowcount=elementList.size();
				else
					rowcount=rowcount+elementList.size();
					
			}
		}
		
	Assert.assertEquals("Showing 1 to "+rowcount+" of "+rowcount+" entries",showentries.get(0).getText());
	Assert.assertEquals("Showing 1 to "+rowcount+" of "+rowcount+" entries",showentries.get(1).getText());
	
	}
	
	public void selectPaginationDropdown()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(rowPerPageSelect));
		Select select = new Select(rowPerPageSelect);
		List<WebElement> values = select.getOptions();
		for(int i = 0; i <= values.size() - 1; i++)
		{
			int value = Integer.parseInt(values.get(i).getText());
			if(value == 50) {
				values.get(i).click();
				break;
			}
		}
		validateRowCount(50);
	}

	public void compareDetails()
	{
		try
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String  uiList[][];
			int counter = 0;
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(reportTable))));
			List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
			List<List<String>> list_UI = new ArrayList<>();
			List<List<String>> list_report = new ArrayList<>();
			File file = new File(filePath);
			FileReader filereader = new FileReader(file,StandardCharsets.UTF_8);
			CSVReader csvReader = new CSVReader(filereader); 
			List<String[]> header = csvReader.readAll();
			int rowCount = tableRows.size();
			uiList = new String[rowCount][12];
			String reportDetails[][] = new String[header.size() - 3][12];
			for (int i= 1; i<= rowCount; i++)
			{
				for(int j = 1; j <= 12; j++)
				{
					String textValue = driver.findElement(By.xpath("(" + reportTable + ")[" + i + "]/td[" + j + "]")).getText();
					if(j==10) {
						
						 SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd, hh:mm aa");
					       
						String stringDate= textValue;  
						System.out.println(textValue);
						
						
						
						Date date1=formatter.parse(stringDate);  
						System.out.println(date1.toString());
					   
					uiList[i-1][j-1] = formatter.format(date1);
					
					System.err.println("Textvalues : "+ formatter.format(date1));

					}
					else {
						uiList[i-1][j-1] = textValue;
						System.err.println("Textvalues : "+textValue);
						
					}
					
					
				}
			}
			for (String[] ints : uiList) 
			{
				list_UI.add(Arrays.asList(ints));
				
			}
			System.err.println(header.size());
			for(int i = 1; i <=header.size() - 3; i++)
			{
				String []excel = header.get(i+2);
				System.out.println(i);
				System.out.println(header.get(i+2).toString());
				System.out.println(Arrays.toString(header.get(i+2)));
				System.out.println();
				String []excelValues = excel[0].split(";");;
				System.out.println("UI List " +Arrays.toString(list_UI.toArray()));
				for(int j = 0; j < 12; j++)
				{
					System.out.println("excelvalues : "+excelValues[j].replace("\"", "").trim());
					
					reportDetails[i-1][j] = excelValues[j].replace("\"", "").trim();
				}				
			}
			csvReader.close();
			for (String[] ints : reportDetails) {
				list_report.add(Arrays.asList(ints));
			}
			System.out.println("Excel List " +Arrays.toString(list_report.toArray()));
			System.out.println("UI List " +Arrays.toString(list_UI.toArray()));
			
			List<List<String>> differences = new ArrayList<>(list_UI);
			differences.removeAll(list_report);
			System.out.println(Arrays.toString(differences.toArray()));
			Assert.assertTrue(differences.size() == 0);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	public void validatePurchaseCheckSortingEachColumn()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		for(int i = 1; i <= 12; i++)
		{
			ArrayList<String> obtainedList = new ArrayList<>(); 
			//div[@id="courseList_wrapper"]//th
			WebElement column = driver.findElement(By.xpath(searchTable + "[" + i + "]"));
			String coln;
			try
			{
				wait.until(ExpectedConditions.elementToBeClickable(column));
				coln=column.getText();
			}
			catch(Exception e)
			{
				WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
				js.executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", scrollArea);
				wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(searchTable + "[" + i + "]"))));
				coln=column.getText();
			}
			js.executeScript("arguments[0].click()", column);
			val = pageLoad.getAttribute("class");
			int m=0;
			while(val.toLowerCase().contains("loading"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			System.out.println(coln);
//		    if(coln.contains("ORDER ID"))
//		    {
//		    	row="(//*[@aria-describedby='purchase_history_report_info' ])[5]//tbody//tr";
//		    }
//		    else  if(coln.contains("ORDER STATUS")||coln.contains("PURCHASE AMOUNT"))
//		    {
//			    reuse.waitforsec(2);
//
//		    	row="//*[@id='purchase_history_report' ]//tbody/tr";
//		    }
//		    else
//		    	 row = "//table[@id = 'purchase_history_report']//tbody/tr";
		    System.out.println(row);
		    reuse.waitforsec(4);
			List<WebElement> elementList= driver.findElements(By.xpath(row + "/td[" + i + "]"));
			
			for(WebElement we:elementList)
			{
				System.out.println(we.getText());
				
				obtainedList.add(we.getText());
			}
			
			ArrayList<String> sortedList = new ArrayList<>();   
			for(String s:obtainedList){
			sortedList.add(s);
			}
			Collections.sort(sortedList);
			
			System.out.println("Sorted list"+sortedList.toString());
			System.out.println("Obtainted list"+obtainedList);
			
			Assert.assertFalse("No data found", obtainedList.isEmpty());
			
			Assert.assertTrue(sortedList.equals(obtainedList));
			
			js.executeScript("arguments[0].click()", column);
			obtainedList.removeAll(obtainedList);
			val = pageLoad.getAttribute("class");
			m=0;
			while(val.toLowerCase().contains("loading"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			reuse.waitforsec(4);
			
			elementList= driver.findElements(By.xpath(row + "/td[" + i + "]"));
			for(WebElement we:elementList)
			{
			   obtainedList.add(we.getText());
			}
			
			Collections.reverse(sortedList);
			Assert.assertFalse("No data found", obtainedList.isEmpty());
			
			Assert.assertTrue(sortedList.equals(obtainedList));
			
		}
		
	}
	
	public void validateNoReportGenerated()
	{
		WebDriverWait wait = new WebDriverWait(driver, 60);
		val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading"))
		{
			val = pageLoad.getAttribute("class");
		}
		
		
		//wait.until(ExpectedConditions.visibilityOf(progressTableFirstRow));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(reportTable)));
		List<WebElement> columnList = driver.findElements(By.xpath(reportTable + "/td"));
		String text = driver.findElement(By.xpath(reportTable + "/td[1]")).getText();
		System.out.println(text);
		if(columnList.size()>1 || (!text.equalsIgnoreCase("No reports data found.")))
		{
			Assert.fail("Compliance report generated");
			System.err.println("Compliance report generated");
		}        
	}


}
