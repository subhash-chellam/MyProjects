package com.qa.pages;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.qa.util.TestBase;

public class CourseManagement extends TestBase
{
	@FindBy(xpath = "//input[@name = 'coursesearchkey']")
	WebElement nameSearchBox;
	
	@FindBy(xpath = "//table[@id = 'instructor-table']/tbody/tr/td[5]")
	WebElement courseEvaluation;
	
	
	
	
	@FindBy(xpath = "//*[@id=\"editcourse\"]//a[contains(text(),'Cancel')]")
	WebElement courseCancel;
	

	@FindBy(xpath = "//*[@id='menu_course']/a")
	WebElement courseMgmt;

	
	@FindBy(xpath = "//*[@id=\"menu_course\"]//li//a[text()='Course Management']")
	WebElement courseMmt;

	@FindBy(xpath = "//*[@name=\"coursesearchkey\"]")
	WebElement courseSearch;

	@FindBy(xpath = "//button[@type=\"submit\"]")
	WebElement searchButton;

	@FindBy(xpath = "//*/a[@title='Edit course']/em")
	WebElement editCourse;
	
	@FindBy(xpath = "//a[text()='URL']")
	WebElement URL;
	
	@FindBy(xpath = "//*[@class=\"removeButton\"]")
	WebElement removeButton;
	
	@FindBy(xpath = "//a[text()='Add URL']")
	WebElement addUrl;
	
	@FindBy(xpath = "//*[@id=\"url_1\"]")
	WebElement urlsend;
	
	@FindBy(xpath = "//select[@name=\"statusfilter\"]")
	WebElement statusfilter;
	
	
	@FindBy(xpath = "//a[text()='Edit Course']")
	WebElement EditC;
	
	
	
	
	
	@FindBy(xpath = "//*[@id=\"urlManagement\"]//input[@value='Save']")
	WebElement saveBtn;
	
	
	
	@FindBy(xpath = "//*[@class=\"success-message\"]")
	WebElement successMsg;
	
	@FindBy(xpath = "//a[text()='Course Topics']")
	WebElement courseTopics;
	
	@FindBy(xpath = "//input[@value='Edit']")
	WebElement actionEdit;
	

	@FindBy(xpath = "//*[@id='ltiUpdateForm']//input[@name='mode'][1]")
	WebElement productionMode;
	@FindBy(xpath = "//*[@id='ltiUpdateForm']//input[@name='mode'][2]")
	WebElement testMode;
	
	@FindBy(xpath = "//*[@id='validationInput']")
	WebElement save;
	
	@FindBy(xpath = "//a[text()='Create Course']")
	WebElement createCourse;
	
	@FindBy(xpath = "//div[text()='Student Purchase Available?']//following::div//input[@name='student_purchase']")
	List<WebElement>  StudentPurchaseRadioBtn;

	
	@FindBy(xpath = "//*[@id='addNewCourse']//select[@name='product_type_id']")
	WebElement createType;
	
	@FindBy(xpath = "//*[@id='addNewCourse']//input[@name='course_name']")
	WebElement createName;
	
	@FindBy(xpath = "//*[@id='addNewCourse']//input[@name='course_code']")
	WebElement createCode;
	
	@FindBy(xpath = "//*[@id='addNewCourse']//input[@name='max_quantity']")
	WebElement max_quantity;
	
	@FindBy(xpath = "//*[@id='intern_course_yes']")
	WebElement intern_course_yes;
	
	@FindBy(xpath = "//*[@id='intern_course_no']")
	WebElement intern_course_no;
	
	
	
	@FindBy(xpath = "(//*[@id='languageId_9'])[2]")
	WebElement english;
	
	@FindBy(xpath = "(//*[@id='languageId_15'])[1]")
	WebElement German;
	
	
	@FindBy(xpath = "//*[@id='addNewCourse']//input[@name='course_run_time']")
	WebElement runtime;
	
	@FindBy(xpath = "//*[@id='addNewCourse']//select[@name='is_perpetual']")
	WebElement is_perpetual;
	
	@FindBy(xpath = "//*[@id='addNewCourse']//select[@name='vendor_id']")
	WebElement courseProvider;
	
	@FindBy(xpath = "//*[@id='addNewCourse']//select[@name='course_primary_category']")
	WebElement primaryCategory;
	
	@FindBy(xpath = "//*[@id='addNewCourse']//select[@name='product_type_id']")
	WebElement courseType;
	
	
	@FindBy(xpath = "//*[@id='courseNameInput']")
	WebElement courseNameInput;
	
	@FindBy(xpath = "//select[@name = 'course_type']")
	WebElement courseModuleType;
	
	


	@FindBy(xpath = "//input[@name='student_purchase' and @value='1']")
	WebElement studentPayYes;
	
	
	@FindBy(xpath = "//*[@id='saveCoursebtn']")
	WebElement saveCoursebtn;
	
	@FindBy(xpath = "//*[@id=\"addCourseModel\"]//button[text()='Cancel']")
	WebElement CancelCoursebtn;
	
	
	@FindBy(xpath = "(//body[@id]/p)[1]")
	WebElement courseLanguageDescriptionText;
	
	@FindBy(xpath = "//*[@id='saveShortDescrbtn']")
	WebElement saveShortDescrbtn;

	@FindBy(xpath = "//*[@id='saveLongDescrbtn']")
	WebElement saveLongDescrbtn;
	
	@FindBy(xpath = "//*[@id='saveLaunchDescrbtn']")
	WebElement saveLaunchDescrbtn;
	
	@FindBy(xpath = "//*[@id='saveTermsandcondbtn']")
	WebElement saveTermsandcondbtn;
	
	@FindBy(xpath = "//*[@name='makeDefaultLang']")
	WebElement makeDefaultLang;
	
	
	
	//*[@id="saveShortDescrbtn"]
	@FindBy(xpath = "//*[@id=\"shortdescription_bold\"]/span[1]")
	WebElement bold;
	
	@FindBy(xpath = "//*[@id=\"shortdescription_strikethrough\"]/span[1]")
	WebElement shortdescription_strikethrough;
	
	@FindBy(xpath = "//*[@id=\"shortdescription_underline\"]/span[1]")
	WebElement shortdescription_underline;
	
	
	@FindBy(xpath = "//input[@name = 'course_run_time']")
	WebElement courseRunTime;
	
	@FindBy(xpath = "//*[@id=\"longdescription_bold\"]/span[1]")
	WebElement longdescription_bold;
	
	
	@FindBy(xpath = "//*[@id=\"longdescription_strikethrough\"]/span[1]")
	WebElement longdescription_strikethrough;
	
	@FindBy(xpath = "//*[@id=\"longdescription_underline\"]/span[1]")
	WebElement longdescription_underline;
	

	@FindBy(xpath = "//*[@id=\"launchdescription_bold\"]/span[1]")
	WebElement launchdescription_bold;
	
	
	@FindBy(xpath = "//*[@id=\"launchdescription_underline\"]/span[1]")
	WebElement launchdescription_underline;
	
	@FindBy(xpath = "//*[@id=\"launchdescription_strikethrough\"]/span[1]")
	WebElement launchdescription_strikethrough;
	
	
	@FindBy(xpath = "//*[@id=\"termsandcond_bold\"]/span[1]")
	WebElement termsandcond_bold;
	
	
	@FindBy(xpath = "//*[@id=\"termsandcond_underline\"]/span[1]")
	WebElement termsandcond_underline;
	
	@FindBy(xpath = "//*[@id=\"termsandcond_strikethrough\"]/span[1]")
	WebElement termsandcond_strikethrough;
	
	
	String courseEditRow = "//table[@id = 'instructor-table']//tbody/tr";

	@FindBy(xpath = "//*[@id='submitBtn']")
	WebElement submitBtn;
	
	
	public static String courseDeleteXpath="')]/parent::tr/td//a[@title='Delete course']/em",evaluationStatus,courseFrontXpath="//td[contains(text(),'",courseNameValue,courseEditXpath="')]/parent::tr/td//a[@title='Edit course']/em";
	
	public CourseManagement() 
	{
		PageFactory.initElements(driver, this);
	}

	public void searchCourseByName(String name)
	{

		if(courseListName.containsKey(name+"Option"))
			name=courseListName.get(name+"Option").toString();
			
	
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOf(nameSearchBox));
		nameSearchBox.clear();
		nameSearchBox.sendKeys(name);
		
        wait.until(ExpectedConditions.visibilityOf(statusfilter));
		
		statusfilter.click();
		
		Select drptime = new Select(statusfilter);
		drptime.selectByVisibleText("All Courses");;

	}
	
	
	public void openCourseDetails(String courseName) {
		if(courseListName.containsKey(courseName))
			courseName=courseListName.get(courseName).toString();
	

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseEditRow))));
		courseName = courseName.replaceAll("registered", "\u00AE");
		List<WebElement> courseList = driver.findElements(By.xpath(courseEditRow));
		boolean flag = false;
		for(int i = 1; i <= courseList.size(); i++) {
			String text = driver.findElement(By.xpath(courseEditRow + "[" + i + "]/td[1]")).getText();
			if(text.equalsIgnoreCase(courseName)) {
				driver.findElement(By.xpath(courseEditRow + "[" + i + "]/td[8]/a/em")).click();
				flag = true;
				break;
			}
		}
		if(flag == false)
			Assert.fail("course name not found " + courseName );
	
	}

	
	

	public void DeleteCourse(String course)
	{

		if(courseListName.containsKey(course))
			course=courseListName.get(course).toString();
	
		//td[contains(text(),'RQI BLS Entry 2025 (2025BLSEntry)
		try
		{
		Thread.sleep(5000);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseFrontXpath+course+courseDeleteXpath))));
		System.out.println(courseFrontXpath+course+courseDeleteXpath);
		driver.findElement(By.xpath(courseFrontXpath+course+courseDeleteXpath)).click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());	
		}
		
	}
	
	public void editCourse(String course)
	{

		if(courseListName.containsKey(course))
			course=courseListName.get(course).toString();
	
		//td[contains(text(),'RQI BLS Entry 2025 (2025BLSEntry)
		try
		{
		Thread.sleep(7000);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseFrontXpath+course+courseEditXpath))));
		System.out.println(courseFrontXpath+course+courseEditXpath);
		driver.findElement(By.xpath(courseFrontXpath+course+courseEditXpath)).click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());	
		}
		
	}
	public void coursemode(String mode) throws InterruptedException
	{
		wait.until(ExpectedConditions.visibilityOf(courseTopics));
		courseTopics.click();
		wait.until(ExpectedConditions.visibilityOf(actionEdit));
		actionEdit.click();
		Thread.sleep(4000);
		if(mode.contains("Production"))
		{
			wait.until(ExpectedConditions.visibilityOf(productionMode));
			productionMode.click();
		}
		else
		{
			wait.until(ExpectedConditions.visibilityOf(testMode));
			testMode.click();
				
		}
		try
		{
			
		wait.until(ExpectedConditions.visibilityOf(save));
		save.click();
		}
		catch(Exception e)
		{
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			
			executor.executeScript("arguments[0].click();", save);
		
				
		}
	}
	
	public void courseEvaluationStatus()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(courseEvaluation));
		evaluationStatus = courseEvaluation.getText();
	}

	public void courseaddurl(String course,String url)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
		
		course = course.replace("Â", "");
		
		 if(AssignmentReport. checkifParmeterAvailable(url))
			 url=AssignmentReport.getParmeterAvailable(url);
		
		
		wait.until(ExpectedConditions.visibilityOf(courseMgmt));
		courseMgmt.click();
		wait.until(ExpectedConditions.visibilityOf(courseMmt));
		courseMmt.click();
		wait.until(ExpectedConditions.visibilityOf(courseSearch));
		courseSearch.sendKeys(course);
		
		wait.until(ExpectedConditions.visibilityOf(statusfilter));
		
		statusfilter.click();
		
		Select drptime = new Select(statusfilter);
		drptime.selectByVisibleText("All Courses");;
		
		wait.until(ExpectedConditions.visibilityOf(searchButton));
		searchButton.click();
		
		wait.until(ExpectedConditions.visibilityOf(editCourse));
		editCourse.click();
		
		wait.until(ExpectedConditions.visibilityOf(URL));
		URL.click();
		
		try
		{
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOf(removeButton));
			removeButton.click();
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOf(saveBtn));
			saveBtn.click();
			
//			wait.until(ExpectedConditions.visibilityOf(successMsg));
			wait.until(ExpectedConditions.visibilityOf(EditC));
			EditC.click();
			
			wait.until(ExpectedConditions.visibilityOf(URL));
			URL.click();
			
			
		}
		catch(Exception e)
		{
			wait.until(ExpectedConditions.visibilityOf(addUrl));
			addUrl.click();
			System.out.println(e.getMessage());
		}
	
	
		
		wait.until(ExpectedConditions.visibilityOf(urlsend));
		
		for(int i=0;i<url.length();i++)
		urlsend.sendKeys(String.valueOf(url.charAt(i)));
		
		urlsend.sendKeys("\t");
		try
		{
			Thread.sleep(5000);
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		wait.until(ExpectedConditions.visibilityOf(saveBtn));
		saveBtn.click();
		
		wait.until(ExpectedConditions.visibilityOf(successMsg));
		
		
	
	}
	public void clickCreateCourse()
	{
		wait.until(ExpectedConditions.visibilityOf(createCourse));
		createCourse.click();
	}
	
	public void validateStudentPurchaseRadioBtn()
	{
		wait.until(ExpectedConditions.visibilityOfAllElements(StudentPurchaseRadioBtn));
		
		System.out.println(StudentPurchaseRadioBtn.size());
		System.out.println(StudentPurchaseRadioBtn.get(0).getAttribute("checked"));
		
		System.out.println(StudentPurchaseRadioBtn.get(1).getAttribute("checked"));
		
		Assert.assertTrue("Default NO should be selected for allow student pay option",Boolean.valueOf(StudentPurchaseRadioBtn.get(1).getAttribute("checked")));
		
		System.out.println(driver.findElement(By.xpath("(//div[text()='Student Purchase Available?']//following::div)[1]")).getText().split("   ")[0]);
		System.out.println(driver.findElement(By.xpath("(//div[text()='Student Purchase Available?']//following::div)[1]")).getText().split("   ")[1]);
		
		System.out.println(driver.findElement(By.xpath("(//div[text()='Student Purchase Available?']//following::div)[1]")).getText());
		Assert.assertEquals(driver.findElement(By.xpath("(//div[text()='Student Purchase Available?']//following::div)[1]")).getText().split("   ")[1], "No");
		Assert.assertEquals(StudentPurchaseRadioBtn.size(), 2);

	}
	
	public void validateStudentPurchaseRadioBtnisYes()
	{
		wait.until(ExpectedConditions.visibilityOfAllElements(StudentPurchaseRadioBtn));
		
		System.out.println(StudentPurchaseRadioBtn.size());
		System.out.println(StudentPurchaseRadioBtn.get(0).getAttribute("checked"));
		
		System.out.println(StudentPurchaseRadioBtn.get(1).getAttribute("checked"));
		
		Assert.assertTrue("Default NO should be selected for allow student pay option",Boolean.valueOf(StudentPurchaseRadioBtn.get(0).getAttribute("checked")));
		
		System.out.println(driver.findElement(By.xpath("(//div[text()='Student Purchase Available?']//following::div)[1]")).getText().split("   ")[0]);
		System.out.println(driver.findElement(By.xpath("(//div[text()='Student Purchase Available?']//following::div)[1]")).getText().split("   ")[1]);
		
		System.out.println(driver.findElement(By.xpath("(//div[text()='Student Purchase Available?']//following::div)[1]")).getText());
		Assert.assertEquals(driver.findElement(By.xpath("(//div[text()='Student Purchase Available?']//following::div)[1]")).getText().split("   ")[0], "Yes");
		Assert.assertEquals(StudentPurchaseRadioBtn.size(), 2);

	}
	
	public void createCourseNLN(String primaryCat,String courseModule ) throws InterruptedException
	{
		wait.until(ExpectedConditions.visibilityOf(createCourse));
		createCourse.click();
		wait.until(ExpectedConditions.visibilityOf(createType));


		String date = new java.util.Date().toString();
		date = date.replace(" ", "");
		courseNameValue = "course_"+date;

		
		Select select = new Select(courseType);
		select.selectByVisibleText("Curriculum");
		
		wait.until(ExpectedConditions.visibilityOf(createName));
		createName.sendKeys(courseNameValue);

		wait.until(ExpectedConditions.visibilityOf(createCode));
		createCode.sendKeys(courseNameValue);

		wait.until(ExpectedConditions.visibilityOf(max_quantity));
		max_quantity.sendKeys("5");

		wait.until(ExpectedConditions.visibilityOf(intern_course_no));
		intern_course_no.click();

		wait.until(ExpectedConditions.visibilityOf(english));
		english.click();

//		wait.until(ExpectedConditions.visibilityOf(German));
//		German.click();

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("( //*[contains(@id,'addCourseLink')])[1]"))));
		driver.findElement(By.xpath("( //*[contains(@id,'addCourseLink')])[1]")).click();

		wait.until(ExpectedConditions.visibilityOf(courseNameInput));
		courseNameInput.sendKeys("courseNameInput"+date);
		
		wait.until(ExpectedConditions.visibilityOf(saveCoursebtn));
		saveCoursebtn.click();

		//////////////////////////////////////////////////shortdescription/////////////////////////////////////////////////////////////////////

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("( //*[contains(@id,'addShortDescLink')])[1]"))));
		driver.findElement(By.xpath("( //*[contains(@id,'addShortDescLink')])[1]")).click();

		wait.until(ExpectedConditions.visibilityOf(bold));
		bold.click();

		driver.switchTo().frame("shortdescription_ifr");

		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		courseLanguageDescriptionText.sendKeys("shortdescriptionBold"+date);

		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(shortdescription_strikethrough));

		//shortdescription_strikethrough.click();

		driver.switchTo().frame("shortdescription_ifr");

		courseLanguageDescriptionText.sendKeys(" shortdescriptionstrikethrough"+date);


		driver.switchTo().defaultContent();


		//shortdescription_strikethrough.click();

		//shortdescription_underline.click();

		driver.switchTo().frame("shortdescription_ifr");

		courseLanguageDescriptionText.sendKeys(" shortdescriptionunderline"+date);

		System.out.println(driver.getPageSource());

		System.err.println(courseLanguageDescriptionText.getText());

		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(saveShortDescrbtn));
		saveShortDescrbtn.click();
		Thread.sleep(5000);
//		wait.until(ExpectedConditions.visibilityOf(makeDefaultLang));
//		makeDefaultLang.click();
		
		courseRunTime.click();
		courseRunTime.clear();
		courseRunTime.sendKeys("2");

		 select = new Select(is_perpetual);
		select.selectByVisibleText("Regular");
		
		select = new Select(courseProvider);
		select.selectByVisibleText("Laerdal");
		
		select = new Select(primaryCategory);
		select.selectByVisibleText(primaryCat);


		wait.until(ExpectedConditions.visibilityOf(courseModuleType));
		 select = new Select(courseModuleType);
		select.selectByVisibleText(courseModule);
		
		wait.until(ExpectedConditions.visibilityOf(studentPayYes));
		
		studentPayYes.click();
	
		wait.until(ExpectedConditions.visibilityOf(submitBtn));
		submitBtn.click();

		//*[@id='longdescription_bold']


	}
	
	public void createCourse(String primaryCat,String courseModule ) throws InterruptedException
	{
		wait.until(ExpectedConditions.visibilityOf(createCourse));
		createCourse.click();
		wait.until(ExpectedConditions.visibilityOf(createType));


		String date = new java.util.Date().toString();
		date = date.replace(" ", "");
		courseNameValue = "course_"+date;

		wait.until(ExpectedConditions.visibilityOf(createName));
		createName.sendKeys(courseNameValue);

		wait.until(ExpectedConditions.visibilityOf(createCode));
		createCode.sendKeys(courseNameValue);

		wait.until(ExpectedConditions.visibilityOf(max_quantity));
		max_quantity.sendKeys("5");

		wait.until(ExpectedConditions.visibilityOf(intern_course_yes));
		intern_course_yes.click();

		wait.until(ExpectedConditions.visibilityOf(english));
		english.click();

//		wait.until(ExpectedConditions.visibilityOf(German));
//		German.click();

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("( //*[contains(@id,'addCourseLink')])[1]"))));
		driver.findElement(By.xpath("( //*[contains(@id,'addCourseLink')])[1]")).click();

		wait.until(ExpectedConditions.visibilityOf(courseNameInput));
		courseNameInput.sendKeys("courseNameInput"+date);
		
		wait.until(ExpectedConditions.visibilityOf(saveCoursebtn));
		saveCoursebtn.click();

//////////////////////////////////////////////////shortdescription/////////////////////////////////////////////////////////////////////

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("( //*[contains(@id,'addShortDescLink')])[1]"))));
		driver.findElement(By.xpath("( //*[contains(@id,'addShortDescLink')])[1]")).click();

		wait.until(ExpectedConditions.visibilityOf(bold));
		bold.click();

		driver.switchTo().frame("shortdescription_ifr");

		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		courseLanguageDescriptionText.sendKeys("shortdescriptionBold"+date);

		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(shortdescription_strikethrough));

//		shortdescription_strikethrough.click();

		driver.switchTo().frame("shortdescription_ifr");

		courseLanguageDescriptionText.sendKeys(" shortdescriptionstrikethrough"+date);


		driver.switchTo().defaultContent();


//		shortdescription_strikethrough.click();

//		shortdescription_underline.click();

		driver.switchTo().frame("shortdescription_ifr");

		courseLanguageDescriptionText.sendKeys(" shortdescriptionunderline"+date);

		System.out.println(driver.getPageSource());

		System.err.println(courseLanguageDescriptionText.getText());

		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(saveShortDescrbtn));
		saveShortDescrbtn.click();
//////////////////////////////////////////////////longdescription/////////////////////////////////////////////////////////////////////
		
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("( //*[contains(@id,'addLongDescLink')])[1]"))));
		driver.findElement(By.xpath("( //*[contains(@id,'addLongDescLink')])[1]")).click();

		wait.until(ExpectedConditions.visibilityOf(longdescription_bold));
		longdescription_bold.click();

		driver.switchTo().frame("longdescription_ifr");


		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		courseLanguageDescriptionText.sendKeys("longdescriptionbold"+date);

		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(longdescription_strikethrough));
		longdescription_strikethrough.click();

		driver.switchTo().frame("longdescription_ifr");

		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		courseLanguageDescriptionText.sendKeys(" longdescriptionstrikethrough"+date);

//		System.out.println(driver.getPageSource());

		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(longdescription_strikethrough));
		longdescription_strikethrough.click();

		wait.until(ExpectedConditions.visibilityOf(longdescription_underline));
//		longdescription_underline.click();

		driver.switchTo().frame("longdescription_ifr");

		
		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		courseLanguageDescriptionText.sendKeys(" longdescriptionunderline"+date);

		System.err.println(courseLanguageDescriptionText.getText());

		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(saveLongDescrbtn));
		saveLongDescrbtn.click();

//////////////////////////////////////////////////Launch Page Description/////////////////////////////////////////////////////////////////////
	
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("( //*[contains(@id,'addLaunchDescLink')])[1]"))));
		driver.findElement(By.xpath("( //*[contains(@id,'addLaunchDescLink')])[1]")).click();

		wait.until(ExpectedConditions.visibilityOf(launchdescription_bold));
		launchdescription_bold.click();

		driver.switchTo().frame("launchdescription_ifr");


		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		courseLanguageDescriptionText.sendKeys("launchdescriptionbold"+date);


		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(launchdescription_strikethrough));
		launchdescription_strikethrough.click();

		driver.switchTo().frame("launchdescription_ifr");

		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		courseLanguageDescriptionText.sendKeys(" launchdescriptionstrikethrough"+date);

//		System.out.println(driver.getPageSource());

		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(launchdescription_strikethrough));
		launchdescription_strikethrough.click();

		wait.until(ExpectedConditions.visibilityOf(launchdescription_underline));
//		launchdescription_underline.click();

		driver.switchTo().frame("launchdescription_ifr");

		
		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		courseLanguageDescriptionText.sendKeys(" launchdescriptionnunderline"+date);

		System.err.println(courseLanguageDescriptionText.getText());
		
		
		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(saveLaunchDescrbtn));
		saveLaunchDescrbtn.click();


		//////////////////////////////////////////////////terms and cond/////////////////////////////////////////////////////////////////////

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("( //*[contains(@id,'addTermAndCondLink')])[1]"))));
		driver.findElement(By.xpath("( //*[contains(@id,'addTermAndCondLink')])[1]")).click();

		wait.until(ExpectedConditions.visibilityOf(termsandcond_bold));
		termsandcond_bold.click();

		driver.switchTo().frame("termsandcond_ifr");


		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		courseLanguageDescriptionText.sendKeys("termsandcondbold"+date);

		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(termsandcond_strikethrough));
		termsandcond_strikethrough.click();

		driver.switchTo().frame("termsandcond_ifr");

		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		courseLanguageDescriptionText.sendKeys(" termsandcondstrikethrough"+date);

		//System.out.println(driver.getPageSource());

		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(termsandcond_strikethrough));
		termsandcond_strikethrough.click();

		wait.until(ExpectedConditions.visibilityOf(termsandcond_underline));
//		termsandcond_underline.click();

		driver.switchTo().frame("termsandcond_ifr");


		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		courseLanguageDescriptionText.sendKeys(" termsandcondnunderline"+date);

		System.err.println(courseLanguageDescriptionText.getText());

		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(saveTermsandcondbtn));
		saveTermsandcondbtn.click();

		Thread.sleep(5000);
		wait.until(ExpectedConditions.visibilityOf(makeDefaultLang));
		makeDefaultLang.click();
		
		courseRunTime.click();
		courseRunTime.clear();
		courseRunTime.sendKeys("1");

		Select select = new Select(is_perpetual);
		select.selectByVisibleText("Regular");
		
		select = new Select(courseProvider);
		select.selectByVisibleText("Laerdal");
		
		select = new Select(primaryCategory);
		select.selectByVisibleText(primaryCat);


		wait.until(ExpectedConditions.visibilityOf(courseModuleType));
		 select = new Select(courseModuleType);
		select.selectByVisibleText(courseModule);
		
	
		wait.until(ExpectedConditions.visibilityOf(submitBtn));
		submitBtn.click();

		//*[@id='longdescription_bold']


	}
	
	public void validateCourseDetails( )
	{
		
//		German.click();

		String date=courseNameValue.replace("course_","");
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("( //*[contains(@id,'addCourseLink')])[1]"))));
		driver.findElement(By.xpath("( //*[contains(@id,'addCourseLink')])[1]")).click();

		wait.until(ExpectedConditions.visibilityOf(courseNameInput));
System.out.println("testt"+courseNameInput.getAttribute("value"));
		Assert.assertEquals("Course Name input in correct"+courseNameInput.getAttribute("value"),courseNameInput.getAttribute("value"),"courseNameInput"+date);
		wait.until(ExpectedConditions.visibilityOf(CancelCoursebtn));
		CancelCoursebtn.click();

//////////////////////////////////////////////////shortdescription/////////////////////////////////////////////////////////////////////

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("( //*[contains(@id,'addShortDescLink')])[1]"))));
		driver.findElement(By.xpath("( //*[contains(@id,'addShortDescLink')])[1]")).click();

		
		driver.switchTo().frame("shortdescription_ifr");

		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		
		Assert.assertTrue("shortdescription is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("shortdescriptionBold"+date));
	
		Assert.assertTrue("shortdescription is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("shortdescriptionstrikethrough"+date));
		
		Assert.assertTrue("shortdescription is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("shortdescriptionunderline"+date));
		
        Assert.assertTrue("shortdescription CSS styple is incorrect "+driver.findElement(By.xpath("//p/strong/span[1]")).getCssValue("text-decoration"),driver.findElement(By.xpath("//p/strong/span[1]")).getCssValue("text-decoration").contains("line-through"));
		
		Assert.assertTrue("shortdescription CSS styple is incorrect "+driver.findElement(By.xpath("//p/strong/span[2]")).getCssValue("text-decoration"),driver.findElement(By.xpath("//p/strong/span[2]")).getCssValue("text-decoration").contains("underline"));
		System.out.println(driver.findElement(By.xpath("//*[@id]/p//strong/span")).getText());
		
		
		System.out.println(driver.getPageSource());
		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(saveShortDescrbtn));
		saveShortDescrbtn.click();
//////////////////////////////////////////////////longdescription/////////////////////////////////////////////////////////////////////
		
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("( //*[contains(@id,'addLongDescLink')])[1]"))));
		driver.findElement(By.xpath("( //*[contains(@id,'addLongDescLink')])[1]")).click();


		driver.switchTo().frame("longdescription_ifr");

		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		
		
		Assert.assertTrue("longdescription is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("longdescriptionbold"+date));
		
		Assert.assertTrue("longdescription is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("longdescriptionstrikethrough"+date));
		
		Assert.assertTrue("longdescription is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("longdescriptionunderline"+date));
		
		
	
		  Assert.assertTrue("longdescription CSS styple is incorrect "+driver.findElement(By.xpath("//p/strong/span[1]")).getCssValue("text-decoration"),driver.findElement(By.xpath("//p/strong/span[1]")).getCssValue("text-decoration").contains("line-through"));
			
			Assert.assertTrue("longdescription CSS styple is incorrect "+driver.findElement(By.xpath("//p/strong/span[2]")).getCssValue("text-decoration"),driver.findElement(By.xpath("//p/strong/span[2]")).getCssValue("text-decoration").contains("underline"));
			System.out.println(driver.findElement(By.xpath("//*[@id]/p//strong/span")).getText());
			
		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(saveLongDescrbtn));
		saveLongDescrbtn.click();

//////////////////////////////////////////////////Launch Page Description/////////////////////////////////////////////////////////////////////
	
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("( //*[contains(@id,'addLaunchDescLink')])[1]"))));
		driver.findElement(By.xpath("( //*[contains(@id,'addLaunchDescLink')])[1]")).click();

		
		driver.switchTo().frame("launchdescription_ifr");
		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		
		

       Assert.assertTrue("launchdescription is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("launchdescriptionbold"+date));
		
		Assert.assertTrue("launchdescription is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("launchdescriptionstrikethrough"+date));
		
		Assert.assertTrue("launchdescription is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("launchdescriptionnunderline"+date));
		  Assert.assertTrue("launchdescription CSS styple is incorrect "+driver.findElement(By.xpath("//p/strong/span[1]")).getCssValue("text-decoration"),driver.findElement(By.xpath("//p/strong/span[1]")).getCssValue("text-decoration").contains("line-through"));
			
			Assert.assertTrue("launchdescription CSS styple is incorrect "+driver.findElement(By.xpath("//p/strong/span[2]")).getCssValue("text-decoration"),driver.findElement(By.xpath("//p/strong/span[2]")).getCssValue("text-decoration").contains("underline"));
			System.out.println(driver.findElement(By.xpath("//*[@id]/p//strong/span")).getText());
	
		
	
		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(saveLaunchDescrbtn));
		saveLaunchDescrbtn.click();


		//////////////////////////////////////////////////terms and cond/////////////////////////////////////////////////////////////////////

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("( //*[contains(@id,'addTermAndCondLink')])[1]"))));
		driver.findElement(By.xpath("( //*[contains(@id,'addTermAndCondLink')])[1]")).click();

	
		driver.switchTo().frame("termsandcond_ifr");

		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		
		
		   Assert.assertTrue("addTermAndCond is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("termsandcondbold"+date));
			
			Assert.assertTrue("addTermAndCond is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("termsandcondstrikethrough"+date));
			
			Assert.assertTrue("addTermAndCond is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("termsandcondnunderline"+date));
			  Assert.assertTrue("addTermAndCond CSS styple is incorrect "+driver.findElement(By.xpath("//p/strong/span[1]")).getCssValue("text-decoration"),driver.findElement(By.xpath("//p/strong/span[1]")).getCssValue("text-decoration").contains("line-through"));
				
				Assert.assertTrue("addTermAndCond CSS styple is incorrect "+driver.findElement(By.xpath("//p/strong/span[2]")).getCssValue("text-decoration"),driver.findElement(By.xpath("//p/strong/span[2]")).getCssValue("text-decoration").contains("underline"));
				System.out.println(driver.findElement(By.xpath("//*[@id]/p//strong/span")).getText());
			
			
		
		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(saveTermsandcondbtn));
		saveTermsandcondbtn.click();
		wait.until(ExpectedConditions.visibilityOf(submitBtn));
		submitBtn.click();


	}
	
	
	public void updateCourse( )
	{
	

//		wait.until(ExpectedConditions.visibilityOf(German));
//		German.click();

		String date=courseNameValue.replace("course_","");

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("( //*[contains(@id,'addCourseLink')])[1]"))));
		driver.findElement(By.xpath("( //*[contains(@id,'addCourseLink')])[1]")).click();

		wait.until(ExpectedConditions.visibilityOf(courseNameInput));
		courseNameInput.clear();
		courseNameInput.sendKeys("courseNameInputupdate"+date);
		
		wait.until(ExpectedConditions.visibilityOf(saveCoursebtn));
		saveCoursebtn.click();

//////////////////////////////////////////////////shortdescription/////////////////////////////////////////////////////////////////////

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("( //*[contains(@id,'addShortDescLink')])[1]"))));
		driver.findElement(By.xpath("( //*[contains(@id,'addShortDescLink')])[1]")).click();

//		wait.until(ExpectedConditions.visibilityOf(shortdescription_strikethrough));
//		
//		shortdescription_strikethrough.click();
//
//		shortdescription_underline.click();
		
		
		driver.switchTo().frame("shortdescription_ifr");

		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		courseLanguageDescriptionText.clear();

		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(bold));
		bold.click();
		driver.switchTo().frame("shortdescription_ifr");
	
		courseLanguageDescriptionText.sendKeys("shortdescriptionupdateBold"+date);

		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(shortdescription_strikethrough));

		shortdescription_strikethrough.click();

		driver.switchTo().frame("shortdescription_ifr");

		courseLanguageDescriptionText.sendKeys(" shortdescriptionupdatestrikethrough"+date);


		driver.switchTo().defaultContent();


		shortdescription_strikethrough.click();

		shortdescription_underline.click();

		driver.switchTo().frame("shortdescription_ifr");

		courseLanguageDescriptionText.sendKeys(" shortdescriptionupdateunderline"+date);

		System.out.println(driver.getPageSource());

		System.err.println(courseLanguageDescriptionText.getText());

		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(saveShortDescrbtn));
		saveShortDescrbtn.click();
//////////////////////////////////////////////////longdescription/////////////////////////////////////////////////////////////////////
		
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("( //*[contains(@id,'addLongDescLink')])[1]"))));
		driver.findElement(By.xpath("( //*[contains(@id,'addLongDescLink')])[1]")).click();

//		wait.until(ExpectedConditions.visibilityOf(longdescription_bold));
//		longdescription_bold.click();


		driver.switchTo().frame("longdescription_ifr");


		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		courseLanguageDescriptionText.clear();
		
		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(longdescription_bold));
		longdescription_bold.click();


		driver.switchTo().frame("longdescription_ifr");

		
		courseLanguageDescriptionText.sendKeys("longdescriptionupdatebold"+date);

		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(longdescription_strikethrough));
		longdescription_strikethrough.click();

		driver.switchTo().frame("longdescription_ifr");

		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		courseLanguageDescriptionText.sendKeys(" longdescriptionupdatestrikethrough"+date);

//		System.out.println(driver.getPageSource());

		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(longdescription_strikethrough));
		longdescription_strikethrough.click();

		wait.until(ExpectedConditions.visibilityOf(longdescription_underline));
		longdescription_underline.click();

		driver.switchTo().frame("longdescription_ifr");

		
		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		courseLanguageDescriptionText.sendKeys(" longdescriptionupdateunderline"+date);

		System.err.println(courseLanguageDescriptionText.getText());

		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(saveLongDescrbtn));
		saveLongDescrbtn.click();

//////////////////////////////////////////////////Launch Page Description/////////////////////////////////////////////////////////////////////
	
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("( //*[contains(@id,'addLaunchDescLink')])[1]"))));
		driver.findElement(By.xpath("( //*[contains(@id,'addLaunchDescLink')])[1]")).click();

//		wait.until(ExpectedConditions.visibilityOf(launchdescription_bold));
//		launchdescription_bold.click();

		driver.switchTo().frame("launchdescription_ifr");


		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		courseLanguageDescriptionText.clear();
		
		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(launchdescription_bold));
		launchdescription_bold.click();

		driver.switchTo().frame("launchdescription_ifr");

		courseLanguageDescriptionText.sendKeys("launchdescriptionupdatebold"+date);


		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(launchdescription_strikethrough));
		launchdescription_strikethrough.click();

		driver.switchTo().frame("launchdescription_ifr");

		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		courseLanguageDescriptionText.sendKeys(" launchdescriptionupdatestrikethrough"+date);

//		System.out.println(driver.getPageSource());

		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(launchdescription_strikethrough));
		launchdescription_strikethrough.click();

		wait.until(ExpectedConditions.visibilityOf(launchdescription_underline));
		launchdescription_underline.click();

		driver.switchTo().frame("launchdescription_ifr");

		
		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		courseLanguageDescriptionText.sendKeys(" launchdescriptionupdateunderline"+date);

		System.err.println(courseLanguageDescriptionText.getText());
		
		
		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(saveLaunchDescrbtn));
		saveLaunchDescrbtn.click();


		//////////////////////////////////////////////////terms and cond/////////////////////////////////////////////////////////////////////

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("( //*[contains(@id,'addTermAndCondLink')])[1]"))));
		driver.findElement(By.xpath("( //*[contains(@id,'addTermAndCondLink')])[1]")).click();

//		wait.until(ExpectedConditions.visibilityOf(termsandcond_bold));
//		termsandcond_bold.click();

		driver.switchTo().frame("termsandcond_ifr");


		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		courseLanguageDescriptionText.clear();
	
		
		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(termsandcond_bold));
		termsandcond_bold.click();

		driver.switchTo().frame("launchdescription_ifr");
		
		courseLanguageDescriptionText.sendKeys("termsandcondupdatebold"+date);

		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(termsandcond_strikethrough));
		termsandcond_strikethrough.click();

		driver.switchTo().frame("termsandcond_ifr");

		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		courseLanguageDescriptionText.sendKeys(" termsandcondupdatestrikethrough"+date);

		//System.out.println(driver.getPageSource());

		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(termsandcond_strikethrough));
		termsandcond_strikethrough.click();

		wait.until(ExpectedConditions.visibilityOf(termsandcond_underline));
		termsandcond_underline.click();

		driver.switchTo().frame("termsandcond_ifr");


		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		courseLanguageDescriptionText.sendKeys(" termsandcondupdatenunderline"+date);

		System.err.println(courseLanguageDescriptionText.getText());

		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(saveTermsandcondbtn));
		saveTermsandcondbtn.click();

		
		wait.until(ExpectedConditions.visibilityOf(submitBtn));
		submitBtn.click();

		//*[@id='longdescription_bold']


	}
	
	
	public void validateCourseupdateDetails( )
	{
		
//		German.click();

		String date=courseNameValue.replace("course_","");
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("( //*[contains(@id,'addCourseLink')])[1]"))));
		driver.findElement(By.xpath("( //*[contains(@id,'addCourseLink')])[1]")).click();

		Assert.assertEquals("Course Name input in correct"+courseNameInput.getAttribute("value"),courseNameInput.getAttribute("value"),"courseNameInputupdate"+date);
		wait.until(ExpectedConditions.visibilityOf(CancelCoursebtn));
		CancelCoursebtn.click();

//////////////////////////////////////////////////shortdescription/////////////////////////////////////////////////////////////////////

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("( //*[contains(@id,'addShortDescLink')])[1]"))));
		driver.findElement(By.xpath("( //*[contains(@id,'addShortDescLink')])[1]")).click();

		
		driver.switchTo().frame("shortdescription_ifr");

		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		
		Assert.assertTrue("shortdescription is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("shortdescriptionupdateBold"+date));
	
		Assert.assertTrue("shortdescription is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("shortdescriptionupdatestrikethrough"+date));
		
		Assert.assertTrue("shortdescription is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("shortdescriptionupdateunderline"+date));
		
		  Assert.assertTrue("shortdescription CSS styple is incorrect "+driver.findElement(By.xpath("//p/strong/span[1]")).getCssValue("text-decoration"),driver.findElement(By.xpath("//p/strong/span[1]")).getCssValue("text-decoration").contains("line-through"));
			
			Assert.assertTrue("shortdescription CSS styple is incorrect "+driver.findElement(By.xpath("//p/strong/span[2]")).getCssValue("text-decoration"),driver.findElement(By.xpath("//p/strong/span[2]")).getCssValue("text-decoration").contains("underline"));
			System.out.println(driver.findElement(By.xpath("//*[@id]/p//strong/span")).getText());
		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(saveShortDescrbtn));
		saveShortDescrbtn.click();
//////////////////////////////////////////////////longdescription/////////////////////////////////////////////////////////////////////
		
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("( //*[contains(@id,'addLongDescLink')])[1]"))));
		driver.findElement(By.xpath("( //*[contains(@id,'addLongDescLink')])[1]")).click();

	
		driver.switchTo().frame("longdescription_ifr");
		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		
		
		Assert.assertTrue("longdescription is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("longdescriptionupdatebold"+date));
		
		Assert.assertTrue("longdescription is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("longdescriptionupdatestrikethrough"+date));
		
		Assert.assertTrue("longdescription is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("longdescriptionupdateunderline"+date));
		
		  Assert.assertTrue("longdescription CSS styple is incorrect "+driver.findElement(By.xpath("//p/strong/span[1]")).getCssValue("text-decoration"),driver.findElement(By.xpath("//p/strong/span[1]")).getCssValue("text-decoration").contains("line-through"));
			
			Assert.assertTrue("longdescription CSS styple is incorrect "+driver.findElement(By.xpath("//p/strong/span[2]")).getCssValue("text-decoration"),driver.findElement(By.xpath("//p/strong/span[2]")).getCssValue("text-decoration").contains("underline"));
			System.out.println(driver.findElement(By.xpath("//*[@id]/p//strong/span")).getText());
	
			
		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(saveLongDescrbtn));
		saveLongDescrbtn.click();

//////////////////////////////////////////////////Launch Page Description/////////////////////////////////////////////////////////////////////
	
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("( //*[contains(@id,'addLaunchDescLink')])[1]"))));
		driver.findElement(By.xpath("( //*[contains(@id,'addLaunchDescLink')])[1]")).click();

		
		driver.switchTo().frame("launchdescription_ifr");
		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		
		

       Assert.assertTrue("launchdescription is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("launchdescriptionupdatebold"+date));
		
		Assert.assertTrue("launchdescription is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("launchdescriptionupdatestrikethrough"+date));
		
		Assert.assertTrue("launchdescription is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("launchdescriptionupdateunderline"+date));
		
		
		  Assert.assertTrue("launchdescription CSS styple is incorrect "+driver.findElement(By.xpath("//p/strong/span[1]")).getCssValue("text-decoration"),driver.findElement(By.xpath("//p/strong/span[1]")).getCssValue("text-decoration").contains("line-through"));
			
			Assert.assertTrue("launchdescription CSS styple is incorrect "+driver.findElement(By.xpath("//p/strong/span[2]")).getCssValue("text-decoration"),driver.findElement(By.xpath("//p/strong/span[2]")).getCssValue("text-decoration").contains("underline"));
			System.out.println(driver.findElement(By.xpath("//*[@id]/p//strong/span")).getText());
	
		
		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(saveLaunchDescrbtn));
		saveLaunchDescrbtn.click();


		//////////////////////////////////////////////////terms and cond/////////////////////////////////////////////////////////////////////

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("( //*[contains(@id,'addTermAndCondLink')])[1]"))));
		driver.findElement(By.xpath("( //*[contains(@id,'addTermAndCondLink')])[1]")).click();


		driver.switchTo().frame("termsandcond_ifr");

		wait.until(ExpectedConditions.visibilityOf(courseLanguageDescriptionText));
		
		
		   Assert.assertTrue("addTermAndCond is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("termsandcondupdatebold"+date));
			
			Assert.assertTrue("addTermAndCond is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("termsandcondupdatestrikethrough"+date));
			
			Assert.assertTrue("addTermAndCond is incorrect "+courseLanguageDescriptionText.getText(),courseLanguageDescriptionText.getText().contains("termsandcondupdatenunderline"+date));
			
			  Assert.assertTrue("addTermAndCond CSS styple is incorrect "+driver.findElement(By.xpath("//p/strong/span[1]")).getCssValue("text-decoration"),driver.findElement(By.xpath("//p/strong/span[1]")).getCssValue("text-decoration").contains("line-through"));
				
				Assert.assertTrue("addTermAndCond CSS styple is incorrect "+driver.findElement(By.xpath("//p/strong/span[2]")).getCssValue("text-decoration"),driver.findElement(By.xpath("//p/strong/span[2]")).getCssValue("text-decoration").contains("underline"));
				System.out.println(driver.findElement(By.xpath("//*[@id]/p//strong/span")).getText());
			
				
			
		
		driver.switchTo().defaultContent();

		wait.until(ExpectedConditions.visibilityOf(saveTermsandcondbtn));
		saveTermsandcondbtn.click();

		wait.until(ExpectedConditions.visibilityOf(submitBtn));
		submitBtn.click();

	}
}
