package com.qa.pages;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.python.modules.thread.thread;

import com.qa.util.TestBase;

public class Student extends TestBase
{
	
	@FindBy(xpath = "//a[text() = 'Manage Students']")
	WebElement manageStudentTab;

	@FindBy(xpath = "//a[@class = 'action_dropdown']")
	WebElement actionDetails;
	
	@FindBy(xpath = "//a[text() = 'View Details']")
	WebElement viewDetails;
	
	@FindBy(xpath = "//div[text()='Unit Name']//following-sibling::div")
	WebElement viewUnitName;
	
	@FindBy(xpath = "//div[text()='First Name']//following-sibling::div")
	WebElement viewFirstName;
	
	@FindBy(xpath = "//div[text()='Last Name']//following-sibling::div")
	WebElement viewLastName;
	
	@FindBy(xpath = "//div[text()='Email']//following-sibling::div")
	WebElement viewEmail;
	
	@FindBy(xpath = "(//button[text() = 'Cancel'])[1]")
	WebElement cancelViewDetails;


	@FindBy(xpath = "//*[@id='tablelisting']//a[@title='Download Source File']")
	public WebElement downloadSourceFile;
	
	@FindBy(xpath = "//*[@id='tablelisting']//a[@title='Download Error Log File']")
	public WebElement downloadErrorFile;

	

	@FindBy(xpath = "//*[@id='errorLogTableData']")
	WebElement errorLogTableData;

	@FindBy(xpath = "//input[@name='email']")
	WebElement searchTextstudentEmail;
	
	@FindBy(xpath = "//button[@id = 'search']")
	WebElement searchIcon;
	
	@FindBy(xpath = "//table[@id = 'learnerTableList']//td[3]")
	WebElement searchResultStudentEmail;
	
	@FindBy(xpath = "//*[text() = 'Showing 1 to 1 of 1 entries']")
	WebElement studentSearchResult;
	
	
   @FindBy(xpath = "//table[@id='tablelisting']")
	WebElement demographicReport;
	
   
		   @FindBy(xpath = "(//*[@id='log-modal-content']//button[@class='close'])[1]")
			WebElement close;

		   
		   @FindBy(xpath = "//body[@class]")
	WebElement pageLoad;
	
	By userTable = By.xpath("//table[@id = 'learnerTableList']//tr[@class]/td[text() = 'Active']");
	String userRows = "//table[@id = 'learnerTableList']//tr[@class]";
	
	String val;

	public static String firstName, lastName;

	public Student() 
	{
		PageFactory.initElements(driver, this);
	}
	
	public void navigateToStudentTab()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(manageStudentTab));
		manageStudentTab.click();
	}
	
	public void getStudentDetails()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewDetails));
		viewDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewUnitName));
		firstName = viewFirstName.getText().trim();
		lastName = viewLastName.getText().trim();
		Students. email = viewEmail.getText().trim();
		System.out.println(firstName + " " + lastName + " " + Students. email);
		cancelViewDetails.click();
	}
	
	public void studentSearchTrainingSite()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchTextstudentEmail));
			searchTextstudentEmail.sendKeys(ClassDetail.email);
			searchIcon.click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(studentSearchResult));
			wait.until(ExpectedConditions.visibilityOf(searchResultStudentEmail));
			String result = searchResultStudentEmail.getText();
			Assert.assertEquals(ClassDetail.email, result);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
	}

	
	public void studentSearch(String studentEmail)
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchTextstudentEmail));
			searchTextstudentEmail.sendKeys(studentEmail);
			searchIcon.click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(studentSearchResult));
			wait.until(ExpectedConditions.visibilityOf(searchResultStudentEmail));
			String result = searchResultStudentEmail.getText();
			Assert.assertEquals(studentEmail, result);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
	}

	public void getRowCount(int count)
	{
		try
		{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_compliance loading_user"))
		{
			val = pageLoad.getAttribute("class");
		}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(userTable)));
		Thread.sleep(5000);
		List<WebElement> rows = driver.findElements(userTable);
		if(count > 0)
			Assert.assertEquals(count, rows.size());
		else
		{
			List<WebElement> column = driver.findElements(By.xpath(userRows + "/td"));
			Assert.assertEquals(1, column.size());
			String  text = column.get(0).getText();
			Assert.assertEquals(text, "No records are present.");			
		}
		val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_compliance loading_user"))
		{
			val = pageLoad.getAttribute("class");
		}
		}
		catch(Exception e)
		{
			
		}
			
	}
	
	
	
	
	
}
