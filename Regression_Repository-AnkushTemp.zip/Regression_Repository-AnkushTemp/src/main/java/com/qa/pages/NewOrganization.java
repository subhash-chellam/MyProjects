package com.qa.pages;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.logging.FileHandler;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.qa.util.TestBase;


public class NewOrganization extends TestBase
{
	
	@FindBy(xpath = "//select[@name='usertype']")
	WebElement orgTypeSelect;	
	
	String orgTypeLMS = "LMS";
	String orgTypeCTC = "ENTERPRISE";
			
	@FindBy(xpath = "//input[@name = 'organization']")		
	WebElement orgName; 
	
	String orgProduct = "//label[text() = '";
	
	@FindBy(xpath = "//a[text()='Add/Edit']")		
	WebElement orgHier; 
	
	@FindBy(xpath = "//a[text()='Add']")		
	WebElement hierAdd; 
	
	@FindBy(xpath = "//div[contains(@class, 'email')]/div[2]/label")
	WebElement emailNotificationOff;

	@FindBy(xpath = "//input[@name = 'first_name']")	
	WebElement contFirst;

	@FindBy(xpath = "//input[@name = 'last_name']")
	WebElement contLast;
	
	@FindBy(xpath = "//input[@name = 'email']")
	WebElement contEmail;
	
	@FindBy(xpath = "//input[@name = 'phone']")
	WebElement contNumber;
	
	@FindBy(xpath = "//input[@name = 'address1']")
	WebElement cmpAdr1;
	
	@FindBy(xpath = "//input[@name = 'address2']")
	WebElement cmpAdr2;
	
	@FindBy(xpath = "//input[@name = 'city']")
	WebElement cmpCity;
	
	@FindBy(xpath = "//select[@name='state_id']")
	WebElement cmpStateSelect;
	
	String state = "//select[@name = 'state_id']/option[text()='";
	
	@FindBy(xpath = "//input[@name = 'zipcode']")
	WebElement cmpZip;
	
	@FindBy(xpath = "//input[@name = 'subdomain']")
	WebElement subDomain;
	
	
	
	@FindBy(xpath = "//label[contains(text(), 'English')]")
	WebElement language;
			
	@FindBy(xpath = "//select[@name = 'default_lang_id']")
	WebElement defaultLang;
	
	@FindBy(xpath = "//select[@name = 'timezone']")
	WebElement timeZone;
	
	@FindBy(xpath = "//input[@name = 'admin_first_name']")
	WebElement adminFirst;
	
	@FindBy(xpath = "//input[@name = 'admin_last_name']")
	WebElement adminLast;
	
	@FindBy(xpath = "//input[@name = 'admin_email']")
	WebElement adminEmail;
	
	@FindBy(xpath = "//button[contains(text(),'Create  Organization')]")
	WebElement createOrg;
	
	@FindBy(xpath = "(//i[contains(@class, 'remove')])")
	WebElement errorSymbol;
	
	@FindBy(xpath = "//a[text()= 'Add more levels']")
	WebElement addLevel;
	
	@FindBy(xpath = "//label[text() = 'Enable']")
	WebElement enable;
	
	@FindBy(xpath = "//*[@id='selfRegistartionEmailRequired']//label[text()='Yes']")
	WebElement RegistartionEmailRequired;
	
	
	
	@FindBy(xpath = "//*[@id=\"selfRegistartionEmailRequired\"]//label[text()='No']")
	WebElement RegistartionEmailRequiredNo;
	
	
	@FindBy(xpath = "(//label[contains(text(),'Training Center')])[2]")
	WebElement training_Center;
	
	@FindBy(xpath = "(//label[contains(text(),'Training Site')])")
	WebElement training_Site;
	
	
	@FindBy(xpath = "//button[@title='Select Parent Organization']")
	WebElement parentbtn;
	
	
	
	
	@FindBy(xpath = "//*[@id='autocompleteParentOrg']")
	WebElement parentInput;
	
	@FindBy(xpath = "//label[text() = 'Disable']")
	WebElement disable;
	@FindBy(xpath = "(//*[@name='is_federal'])[1]")
	WebElement federal;
	
	
	
	@FindBy(xpath = "//select[@name = 'parent_company_id']")
	WebElement parentOrg;

	
	@FindBy(xpath = "(//*[@id='customerform']//input[@aria-label='Search'])[1]")
	WebElement parentInputhlc;

	
	@FindBy(xpath = "//i[@data-fv-icon-for='subdomain']")
	WebElement subDomainErrorSymbol;
	
	@FindBy(xpath = "//small[contains(text(), 'Sub Domain')]")
	WebElement subDomainError;
	
	@FindBy(xpath = "//i[@data-fv-icon-for='timezone']")
	WebElement timeZoneErrorSymbol;
	
	@FindBy(xpath = "//small[contains(text(), 'Timezone')]")
	WebElement timeZoneError;
	
	@FindBy(xpath = "//a[text() = '+Add']")
	WebElement lmsInfoAddButton;
	
	@FindBy(xpath = "//input[@placeholder = 'LMS URL']")
	WebElement lmsInfoUrlInput;
	
	
	@FindBy(xpath = "//input[@name = 'salesforce_id']")
	WebElement salesforceID;
	
	@FindBy(xpath = "//*[@id=\"customerform\"]/div[1]/div[7]/div")
	WebElement product;
	
	static String SalesforceName;
	
	static boolean fedflag=false;
	public NewOrganization()
	{
		PageFactory.initElements(driver, this);
	}
	public void addSalesforceId()
	{
		WebDriverWait wait = new WebDriverWait(driver, 5);
		wait.until(ExpectedConditions.visibilityOf(salesforceID));
		String date = new java.util.Date().toString();
		date = date.replace(" ", "");
		SalesforceName = "salesF"+date;
		salesforceID.sendKeys(SalesforceName);
	}
	
	
	public void selectOrgType(String type)
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		String pageValue = js.executeScript("return document.readyState").toString();
		int m=0;
		while(!(pageValue.equalsIgnoreCase("complete")))
		{
			pageValue = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			m++;
		}
		try
		{
		Thread.sleep(4000);	
		}
		catch(Exception e)
		{
			
		}
		wait.until(ExpectedConditions.visibilityOf(orgTypeSelect));
		Select drpOrgType = new Select(orgTypeSelect);
		if (type.equalsIgnoreCase("ctc"))
		{
			drpOrgType.selectByValue(orgTypeCTC);
		}
		else if(type.equalsIgnoreCase("lms"))
			drpOrgType.selectByValue(orgTypeLMS);
	}
	
	public void addDuplicateSalesforceId()
	{
		WebDriverWait wait = new WebDriverWait(driver, 5);
		wait.until(ExpectedConditions.visibilityOf(salesforceID));
		salesforceID.sendKeys(SalesforceName);
	}
	
	public String enterOrgName(String type)
	{
		wait.until(ExpectedConditions.visibilityOf(orgName));
		String date = new java.util.Date().toString();
		date = date.replace(" ", "");
		String name = "Autoorg_"+date;
		orgName.sendKeys(name);
		Log_Organisation_Name(name,type);
		return name;
	}
	
	public void Log_Organisation_Name(String org,String Type)
	{
		try
		{
		String date = new java.util.Date().toString();
		date = date.replace(" ", "");
		date = date.replace(":", "");
		  LocalDateTime myDateObj = LocalDateTime.now();
		    DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("yyyyMMMdd");

		    String formattedDate = myDateObj.format(myFormatObj);

		 FileHandler handler = new FileHandler("ExceptionandOrgLogFolder\\CreateOrgId"+formattedDate+".log", true);
		 
	        Logger logger = Logger.getLogger("com.qa.pages.NewOrganization");
	        logger.addHandler(handler);
	        logger.setUseParentHandlers(false);
		    
	        handler.setFormatter(new SimpleFormatter() {
	            private static final String format
	                = "[%1$tF %1$tT] [%2$-7s] %3$s %n";
	 
	            // Override format method
	            @Override
	            public synchronized String format(
	                LogRecord logRecord)
	            {
	                return String.format(
	                    format, new Date(logRecord.getMillis()),
	                    logRecord.getLevel().getLocalizedName(),
	                    logRecord.getMessage());
	            }
	        });
	 
	        logger.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
	        logger.info("Created Org "+Type+" : "+org);
	        logger.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
	        
			  handler.close();
			  
	       
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());	
		}
	 
	}
	public void selectHierarchy()
	{
		wait.until(ExpectedConditions.visibilityOf(orgHier));

		orgHier.click();
		wait.until(ExpectedConditions.visibilityOf(hierAdd));
		hierAdd.click();
	}
	
	public void addLMSInformation(String url)
	{
		wait.until(ExpectedConditions.visibilityOf(lmsInfoAddButton));
		lmsInfoAddButton.click();
		wait.until(ExpectedConditions.visibilityOf(lmsInfoUrlInput));
		url = url.replace("org_", "url").replace(":","").toLowerCase();
		url = url.replace("child_", "url").replace(":","").toLowerCase();
		
		lmsInfoUrlInput.sendKeys("https://www." + url + ".com");
	}
	
	public boolean checkElearning()
	{
		System.out.println(product.getText());
		if(product.getText().contains("Elearning"))
		{
			return true;
		}
		else
			return false;
	}
	public void selectProductType(String type)
	{
		try
		{
			Thread.sleep(5000);
		}
		catch(Exception e)
		{
			
		}
		
		
		By prod = By.xpath(orgProduct + type + "']");
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(prod)));
		driver.findElement(prod).click();
		
	}
	
	public void selectProductType(String[] type)
	{
		for(int i=0;i<type.length;i++)
		{
		By prod = By.xpath(orgProduct + type[i] + "']");
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(prod)));
		driver.findElement(prod).click();
		}
		
		
	}
	
	public void contactPersonDetail(String first, String last, String email, String number)
	{
		contFirst.sendKeys(first);
		contLast.sendKeys(last);
		email = User.getUserEmail();
		email = email.replace(":", "");
		for(int i = 0; i< email.length(); i++) {
			try {
				Thread.sleep(500);
			}
			catch(Exception e) {
				
			}
			contEmail.sendKeys(String.valueOf(email.charAt(i)));
		}
//		contEmail.sendKeys(email);
		contNumber.sendKeys(number);
	}
	
	public void companyDetails(String adr1, String city, String state, String zip)
	{
		
		cmpAdr1.sendKeys(adr1);
		cmpCity.sendKeys(city);
		cmpZip.sendKeys(zip);
		wait.until(ExpectedConditions.visibilityOf(cmpStateSelect));
	
		try
		{
			Thread.sleep(5000);
		}
		catch(Exception e)
		{
			
		}
		
		Select drpState = new Select(cmpStateSelect);
		drpState.selectByVisibleText(state);
		
	}
	
	public void enterSubDomain(String subName)
	{
		subName = subName.replace("Autoorg_", "subD").replace(":","");
		subName = subName.replace("Autchild_", "subD").replace(":","");
		
		for(int i=0;i<subName.length();i++)
		subDomain.sendKeys(String.valueOf(subName.charAt(i)));
	}
	
	public void selectLang()
	{

		User u=new User();
		
		u. ElementWait(defaultLang);
	
		Select deflang = new Select(defaultLang);
		try
		{
		Thread.sleep(10000);	
		deflang.selectByVisibleText("English/English");
		
		}
		catch(Exception e)
		{
			try
			{
			deflang.selectByVisibleText("English/English");
			}
			catch(Exception m)
			{
			 Assert.fail("Unable to create Orgid due to app issues(Lang dropdown not avaliable)");	
			}
			
		}
		
		language.click();
	}
	
	public void selectLang(String lang)
	{
		
		
		User u=new User();
		
		u. ElementWait(defaultLang);
		
		Select deflang = new Select(defaultLang);

		deflang.selectByVisibleText(lang);
		language.click();
	}
	public void ElementWait(WebElement e)
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
	     
	      int m=0;
	
	      while(m==10)
	      {
	    	  try
	    	  {
	    			wait.until(ExpectedConditions.visibilityOf(e));
	    			break;
	    	  }
	    	  catch(Exception s)
	    	  {
	    		  
	    	  }
	    	  m++;
	      }
	}
	public void selectTimeZone()
	{
		
//		wait.until(ExpectedConditions.visibilityOf(timeZone));
		ElementWait(timeZone);
		Select drptime = new Select(timeZone);
		drptime.selectByValue("4");
	}
	
	public void enterAdminDetails(String first, String last, String email)
	{
		adminFirst.sendKeys(first);
		adminLast.sendKeys(last);
		email = User.getUserEmail();
		User. adminEmailid=email;
//		adminEmail.sendKeys(email);
	
		
		for(int i=0;i<email.length();i++) {
		try {
			Thread.sleep(500);
		}
		catch(Exception e) {
			
		}
		adminEmail.sendKeys(String.valueOf(email.charAt(i)));
			  }
	}
		
	public void clickToCreate()
	{
		 try
   	  {
   			Thread.sleep(4000);
   	  }
   	  catch(Exception s)
   	  {
   		  
   	  }
		wait.until(ExpectedConditions.visibilityOf(createOrg));
		createOrg.click();
		
	}

	public void addLevel(int i)
	{
		wait.until(ExpectedConditions.elementToBeClickable(orgHier));
		wait.until(ExpectedConditions.visibilityOf(orgHier));
		
		orgHier.click();
		wait.until(ExpectedConditions.visibilityOf(hierAdd));
		for(int x = 1; x <= i-1; x++)
		{
			addLevel.click();
		}
		hierAdd.click();
	}

	public void clickSelfRegister()
	{
		wait.until(ExpectedConditions.visibilityOf(enable));
		enable.click();
		
		wait.until(ExpectedConditions.visibilityOf(RegistartionEmailRequired));
		RegistartionEmailRequired.click();
		
		
	}
	
	public void clickSelfRegisterOption()
	{
		wait.until(ExpectedConditions.visibilityOf(enable));
		enable.click();
		wait.until(ExpectedConditions.visibilityOf(RegistartionEmailRequiredNo));
		
		RegistartionEmailRequiredNo.click();
	}
	
	public void clickonTrainingCenter()
	{
		wait.until(ExpectedConditions.visibilityOf(training_Center));
		training_Center.click();
	}
	public void clickonTrainingSite()
	{
		wait.until(ExpectedConditions.visibilityOf(training_Site));
		training_Site.click();
	}
	public void clickSelfRegisterdisable()
	{
		wait.until(ExpectedConditions.visibilityOf(disable));
		disable.click();
	}
	
	public void clickfederalyes()
	{
		
	
//		wait.until(ExpectedConditions.visibilityOf(federal));
		 JavascriptExecutor jse = (JavascriptExecutor)driver;
			
		jse.executeScript("arguments[0].click();", federal);
		fedflag=true;
//		federal.click();
		
	}

	public void selectParentOrganisation(String orgName) throws InterruptedException
	{
		System.out.println(orgName);
		try
		{
		Thread.sleep(10000);
		parentbtn.click();
		Thread.sleep(10000);
		parentInput.sendKeys(orgName);
		Thread.sleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		Thread.sleep(2000);
		Select deflang = new Select(parentOrg);
		deflang.selectByVisibleText(orgName);
	}
	public void selectParentOrganisationhlc(String orgName) throws InterruptedException
	{
		System.out.println(orgName);
		try
		{
		Thread.sleep(10000);
		parentbtn.click();
		Thread.sleep(10000);
		for(int i=0;i<orgName.length();i++)
			parentInputhlc.sendKeys(String.valueOf(orgName.charAt(i)));

		Thread.sleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		Thread.sleep(2000);
		Select deflang = new Select(parentOrg);
		deflang.selectByVisibleText(orgName);
	}


	
	public void validErrorMessageSubDomain()
	{
		wait.until(ExpectedConditions.visibilityOf(subDomainErrorSymbol));
		Assert.assertTrue(subDomainError.isDisplayed());
	}
	
	public void validErrorMessageTimeZone()
	{
		wait.until(ExpectedConditions.visibilityOf(timeZoneErrorSymbol));
		Assert.assertTrue(timeZoneError.isDisplayed());
	}
	
	public String entercustomizeOrgName(String name)
	{
			wait.until(ExpectedConditions.visibilityOf(orgName));
		String date = new java.util.Date().toString();
		date = date.replace(" ", "");
		String finalName = name+date;
		orgName.sendKeys(finalName);
		return finalName;
	}
	
	public void enterCustomSubDomain()
	{
		String date = new java.util.Date().toString();
		date = date.replace(" ", "");
		String subName = ("subD" + date).replace(":","");
		subDomain.sendKeys(subName);
		System.out.println(subName);
	}
	
	public void enterCustomAdminDetails(String first, String last)
	{
		adminFirst.sendKeys(first);
		adminLast.sendKeys(last);
		String date = new java.util.Date().toString();
		date = date.replace(" ", "");
		String email = User.getUserEmail();
//		adminEmail.sendKeys(email);
		for(int i=0;i<email.length();i++) {
			try {
				Thread.sleep(500);
			}
			catch(Exception e) {
				
			}
			adminEmail.sendKeys(String.valueOf(email.charAt(i)));
		}
	}
	
	public void contactCustomPersonDetail(String first, String last, String number)
	{
		contFirst.sendKeys(first);
		contLast.sendKeys(last);
		String date = new java.util.Date().toString();
		date = date.replace(" ", "");
		String email = User.getUserEmail();
		email = email.replace(":", "");
		contEmail.sendKeys(email);
		contNumber.sendKeys(number);
	}
	
	public void selectHierarchyWithLevel(int level)
	{
		try {
		orgHier.click();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(hierAdd));
		int counter = 0;
		while(driver.findElements(By.xpath("//a[text() = 'Delete']")).size() > 0)
		{
			WebElement delete = driver.findElement(By.xpath("//a[text() = 'Delete']"));
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("arguments[0].click()", delete);
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load page after waiting for 1 minute");
		}
		for(int x = 1; x < level; x++)
		{
			addLevel.click();
		}	
		hierAdd.click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
	}
	
	public void turnOffNotification()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(emailNotificationOff));
		emailNotificationOff.click();
	}
	
}
