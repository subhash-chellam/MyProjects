package com.qa.pages;

import java.util.List;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.qa.util.TestBase;

public class Analytics extends TestBase
{
	@FindBy(xpath = "//a[text() = 'Analytics']")
	WebElement analyticsTab;
	
	@FindBy(xpath = "//label[@class = 'analytics_switch']")
	WebElement analyticsToggle;
	
	@FindBy(xpath = "//button[text() = 'Save']")
	WebElement buttonSave;
	
	@FindBy(xpath = "//li[@class = 'dropdown ']")
	WebElement analyticsDropdown;
	
	@FindBy(xpath = "//body[@class]")
	WebElement pageLoad;
	
	@FindBy(xpath = "//div[contains(@class, 'alert-dismissable')]")
	WebElement errorMessage;
	
	@FindBy(xpath = "//button[text() = 'Confirm']")
	WebElement warningConfirmButton;
	
	@FindBy(xpath = "//button[text() = 'Cancel']")
	WebElement warningCancelButton;

	@FindBy(xpath = "//*[@id='bs-example-navbar-collapse-1']//a[text()='Analytics']")
	WebElement anlyticsTab;

	@FindBy(xpath = "//body//h1")
	WebElement header;
	
	
	@FindBy(xpath = "//*[@id='analytics_app_form']/div[@class='analyticsCls']")
	WebElement table;
	
	String appTable = "//table[@id = 'analytics_app_list']//tbody/tr";
	String analyticsDropdownList = "(//li[@class = 'dropdown  open']//li/a)"; 
	String warningMessage = "//h4[text() = 'Turn Off Analytics']";
	String val;
	
	public Analytics() 
	{
		PageFactory.initElements(driver, this);
	}

	public void clickOnAnalyticsTab()
	{
	   wait.until(ExpectedConditions.visibilityOf(analyticsTab));
		analyticsTab.click();
	}

	public void toggleAnalytics()
	{
		wait.until(ExpectedConditions.visibilityOf(analyticsToggle));
		analyticsToggle.click();
	}
	
	public void checktoggleAnalytics(String status)
	{
		wait.until(ExpectedConditions.visibilityOf(analyticsToggle));
		if(table.getAttribute("style").contains("display: none;")&&status.contains("ON"))
		analyticsToggle.click();
		else if(table.getAttribute("style").contains("display: block;")&&status.contains("OFF"))
			analyticsToggle.click();
		
	}
	
	public void enableInsightApp(String app)
	{
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(appTable))));
		List<WebElement> table = driver.findElements(By.xpath(appTable));
		for(int i= 1; i <= table.size(); i++)
		{
			String appName = driver.findElement(By.xpath(appTable + "[" + i + "]/td[1]")).getText();
			if(appName.equalsIgnoreCase(app))
			{
				flag = true;
			}
		}
		Assert.assertTrue(flag);
	}

	public void enableInsightAppSave(String app)
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(appTable))));
		List<WebElement> table = driver.findElements(By.xpath(appTable));
		for(int i= 1; i <= table.size(); i++)
		{
			String appName = driver.findElement(By.xpath(appTable + "[" + i + "]/td[1]")).getText();
			if(appName.equalsIgnoreCase(app) || appName.equalsIgnoreCase("Rqi-2020"))
			{
				driver.findElement(By.xpath(appTable + "[" + i + "]/td[3]//div/label")).click();
			}
		}
		buttonSave.click();
	}
	
	public void validateAnalyticsDropdown(String name)
	{
		wait.until(ExpectedConditions.visibilityOf(analyticsDropdown));
		try 
		{ 
			int m=0;
			val = pageLoad.getAttribute("class");
			while((val.contains("loading")|| val.contains("loading_user")))  
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(1000);
				if(m==pagload)
					break;
				m++;
			}
			System.out.println(val);
			analyticsDropdown.click();
			checkAppNamePresent(name);
		}
		catch (Exception e) 
		{
			analyticsDropdown.click();
			checkAppNamePresent(name);
		}
	}
	
	public void checkAppNamePresent(String name)
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(analyticsDropdownList))));
		List<WebElement> list = driver.findElements(By.xpath(analyticsDropdownList));
		Boolean flag=false;
		for(int i = 1; i <= list.size(); i++)
		{
			String appName = driver.findElement(By.xpath(analyticsDropdownList + "[" + i + "]")).getText();
			if(appName.equalsIgnoreCase(name))
			{
				flag=true;
				Assert.assertTrue(true);
			}
		}
		Assert.assertTrue(flag);
		
	}

	public void validateAnalyticsDropdownNotAvailable(String name)
	{
		wait.until(ExpectedConditions.visibilityOf(analyticsDropdown));
		try 
		{
			int m=0;
			val = pageLoad.getAttribute("class");
			while((val.contains("loading")|| val.contains("loading_user")))  
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(1000);
				if(m==pagload)
					break;
				m++;
				
			}
			System.out.println(val);
			analyticsDropdown.click();
			checkAppNameAbsent(name);
		}
		catch (Exception e) 
		{
			analyticsDropdown.click();
			checkAppNameAbsent(name);
		}
	}
	
	public void checkAppNameAbsent(String name)
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(analyticsDropdownList))));
		List<WebElement> list = driver.findElements(By.xpath(analyticsDropdownList));
		for(int i = 1; i <= list.size(); i++)
		{
			String appName = driver.findElement(By.xpath(analyticsDropdownList + "[" + i + "]")).getText();
			if(appName.equalsIgnoreCase(name))
			{
				Assert.assertFalse(true);
			}
		}
	}

	public void validateApplicationAbsent(String name)
	{
		boolean flag = false;
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(appTable))));
			List<WebElement> table = driver.findElements(By.xpath(appTable));
			for(int i= 1; i <= table.size(); i++)
			{
				String appName = driver.findElement(By.xpath(appTable + "[" + i + "]/td[1]")).getText();
				if(appName.equalsIgnoreCase(name))
				{
					flag = true;
				}
			}
			Assert.assertFalse(flag);
	}
	
	public void validateDescription(String desc)
	{
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(appTable))));
		List<WebElement> table = driver.findElements(By.xpath(appTable));
		for(int i= 1; i <= table.size(); i++)
		{
			String appName = driver.findElement(By.xpath(appTable + "[" + i + "]/td[2]")).getText().trim();
			if(appName.equalsIgnoreCase(desc))
			{
				flag = true;
			}
		}
		Assert.assertTrue(flag);
	}
	
	public void enableMulitpleInsightAppSave(String app)
	{
		
		if(AssignmentReport. checkifParmeterAvailable(app))
			app=AssignmentReport.getParmeterAvailable(app);

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(appTable))));
		List<WebElement> table = driver.findElements(By.xpath(appTable));
		String givenAppName[] = app.split(",");
		System.out.println(givenAppName.length);
		for(int i =0; i <= givenAppName.length-1; i++)
		{
			for(int j= 1; j <= table.size(); j++)
			{
				String appName = driver.findElement(By.xpath(appTable + "[" + j + "]/td[1]")).getText().trim();
				if(appName.equalsIgnoreCase(givenAppName[i].trim()))
				{
					driver.findElement(By.xpath(appTable + "[" + j + "]/td[3]//div/label")).click();
					break;
				}
			}
		}
		
		buttonSave.click();
	}
	
	public void MulitpleInsightAppSave(String app)
	{
		
		if(AssignmentReport. checkifParmeterAvailable(app))
			app=AssignmentReport.getParmeterAvailable(app);

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(appTable))));
		List<WebElement> table = driver.findElements(By.xpath(appTable));
		String givenAppName[] = app.split(",");
		System.out.println(givenAppName.length);
		for(int i =0; i <= givenAppName.length-1; i++)
		{
			for(int j= 1; j <= table.size(); j++)
			{
				String appName = driver.findElement(By.xpath(appTable + "[" + j + "]/td[1]")).getText().trim();
				if(appName.equalsIgnoreCase(givenAppName[i].trim()))
				{
					if(driver.findElement(By.xpath(appTable + "[" + j + "]/td[3]//div/input")).getAttribute("checked")==null)
					driver.findElement(By.xpath(appTable + "[" + j + "]/td[3]//div/label")).click();
					System.out.println(givenAppName[i].trim());
					break;
				}
			}
		}
		
		buttonSave.click();
	}
	
	public void validateAnalyticsDropdownAndSelect(String allNames, String name)
	{
		if(AssignmentReport. checkifParmeterAvailable(allNames))
			allNames=AssignmentReport.getParmeterAvailable(allNames);
		
		if(AssignmentReport. checkifParmeterAvailable(name))
			name=AssignmentReport.getParmeterAvailable(name);

		wait.until(ExpectedConditions.visibilityOf(analyticsDropdown));
		try 
		{
			int m=0;
			val = pageLoad.getAttribute("class");
			while((val.contains("loading")|| val.contains("loading_user")))  
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(1000);
				if(m==pagload)
					break;
				m++;
			}
			System.out.println(val);
			analyticsDropdown.click();
			checkMultipleAppNamePresent(allNames, name);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	public void checkMultipleAppNamePresent(String names, String givenName)
	{
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(analyticsDropdownList))));
		List<WebElement> list = driver.findElements(By.xpath(analyticsDropdownList));
		String nameList[] = names.split(",");
		for(int j = 0; j <= nameList.length-1; j++)
		{
			System.out.println(nameList[j].trim());
			for(int i = 1; i <= list.size(); i++)
			{
				String appName = driver.findElement(By.xpath(analyticsDropdownList + "[" + i + "]")).getText().trim();
				System.out.println(appName);
				if(appName.equalsIgnoreCase(nameList[j].trim()))
				{
					flag = true;
					Assert.assertTrue(flag);
					if(appName.equalsIgnoreCase(givenName))
					{
						driver.findElement(By.xpath(analyticsDropdownList + "[" + i + "]")).click();
						break;
					}
				}
			}
		}
		
	}
	
	public void getFrameSourceValidate()
	{
		boolean flag = false;
		driver.switchTo().frame(0);
		String source = driver.getPageSource();
		System.out.println(source);
		if(source.contains("var appVersion"))
		{
			flag = true;
		}
			Assert.assertTrue(flag);
		driver.switchTo().defaultContent();
	}

	public void validateErrorForNotSelectApplication()
	{
		wait.until(ExpectedConditions.visibilityOf(errorMessage));
	}

	public void validateWarningMessageForApplication(String value)
	{
		if(value.toLowerCase().equalsIgnoreCase("yes"))
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(warningMessage))));
		}
		else if(value.toLowerCase().equalsIgnoreCase("no"))
		{
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(warningMessage)));
		}
		
	}
	
	public void clickOnButton(String name)
	{
		validateWarningMessageForApplication("yes");
		if(name.equalsIgnoreCase("confirm"))
		{
			wait.until(ExpectedConditions.visibilityOf(warningConfirmButton));
			warningConfirmButton.click();
		}
		else if(name.equalsIgnoreCase("cancel"))
		{
			wait.until(ExpectedConditions.visibilityOf(warningCancelButton));
			warningCancelButton.click();
		}
		
	}

	public void clickOnAnalyticsinaccessTab()
	{
	   wait.until(ExpectedConditions.visibilityOf(anlyticsTab));
	   anlyticsTab.click();
	}


	public void validateifAnalytics()
	{
		int m=0;
		while(true)
		{
			
			if(driver.getCurrentUrl().contains("insightsAnalyticsReport"))
				break;
			else
			{
				try
				{
				Thread.sleep(1000);
				if(m==pagload)
					break;
				m++;
				}
				catch(Exception e)
				{
					
				}
				
			}
		}
		
		wait.until(ExpectedConditions.visibilityOf(header));
		Assert.assertFalse("Getting error"+header.getText(),header.getText().contains("504 Gateway Time-out"));
	}
}
