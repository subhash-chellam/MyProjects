package com.qa.pages;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.util.TestBase;
import com.qa.util.TestUtils;

public class UnitAdmin extends TestBase {

	public UnitAdmin() {
		PageFactory.initElements(driver, this);
	}

	WebDriverWait wait;

	@FindBy(xpath = "(//table[@aria-describedby='learnerTableList_info']//tbody//tr//label)[1]")
	WebElement SelectUserIdcheckBox;
	// table[@aria-describedby='learnerTableList_info']//tbody//tr//td//input[1]

	// table[@aria-describedby='learnerTableList_info']//tbody//tr//td//input[@type='checkbox'])[1]

	@FindBy(xpath = "//div[@class='btn_options']//div[@id='action_items']")
	WebElement Button_ActionItems;

	@FindBy(xpath = "//button[@data-toggle='dropdown']//following-sibling::ul/li")
	List<WebElement> List_ActionItems;

	@FindBy(xpath = "(//table[@id='learnerTableList']//a[@data-toggle='dropdown'])[1]")
	WebElement User_ActionDropdown;

	// div[@class=\"dropdown open\"]//ul/li//a[contains(text(),'View User Details')]
	public void SelectUserIDCheckBox() {
		try {
			SelectUserIdcheckBox.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	} 
	public void CheckUserCheckboxIsavailable() {
		try {
			wait = new WebDriverWait(driver, 30);
			boolean value = SelectUserIdcheckBox.isDisplayed();
			Assert.fail();
		} catch (Exception e) {
			
		//	e.printStackTrace();
		}
	}

	public void Button_ActionItems() {
		try {
			wait = new WebDriverWait(driver, 30);
			Thread.sleep(2000);
			Button_ActionItems.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void SelectFromTheList(String Itemsvalue) {
		try {
			wait = new WebDriverWait(driver, 30);
			TestUtils.checkvalueisPresentInTheList(List_ActionItems, Itemsvalue);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickOnActionDropDown(String Dropdownvalue) {
		try {
			wait = new WebDriverWait(driver, 30);
			User_ActionDropdown.click();
			String value = "//div[@class='dropdown open']//ul/li//a[contains(text(),'" + Dropdownvalue + "')]";
			// WebElement ele = driver.findElement(By.xpath(value));
			String ddvalue = driver.findElement(By.xpath(value)).getText();
			System.out.println(" Dropdown value is :" + ddvalue);
			if (!ddvalue.equalsIgnoreCase(Dropdownvalue)) {
				System.out.println("The" + Dropdownvalue + " dropdown value is not present");
			} else {
				Assert.fail("The" + Dropdownvalue + " dropdown value is present");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@FindBy(xpath = "(//a[@title='View Group Details'])[1]")
	WebElement viewGroupDetails;

	@FindBy(xpath = "(//a[@title='Edit Group Details'])[1]")
	WebElement EditGroupDetails;
	// a[@title = 'Edit Group Details']

	public void checkGroupAction() {
		// boolean isPresent = true;
		try {
			boolean viewGroupValue = viewGroupDetails.isDisplayed();
			Assert.assertTrue(viewGroupValue);

		
			// Assert.assertFalse(editvalue);
			/*
			 * if (editvalue == false) {
			 * System.out.println(" Edit group Details is not found"); } else {
			 * System.out.println(" Edit group Details is present"); }
			 */

		} catch (Exception e) {
			// e.printStackTrace();
		}

		try {
			boolean editvalue = EditGroupDetails.isDisplayed();
			Assert.fail(" Edit Group Details available");
		} catch (Exception e) {
			System.out.println(" The edit group details not found");
		}

	}

	@FindBy(xpath = "(//a[@title='Edit Job Title Details'])[1]")
	WebElement EditJobTitleDetails;

	@FindBy(xpath = "(//a[@title='View Job Title Details'])[1]")
	WebElement ViewJobTitleDetails;

	public void checktitleExists() {
		// boolean isPresent = true;
		try {
			boolean viewJobValue = ViewJobTitleDetails.isDisplayed();
			Assert.assertTrue(viewJobValue);


		} catch (Exception e) {
			// e.printStackTrace();
		}
		try {
			boolean editJob = (!EditJobTitleDetails.isDisplayed());
			Assert.assertTrue(editJob);
		} catch (Exception e) {
			System.out.println(" The edit job title details found");
		}

	}

	// -------------------------------------------------------------------------------
	@FindBy(xpath = "//a[contains(text(), 'Groups')]")
	WebElement groupTab;

	@FindBy(xpath = "//a[contains(text(),'Job Titles')]")
	WebElement JobTitleTab;

	@FindBy(xpath = "//a[contains(text(),'Notifications')]")
	WebElement NotificationTab;

	@FindBy(xpath = "//a[contains(text(),'Organization Hierarchy')]")
	WebElement OrganizationHierarchyTab;

	@FindBy(xpath = "//a[contains(text(),'Demographic Settings')]")
	WebElement DemographicSettingsTab;

	@FindBy(xpath = "//a[contains(text(),'Demographic Report')]")
	WebElement DemographicReportTab;

	public void checkAvailableOptionsInOrgSettingsTab() {
		// boolean isPresent = true;
		try {
			boolean viewgroupTab = groupTab.isDisplayed();
			Assert.assertTrue(viewgroupTab);

			boolean viewJobTitleTab = JobTitleTab.isDisplayed();
			Assert.assertTrue(viewJobTitleTab);

			boolean viewNotificationTab = NotificationTab.isDisplayed();
			Assert.assertTrue(viewNotificationTab);

			boolean viewOrganizationHierarchyTab = OrganizationHierarchyTab.isDisplayed();
			Assert.assertTrue(viewOrganizationHierarchyTab);

			try {
				boolean editvalue = DemographicSettingsTab.isDisplayed();
				Assert.fail(" Demographic Settings Tab available");
			} catch (Exception e) {
				System.out.println(" The Demographic Settings Tab not found");
			}

			try {
				boolean editvalue = DemographicReportTab.isDisplayed();
				Assert.fail("Demographic Report Tab available");
			} catch (Exception e) {
				System.out.println(" The Demographic Report Tab not found");
			}

		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	@FindBy(xpath = "//button[@data-id='job_title_id']")
	WebElement JobTitleId;

	public void jobTitleIsEnabled() {
		try {
			boolean jobtitleid = JobTitleId.isEnabled();
			Assert.assertTrue(jobtitleid);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@FindBy(xpath = "//a[contains(text(),'User Details')]")
	WebElement UserDetailsTab;

	@FindBy(xpath = "(//a[contains(text(),'Assignments')])[2]")
	WebElement AssignmentsTab;

	@FindBy(xpath = "//a[contains(text(),'Certificates')]")
	WebElement CertificatesTab;

	public void checkTabsPresentInUserDetailsTab() {
		// boolean isPresent = true;
		try {
			boolean viewgroupTab = groupTab.isDisplayed();
			Assert.assertTrue(viewgroupTab);

			boolean viewAssignmentTab = AssignmentsTab.isDisplayed();
			Assert.assertTrue(viewAssignmentTab);

			boolean viewCertificateTab = CertificatesTab.isDisplayed();
			Assert.assertTrue(viewCertificateTab);

			boolean viewUserDetailsTab = UserDetailsTab.isDisplayed();
			Assert.assertTrue(viewUserDetailsTab);

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@FindBy(xpath = "//tr[1]//a[@class = 'action_dropdown']")
	WebElement actionDetail;

	@FindBy(xpath = "(//a[contains(text() , 'Delete User')])[1]")
	WebElement deleteUser;

	public void checkDeleteUser() {
		try {
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetail));
			actionDetail.click();

			try {
				boolean delUser = deleteUser.isDisplayed();
				Assert.fail("Delete User is not available");
			} catch (Exception e) {
				System.out.println("The Delete user is available");
			}

		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	@FindBy(xpath = "//a[@title='Remove']")
	WebElement RemoveUser;

	public void RemoveUser() {
		try {
			boolean delUser = RemoveUser.isDisplayed();
			Assert.fail("Remove User is not available");
		} catch (Exception e) {
			System.out.println("The Remove User is available");
		}

	}

	// td[contains(text(),'"+Name+"')]/following-sibling::td[contains(text(),'"+Role+"')]/following-sibling::td[2]

	public void CheckUrlContains() {
		try {
			Thread.sleep(2000);
			System.out.println(" my url is :" + driver.getCurrentUrl());
			boolean value = driver.getCurrentUrl().contains("mycourse");

			Assert.assertTrue(value);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(" The Url doesn't have the my course");
		}

	}

	@FindBy(xpath = "//div[@class='btn_options']//div[@class='fr']//a[text()='Create Assignment']")
	WebElement Button_CreateAssignment;

	@FindBy(xpath = "//table[@id='assignmentlisting']//tbody//tr[1]//td[8]//div//a[@class='action_dropdown']")
	WebElement ActionButton_Assignment;

	@FindBy(xpath = "//div[@class='dropdown open']//ul//li//a[text()='Edit Assignment']")
	WebElement DropDown_EditAssignment;

	public void createAssignment() {
		try {
			boolean buttonAssignment = Button_CreateAssignment.isEnabled();
			Assert.fail("Create Assignment button");

			ActionButton_Assignment.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void checkAssignmentDropDown(String text) {
		try {
			String textvalue = "//div[@class='dropdown open']//ul//li//a[text()='" + text + "']";

			String value = driver.findElement(By.xpath(textvalue)).getText();
			System.out.println(" The value of drop down is :" + value);

			boolean dropdownvalue = driver.findElement(By.xpath(textvalue)).isEnabled();
			Assert.fail("Dropdown value is not present");

		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@FindBy (xpath = "//table[@id='learnerTableList']//tbody/tr[1]//td[8]//div/a[@class='action_dropdown']")
	WebElement DropDown_ViewUserDetails;
	
	public void ClickOnActionButtonandSelectvalueFromlist(String Dropdownvalue) {
		try {
	
			wait = new WebDriverWait(driver, 30);
			User_ActionDropdown.click();
			String value = "//div[@class='dropdown open']//ul/li//a[contains(text(),'" + Dropdownvalue + "')]";
			// WebElement ele = driver.findElement(By.xpath(value));
			String ddvalue = driver.findElement(By.xpath(value)).getText();
		System.out.println( " The value : "+ ddvalue );
		driver.findElement(By.xpath(value)).click();
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	
	public void CheckdropdownvaluesFromlistuserScreen(String Dropdownvalue) {
		try {
	
			wait = new WebDriverWait(driver, 30);
			User_ActionDropdown.click();
			String value = "//div[@class='dropdown open']//ul/li//a[contains(text(),'" + Dropdownvalue + "')]";
			// WebElement ele = driver.findElement(By.xpath(value));
			
		System.out.println( " The value : "+ value );
	//	driver.findElement(By.xpath(value)).click();
			
		boolean ddvalue = driver.findElement(By.xpath(value)).isDisplayed();
		Assert.fail();
		
		User_ActionDropdown.click();
		
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void CheckDropdownValueNotPresentInUsertable(String Dropdownvalue) {
		try {
			wait.until(ExpectedConditions.visibilityOf(User_ActionDropdown));
			
			User_ActionDropdown.click();
			String value = "//div[@class='dropdown open']//ul/li//a[contains(text(),'" + Dropdownvalue + "')]";
			// WebElement ele = driver.findElement(By.xpath(value));
			String ddvalue = driver.findElement(By.xpath(value)).getText();
			System.out.println(" Dropdown value is :" + ddvalue);
			if (!ddvalue.equalsIgnoreCase(Dropdownvalue)) {
				System.out.println("The" + Dropdownvalue + " dropdown value is not present");
			} else {
				Assert.fail("The" + Dropdownvalue + " dropdown value is present");
			}
			User_ActionDropdown.click();
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail("Issues with app");
		}
	}
	public void CheckDropdownValuePresentInUsertable(String Dropdownvalue) {
		try {
			wait.until(ExpectedConditions.visibilityOf(User_ActionDropdown));
			
			User_ActionDropdown.click();
			String value = "//div[@class='dropdown open']//ul/li//a[contains(text(),'" + Dropdownvalue + "')]";
			// WebElement ele = driver.findElement(By.xpath(value));
			String ddvalue = driver.findElement(By.xpath(value)).getText();
			System.out.println(" Dropdown value is :" + ddvalue);
			if (!ddvalue.equalsIgnoreCase(Dropdownvalue)) {
				Assert.fail("The" + Dropdownvalue + " dropdown value is present");
				
			} else {
				System.out.println("The" + Dropdownvalue + " dropdown value is not present");
			}
			User_ActionDropdown.click();
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail("Issues with app");
		}
	}
	
	@FindBy (xpath = "//div[@class='clear_float']//ul/li/a")
	List<WebElement> HeaderTabs;
	
	public void selectFromHeadertabs(String Tabvalue) {
		try {
			
			Thread.sleep(2000);
			TestUtils.selectFromTheList(HeaderTabs, Tabvalue);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void checkvaluePresentInDropDownvalue(String Dropdownvalue) {
		try {
			String value = "//div[@class='dropdown open']//ul/li//a[contains(text(),'" + Dropdownvalue + "')]";
			// WebElement ele = driver.findElement(By.xpath(value));
			boolean ddvalue = driver.findElement(By.xpath(value)).isDisplayed();
			Assert.assertTrue(ddvalue);
		} catch (Exception e) {
			Assert.assertTrue(false);
		}
	}
	String actionItem="']//following-sibling::td//a[@class='action_dropdown']",unenrollfront="//td[contains(text(),'",unenrollback="')]//following-sibling::td[3]/a[@title='Unenroll']";
	String assigment="//td[text()='";

	public void checkvalueNotPresentInDropDownvalue(String Dropdownvalue) {
		try {
			wait = new WebDriverWait(driver, 30);
			
			String value = "//div[@class='dropdown open']//ul/li//a[contains(text(),'" + Dropdownvalue + "')]";
			// WebElement ele = driver.findElement(By.xpath(value));
			Thread.sleep(3000);
			System.out.println(assigment+Assignments.AssgnmentName+actionItem);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(assigment+Assignments.AssgnmentName+actionItem))));
			driver.findElement(By.xpath(assigment+Assignments.AssgnmentName+actionItem)).click();
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(value))));
			
			boolean ddvalue = driver.findElement(By.xpath(value)).isDisplayed();
			Assert.assertFalse("Drop drop should  not be present "+Dropdownvalue,ddvalue);
		} catch (Exception e) {
			
		System.out.println("Drop drop not present");	
		}
	}
	@FindBy (xpath = "//a[contains(text(),'Edit User Details')]")
	WebElement button_EditUserDetails;
	
	public void CheckEditUserDetails() {
		try {
			Thread.sleep(2000);
		boolean value =	button_EditUserDetails.isDisplayed();
		Assert.fail();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	//Assignment Action
	@FindBy (xpath = "(//table[@id='assignmentlisting']//a[@data-toggle='dropdown'])[1]")
	WebElement Actions_Assignment;
	
	public void clickOnActionAssignment() {
		try {
		Actions_Assignment.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@FindBy (xpath = "//table[@id='tablelisting']//tbody//tr[@role='row']//td[4]//a[@title='View Group Details']")
	WebElement Text_ViewGroupDetails;
	
	public void ViewGroupDetailsText() {
		try {
			 boolean value = Text_ViewGroupDetails.isDisplayed();
			 Assert.assertTrue(value);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@FindBy (xpath = "//table[@id='jobtitle']//tbody//tr[@role='row']//td[3]//a[@title='View Job Title Details']")
	WebElement Text_ViewJobTitleDetails;
	
	
	public void ViewJobTitleDetails() {
		try {
			 boolean value = Text_ViewJobTitleDetails.isDisplayed();
			 Assert.assertTrue(value);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@FindBy (xpath = "//div[@class='container']//div/ul[@class='nav nav-tabs edit_organization_tabs']/li/a")
	List<WebElement> Link_OrgTabs; 
	
	public void LinkOrgTabs(String value) {
		try {
			TestUtils.selectFromTheList(Link_OrgTabs, value);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@FindBy (xpath = "//div[@class='btn_options']//div//a[text()='Add to Group']")
	WebElement Button_AddToGroup;
	
	public void checkAddToGroupButtonExistsInGroupTab() {
		try {
			boolean value =Button_AddToGroup.isDisplayed();
			Assert.fail();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}	
	
	@FindBy (xpath = "//table[@id='mmgroupuser']//tbody//tr[@role='row']//td[4]//a[@title='View']")
	WebElement mmgroupUserView;
	
	@FindBy (xpath = "//table[@id='mmgroupuser']//tbody//tr[@role='row']//td[4]//a[@title='Remove']")
	WebElement mmgroupUserDelete;
	
	
	public void mmgroupuser(String groupValue) {
		try {
			
			String value = "//table[@id='mmgroupuser']//tbody//tr[@role='row']//td[4]//a[@title'"+ groupValue+"']";
			 String ggvalue = driver.findElement(By.xpath(value)).getText();
				if (!ggvalue.equalsIgnoreCase(groupValue)) {
					System.out.println("The" + groupValue + " dropdown value is not present");
				} else {
					Assert.fail("The" + groupValue + " dropdown value is present");
				}
			 
		
		} catch (Exception e) {
			// TODO: handle exception
		}
	}	
	
	
	public void mmgroupuser() {
		try {
			
			boolean value =  mmgroupUserView.isDisplayed();
			Assert.assertTrue(value);
			
			boolean userdelete = mmgroupUserDelete.isDisplayed();
			Assert.fail();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
}
