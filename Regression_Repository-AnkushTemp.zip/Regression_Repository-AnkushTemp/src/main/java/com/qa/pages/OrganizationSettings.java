package com.qa.pages;

import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.python.icu.text.SimpleDateFormat;
import org.python.modules.thread.thread;

import com.qa.util.TestBase;

import groovyjarjarantlr4.v4.runtime.tree.xpath.XPath;


public class OrganizationSettings extends TestBase
{

//#####################################--------GROUP TAB-----------############################################
	@FindBy(xpath = "//a[contains(text(), 'Groups')]")
	WebElement groupTab;
	
	@FindBy(xpath = "//a[contains(text(), 'Create Group')]")
	WebElement createGroup;
	
	@FindBy(xpath = "//input[@name = 'group_name']")
	WebElement newGroupName;
	
	@FindBy(xpath = "//li[@role = 'presentation']")
	WebElement studentSearchOption;
	

	@FindBy(xpath = "//*[@id='group_desc']")
	WebElement newGroupdesc;
	
	@FindBy(xpath = "//input[@name = 'creategroup']")
	WebElement createButton;
	
	@FindBy(xpath = "//input[@name = 'group_name']")
	WebElement groupSearch;
	
	@FindBy(xpath = "//button[@id = 'searchgroup']")
	WebElement searchButton;
	
	@FindBy(xpath = "//div[@role = 'status' and contains(text(), 'filtered')]")
	WebElement filteredData;
	
	@FindBy(xpath = "//table[@aria-describedby = 'tablelisting_info']//td[1]")
	WebElement searchResult;
	
	@FindBy(xpath = "//*[@id='tablelisting']/tbody/tr[1]/td[3]")
	WebElement userCount;
	@FindBy(xpath = "//a[contains(text() , 'Delete User')]")
	WebElement deleteUser;

	@FindBy(xpath = "//button[text() = 'Yes']")
	WebElement deleteYesButton;
	
	
	@FindBy(xpath = "//a[@title = 'Edit Group Details']")
	WebElement editGroup;
	
	//#####################################--------TITLE TAB-----------############################################	
	@FindBy(xpath = "//a[contains(text(), 'Title')]")
	WebElement titleTab;
	
	@FindBy(xpath = "//a[contains(text(), 'Notifications')]")
	WebElement notifications;

	String radioBtns="//table/tbody//label/input";
    String buttonbtnEvent="//table/tbody//td[3]/input[@readonly]";
    String buttonbtnRepet="//table/tbody//td[4]//button[contains(@class,'disabled')]";
                
	
	@FindBy(xpath = "//a[contains(text(), 'Create Job Title')]")
	WebElement createTitle;
	
	@FindBy(xpath = "//input[@name = 'Job_tilte_name']")
	WebElement newTitleName;
	
	
	@FindBy(xpath = "//*[@id='job_code']")
	WebElement jobCode;
	
	@FindBy(xpath = "//button[text() = 'Create']")
	WebElement createJob;
		
	@FindBy(xpath = "//input[@name = 'jobtitle']")
	WebElement titleSearch;
	
	@FindBy(xpath = "//span[@role = 'status']")
	WebElement studentSearchResult;
	
	@FindBy(xpath = "//button[@id = 'searchbtn']")
	WebElement searchTitleButton;
	
	@FindBy(xpath = "//div[@role = 'status' and text() = 'Showing 1 to 1 of 1 entries']")
	WebElement titleSearchPage;
	
	@FindBy(xpath = "//table[@aria-describedby = 'jobtitle_info']//td[1]")
	WebElement titleSearchResult;
	
	@FindBy(xpath = "//a[@title = 'Edit Job Title Details']")
	WebElement editTitle;
	
	
	@FindBy(xpath = "//button[text() = 'Save']")
	WebElement saveTitle;

	@FindBy(xpath = "//*[@id=\"studentlistbody\"]//em[@title=\"Remove member from group\"]")
	WebElement removeGroup;

	@FindBy(xpath = "(//*[@id='tablelisting']//i)[1]")
	WebElement viewGroup;

	@FindBy(xpath = "//*[@id='jobtitle']//a/i")
	WebElement viewJob;

	public static String groupName, groupNamedes,titleName,titleCode;
	
	public static String[] jobTitle,groupNames;
	public static int groupCount, memberCount, unitCount;
	public static String newUnitName;
	

	public OrganizationSettings()
	{
		PageFactory.initElements(driver, this);
	}

	//#####################################--------Organization Hierarchy-----------############################################	
	
	@FindBy(xpath = "//div[@class='left-nav tab-content']//a[contains(text(),'Level 2')]")
	WebElement level2Link;
	
	@FindBy(xpath = "//div[@class='left-nav tab-content']//a[contains(text(),'Level 3')]")
	WebElement level3Link;
	

	@FindBy(xpath = "//div[@class='left-nav tab-content']//a[contains(text(),'Level 4')]")
	WebElement level4Link;
	
	
	@FindBy(xpath = "//a[text() = 'Create Level 2']")
	WebElement createLevel2Link;
	
	@FindBy(xpath = "//a[text() = 'Create Level 3']")
	WebElement createLevel3Link;
	
	@FindBy(xpath = "//a[text() = 'Create Level 4']")
	WebElement createLevel4Link;
	
	@FindBy(xpath = "//a[text() = '  Add/Edit ']")
	WebElement add;
	
	@FindBy(xpath = "//*[@id=\"unit_2\"]")
	WebElement level2;
	
	@FindBy(xpath = "//*[@id=\"unit_3\"]")
	WebElement level3;
	
	@FindBy(xpath = "//*[@id=\"popup-submit-btn\"]")
	WebElement savebtn;
	
	
	
	@FindBy(xpath = "//input[@name = 'unit_name']")
	WebElement unitName;
	
	@FindBy(xpath = "//div[@style = 'display: block;'][1]")
	WebElement unitAdrDisplay;
	
	@FindBy(xpath = "//input[@name = 'include_address']")
	WebElement unitAdrCheckbox;
	
	@FindBy(xpath = "//input[@name = 'address1']")
	WebElement unitAdr1;
	
	
	@FindBy(xpath = "//input[@name = 'address2']")
	WebElement unitAdr2;
	
	@FindBy(xpath = "//*[@id='contactPersonName']")
	WebElement contactPersonName;
	
	
	@FindBy(xpath = "//input[@name='contact_email']")
	WebElement contact_email;
	
	@FindBy(xpath = "//input[@name='contact_phone']")
	WebElement contact_phone;
	
	
	
	@FindBy(xpath = "//input[@name = 'city']")
	WebElement unitCity;
	
	@FindBy(xpath = "//*[@id='form_unitCode']")
	WebElement unitCode;
	
	
	@FindBy(xpath = "//select[@name = 'country_id']")
	WebElement selectUnitCountry;
	
	@FindBy(xpath = "//select[@name = 'state_id']")
	WebElement selectunitState;
	
	@FindBy(xpath = "//input[@name = 'zipcode']")
	WebElement unitZip;
	
	@FindBy(xpath = "//button[@id = 'submit_btn']")
	WebElement unitCreate;
	
	
	@FindBy(xpath = "//*[@id='deleteprocess']")
	WebElement submit;

	@FindBy(xpath = "(//a[@class = 'action_dropdown'])")
	WebElement unitAction;
	
	@FindBy(xpath = "//a[contains(text(), 'Edit')]")
	WebElement unitEdit;
	
	@FindBy(xpath = "(//a[contains(text(), 'View')])")
	WebElement unitView;
	
	@FindBy(xpath = "(//a[@data-target = '#unitdiv'])")
	WebElement unitRow;
	
	@FindBy(xpath = "//p[@id='userExistErr']")
	WebElement messagevalidate;
	
	
	
	@FindBy(xpath = "(//a[contains(text(), 'Delete')])")
	WebElement unitDelete;
	
	@FindBy(xpath = "//a[text() = 'Yes']")
	WebElement unitYesButton;
	
	@FindBy(xpath = "//*[@id='confirm-delete']//a[text()='Cancel']")
	WebElement unitCancelButton;
	
	
	
	@FindBy(xpath = "//input[@id = 'search_term']")
	WebElement unitsearchBox;
	
	@FindBy(xpath = "//button[@id = 'search']")
	WebElement unitsearchIcon;
	
	@FindBy(xpath = "No records found")
	WebElement unitsearchResult;
	
	@FindBy(xpath = "//a[@id = 'add_edit']")
	WebElement AddUnitLevelLink;
	
	@FindBy(xpath = "//button[@id = 'popup-submit-btn']")
	WebElement AddUnitLevelsave;
	
	@FindBy(xpath = "//a[contains(@class, 'unitadmin')]")
	WebElement AddUnitButton;
	
	@FindBy(xpath = "//input[@id = 'combobox']")
	WebElement searchTextBox;
	
	@FindBy(xpath = "//li[@role = 'presentation']/a")
	WebElement learnerSearchResult;
	
	@FindBy(xpath = "//*[@id='usernotfound']/p")
	WebElement usernotfound;
	
	
	@FindBy(xpath = "//li[@role = 'presentation']")
	WebElement learnerSearchOption;
	
	@FindBy(xpath = "//button[@id = 'add-admin-observer']")
	WebElement buttonAddUnitAdmin;
	
	@FindBy(xpath = "//*[@id='myModalForm']/div[1]/button")
	WebElement cancelBtn;
	
	
	@FindBy(xpath = "//a[contains(@class, 'unitobserver')]")
	WebElement AddUnitObserverButton;
	
	@FindBy(xpath = "//span[text()='Add Unit Observer - Automation Test']")
	WebElement UnitObserverPopUp;
	
	@FindBy(xpath = "//table[@id = 'admins']//tbody/tr/td[2]")
	WebElement adminTableRow;
	
	@FindBy(xpath = "//label[@for = 'non_existing_user']")
	WebElement addManuallyRadioButton;
	
	
	@FindBy(xpath = "//*[@id='myModalForm']//div[contains(@class,'tab-pane active')]//button[contains(text(),'Cancel')]")
	WebElement cancel;
	
	//*[@id='add_non_exiting_user']//button[contains(text(),'Cancel')]
	@FindBy(xpath = "//input[@name = 'first_name']")
	WebElement firstNameText;
	
	@FindBy(xpath = "//input[@name = 'last_name']")
	WebElement lastNameText;
	
	@FindBy(xpath = "//input[@id = 'email_address']")
	WebElement emailText;
	
	@FindBy(xpath = "(//button[@class = 'btn btn-default red_btn'])[2]/span")
	WebElement buttonManuallyEnable;
	
	@FindBy(xpath = "(//button/span[text() = 'Add Unit Admin']/ancestor::button)[2]")
	WebElement buttonAddUnitAdminManually;
	
	@FindBy(xpath = "(//button/span[text() = 'Add Unit Observer']/ancestor::button)[2]")
	WebElement buttonAddUnitObserverManually;
	
	String levelxLink = "//div[@class='left-nav tab-content']//li[";
	String createLevelxLink = "//a[text() = 'Create Level ";
	String selectUnit = "//select[@id = 'unit_";
	OrganizationHome orgHome;
	
	@FindBy(xpath = "//table[@id = 'admins']//tbody/tr/td[4]")
	WebElement adminTableActionButton;

	@FindBy(xpath = "//a[text() = 'Remove Admin Role']")
	WebElement adminTableRemoveAdmin;

	@FindBy(xpath = "//a[text() = 'Remove Observer Role']")
	WebElement adminTableRemoveObserver;

	@FindBy(xpath = "//a[text() = 'Submit']")
	WebElement submitRemoveAdmin;
	//#####################################--------Demographic Report TAB-----------############################################
	
	@FindBy(xpath = "//a[contains(text(), 'Demographic Report')]")
	WebElement reportTab;
	
	@FindBy(xpath = "(//a[@title = 'Download Source File'])[1]")
	WebElement dwnld;
	
	@FindBy(xpath = "//*[@id='submitBtn']")
	WebElement submitBtn;
	
	
	
	@FindBy(xpath = "//*[@id='file_name']")
	WebElement file_name;
	
	@FindBy(xpath = "//*[@id='deltachangetext']/span[text()=' (This setting is not available for selection.  Please contact RQIP to enable this option.)']")
	WebElement msg;
		
	@FindBy(xpath = "//*[@id='deltachangetext']/span[text()=' (This option has been selected by RQIP.  Please contact RQIP for any changes.)']")
	WebElement msg2;
	
	@FindBy(xpath = "//input[@name='import_settings' and @value='3']")
	WebElement alllearneroptionCheck;
	
	
	
	@FindBy(xpath = "//a[contains(text(),'Demographic Settings')]")
	WebElement DemographicSettings;
	
	@FindBy(xpath = "//*[@id='combobox']")
	WebElement search;
	
	
	@FindBy(xpath = "//*[@id='addstudentstolistbutton']")
	WebElement addUser;
	
	//#####################################--------Notification Settings-----------############################################
	
	@FindBy(xpath = "//a[contains(text(), 'Notifications')]")
	WebElement notificationTab;
	
	String notificationTable = "(//table[contains(@class, 'notification')])[1]//tbody/tr";
	
	//############################################## Variables ################################################
	
	OrganizationAccess orgAcc;
	static public String groupName2,groupName1,contactEmail;

	//#####################################--------GROUP TAB-----------############################################	
	
	public void navigateGroup()
	{
		wait.until(ExpectedConditions.visibilityOf(groupTab));
		groupTab.click();
	}
	
	

	public void deleteUnitAdmin()
	{
	wait.until(ExpectedConditions.visibilityOf(adminTableActionButton));
	adminTableActionButton.click();
	wait.until(ExpectedConditions.visibilityOf(adminTableRemoveAdmin));
	adminTableRemoveAdmin.click();
	wait.until(ExpectedConditions.visibilityOf(submitRemoveAdmin));
	submitRemoveAdmin.click();
	}

	public void deleteUnitObserver()
	{
	wait.until(ExpectedConditions.visibilityOf(adminTableActionButton));
	adminTableActionButton.click();
	wait.until(ExpectedConditions.visibilityOf(adminTableRemoveObserver));
	adminTableRemoveObserver.click();
	wait.until(ExpectedConditions.visibilityOf(submitRemoveAdmin));
	submitRemoveAdmin.click();
	}
	 public void enterOtherGroupDetails()
	    {
	        WebDriverWait wait = new WebDriverWait(driver, 20);
	        wait.until(ExpectedConditions.visibilityOf(newGroupName));
	        String date = new java.util.Date().toString();
	        date = date.replace(" ", "");
	        String name = "group_"+date;
	        newGroupName.sendKeys(name);
	        groupName2 = name;
	    }
	public void clickOnCreateGroup()
	{
		wait.until(ExpectedConditions.visibilityOf(createGroup));
		createGroup.click();
	}
	public void CreateGroupbtnnotAvalble()
	{
		try
		{
			wait.until(ExpectedConditions.visibilityOf(createGroup));
			createGroup.click();
			Assert.fail("Group btn should not be available");
		}
		catch(Exception e)
		{
			System.out.println("Group btn is not be available");
		}
		
	}

	public void enterGroupDetails()
	{
		wait.until(ExpectedConditions.visibilityOf(newGroupName));
		String date = new java.util.Date().toString();
		date = date.replace(" ", "");
		String name = "group_"+date;
		newGroupName.sendKeys(name);
		groupName = name;
		groupName = name;
		groupName1 = name;
		groupNamedes=name;
		newGroupdesc.sendKeys(name+"_AutoDescription");
		System.out.println(groupName);
		;
	}
	public void clickTosubmit()
	{
		wait.until(ExpectedConditions.visibilityOf(submit));
		submit.click();
		
	}
	public void clickOnCreate()
	{
		createButton.click();
		wait.until(ExpectedConditions.visibilityOf(createGroup));
	}
	 public void searchOtherGroupName()
	    {
	        try {
	            WebDriverWait wait = new WebDriverWait(driver, 20);
	            wait.until(ExpectedConditions.visibilityOf(groupSearch));
	            groupSearch.sendKeys(groupName2);
	            searchButton.click();
	            JavascriptExecutor js = (JavascriptExecutor)driver;
	            String val = js.executeScript("return document.readyState").toString();
	            System.out.println(val);
	            while(!(val.equalsIgnoreCase("complete")))
	            {
	                val = js.executeScript("return document.readyState").toString();
	            }
	            Thread.sleep(5000);
	        }
	        catch (Exception e)
	        {
	            System.out.println(e.getMessage());
	            Assert.fail(e.getMessage());
	        }
	    }
	    

	 public void validateAnotherSearchResult()
	    {
	        String result = searchResult.getText();
	        System.out.println("Group name is " + groupName2);
	        System.out.println("Searched group name is " + result);
	        Assert.assertEquals(groupName2.trim(), result.trim());
	    }
	public void searchGroupName()
	{
		wait.until(ExpectedConditions.visibilityOf(groupSearch));
		groupSearch.sendKeys(groupName);
		searchButton.click();
	}
	public void searchGroupName(int i)
	{
		wait.until(ExpectedConditions.visibilityOf(groupSearch));
		groupSearch.clear();
		groupSearch.sendKeys( User.group[i-1]);
		searchButton.click();
	}
	public void validateSearchResult()
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			
		wait.until(ExpectedConditions.visibilityOf(filteredData));
		}
		catch(Exception e)
		{
			
		}
		String result = searchResult.getText();
		System.out.println("Group name is " + groupName);
		System.out.println("Searched group name is " + result);
		Assert.assertEquals(groupName.trim(), result.trim());
	}
//
	
	public void validateSearchResultUser(String user)
	{
//		wait.until(ExpectedConditions.visibilityOf(filteredData));
		String result = userCount.getText();
	
		Assert.assertEquals(user.trim(), result.trim());
	}
	public void clickOnEditGroup()
	{
		wait.until(ExpectedConditions.visibilityOf(editGroup));
		editGroup.click();
	}

	public void validatetheuser(String count)
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='tablelisting' ]/tbody/tr/td[3]"))));
		
		Assert.assertEquals(driver.findElement(By.xpath("//*[@id='tablelisting' ]/tbody/tr/td[3]")).getText(), count);
	}
	

	
	public void clickOnViewGroup()
	{
		wait.until(ExpectedConditions.visibilityOf(viewGroup));
		viewGroup.click();
	}

	public void clickOnViewJob()
	{
		wait.until(ExpectedConditions.visibilityOf(viewJob));
		viewJob.click();
	}

	
	public void enterUpdatedGroupDetails()
	{
		wait.until(ExpectedConditions.visibilityOf(newGroupName));
		newGroupName.click();
		newGroupName.clear();
		newGroupName.sendKeys(groupName + "_update");
		groupNamedes=groupName;
		groupName=groupName + "_update";
	}
	
	
	public void validateGroup()
	{
		
		Assert.assertTrue("Validation group name", driver.findElement(By.xpath("//*[@id=\"groupform\"]//p[text()='"+groupName+"']")).getText().contains(groupName));
		Assert.assertTrue("Validation group description", driver.findElement(By.xpath("//*[@id=\"groupform\"]//p[text()='"+groupNamedes+"_AutoDescription']")).getText().contains(groupNamedes+"_AutoDescription"));
		
	}

	public void validateUserGroup(String name)
	{
		try
		{
		Thread.sleep(3000);	
		}
		catch(Exception e)
		{
			
		}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='studentlistbody']/tr/td[2]"))));
		
		
		Assert.assertTrue("Validation if user name group", driver.findElement(By.xpath("//*[@id='studentlistbody']/tr/td[2]")).getText().contains(name));
		
	}
	

	public void validateUsernorecord(String name)
	{
		try
		{
		Thread.sleep(3000);	
		}
		catch(Exception e)
		{
			
		}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='studentlistbody']/tr/td[1]"))));
		
		
		Assert.assertTrue("Validation if user name group", driver.findElement(By.xpath("//*[@id='studentlistbody']/tr/td[1]")).getText().contains(name));
		
	}
	
	
	public void validateJob()
	{
		
		Assert.assertTrue("Validation Job name", driver.findElement(By.xpath("//*[@class='form-group']//span[contains(text(),'"+titleName+"')]")).getText().contains(titleName));
		Assert.assertTrue("Validation Job description", driver.findElement(By.xpath("//*[@class='form-group']//span[contains(text(),'"+titleCode+"')]")).getText().contains(titleCode));
		
	}
	public void addusergroup(String email)
	{
		wait.until(ExpectedConditions.visibilityOf(search));
		search.click();
		search.clear();
		for(int i=0;i<User.userEmail.length();i++)
			search.sendKeys(String.valueOf(User.userEmail.charAt(i)));

		try
		{
			String result = studentSearchResult.getText();
			int k=0;

			while(result.length() == 0)
			{
				result = studentSearchResult.getText();
				if(k==232)
					break;
				k++;

			}
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", studentSearchOption);
		}
		catch(Exception e)
		{

		}
		wait.until(ExpectedConditions.visibilityOf(addUser));

		addUser.click();


	}
	public void removeusergroup()
	{
		
		wait.until(ExpectedConditions.visibilityOf(removeGroup));
		
		removeGroup.click();
	}

	public void createMultipleGroups(int count)
	{
		 User.group= new String[count];
		for(int i = 0; i < count; i++)
	    {
		    orgAcc = new OrganizationAccess();
		    orgAcc.navigateOrgSetting();
		    navigateGroup();
		    clickOnCreateGroup();
		    enterGroupDetails();
		    clickOnCreate();
		    User.group[i]=groupName;
	    }
	}
	
	public void crateMultipleGroups()
	{
		
		    orgAcc = new OrganizationAccess();
		    orgAcc.navigateOrgSetting();
		    navigateGroup();
		    CreateGroupbtnnotAvalble();
		   
		 
	}
	//#####################################--------TITLE TAB-----------############################################	
	
	public void navigateTitle()
	{
		wait.until(ExpectedConditions.visibilityOf(titleTab));
		titleTab.click();
	}
	
	public void navigateNotifications()
	{
		wait.until(ExpectedConditions.visibilityOf(notifications));
		notifications.click();
	}
	public void Checkbuttonaredisable()
	{
		List<WebElement> radioBtn = driver.findElements(By.xpath(radioBtns));
		for(int i = 0; i < radioBtn.size(); i++)
		{
			try
			{
				radioBtn.get(i).click();
				Assert.fail("Should not be able change the notification");
			}
			catch(ElementNotInteractableException e)
			{
				System.out.println("radio btn disable");
			}
		}
		
		List<WebElement> btn = driver.findElements(By.xpath(buttonbtnRepet));
		Assert.assertFalse(btn.size()==0);
		for(int i = 0; i < btn.size(); i++)
		{
			try
			{
				btn.get(i).click();
				
				System.out.println("button disable");
			
			}
			catch(Exception e)
			{
				Assert.fail("Should not be able change the notification");
			}
			
		}
		
		 btn = driver.findElements(By.xpath(buttonbtnEvent));
			Assert.assertFalse(btn.size()==0);
			
		for(int i = 0; i < btn.size(); i++)
		{
			try
			{
				btn.get(i).click();
				System.out.println("button disable");
			}
			catch(ElementNotInteractableException e)
			{
				Assert.fail("Should not be able change the notification");
			
			}
		}
		
	
	}
	
	
	public void clickOnCreateTitle()
	{
		wait.until(ExpectedConditions.visibilityOf(createTitle));
		createTitle.click();
		
	}
	public void clickOnshouldnotavailableCreateTitle()
	{
		try
		{
		wait.until(ExpectedConditions.visibilityOf(createTitle));
		createTitle.click();
		Assert.fail("Create available");
		}
		catch(Exception e)
		{
			System.out.println("Create button is  not be avalible");
		}
	}
	
	public void enterTitleDetails()
	{
		wait.until(ExpectedConditions.visibilityOf(newTitleName));
		String date = new java.util.Date().toString();
		date = date.replace(" ", "");
		String name = "Title_"+date;
		newTitleName.sendKeys(name);
		titleName = name;
		titleCode=name;
		jobCode.sendKeys(titleName);
		
	}
	
	public void clickOnCreateButton()
	{
		createJob.click();
	}

	public void searchTitleName()
	{
		wait.until(ExpectedConditions.visibilityOf(titleSearch));
		titleSearch.clear();
		titleSearch.sendKeys(titleName);
		searchTitleButton.click();
	}

	public void validateSearchTitleResult()
	{
		wait.until(ExpectedConditions.visibilityOf(titleSearchPage));
		String result = titleSearchResult.getText();
		System.out.println("Title name is " + titleName);
		System.out.println("Searched title name is " + result);
		Assert.assertEquals(titleName.trim(), result.trim());
	}


	public void validateifduplicateisnotcreated()
	{
		wait.until(ExpectedConditions.visibilityOf(titleSearchPage));
		int result = driver.findElements(By.xpath("//*[@id='jobtitle']/tbody//td[text()='"+titleName+"']")).size();
			Assert.assertEquals(1, result);
	}

	
	public void clickOnEditTitle()
	{
		wait.until(ExpectedConditions.visibilityOf(editTitle));
		editTitle.click();
	}
	
	public void enterUpdatedTitleDetails()
	{
		wait.until(ExpectedConditions.visibilityOf(newTitleName));
		newTitleName.click();
		newTitleName.clear();
		newTitleName.sendKeys(titleName + "_update");
		titleName=titleName + "_update";
	}
	
	public void clickOnSaveButton()
	{
		wait.until(ExpectedConditions.visibilityOf(saveTitle));
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click()", saveTitle);
	}

	//#####################################--------Organization Hierarchy-----------############################################
	
	public void navigateLevel2()
	{
		wait.until(ExpectedConditions.visibilityOf(level2Link));
		level2Link.click();
	}
	public void navigateLevel4()
	{
		wait.until(ExpectedConditions.visibilityOf(level4Link));
		level4Link.click();
	}
	
	public void navigateLevel3()
	{
		wait.until(ExpectedConditions.visibilityOf(level3Link));
		level3Link.click();
	}
	
	public void selectforRoleName(String dropdown,String Role,String Name )
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//td[contains(text(),'"+Name+"')]/following-sibling::td[contains(text(),'"+Role+"')]/following-sibling::td[2]"))));
		driver.findElement(By.xpath("//td[contains(text(),'"+Name+"')]/following-sibling::td[contains(text(),'"+Role+"')]/following-sibling::td[2]")).click();	
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//td[contains(text(),'"+Name+"')]/following-sibling::td[contains(text(),'"+Role+"')]/following-sibling::td[2]//a[contains(text(),'"+dropdown+"')]"))));
		driver.findElement(By.xpath("//td[contains(text(),'"+Name+"')]/following-sibling::td[contains(text(),'"+Role+"')]/following-sibling::td[2]//a[contains(text(),'"+dropdown+"')]")).click();	

	}

	public void clickOnCreateLevelButton()
	{
		try
		{
			Thread.sleep(3000);
		}
		catch(Exception e)
		{
			
		}
		wait.until(ExpectedConditions.visibilityOf(createLevel2Link));
		createLevel2Link.click();
	}
	public void clickOnCreateLevel3Button()
	{
		wait.until(ExpectedConditions.visibilityOf(createLevel3Link));
		createLevel3Link.click();
	}
	public void clickOnCreateLevel4Button()
	{
		wait.until(ExpectedConditions.visibilityOf(createLevel4Link));
		createLevel4Link.click();
	}
	public void create_buttondisable()
	{
		try
		{
		wait.until(ExpectedConditions.visibilityOf(createLevel3Link));
		createLevel3Link.click();
		Assert.fail("Create level 3 is not available ");
		}
		catch(Exception e)
		{
			System.out.println("Create level 3 is available");
		}
	}
	
	
	public void addlevel(String levl2)
	{
		
		add.click();
		
		Select select = new Select(level2);
		wait.until(ExpectedConditions.visibilityOf(level2));
		if(AssignmentReport. checkifParmeterAvailable(levl2+prop.getProperty("environment")))
			levl2=AssignmentReport.getParmeterAvailable(levl2+prop.getProperty("environment"));

		level2.click();
		select.selectByVisibleText(levl2);
		
		savebtn.click();
		
	}
	
	public void add_2_level(String levl2)
	{
		
		add.click();
		
		Select select = new Select(level2);
		wait.until(ExpectedConditions.visibilityOf(level2));
		if(AssignmentReport. checkifParmeterAvailable(levl2+prop.getProperty("environment")))
			levl2=AssignmentReport.getParmeterAvailable(levl2+prop.getProperty("environment"));

		level2.click();
		select.selectByVisibleText(levl2);
		level2.click();
		
		try
		{
		Thread.sleep(5000);	
		}
		catch(Exception e)
		{
			
		}
		 select = new Select(level3);
		wait.until(ExpectedConditions.visibilityOf(level3));
		
		level3.click();
		select.selectByVisibleText(levl2);
		
		savebtn.click();
		
	}
	
	
	public void enterLevelDetails(String adr1, String city, String country, String state, String zip)
	{
		wait.until(ExpectedConditions.visibilityOf(unitName));
		unitName.sendKeys("Automation Test");		
		wait.until(ExpectedConditions.visibilityOf(unitAdr1));
		unitAdr1.sendKeys(adr1);
		unitCity.sendKeys(city);
		Select drpCountry = new Select(selectUnitCountry);
		drpCountry.selectByVisibleText(country);
		driver.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);
		Select drpState = new Select(selectunitState);
		drpState.selectByVisibleText(state);
		unitZip.sendKeys(zip);
	}
	public void enterLevelTestDetails(String adr1, String city, String country, String state, String zip)
	{
		wait.until(ExpectedConditions.visibilityOf(unitName));
		unitName.sendKeys("Test Unit");		
		wait.until(ExpectedConditions.visibilityOf(unitAdr1));
		unitAdr1.sendKeys(adr1);
		unitCity.sendKeys(city);
		Select drpCountry = new Select(selectUnitCountry);
		drpCountry.selectByVisibleText(country);
		driver.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);
		Select drpState = new Select(selectunitState);
		drpState.selectByVisibleText(state);
		unitZip.sendKeys(zip);
	}

	public void clickCreateUnit()
	{	
		wait.until(ExpectedConditions.visibilityOf(unitCreate));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", unitCreate);
		
	}
	
	public void multiUnitSetup(int level,String adr1, String city, String country, String state, String zip)
	{
		for(int i = 2; i <= level; i++)
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(levelxLink + i + "]/a"))));
			driver.findElement(By.xpath(levelxLink + i + "]/a")).click();
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(createLevelxLink + i + "']"))));
			driver.findElement(By.xpath(createLevelxLink + i + "']")).click();
			enterLevelDetails(adr1, city, country, state, zip);
			if(i > 2)
			{
				wait.until(ExpectedConditions.visibilityOf(AddUnitLevelLink));
				AddUnitLevelLink.click();
				for(int j = 2; j < i; j++)
				{
					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(selectUnit + j + "']"))));
					wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(selectUnit + j + "']"))));
					Select select =new Select(driver.findElement(By.xpath(selectUnit + j + "']")));
					select.selectByIndex(1);
					AddUnitLevelsave.click();
				}
			}
			clickCreateUnit();
			orgHome = new OrganizationHome();
			orgHome.validateSucessMesssage();
		}
	}
	
	public void clickActionButton()
	{
		wait.until(ExpectedConditions.visibilityOf(unitAction));
		unitAction.click();
	}
	
	public void clickEditButton()
	{
		wait.until(ExpectedConditions.visibilityOf(unitEdit));
		unitEdit.click();
	}
	
	public void clickViewButton()
	{
		wait.until(ExpectedConditions.visibilityOf(unitView));
		unitView.click();
	}
	
	public void validateUnitDetails(String data)
	{
		if(AssignmentReport.checkifParmeterAvailable(data))
			data=AssignmentReport.getParmeterAvailable(data);

		
		if(data.contains("Today"))
		{
			Date formatDate = new java.util.Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
			 data = formatter.format(formatDate);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='home1']//span[contains(text(),'"+data+"')]"))));
//		
		Assert.assertEquals( driver.findElement(By.xpath("(//*[@id='home1']//span[contains(text(),'"+data+"')])[1]")).getText(),data);
		Assert.assertEquals( driver.findElement(By.xpath("(//*[@id='home1']//span[contains(text(),'"+data+"')])[2]")).getText(),data);
		
		}
		else if (data.contains("CreatedEmail"))
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='home1']//span[contains(text(),'"+contactEmail+"')]"))));
			System.out.println("Validate the Details "+contactEmail+" Actual:"+ driver.findElement(By.xpath("//*[@id='home1']//span[contains(text(),'"+contactEmail+"')]")).getText());
		    
			Assert.assertEquals( driver.findElement(By.xpath("//*[@id='home1']//span[contains(text(),'"+contactEmail+"')]")).getText(),contactEmail);
				
		}
		else 
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='home1']//span[contains(text(),'"+data+"')]"))));
			System.out.println("Validate the Details "+data+" Actual:"+ driver.findElement(By.xpath("//*[@id='home1']//span[contains(text(),'"+data+"')]")).getText());
			Assert.assertEquals( driver.findElement(By.xpath("//*[@id='home1']//span[contains(text(),'"+data+"')]")).getText(),data);
				
		}
		
	}
	
	
	
	
	public void editUnitDetails()
	{
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(unitName));
			String name = unitName.getAttribute("value");
			System.out.println("Name of the unit is " + name);
			unitName.click();
			unitName.sendKeys("_update");
		} 
		catch (Exception e) 
		{
			
		}
	}
	
	public void editUnitDetail()
	{
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(unitName));
			String name = unitName.getAttribute("value");
			System.out.println("Name of the unit is " + name);
			unitName.click();
			unitName.sendKeys("_update");
			
			wait.until(ExpectedConditions.visibilityOf(unitAdr1));
			wait.until(ExpectedConditions.visibilityOf(unitAdr2));
			
			unitAdr1.sendKeys("_update");
			unitAdr2.sendKeys("Addressupdate");
			
			unitCity.sendKeys("_update");
			wait.until(ExpectedConditions.visibilityOf(unitCode));
			
			unitCode.sendKeys("AutomationCode");
			wait.until(ExpectedConditions.visibilityOf(contactPersonName));
			contactPersonName.sendKeys("AutomationName");
			wait.until(ExpectedConditions.visibilityOf(contact_phone));
			contact_phone.sendKeys("112233445");
			Date formatDate = new java.util.Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			
			String date = formatter.format(formatDate);
			date = date.replace(" ", "").replace(":", "").replace("-", "");
			
			wait.until(ExpectedConditions.visibilityOf(contact_email));
			contactEmail=User.getUserEmail(date) ;
				
			contact_email.sendKeys(contactEmail);
			Select drpCountry = new Select(selectUnitCountry);
			drpCountry.selectByVisibleText("Togo");
			driver.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);
			Select drpState = new Select(selectunitState);
			drpState.selectByVisibleText("Maritime");
			unitZip.sendKeys("1");
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
	}
	
	

	public void deleteUnit()
	{
		wait.until(ExpectedConditions.visibilityOf(unitDelete));
		String name = unitRow.getText();
		unitDelete.click();
		wait.until(ExpectedConditions.visibilityOf(unitYesButton));
		unitYesButton.click();
		wait.until(ExpectedConditions.visibilityOf(unitsearchBox));
		unitsearchBox.sendKeys(name);
		unitsearchIcon.click();
	}

	public void deleteAutomatedUnit()
	{
		try
		{
		wait.until(ExpectedConditions.visibilityOf(unitRow));
		wait.until(ExpectedConditions.elementToBeClickable(unitRow));
		String rowsElement = unitRow.toString().split("xpath:")[1].trim();
		rowsElement = rowsElement.substring(0, rowsElement.length()-1);
		List<WebElement> rows = driver.findElements(By.xpath(rowsElement));
		for(int i = 1; i <= rows.size(); i++)
		{
			String element = rowsElement + "[" + i + "]";
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(element))));
			String text =  driver.findElement(By.xpath(element)).getText().toLowerCase().trim();
			if(text.contains("automation test"))
			{
				String actionElement = unitAction.toString().split("xpath:")[1].trim();
				actionElement =actionElement.substring(0, actionElement.length()-1) + "[" + i + "]";
				driver.findElement(By.xpath(actionElement)).click();
				String deleteElement = unitDelete.toString().split("xpath:")[1].trim();
				deleteElement = deleteElement.substring(0, deleteElement.length()-1) + "[" + i + "]";
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(deleteElement))));
				driver.findElement(By.xpath(deleteElement)).click();
				wait.until(ExpectedConditions.visibilityOf(unitYesButton));
				wait.until(ExpectedConditions.elementToBeClickable(unitYesButton));
				unitYesButton.click();
				break;
			}
		}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		
		}
	}
	public void deletetestUnit()
	{
		try
		{
		wait.until(ExpectedConditions.visibilityOf(unitRow));
		wait.until(ExpectedConditions.elementToBeClickable(unitRow));
		String rowsElement = unitRow.toString().split("xpath:")[1].trim();
		rowsElement = rowsElement.substring(0, rowsElement.length()-1);
		List<WebElement> rows = driver.findElements(By.xpath(rowsElement));
		for(int i = 1; i <= rows.size(); i++)
		{
			String element = rowsElement + "[" + i + "]";
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(element))));
			String text =  driver.findElement(By.xpath(element)).getText().toLowerCase().trim();
			if(text.contains("test unit"))
			{
				String actionElement = unitAction.toString().split("xpath:")[1].trim();
				actionElement =actionElement.substring(0, actionElement.length()-1) + "[" + i + "]";
				driver.findElement(By.xpath(actionElement)).click();
				String deleteElement = unitDelete.toString().split("xpath:")[1].trim();
				deleteElement = deleteElement.substring(0, deleteElement.length()-1) + "[" + i + "]";
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(deleteElement))));
				driver.findElement(By.xpath(deleteElement)).click();
				wait.until(ExpectedConditions.visibilityOf(unitYesButton));
				wait.until(ExpectedConditions.elementToBeClickable(unitYesButton));
				unitYesButton.click();
				break;
			}
		}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			
		}
	}
	public void deleteAutomated(String leve)
	{
		
		String userrow=" //*[@id='learnerTableList']/tbody//td/a[text()='"+leve+"']//following::td[4]//a[@class='action_dropdown']";
		try
		{
			 
			Thread.sleep(5000);
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userrow))));
				
			 List<WebElement> rows = driver.findElements(By.xpath(userrow));
			 System.out.println(rows.size());
				for(int i = 0; i < rows.size(); i++)
				{
					wait.until(ExpectedConditions.elementToBeClickable(rows.get(i)));
					
					Thread.sleep(10000);
					driver.findElement(By.xpath(userrow)).click();
					
					Thread.sleep(5000);
					
					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(" //*[@id=\"learnerTableList\"]/tbody//td/a[text()='"+leve+"']//following::td[4]//ul//li/a[text()='Delete User']"))));
					driver.findElement(By.xpath(" //*[@id=\"learnerTableList\"]/tbody//td/a[text()='"+leve+"']//following::td[4]//ul//li/a[text()='Delete User']")).click();
					wait.until(ExpectedConditions.visibilityOf(deleteYesButton));
					deleteYesButton.click();
					
					driver=driver;
				}
		}
		catch(Exception e)
		{ 
		}
		
	}
	public void deleteAutomatedUnit(String leve)
	{
		try
		{
		wait.until(ExpectedConditions.visibilityOf(unitRow));
		wait.until(ExpectedConditions.elementToBeClickable(unitRow));
		String rowsElement = unitRow.toString().split("xpath:")[1].trim();
		rowsElement = rowsElement.substring(0, rowsElement.length()-1);
		List<WebElement> rows = driver.findElements(By.xpath(rowsElement));
		for(int i = 1; i <= rows.size(); i++)
		{
			String element = rowsElement + "[" + i + "]";
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(element))));
			String text =  driver.findElement(By.xpath(element)).getText().toLowerCase().trim();
			if(text.contains(leve))
			{
				String actionElement = unitAction.toString().split("xpath:")[1].trim();
				actionElement =actionElement.substring(0, actionElement.length()-1) + "[" + i + "]";
				driver.findElement(By.xpath(actionElement)).click();
				String deleteElement = unitDelete.toString().split("xpath:")[1].trim();
				deleteElement = deleteElement.substring(0, deleteElement.length()-1) + "[" + i + "]";
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(deleteElement))));
				driver.findElement(By.xpath(deleteElement)).click();
			
				System.out.println();
				wait.until(ExpectedConditions.visibilityOf(unitYesButton));
				wait.until(ExpectedConditions.elementToBeClickable(unitYesButton));
				unitYesButton.click();
				break;
			}
		}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	public void deleteAutomatedUnit(String leve,String msg)
	{
		try
		{
		wait.until(ExpectedConditions.visibilityOf(unitRow));
		wait.until(ExpectedConditions.elementToBeClickable(unitRow));
		String rowsElement = unitRow.toString().split("xpath:")[1].trim();
		rowsElement = rowsElement.substring(0, rowsElement.length()-1);
		List<WebElement> rows = driver.findElements(By.xpath(rowsElement));
		for(int i = 1; i <= rows.size(); i++)
		{
			String element = rowsElement + "[" + i + "]";
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(element))));
			String text =  driver.findElement(By.xpath(element)).getText().toLowerCase().trim();
			if(text.contains(leve))
			{
				String actionElement = unitAction.toString().split("xpath:")[1].trim();
				actionElement =actionElement.substring(0, actionElement.length()-1) + "[" + i + "]";
				driver.findElement(By.xpath(actionElement)).click();
				String deleteElement = unitDelete.toString().split("xpath:")[1].trim();
				deleteElement = deleteElement.substring(0, deleteElement.length()-1) + "[" + i + "]";
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(deleteElement))));
				driver.findElement(By.xpath(deleteElement)).click();
				//p[@id='userExistErr']
				Thread.sleep(5000);
				wait.until(ExpectedConditions.visibilityOf(messagevalidate));
				System.out.println(messagevalidate.getText());

				Assert.assertTrue(messagevalidate.getText().contains(msg));
				wait.until(ExpectedConditions.visibilityOf(unitCancelButton));
				wait.until(ExpectedConditions.elementToBeClickable(unitCancelButton));
				unitCancelButton.click();
				break;
			}
		}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	public void viewAutomatedUnit()
	{
		wait.until(ExpectedConditions.visibilityOf(unitRow));
		wait.until(ExpectedConditions.elementToBeClickable(unitRow));
		String rowsElement = unitRow.toString().split("xpath:")[1].trim();
		rowsElement = rowsElement.substring(0, rowsElement.length()-1);
		List<WebElement> rows = driver.findElements(By.xpath(rowsElement));
		for(int i = 1; i <= rows.size(); i++)
		{
			String element =  rowsElement + "[" + i + "]";
			String text =  driver.findElement(By.xpath(element)).getText().toLowerCase().trim();
			if(text.contains("automation test"))
			{
				String actionElement = unitAction.toString().split("xpath:")[1].trim();
				actionElement =actionElement.substring(0, actionElement.length()-1) + "[" + i + "]";
				driver.findElement(By.xpath(actionElement)).click();
				String unitViewString = unitView.toString().split("xpath:")[1].trim();
				unitViewString = unitViewString.substring(0, unitViewString.length()-1) + "[" + i + "]";
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitViewString))));
				driver.findElement(By.xpath(unitViewString)).click();
				break;
			}
		}
	}

	public void validateDetail(String details)
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//td[contains(text(),'"+User.userEmail+"')]"))));
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//td[contains(text(),'"+User.userEmail+"')]"))));
		
		for(int i=0;i<details.split(",").length;i++)
		{
		Assert.assertTrue("Data doesnt match",	driver.findElement(By.xpath("//td[contains(text(),'"+User.userEmail+"')]//preceding::td[text()='"+details.split(",")[i]+"']")).isDisplayed());
		}
		
	}

	public void viewAutomatedUnit(String level)
	{
		wait.until(ExpectedConditions.visibilityOf(unitRow));
		wait.until(ExpectedConditions.elementToBeClickable(unitRow));
		String rowsElement = unitRow.toString().split("xpath:")[1].trim();
		rowsElement = rowsElement.substring(0, rowsElement.length()-1);
		
		Boolean flag=false;
		List<WebElement> rows = driver.findElements(By.xpath(rowsElement));
		for(int i = 1; i <= rows.size(); i++)
		{
			String element =  rowsElement + "[" + i + "]";
			String text =  driver.findElement(By.xpath(element)).getText().trim();
			System.out.println(text);
			if(text.contains(level))
			{
				System.out.println("Clicked"+text);
				
				String actionElement = unitAction.toString().split("xpath:")[1].trim();
				actionElement =actionElement.substring(0, actionElement.length()-1) + "[" + i + "]";
				driver.findElement(By.xpath(actionElement)).click();
				String unitViewString = unitView.toString().split("xpath:")[1].trim();
				unitViewString = unitViewString.substring(0, unitViewString.length()-1) + "[" + i + "]";
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitViewString))));
				driver.findElement(By.xpath(unitViewString)).click();
				flag=true;
				break;
			}
		}
		Assert.assertTrue("Unit not found",flag);
	}
	
	public void viewAutomatedUnitandvalidatethedata(String level)
	{
		wait.until(ExpectedConditions.visibilityOf(unitRow));
		wait.until(ExpectedConditions.elementToBeClickable(unitRow));
		String rowsElement = unitRow.toString().split("xpath:")[1].trim();
		rowsElement = rowsElement.substring(0, rowsElement.length()-1);
		List<WebElement> rows = driver.findElements(By.xpath(rowsElement));
		for(int i = 1; i <= rows.size(); i++)
		{
			String element =  rowsElement + "[" + i + "]";
			String text =  driver.findElement(By.xpath(element)).getText().toLowerCase().trim();
			if(text.contains(level))
			{
				String actionElement = unitAction.toString().split("xpath:")[1].trim();
				actionElement =actionElement.substring(0, actionElement.length()-1) + "[" + i + "]";
				driver.findElement(By.xpath(actionElement)).click();
				String unitViewString = unitView.toString().split("xpath:")[1].trim();
				unitViewString = unitViewString.substring(0, unitViewString.length()-1) + "[" + i + "]";
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitViewString))));
				driver.findElement(By.xpath(unitViewString)).click();
				break;
			}
		}
	}
	
	
	public void clickOnUnitAdminButton()
	{
		wait.until(ExpectedConditions.visibilityOf(AddUnitButton));
		wait.until(ExpectedConditions.elementToBeClickable(AddUnitButton));
		AddUnitButton.click();
		try
		{
		wait.until(ExpectedConditions.visibilityOf(searchTextBox));
		}
		catch(Exception e)
		{
			wait.until(ExpectedConditions.visibilityOf(AddUnitButton));
			wait.until(ExpectedConditions.elementToBeClickable(AddUnitButton));
			AddUnitButton.click();
		}
	}
	
	public void searchAvailableUser(String email)
	{
		
		wait.until(ExpectedConditions.visibilityOf(searchTextBox));
		wait.until(ExpectedConditions.elementToBeClickable(searchTextBox));
		searchTextBox.click();
		 for(int i=0;i<email.length();i++)
		 {
			  
			 searchTextBox.sendKeys(String.valueOf(email.charAt(i))); 
		 }
		
	}
	
	public void selectAvailableUser()
	{
		try
		{
		wait.until(ExpectedConditions.visibilityOf(learnerSearchResult));
		
		String result = learnerSearchResult.getText();
      int m=0;
		while(result.length() == 0)
		{
			result = learnerSearchResult.getText();
			if(m==pagload)
				break;
			m++;
		}
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", learnerSearchOption);
		}
		catch(Exception e)
		{
			
		}
	}
	
	public void noUserFound()
	{
		wait.until(ExpectedConditions.visibilityOf(usernotfound));
		
		String result = usernotfound.getText();
		
	Assert.assertEquals(result, "No matching Users!");
	cancelBtn.click();
	
	}
	
	
	public void clickAddUnitAdmin()
	{
		wait.until(ExpectedConditions.visibilityOf(buttonAddUnitAdmin));
		wait.until(ExpectedConditions.elementToBeClickable(buttonAddUnitAdmin));
		buttonAddUnitAdmin.click();
	}
	
	public void clickAddUnitAdmindisabled()
	{
		wait.until(ExpectedConditions.visibilityOf(buttonAddUnitAdmin));
		wait.until(ExpectedConditions.elementToBeClickable(buttonAddUnitAdmin));
		Assert.assertTrue("Button is no Disable",buttonAddUnitAdmin.getAttribute("class").contains("disabled")); ;
	}
	
	public void clickAddUnitAdminManuallydisabled()
	{
		try 
		{
			Thread.sleep(4000);
			wait.until(ExpectedConditions.visibilityOf(buttonAddUnitAdminManually));
			wait.until(ExpectedConditions.elementToBeClickable(buttonAddUnitAdminManually));
			buttonAddUnitAdminManually.click();
			Assert.assertTrue("Button is no Disable",buttonAddUnitAdminManually.getAttribute("class").contains("disabled")); ;
			} 
		catch (Exception e) 
		{
		
		}
	}
	
	public void clickAddUnitObserverManuallydisabled()
	{
		try 
		{
			Thread.sleep(4000);
				wait.until(ExpectedConditions.visibilityOf(buttonAddUnitObserverManually));
			wait.until(ExpectedConditions.elementToBeClickable(buttonAddUnitObserverManually));
			buttonAddUnitObserverManually.click();
			Assert.assertTrue("Button is no Disable"+buttonAddUnitObserverManually.getAttribute("class"),buttonAddUnitObserverManually.getAttribute("class").contains("disabled")); ;
			
		
		}
		catch (Exception e)
		{
			
		}
	}
	
	public void clickAddUnitObserverManually()
	{
		try 
		{
			Thread.sleep(4000);
				wait.until(ExpectedConditions.visibilityOf(buttonAddUnitObserverManually));
			wait.until(ExpectedConditions.elementToBeClickable(buttonAddUnitObserverManually));
			buttonAddUnitObserverManually.click();
		}
		catch (Exception e)
		{
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	
	public void clickOnUnitObserverButton()
	{
		
			wait.until(ExpectedConditions.visibilityOf(AddUnitObserverButton));
			wait.until(ExpectedConditions.elementToBeClickable(AddUnitObserverButton));
			AddUnitObserverButton.click();
			try
			{
				wait.until(ExpectedConditions.visibilityOf(searchTextBox));
			}
			catch(Exception e)
			{
				wait.until(ExpectedConditions.visibilityOf(AddUnitObserverButton));
				wait.until(ExpectedConditions.elementToBeClickable(AddUnitObserverButton));
				AddUnitObserverButton.click();
			}
		
	}
	
	public void addManuallyRadioButton()
	{
		wait.until(ExpectedConditions.visibilityOf(addManuallyRadioButton));
		
		addManuallyRadioButton.click();
	}

	
	public void validateErrorMsg(String msg)
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='add_non_exiting_user']//small[text()='"+msg+"']"))));
		
		Assert.assertTrue("UI message is not as excepted"+driver.findElement(By.xpath("//*[@id='add_non_exiting_user']//small[text()='"+msg+"']")).getText(), driver.findElement(By.xpath("//*[@id='add_non_exiting_user']//small[text()='"+msg+"']")).getText().contains(msg));
	}


	public void addLearnerDetailsManually()
	{
		
		try
		{
			wait.until(ExpectedConditions.visibilityOf(addManuallyRadioButton));
			
		}
		catch(Exception e)
		{
			wait.until(ExpectedConditions.visibilityOf(AddUnitButton));
			wait.until(ExpectedConditions.elementToBeClickable(AddUnitButton));
			AddUnitButton.click();
		}
		wait.until(ExpectedConditions.visibilityOf(addManuallyRadioButton));
		
		wait.until(ExpectedConditions.elementToBeClickable(addManuallyRadioButton));
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		date = date.replace(" ", "").replace(":", "").replace("-", "");
		addManuallyRadioButton.click();
		wait.until(ExpectedConditions.elementToBeClickable(firstNameText));
		firstNameText.click();
		firstNameText.sendKeys("user");
		lastNameText.click();
		lastNameText.sendKeys("Test");
		emailText.click();
		User.userEmail = User.getUserEmail(date);
		User.loginEmail=User.userEmail;
		
		 Actions ac = new Actions(driver);
		 ac.sendKeys(emailText,User.userEmail).build().perform();
		emailText.sendKeys(Keys.TAB);
		try
		{
			Thread.sleep(3000);
		}
		catch(Exception e)
		{
			
		}
		for(int i=0;i<4;i++)
		{
		emailText.sendKeys(Keys.BACK_SPACE);
		emailText.sendKeys(String.valueOf(User.userEmail.charAt(User.userEmail.length()-1)));
		try
		{
			Thread.sleep(3000);
			
		}
		catch(Exception e)
		{
			
		}
		emailText.sendKeys(Keys.TAB);
		try
		{
			Thread.sleep(3000);
			wait.until(ExpectedConditions.elementToBeClickable(buttonManuallyEnable));
			break;
		}
		catch(Exception e)
		{
			
		}
		}
       

		try
		{
			Thread.sleep(3000);
		}
		catch(Exception e)
		{
			
		}	
		wait.withTimeout(timeout, TimeUnit.MILLISECONDS);
		wait.until(ExpectedConditions.elementToBeClickable(buttonManuallyEnable));
		wait.until(ExpectedConditions.visibilityOf(buttonManuallyEnable));
	}
	
	public void addalreadyLearnerDetailsManually()
	{
		wait.until(ExpectedConditions.visibilityOf(addManuallyRadioButton));
		wait.until(ExpectedConditions.elementToBeClickable(addManuallyRadioButton));
		addManuallyRadioButton.click();
		wait.until(ExpectedConditions.elementToBeClickable(firstNameText));
		firstNameText.click();
		firstNameText.sendKeys("Ansh");
		lastNameText.click();
		lastNameText.sendKeys("G");
		emailText.click();
	
		
		 Actions ac = new Actions(driver);
		 ac.sendKeys(emailText,User.userEmail).build().perform();
		emailText.sendKeys(Keys.TAB);
		try
		{
			Thread.sleep(3000);
		}
		catch(Exception e)
		{
			
		}
		for(int i=0;i<4;i++)
		{
		emailText.sendKeys(Keys.BACK_SPACE);
		emailText.sendKeys(String.valueOf(User.userEmail.charAt(User.userEmail.length()-1)));
		try
		{
			Thread.sleep(3000);
			
		}
		catch(Exception e)
		{
			
		}
		emailText.sendKeys(Keys.TAB);
		try
		{
			Thread.sleep(3000);
			wait.until(ExpectedConditions.elementToBeClickable(buttonManuallyEnable));
			break;
		}
		catch(Exception e)
		{
			
		}
		}
       

		try
		{
			Thread.sleep(3000);
		}
		catch(Exception e)
		{
			
		}	
		wait.withTimeout(timeout, TimeUnit.MILLISECONDS);
		wait.until(ExpectedConditions.elementToBeClickable(buttonManuallyEnable));
		wait.until(ExpectedConditions.visibilityOf(buttonManuallyEnable));
	}
	
	
	public void clickAddUnitAdminManually()
	{
		try 
		{
			Thread.sleep(4000);
			wait.until(ExpectedConditions.visibilityOf(buttonAddUnitAdminManually));
			wait.until(ExpectedConditions.elementToBeClickable(buttonAddUnitAdminManually));
			buttonAddUnitAdminManually.click();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	

	
	public void checkRowAvailable() 
	{
		wait.until(ExpectedConditions.visibilityOf(adminTableRow));
	}
	
	
	
	//#####################################--------Demographic Report TAB-----------############################################	
	
	public void navigateDemographicReport()
	{
		wait.until(ExpectedConditions.visibilityOf(reportTab));
		reportTab.click();
	}
	
	
	
	public void clickSFTPImportoption(String option)
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//label[contains(text(),'"+option+"')]"))));
		
		if(option.contains("Large File Processing"))
			driver.findElement(By.xpath("//label[contains(text(),'"+option+"') and @id='deltachangetext']")).click();
		else
		{
			driver.findElement(By.xpath("//label[contains(text(),'"+option+"')]")).click();
			
            wait.until(ExpectedConditions.visibilityOf(file_name));
			
			file_name.clear();
			String date = new java.util.Date().toString();
			date = date.replace(" ", "");
			date=date.replace(":", "");
			file_name.sendKeys(date+".csv");
		
		}
		wait.until(ExpectedConditions.visibilityOf(submitBtn));
		submitBtn.click();
		
	}
	
	public void validateifoptionareDisable(int count)
	{
		Assert.assertEquals(driver.findElements(By.xpath("//input[@name='import_settings' and @disabled=\"disabled\"]")).size(), count);
	
		try
		{
		alllearneroptionCheck.click();
		Assert.fail();
		}
		catch(ElementNotInteractableException  e)
		{
			
		}
		wait.until(ExpectedConditions.visibilityOf(msg2));
		
		
	}
	
	public void validateifoptionareDisable()
	{
		Assert.assertEquals(driver.findElements(By.xpath("//input[@name='import_settings' and @disabled='disabled']")).size(), 1);
		wait.until(ExpectedConditions.visibilityOf(msg));
		
	}
	
	
	
	public void validateText()
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@class='tab-content']"))));
//		driver.findElement(By.xpath("//div[@class='tab-content']")).click();
		System.out.println(driver.findElement(By.xpath("//div[@class='tab-content']")).getText());
	}
	
	
	
	public void validate_if_mentioned_text_is_present(String line)
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@class='tab-content']"))));
//		driver.findElement(By.xpath("//div[@class='tab-content']")).click();
//		System.out.println(driver.findElement(By.xpath("//div[@class='tab-content']")).getText());
		Assert.assertTrue("\""+line+"\" text is missing or not updated",driver.findElement(By.xpath("//div[@class='tab-content']")).getText().contains(line));
	}
	

	public void validate_if_mentioned_text_is_not_present(String line)
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@class='tab-content']"))));
//		driver.findElement(By.xpath("//div[@class='tab-content']")).click();
		Assert.assertFalse("\""+line+"\" text is missing or not updated",driver.findElement(By.xpath("//div[@class='tab-content']")).getText().contains(line));
	}
	
	
	
	public void navigateDemographicSettings()
	{
		wait.until(ExpectedConditions.visibilityOf(DemographicSettings));
		DemographicSettings.click();
	}
	
	
	public void clickonCancel()
	{
		wait.until(ExpectedConditions.visibilityOf(cancel));
		cancel.click();
	}
	
	
	public void clickDownloadLink()
	{
		wait.until(ExpectedConditions.visibilityOf(dwnld));
		dwnld.click();
	}

	//#####################################--------Notification Settings-----------############################################

	public void navigateNotificationTab()
	{
		wait.until(ExpectedConditions.visibilityOf(notificationTab));
		notificationTab.click();
	}
	
	public void turnOffNotification(String field)
	{
		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(notificationTable))));
		List<WebElement> elementList= driver.findElements(By.xpath(notificationTable));
		for(int i = 1; i <= elementList.size(); i++)
		{
			String event = driver.findElement(By.xpath(notificationTable + "[" + i + "]/td[2]")).getText();
			if(event.trim().equalsIgnoreCase(field.trim()))
			{
				driver.findElement(By.xpath(notificationTable + "[" + i + "]/td[1]//span")).click();
				break;
			}
		}
	}
	
	public void viewAutomatedUnit(String item,String Status)
	{
		wait.until(ExpectedConditions.visibilityOf(unitRow));
		wait.until(ExpectedConditions.elementToBeClickable(unitRow));
		String rowsElement = unitRow.toString().split("xpath:")[1].trim();
		rowsElement = rowsElement.substring(0, rowsElement.length()-1);
		List<WebElement> rows = driver.findElements(By.xpath(rowsElement));
		for(int i = 1; i <= rows.size(); i++)
		{
			String element =  rowsElement + "[" + i + "]";
			String text =  driver.findElement(By.xpath(element)).getText().toLowerCase().trim();
			
				String actionElement = unitAction.toString().split("xpath:")[1].trim();
				actionElement =actionElement.substring(0, actionElement.length()-1) + "[" + i + "]";
				driver.findElement(By.xpath(actionElement)).click();
			
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='tablelisting']//ul[@class='dropdown-menu']//a"))));
				
				
				List<WebElement> actionitem = driver.findElements(By.xpath("//*[@id='tablelisting']//ul[@class='dropdown-menu']//a"));
				Boolean flag=false;
				for(int m=0;m<actionitem.size();m++)
				{
					System.out.println(actionitem.get(m).getText());
					
					if(actionitem.get(m).getText().contains(item))
					{
						flag=true;	
						break;
					}
					
				}
				if(Status.equals("Present"))
					Assert.assertTrue("Not Present"+item,flag);
				else
					Assert.assertFalse("Present"+item,flag);
				driver.findElement(By.xpath(actionElement)).click();
				
			
		}
	}
	public void checkforRoleNameExists(String dropdown,String Role,String Name )
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//td[contains(text(),'"+Name+"')]/following-sibling::td[contains(text(),'"+Role+"')]/following-sibling::td[2]"))));
		driver.findElement(By.xpath("//td[contains(text(),'"+Name+"')]/following-sibling::td[contains(text(),'"+Role+"')]/following-sibling::td[2]")).click();	
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//td[contains(text(),'"+Name+"')]/following-sibling::td[contains(text(),'"+Role+"')]/following-sibling::td[2]//a[contains(text(),'"+dropdown+"')]"))));
	boolean value =	driver.findElement(By.xpath("//td[contains(text(),'"+Name+"')]/following-sibling::td[contains(text(),'"+Role+"')]/following-sibling::td[2]//a[contains(text(),'"+dropdown+"')]")).isDisplayed();	
	Assert.assertTrue(value);
	driver.findElement(By.xpath("//td[contains(text(),'"+Name+"')]/following-sibling::td[contains(text(),'"+Role+"')]/following-sibling::td[2]")).click();
	
	}

}
