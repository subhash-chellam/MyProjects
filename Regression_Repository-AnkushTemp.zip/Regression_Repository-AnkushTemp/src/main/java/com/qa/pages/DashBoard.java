package com.qa.pages;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.qa.util.TestBase;

public class DashBoard extends TestBase
{
	@FindBy(xpath = "//div[text()='Organizations']")
	WebElement orgPanel;
	
	@FindBy(xpath = "//li[@id = 'menu_user']/a")
	WebElement userMgmtDrop;
	
	@FindBy(xpath = "//ul[@class = 'dropdown-menu']//a[text() = 'User Management']")
	WebElement userManagementLink;
	
	@FindBy(xpath = "//li[@id = 'menu_course']/a")
	WebElement courseMgmtDrop;
	
	@FindBy(xpath = "//ul[@class = 'dropdown-menu']//a[text() = 'Course Management']")
	WebElement courseManagementLink;
	
	@FindBy(xpath = "//ul[@class = 'dropdown-menu']//a[text() = 'Insights Management']")
	WebElement insightManagementLink;
	
	@FindBy(xpath = "(//li[@id = 'license']//a)[1]")
	WebElement usercourseManagementLink;

	@FindBy(xpath = "//ul[@class = 'dropdown-menu']//a[text() = 'Manage User Course']")
	WebElement manageusercourseLink;

	@FindBy(xpath = "//div[text() = 'Number of Cycles']/following-sibling::div/input")
	WebElement courseManagementCycleNumber;
	
	@FindBy(xpath = "(//li[@id = 'license']//a)//following-sibling::ul/li/a")
	List<WebElement> usercourseManagementOptions;
		
	@FindBy(xpath = "//h1[text() = 'Generate CME/CE Feed']")
	WebElement GenerateClaimsDefaultHeading;
	
	@FindBy(xpath = "(//li[@id = 'license']//a)//following-sibling::ul/li/a[text() = 'Generate CME/CE Feed']")
	WebElement generateClaimsLink;
	
	@FindBy(xpath = "//ul[@class = 'dropdown-menu']//a[text() = 'User Roles Management']")
	WebElement userRoleManagementLink;
	
	
	public static int cycleNumber; 
	
	String roleTable = "//table[@id = 'instructor-table']/tbody/tr";
	String userRoleNextButtonEnable = "//a[text() = 'Next' and not(contains(@class,'disable'))]";
	String manageClaimTabCount = "//div[@class = 'main-content']//ul/li";

	JavascriptExecutor executor = (JavascriptExecutor)driver;
	
	
	//Initialize Page objects
		public DashBoard() 
		{
			PageFactory.initElements(driver, this);
		}
		
		public void selectOrgpanel()
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(orgPanel));
			orgPanel.click();
		}
		
		public void clickUserMgmtDropDown()
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userMgmtDrop));
			userMgmtDrop.click();
		}

		public void waitfor1min(int min)
		{
			try {
				Thread.sleep(60000*min);
				
			} catch (Exception e) {
				// TODO: handle exception
			}
		}

		public void clickUserManagementOption()
		{
			wait.until(ExpectedConditions.visibilityOf(userManagementLink));
			userManagementLink.click();
		}

		public void clickCourseMgmtDropDown()
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(courseMgmtDrop));
			courseMgmtDrop.click();
			//executor.executeScript("arguments[0].click();", courseMgmtDrop);
		}

		public void clickCourseManagementOption()
		{
//			WebDriverWait wait = new WebDriverWait(driver, 30);
//			wait.until(ExpectedConditions.visibilityOf(courseManagementLink));
//			courseManagementLink.click();
			executor.executeScript("arguments[0].click();", courseManagementLink);
		}
		
		public void clickInsightManagementOption()
		{
//			WebDriverWait wait = new WebDriverWait(driver, 30);
//			wait.until(ExpectedConditions.visibilityOf(insightManagementLink));
//			insightManagementLink.click();
			executor.executeScript("arguments[0].click();", insightManagementLink);
		}
		public void clickUsercourseMgmtDropDown()
		{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(usercourseManagementLink));
		usercourseManagementLink.click();
		}
		public void clickManageusercourseOption()
		{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(manageusercourseLink));
		manageusercourseLink.click();
		}
		
		public void getNumberOfCycle()
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(courseManagementCycleNumber));
			cycleNumber = Integer.parseInt(courseManagementCycleNumber.getAttribute("value"));
			System.out.println("The number of cycles displayed in course mgmt page is " + cycleNumber);
		}
		
		public void validateCountOptionsUserCourseMgmt(int countExpected) {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOfAllElements(usercourseManagementOptions));
			int countActual = usercourseManagementOptions.size();
			Assert.assertTrue(countExpected == countActual);
		}
		
		public void validateUserCourseMgmtOptions(String value) {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOfAllElements(usercourseManagementOptions));
			for(WebElement element: usercourseManagementOptions) {
				String name = element.getText().toString().toLowerCase().trim();
				System.out.println(name);
				if(name.contains(value))
					Assert.fail(value + " is present in the user course management dropdown");
				clickUsercourseMgmtDropDown();
			}			
		}
		
		public void validateUserCourseMgmtOptionsAvailable(String value) {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOfAllElements(usercourseManagementOptions));
			boolean flag = false;
			for(WebElement element: usercourseManagementOptions) {
				String name = element.getText().toString().trim();
				System.out.println(name);
				if(name.contains(value))
					flag = true;
				clickUsercourseMgmtDropDown();
			}			
			Assert.assertTrue(flag);
		}

		public void clickGenerateClaimsOption()
		{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(generateClaimsLink));
		generateClaimsLink.click();
		}
		
		public void validateGenerateClaimsTabOptions(String value) {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOfAllElements(GenerateClaimsDefaultHeading));
			int tabCount = driver.findElements(By.xpath(manageClaimTabCount)).size();
			Assert.assertFalse("Tab options are available under claims page", tabCount > 0);
		}
		
		public void clickUserRoleManagementOption()
		{
			wait.until(ExpectedConditions.visibilityOf(userRoleManagementLink));
			userRoleManagementLink.click();
		}
		
		public void validateRoleAvailable(String role) {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(roleTable))));
			boolean flag = false;
			List<WebElement> rowList = driver.findElements(By.xpath(roleTable));
			int nextButtonSize = driver.findElements(By.xpath(userRoleNextButtonEnable)).size();
			int tableAvailableSize = rowList.size();
			for(int i = 1; i <= tableAvailableSize; i++) {
				String availableRoleName = driver.findElement(By.xpath(roleTable + "[" + i + "]/td[1]")).getText();
				if(availableRoleName.equalsIgnoreCase(role)) {
					flag = true;
					break;
				}
			if(flag == false && nextButtonSize > 0) {
				driver.findElement(By.xpath(userRoleNextButtonEnable)).click();
				tableAvailableSize = driver.findElements(By.xpath(roleTable)).size();
				nextButtonSize = driver.findElements(By.xpath(userRoleNextButtonEnable)).size();
		}
		}
			Assert.assertTrue(flag);
		}

}
