package com.qa.pages;

import java.io.BufferedInputStream;
import static io.restassured.RestAssured.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.TestNG;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import javax.xml.parsers.DocumentBuilderFactory;  
import javax.xml.parsers.DocumentBuilder;  
import org.w3c.dom.Document;  
import org.w3c.dom.NodeList;  
import org.w3c.dom.Node;  
import org.w3c.dom.Element;  
import java.io.File;

import com.beust.jcommander.internal.Maps;
import com.deque.html.axecore.results.Results;
import com.deque.html.axecore.results.Rule;
import com.deque.html.axecore.selenium.AxeBuilder;
import com.deque.html.axecore.selenium.AxeReporter;
import com.google.common.util.concurrent.ExecutionError;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.jayway.jsonpath.JsonPath;
import com.manybrain.mailinator.client.MailinatorClient;
import com.manybrain.mailinator.client.message.GetInboxRequest;
import com.manybrain.mailinator.client.message.GetMessageRequest;
import com.manybrain.mailinator.client.message.Inbox;
import com.manybrain.mailinator.client.message.Message;
import com.manybrain.mailinator.client.message.Part;
import com.manybrain.mailinator.client.message.Sort;
import com.opencsv.CSVReader;
import com.qa.util.TestBase;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

import org.json.*;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellRangeAddress;
import org.monte.media.math.Rational;
import org.monte.media.Format;
import org.monte.screenrecorder.ScreenRecorder;

import static org.monte.media.AudioFormatKeys.*;
import static org.monte.media.VideoFormatKeys.*;
import java.awt.*;
public class test {
	static   int  t;
	 private static ScreenRecorder screenRecorder;
	 static String chromePath = System.getProperty("user.dir");
	 public static Properties prop;
	  final static String secretKey1 = "AutoClan";
	
	public static void main(String[] args) throws Exception {
		
		
		File xlsxFile = new File("C:\\Users\\INSKA6\\git\\Regression_RepositoryRQIP\\ExceptionandOrgLogFolder\\UtilizationReport.xlsx");
        
        //New students records to update in excel file
    
        try {
            //Creating input stream
            FileInputStream inputStream = new FileInputStream(xlsxFile);
             
            //Creating workbook from input stream
            Workbook workbook = WorkbookFactory.create(inputStream);
 
            //Reading first sheet of excel file
            Sheet sheet = null;
//            if(FeatureName.contains("Smoke"))
            	sheet = 	workbook.getSheetAt(0);
//            else
//            	sheet = 	workbook.getSheetAt(1);
            	
            	String filDate="RQILLP-3464";
            	
            	Iterator<Row> rowIterator = sheet.iterator();
            	   while(rowIterator.hasNext()) {
            	            
            	            Row row = rowIterator.next();
            	            
            	            Iterator<Cell> cellIterator = row.iterator();               
            	                        
            	            while(cellIterator.hasNext()) {
            	                Cell currentCell = cellIterator.next();
            	                
            	                // To get values of the merged cells
            	                
            	                for(int i = 0; i < sheet.getNumMergedRegions(); i++) {
            	                    
            	                    CellRangeAddress region = sheet.getMergedRegion(i);
            	                    
            	                    int colIndex = region.getFirstColumn(); // no of columns merged
            	                    int rownum = region.getFirstRow();      // no of rows merged
            	                    
            	                    int last = region.getLastRow(); // no of columns merged
//            	                    int lastcol = region.getLastColumn();      // no of rows merged
            	                    
//            	                    System.out.println(i);
            	                    
            	                    if(rownum == currentCell.getRowIndex() && colIndex == currentCell.getColumnIndex()) {
            	                    	 System.out.println(region.getFirstRow() + " " + region.getLastRow());
              	                       
            	                    	System.out.println(region.getFirstColumn() + " " + region.getLastColumn());
            	                    	String data= sheet.getRow(rownum).getCell(colIndex).getStringCellValue();
            	                        if(filDate.equals(data))
            	                        {
            	                        	
            	                        for(int m=rownum;m<=last;m++)
            	                        {	
            	                        	for(int n=1;n<5;n++)
                	                   {
            	                        Row rw=sheet.getRow(m); //returns the logical row  
            	                        Cell cll=rw.getCell(n); //getting the cell representing the given column  
            	                        if(cll!=null)
            	                        System.out.println(cll.getStringCellValue());
            	                        else
            	                        System.out.println("Data");;  
                    	                        	
            	                    	}
            	                        }
            	                        
            	                        }
            	                    }
            	                }
            	            }
            	        }
        }
        catch(Exception e)
        {
        	e.printStackTrace();
        }
        
	}  
	
	  private static byte[] key;
	  private static SecretKeySpec secretKey;

	  public static void setKey(final String myKey) {
	    MessageDigest sha = null;
	    try {
	      key = myKey.getBytes("UTF-8");
	      sha = MessageDigest.getInstance("SHA-1");
	      key = sha.digest(key);
	      key = Arrays.copyOf(key, 16);
	      secretKey = new SecretKeySpec(key, "AES");
	    } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
	      e.printStackTrace();
	    }
	  }

	  public static String encrypt(final String strToEncrypt, final String secret) {
	    try {
	      setKey(secret);
	      Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
	      cipher.init(Cipher.ENCRYPT_MODE, secretKey);
	      return Base64.getEncoder()
	        .encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
	    } catch (Exception e) {
	      System.out.println("Error while encrypting: " + e.toString());
	    }
	    return null;
	  }

	  public static String decrypt(final String strToDecrypt, final String secret) {
	    try {
	      setKey(secret);
	      Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
	      cipher.init(Cipher.DECRYPT_MODE, secretKey);
	      return new String(cipher.doFinal(Base64.getDecoder()
	        .decode(strToDecrypt)));
	    } catch (Exception e) {
	      System.out.println("Error while decrypting: " + e.toString());
	    }
	    return null;
	  }
	
//	   public static  JsonPath getResponseBody(){
//		   RestAssured.baseURI = "https://mailinator.com/api/v2/domains/laerdalonline.com/inboxes/testuser02/messages";
//			RequestSpecification httpRequest = RestAssured.given().header("Authorization", "d0c357b446994f8cba5166b21b5e3cdf");
//			Response response = httpRequest.get("/testuser02-1678430729-92407772");
//
//			
//	 	   }
	
	
	public static JSONObject courseListName;	
	public static void coursesNamejson()
	{

		
		

		JSONParser jsonParser = new JSONParser();

		try (FileReader reader = new FileReader( System.getProperty("user.dir")+"\\src\\test\\java\\resources\\MailUsers2.json", StandardCharsets.UTF_8))
		{
			//Read JSON file
			Object obj = jsonParser.parse(reader);
			
			courseListName = (JSONObject) obj;

//			courseListName.
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}



	}
	public static void excel(String ScenarioName,String Status,String errorLog,String FeatureName,String orgID,String path)
	{
		 // Creating file object of existing excel file
        File xlsxFile = new File("E:/Excel/students.xlsx");
         
        //New students records to update in excel file
    
        try {
            //Creating input stream
            FileInputStream inputStream = new FileInputStream(xlsxFile);
             
            //Creating workbook from input stream
            Workbook workbook = WorkbookFactory.create(inputStream);
 
            //Reading first sheet of excel file
            Sheet sheet = null;
            if(FeatureName.contains("Smoke"))
            		workbook.getSheetAt(0);
            else
          		workbook.getSheetAt(1);
              	
            //Getting the count of existing records
            int rowCount = sheet.getLastRowNum();
           
            Object[][] data = {
                    {rowCount,ScenarioName, Status, errorLog,FeatureName, orgID,path}};
     
            //Iterating new students to update
            for (Object[] rowdata : data) {
                 
                //Creating new row from the next row count
                Row row = sheet.createRow(++rowCount);
 
                int columnCount = 0;
 
                //Iterating student informations
                for (Object info : rowdata) {
                     
                    //Creating new cell and setting the value
                    Cell cell = row.createCell(columnCount++);
                    if (info instanceof String) {
                        cell.setCellValue((String) info);
                    } else if (info instanceof Integer) {
                        cell.setCellValue((Integer) info);
                    }
                }
            }
            //Close input stream
            inputStream.close();
 
            //Crating output stream and writing the updated workbook
            FileOutputStream os = new FileOutputStream(xlsxFile);
            workbook.write(os);
             
            //Close the workbook and output stream
            workbook.close();
            os.close();
             
            System.out.println("Excel file has been updated successfully.");
             
        } catch (EncryptedDocumentException | IOException e) {
            System.err.println("Exception while updating an existing excel file.");
            e.printStackTrace();
        }
	}
	public static String getMailTemplate(String Mail)
	{
		String mail=null;
		try   
		{  
			String env="Bhagat";
		//creating a constructor of file class and parsing an XML file  
		File file = new File(System.getProperty("user.dir") + "\\src\\main\\java\\com\\qa\\config\\mail.Templates\\"+env+"MailTemplates.xml");  
		//an instance of factory that gives a document builder  
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
		//an instance of builder to parse the specified xml file  
		DocumentBuilder db = dbf.newDocumentBuilder();  
		Document doc = db.parse(file);  
		doc.getDocumentElement().normalize();  
		 mail = doc.getElementsByTagName(Mail).item(0).getTextContent();
		return mail;
		}
		// nodeList is not iterable, so we are using for loop  
		
		catch (Exception e)   
		{  
		e.printStackTrace();  
		}  
		return mail;
	}

	private static char[] generatePassword(int length) {
	      String capitalCaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	      String lowerCaseLetters = "abcdefghijklmnopqrstuvwxyz";
	      String specialCharacters = "@$";
	      String numbers = "1234567890";
	      String combinedChars = capitalCaseLetters + lowerCaseLetters + specialCharacters + numbers;
	      Random random = new Random();
	      char[] password = new char[length];

	      password[0] = lowerCaseLetters.charAt(random.nextInt(lowerCaseLetters.length()));
	      password[1] = capitalCaseLetters.charAt(random.nextInt(capitalCaseLetters.length()));
	      password[2] = specialCharacters.charAt(random.nextInt(specialCharacters.length()));
	      password[3] = numbers.charAt(random.nextInt(numbers.length()));
	   
	      for(int i = 4; i< length ; i++) {
	         password[i] = combinedChars.charAt(random.nextInt(combinedChars.length()));
	      }
	      return password;
	   }
}
