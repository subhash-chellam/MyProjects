package com.qa.pages;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.util.TestBase;


public class EndUser extends TestBase 
{
	@FindBy(xpath = "//span[contains(text(), 'Welcome')]")
	WebElement endUserHomePage;

	@FindBy(xpath = "//a[contains(text(), 'My Account') and @target]")
	WebElement endUserAccountLink;

	@FindBy(xpath = "//h2[contains(text(), 'Edit')]")
	WebElement endUserAccountPage;

	@FindBy(xpath = "//button[text() = 'Completed and Expired Programs']")
	WebElement endUsercompletedPrograms;

	@FindBy(xpath = "//button[text()='Current Programs']")
	WebElement endUserCurrentPrograms;
	
	@FindBy(xpath = "//*[@id='tab1']//div[@class='nocourse-available']//span")
	WebElement nocoursepresnt;
	
	@FindBy(xpath = "//*[@id='tab2']//div[@class='nocourse-available']")
	WebElement nocoursepresntCompleteTab;
	
	@FindBy(xpath = "//*[@id='current-programs']//span[contains(text(),'Expires on')]")
	WebElement expiredOninCurrentTab;
	
	@FindBy(xpath = "//*[@id='expired-programs']//span[contains(@class,'expires_on_text')]")
	WebElement expiredOnCompletedTab;
	
	
	@FindBy(xpath = "//*[@id='current-programs']//div/span[text()='Subscribed,']")
	WebElement SubscribedOnCompletedTab;
	
	
	
	@FindBy(xpath = "//a[contains(text(), 'Log Out') and @target]")
	WebElement endUserLogOut;

	@FindBy(xpath = "(//a[text() = 'Activate'])[1]")
	WebElement endUserActivateCourse;

	@FindBy(xpath = "(//span[text() = 'I Agree'])[1]")
	WebElement endUserAgreeLink;

	@FindBy(xpath = "(//span[contains(text(), 'Launch')])[1]")
	WebElement endUserLaunch;

	@FindBy(xpath = "(//span[contains(text(), 'Review')])[1]")
	WebElement endUserReview;

	@FindBy(xpath = "//*[@name='context_id']")
	WebElement context_id;

	@FindBy(xpath = "//*[@name='context_label']")
	WebElement context_label;

	@FindBy(xpath = "//*[@name='context_title']")
	WebElement context_title;
	

	@FindBy(xpath = "//*[@id=\"page-wrap-inner\"]//a[text()='Claim CME/CE']")
	WebElement ClaimCME;
	
	
	@FindBy(xpath = "//*[@id='cmeEvaluationValidation']//div[@class='full clearfix']")
	WebElement message;
	
	@FindBy(xpath = "//*[@id='cmeEvaluationValidationClose']/span[1]")
	WebElement close;
	
	
	
	@FindBy(xpath = "//select")
	WebElement ClaimCMEpart2;
	
	

	@FindBy(xpath = "//div[@class='checkcredit-label']//label")
	WebElement CME_CE;


	@FindBy(xpath = "//*[@id=\"speciality_master_id\"]")
	WebElement specialitymaster_id;

	@FindBy(xpath = "//*[@id=\"designation\"]")
	WebElement designation;

	@FindBy(xpath = "//*[@id=\"classification_code\"]")
	WebElement classification_code;


	@FindBy(xpath = "//*[@id=\"state\"]")
	WebElement state;



	@FindBy(xpath = "//*[@id=\"submitButton\"]")
	WebElement submitButton;

	@FindBy(xpath = "//*[@id=\"submitButtonCME\"]")
	WebElement submitButtonCME;

	@FindBy(xpath = "//*[@id=\"zipcode\"]")
	WebElement zipcode;

	@FindBy(xpath = "//*[@id=\"address1\"]")
	WebElement address;


	@FindBy(xpath = "//*[@id=\"phone\"]")
	WebElement phone;

	@FindBy(xpath = "//*[@id='credits_claimed']")
	WebElement credits_claimed;


	@FindBy(xpath = "//label[text() = 'Order ID']//following-sibling::div")
	WebElement paymentOrderID;

	@FindBy(xpath = "//label[text() = 'Amount Paid']//following-sibling::div")
	WebElement paymentAmount;
	
	@FindBy(xpath = "//label[text() = 'Course Name']//following-sibling::div")
	WebElement paymentCourseName;
	
	@FindBy(xpath = "//label[text() = 'Transaction Ref Number']//following-sibling::div")
	WebElement paymentTransactionNumber;

	@FindBy(xpath = "//button[@id = 'select_reason']")
	WebElement CancelReasonDropdown;

	@FindBy(xpath = "//div[@class = 'alert alert-warning custom-width']//h5")
	WebElement cancelWarningHeading;

	@FindBy(xpath = "//div[@class = 'alert alert-warning custom-width']//span")
	WebElement cancelWarningText;

	@FindBy(xpath = "//a[@id = 'cancel_back_btn']")
	WebElement cancelAndGoButton;

	

	@FindBy(xpath = "//input[@type = 'submit']")
	WebElement endUserSubmitDate;

	@FindBy(xpath = "//span[contains(text(),'Start')]")
	WebElement endUserStartCourse;

	@FindBy(xpath = "//span[contains(text(), 'Resume')]")
	WebElement endUserResumeCourse;
	@FindBy(xpath = "//input[@name = 'vendor_sharable_id']")
	WebElement vendorSharableId;
	@FindBy(xpath = "//span[contains(text(),'Start')]")
	WebElement endUserStartCourseonline;

//	@FindBy(xpath = "//span[text() = 'Exit']")
//	WebElement endUserExitCourse;

	@FindBy(xpath = "//span[text() = 'Exit Exercise']")
	WebElement endUserExitCourse;

	@FindBy(xpath = "//*[@id='cecmeModal']//button[text()='Acknowledge']")
	WebElement cecmeBtn;

	@FindBy(xpath = "//*[@id='send-email']")
	WebElement sendemai;

	
	@FindBy(xpath = "//button[@id='Exit Exercise']")
	WebElement ExitCourse;

	@FindBy(xpath = "//span//a[text() = 'My Courses']")
	WebElement endUserMyCoursesLink;
//	@FindBy(xpath = "//span//a[text() = 'My Courses']")
	@FindBy(xpath = "//span//a[text() = 'My Programs']")
	WebElement endUserProgramLink;

	
	
	
	@FindBy(xpath = "//iframe[@id = 'frame']")
	WebElement frameTwo;
	@FindBy(xpath = "//div[contains(@class,'footer')]/p")
	WebElement laerdalFooter;
	
	@FindBy(xpath = "(//span[@class= 'test_links'])[1]")
	WebElement complete;

	@FindBy(xpath = "//iframe[@id = 'basicltiLaunchFrame']")
	WebElement frameOne;

	@FindBy(xpath = "//iframe[@id = 'launchFrame']")
	WebElement fraeOne;

	@FindBy(xpath = "//table[@class]")
	WebElement sharedCourses;

	@FindBy(xpath = "//span[text() = 'I Agree']")
	WebElement iAgreeButton;

	@FindBy(xpath = "//a[text() = 'Evaluation']")
	WebElement endUserEvaluation;

	@FindBy(xpath = "//input[@type = 'submit']")
	WebElement endUserSubmitEvaluation;

	@FindBy(xpath = "(//td[@title = 'Action'])[1]//a")
	WebElement endUserCourseAction;

	@FindBy(xpath = "//div[@id = 'announcement']")
	WebElement courseExit;

	@FindBy(xpath = "//input[@name = 'test_today_date']")
	WebElement endUserCourseDate;

	@FindBy(xpath = "//a[@aria-label='Completed Activities']")
	WebElement completedActivitiesButton;

	@FindBy(xpath = "//button[text() = 'Completed and Expired Programs']")
	WebElement completedProgramsButton;

	@FindBy(xpath = "//table[@aria-describedby = 'course-name']//tbody/tr[1]/td[4]")
	WebElement completedCourseReview;

	@FindBy(xpath = "//select[@id='select-active-status']")
	WebElement filterStatus;

	@FindBy(xpath = "//select[@id='select-cm-exp-status']")
	WebElement filterexpStatus;

	
		
	@FindBy(xpath = "//label[@class='switch']//input[@id='expired-course-switch']/following::span[@class='slider round']")
	WebElement expireToggleButton;

	@FindBy(xpath = "//table[@aria-describedby = 'completed_courses']//tbody/tr[1]/td[6]//a")
	WebElement completedCourseReviews;

	
	@FindBy(xpath = "//*[@id=\"page-wrap-inner\"]//a[text()='View eCard']")
	WebElement completedCourseEcard;
	
	
	@FindBy(xpath = "//td[@title='Score']//span[text()='100%']")
	List<WebElement> reviewScore;
	
	@FindBy(xpath = "//td//a[@class='review_btn']")
	List<WebElement> review_btn;
	
	@FindBy(xpath = "//td[@title='Completed Activities']//span")
	List<WebElement> topics;
	
	
	

	@FindBy(xpath = "//*[@id='page-wrap-inner']//a[text()='Certificate']")
	WebElement completedCourseCertificate;

	@FindBy(xpath = "//button[text()='Continue']")
	WebElement Continue;


	@FindBy(xpath = "//*[@id='hideshowbtn' and @aria-label='Completed Activities']")
	WebElement completedActivities;

	
	

	@FindBy(xpath = "//button[text()='Activate']")
	WebElement Activate;

	@FindBy(xpath = "//a[text() = 'Survey']")
	WebElement endUserSurvey;


	@FindBy(xpath = "//input[@type = 'submit']")
	WebElement endUserSubmitSurvey;

	@FindBy(xpath = "//*[@id='successbox']")
	WebElement successmsg;

	@FindBy(xpath = "//*[@id=\"confirm-delete\"]//a/span[text()='Continue']")
	WebElement confirm;
	
	@FindBy(xpath = "//a[@aria-label='Cancel Claim CME/CE Credit']")
	WebElement cancel;
	@FindBy(xpath = "//a[@title='View eCard']")
	WebElement viewEcardButton;
	@FindBy(xpath = "//img[@title='View Certificate']")
	WebElement viewCertficateButton;
	
	

	@FindBy(xpath = "//img[@alt = 'RQI Logo']")
	WebElement laerdalLogo;
	
	
	@FindBy(xpath = "//div/span[@class='welcomeuser']")
	WebElement welcome;
	
	@FindBy(xpath = "//ul[@aria-labelledby = 'navAccountMenu']/li//a/ancestor::li/a")
	WebElement menuDropdown;
	
	@FindBy(xpath = "//ul[@aria-labelledby = 'navAccountSupp']/li//a/ancestor::li/a")
	WebElement supportDropdown;
	
	@FindBy(xpath = "//a[contains(text(),'(Download Certificate)')]")
	WebElement download;
	
	@FindBy(xpath = "//*[@id='current-programs']//a[text()='Subscribe']")
	WebElement subscribeBtn;
	
	
	
	@FindBy(xpath = "//*[@id='wrapper-right']//span[text()='Order Summary']")
	WebElement orderSummary;
	
	@FindBy(xpath = "//*[@id='wrapper-left']/address")
	WebElement Billingaddress;
	
	@FindBy(xpath = "//*[@id='org-address' and text()='Organization address']")
	WebElement Organizationaddress;
	
	@FindBy(xpath = "//*[@id='wrapper-left']/h3[text()='Billing address']")
	WebElement BillingaddressHeader;
	
	
	@FindBy(xpath = "//h3[contains(text(),'Subscription Plan')]//following::span[1]")
	WebElement SubscriptionPlan;
	
	@FindBy(xpath = "//*[@id='viewTerms']")
	WebElement clickonTermAndCondition;
	
	@FindBy(xpath = "//*[@id='termsDialog-desktop']//li[3]/a[text()='Cancellation &']")
	WebElement cancellationAndRefundPolicy;
	
	@FindBy(xpath = "//*[@id='termsDialog-desktop']//li[2]/a[text()='Purchase']")
	WebElement purchaseTab;
	
	@FindBy(xpath = "//*[@id='termsDialog-desktop']//li[1]/a[text()='Course']")
	WebElement courseTab;
	
	@FindBy(xpath = "//div[@id='tab1']")
	WebElement coursedescTab;
	
	@FindBy(xpath = "//div[@id='tab2']")
	WebElement purchasedescTab;
	
	@FindBy(xpath = "//div[@id='tab3']")
	WebElement cancellationAndRefunddescTab;
	
	@FindBy(xpath = "//button[@id='acceptTerms']")
	WebElement acceptTermsBtn;
	
	@FindBy(xpath = "//*[@id='wrapper-left']//p/input")
	WebElement checkBoxClass;
	
	
	@FindBy(xpath = "//div[text()='Ends on']//following::span[1]")
	WebElement endsOn;

	@FindBy(xpath = "(//div[text()='Completed']//following::span)[2]")
	WebElement Completed;

	
	
	
	@FindBy(xpath = "//*[@id='wrapper-left']/h2")
	WebElement courseDescription;
	
	@FindBy(xpath = "//input[@name='email']")
	WebElement contactEmail;
	
	@FindBy(xpath = "//input[@id='terms']")
	WebElement acceptCheckBox;

	@FindBy(xpath = "(//*[@id='page-wrap-inner']//h4[contains(text(),'Subscription Expiration: ')]//following::span)[1]")
	WebElement subscriptionExpiration;
	
	@FindBy(xpath = "//*[@id='success-popup']/div/div[3]/div/strong")
	WebElement subscriptionDetails;
	
	@FindBy(xpath = "//*[@id='validity_info']/span")
	WebElement validity_infonDetails;
	
	
	
	//*[@id='current-programs']//span[text()='Subscribed,']
	
	@FindBy(xpath = "//button[contains(text(),'Pay Now')]")
	WebElement payNowBtn;
	
	@FindBy(xpath = "(//*[@id='current-programs']//span[text()='Payment Required'])[2]")
	WebElement payNowRequiredLabel;
	
	
	@FindBy(xpath = "//*[@id='success-popup']//button[2]")
	WebElement closeBtn;
	
	@FindBy(xpath = "//*[@id='cancel_order']")
	WebElement cancel_order;
	
	
	
	@FindBy(xpath = "//*[@id='success-popup']//button[text()='Launch Now']")
	WebElement launch_NowBtn;
	
	@FindBy(xpath = "//*[@id='success-popup']//button[text()='ORDER RECEIPT']")
	WebElement order_ReceiptBtn;

	
	
	@FindBy(xpath = "//input[@id='cc_number']")
	WebElement cc_number;
	
	@FindBy(xpath = "//input[@id='expdate_month']")
	WebElement expdate_month;
	
	@FindBy(xpath = "//input[@id='expdate_year']")
	WebElement expdate_year;
	
	
	
	@FindBy(xpath = "//*[@id='main']//a[contains(text(),\"Return to merchant's website\")]")
	WebElement returnToMerchant;
	
	@FindBy(xpath = "//input[@id='btn_pay_cc']")
	WebElement payNow;
	
	
	@FindBy(xpath = "//*[@id='orderViewPopup']")
	WebElement orderViewPopupBtn;
	
	
	@FindBy(xpath = "//a[@aria-label='Download Receipt Downloads in Pdf Format']")
	WebElement downloadReceipt;
	
	@FindBy(xpath = "(//button[text()='Close' and @data-dismiss='modal'])[1]")
	WebElement orderViewPopupCloseBtn;
							
	@FindBy(xpath = "//*[@id='current-programs']//span[text()='Assigned on']")
	List<WebElement> assignsOnDate;
	
	@FindBy(xpath = "//a[contains(text(), 'Reference Library') and @target]")
	WebElement endReferenceLibraryLink;
	
	@FindBy(xpath = "//a[contains(text(), 'My Programs') and @target]")
	WebElement myProgramLink;
	
	@FindBy(xpath = "//*[@id='success-close']/button[text()='Close']")
	WebElement cmeClose;
	

	
	String contactSupportLabel = "//h3[text() = 'Contact Support']";

	
	
	String topicAvailable = "//table[@class ='table panel panel-default referencePanel' ]";

	String courseTablescrom = "//div[@id='accordion']//table[contains(@class, 'table panel panel-default')]";

	String courseTable = "//table[@class = 'table panel panel-default referencePanel']";
	String curseTable="//table[@class = 'table panel panel-default']";
	String courseTablelock = "//table[contains(@class, 'table panel panel-default')]";
	String completeTable = "//table[@aria-describedby = 'completed_courses']//tbody/tr";
	By course = By.xpath("//div[@id='current-programs']//div[contains(@class,'wrapper')]");
	String courseAvailable = "//div[@id='current-programs']//div[contains(@class,'wrapper-bg wrapper')]";
	String buttonxpath="//div[contains(@class,'w-sm-100 text-sm-right d-block')]//a";
	
	String supportOptionList = "//ul[@aria-labelledby = 'navAccountSupp']/li//a";
	public static String TransactionRefNumber,OrderID,OrderDate,Tpaid;
	
	
	By mandatoryQuestion = By.xpath("//small[contains(text(), 'required')]//parent::div");
	By rhapsodeCourse = By.xpath("(//input[@id = 'lis_result_sourcedid'])");
	String sideMenu = "//ul[@id = 'side_menu']/li//a";
	String menuOptionList = "//ul[@aria-labelledby = 'navAccountMenu']/li//a";
	String pagelinks = "//a[not (@href = '#') and not (@href = 'javascript:void(0);') and not (@href = 'javascript:void(0)') and @href]";
	String nlnCourseLAunchButton = "(//span[contains(text(), 'Launch')])";
	String firstRadioMandatryQuestion = "((//small[contains(text(), 'required')]//parent::div)[";
	String completeTableRow = "//table[@aria-describedby = 'completed_courses']//tbody/tr/td[";
	String cancelRefundSection = "//div[@id = 'cancel_refund_wrapper']";
	String validationErrorMessageCount = "//span[@id = 'validation_error']";
	String validationErorList = "//ol[@id = 'errorlist']/li";

	
	public static String courseTopic[],secondaryEmail=null;
	public static boolean flag = false;

	RestApi rest;

	public EndUser() 
	{
		PageFactory.initElements(driver, this);
		driver.manage().timeouts().pageLoadTimeout(300, TimeUnit.SECONDS);
	}

	

	public void validatemsgClaimCME(String msg)
	{
		wait.until(ExpectedConditions.visibilityOf(ClaimCME));

		ClaimCME.click();
		wait.until(ExpectedConditions.visibilityOf(message));
		Assert.assertTrue("Validate Message"+message.getText(),message.getText().contains(msg) );

		wait.until(ExpectedConditions.visibilityOf(close));
		close.click();

		
	}
	public static boolean isFileDownloaded_Ext(String dirPath, String ext){
		boolean flag=false;
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			flag = false;
		}

		for (int i = 1; i < files.length; i++) 
		{
			if(files[i].getName().contains(ext)) 
			{
				System.out.println(files[i].getName());
				files[i].delete();
				flag=true;
			}
		}
		return flag;
	}

	public void claimCredit()
	{
		wait.until(ExpectedConditions.visibilityOf(ClaimCME));

		ClaimCME.click();

		clamCmeDetails("12345567","Ajekar","Nurse","Physician","Nurse Practitioner","Alabama","12344" );

		try
		{
//		wait.until(ExpectedConditions.visibilityOf(confirm));
//		confirm.click();
		
		wait.until(ExpectedConditions.visibilityOf(ClaimCMEpart2));
		Select drptime = new Select(ClaimCMEpart2);
		drptime.selectByIndex(1);;
	
		submitButton.click();
		
		wait.until(ExpectedConditions.visibilityOf(confirm));
		confirm.click();

		}
		catch(Exception e)
		{
			
		}
		Students std=new Students();
		
		isFileDownloaded_Ext(std.downloadPath, ".pdf");
		
		wait.until(ExpectedConditions.visibilityOf(successmsg));
		
		Assert.assertTrue(successmsg.getText().contains("CME/CE credits updated successfully."));
		
		wait.until(ExpectedConditions.visibilityOf(ClaimCME));
		ClaimCME.click();
		
		wait.until(ExpectedConditions.visibilityOf(download));
		download.click();
		boolean dwnld = false;
		int m=0;
		do 
		{
			dwnld =std.isFileDownloaded_Ext(std.downloadPath, ".pdf");
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			m++;
		}
		while(dwnld == false);
		
		Assert.assertTrue(dwnld);
		
		std.deleteFile(Students.filePath);
	
		wait.until(ExpectedConditions.visibilityOf(cancel));
		cancel.click();
		
		
		
		
	}
	public void clamCmeDetails(String phne,String addres,String speciality,String designtion,String classification,String stte,String zipcde)
	{
		wait.until(ExpectedConditions.visibilityOf(CME_CE));

		CME_CE.click();	
		wait.until(ExpectedConditions.visibilityOf(address));

		address.sendKeys(addres);
		wait.until(ExpectedConditions.visibilityOf(phone));

		phone.sendKeys(phne);
		
		try
		{
			wait.until(ExpectedConditions.visibilityOf(credits_claimed));
			credits_claimed.sendKeys("1");
			
		}
		catch(Exception e)
		{
			
		}
		wait.until(ExpectedConditions.visibilityOf(specialitymaster_id));

		specialitymaster_id.click();

		Select drptime = new Select(specialitymaster_id);
		drptime.selectByVisibleText(speciality);;

		wait.until(ExpectedConditions.visibilityOf(designation));

		designation.click();

		drptime = new Select(designation);
		drptime.selectByVisibleText(designtion);;
		
		wait.until(ExpectedConditions.visibilityOf(classification_code));

		classification_code.click();

		drptime = new Select(classification_code);
		drptime.selectByVisibleText(classification);;
		
		wait.until(ExpectedConditions.visibilityOf(state));
		state.click();
		drptime = new Select(state);
		drptime.selectByVisibleText(stte);;
		wait.until(ExpectedConditions.visibilityOf(zipcode));

		zipcode.sendKeys(zipcde);

		try
		{
				
			wait.until(ExpectedConditions.visibilityOf(submitButtonCME));
			submitButtonCME.click();
		
		}
		catch(Exception e)
		{
		wait.until(ExpectedConditions.visibilityOf(submitButton));
		submitButton.click();
		}

	}
	public void launchFurtureAssignmentUrl(int numCount, String dateType)
	{
		LocalDate localDate = LocalDate.now();
		LocalDate changeDate = null;
		switch(dateType.toLowerCase().trim())
		{
		case "days":
			changeDate = localDate.plusDays(numCount);
			break;
		case "months":
			changeDate = localDate.plusMonths(numCount);
			break;
		case "weeks":
			changeDate = localDate.plusWeeks(numCount);
			break;
		}
		
			
			driver.navigate().to(prop.getProperty("url"+prop.getProperty("environment")).replace("admin", "mycourse?request_date=") + changeDate.toString());
		
	}
	public void clickOnSubmitOnlyWithDate()
	{
		try
		{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(endUserSubmitDate));
		String date = LocalDate.now().toString();
		System.out.println("Current date is " + date);
		if(date.length() > 1)
		{
			endUserCourseDate.click();
			endUserCourseDate.clear();
			endUserCourseDate.sendKeys(date);
			endUserCourseDate.click();
		}
		endUserSubmitDate.click();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	public void validateAssignDate()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(assignsOnDate.get(0)));
	
		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");  
	       Boolean flag=false;
//		  System.out.println(date.);
		 for(int i=0;i<assignsOnDate.size();i++)
		 {
		  Calendar cal = Calendar.getInstance();  
	        String dateAfter = sdf.format(cal.getTime());  
	        System.out.println(dateAfter);
	        Assert.assertEquals(assignsOnDate.get(i).getText().split("\n")[1], dateAfter);
	        flag=true;
		 }
		 
	     Assert.assertTrue(flag);
		String date = LocalDate.now().toString();
		
	}
	
	
	
	
	public void verifyHomePage() 
	{

		wait.until(ExpectedConditions.visibilityOf(endUserHomePage));
	}
	public void validateContextItems(String contextid, String contextlabel, String contexttitle)
	{
		String source = driver.getPageSource();
		
		Assert.assertTrue(source.toLowerCase().contains("context_id"));
		Assert.assertTrue(source.toLowerCase().contains("context_label"));
		Assert.assertTrue(source.toLowerCase().contains("context_title"));
		
		System.out.println(context_id.getAttribute("value")+" "+contextid);
		System.out.println(context_label.getAttribute("value")+" "+contextlabel);
		System.out.println(context_title.getAttribute("value")+" "+contexttitle);
		
		
	}
	public void validateRowCountActiveCourses(int expectedCount)
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);	
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" + courseAvailable + ")[1]"))));
		List<WebElement> rowCount = driver.findElements(By.xpath(courseAvailable));
		System.out.println("Row count from UI is " + rowCount.size() + " and expected count is " + expectedCount);
		Assert.assertTrue(rowCount.size() == expectedCount);
	}
	
	public void validateRowCountActiveCourses(int expectedCount,String name)
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);	
		if(courseListName.containsKey( name+"Option"))
			 name=courseListName.get( name+"Option").toString();
		try {
			name=name.replace("Â", "");
			System.out.println(name.replace("Â", ""));
			courseAvailable = "//div[@id='current-programs']//div[contains(@class,'wrapper-bg wrapper')]";
		

			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[contains(text(),'"+name+"')]" ))));
		}
		catch(NoSuchElementException e)
		{
			
			courseAvailable = "//div[@class='wrapper']//div[@class='row inner-content d-flex']";
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[contains(text(),'"+name+"')]" ))));
			
		}
		List<WebElement> rowCount = driver.findElements(By.xpath(courseAvailable+"//span[@class='course-title' and contains(text(),'"+name+"')]"));
		System.out.println("Row count from UI is " + rowCount.size() + " and expected count is " + expectedCount);
		Assert.assertTrue(rowCount.size() == expectedCount);
	}
	

	public void validateRowCountCurrentCourses(int expectedCount,String name) throws InterruptedException
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);	
		if(courseListName.containsKey( name+"Option"))
			 name=courseListName.get( name+"Option").toString();

				name=name.replace("Â", "");
			System.out.println(name.replace("Â", ""));
			courseAvailable = "//div[@id='current-programs']//div[contains(@class,'wrapper-bg wrapper')]";
			
			Thread.sleep(3000);

		
		List<WebElement> rowCount = driver.findElements(By.xpath(courseAvailable+"//span[@class='course-title' and contains(text(),'"+name+"')]"));
		System.out.println("Row count from UI is " + rowCount.size() + " and expected count is " + expectedCount);
		Assert.assertTrue(rowCount.size() == expectedCount);
	}
	public void clickOnCompletedPrograms()
	{
		wait.until(ExpectedConditions.visibilityOf(endUsercompletedPrograms));
		endUsercompletedPrograms.click();
	}
	
	public void clickOnCurrentPrograms()
	{
		wait.until(ExpectedConditions.visibilityOf(endUserCurrentPrograms));
		endUserCurrentPrograms.click();
	}
	
	
	public void clickOnexpireToggleButton()
	{
		wait.until(ExpectedConditions.visibilityOf(expireToggleButton));
		expireToggleButton.click();
	}
	
	
	public void nocoursepresent()
	{
		wait.until(ExpectedConditions.visibilityOf(nocoursepresnt));
		Assert.assertEquals(nocoursepresnt.getText(), "No programs available.");
	}
	
	public void nocoursepresntCompleteTab()
	{
		wait.until(ExpectedConditions.visibilityOf(nocoursepresntCompleteTab));
		Assert.assertEquals(nocoursepresntCompleteTab.getText(), "No programs available.");
	}
	
	
	public void validateDateShared(int count, String dateType)
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);	
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" + courseAvailable + ")[1]"))));
		List<WebElement> rowCount = driver.findElements(By.xpath(courseAvailable));
		Assert.assertTrue(rowCount.size() == count);
		for(int i = 1; i <= count; i++)
		{
			String shareDate = driver.findElement(By.xpath("(" + courseAvailable + ")[" + i + "]/td[2]")).getText();
			LocalDate localDate = LocalDate.now();
			switch(dateType.toLowerCase().trim())
			{
			case "days":
				LocalDate addedDays = localDate.plusDays(i-1);
				String formattedDate = addedDays.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
				Assert.assertEquals(shareDate, formattedDate);
				break;
			case "months":
				LocalDate addedMonths = localDate.plusMonths(i-1);
				formattedDate = addedMonths.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
				Assert.assertEquals(shareDate, formattedDate);
				break;
			case "weeks":
				LocalDate addedWeeks = localDate.plusWeeks(i-1);
				formattedDate = addedWeeks.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
				Assert.assertEquals(shareDate, formattedDate);
				break;		
			}
			
		}
	}

	public void clickMyAccount()
	{
		wait.until(ExpectedConditions.visibilityOf(endUserAccountLink));
		endUserAccountLink.click();
		wait.until(ExpectedConditions.visibilityOf(endUserAccountPage));
	}
	public void surveyCourse()
	{
		try
		{
			Thread.sleep(5000);
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(endUserSurvey));
			endUserSurvey.click();
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(mandatoryQuestion)));
			List<WebElement> mandate = driver.findElements(mandatoryQuestion);
			for(int i= 1; i<= mandate.size(); i++)
			{
				driver.findElement(By.xpath(firstRadioMandatryQuestion + i + "]//input[@type = 'radio'])[1]")).click();;
			}
			endUserSubmitSurvey.click();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}

	}

	public void clickLogOut()
	{
		wait.until(ExpectedConditions.visibilityOf(endUserLogOut));
		endUserLogOut.click();
	}

	public void launchCourse()
	{
		wait.until(ExpectedConditions.visibilityOf(endUserActivateCourse));
		endUserActivateCourse.click();
	
		wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
		endUserLaunch.click();
	}

	public void clickActivate()
	{
		try 
		{
			checkCourseAvailable();
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(endUserActivateCourse));
			endUserActivateCourse.click();
		
			wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	public void clickLaunch()
	{
		wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
		endUserLaunch.click();
		clickOnSubmitOnly();
		startCourse();
		exitCourse();
	}

	public void startORResumeCourse()
	{
		WebDriverWait wait = new WebDriverWait(driver, 20);
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(endUserStartCourse));
			endUserStartCourse.click();
		} 
		catch (Exception e) 
		{

			wait.until(ExpectedConditions.visibilityOf(endUserResumeCourse));
			endUserResumeCourse.click();
		}

	}
	public void getVendorSharableId()
	{
		WebDriverWait wait = new WebDriverWait(driver, 20);
		try 
		{
			JavascriptExecutor j = (JavascriptExecutor) driver;
			String pageSource = (String) j.executeScript("return arguments[0].getAttribute('value')", vendorSharableId);
			System.out.println("Vendor sharable id is " + pageSource);
			if(!(pageSource.length() > 0))
				Assert.fail("Vendor Sharable id not available");
		} 
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
			Assert.fail(e.getMessage());
		}
	}
	public void startCourse()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(endUserStartCourse));
		endUserStartCourse.click();

	}
	public int getTopicAvaialble()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(topicAvailable))));
		List<WebElement> count = driver.findElements(By.xpath(topicAvailable + "//tbody/tr"));
		return count.size();
	}

	public void completeCourse() 
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		try 
		{
			Thread.sleep(15000);
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(frameOne));
			Assert.assertTrue(driver.getCurrentUrl().contains("https"));
			driver.switchTo().frame("basicltiLaunchFrame");
			wait.until(ExpectedConditions.visibilityOf(frameTwo));
			driver.switchTo().frame("frame");
			wait.until(ExpectedConditions.visibilityOf(complete));
			complete.click();
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(courseExit));
			driver.switchTo().defaultContent();



		} 
		catch (Exception e) 
		{
			driver.switchTo().defaultContent();
			driver=driver;
			WebDriverWait wait = new WebDriverWait(driver, 30);
			try
			{
				WebDriverWait wait1 = new WebDriverWait(driver, 50);

				wait1.until(ExpectedConditions.visibilityOf(fraeOne));
				driver.switchTo().frame("playerframe");
				if(driver.findElement(By.xpath("//*[@id='defaultmsg']")).getText().contains("NRP organization not found for given lmsOrgId (Error Code: 400)"))
				{
					System.err.println("NRP organization not found for given lmsOrgId (Error Code: 400)");
					driver.switchTo().defaultContent();
				}
				else
					System.out.println(driver.findElement(By.xpath("//*[@id='defaultmsg']")).getText());



			}
			catch(Exception m)
			{

				driver.switchTo().defaultContent();
				driver.navigate().refresh();
				try
				{
					wait.until(ExpectedConditions.visibilityOf(frameOne));
				}
				catch(StaleElementReferenceException s)
				{

					driver.navigate().refresh();
					driver=driver;
				}
				driver.switchTo().frame("basicltiLaunchFrame");
				js.executeScript("setInterval(function() {frames[\"HYPER_19720220\"].skipSco();}, 300);//");
				try 
				{
					wait = new WebDriverWait(driver, 60);
					wait.until(ExpectedConditions.visibilityOf(frameTwo));
					driver.switchTo().frame("frame");
					wait.until(ExpectedConditions.visibilityOf(courseExit));
				}
				catch(Exception ex)
				{
					try {
						Thread.sleep(15000);
					} catch (InterruptedException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					driver.switchTo().defaultContent();
					wait.until(ExpectedConditions.visibilityOf(frameOne));
					driver.switchTo().frame("basicltiLaunchFrame");
					driver.navigate().refresh();

					String value = null;
					try {
						driver.navigate().refresh();
						Thread.sleep(20000);
						value = driver.findElement(rhapsodeCourse).getAttribute("value");

					} catch (Exception e1) {

						try
						{
							value = driver.findElement(By.xpath("//*[@id=\"lis_result_sourcedid\"]")).getAttribute("value");

						}
						catch(Exception kk)
						{
							System.out.println(driver.getPageSource().split("name=\"lis_result_sourcedid\" value=\"")[0].split(">")[0].replace("\"", ""));

							value=driver.getPageSource().split("name=\"lis_result_sourcedid\" value=\"")[1].split(">")[0].replace("\"", "");
							System.out.println(value);

						}

					}
					System.out.println(value);
					rest = new RestApi();
					rest.getResponse(value);
				}
				driver.switchTo().defaultContent();
			}
		}
	}
	
	public void completeCourseTestCode() 
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(frameOne));
			Assert.assertTrue(driver.getCurrentUrl().contains("https"));
		
			String value=driver.getCurrentUrl().split("sourceId=")[1];
			rest = new RestApi();
			rest.getResponse(value);
			driver.switchTo().defaultContent();
//			wait.until(ExpectedConditions.visibilityOf(courseExit));
			
		} 
		catch (Exception e) 
		{
			
			System.out.println(e.getMessage());
//			Assert.fail(e.getMessage());
		}
	}

	public void exitCourse()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(endUserExitCourse));
			Thread.sleep(3000);
			endUserExitCourse.click();
			wait.until(ExpectedConditions.visibilityOf(endUserProgramLink));
			endUserProgramLink.click();
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
	}

	public void cecmepopup(String name)
	{
			if(courseListName.containsKey(name+"CME_CE"))
			{
				wait.until(ExpectedConditions.visibilityOf(cecmeBtn));
				cecmeBtn.click();
			}

		
	}
	public void closececmepopup()
	{
			
				wait.until(ExpectedConditions.visibilityOf(cecmeBtn));
				cecmeBtn.click();
			
		
	}
	public void cecmepopup()
	{
		try
		{
//			    WebDriverWait wait = new WebDriverWait(driver, 15);
				wait.until(ExpectedConditions.visibilityOf(cecmeBtn));
				cecmeBtn.click();
		}
		catch(Exception e)
		{
			
		}
		
	}
	
	public boolean validateCMEPopupAvailable()
	{
		boolean flag =false;
		try
		{
			    WebDriverWait wait = new WebDriverWait(driver, 7);
				wait.until(ExpectedConditions.visibilityOf(cecmeBtn));
				flag = true;
		}
		catch(Exception e)
		{
			
		}
		return flag;
	}
	
	public void cecmepopupforsub()
	{
		  WebDriverWait wait = new WebDriverWait(driver, 7);
				wait.until(ExpectedConditions.visibilityOf(cecmeBtn));
				cecmeBtn.click();
		
				try
				{
					wait.until(ExpectedConditions.visibilityOf(sendemai));					
					sendemai.click();
					wait.until(ExpectedConditions.visibilityOf(cmeClose));
					cmeClose.click();
				}
				catch(Exception e)
				{
					
				}
		
	}
	public void clickEndUserProgramLink()
	{
		try 
		{
			driver.navigate().refresh();
			WebDriverWait wait = new WebDriverWait(driver, 30);
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(endUserProgramLink));
			endUserProgramLink.click();
			Thread.sleep(5000);
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
	}
	
	public void clickEndUserProgramLinkonline()
	{
		try 
		{
			Thread.sleep(5000);
			
			driver.navigate().refresh();
			Thread.sleep(3000);
			
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(endUserProgramLink));
			endUserProgramLink.click();
		} 
		catch (Exception e) 
		{
			Assert.fail("Error with the course");
		}
	}
	
	
	public void startORResumeCourseOnline()
	{
		WebDriverWait wait = new WebDriverWait(driver, 20);
		try
		{
			wait.until(ExpectedConditions.visibilityOf(endUserStartCourseonline));
			endUserStartCourseonline.click();
		}
		catch (Exception e)
		{

			wait.until(ExpectedConditions.visibilityOf(endUserResumeCourse));
			endUserResumeCourse.click();
		}

	}
	public void clickEndUserMyCoursesLink()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(endUserMyCoursesLink));
			endUserMyCoursesLink.click();
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());	
		}
	}
	public void onlyExitCourse()
	{
		try
		{
			Thread.sleep(5000);
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(endUserExitCourse));
			endUserExitCourse.click();
		}
		catch(Exception e)
		{
			wait.until(ExpectedConditions.visibilityOf(ExitCourse));
			JavascriptExecutor js = (JavascriptExecutor)driver;

			js.executeScript("arguments[0].click()", ExitCourse);
			
		}
	}

	public void closeTab()
	{
		driver.close();
	}
	public boolean checkCoursesAvailable()
	{
		boolean flag = false;

		for(int m=0;m<=40;m++)
		{
		 try 
		{
			
				Thread.sleep(5000);
				driver.findElement(course).isDisplayed();
				flag = true;
				break;
			}		
		
		catch (Exception e) 
		{
			driver.navigate().refresh();
				
		}
		}
		return flag;
	}
	static int m=0;
	public void checkCourseAvailable()
	{
		for(int m=0;m<=40;m++)
		{
		try 
		{
			Thread.sleep(2000);
			driver.findElement(course).isDisplayed();
			break;
		} 
		catch (Exception e) 
		{
			
					driver.navigate().refresh();
			
		}
		}
	}

	public void launchUserCourse()
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);	
		try
		{
			checkCourseAvailable();
			wait.until(ExpectedConditions.visibilityOf(endUserActivateCourse));
			endUserActivateCourse.click();
			
			wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
			endUserLaunch.click();
		}
		catch(Exception e)
		{
			try
			{
				boolean flag = endUserLaunch.isDisplayed();
				if(flag)
					endUserLaunch.click();
				else if(wait.until(ExpectedConditions.visibilityOf(endUserResumeCourse)).isDisplayed())
				{
					wait.until(ExpectedConditions.visibilityOf(endUserResumeCourse));
					endUserResumeCourse.click();
				}

			}
			catch(Exception ex)
			{
				Assert.fail(e.getMessage());
			}

		}
	}

	public void launchUserCourse1()
	{
		WebDriverWait wait = new WebDriverWait(driver, 40);	
		try
		{
			checkCourseAvailable();
			wait.until(ExpectedConditions.visibilityOf( driver.findElement(By.xpath("(" + courseAvailable +buttonxpath+")[1]"))));
			String action = null;
			try
			{
				action = driver.findElement(By.xpath("(" + courseAvailable +buttonxpath+")[1]")).getText();
			}
			catch(Exception e)
			{
					action = driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[1]")).getText();
				
			}
			action=action.toLowerCase();
			System.out.println(action);
			if(action.contains("resume"))
			{
				endUserResumeCourse.click();
			}
			else if(action.contains("activate"))
			{
				endUserActivateCourse.click();
				try {
					
					wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
					endUserLaunch.click();
					
					
				}
				catch(Exception e)
				{
					wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
					endUserLaunch.click();
				}	
				
			}

			else if(action.contains("review"))
			{
				wait.until(ExpectedConditions.visibilityOf(endUserReview));
				endUserReview.click();
			}

			else if(action.contains("launch"))
			{
				wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
				endUserLaunch.click();
			}
			flag = true;
		}
		catch(Exception e)
		{
			flag = false;
			System.out.println(e.getMessage());
			Assert.fail(e.getMessage());
		}

	}
	public String changeDate(int quarter)
	{

		LocalDate localDate = LocalDate.now();
		LocalDate firstDayOfQuarter = localDate.with(localDate.getMonth().firstMonthOfQuarter()).with(TemporalAdjusters.firstDayOfMonth());
		LocalDate lastDayOfQuarter;
		lastDayOfQuarter = firstDayOfQuarter.plusMonths(quarter*3).plusMonths(2).with(TemporalAdjusters.lastDayOfMonth());
		System.out.println(firstDayOfQuarter);
		System.out.println(lastDayOfQuarter);
		return lastDayOfQuarter.toString();
	}
	//div[@class='checkcredit-label']//label


	public int getAvailableTopicNumberscrom()
	{
		int topicCount = 0;
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseTablescrom))));
			Thread.sleep(5000);
			List<WebElement> count = driver.findElements(By.xpath(courseTablescrom + "//tbody[@class]/tr/td[4]//a"));
			if(count.size() > 0) {
			if(!driver.findElement(By.xpath(courseTablescrom + "//tbody/tr/td[4]//a[1]")).isDisplayed())
				topicCount = 0;
			else if(driver.findElement(By.xpath(courseTablescrom + "//tbody/tr/td[4]//a[1]")).getText().equalsIgnoreCase("review"))
				topicCount = 0;
			else
				topicCount = count.size();
			}
			else
				topicCount = count.size();
		}
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
			System.out.println(e.getMessage());
		}
		return topicCount;
	}
	  public int validateAvailableTopicLocked()
	    {
	        int topicCount = 0;
	        try
	        {
	            WebDriverWait wait = new WebDriverWait(driver, 30);
	            wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseTablelock))));
	            Thread.sleep(5000);
	            List<WebElement> count = driver.findElements(By.xpath(courseTablelock + "//tbody/tr/td[4]/span[@class = 'lock_icon']"));
	            topicCount = count.size();
	        }
	        catch (Exception e)
	        {
	            System.out.println(e.getMessage());
	        }
	        return topicCount;
	    }
	  public void clickEcardButton()
		{
			WebDriverWait wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.visibilityOf(viewEcardButton));
			viewEcardButton.click();
			driver.close();
		}
	  public void switchToApplicationPage()
		{
			Set<String> handles=driver.getWindowHandles();
			String window = null;
			for(String actual: handles)
	        {
				driver.switchTo().window(actual);
				String currentUrl = driver.getCurrentUrl();
				if(currentUrl.contains("/manageuser"))
				{
					window = actual;
				}			
				else
					driver.close();
				handles=driver.getWindowHandles();
	        }
			driver.switchTo().window(window);
			
		}
	  public void switchToPDFPage()
		{
			Set<String> handles=driver.getWindowHandles();
			
			boolean flag = false;
			try {
				Thread.sleep(5000);
				for(String actual: handles)
				{
					driver.switchTo().window(actual);
					String currentUrl = driver.getCurrentUrl();
					int m=0;
					while(currentUrl.contains("blank"))
					{
						Thread.sleep(5000);
						currentUrl = driver.getCurrentUrl();
						if(m==pagload)
							break;
						else
						{
							try {
								Thread.sleep(550);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
						m++;
					}
					if(currentUrl.contains("blob"))
					{
						String source = driver.getPageSource();
						Assert.assertTrue(source.toLowerCase().contains("application/pdf"));
						flag= true;
						break;
					}
					else
					{
						continue;
					}
				}
				Assert.assertTrue(flag == true);
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
				Assert.fail(e.getMessage());
			}
		}
	  public void clickviewCertficateButtonPage()
		{
			WebDriverWait wait = new WebDriverWait(driver, 15);
			driver.switchTo().frame("examReaderFrame");
			wait.until(ExpectedConditions.visibilityOf(viewCertficateButton));
			viewCertficateButton.click();
			driver.switchTo().defaultContent();
		}

	  public void switchToCertificatePage()
		{
			Set<String> handles=driver.getWindowHandles();
			for(String actual: handles)
	        {
				driver.switchTo().window(actual);
				String currentUrl = driver.getCurrentUrl();
				if(currentUrl.contains("certificate"))
				{
					break;
				}
				else
				{
					continue;
				}
	        }
		}


		public void validateCourseStatusOrgPay(String name,String btn)
		{
			if(courseListName.containsKey( name+"Option"))
				 name=courseListName.get( name+"Option").toString();

				System.out.println(name);

			if(btn.contains("LAUNCH"))
			{
			   courseAvailable = "//div[@class='wrapper']//div[@class='row inner-content d-flex']";
			   wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[contains(text(),'"+name+"')]" ))));
			}
			else
			{
				courseAvailable = "//div[@id='current-programs']//div[contains(@class,'wrapper-bg wrapper')]";
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[contains(text(),'"+name+"')]" ))));

			}
			Boolean flag=false;
			List<WebElement> rowCount = driver.findElements(By.xpath(courseAvailable));
			String action;
			for(int i = 1; i <= rowCount.size(); i++)
			{
				String courseName = driver.findElement(By.xpath("(" + courseAvailable + "//span[@class='course-title'])[" + i + "]")).getText().trim();

				action = driver.findElement(By.xpath("(" + courseAvailable +buttonxpath+")[" + i + "]")).getText();
//				String statustext = driver.findElement(By.xpath("(" + courseAvailable + "//span[@class='custom-font'])[" + i + "]")).getText().trim();
//				System.out.println(statustext);
				System.out.println(action);
				System.out.println(courseName);
//				Assert.assertEquals(statustext, status);
				
				Assert.assertEquals(action.contains(btn),true);
				
			
				flag=true;
				
				
			}
			Assert.assertTrue("Course not found",flag);
   	}
	
		public void validateCourseStatus(String status,String name,String btn)
		{
			Boolean flag=false;
			if(courseListName.containsKey( name+"Option"))
				 name=courseListName.get( name+"Option").toString();

				System.out.println(name);

			if(btn.contains("LAUNCH"))
			{
			   courseAvailable = "//div[@class='wrapper']//div[@class='row inner-content d-flex']";
			   wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[contains(text(),'"+name+"')]" ))));
			}
			else
			{
				courseAvailable = "//div[@id='current-programs']//div[contains(@class,'wrapper-bg wrapper')]";
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[contains(text(),'"+name+"')]" ))));

			}

			List<WebElement> rowCount = driver.findElements(By.xpath(courseAvailable));
			String action;
			for(int i = 1; i <= rowCount.size(); i++)
			{
				
				String courseName = driver.findElement(By.xpath("(" + courseAvailable + "//span[@class='course-title'])[" + i + "]")).getText().trim();
				System.out.println(courseName);
				if(courseName.replace(" New!","").equalsIgnoreCase(name))
				{
				action = driver.findElement(By.xpath("(" + courseAvailable +buttonxpath+")[" + i + "]")).getText();
				String statustext = driver.findElement(By.xpath("(" + courseAvailable + "//span[@class='custom-font'])[" + i + "]")).getText().trim();
				System.out.println(statustext);
				System.out.println(action);
				System.out.println(courseName);
				Assert.assertEquals(statustext, status);
				Assert.assertEquals(action.contains(btn),true);
				Assert.assertEquals(courseName.contains(name+" New!") , true);
				flag=true;
				}
			
			}
			Assert.assertTrue("Course not found",flag);
     	}
	
	public boolean launchCourseWithName(String name)
	{
		if(courseListName.containsKey( name+"Option"))
		 name=courseListName.get( name+"Option").toString();

		System.out.println(name);

//		name=name.replace("Â", "");
		WebDriverWait wait = new WebDriverWait(driver, 40);	
		boolean flag = false;
		checkCourseAvailable();


		try {
			name=name.replace("Â", "");
			System.out.println(name.replace("Â", ""));
			try
			{
			courseAvailable = "//div[@id='current-programs']//div[contains(@class,'wrapper-bg wrapper')]";
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[text()='"+name+"']" ))));

			}
			catch(NoSuchElementException e)
			{
				courseAvailable = "//div[@id='current-programs']//div[contains(@class,'wrapper-bg wrapper')]";
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[contains(text(),'"+name+"')]" ))));

			}
		}
		catch(NoSuchElementException e)
		{
			try
			{
				courseAvailable = "//div[@class='wrapper']//div[@class='row inner-content d-flex']";
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[text()='"+name+"']" ))));

			}
			catch(NoSuchElementException m)
			{
				courseAvailable = "//div[@class='wrapper']//div[@class='row inner-content d-flex']";
								wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[contains(text(),'"+name+"')]" ))));

			}

			
			
		}

	
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath( courseAvailable ))));

		List<WebElement> rowCount = driver.findElements(By.xpath(courseAvailable));

		for(int i = 1; i <= rowCount.size(); i++)
		{
			System.out.println("tess");
			String courseName = driver.findElement(By.xpath("(" + courseAvailable + "//span[@class='course-title'])[" + i + "]")).getText().trim();

			System.out.println(courseName);
			System.out.println(name);
			System.out.println(courseAvailable);
			System.out.println(rowCount.size());
			System.out.println(name.toLowerCase().trim().contains(courseName.toLowerCase().trim().replace(" new!", "")));
			System.out.println(name.toLowerCase().trim().contains(courseName.toLowerCase().trim().replace("new!", "")));
				
			if(name.toLowerCase().trim().equals(courseName.toLowerCase().trim().replace(" new!", "")))
			{
				String action;
				try
				{
					action = driver.findElement(By.xpath("(" + courseAvailable +buttonxpath+")[" + i + "]")).getText();
				}
				catch(Exception e)
				{
						action = driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).getText();
					
				}
				System.out.println(action.toLowerCase());
				if(action.toLowerCase().contains("resume"))
				{
					try
					{
						driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).click();
					}
					catch(Exception e)
					{
						driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).click();

					}
					flag = true;
					break;
				}
				else if(action.toLowerCase().contains("activate"))
				{
					driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).click();
					try
					{

				    wait.until(ExpectedConditions.visibilityOf(Activate));
					
						Activate.click();	
					}
					catch (Exception e) {
						// TODO: handle exception

						System.out.println(driver.getWindowHandles().size());
					}
					try 
					{Thread.sleep(4000);
						this.wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
						endUserLaunch.click();
						flag = true;
						break;
						
					}
					catch(Exception e)
					{
						
						
						
						wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
						endUserLaunch.click();
						flag = true;
						break;
					}	
				}
				else if(action.toLowerCase().contains("launch"))
				{
					wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
					try
					{
						driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).click();
					}
					catch(Exception e)
					{
						driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).click();

					}
					flag = true;
					break;
				}
			}
		}
		Assert.assertTrue("Course not found",flag);
		return flag;
	}
	
	public boolean launchCourseWithNameequal(String name)
	{
		if(courseListName.containsKey( name+"Option"))
		 name=courseListName.get( name+"Option").toString();

		System.out.println(name);

//		name=name.replace("Â", "");
		WebDriverWait wait = new WebDriverWait(driver, 40);	
		boolean flag = false;
		checkCourseAvailable();


		try {
			name=name.replace("Â", "");
			System.out.println(name.replace("Â", ""));
			try
			{
			courseAvailable = "//div[@id='current-programs']//div[contains(@class,'wrapper-bg wrapper')]";
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[text()='"+name+"']" ))));

			}
			catch(NoSuchElementException e)
			{
				courseAvailable = "//div[@id='current-programs']//div[contains(@class,'wrapper-bg wrapper')]";
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[contains(text(),'"+name+"')]" ))));

			}
		}
		catch(NoSuchElementException e)
		{
			try
			{
				courseAvailable = "//div[@class='wrapper']//div[@class='row inner-content d-flex']";
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[text()='"+name+"']" ))));

			}
			catch(NoSuchElementException m)
			{
				courseAvailable = "//div[@class='wrapper']//div[@class='row inner-content d-flex']";
								wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[contains(text(),'"+name+"')]" ))));

			}

			
			
		}

	
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath( courseAvailable ))));

		List<WebElement> rowCount = driver.findElements(By.xpath(courseAvailable));

		for(int i = 1; i <= rowCount.size(); i++)
		{
			System.out.println("tess");
			String courseName = driver.findElement(By.xpath("(" + courseAvailable + "//span[@class='course-title'])[" + i + "]")).getText().trim();

			System.out.println(courseName);
			System.out.println(name);
			System.out.println(courseAvailable);
			System.out.println(rowCount.size());
			System.out.println(name.toLowerCase().trim().contains(courseName.toLowerCase().trim().replace(" new!", "")));
			System.out.println(name.toLowerCase().trim().contains(courseName.toLowerCase().trim().replace("new!", "")));
				
			if(name.toLowerCase().trim().equals(courseName.toLowerCase().trim().replace(" new!", "")))
			{
				String action;
				try
				{
					action = driver.findElement(By.xpath("(" + courseAvailable +buttonxpath+")[" + i + "]")).getText();
				}
				catch(Exception e)
				{
						action = driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).getText();
					
				}
				System.out.println(action.toLowerCase());
				if(action.toLowerCase().contains("resume"))
				{
					try
					{
						driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).click();
					}
					catch(Exception e)
					{
						driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).click();

					}
					flag = true;
					break;
				}
				else if(action.toLowerCase().contains("activate"))
				{
					driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).click();
					try
					{

				    wait.until(ExpectedConditions.visibilityOf(Activate));
					
						Activate.click();	
					}
					catch (Exception e) {
						// TODO: handle exception

						System.out.println(driver.getWindowHandles().size());
					}
					try 
					{Thread.sleep(4000);
						this.wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
						endUserLaunch.click();
						flag = true;
						break;
						
					}
					catch(Exception e)
					{
						
						
						
						wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
						endUserLaunch.click();
						flag = true;
						break;
					}	
				}
				else if(action.toLowerCase().contains("launch"))
				{
					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]"))));
					try
					{
						driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).click();
					}
					catch(Exception e)
					{
						driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).click();

					}
					flag = true;
					break;
				}
			}
		}
		Assert.assertTrue("Course not found",flag);
		return flag;
	}
	
	public boolean launchCourseWithNamealready(String name)
	{
		if(courseListName.containsKey( name+"Option"))
			 name=courseListName.get( name+"Option").toString();
	
		name=name.replace("Â", "");
		WebDriverWait wait = new WebDriverWait(driver, 50);	
		boolean flag = false;
		checkCourseAvailable();


		try {
			
			
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//td//span[contains(text(),'"+name+"')]" ))));
		}
		catch(NoSuchElementException e)
		{
			courseAvailable = "//table[@class and @aria-describedby='my_courseList']//tbody/tr";
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//td//span[contains(text(),'"+name+"')]" ))));
			
		}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath( courseAvailable ))));

		List<WebElement> rowCount = driver.findElements(By.xpath(courseAvailable));

		for(int i = 1; i <= rowCount.size(); i++)
		{
			System.out.println("tess");
			String courseName = driver.findElement(By.xpath("(" + courseAvailable + "/td[1]//span)[" + i + "]")).getText().trim();
			if(name.toLowerCase().trim().equals(courseName.toLowerCase().trim().replace(" new!", "")))
			{
				String action;
				try
				  {
					action = driver.findElement(By.xpath("(" + courseAvailable + "/td[5]//a)[" + i + "]")).getText();
				}
				catch(Exception e)
				{
					try {
						action = driver.findElement(By.xpath("(" + courseAvailable + "/td[4]//a)[" + i + "]")).getText();
					}
					catch(Exception m)
					{
						action = driver.findElement(By.xpath("(" + courseAvailable + "/td[3]//a)[" + i + "]")).getText();

					}
				}
				if(action.toLowerCase().contains("resume"))
				{
					try
					{
						driver.findElement(By.xpath("(" + courseAvailable + "/td[5]//a)[" + i + "]")).click();
					}
					catch(Exception e)
					{
						driver.findElement(By.xpath("(" + courseAvailable + "/td[4]//a)[" + i + "]")).click();

					}
					flag = true;
					break;
				}
				else if(action.toLowerCase().contains("activate"))
				{
					driver.findElement(By.xpath("(" + courseAvailable + "/td[5]//a)[" + i + "]")).click();
					try
					{

						//					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[20]/div/div/div[3]/button[2]"))));
						System.out.println("test");
						Thread.sleep(15000);
						driver.findElement(By.xpath("//div/div/div/div[3]/button[2]")).click();

					}
					catch (Exception e) {
						// TODO: handle exception

						System.out.println(driver.getWindowHandles().size());
					}
					try 
					{
					
						wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
						endUserLaunch.click();
						flag = true;
						break;
					}
					catch(Exception e)
					{
						wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
						
						try
						{
							driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).click();
						}
						catch(Exception m)
						{
							driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).click();

						}
						flag = true;
						break;
					}	
				}
				else if(action.toLowerCase().contains("launch"))
				{
					wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
					endUserLaunch.click();
					flag = true;
					break;
				}
			}
		}
		Assert.assertTrue("Course not found ",flag);
		return flag;
	}

	public boolean launchCourseWithNameResume(String name)
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);	
		boolean flag = false;
		checkCourseAvailable();
		if(courseListName.containsKey(name))
			name=courseListName.get(name).toString();

	


		try {
			courseAvailable = "//table[@class and @aria-describedby='my_courseList']//tbody/tr";
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" + courseAvailable + ")[1]"))));
		}
		catch(NoSuchElementException e)
		{
			courseAvailable = "//*[@id=\"accordion2\"]/table/tbody/tr";
		}

		List<WebElement> rowCount = driver.findElements(By.xpath(courseAvailable));
		//		 driver.findElement(By.xpath(courseAvailable));

		for(int i = 1; i <= rowCount.size(); i++)
		{
			String courseName = driver.findElement(By.xpath("(" + courseAvailable + "/td[1]//span)[" + i + "]")).getText().trim();
			if(name.toLowerCase().trim().equals(courseName.toLowerCase().trim()))
			{
				String action;
				try
				{
					action = driver.findElement(By.xpath("(" + courseAvailable + "/td[5]//a)[" + i + "]")).getText();
				}
				catch(Exception e)
				{
					try
					{
						action = driver.findElement(By.xpath("(" + courseAvailable + "/td[4]//a)[" + i + "]")).getText();
					}
					catch(Exception w )
					{
						action = driver.findElement(By.xpath("(" + courseAvailable + "/td[3]//a)[" + i + "]")).getText();

					}
				}
				if(action.toLowerCase().contains("resume"))
				{
					try
					{
						driver.findElement(By.xpath("(" + courseAvailable + "/td[5]//a)[" + i + "]")).click();
					}
					catch(Exception e)
					{
						try
						{
							driver.findElement(By.xpath("(" + courseAvailable + "/td[4]//a)[" + i + "]")).click();
						}	
						catch(Exception m)
						{
							driver.findElement(By.xpath("(" + courseAvailable + "/td[3]//a)[" + i + "]")).click();

						}

					}
					flag = true;
					break;
				}
				else if(action.toLowerCase().contains("activate"))
				{
					driver.findElement(By.xpath("(" + courseAvailable + "/td[5]//a)[" + i + "]")).click();
					try 
					{
						
						wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
						endUserLaunch.click();
						flag = true;
						break;
					}
					catch(Exception e)
					{
						wait.until(ExpectedConditions.visibilityOf(endUserLaunch));
						endUserLaunch.click();
						flag = true;
						break;
					}	
				}
				else if(action.toLowerCase().contains("launch"))
				{
					
					try
					{
						driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).click();
					}
					catch(Exception e)
					{
						driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).click();

					}
					flag = true;
					break;
				}
			}
		}
		Assert.assertTrue("Course not found",flag);
		return flag;
	}


	public void clickOnSubmitOnly()
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.visibilityOf(endUserSubmitDate));
			endUserSubmitDate.click();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	public boolean validateCourseAvailable()
	{
		boolean flag = false;
		for(int  i = 1; i <2; i++)
		{
			flag = checkCoursesAvailable();
			if(flag == false)
			{
				driver.navigate().refresh();
			}
			else
				break;
		}
		return flag;
	}
	public int getNumberRows()
	{
		
		List<WebElement> count;
		try
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseTable))));
			count = driver.findElements(By.xpath(courseTable + "//tbody/tr"));
		}
		catch(Exception e)
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"courseWithoutTodoList\"]"))));
			count = driver.findElements(By.xpath("//*[@id=\"courseWithoutTodoList\"]" + "//tbody/tr"));

		}
		return count.size();
	}

	public int getNumberRow()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);

		List<WebElement> count;
		try
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(curseTable))));
			count = driver.findElements(By.xpath(curseTable + "//tbody/tr"));
		}
		catch(Exception e)
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"courseWithoutTodoList\"]"))));
			count = driver.findElements(By.xpath("//*[@id=\"courseWithoutTodoList\"]" + "//tbody/tr"));

		}
		return count.size();
	}
	public void evaluateCourse()
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(endUserEvaluation));
			endUserEvaluation.click();
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(mandatoryQuestion)));
			List<WebElement> mandate = driver.findElements(mandatoryQuestion);
			for(int i= 1; i<= mandate.size(); i++)
			{
				driver.findElement(By.xpath(firstRadioMandatryQuestion + i + "]//input[@type = 'radio'])[1]")).click();;
			}
			endUserSubmitEvaluation.click();
		}
		catch(Exception e)
		{
			//			driver.findElement(By.xpath("//button[@id=\"complete_course_topics_close\"]")).click();
			System.out.println(e.getMessage());
		}

	}
	
	public void evaluateCourse(String course)
	{
		if(courseListName.containsKey(course+"evaluateCourse"))
		{
		
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(endUserEvaluation));
			endUserEvaluation.click();
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(mandatoryQuestion)));
			List<WebElement> mandate = driver.findElements(mandatoryQuestion);
			for(int i= 1; i<= mandate.size(); i++)
			{
				driver.findElement(By.xpath(firstRadioMandatryQuestion + i + "]//input[@type = 'radio'])[1]")).click();;
			}
			endUserSubmitEvaluation.click();
		}
		catch(Exception e)
		{
			//			driver.findElement(By.xpath("//button[@id=\"complete_course_topics_close\"]")).click();
		Assert.fail("Evaluate Course is not enabled"+course);
		
		}
		}

	}

	public void validateMenuOption()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(laerdalLogo));
		List<WebElement> menuOption = driver.findElements(By.xpath(menuOptionList));
		boolean flag = false;
		Assert.assertTrue(menuOption.size() == 4);
		for(WebElement element:menuOption)
		{
			flag = false;
			menuDropdown.click();
			String text = element.getText();
			if(text.toLowerCase().trim().equalsIgnoreCase("my programs")||text.toLowerCase().trim().equalsIgnoreCase("my account")||
					text.toLowerCase().trim().equalsIgnoreCase("Log Out")||	text.toLowerCase().trim().equalsIgnoreCase("reference library"))
				flag = true;
			
		}
		Assert.assertFalse("Menu Options are not matching", flag == false);
	}
	public void courseNotAvaialble() {
		
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='tab1']/div/div[2]/span"))));
		Assert.assertEquals(driver.findElement(By.xpath("//*[@id='tab1']/div/div[2]/span")).getText(), "No programs available.");
		Assert.assertFalse(driver.findElement(By.xpath("//*[@id='tab1']/div/div[2]/span")).getAttribute("id").equalsIgnoreCase("shared_courses"));
	}

	public void validateResponseForLink()
	{
		String url = "";
		HttpURLConnection huc = null;
		int respCode = 200;
		List<WebElement> links = driver.findElements(By.xpath(pagelinks));
		Iterator<WebElement> it = links.iterator();
		while(it.hasNext())
		{
			url = it.next().getAttribute("href");
			if(url == null || url.isEmpty()){
				System.out.println("URL is either not configured for anchor tag or it is empty");
				continue;
			}
			try 
			{
				huc = (HttpURLConnection)(new URL(url).openConnection());
				huc.setRequestMethod("HEAD");
				huc.connect();
				respCode = huc.getResponseCode();
				if(respCode >= 400)
					System.out.println(url+" is a broken link");
				else
					System.out.println(url+" is a valid link");
			} 
			catch (Exception e)
			{
//				Assert.fail(url + e.getMessage());
			}
			}
	}
	public void validateSideMenuOption()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(laerdalLogo));
		List<WebElement> sideMenuOption = driver.findElements(By.xpath(sideMenu));
		boolean flag = false;
		Assert.assertTrue(sideMenuOption.size() == 4);
		for(WebElement element:sideMenuOption)
		{
			flag = false;
			String text = element.getText();
			System.out.println(text);
			if(text.toLowerCase().trim().equalsIgnoreCase("my programs")||text.toLowerCase().trim().equalsIgnoreCase("my account")||
					text.toLowerCase().trim().equalsIgnoreCase("Log Out")||	text.toLowerCase().trim().equalsIgnoreCase("reference library"))
		
				flag = true;
			
		}
		Assert.assertFalse("Menu Options are not matching", flag == false);
	}
	public void validateWelcome()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(welcome));
		Point location = welcome.getLocation();
		System.out.println(location);
	}
	
	public void validateSupportOption()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(laerdalLogo));
		List<WebElement> supportOption = driver.findElements(By.xpath(supportOptionList));
		boolean flag = false;
		Assert.assertTrue(supportOption.size() == 2);
		for(WebElement element:supportOption)
		{
			flag = false;
			supportDropdown.click();
			String text = element.getText();
			System.out.println(text);
			if(text.toLowerCase().trim().equalsIgnoreCase("FAQ")||text.toLowerCase().trim().equalsIgnoreCase("Contact Customer Support"))
				flag = true;
			
		}
		Assert.assertFalse("Menu Options are not matching", flag == false);
	}
	
	public void validateHeaderFooter()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(laerdalLogo));
		boolean header = laerdalLogo.isDisplayed();
		Assert.assertFalse("AHA Logo is not avaialble", header == false);
		LocalDate date = LocalDate.now();
		int currentYear = date.getYear();
		wait.until(ExpectedConditions.visibilityOf(laerdalFooter));
		String footerTextUI = laerdalFooter.getText();
		
		String footerTextExpected = "Copyright © "+currentYear+" RQI Partners, LLC. All rights reserved. Unauthorized use prohibited";
		System.out.println(footerTextExpected);
		System.out.println(footerTextUI);
//		Assert.assertFalse("Footer text not matched",!footerTextUI.equalsIgnoreCase(footerTextExpected));		
	}
	public void clickOnSubmitOnlyWithDate(String date)
	{
		String url=driver.getCurrentUrl();
		
		try
		{
			if(courseListName.containsKey(date))
				date=courseListName.get(date).toString();
			
			  LocalDate currentQDate = LocalDate.now();
		      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	         
		
		      Calendar cal = Calendar.getInstance();
		      int month = cal.get(Calendar.MONTH);
		      int quarter = (month / 3) + 1;
		      month=((quarter-1)*3)-1;
		      
		      Calendar cal1 = Calendar.getInstance();
		      SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		      cal1.set(Calendar.MONTH,month);
		      Date date1 = cal1.getTime();             
		      String previousQdate = format1.format(date1);   
			 
		      if(date.contains("previousQdate"))
		    	  date=  previousQdate;
		      
		      if(date.contains("currentQDate"))
		    	  date=  formatter.format(currentQDate);
		      
			WebDriverWait wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.visibilityOf(endUserSubmitDate));
			if(date.length() > 1)
			{
				endUserCourseDate.click();
				endUserCourseDate.clear();
				endUserCourseDate.sendKeys(date);
				endUserCourseDate.click();
			}
			endUserSubmitDate.click();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
//			runScriptForPastDate(date);
//			driver.navigate().to(url+"?test_today_date="+date);
			
		}
	}

	public int getAvailableTopicNumber()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseTable))));
		List<WebElement> count = driver.findElements(By.xpath(courseTable + "//tbody/tr/td[4]/a"));
		return count.size();
	}
	public int getAvailableTopiNumber()
	{
		try
		{
		Thread.sleep(6000);
		
		}
		catch(Exception e)
		{
			
		}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(curseTable))));
		List<WebElement> count = driver.findElements(By.xpath(curseTable + "//tbody/tr/td[4]/a"));
		return count.size();
	}

	public int getlockTopiNumber()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(curseTable))));
		List<WebElement> count = driver.findElements(By.xpath(curseTable + "//tbody/tr/td[4]/a"));
		return count.size();
	}

	public void clickOnCompletedActivities()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(completedActivitiesButton));
		completedActivitiesButton.click();
	}

	public void selectFilterstatus(String status)
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(filterStatus));
		
		Select drpOrgType = new Select(filterStatus);
		drpOrgType.selectByVisibleText(status);
		
	}
	
	public void selectFilterstatusInCompleteTab(String status)
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(filterexpStatus));
		
		Select drpOrgType = new Select(filterexpStatus);
		drpOrgType.selectByVisibleText(status);
		
	}
	public void navigateCompletedPrograms()
	{
			wait.until(ExpectedConditions.visibilityOf(completedProgramsButton));
			wait.until(ExpectedConditions.elementToBeClickable(completedProgramsButton));
			
			completedProgramsButton.click();
	}

	public void clickReviewGivenCourse(String courseName)
	{

		if(courseListName.containsKey(courseName))
			courseName=courseListName.get(courseName).toString();


		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(completeTable))));
		List<WebElement> count = driver.findElements(By.xpath(completeTable));
		for(int i=1; i<=count.size(); i++)
		{
			String prog = driver.findElement(By.xpath(completeTableRow + i + "]//span")).getText();
			if(courseName.toLowerCase().contains(prog.toLowerCase()))
			{
				driver.findElement(By.xpath(completeTableRow + "6]//a")).click();
			}
		}
	}

	public void clickOnCompletedCourseReview()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(completedCourseReview));
		completedCourseReview.click();
	}


	public void clickOnCompletedCourseReviews()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(completedCourseReviews));
		completedCourseReviews.click();
	}

	
	public void clickOncompletedActivitiesButton()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(completedActivitiesButton));
		completedActivitiesButton.click();
	}

	
	public void validateIfReviewtheCourse(String date)
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(reviewScore.get(0)));
		Assert.assertEquals(reviewScore.size(), review_btn.size());
		Assert.assertEquals(getNumberRows(),0);
		Boolean flag=false;
		int count=review_btn.size();
		int loopcount=0;
		for(int i=0;i<review_btn.size();i++)
		{
			review_btn.get(i).click();
			onlyExitCourse();
			flag=true;
			clickOnSubmitOnlyWithDate(date);
			clickOncompletedActivitiesButton();
			
			loopcount++;
		}
		Assert.assertEquals(count, loopcount);
		
		Assert.assertTrue("Course not in review status",flag);
		
	}

	
	public void clickOnCompletedCourseReviews(String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
			
		try
		{
		Thread.sleep(5000);
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//span[text()='"+course+"']//following::div//a[@aria-label='Review'])[1]"))));
		driver.findElement(By.xpath("(//span[text()='"+course+"']//following::div//a[@aria-label='Review'])[1]")).click();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}

	}
	
	public void validateCourseiscompleted(String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
			
		reuse.waitforsec(4);
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//span[text()='"+course+"']//following::div//a[@aria-label='Review'])[1]"))));
//		driver.findElement(By.xpath("(//span[text()='"+course+"']//following::div//a[@aria-label='Review'])[1]")).click();
	
	}
	
	public void validateIfCourseIsAvalble(String course) throws InterruptedException
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
		
		Thread.sleep(5000);
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//span[text()='"+course+"']//following::div//a[@aria-label='Review'])[1]"))));
		

	}
	
	public void view_ecard_is_not_present(String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
			
		try
		{
		Thread.sleep(5000);
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//span[text()='"+course+"']//following::div//a[@aria-label='View eCard '])[1]"))));
		Assert.fail("View Ecard should  not be present");
	
		
		}
		catch(Exception e)
		{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 15);
			
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//span[text()='"+course+"']//following::div//a[@title='View eCard'])[2]"))));
			Assert.fail("View Ecard should  not be present");
		}
		catch(Exception y)
		{
			
		}
			
		}

	}
	

	public void clickOnCompletedCourseViewEcard(String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
			
		try
		{
		Thread.sleep(5000);
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//span[text()='"+course+"']//following::div//a[@aria-label='View eCard'])[1]"))));
		driver.findElement(By.xpath("(//span[text()='"+course+"']//following::div//a[@aria-label='View eCard'])[1]")).click();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}

	}
	
	public void clickOnCompletedCourseViewEcardLink(String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
			
		try
		{
		Thread.sleep(5000);
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//span[text()='"+course+"']//following::div//a[@title='View eCard'])[2]"))));
		driver.findElement(By.xpath("(//span[text()='"+course+"']//following::div//a[@title='View eCard'])[2]")).click();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}

	}
	
	public void clickOnCompletedCourseViewEcardLinkinLogin(String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
			
		try
		{
		Thread.sleep(5000);
		WebDriverWait wait = new WebDriverWait(driver, 15);
		
	    wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//span[text()='"+course+"']//following::div//a[@data-toggle='dropdown'])[2]"))));
	    driver.findElement(By.xpath("(//span[text()='"+course+"']//following::div//a[@data-toggle='dropdown'])[2]")).click();
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//span[text()='"+course+"']//following::div//a[@title='View eCard'])[2]"))));
		driver.findElement(By.xpath("(//span[text()='"+course+"']//following::div//a[@title='View eCard'])[2]")).click();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}

	}
	public void clickOnCompletedCourseEcard()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(completedCourseEcard));
		completedCourseEcard.click();
		try
		{
			Thread.sleep(10000);

			String currentHandle= driver.getWindowHandle();
			Set<String> handles=driver.getWindowHandles();

			driver.switchTo().window(handles.toArray()[handles.size()-1].toString());

			Assert.assertTrue(driver.getCurrentUrl().contains("/certificate/ecard/"));

			
			driver.close();

			driver.switchTo().window(handles.toArray()[handles.size()-2].toString());



		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}

	}
	
	public void clickOnCompletedCourseCertificate(String course)
	{
		
		
		if(courseListName.containsKey(course+"Certificate"))
			course=courseListName.get(course+"Certificate").toString();
			
	
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(completedCourseCertificate));
		completedCourseCertificate.click();
		try
		{
			Thread.sleep(10000);

			String currentHandle= driver.getWindowHandle();
			Set<String> handles=driver.getWindowHandles();

		Boolean flag=	Products.isFileDownloaded_Ext (Products.downloadPath , ".pdf");
			
			if(flag==false)
			{
			driver.switchTo().window(handles.toArray()[handles.size()-1].toString());

			Assert.assertTrue(driver.getCurrentUrl().contains("/certificate/completion"));
			try
			{
				
				Thread.sleep(5000);
				driver.switchTo().frame("examReaderFrame");
				wait.until(ExpectedConditions.visibilityOf(Continue));
				Continue.click();
				Thread.sleep(5000);
				
				wait.until(ExpectedConditions.visibilityOf(Continue));
				Continue.click();
//				driver.switchTo().alert().accept();
				
			}
			catch(Exception e)
			{
			
				
			}
			
			driver.findElement(By.xpath("//table/tr//td[contains(text(),'"+course+"')]/following::td/img")).click();

			Assert.assertTrue(driver.getWindowHandles().size()==4);
            handles=driver.getWindowHandles();
			
			driver.switchTo().window(handles.toArray()[3].toString());
			driver.close();

			driver.switchTo().window(handles.toArray()[2].toString());
			driver.close();

			driver.switchTo().window(handles.toArray()[1].toString());
			}


		}
		catch(Exception e)
		{
			Assert.fail("error");
		}

	}
	
	public void clickOnCompletedCourseEcard(String course)
	{
		if(courseListName.containsKey(course+"Ecard"))
			course=courseListName.get(course+"Ecard").toString();
			
	
		
		
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(completedCourseEcard));
		completedCourseEcard.click();
		try
		{
			Thread.sleep(5000);

			String currentHandle= driver.getWindowHandle();
			Set<String> handles=driver.getWindowHandles();

			driver.switchTo().window(handles.toArray()[handles.size()-1].toString());

			Assert.assertTrue(driver.getCurrentUrl().contains("/certificate/ecard/"));

			System.out.println(driver.getCurrentUrl());
			
			try
			{
				Thread.sleep(5000);
				driver.switchTo().frame("examReaderFrame");
			}
			catch(Exception e)
			{
				
			}

			this.wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//table/tr//td[contains(text(),'"+course+"')]/following::td/img"))));
			
			driver.findElement(By.xpath("//table/tr//td[contains(text(),'"+course+"')]/following::td/img")).click();
			
            handles=driver.getWindowHandles();

			Assert.assertTrue(driver.getWindowHandles().size()==4);
            handles=driver.getWindowHandles();
			
			driver.switchTo().window(handles.toArray()[3].toString());
			driver.close();

			driver.switchTo().window(handles.toArray()[2].toString());
			driver.close();

			driver.switchTo().window(handles.toArray()[1].toString());



		}
		catch(Exception e)
		{
				Assert.fail( e.getMessage());
		}

	}
	
	public void clickOnViewEcard(String course,int tab)
	{
		if(courseListName.containsKey(course+"Ecard"))
			course=courseListName.get(course+"Ecard").toString();
			
	
		
		
		WebDriverWait wait = new WebDriverWait(driver, 15);
	
		try
		{
			Thread.sleep(5000);

			String currentHandle= driver.getWindowHandle();
			Set<String> handles=driver.getWindowHandles();

			driver.switchTo().window(handles.toArray()[handles.size()-1].toString());

			Assert.assertTrue(driver.getCurrentUrl().contains("/certificate/ecard/"));

			System.out.println(driver.getCurrentUrl());
			
			try
			{
				Thread.sleep(5000);
				driver.switchTo().frame("examReaderFrame");
			}
			catch(Exception e)
			{
				
			}

			this.wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//table/tr//td[contains(text(),'"+course+"')]/following::td/img"))));
			
			driver.findElement(By.xpath("//table/tr//td[contains(text(),'"+course+"')]/following::td/img")).click();
			
            handles=driver.getWindowHandles();

			Assert.assertTrue(driver.getWindowHandles().size()==tab);
            handles=driver.getWindowHandles();
			
			driver.switchTo().window(handles.toArray()[2].toString());
			driver.close();

			driver.switchTo().window(handles.toArray()[1].toString());
			driver.close();

			driver.switchTo().window(handles.toArray()[0].toString());



		}
		catch(Exception e)
		{
				Assert.fail( e.getMessage());
		}

	}
	
	public void clickOnViewEcard(String course)
	{
		if(courseListName.containsKey(course+"Ecard"))
			course=courseListName.get(course+"Ecard").toString();
			
	
		
	
		try
		{
			Thread.sleep(5000);

			String currentHandle= driver.getWindowHandle();
			Set<String> handles=driver.getWindowHandles();

			driver.switchTo().window(handles.toArray()[handles.size()-1].toString());

			Assert.assertTrue(driver.getCurrentUrl().contains("/certificate/ecard/"));

			System.out.println(driver.getCurrentUrl());
			
			try
			{
				Thread.sleep(5000);
				driver.switchTo().frame("examReaderFrame");
			}
			catch(Exception e)
			{
				
			}

			this.wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//table/tr//td[contains(text(),'"+course+"')]/following::td/img"))));
			
			driver.findElement(By.xpath("//table/tr//td[contains(text(),'"+course+"')]/following::td/img")).click();
			
            handles=driver.getWindowHandles();

			Assert.assertTrue(driver.getWindowHandles().size()==4);
            handles=driver.getWindowHandles();
			
			driver.switchTo().window(handles.toArray()[3].toString());
			driver.close();

			driver.switchTo().window(handles.toArray()[2].toString());
			driver.close();

			driver.switchTo().window(handles.toArray()[1].toString());



		}
		catch(Exception e)
		{
				Assert.fail( e.getMessage());
		}

	}
	
	
	public void validateCourseLaunchError()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseTable + "//td"))));
		String getMessage = driver.findElement(By.xpath(courseTable + "//td")).getText().trim();
		System.out.println(getMessage);
		Assert.assertTrue(getMessage.toLowerCase().contains("this course can only launch if other courses have been completed"));
	}
	
	public void clickViewOrderCloseBtn()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(orderViewPopupCloseBtn));
		orderViewPopupCloseBtn.click();
	}
	
	
	
	public void validate_OrderDetail(String header,String value)
	{
		if(AssignmentReport. checkifParmeterAvailable(value))
			value=AssignmentReport.getParmeterAvailable(value);

		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//label[text()='"+header+"']//following::div[1]"))));
//		orderViewPopupBtn.click();
		System.out.println(driver.findElement(By.xpath("//label[text()='"+header+"']//following::div[1]")).getText());
		if(header.contains("Transaction Ref Number"))
		{
			TransactionRefNumber=driver.findElement(By.xpath("//label[text()='"+header+"']//following::div[1]")).getText();
//			Assert.assertEquals(driver.findElement(By.xpath("//label[text()='"+header+"']//following::div[1]")).getText(), value);
		}
		else if(header.contains("Order ID"))
		{
			OrderID=driver.findElement(By.xpath("//label[text()='"+header+"']//following::div[1]")).getText();
//			Assert.assertEquals(driver.findElement(By.xpath("//label[text()='"+header+"']//following::div[1]")).getText(), value);
		}
		else if(header.contains("Order Date and Time"))
		{
			OrderDate=driver.findElement(By.xpath("//label[text()='"+header+"']//following::div[1]")).getText();
//			Assert.assertEquals(driver.findElement(By.xpath("//label[text()='"+header+"']//following::div[1]")).getText(), value);
		}
		else
		Assert.assertEquals(driver.findElement(By.xpath("//label[text()='"+header+"']//following::div[1]")).getText(), value);
	}
	
	public void validate_OrderDetail(String header,String value,String course)
	{
		if(AssignmentReport. checkifParmeterAvailable(value))
			value=AssignmentReport.getParmeterAvailable(value);

		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//label[text()='"+header+"']//following::div[1]"))));
//		orderViewPopupBtn.click();
		System.out.println(driver.findElement(By.xpath("//label[text()='"+header+"']//following::div[1]")).getText());
		if(header.contains("Transaction Ref Number"))
		{
			TransactionRefNumber=driver.findElement(By.xpath("//label[text()='"+header+"']//following::div[1]")).getText();
//			Assert.assertEquals(driver.findElement(By.xpath("//label[text()='"+header+"']//following::div[1]")).getText(), value);
			dataMap.put(course+"TransactionRefNumber", TransactionRefNumber);
		}
		else if(header.contains("Order ID"))
		{
			OrderID=driver.findElement(By.xpath("//label[text()='"+header+"']//following::div[1]")).getText();
			dataMap.put(course+"OrderID", OrderID);
//			Assert.assertEquals(driver.findElement(By.xpath("//label[text()='"+header+"']//following::div[1]")).getText(), value);
		}
		else if(header.contains("Order Date and Time"))
		{
			OrderDate=driver.findElement(By.xpath("//label[text()='"+header+"']//following::div[1]")).getText();
			dataMap.put(course+"OrderDate", OrderDate);
//			Assert.assertEquals(driver.findElement(By.xpath("//label[text()='"+header+"']//following::div[1]")).getText(), value);
		}
		else
		Assert.assertEquals(driver.findElement(By.xpath("//label[text()='"+header+"']//following::div[1]")).getText(), value);
	}
	
	public void clickViewOrderBtn()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(orderViewPopupBtn));
		orderViewPopupBtn.click();
	}
	
	public void clickdownloadReceiptBtn()
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(downloadReceipt));
		downloadReceipt.click();
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception w)
		{
			
		}
	}
	
	
	public boolean startCourseWithName(String courseName)
	{
		if(courseListName.containsKey(courseName))
			courseName=courseListName.get(courseName).toString();

		WebDriverWait wait = new WebDriverWait(driver, 30);	
		boolean flag = false;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" + courseAvailable + ")[1]"))));
		List<WebElement> rowCount = driver.findElements(By.xpath(courseAvailable));
		for(int i = 1; i <= rowCount.size(); i++)
		{
			String courseNameAvailable = driver.findElement(By.xpath("(" + courseAvailable + ")[" + i + "]/td[1]")).getText();
			courseNameAvailable = courseNameAvailable.replace("New!", "");
			if(courseName.toLowerCase().trim().contains(courseNameAvailable.trim().toLowerCase()))
			{
				if(driver.findElements(By.xpath("(" + courseAvailable + ")[" + i + "]/td[5]")).size() > 0)
				{
					driver.findElement(By.xpath("(" + courseAvailable + ")[" + i + "]/td[5]")).click();
					try
					{
						wait.until(ExpectedConditions.visibilityOf(endUserAgreeLink)).isDisplayed();
						Thread.sleep(9000);
					}
					catch(Exception e)
					{
					
					}
					flag = true;
					break;
				}
				else if(driver.findElements(By.xpath("(" + courseAvailable + ")[" + i + "]/td[4]")).size() > 0)
				{
					driver.findElement(By.xpath("(" + courseAvailable + ")[" + i + "]/td[4]")).click();
					flag = true;
					break;
				}
				else if(driver.findElements(By.xpath("(" + courseAvailable + ")[" + i + "]/td[3]")).size() > 0)
				{
					driver.findElement(By.xpath("(" + courseAvailable + ")[" + i + "]/td[3]//a")).click();
					flag = true;
					break;
				}
			}
			
		}
		return flag;
	}
	public void runScriptForPastDate(String date)
	{
		try 
		{
			if(courseListName.containsKey(date))
				date=courseListName.get(date).toString();

			
		 	LocalDate currentQDate = LocalDate.now();
		      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	         
		
		      Calendar cal = Calendar.getInstance();
		      int month = cal.get(Calendar.MONTH);
		      int quarter = (month / 3) + 1;
		      month=((quarter-1)*3)-1;
		      
		      Calendar cal1 = Calendar.getInstance();
		      SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		      cal1.set(Calendar.MONTH,month);
		      Date date1 = cal1.getTime();             
		      String previousQdate = format1.format(date1);   
			 
		      if(date.contains("previousQdate"))
		    	  date=  previousQdate;
		      
		      if(date.contains("currentQDate"))
		    	  date=  formatter.format(currentQDate);
		      
			 
			LocalDate currentDate = LocalDate.now();
			LocalDate courseDate = LocalDate.parse(date);
			Period diff = Period.between(courseDate, currentDate);
			int days = diff.getDays();
			int months = diff.getMonths();
			int year = diff.getYears();
			
			Thread.sleep(5000);
			if(days >= 1 || months >= 1 || year >=1)
				System.out.println("Date is in past");
			
				JavascriptExecutor js = (JavascriptExecutor)driver;
				js.executeScript("var testActivatedate; function setValue() {testActivateDate = '"+date+"' ; }; setValue(); testActivateDate;");
			
			
			
		} 
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}
	}


	public void subscribeBtn()
	{
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.visibilityOf(subscribeBtn));
	subscribeBtn.click();
	}
	
	public void payNowRequiredLabel(String course)
	{
		if(courseListName.containsKey( course+"Option"))
			course=courseListName.get( course+"Option").toString();

	WebDriverWait wait = new WebDriverWait(driver, 60);
		
	  wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//*[@id='current-programs']//span[text()='"+course+"']//following::span[text()='Payment Required'])[1]"))));
		driver.findElement(By.xpath("(//*[@id='current-programs']//span[text()='"+course+"']//following::span[text()='Payment Required'])[1]")).click();
		
	 
	
	}
	
	
	
	public void subscribeBtn(String course)
	{
		if(courseListName.containsKey( course+"Option"))
			course=courseListName.get( course+"Option").toString();

	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='current-programs']//span[text()='"+course+"']//following::div[3]//a[text()='Subscribe']"))));
	driver.findElement(By.xpath("//*[@id='current-programs']//span[text()='"+course+"']//following::div[3]//a[text()='Subscribe']")).click();
	}
	
	

	public void SubscribedOnCompletedTab(String course)
	{
		
		if(courseListName.containsKey( course+"Option"))
			course=courseListName.get( course+"Option").toString();

	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//*[@id='current-programs']//span[text()='"+course+"']//following::div/span[text()='Subscribed,'])[1]"))));
	
	
	
	}
	public void validate_subscriptionExpiration(int plan)
	{
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.visibilityOf(subscriptionExpiration));
	
	SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM, yyyy");  
    
	
	  
//	  System.out.println(date.);
	  Calendar cal = Calendar.getInstance();  
        try{  
//           cal.setTime(sdf.parse(date1));
        	cal.add(Calendar.MONTH, plan);
//    		String formattedStartDate = dateFormat.format(cal.getTime());
        }catch(Exception e){  
            e.printStackTrace();  
         }  
             
        
        // use add() method to add the days to the given date  
        String dateAfter = sdf.format(cal.getTime());  
        System.out.println(dateAfter);
    	
        Assert.assertEquals(dateAfter, subscriptionExpiration.getText());
    
	}
	
	
	public void validate_subscriptionvalid_until_date(String course,int plan)
	{
		if(courseListName.containsKey( course+"Option"))
			course=courseListName.get( course+"Option").toString();

	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.visibilityOf(subscriptionDetails));
	
	String details="Your course "+course+" has been activated and ready to launch";
	
	Assert.assertEquals(details, subscriptionDetails.getText());
	SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM, yyyy");  
      
	  Calendar cal = Calendar.getInstance();  
        try{  
        	cal.add(Calendar.MONTH, plan);
        }catch(Exception e){  
            e.printStackTrace();  
         }  
             
        
        String dateAfter = sdf.format(cal.getTime());  
        System.out.println(dateAfter);
    	
        Assert.assertEquals("Subscription valid till "+dateAfter, validity_infonDetails.getText());
    
	}
	
	public void validate_order_summary(String header,String value)
	{
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.visibilityOf(orderSummary));
	if(AssignmentReport. checkifParmeterAvailable(value))
		value=AssignmentReport.getParmeterAvailable(value);
	
	Assert.assertEquals(driver.findElement(By.xpath("(//span[contains(text(),'"+header+"')]//following::span[1])[2]")).getText(), value);
    
	if(header.contains("Total Price"))
	Tpaid=value;
	}
	
	
	public void validate_Billing_Address()
	{
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.visibilityOf(Billingaddress));
	wait.until(ExpectedConditions.visibilityOf(Organizationaddress));
	wait.until(ExpectedConditions.visibilityOf(BillingaddressHeader));
	
	System.out.println(Billingaddress.getText().split("\n"));
	System.out.println(OrganizationDetails.StateZipcodetext);
	assertEquals(Billingaddress.getText().split("\n")[0].contains(OrganizationDetails.organizationNametext), true);
	assertEquals(Billingaddress.getText().split("\n")[1].contains(OrganizationDetails.companyAddress1text), true);
	assertEquals(Billingaddress.getText().split("\n")[2].contains(OrganizationDetails.StateZipcodetext), true);
	
	}
	

	public void validate_Subscription_Plan(String value)
	{
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.visibilityOf(SubscriptionPlan));
	
	System.out.println(SubscriptionPlan.getText());
	Assert.assertEquals(SubscriptionPlan.getText(), value);

	}
	
	
	public void click_closeBtn()
	{
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.visibilityOf(closeBtn));
	closeBtn.click();
	}
	
	
	public void click_launch_NowBtn()
	{
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.visibilityOf(launch_NowBtn));
	launch_NowBtn.click();
	}
	
	
	
	public void click_cancel_order()
	{
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.visibilityOf(cancel_order));
	cancel_order.click();
	
	}
	
	
	public void SubscribedOnCompletedTab()
	{
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.visibilityOf(SubscribedOnCompletedTab));
	}
	
	
	public void click_returnToMerchant()
	{
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.visibilityOf(returnToMerchant));
	returnToMerchant.click();
	}
	
	
		public void click_PayNowBtn()
		{
		WebDriverWait wait = new WebDriverWait(driver, 60);
		  wait.until(ExpectedConditions.visibilityOf(payNow));
			
		   payNow.click();
		
		}

		public void payNowRequiredLabel()
		{
		WebDriverWait wait = new WebDriverWait(driver, 60);
		  wait.until(ExpectedConditions.visibilityOf(payNowRequiredLabel));
			
		  payNowRequiredLabel.click();
		
		}
		
		
	public void click_order_ReceiptBtn()
	{
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.visibilityOf(order_ReceiptBtn));
	order_ReceiptBtn.click();
	try
	{
		Thread.sleep(10000);
	}
	catch(Exception w)
	{
		
	}
	}
//	clickonTermAndCondition
	
	public void clickonTermAndConditionnAndValidateTermandCondition()
	{
		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		
		wait.until(ExpectedConditions.visibilityOf(clickonTermAndCondition));
		wait.until(ExpectedConditions.visibilityOf(checkBoxClass));

		System.err.println(checkBoxClass.isSelected());
		Assert.assertFalse(Boolean.valueOf(checkBoxClass.isSelected()));
		clickonTermAndCondition.click();
		wait.until(ExpectedConditions.visibilityOf(courseTab));
		wait.until(ExpectedConditions.visibilityOf(purchaseTab));
		wait.until(ExpectedConditions.visibilityOf(cancellationAndRefundPolicy));
		courseTab.click();
	
		wait.until(ExpectedConditions.visibilityOf(coursedescTab));
		System.out.println(coursedescTab.getText());
		purchaseTab.click();
		wait.until(ExpectedConditions.visibilityOf(purchasedescTab));
		System.out.println(purchasedescTab.getText());
		cancellationAndRefundPolicy.click();
		
		wait.until(ExpectedConditions.visibilityOf(cancellationAndRefunddescTab));
		System.out.println(cancellationAndRefunddescTab.getText());
		
		wait.until(ExpectedConditions.visibilityOf(acceptTermsBtn));
		acceptTermsBtn.click();
		wait.until(ExpectedConditions.visibilityOf(checkBoxClass));
		
		System.out.println(checkBoxClass.getAttribute("class"));
		System.err.println(checkBoxClass.isSelected());
		Assert.assertTrue(Boolean.valueOf(checkBoxClass.isSelected()));
	}
	public void performPaymentAndSubscribe(String email)
	{
      wait.until(ExpectedConditions.visibilityOf(contactEmail));
      contactEmail.click();
      contactEmail.clear();
      if(email==null)
      {
      secondaryEmail=User.getUserEmail();
      email=secondaryEmail;
      }
      contactEmail.sendKeys(email);;
	  acceptCheckBox.click();
	
	  payNowBtn.click();
	  wait.until(ExpectedConditions.visibilityOf(cc_number));
	
	  reuse.waitforsec(5);
	   
	  String cardnumber=reuse.decrypt(TestBase.prop.getProperty("cardNumber"), "AutoClan");
	  SimpleDateFormat sdf = new SimpleDateFormat("yy:MM:dd");  
	  reuse.waitforsec(4);
	  cc_number.sendKeys(cardnumber);
      Calendar cal = Calendar.getInstance();  
	  cal.add(Calendar.YEAR, 3);  
	 
      String date = sdf.format(cal.getTime()); 
      String m=date.toString().split(":")[1];
	   String y=date.toString().split(":")[0];
	   expdate_month.sendKeys(m);
	   expdate_year.sendKeys(y);
	   reuse.waitforsec(4);
	   wait.until(ExpectedConditions.visibilityOf(returnToMerchant));
		
	   payNow.click();
		
	}
	
	public void performPaymentAndSubscribe()
	{
      wait.until(ExpectedConditions.visibilityOf(contactEmail));
      contactEmail.click();
      contactEmail.clear();
	  contactEmail.sendKeys(User.userEmail);;
	  acceptCheckBox.click();
	
	  payNowBtn.click();
	  wait.until(ExpectedConditions.visibilityOf(cc_number));
	
	  reuse.waitforsec(5);
	   
	  String cardnumber=reuse.decrypt(TestBase.prop.getProperty("cardNumber"), "AutoClan");
	  SimpleDateFormat sdf = new SimpleDateFormat("yy:MM:dd");  
	  reuse.waitforsec(4);
	  cc_number.sendKeys(cardnumber);
      Calendar cal = Calendar.getInstance();  
	  cal.add(Calendar.YEAR, 3);  
	 
      String date = sdf.format(cal.getTime()); 
      String m=date.toString().split(":")[1];
	   String y=date.toString().split(":")[0];
	   expdate_month.sendKeys(m);
	   expdate_year.sendKeys(y);
	   reuse.waitforsec(4);
	   wait.until(ExpectedConditions.visibilityOf(returnToMerchant));
		
	   payNow.click();
		
	}
	public void performPaymentAndSubscribeWithoutClickOnPayNow()
	{
      wait.until(ExpectedConditions.visibilityOf(contactEmail));
      contactEmail.clear();
	  contactEmail.sendKeys(User.userEmail);;
	  acceptCheckBox.click();
	
	  payNowBtn.click();
	  wait.until(ExpectedConditions.visibilityOf(cc_number));
	
	  String cardnumber=reuse.decrypt(TestBase.prop.getProperty("cardNumber"), "AutoClan");
	  SimpleDateFormat sdf = new SimpleDateFormat("yy:MM:dd");  
	  cc_number.sendKeys(cardnumber);
      Calendar cal = Calendar.getInstance();  
	  cal.add(Calendar.YEAR, 3);  
	  reuse.waitforsec(4);
      String date = sdf.format(cal.getTime()); 
      String m=date.toString().split(":")[1];
	   String y=date.toString().split(":")[0];
	   expdate_month.sendKeys(m);
	   expdate_year.sendKeys(y);
	   reuse.waitforsec(4);
	   
	   wait.until(ExpectedConditions.visibilityOf(returnToMerchant));
		
	  
//	   payNow.click();
		
	}
	
	public void click_and_EnterEmail_payNowBtn()
	{
	WebDriverWait wait = new WebDriverWait(driver, 60);
	
	wait.until(ExpectedConditions.visibilityOf(payNowBtn));
	contactEmail.clear();
	  contactEmail.sendKeys(User.userEmail);;
	
	payNowBtn.click();
	}
	
	public void validatePaymentScreen(String header,String value)
	{
      wait.until(ExpectedConditions.visibilityOf(cc_number));
	
	  System.out.println( OrganizationDetails.StateZipcodetext.split(" ")[0]);
	   if(header.contains("State"))
			Assert.assertEquals(driver.findElement(By.xpath("(//label[contains(text(),'" +header+"')]//following::span//select//option[@selected])[1]")).getText(), OrganizationDetails.StateZipcodetext.split(" ")[0]);
	   else    if(header.contains("Country"))
			Assert.assertEquals(driver.findElement(By.xpath("(//label[contains(text(),'" +header+"')]//following::span//select//option[@selected])[1]")).getText(), value);
	   else    if(header.contains("Billing address"))
			Assert.assertEquals(driver.findElement(By.xpath("(//label[contains(text(),'" +header+"')]//following::span//input)[1]")).getAttribute("value"),OrganizationDetails.companyAddress1text );
	   else   if(header.contains("City"))
				Assert.assertEquals(driver.findElement(By.xpath("(//label[contains(text(),'" +header+"')]//following::span//input)[1]")).getAttribute("value"),OrganizationDetails.CitylabelText );
	   else   if(header.contains("ZIP"))
			Assert.assertEquals(driver.findElement(By.xpath("(//label[contains(text(),'" +header+"')]//following::span//input)[1]")).getAttribute("value"),OrganizationDetails.StateZipcodetext.split(" ")[1] );
	   
	   else	  
	  		Assert.assertEquals(driver.findElement(By.xpath("(//label[contains(text(),'" +header+"')]//following::span//input)[1]")).getAttribute("value"), value);
	  
	  
	  
//	   payNow.click();
		
	}
	
	public void performEnterPaymentDetailsOnly()
	{
      wait.until(ExpectedConditions.visibilityOf(cc_number));
	
	  String cardnumber=reuse.decrypt(TestBase.prop.getProperty("cardNumber"), "AutoClan");
	  SimpleDateFormat sdf = new SimpleDateFormat("yy:MM:dd");  
	  cc_number.sendKeys(cardnumber);
      Calendar cal = Calendar.getInstance();  
	  cal.add(Calendar.YEAR, 3);  
	  reuse.waitforsec(4);
      String date = sdf.format(cal.getTime()); 
      String m=date.toString().split(":")[1];
	   String y=date.toString().split(":")[0];
	   expdate_month.sendKeys(m);
	   expdate_year.sendKeys(y);
	   reuse.waitforsec(4);
	   
	   
	   wait.until(ExpectedConditions.visibilityOf(returnToMerchant));
		
	  
//	   payNow.click();
		
	}
	
	public void validateEndOnAndComplete(int year,String day)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		  wait.until(ExpectedConditions.visibilityOf(endsOn));
			
		  SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");  
		  Calendar cal = Calendar.getInstance();  
		  cal.add(Calendar.YEAR, year);  
	      String date = sdf.format(cal.getTime()); 
	    
	      assertEquals(date, endsOn.getText());
	      Calendar cal1 = Calendar.getInstance();  
		  
	      if(day.contains("Today"))
	    	  assertEquals(sdf.format(cal1.getTime()), Completed.getText());
	      else
	       	  assertEquals(day, Completed.getText());
	 	    	  
	    	
	      
	}
	
	public void validateExpiresDateInCurrnetTab(String status)
	{
		Boolean flag=false;
		try
		{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		  wait.until(ExpectedConditions.visibilityOf(expiredOninCurrentTab));
			
		  SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");  
		  Calendar cal = Calendar.getInstance();  
		  cal.add(Calendar.YEAR, 1);  
	      String date = sdf.format(cal.getTime()); 
	      
	    	  expiredOninCurrentTab.getText();
	    	Assert.assertEquals(expiredOninCurrentTab.getText().contains("Expires on "+date),true);  
	    	flag=true;
		}
		catch(Exception e)
	      {
	    	 
	      }
		if(status.equals("Not Displayed"))
		 Assert.assertFalse("Expired Date should not present", flag);
		else
			 Assert.assertTrue("Expired Date should not present", flag);
						
	      
	}
	
	public void validateExpiresDateInCurrnetTab(String status,int plan)
	{
		Boolean flag=false;
		try
		{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		  wait.until(ExpectedConditions.visibilityOf(expiredOninCurrentTab));
			
		  SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");  
		  Calendar cal = Calendar.getInstance();  
		  cal.add(Calendar.MONTH, plan);  
	      String date = sdf.format(cal.getTime()); 
	      	System.out.println(date);
	    	  expiredOninCurrentTab.getText();
	    	Assert.assertEquals(expiredOninCurrentTab.getText().contains("Expires on "+date),true);  
	    	flag=true;
		}
		catch(Exception e)
	      {
	    	 
	      }
		if(status.equals("Not Displayed"))
		 Assert.assertFalse("Expired Date should not present", flag);
		else
			 Assert.assertTrue("Expired Date is not present", flag);
						
	      
	}
	
	public void validateExpiresDateInCurrnetTab(String status,int plan,String course)
	{
		Boolean flag=false;
		if(courseListName.containsKey( course+"Option"))
			course=courseListName.get( course+"Option").toString();

	
		try
		{
			String xpath= "(//*[@id='current-programs']//span[text()='"+course+"']//following::span[contains(text(),'Expires on')])[1]";
			
			WebDriverWait wait = new WebDriverWait(driver, 30);
		  wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(xpath))));
			
					
		  SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");  
		  Calendar cal = Calendar.getInstance();  
		  cal.add(Calendar.MONTH, plan);  
	      String date = sdf.format(cal.getTime()); 
	      	System.out.println(date);
	      	driver.findElement(By.xpath(xpath)).getText();
	    	Assert.assertEquals(driver.findElement(By.xpath(xpath)).getText().contains("Expires on "+date),true);  
	    	flag=true;
		}
		catch(Exception e)
	      {
	    	 
	      }
		if(status.equals("Not Displayed"))
		 Assert.assertFalse("Expired Date should not present", flag);
		else
			 Assert.assertTrue("Expired Date is not present", flag);
						
	      
	}
	
	public void validateExpiresDateInCompleteTab(String status)
	{
		Boolean flag=false;
		try
		{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		  wait.until(ExpectedConditions.visibilityOf(expiredOnCompletedTab));
			
		  SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");  
		  Calendar cal = Calendar.getInstance();  
		  cal.add(Calendar.YEAR, 1);  
	      String date = sdf.format(cal.getTime()); 
	      
	      expiredOnCompletedTab.getText();
	    	Assert.assertEquals(expiredOnCompletedTab.getText().contains("Expires on "+date),true);  
	    	flag=true;
		}
		catch(Exception e)
	      {
	    	 
	      }
		if(status.equals("Not Displayed"))
		 Assert.assertFalse("Expired Date should not present", flag);
		else
			 Assert.assertTrue("Expired Date should present", flag);
						
	      
	}
	

	public void performPaymentAndSubscribeForSpartans(int number)
	{
		try {
		      wait.until(ExpectedConditions.visibilityOf(contactEmail));
		      contactEmail.click();
		      contactEmail.clear();
			  contactEmail.sendKeys(User.userEmail);;
			  acceptCheckBox.click();	
			  payNowBtn.click();
			  wait.until(ExpectedConditions.visibilityOf(cc_number));
			  Thread.sleep(5000);
			  String cardnumber = "";
			  if(number == 1) {
				  cardnumber=reuse.decrypt(TestBase.prop.getProperty("cardNumber"), "AutoClan");
			  }
			  else {
				  cardnumber=reuse.decrypt(TestBase.prop.getProperty("cardNumber" + "_" + (number - 1)), "AutoClan");
			  }
			  SimpleDateFormat sdf = new SimpleDateFormat("yy:MM:dd"); 
			  Thread.sleep(3000);
			  cc_number.sendKeys(cardnumber);
		      Calendar cal = Calendar.getInstance();  
			  cal.add(Calendar.YEAR, 3);  
			  Thread.sleep(4000);
				  
		      String date = sdf.format(cal.getTime()); 
		      String m=date.toString().split(":")[1];
			  String y=date.toString().split(":")[0];
			  expdate_month.sendKeys(m);
			  expdate_year.sendKeys(y);	   
			  Thread.sleep(4000);
				 
			  payNow.click();
			}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void performPaymentAndSubscribeAsCardNumber(int number)
	{
		try {
      wait.until(ExpectedConditions.visibilityOf(contactEmail));
      contactEmail.click();
      contactEmail.clear();
	  contactEmail.sendKeys(User.userEmail);;
	  acceptCheckBox.click();	
	  payNowBtn.click();
	  wait.until(ExpectedConditions.visibilityOf(cc_number));
	  String cardnumber = "";
	  Thread.sleep(5000);
	  if(number == 0) {
		  cardnumber=reuse.decrypt(TestBase.prop.getProperty("cardNumber"), "AutoClan");
	  }
	  else {
		  cardnumber=reuse.decrypt(TestBase.prop.getProperty("cardNumber" + "_" + number), "AutoClan");
	  }
	  SimpleDateFormat sdf = new SimpleDateFormat("yy:MM:dd"); 
	  Thread.sleep(3000);
	  cc_number.sendKeys(cardnumber);
      Calendar cal = Calendar.getInstance();  
	  cal.add(Calendar.YEAR, 3);  
	  reuse.waitforsec(4);
      String date = sdf.format(cal.getTime()); 
      String m=date.toString().split(":")[1];
	   String y=date.toString().split(":")[0];
	   expdate_month.sendKeys(m);
	   expdate_year.sendKeys(y);
	   reuse.waitforsec(4);
	   payNow.click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
	}
	public void clickOnCancelSubscriptionButtonForProxyUser() {
		try {
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(cancelRefundSection))));
			Thread.sleep(4000);
			Scrom.orderID = paymentOrderID.getText();
			Scrom.orderAmount = paymentAmount.getText();
			Scrom.orderSummaryCourse = paymentCourseName.getText();
			Scrom.orderTransaction = paymentTransactionNumber.getText();
			System.out.println("The order id is " + Scrom.orderID + " and the order amount is " + Scrom.orderAmount
					 + " for course " + Scrom.orderSummaryCourse + " with transaction number " + Scrom.orderTransaction);
			driver.findElement(By.xpath(cancelRefundSection + "//a/span")).click();
			wait.until(ExpectedConditions.visibilityOf(CancelReasonDropdown));
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void validateWarningHeadingCancelPage() {
		wait.until(ExpectedConditions.visibilityOf(cancelWarningHeading));
		String text = cancelWarningHeading.getText();
		System.out.println(text);
		Assert.assertTrue(text.equals("Are you sure you want to cancel?"));
	}

	public void validateWarningTextCancelPage() {
		wait.until(ExpectedConditions.visibilityOf(cancelWarningText));
		String text = cancelWarningText.getText();
		System.out.println(text);
		Assert.assertTrue(text.equals("By cancelling this subscription, you will lose access to the course, and your refund request will be initiated."));
	}

	public void validateErrorMessageWithCountCancelPage(int count) {
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(validationErrorMessageCount))));
		String text = driver.findElement(By.xpath(validationErrorMessageCount)).getText();
		System.out.println(text);
		Assert.assertTrue(text.equals("Total number of form validation error is " + count));
	}

	public void validateErrorListWithCountCancelPage(int number) {
		wait.until(ExpectedConditions.visibilityOf(driver.findElements(By.xpath(validationErorList)).get(0)));
		List<WebElement> listCount = driver.findElements(By.xpath(validationErorList));
		String text = listCount.get(0).getText();
		System.out.println(text);
		Assert.assertTrue(text.equals("Other Reason is required."));
		Assert.assertTrue(listCount.size() == number);
	}

	public void clickCancelAndGoBackButton() {
		wait.until(ExpectedConditions.visibilityOf(cancelAndGoButton));
		cancelAndGoButton.click();
		wait.until(ExpectedConditions.visibilityOf(endUserCourseDate));
	}
	public boolean launchNLNCourseWithName(String name)
	{
		if(courseListName.containsKey( name+"Option"))
		 name=courseListName.get( name+"Option").toString();

		System.out.println(name);

//		name=name.replace("Â", "");
		WebDriverWait wait = new WebDriverWait(driver, 40);	
		boolean flag = false;
		checkCourseAvailable();


		try {
			name=name.replace("Â", "");
			System.out.println(name.replace("Â", ""));
			try
			{
			courseAvailable = "//div[@id='current-programs']//div[contains(@class,'wrapper-bg wrapper')]";
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[text()='"+name+"']" ))));

			}
			catch(NoSuchElementException e)
			{
				courseAvailable = "//div[@id='current-programs']//div[contains(@class,'wrapper-bg wrapper')]";
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[contains(text(),'"+name+"')]" ))));

			}
		}
		catch(NoSuchElementException e)
		{
			try
			{
				courseAvailable = "//div[@class='wrapper']//div[@class='row inner-content d-flex']";
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[text()='"+name+"']" ))));

			}
			catch(NoSuchElementException m)
			{
				courseAvailable = "//div[@class='wrapper']//div[@class='row inner-content d-flex']";
								wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseAvailable+"//span[contains(text(),'"+name+"')]" ))));

			}



		}


		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath( courseAvailable ))));

		List<WebElement> rowCount = driver.findElements(By.xpath(courseAvailable));

		for(int i = 1; i <= rowCount.size(); i++)
		{
			System.out.println("tess");
			String courseName = driver.findElement(By.xpath("(" + courseAvailable + "//span[@class='course-title'])[" + i + "]")).getText().trim();

			System.out.println(courseName);
			System.out.println(name);
			System.out.println(courseAvailable);
			System.out.println(rowCount.size());
			System.out.println(name.toLowerCase().trim().contains(courseName.toLowerCase().trim().replace(" new!", "")));
			System.out.println(name.toLowerCase().trim().contains(courseName.toLowerCase().trim().replace("new!", "")));

			if(name.toLowerCase().trim().contains(courseName.toLowerCase().trim().replace(" new!", "")))
			{
				String action;
				try
				{
					action = driver.findElement(By.xpath("(" + courseAvailable +buttonxpath+")[" + i + "]")).getText();
				}
				catch(Exception e)
				{
						action = driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).getText();

				}
				System.out.println(action.toLowerCase());
				String element = "//span[contains(text(), '" + name + 
						"')]//ancestor::div[contains(@class, 'row')]//parent::div//following-sibling::div//span[contains(text()";

				if(action.toLowerCase().contains("resume"))
				{
					try
					{
						driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).click();
					}
					catch(Exception e)
					{
						driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).click();

					}
					flag = true;
					break;
				}
				else if(action.toLowerCase().contains("activate"))
				{
					driver.findElement(By.xpath("(" + courseAvailable + buttonxpath+")[" + i + "]")).click();
					try
					{

				    wait.until(ExpectedConditions.visibilityOf(Activate));

						Activate.click();	
					}
					catch (Exception e) {
						System.out.println(driver.getWindowHandles().size());
					}
					try 
					{Thread.sleep(4000);
					WebElement courseRow = driver.findElement(By.xpath(element + ", 'Launch')]"));
						this.wait.until(ExpectedConditions.visibilityOf(courseRow));
						courseRow.click();
						flag = true;
						break;

					}
					catch(Exception e)
					{


						
						WebElement courseRow = driver.findElement(By.xpath(element + ", 'Launch')]"));
							this.wait.until(ExpectedConditions.visibilityOf(courseRow));
							courseRow.click();
						flag = true;
						break;
					}	
				}
				else if(action.toLowerCase().contains("launch"))
				{
					WebElement courseRow = driver.findElement(By.xpath(element + ", 'Launch')]"));
					wait.until(ExpectedConditions.visibilityOf(courseRow));
					courseRow.click();
					flag = true;
					break;
				}
			}
		}
		return flag;
	}

	public String changeDateAsPerTime(int num, String time)
	{
		LocalDate localDate = LocalDate.now();
		LocalDate requiredDate = null;
		if(time.equalsIgnoreCase("days"))
		{
			requiredDate = localDate.plusDays(num);
		}
		else if(time.equalsIgnoreCase("month"))
		{
			requiredDate = localDate.plusMonths(num);
		}
		else if(time.equalsIgnoreCase("year"))
		{
			requiredDate = localDate.plusYears(num);
		}
		return requiredDate.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")).toString();
	}	

	@SuppressWarnings("unchecked")
	public void validateCancelRefundSection(int dayCount, String dateType) {
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(cancelRefundSection))));
		String headingText = driver.findElement(By.xpath(cancelRefundSection + "/h4")).getText();
		String labelText = driver.findElement(By.xpath(cancelRefundSection + "/span[1]")).getText();
		String labelDate = driver.findElement(By.xpath(cancelRefundSection + "/span[2]")).getText();
		String buttonText = driver.findElement(By.xpath(cancelRefundSection + "//button")).getText();
		String date = changeDateAsPerTime(dayCount, dateType);
		System.out.println("Date after adding 30 days is " + date);
		Assert.assertTrue(headingText.equals("Cancel & Refund"));
		Assert.assertTrue(labelText.equals("Cancel my subscription and request refund. Cancellation available till"));
		Assert.assertTrue(labelDate.equals(date));
		Assert.assertTrue(buttonText.equals("CANCEL SUBSCRIPTION"));
	}

	@SuppressWarnings("unchecked")
	public void validateCancelRefundSectionForLaunchedCourse() {
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(cancelRefundSection))));
		String headingText = driver.findElement(By.xpath(cancelRefundSection + "/h4")).getText();
		String labelText = driver.findElement(By.xpath(cancelRefundSection + "/span[1]")).getText();
		List<WebElement> cancelButton =  driver.findElements(By.xpath(cancelRefundSection + "//button"));
		Assert.assertFalse("Cancel Button is available" , cancelButton.size() > 0);
		Assert.assertTrue(headingText.equals("Cancel and Refund"));
		Assert.assertTrue(labelText.equals("Cancellation is no longer available for this order. Please contact RQI Partner support for help."));

	}
	public void validate_courseDescription(String value)
	{
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.visibilityOf(courseDescription));

	if(courseListName.containsKey( value+"Option"))
		value=courseListName.get( value+"Option").toString();

	
	System.out.println(courseDescription.getText());
	Assert.assertEquals(courseDescription.getText(), value);

	}
	public void validateViewOrderBtnUnavailable()
	{
		try {
		WebDriverWait wait = new WebDriverWait(driver, 5);
		Assert.assertFalse(driver.findElements(By.xpath("//*[@id='orderViewPopup']")).size() > 0);
		}
		catch(NoSuchElementException e) {
			Assert.fail(e.getMessage());
		}
	}
	
	public void clickEndUserProgramLinkWithoutRefresh()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(endUserProgramLink));
			endUserProgramLink.click();
			Thread.sleep(5000);
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
	}
	

	public void getTopicList(String course,String date)
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(reviewScore.get(0)));
		Assert.assertEquals(reviewScore.size(), review_btn.size());
//		Assert.assertEquals(getNumberRows(),0);
		Boolean flag=false;
		int count=review_btn.size();
		int loopcount=0;
		for(int i=0;i<review_btn.size();i++)
		{
		 dataMap.put( course+"Topic"+i,topics.get(i).getText())	;
			System.out.println("Topic :"+topics.get(i).getText());
			review_btn.get(i).click();
			onlyExitCourse();
			flag=true;
			clickOnSubmitOnlyWithDate(date);
			clickOncompletedActivitiesButton();
			
			loopcount++;
		}
		 dataMap.put( course+"TopicNumber",String.valueOf( loopcount))	;
			
		Assert.assertEquals(count, loopcount);
		
		Assert.assertTrue("Course not in review status",flag);
		
	}
	
	
	
	@FindBy(xpath = "//select[@id='ce_job_title']")
	WebElement jobtitleselectionwithinpopup;
	@FindBy(xpath = "//select[@id='ce_job_title_edit']")
	WebElement jobtitleselectionwithineditpopup;

	public void jobtitleselectionwithinCM_CEpopup(String jobtitle)
	{
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOf(jobtitleselectionwithinpopup));
		jobtitleselectionwithinpopup.click();
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//select[@id='ce_job_title']//option[contains(text(),'"+jobtitle+"')]"))));
		driver.findElement(By.xpath("//select[@id='ce_job_title']//option[contains(text(),'"+jobtitle+"')]")).click();

	}

	public void jobtitleselectionwithinCM_CEpopupfromedit(String jobtitle) throws Exception
	{
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOf(jobtitleselectionwithineditpopup));
		jobtitleselectionwithineditpopup.click();
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//select[@id='ce_job_title_edit']//option[contains(text(),'"+jobtitle+"')]"))));
		driver.findElement(By.xpath("//select[@id='ce_job_title_edit']//option[contains(text(),'"+jobtitle+"')]")).click();
		dataMap.clear();
	}


	@FindBy(xpath = "//div[(text()='Type')]/following::select[@id=\"type\"]")
	WebElement typeselectionwithinpopup;

	@FindBy(xpath = "//div[(text()='License Number')]/following::input[@id=\"licenseNumber\"]")
	WebElement Lisencenumberinputnwithinpopup;

	@FindBy(xpath = "//div[(text()='License Type')]/following::select[@id=\"licenseType\"]")
	WebElement Liscensetypeselectionwithinpopup;

	@FindBy(xpath = "//div[(text()='License State')]/following::input[@id=\"licenseState\"]")
	WebElement Lisencesstateinputwithinpopup;

	@FindBy(xpath = "//div[(text()='nremt Number')]/following::input[@id=\"nremtNumber\"]")
	WebElement nremtNumberinputwithinpopup;

	@FindBy(xpath = "//div[(text()='NEMSID')]/following::input[@id=\"nemsId\"]")
	WebElement NEMSIDinputwithinpopup;

	@FindBy(xpath = "//div[(text()='Address Line 1')]/following::input[@id=\"address_line_1\"]")
	WebElement Addrline1inputwithinpopup;	

	@FindBy(xpath = "//div[(text()='Address Line 2')]/following::input[@id=\"address_line_2\"]")
	WebElement Addrline2inputwithinpopup;

	@FindBy(xpath = "//div[(text()='City')]/following::input[@id=\"city\"]")
	WebElement Cityinputwithinpopup;

	@FindBy(xpath = "//div[(text()='Zipcode')]/following::input[@id=\"zipcode\"]")
	WebElement ZipCodeinputwithinpopup;

	@FindBy(xpath = "//div[(text()='State/Province')]/following::select[@id=\"state\"]")
	WebElement stateselectionwithinpopup;

	@FindBy(xpath = "//div[(text()='License Expiration Date')]/following::input[@id=\"licenseExpirationDate\"]")
	WebElement LicenseExpirationdatewithinpopup;

	@FindBy(xpath = "//div[(text()='nremtReRegDate')]/following::input[@id=\"nremtReRegDate\"]")
	WebElement nremtreregdate;

	@FindBy(xpath = "//div[(text()='Aarc Member ID')]/following::input[@id=\"aarcMemberId\"]")
	WebElement Aarcmemberidinput;

	@FindBy(xpath = "//div[(text()='AAP ID')]/following::input[@id=\"aapId\"]")
	WebElement AAPIDinput;

	@FindBy(xpath = "//div[@class=\"modal-footer\"]//button[contains(text(),\"Submit\")]")
	WebElement submitbuttonwithinpopup;


	public void validatetabledatawithinCM_CEpopup() throws Exception 
	{
		Thread.sleep(2000);
		if(dataMap.containsKey("Type"))
				{
				typeselectionwithinpopup.click();

				Select value = new Select(typeselectionwithinpopup);
				value.selectByVisibleText(dataMap.get("Type"));

		        }
		if(dataMap.containsKey("License Number"))
				{

					Lisencenumberinputnwithinpopup.sendKeys(dataMap.get("License Number"));
				}
		if(dataMap.containsKey("License Type"))
				{
				Liscensetypeselectionwithinpopup.click();
				Select value = new Select(Liscensetypeselectionwithinpopup);
				value.selectByVisibleText(dataMap.get("License Type"));
				}
		if(dataMap.containsKey("License State"))
				{		 
					Lisencesstateinputwithinpopup.sendKeys(dataMap.get("License State"));
				}
		if(dataMap.containsKey("License Expiration Date"))
		{
			  SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");  
			  Calendar cal = Calendar.getInstance();
			  String currentdate = sdf.format(cal.getTime()); 
			    System.out.println(cal.getTime());
				   String todaysdate = currentdate.toString().split("/")[2];
		       System.out.println(currentdate);
			  cal.add(Calendar.MONTH, 1);  		 
		      String nextmonthdate = sdf.format(cal.getTime()); 
		       System.out.println(nextmonthdate);
		      System.out.println(cal.getTime());
//		sdf = new SimpleDateFormat("MMMM");
//	     String strMonth= sdf.format(cal.getTime());
//	     System.out.println("Month in MMMM format = "+strMonth);
		      LicenseExpirationdatewithinpopup.click();
		      Thread.sleep(1000);
			driver.findElement(By.xpath("//*[text()="+todaysdate+" and @class = 'day' ]")).click();
			Thread.sleep(2000);
		}
		if(dataMap.containsKey("nremt Number"))
				{
					nremtNumberinputwithinpopup.sendKeys(dataMap.get("nremt Number"));
				}
		if(dataMap.containsKey("NEMSID")) 
				{
			Thread.sleep(1500);
					NEMSIDinputwithinpopup.sendKeys(dataMap.get("NEMSID"));
				}
		if(dataMap.containsKey("Address Line 1")) 
				{
					Addrline1inputwithinpopup.sendKeys(dataMap.get("Address Line 1"));
				}
		if(dataMap.containsKey("Address Line 2")) 
				{
					Addrline2inputwithinpopup.sendKeys(dataMap.get("Address Line 2"));
				}
		if(dataMap.containsKey("City") )
				{
					Cityinputwithinpopup.sendKeys(dataMap.get("City"));
				}
		if(dataMap.containsKey("Zipcode") )
				{
					ZipCodeinputwithinpopup.sendKeys(dataMap.get("Zipcode"));
				}

		if(dataMap.containsKey("Aarc Member ID") )
		{
			Aarcmemberidinput.sendKeys(dataMap.get("Aarc Member ID"));
		}

		if(dataMap.containsKey("AAP ID") )
		{
			AAPIDinput.sendKeys(dataMap.get("AAP ID"));
		}
		if(dataMap.containsKey("State/Province"))
				{
				stateselectionwithinpopup.click();
				Select value = new Select(stateselectionwithinpopup);
				value.selectByVisibleText(dataMap.get("State/Province"));
				}		

		if(dataMap.containsKey("nremtReRegDate"))
				{
			 SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");  
			  Calendar cal = Calendar.getInstance();
			  String currentdate = sdf.format(cal.getTime());
			  String todaysdate = currentdate.toString().split("/")[2];
			 nremtreregdate.click();
			 Thread.sleep(2000);
				driver.findElement(By.xpath("//*[text()="+todaysdate+" and @class = 'day' ]")).click();
				Thread.sleep(1500);
				}
	}

//	@FindBy(xpath = "//span[contains(text(),\"NRP CE Profile information updated successfully.\")]")
//	WebElement CEprofileupdatesuccessmessage;
	public void cecmepopupsubmit() throws InterruptedException {
		submitbuttonwithinpopup.click();
		Thread.sleep(3000);
//		assertTrue(CEprofileupdatesuccessmessage.isDisplayed());

	}
	@FindBy(xpath = "//a[contains(text(),\"View NRP CE Profile\")]")
	WebElement viewCEProfile;

	@FindBy(xpath = "//button[@id=\"ce-profile-view-btn\"]")
	WebElement EditCEProfile;

	@FindBy(xpath = "	//form[@id=\"ce-profile-edit\"]//input[@type=\"text\"]")
	List<WebElement> inputtextfieldsinpopup;

	public void verifyviewprofileispresent() {
	Assert.	assertTrue(viewCEProfile.isDisplayed());		
	}
	public void clickonviewCElink() throws InterruptedException {
		viewCEProfile.click();
		Thread.sleep(3000);		
	}

	public void validate_Viewdetails_CMCE(String label, String value) throws Exception {
		Thread.sleep(3000);
		System.out.println(label);
		System.out.println(value);		
		Assert.	assertTrue(driver.findElement(By.xpath("//div[label='"+label+"']//div[span='"+value+"']")).isDisplayed());

	}
	@FindBy(xpath = "//div[@id=\"ce-cme-app-provider_view_data\"]//p")
	List<WebElement> viewdetailsparalist;
	public void validate_Viewdetails_CMCE1() throws Exception {	
		try {
		int count=viewdetailsparalist.size();
		System.out.println(count);
		for(int i=1;i<=count;i++)
		{
		String valuefromapplication = driver.findElement(By.xpath(("(//div[@id=\"ce-cme-app-provider_view_data\"]//p)["+i+"]"))).getText();
		System.out.println(valuefromapplication);
//		val input = "before/after"

				// Split will return an array
				String[] split = valuefromapplication.split("\\n");
				String key  = split[0];// First element
				String value  = split[1];
		System.out.println(key);
		System.out.println(value);
		Assert.	assertTrue(dataMap.containsKey(key));
		Assert.	assertTrue(dataMap.containsValue(value));
		}
		}
		catch(Exception e)
		{
		e.printStackTrace()	;
		}
	}
	//div[@id="ce-cme-app-provider_view_data"]//p
	public void clickonsubmitbutton() throws InterruptedException {
		Thread.sleep(1500);
		EditCEProfile.click();
		Thread.sleep(3000);
	}
	public void clearallmandatoryfields() throws Exception {

//		int count=inputtextfieldsinpopup.size();
//		System.out.println(count);
////		int loopcount=1;
//		for(int i=1;i<=count;i++)
//		{
//		driver.findElement(By.xpath(("(//form[@id=\"ce-profile-edit\"]//input[@type=\"text\"])["+i+"]"))).click();
//		driver.findElement(By.xpath(("(//form[@id=\"ce-profile-edit\"]//input[@type=\"text\"])["+i+"]"))).sendKeys(Keys.CONTROL,"a",Keys.DELETE);
//		Thread.sleep(1000);
//		}
		Lisencenumberinputnwithinpopup.click();
		Lisencenumberinputnwithinpopup.sendKeys(Keys.CONTROL,"a",Keys.DELETE);
		Thread.sleep(1500);

		Lisencesstateinputwithinpopup.click();
		Lisencesstateinputwithinpopup.sendKeys(Keys.CONTROL,"a",Keys.DELETE);
		Thread.sleep(1500);

		nremtNumberinputwithinpopup.click();
		nremtNumberinputwithinpopup.sendKeys(Keys.CONTROL,"a",Keys.DELETE);
		Thread.sleep(1500);

		NEMSIDinputwithinpopup.click();
		NEMSIDinputwithinpopup.sendKeys(Keys.CONTROL,"a",Keys.DELETE);
		Thread.sleep(1500);

		Addrline1inputwithinpopup.click();
		Addrline1inputwithinpopup.sendKeys(Keys.CONTROL,"a",Keys.DELETE);
		Thread.sleep(1500);

		Cityinputwithinpopup.click();
		Cityinputwithinpopup.sendKeys(Keys.CONTROL,"a",Keys.DELETE);
		Thread.sleep(1500);

		ZipCodeinputwithinpopup.click();
		ZipCodeinputwithinpopup.sendKeys(Keys.CONTROL,"a",Keys.DELETE);
		Thread.sleep(1500);

//		nremtreregdate.clear();
//		Thread.sleep(1500);
//		
//		LicenseExpirationdatewithinpopup.clear();
//		Thread.sleep(1500);


	}

	public void Validatetheerrormessage(String errormessages) {
		Assert.assertTrue(driver.findElement(By.xpath("//form[@id=\"ce-profile-edit\"]//div//small[contains(text(),'"+errormessages+"')]")).isDisplayed());
	}
@FindBy(xpath = "//*[@id=\"ce-cme-app-provider_view\"]/div/div/div[1]/button/span[1]")
	WebElement closecmcepopup;

	@FindBy(xpath = "(//a[@title=\"NRP CE Profile\"])[1]")
	WebElement NRP_CElink_myprogramspage;
	
	public void closeAPP_cecmepopup() throws Exception {	
	closecmcepopup.click();
	Thread.sleep(1500);	
	}
	public void clickNRPCElink_Myprograms() throws Exception {
		NRP_CElink_myprogramspage.click();
		Thread.sleep(3000);

	}
@FindBy(xpath = "(//*[@id=\"dropdownContainer_mobile\"]/a)[2]")
	WebElement Kebabicon_completedprogramstab;

	@FindBy(xpath = "(//*[@id=\"dropdownList_mobile\"])[2]//li[3]")
	WebElement NRP_CELink_KEBABicon;


	public void clickonkebabicon_completedprograms() throws InterruptedException {
		Thread.sleep(4000);
//		wait.until(ExpectedConditions.visibilityOf(Kebabicon_completedprogramstab));
		Kebabicon_completedprogramstab.click();
		}

	public void VerifyNRP_CEprofilelink() throws InterruptedException {
		Thread.sleep(2000);
		Assert.assertTrue(NRP_CELink_KEBABicon.isDisplayed());
	}

	public void clickNRP_CEprofilekebab() throws InterruptedException {
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOf(NRP_CELink_KEBABicon));
		NRP_CELink_KEBABicon.click();
		Thread.sleep(2000);

	}
	
	public void clickReferenceLibrary()
	{
		wait.until(ExpectedConditions.visibilityOf(endReferenceLibraryLink));
		endReferenceLibraryLink.click();
	}
	
	public void clickMyProgram()
	{
		wait.until(ExpectedConditions.visibilityOf(myProgramLink));
		myProgramLink.click();
	}
	
	public void verifySupportDropNotAvailable() {
		if(!(driver.findElements(By.xpath(contactSupportLabel)).size() > 0)) {
			Assert.fail("Support dropdown is available");
		}
	}
	
}

	