package com.qa.pages;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.qa.util.TestBase;

public class Notification extends TestBase
{
	@FindBy(xpath = "//a[contains(text(), 'Notification Log')]")
	WebElement notificationReportLink;
	
	@FindBy(xpath = "//label[@id = 'inputSearch' and text() = 'Search for Name, Email or User ID']")
	WebElement searchField;
	
	@FindBy(xpath = "//input[@name = 'searchbox_name_email']")
	WebElement inputSearchField;
	
	@FindBy(xpath = "//button[@data-id = 'orgLevel']")
	WebElement orgLevelField;
	
	@FindBy(xpath = "//a[contains(text(), 'More Filters')]")
	WebElement moreFilterLink;
	

	@FindBy(xpath = "//select[@name='orgCourseIds[]']//following-sibling::div/button")
	WebElement courseNameFilter;

	@FindBy(xpath = "//div[@id = 'job_select']//button")
	WebElement jobTitleDropdown;
	
	@FindBy(xpath = "//select[@id = 'job_title_id']//following-sibling::div//a")
	WebElement jobTitleSelectAllFilter;
	
	@FindBy(xpath = "//label[text() = 'Group']//parent::div//button")
	WebElement groupDropdown;
	
	@FindBy(xpath = "//select[@id = 'group_id']//following-sibling::div//a")
	WebElement groupSelectAllFilter;
	
	@FindBy(xpath = "//label[contains(text() , 'User Status')]//parent::div//button")
	WebElement userStatusDropdown;
	
	@FindBy(xpath = "//label[contains(text() , 'User Status')]//parent::div//button/span")
	WebElement userStatusDropdownDefault;
	
	@FindBy(xpath = "//a[contains(text(), 'Course Filters')]")
	WebElement courseFilterLink;
	
	@FindBy(xpath = "(//select[@name = 'orgCourseIds[]']//following-sibling::div)//input[@type= 'text']")
	WebElement courseFilterFilterSearch;

	@FindBy(xpath = "//label[text() = 'Course']//parent::div//button")
	WebElement courseDropdown;
	
	@FindBy(xpath = "//div/a[contains(text(), 'Notification Log')]")
	WebElement notificationLogLink;
	
	@FindBy(xpath = "//label[text() = 'Notification Title']//parent::div//button")
	WebElement notificationTitleDropdown;
	
	@FindBy(xpath = "//label[text() = 'Delivery Status']//parent::div//button")
	WebElement deliveryStatusDropdown;
	
	@FindBy(xpath = "//button[@name = 'exportbtn']")
	WebElement exportButton;
	
	@FindBy(xpath = "//button[@id = 'resend']")
	WebElement resendButton;
	
	@FindBy(xpath = "//button[@id = 'searchbtn']")
	WebElement searchButton;
	
	@FindBy(xpath = "//div[@id = 'clear']//a")
	WebElement clearSearchLink;
	
	@FindBy(xpath = "//a[contains(text(), 'More Filters')]//ancestor::div[@class='card']//button[@value = 'Search']")
	WebElement moreFilterSearchButton;
	
	@FindBy(xpath = "//a[contains(text(), 'More Filters')]//ancestor::div[@class='card']//a[text() = 'Clear Search']")
	WebElement moreFilterClearSearch;
	
	@FindBy(xpath = "//a[contains(text(),'Course Filters')]")
	WebElement coursefiltersnotif;
	
	
	@FindBy(xpath = "//a[@class = 'card-link']")
	WebElement moreFilter;
	
	@FindBy(xpath = "//a[contains(text(), 'Course')]//ancestor::div[@class='card']//button[@value = 'Search']")
	WebElement courseFilterSearchButton;
	
	@FindBy(xpath = "//a[contains(text(), 'Course')]//ancestor::div[@class='card']//a[text() = 'Clear Search']")
	WebElement courseFilterClearSearch;
	
	@FindBy(xpath = "//select[@id = 'orgCourseIds']//following-sibling::div//a")
	WebElement courseSelectAllFilter;
	
	@FindBy(xpath = "//select[@id = 'deliveryStatusIds']//following-sibling::div//a")
	WebElement deliverySelectAllFilter;
	
	@FindBy(xpath = "//select[@id = 'deliveryStatusIds']//following-sibling::div//li[2]/label")
	WebElement deliveryStatusSentOption;
	
	@FindBy(xpath = "//a[contains(text(), 'Notification Log  ')]//ancestor::div[@class='card']//button[@value = 'Search']")
	WebElement deliveryStatusSearchButton;
	
	@FindBy(xpath = "//a[contains(text(), 'Notification Log  ')]//ancestor::div[@class='card']//a[text() = 'Clear Search']")
	WebElement notificationLogClearSearch;
	
	@FindBy(xpath = "//select[@id = 'statusFilter']//following-sibling::div//a")
	WebElement selectAllFilter;
	
	@FindBy(xpath = "//div[@class= 'bottom']//div[@class = 'dataTables_info']")
	WebElement searchResult;
	
	@FindBy(xpath = "//div[@class = 'dataTables_length']//select")
	WebElement rowsDropdown;
	
	@FindBy(xpath = "//a[@id = 'reports_next']")
	WebElement nextPageButton;
	
	@FindBy(xpath = "//div[@id = 'reports_paginate']//span/a[1]")
	WebElement firstPageButton;
	
	@FindBy(xpath = "//body[@class]")
	WebElement pageLoad;
	
	@FindBy(xpath = "//div[@class = 'bootbox-body']")
	WebElement resendPopupText;
	
	@FindBy(xpath = "(//label[@for = 'checkbox_all-0'])[1]")
	WebElement selectallnotif;
	@FindBy(xpath = "//button[@data-bb-handler = 'cancel']")
	WebElement resendPopupCancelButton;
	
	@FindBy(xpath = "//button[@data-bb-handler = 'confirm']")
	WebElement resendPopupConfirmButton;
	@FindBy(xpath = "//a[contains(text(),'Notifications')]")
	WebElement notificationTabLink;
	@FindBy(xpath = "//h4[contains(text(),'Notifications')]")
	WebElement notificationTabHeading;
	String userCourseFilter = "(//select[@name = 'orgCourseIds[]']//following-sibling::div//ul//label)";

	
	String val;
	String userFirstName, userID, userEmail;
	String firstName = "(//table[contains(@id,'reports')]//tbody//td[4])[";
	String id = "(//table[contains(@id,'reports')]//tbody//td[2])[";
	String email = "(//table[contains(@id,'reports')]//tbody//td[14])[";
	String status = "(//table[contains(@id,'reports')]//tbody//td[10])[";
	String course = "(//table[contains(@id,'reports')]//tbody//td[6])[";
	String notificationList = "//label[text() = 'Notification Title']//parent::div//li";
	String deliveryStatus = "(//table[contains(@id,'reports')]//tbody//td[8])[";
	String deliverOption = "//select[@id = 'deliveryStatusIds']//following-sibling::div//li";
	String row = "//table[contains(@id,'reports')]//tbody//tr";
	String searchTable = "//div[@class = 'dataTables_scrollHead']//th";
	String courseOption = "//select[@id = 'orgCourseIds']//following-sibling::div//li";
	String jobTitle = "(//table[contains(@id,'reports')]//tbody//td[13])[";
	String tableLeftWrapper = "(//table[@role = 'grid'])[5]//tbody/tr";
	String resendPopupActualText = "Would you wish to resend the notification(s)?";
	String notification = "(//table[contains(@id,'reports')]//tbody//td[5])[";
	String resent = "(//table[contains(@id,'reports')]//tbody//td[9])[";
	String reportTable = "//table[@id = 'reports']//tbody/tr";
	
	public Notification() 
	{
		PageFactory.initElements(driver, this);
		try 
		{
			int m=0;
			String val = pageLoad.getAttribute("class");
			while(val.contains("loading_compliance loading"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
		} 
		catch (Exception e) 
		{
			
		}
	}

	public void selectNotificationReportLink()
	{
		wait.until(ExpectedConditions.visibilityOf(notificationReportLink));
		notificationReportLink.click();
		try
		{
			wait.until(ExpectedConditions.visibilityOf(pageLoad));
			val = pageLoad.getAttribute("class");
			int m=0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
		}
		catch(Exception e)
		{
			e.getMessage();
			Assert.fail(e.getMessage());
		}
		
	}
	
	public void validateSearchFields()
	{
		wait.until(ExpectedConditions.visibilityOf(searchField));
		wait.until(ExpectedConditions.visibilityOf(orgLevelField));
	}
	
	public void vaidateMoreFilterFields()
	{
		wait.until(ExpectedConditions.visibilityOf(moreFilterLink));
		moreFilterLink.click();
		wait.until(ExpectedConditions.visibilityOf(jobTitleDropdown));
		wait.until(ExpectedConditions.visibilityOf(groupDropdown));
		wait.until(ExpectedConditions.visibilityOf(userStatusDropdown));
	}

	public void vaidateCourseFilterFields()
	{
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(courseFilterLink));
			Thread.sleep(5000);
			courseFilterLink.click();
			wait.until(ExpectedConditions.visibilityOf(courseDropdown));
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
	}
	
	public void vaidateNotificationLogFields()
	{
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(notificationLogLink));
			Thread.sleep(5000);
			notificationLogLink.click();
			wait.until(ExpectedConditions.visibilityOf(notificationTitleDropdown));
			wait.until(ExpectedConditions.visibilityOf(deliveryStatusDropdown));
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
	}
	
	public void validateExportButton()
	{
		wait.until(ExpectedConditions.visibilityOf(exportButton));
	}
	
	public void validateResendButton()
	{
		wait.until(ExpectedConditions.visibilityOf(resendButton));
	}
	
	public int generateRandomNumber(int number)
	{
		Random objGenerator = new Random();
		int randomNumber = objGenerator.nextInt(number);
		return randomNumber;
	}
	
	public void getUserDetails(int number)
	{
		try 
		{
			int rowNumber = generateRandomNumber(number);
			while(rowNumber < 1 )
			{
				rowNumber = generateRandomNumber(number);
			}
			Thread.sleep(5000);
			User usr=new User();
			usr.usersearchEmail(usr.usrEmail[rowNumber-1]);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(firstName + "1" + "]"))));
			userFirstName = driver.findElement(By.xpath(firstName + "1" + "]")).getText();
			userID = driver.findElement(By.xpath(id + "1" + "]")).getText();
			userEmail = driver.findElement(By.xpath(email + "1" + "]")).getText();
			System.out.println(rowNumber);
		} 
		catch (Exception e) 
		{
			
		}
		
	}
	
	public void searchUserByName()
	{
		try {
			wait.until(ExpectedConditions.visibilityOf(searchField));
			Thread.sleep(5000);
			searchField.click();
			inputSearchField.sendKeys(userFirstName);
			System.out.println("searching keyword is " + userFirstName);
			searchButton.click();
			int m=0;
			String val = pageLoad.getAttribute("class");
			while(val.contains("loading_compliance loading"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			JavascriptExecutor js = (JavascriptExecutor)driver;
			val = js.executeScript("return document.readyState").toString();
			m=0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			String value  = driver.findElement(By.xpath(firstName +  "1]")).getText();
			System.out.println("Searched Result keyword is " + value);
			Assert.assertTrue(value.trim().equalsIgnoreCase(userFirstName.trim()));
			wait.until(ExpectedConditions.visibilityOf(clearSearchLink));
			wait.until(ExpectedConditions.elementToBeClickable(clearSearchLink));
			Thread.sleep(5000);
			clearSearchLink.click();
			val = js.executeScript("return document.readyState").toString();
			m=0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			wait.until(ExpectedConditions.visibilityOf(searchField));
			searchField.click();
			inputSearchField.sendKeys(userFirstName.substring(2));
			searchButton.click();
			val = pageLoad.getAttribute("class");
			m=0;
			while(val.contains("loading_compliance loading"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			val = js.executeScript("return document.readyState").toString();
			m=0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(5000);
			value  = driver.findElement(By.xpath(firstName +  "1]")).getText();
			Assert.assertTrue(value.equalsIgnoreCase(userFirstName));
			wait.until(ExpectedConditions.visibilityOf(clearSearchLink));
			clearSearchLink.click();
			val = js.executeScript("return document.readyState").toString();
			m=0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
		} 
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
			
		}
	}
	
	public void searchUserByUserID()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		wait.until(ExpectedConditions.visibilityOf(clearSearchLink));
		wait.until(ExpectedConditions.elementToBeClickable(clearSearchLink));
		js.executeScript("arguments[0].click();", clearSearchLink);
		wait.until(ExpectedConditions.visibilityOf(searchField));
		searchField.click();
		inputSearchField.clear();
		inputSearchField.sendKeys(userID);
		searchButton.click();
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.contains("loading_compliance loading"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		val = js.executeScript("return document.readyState").toString();
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			m++;
		}
		String value  = driver.findElement(By.xpath(id +  "1]")).getText();
		System.out.println(id);
		System.out.println(value);
		System.out.println(userID);
		
		Assert.assertTrue(value.equalsIgnoreCase(userID));
		wait.until(ExpectedConditions.visibilityOf(clearSearchLink));
		wait.until(ExpectedConditions.elementToBeClickable(clearSearchLink));
		js.executeScript("arguments[0].click();", clearSearchLink);
		val = js.executeScript("return document.readyState").toString();
		m=0;
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			m++;
		}
	}
	
	public void searchUserByEmail()
	{
		wait.until(ExpectedConditions.visibilityOf(clearSearchLink));
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		wait.until(ExpectedConditions.elementToBeClickable(clearSearchLink));
		clearSearchLink.click();
		wait.until(ExpectedConditions.visibilityOf(searchField));
		searchField.click();
		inputSearchField.clear();
		inputSearchField.sendKeys(userEmail);
		searchButton.click();
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.contains("loading_compliance loading"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		JavascriptExecutor js = (JavascriptExecutor)driver;
		val = js.executeScript("return document.readyState").toString();
		m=0;
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			m++;
		}
		String value  = driver.findElement(By.xpath(email +  "1]")).getText();
		Assert.assertTrue(value.equalsIgnoreCase(userEmail));
		wait.until(ExpectedConditions.visibilityOf(clearSearchLink));
		wait.until(ExpectedConditions.elementToBeClickable(clearSearchLink));
		js.executeScript("arguments[0].click();", clearSearchLink);
		val = js.executeScript("return document.readyState").toString();
		m=0;
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			m++;
		}
		wait.until(ExpectedConditions.visibilityOf(searchField));
		searchField.click();
		inputSearchField.clear();
		inputSearchField.sendKeys(" " + userEmail + " ");
		searchButton.click();
		val = pageLoad.getAttribute("class");
		m=0;
		while(val.contains("loading_compliance loading"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		js = (JavascriptExecutor)driver;
		val = js.executeScript("return document.readyState").toString();
		m=0;
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			m++;
		}
		value  = driver.findElement(By.xpath(email +  "1]")).getText();
		Assert.assertTrue(value.equalsIgnoreCase(userEmail));
		wait.until(ExpectedConditions.visibilityOf(clearSearchLink));
		wait.until(ExpectedConditions.elementToBeClickable(clearSearchLink));
		js.executeScript("arguments[0].click();", clearSearchLink);
		val = js.executeScript("return document.readyState").toString();
		m=0;
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			m++;
		}
	}

	public void validateFieldValues(String value)
	{
		switch (value.toLowerCase()) 
		{
		case "learner":
			wait.until(ExpectedConditions.visibilityOf(moreFilterLink));
			moreFilterLink.click();
			wait.until(ExpectedConditions.visibilityOf(userStatusDropdown));
			wait.until(ExpectedConditions.visibilityOf(userStatusDropdownDefault));
			String defaultValue = userStatusDropdownDefault.getText();
			Assert.assertEquals("active", defaultValue.toLowerCase().trim());
			break;

		default:
			break;
		}
		
	}
	
	public void applySearchFilter(String field, String value)
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		int m=0;
		switch (field.toLowerCase()) 
		{
		case "learner":
			
			applyMoreFilterUserStatusSelectAll();			
			val = js.executeScript("return document.readyState").toString();
			
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			String getValue  = driver.findElement(By.xpath(status +  "1]")).getText();
			Assert.assertTrue(getValue.equalsIgnoreCase(value));
			wait.until(ExpectedConditions.visibilityOf(moreFilterClearSearch));
			wait.until(ExpectedConditions.elementToBeClickable(moreFilterClearSearch));
			js.executeScript("arguments[0].click();", moreFilterClearSearch);
			val = js.executeScript("return document.readyState").toString();
			m=0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			
			break;

		case "assignment":
			applyCourseFilterSelectAll();
			val = js.executeScript("return document.readyState").toString();
			m=0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			getValue  = driver.findElement(By.xpath(course +  "1]")).getText().toLowerCase().trim();
			Assert.assertTrue(value.toLowerCase().trim().contains(getValue));
			wait.until(ExpectedConditions.visibilityOf(courseFilterClearSearch));
			wait.until(ExpectedConditions.elementToBeClickable(courseFilterClearSearch));
			js.executeScript("arguments[0].click();", courseFilterClearSearch);
			val = js.executeScript("return document.readyState").toString();
			m=0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			break;
			
		case "notification":
			int count = 0;
			wait.until(ExpectedConditions.visibilityOf(notificationLogLink));
			js.executeScript("arguments[0].click();", notificationLogLink);
			wait.until(ExpectedConditions.visibilityOf(notificationTitleDropdown));
			String nameList[] = {"3 consecutive failures by student","Assignment completed","Assignment Due date approaching",
					"Assignment not completed","assignment past due","certificate about to expire",
					"certificate renewed","demographic import failure",
					"forgot password", "learner promoted to unit admin/ observer", "new assignment available",
					"new unit admin/ observer", "new user added", "successful demographic import"};
			notificationTitleDropdown.click();
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(notificationList))));
			List<WebElement> notifList = driver.findElements(By.xpath(notificationList));
			Assert.assertTrue(notifList.size() == 14);
			for(int i = 1; i <= notifList.size(); i++)
			{
				String name = driver.findElement(By.xpath(notificationList + "[" + i + "]")).getAttribute("data-search-term").toLowerCase().trim();
				for (String element : nameList) 
				{
					if (element.trim().equalsIgnoreCase(name)) 
		            {
		                count = count + 1;
		                break;
		            }
		        }
				
			}
			Assert.assertTrue(count == 14);
			break;
		case "delivery":
			applyDeliveryStatusSentOption();
			val = js.executeScript("return document.readyState").toString();
			m=0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			getValue  = driver.findElement(By.xpath(deliveryStatus +  "1]")).getText().toLowerCase().trim();
			Assert.assertTrue(value.toLowerCase().trim().contains(getValue));
			wait.until(ExpectedConditions.visibilityOf(notificationLogClearSearch));
			wait.until(ExpectedConditions.elementToBeClickable(notificationLogClearSearch));
			js.executeScript("arguments[0].click();", notificationLogClearSearch);
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}
			break;
		case "multi delivery":
			applyDeliveryStatusMulitpleOption(value);
			val = js.executeScript("return document.readyState").toString();
			m=0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			getValue  = driver.findElement(By.xpath(deliveryStatus +  "1]")).getText().toLowerCase().trim();
			Assert.assertTrue(value.toLowerCase().trim().contains(getValue));
			wait.until(ExpectedConditions.visibilityOf(notificationLogClearSearch));
			wait.until(ExpectedConditions.elementToBeClickable(notificationLogClearSearch));
			js.executeScript("arguments[0].click();", notificationLogClearSearch);
			val = js.executeScript("return document.readyState").toString();
			m=0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			break;
		case "job title":
			applyMoreFilterJobTitleSelectAll();
			val = js.executeScript("return document.readyState").toString();
			m=0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
				
			}
			getValue  = driver.findElement(By.xpath(jobTitle +  "1]")).getText().toLowerCase().trim();
			System.out.println(getValue);
			Assert.assertTrue(getValue.toLowerCase().startsWith(value.toLowerCase()));
			wait.until(ExpectedConditions.visibilityOf(moreFilterClearSearch));
			wait.until(ExpectedConditions.elementToBeClickable(moreFilterClearSearch));
			js.executeScript("arguments[0].click();", moreFilterClearSearch);
			//clearSearchLink.click();
			val = js.executeScript("return document.readyState").toString();
			m=0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			break;
		case "group":
			applyMoreFilterGroupSelectAll();
			val = js.executeScript("return document.readyState").toString();
			m=0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			getValue  = driver.findElement(By.xpath(id +  "1]")).getText().toLowerCase().trim();
			System.out.println(getValue);
			System.out.println(User.userId);
			Assert.assertTrue(getValue.equalsIgnoreCase(User.userId));
			wait.until(ExpectedConditions.visibilityOf(moreFilterClearSearch));
			wait.until(ExpectedConditions.elementToBeClickable(moreFilterClearSearch));
			js.executeScript("arguments[0].click();", moreFilterClearSearch);
			val = js.executeScript("return document.readyState").toString();
			m=0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			break;
		case "group and title":
			applyMoreFilterGroupTitleSelectAll();
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}
			getValue  = driver.findElement(By.xpath(id +  "1]")).getText().toLowerCase().trim();
			System.out.println(getValue);
			System.out.println(User.userId);
			Assert.assertTrue(getValue.equalsIgnoreCase(User.userId));
			wait.until(ExpectedConditions.visibilityOf(moreFilterClearSearch));
			wait.until(ExpectedConditions.elementToBeClickable(moreFilterClearSearch));
			js.executeScript("arguments[0].click();", moreFilterClearSearch);
			//clearSearchLink.click();
			val = js.executeScript("return document.readyState").toString();
			m=0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			break;
		default:
			break;
		}
	}

	public void applyMoreFilterUserStatusSelectAll()
	{
		try
		{
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			wait.until(ExpectedConditions.visibilityOf(moreFilterLink));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", moreFilterLink);
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(userStatusDropdown));
			userStatusDropdown.click();
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(selectAllFilter));
			Thread.sleep(2000);
			selectAllFilter.click();
			wait.until(ExpectedConditions.visibilityOf(moreFilterSearchButton));
			Thread.sleep(2000);
			moreFilterSearchButton.click();
			Thread.sleep(3000);
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void applyMoreFilterJobTitleSelectAll()
	{
		try
		{
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			wait.until(ExpectedConditions.visibilityOf(moreFilterLink));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", moreFilterLink);
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(jobTitleDropdown));
			jobTitleDropdown.click();
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(jobTitleSelectAllFilter));
			Thread.sleep(2000);
			jobTitleSelectAllFilter.click();
			wait.until(ExpectedConditions.visibilityOf(moreFilterSearchButton));
			Thread.sleep(2000);
			moreFilterSearchButton.click();
			Thread.sleep(3000);
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	
	public void applyMoreFilterGroupSelectAll()
	{
		try
		{
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			wait.until(ExpectedConditions.visibilityOf(moreFilterLink));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", moreFilterLink);
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(groupDropdown));
			groupDropdown.click();
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(groupSelectAllFilter));
			Thread.sleep(2000);
			groupSelectAllFilter.click();
			wait.until(ExpectedConditions.visibilityOf(moreFilterSearchButton));
			Thread.sleep(2000);
			moreFilterSearchButton.click();
			Thread.sleep(3000);
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	
	public void applyMoreFilterGroupTitleSelectAll()
	{
		try
		{
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			wait.until(ExpectedConditions.visibilityOf(moreFilterLink));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", moreFilterLink);
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(groupDropdown));
			groupDropdown.click();
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(groupSelectAllFilter));
			Thread.sleep(2000);
			groupSelectAllFilter.click();
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(jobTitleDropdown));
			jobTitleDropdown.click();
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(jobTitleSelectAllFilter));
			Thread.sleep(2000);
			jobTitleSelectAllFilter.click();
			wait.until(ExpectedConditions.visibilityOf(moreFilterSearchButton));
			Thread.sleep(2000);
			moreFilterSearchButton.click();
			Thread.sleep(3000);
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());	
		}
	}
	
	public void applyCourseFilterSelectAll()
	{
		try
		{
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			wait.until(ExpectedConditions.visibilityOf(courseFilterLink));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", courseFilterLink);
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(courseDropdown));
			courseDropdown.click();
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(courseSelectAllFilter));
			Thread.sleep(2000);
			courseSelectAllFilter.click();
			wait.until(ExpectedConditions.visibilityOf(courseFilterSearchButton));
			Thread.sleep(2000);
			courseFilterSearchButton.click();
			Thread.sleep(3000);
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());	
		}
	}
	
	public void selectCourseName(String name)
	{
		try
		{
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			wait.until(ExpectedConditions.visibilityOf(courseFilterLink));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", courseFilterLink);
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(courseDropdown));
			courseDropdown.click();
			Thread.sleep(2000);
			String options[] = name.trim().split(",");
			List<WebElement> optionAvailable = driver.findElements(By.xpath(courseOption));
			for(int i = 1; i <= optionAvailable.size(); i++)
			{
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(courseOption))));
				String getOption = driver.findElement(By.xpath(courseOption + "[" + i + "]/label")).getText().trim().toLowerCase();
				for(int j = 0; j <= options.length-1; j++)
				{
					if(options[j].toLowerCase().contains(getOption))
					{
						Thread.sleep(2000);
						driver.findElement(By.xpath(courseOption + "[" + i + "]/label")).click();
					}
				}
				
				
			}
			wait.until(ExpectedConditions.visibilityOf(courseFilterSearchButton));
			Thread.sleep(2000);
			courseFilterSearchButton.click();
			Thread.sleep(3000);
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void applyDeliveryStatusSentOption()
	{
		try
		{
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			wait.until(ExpectedConditions.visibilityOf(notificationLogLink));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", notificationLogLink);
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(deliveryStatusDropdown));
			deliveryStatusDropdown.click();
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(deliverySelectAllFilter));
			Thread.sleep(2000);
			deliverySelectAllFilter.click();
			wait.until(ExpectedConditions.visibilityOf(deliveryStatusSentOption));
			Thread.sleep(2000);
			deliveryStatusSentOption.click();
			wait.until(ExpectedConditions.visibilityOf(deliveryStatusSearchButton));
			Thread.sleep(2000);
			deliveryStatusSearchButton.click();
			Thread.sleep(3000);
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());	
		}
	}

	public void applyDeliveryStatusMulitpleOption(String value)
	{
		try
		{
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			wait.until(ExpectedConditions.visibilityOf(notificationLogLink));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", notificationLogLink);
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(deliveryStatusDropdown));
			deliveryStatusDropdown.click();
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(deliverySelectAllFilter));
			Thread.sleep(2000);
			deliverySelectAllFilter.click();
			String options[] = value.trim().split(",");
			List<WebElement> optionAvailable = driver.findElements(By.xpath(deliverOption));
			for(int i = 1; i <= optionAvailable.size(); i++)
			{
				wait.until(ExpectedConditions.visibilityOf(deliveryStatusSentOption));
				String getOption = driver.findElement(By.xpath(deliverOption + "[" + i + "]/label")).getText().trim().toLowerCase();
				for(int j = 0; j <= options.length-1; j++)
				{
					if(getOption.equals(options[j]))
					{
						Thread.sleep(2000);
						driver.findElement(By.xpath(deliverOption + "[" + i + "]/label")).click();
					}
				}
				
				
			}
			wait.until(ExpectedConditions.visibilityOf(deliveryStatusSearchButton));
			Thread.sleep(2000);
			deliveryStatusSearchButton.click();
			Thread.sleep(3000);
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void validateSortingLastColum()
	{
		String val = pageLoad.getAttribute("class");
		while(val.contains("loading_compliance loading"))
		{
			val = pageLoad.getAttribute("class");
		}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(row + "/td[3]"))));
		ArrayList<String> obtainedList = new ArrayList<>(); 
		List<WebElement> elementList= driver.findElements(By.xpath(row + "/td[3]"));
		for(WebElement we:elementList)
		{
		   obtainedList.add(we.getText());
		}
		ArrayList<String> sortedList = new ArrayList<>();   
		for(String s:obtainedList){
		sortedList.add(s);
		}
		Collections.sort(sortedList);
		Assert.assertTrue(sortedList.equals(obtainedList));
	}

	public void selectFieldValue(String field, String value)
	{
		switch (field.toLowerCase()) 
		{
		case "delivery":
			applyDeliveryStatusMulitpleOption(value);
			break;
		case "assignment":
			selectCourseName(value);
			break;
		default:
			break;
		}
	}

	public void getTableRowCount(String value)
	{
		wait.until(ExpectedConditions.visibilityOf(searchResult));
		String val = searchResult.getText();
		System.out.println(val);
		switch (value.toLowerCase()) 
		{
		case "0":
			Assert.assertTrue(val.contains("Showing 0 to 0 of 0 entries"));
			break;
		case "1":
			Assert.assertFalse(val.contains("Showing 0 to 0 of 0 entries"));
			break;
		case "3":
			Assert.assertTrue(val.contains("Showing 1 to 3 of 3 entries"));
			break;	
		default:
			break;
		}
		
	}
	
	public void clearSearchResult(String field)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		switch (field.toLowerCase()) 
		{
		case "delivery":
			wait.until(ExpectedConditions.visibilityOf(notificationLogClearSearch));
			wait.until(ExpectedConditions.elementToBeClickable(notificationLogClearSearch));
			js.executeScript("arguments[0].click();", notificationLogClearSearch);
			val = js.executeScript("return document.readyState").toString();
			int m=0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			break;
		default:
			break;
		}
	}

	public void validateNoSearchResult()
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(row))));
		String value = driver.findElement(By.xpath(row)).getText();
		Assert.assertTrue(value.equalsIgnoreCase("No reports data found."));
	}

	public void validateTableFields()
	{
		int count = 0;
		JavascriptExecutor js = (JavascriptExecutor)driver;
		String nameList[] = {"User Id", "First name", "Last name", "Notification Title", "course", "Delivery Timestamp", 
				"Delivery status", "Admin resent", "User Status", "Unit Level", "Unit Name", "Job Title", "Email"};
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(searchTable + "[2]"))));
		List<WebElement> headerList = driver.findElements(By.xpath(searchTable));
		for(int i = 2; i <= headerList.size(); i++)
		{
			try
			{
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(searchTable + "[" + i + "]"))));
			}
			catch(Exception e)
			{
				WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
				js.executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", scrollArea);
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(searchTable + "[" + i + "]"))));
			}
			String columName = driver.findElement(By.xpath(searchTable + "[" + i + "]")).getText();
			for (String element : nameList) 
			{
				if (element.trim().equalsIgnoreCase(columName)) 
	            {
	                count = count + 1;
	                break;
	            }
	        }
		}
		Assert.assertTrue(count == 13);
	}

	public void validateSortingEachColumn()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		for(int i = 2; i <= 14; i++)
		{
			ArrayList<String> obtainedList = new ArrayList<>(); 
			WebElement column = driver.findElement(By.xpath(searchTable + "[" + i + "]"));
			try
			{
				wait.until(ExpectedConditions.elementToBeClickable(column));
			}
			catch(Exception e)
			{
				WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
				js.executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", scrollArea);
				wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(searchTable + "[" + i + "]"))));
			}
			js.executeScript("arguments[0].click()", column);
			val = pageLoad.getAttribute("class");
			int m=0;
			while(val.toLowerCase().contains("loading"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			List<WebElement> elementList= driver.findElements(By.xpath(row + "/td[" + i + "]"));
			for(WebElement we:elementList)
			{
			   obtainedList.add(we.getText());
			}
			ArrayList<String> sortedList = new ArrayList<>();   
			for(String s:obtainedList){
			sortedList.add(s);
			}
			Collections.sort(sortedList);
			
			System.out.println("Sorted list"+sortedList.toString());
			System.out.println("Obtainted list"+obtainedList);
			
			
			Assert.assertTrue(sortedList.equals(obtainedList));
			
			js.executeScript("arguments[0].click()", column);
			obtainedList.removeAll(obtainedList);
			val = pageLoad.getAttribute("class");
			m=0;
			while(val.toLowerCase().contains("loading"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			elementList= driver.findElements(By.xpath(row + "/td[" + i + "]"));
			for(WebElement we:elementList)
			{
			   obtainedList.add(we.getText());
			}
			Collections.reverse(sortedList);
			Assert.assertTrue(sortedList.equals(obtainedList));
			
		}
		
		
		
	}

	public void validateRowPerPage()
	{
		wait.until(ExpectedConditions.elementToBeClickable(rowsDropdown));
		Select select = new Select(rowsDropdown);
		String value = select.getFirstSelectedOption().getText();
		int rowCount = Integer.parseInt(value);
		List<WebElement> elementList= driver.findElements(By.xpath(row));
		int actualCount = elementList.size();
		Assert.assertTrue(actualCount <= rowCount);
	}

	public int totalRowsAvailable()
	{
		int number = 0;
		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(row))));
		List<WebElement> elementList= driver.findElements(By.xpath(row));
		number = elementList.size();
		return number;
	}
	
	public void validateTheRowCount(int count)
	{
		int number = 0;
		JavascriptExecutor js = (JavascriptExecutor)driver;
		val = js.executeScript("return document.readyState").toString();
		int m=0;
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			m++;
		}

		User usr=new User();
		try
		{
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		m=0;
		val = pageLoad.getAttribute("class");
		while(val.toLowerCase().contains("loading"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
			usr.usersearchEmail(usr.userEmail);
		
			try
			{
			Thread.sleep(5000);
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(row))));
		List<WebElement> elementList= driver.findElements(By.xpath("//table[contains(@id,'reports')]//tbody//tr//td[text()='"+User.userEmail+"']"));
		number = elementList.size();
		Assert.assertTrue(number == count);
		
	}
	
	public void validateTheRwCount(int count)
	{
		int number = 0;
		WebDriverWait wait = new WebDriverWait(driver, 10);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		val = js.executeScript("return document.readyState").toString();
		int m=0;
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			m++;
		}
		try
		{
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		val = pageLoad.getAttribute("class");
		m=0;
		while(val.toLowerCase().contains("loading"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(row))));
		List<WebElement> elementList= driver.findElements(By.xpath("//table[contains(@id,'reports')]//tbody//tr"));
		number = elementList.size();
		Assert.assertTrue(number == count);
		
	}

	public void validatePaginationNotificationLog()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		
		wait.until(ExpectedConditions.visibilityOf(nextPageButton));
		nextPageButton.click();
		if(wait.until(ExpectedConditions.stalenessOf(driver.findElement(By.xpath(row + "[1]")))))
		{
			wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(row))));
		}
		List<WebElement> elementList= driver.findElements(By.xpath(row));
		int number = elementList.size();
		Assert.assertTrue(number > 0);
		
	}
	
	public void validateDisbaledResendButton()
	{
		wait.until(ExpectedConditions.visibilityOf(resendButton));
		String val = resendButton.getAttribute("disabled");
		Assert.assertTrue(val.equalsIgnoreCase("true"));
	}

	public void selectRows(int count)
	{
		try {
			JavascriptExecutor js = (JavascriptExecutor)driver;
			val = js.executeScript("return document.readyState").toString();
			int m=0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(row))));
			for(int i= 1; i <= count; i++)
			{
				wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(row))));
				WebElement elem = driver.findElement(By.xpath(tableLeftWrapper + "[" + i + "]/td[1]//input"));
				js.executeScript("arguments[0].click();", elem);
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}

	public void selectGivenRow(int number)
	{
		try {
			JavascriptExecutor js = (JavascriptExecutor)driver;
			val = js.executeScript("return document.readyState").toString();
			int m=0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(row))));
			WebElement elem = driver.findElement(By.xpath(tableLeftWrapper + "[" + number + "]/td[1]//input"));
			js.executeScript("arguments[0].click();", elem);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	public void validateEnabledResendButton()
	{
		wait.until(ExpectedConditions.visibilityOf(resendButton));
		String val = resendButton.getAttribute("disabled");
		Assert.assertTrue(val == null);
	}

	public void clickOnResendButton()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(resendButton));
		resendButton.click();
	}
	public void selectallnotifforresend() throws InterruptedException
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(selectallnotif));
		wait.until(ExpectedConditions.elementToBeClickable(selectallnotif));
		Thread.sleep(5000);
		selectallnotif.click();
	}
	public void verifyResendPopup()
	{
		wait.until(ExpectedConditions.visibilityOf(resendPopupText));
		String text = resendPopupText.getText();
		Assert.assertTrue(text.equalsIgnoreCase(resendPopupActualText));
		wait.until(ExpectedConditions.visibilityOf(resendPopupCancelButton));
		text = resendPopupCancelButton.getText();
		Assert.assertTrue(text.equalsIgnoreCase("Cancel"));
		wait.until(ExpectedConditions.visibilityOf(resendPopupConfirmButton));
		text = resendPopupConfirmButton.getText();
		Assert.assertTrue(text.equalsIgnoreCase("Resend"));
	}
	
	public void clickOnResendConfirmButton()
	{
		wait.until(ExpectedConditions.visibilityOf(resendPopupConfirmButton));
		resendPopupConfirmButton.click();
	}
	
	public void validateNotificationWithRow(String value, int row)
	{

		if(AssignmentReport.checkifParmeterAvailable(value))
			value=AssignmentReport.getParmeterAvailable(value);
     
		WebDriverWait wait = new WebDriverWait(driver, 20);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		val = js.executeScript("return document.readyState").toString();
		int m=0;
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			m++;
		}
		try
		{
					
		if(wait.until(ExpectedConditions.stalenessOf(driver.findElement(By.xpath(notification + row + "]")))))
		{
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(notification + row + "]"))));
		}
		}
		catch(Exception e)
		{
			e.getMessage();
		}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String text = driver.findElement(By.xpath(notification + row + "]")).getText();
		Assert.assertEquals(value.toLowerCase().trim(), text.toLowerCase().trim());
	}
	public void validateNotificationWithRow(String value)
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		val = js.executeScript("return document.readyState").toString();
		int m=0;
		Boolean flag=false;
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
			try
			{
				 driver.findElement(By.xpath(reportTable + "[1]/td[14]")).getText();
				 wait.until(ExpectedConditions.stalenessOf(driver.findElement(By.xpath(reportTable + "[1]/td[14]"))));
			}
			catch(Exception e)
			{
				
			}
			if(m==pagload)
				break;
			m++;
		}

		try
		{

			driver.findElements(By.xpath(reportTable+"//td[text()='"+User.userEmail+"']"));
			int rowCount=0;
			int cont=0;
			while(rowCount==0)
			{
				List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
				rowCount = tableRows.size();
				if(cont==250)
					break;

				cont++;
			}

			System.out.println("Row Size"+rowCount);
			System.out.println("Value "+value);
			System.out.println("USer mail"+User.userEmail);

			for (int i= 1; i<= rowCount; i++)
			{
				String curriculum = reportTable + "[" + i + "]/td[5]";
				String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
				String Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[14]")).getText();
				System.out.println(curriculum);
				System.out.println(Email);
				
				if(value.toLowerCase().contains(curricuclumText.toLowerCase())&&Email.contains(User.userEmail))
				{
					flag = true;
					String data = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[8]")).getText();
					Assert.assertTrue(data.equalsIgnoreCase("Sent"));
					break;
				}
			}

			Assert.assertTrue(flag);
		}
		catch(StaleElementReferenceException e)
		{
			validateNotificationWithRow(value);
			
		}
		catch(Exception e)
		{
			Assert.fail(value);
			
		}
	}
	
	
	public void validateNotificationWithRow(String course,String notifTitle)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
	
		WebDriverWait wait = new WebDriverWait(driver, 20);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		val = js.executeScript("return document.readyState").toString();
		int m=0;
		Boolean flag=false;
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
			try
			{
				 driver.findElement(By.xpath(reportTable + "[1]/td[14]")).getText();
				 wait.until(ExpectedConditions.stalenessOf(driver.findElement(By.xpath(reportTable + "[1]/td[14]"))));
			}
			catch(Exception e)
			{
				
			}
			if(m==pagload)
				break;
			m++;
		}

		try
		{

			driver.findElements(By.xpath(reportTable+"//td[text()='"+User.userEmail+"']"));
			int rowCount=0;
			int cont=0;
			while(rowCount==0)
			{
				List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
				rowCount = tableRows.size();
				if(cont==150)
					break;

				cont++;
			}

			System.out.println("Row Size"+rowCount);
			System.out.println("Value "+course);
			System.out.println("USer mail"+User.userEmail);

			for (int i= 1; i<= rowCount; i++)
			{
				String curriculum = reportTable + "[" + i + "]/td[6]";
				
				
				String curricuclumText = driver.findElement(By.xpath(curriculum)).getText();
				String Email = driver.findElement(By.xpath(reportTable + "[" + i + "]/td[14]")).getText();
				String notificationTitle =driver.findElement(By.xpath(reportTable + "[" + i + "]/td[5]")).getText();
				
				if(course.toLowerCase().contains(curricuclumText.toLowerCase())&&Email.contains(User.userEmail)&&notificationTitle.contains(notifTitle))
				{
					flag = true;
					Assert.assertTrue(notificationTitle.equalsIgnoreCase(notifTitle));
					break;
					
				}
			}

			Assert.assertTrue(flag);
		}
		catch(StaleElementReferenceException e)
		{
			validateNotificationWithRow(course,notifTitle);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail("Issues with Application");
		}
	
	}

	public void validateResentWithRow(String value, int row)
	{
		WebDriverWait wait = new WebDriverWait(driver, 10);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		val = js.executeScript("return document.readyState").toString();
		System.out.println(val);
		int m=0;
		while(!(val.equalsIgnoreCase("complete")))
		{
			System.out.println(val);
			val = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			m++;
		}
		try
		{
        
		if(wait.until(ExpectedConditions.stalenessOf(driver.findElement(By.xpath(resent + row + "]")))))
		{
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(resent + row + "]"))));
		}
		}
		catch(Exception e)
		{
			WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
			js.executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", scrollArea);
		}
		String text = driver.findElement(By.xpath(resent + row + "]")).getText();
		Assert.assertEquals(value.toLowerCase().trim(), text.toLowerCase().trim());
	}
	
	public void disableCheckbox()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		applyMoreFilterUserStatusSelectAll();			
		val = js.executeScript("return document.readyState").toString();
	int	m=0;
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			m++;
		}
		try
		{
		if(wait.until(ExpectedConditions.stalenessOf(driver.findElement(By.xpath(firstName +  "1]")))))
		{
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(firstName +  "1]"))));
		}
		}
		catch(Exception e)
		{
		
		}
		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(row))));
		List<WebElement> rows = driver.findElements(By.xpath(row));
		for(int i = 1; i <= rows.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath(tableLeftWrapper + "[" + i + "]/td[1]//input"));
			String val = elem.getAttribute("disabled");
			Assert.assertTrue(val.equalsIgnoreCase("true"));
		}		
	}	
	public void validaterow(int row)
    {
    int cont=0;
        int rowCount=0;
        while(row!=rowCount)
        {
        try
        {
            Thread.sleep(250);
            List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
            rowCount = tableRows.size();
        //    System.out.println(rowCount);
        }
        catch (Exception e) {
            // TODO: handle exception
        }
         if(cont==650)
             break;
         
         cont++;
        }
        
    }
	
	public void navigateNotificationTab()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(notificationTabLink));
		notificationTabLink.click();
		wait.until(ExpectedConditions.visibilityOf(notificationTabHeading));
	}
	public void clickMoreFilterClearSearch()
	{
		try 
		{
//			navigateUserModule();
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
			}
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(clearSearchLink));
			clickMoreFilter();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.elementToBeClickable(moreFilterClearSearch));
			moreFilterClearSearch.click();
			js = (JavascriptExecutor)driver;
			pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(3000);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	public void clickMoreFilter()
	{
		try
		{
			Thread.sleep(2000);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(moreFilter));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", moreFilter);
			Thread.sleep(2000);
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	public void clickcoursefilterslide() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(coursefiltersnotif));	
	coursefiltersnotif.click();
		
	}
	
	public void clickCourseFilter()
	{
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(courseFilterLink));
			courseFilterLink.click();	
			JavascriptExecutor js = (JavascriptExecutor)driver;
			val = js.executeScript("return document.readyState").toString();
			int counter = 0;
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void clickOnCourseFilterSearchButton()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(courseFilterSearchButton));
		courseFilterSearchButton.click();
	}

	public void searchCourseFilter(String courseName)
	{
		if(courseListName.containsKey(courseName+"Option"))
			courseName=courseListName.get(courseName+"Option").toString();

		if(AssignmentReport. checkifParmeterAvailable(courseName))
			courseName=AssignmentReport.getParmeterAvailable(courseName);

		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(courseFilterFilterSearch));
			int counter = 0;
			courseFilterFilterSearch.click();
			courseFilterFilterSearch.clear();
			courseFilterFilterSearch.sendKeys(courseName);
			List<WebElement> statusList = driver.findElements(By.xpath(userCourseFilter + "/parent::li[not(contains(@class,'hidden'))]"));
			while(statusList.size() > 1)
			{
				statusList = driver.findElements(By.xpath(userCourseFilter + "/parent::li[not(contains(@class,'hidden'))]"));
				Thread.sleep(2000);
				if(counter > 12)
					Assert.fail("Search functionality for user status is not working");
				counter++;
			}
			driver.findElement(By.xpath(userCourseFilter + "//input[contains(@title,'" + courseName + "')]")).click();
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}

	}

	public void validateCourseNameFilterFilterAvailability()
	{
		try{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(courseNameFilter));
			courseNameFilter.click();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}


	
}
