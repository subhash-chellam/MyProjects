package com.qa.pages;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.json.simple.JSONArray;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.python.modules.thread.thread;

import com.mysql.cj.jdbc.Driver;
import com.qa.util.TestBase;
import com.qa.util.reuseableCode;

import junit.framework.Assert;

public class ZimbraOps extends TestBase
{
	@FindBy(xpath = "//input[@id = 'ZLoginUserName']")
	WebElement zadminUserName;
	
	@FindBy(xpath = "//input[@id = 'ZLoginPassword']")
	WebElement zadminUserpwd;
	
	@FindBy(xpath = "//*[@id='ZLoginButton']")
	WebElement zadminLoginbtn;

	@FindBy(xpath = "//*[@id=\"ztabv__HOMEV_output_14\"]/div")
	WebElement zaddAccount;
	
	@FindBy(xpath = "//*[@id=\"zdlgv__NEW_ACCT_name_2\"]")
	WebElement znewUserMail;
	
	@FindBy(xpath= "//*[@id=\"zdlgv__NEW_ACCT_name_3_display\"]")
	WebElement zMailDomain;
	
	@FindBy(xpath = "//*[@id=\"zdlgv__NEW_ACCT_sn\"]")
	WebElement znewUserLname;
	
	@FindBy(xpath = "//*[@id=\"zdlgv__NEW_ACCT_password\"]")
	WebElement znewUserPwd;
	
	@FindBy(xpath = "//*[@id=\"zdlgv__NEW_ACCT_confirmPassword\"]")
	WebElement znewUserCPwd;

	@FindBy(xpath = "//*[@id=\"zdlg__NEW_ACCT_button13_title\"]")
	WebElement znewUserFinish;
	
	@FindBy(xpath = "//*[@id=\"zdlg__ERR_title\"]")
	WebElement znewUserAddError;
	
	@FindBy(xpath = "//*[@id=\"z_toast\"]")
	WebElement znewUserSuccess;
	
	@FindBy(xpath = "//*[@id=\"username\"]")
	WebElement zuserName;
	
	@FindBy(xpath = "//*[@id=\"password\"]")
	WebElement zuserPwd;	
	
	@FindBy(xpath = "//table/tbody/tr[3]/td[2]/input[2]")
	WebElement zuserLogin;	
	
	@FindBy(xpath = "//*[@id=\"zi_search_inputfield\"]")
	WebElement zmailSearchtext;	
	
	@FindBy(xpath = "//*[@id=\"zb__Search__SEARCH_left_icon\"]/div")
	WebElement zmailSearchbtn;	
	
	@FindBy(xpath = "//*[@id=\"zb__App__Mail_title\"]")
	WebElement zmenuMail;	
	
	@FindBy(xpath = "//*[@id=\"DWT29_dropdown\"]")
	WebElement zmenuUserOptions;	
	
	@FindBy(xpath = "//*[@id=\"zl__CLV-main__rows\"]/div/table/tbody/tr/td")
	WebElement zNoRecords;
	
	@FindBy(xpath = "//*[@id=\"zv__CLV-main__CV__header_subject\"]")
	WebElement zMailSubject;
	
	@FindBy(xpath = "//a[text() = 'click here']")
	WebElement zMailLink;
	
	public Select zuserMenu;

	
	public ZimbraOps() 
	{
		PageFactory.initElements(driver, this);
	}
	public void navigateZimbraAdmin()
	{
		driver.get(prop.getProperty("ZambraAdminurl"));
	}
	
	public void zadminLogin() {
		WebDriverWait wait = new WebDriverWait(driver, 60);
		try {
			wait.until(ExpectedConditions.visibilityOf(zadminUserName));
			zadminUserName.sendKeys(prop.getProperty("ZambraAdminid"));
			zadminUserpwd.sendKeys(prop.getProperty("ZambraAdminpwd"));
			zadminLoginbtn.click();
		}
		catch(Exception e) {
			
		}
	}
	
	public void zaddAccount(String userMail,String lname, String password)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		try {
			wait.until(ExpectedConditions.visibilityOf(zaddAccount));
			zaddAccount.click();
			wait.until(ExpectedConditions.visibilityOf(znewUserMail));
			znewUserMail.sendKeys(userMail);
			Thread.sleep(3000);

			wait.until(ExpectedConditions.visibilityOf(zMailDomain));

			zMailDomain.click();
			zMailDomain.clear();
			zMailDomain.sendKeys("rqimail.laerdalblr.in");
			wait.until(ExpectedConditions.visibilityOf(znewUserLname));
			Thread.sleep(3000);

			znewUserLname.click();
			znewUserLname.sendKeys("test");
			wait.until(ExpectedConditions.visibilityOf(znewUserPwd));
			Thread.sleep(3000);

			znewUserPwd.sendKeys(password);
			Thread.sleep(3000);

			znewUserCPwd.sendKeys(password);
			znewUserCPwd.clear();
			znewUserCPwd.sendKeys(password);
			Thread.sleep(3000);
			Thread.sleep(1000);
			wait.until(ExpectedConditions.elementToBeClickable(znewUserFinish));

			znewUserFinish.click();
			Thread.sleep(3000);

			wait.until(ExpectedConditions.visibilityOf(znewUserSuccess));

			Assert.assertTrue(znewUserSuccess.isDisplayed());
			Thread.sleep(5000);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void zaddAccount() {
		int userCount = Integer.parseInt(prop.getProperty("ZambraUsersCount"));
		JSONArray userDetails = new JSONArray();
		reuseableCode rc = new reuseableCode();
		String userEmail = null;
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		for (int i=1;i<=userCount;i++) {
			
			zaddAccount("user"+Integer.toString(i),Integer.toString(i),"Laerdal@2023");
			userEmail="user"+Integer.toString(i);
			userDetails.add(userEmail+"@rqimail.laerdalblr.in");
			
		}
		rc.createJsonFile(userDetails,"userDetails","MailUsers2");
	}
	
	public void navigateZimbraUser()
	{
		driver.get(prop.getProperty("ZambraUserurl"));
	}
	
	public void zuserLogin(String userName, String password) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		try {
			wait.until(ExpectedConditions.visibilityOf(zuserName));
			zuserName.sendKeys(userName);
			zuserPwd.sendKeys(password);
			Thread.sleep(1000);
			zuserLogin.click();
		}
		catch(Exception e) {
		
	}
	}
	
	public void zchangePassword() {
		WebDriverWait wait = new WebDriverWait(driver, 60);
		try {
			wait.until(ExpectedConditions.visibilityOf(zmenuUserOptions));
			zmenuUserOptions.click();
			zuserMenu = new Select(zmenuUserOptions);
			zuserMenu.selectByVisibleText("Change Password");

		}
		catch(Exception e) {
	}
	}
	
	public void zCheckMailCount(String validateString) 
	{
		
		String mailTable1 = "zl__CLV-main__rows\"";
		WebDriverWait wait = new WebDriverWait(driver, 60);
		try {
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"DWT6\"]"))));
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("zl__CLV-main__rows"))));
		    WebElement mailTable = driver.findElement(By.id("zl__CLV-main__rows"));
		    List<WebElement> mailList = mailTable.findElements(By.xpath("//li"));
		    System.out.println("List size is: " + mailList.size());
		    System.out.println("maillist" + mailList.get(0));
		    System.out.println("Content" + mailTable.getText());
		    
		    for(int i=0;i<mailList.size();i++) {
		    	if (!(mailList.get(i).getText().toLowerCase().contains("no results")))
		    	{
		    		if (mailList.get(i).getText().toLowerCase().contains(validateString)) {
		    			mailList.get(i).click();
		    			wait.until(ExpectedConditions.visibilityOf(zMailSubject));
		    			System.out.println("Mail Body Subject : " + zMailSubject.getText());
		    			System.out.println("Body Click" + driver.findElement(By.xpath("//*[@class=\"MsgBody MsgBody-html\"]")).getText());
		    			Thread.sleep(10000);
		    			driver.findElement(By.xpath("//*[@class=\"MsgBody MsgBody-html\"]/div/p[4]/a")).click();
		    		//	System.out.println("Link text :" + driver.findElement(By.xpath("//*[contains(@id,'_com_zimbra_url')]//a[text()='Click here']")).getText());
		    		//	driver.findElement(By.xpath("//*[contains(@id,'_com_zimbra_url')]//a[text()='Click here']")).click();
		    		//	JavascriptExecutor js = (JavascriptExecutor)driver;
		    		//    js.executeScript("arguments[0].click();", zMailLink);
		    		    driver.switchTo().alert().accept();
		    		}
		    	} 
		    	System.out.println("List item " + i + " = " + mailList.get(0).getText());
		    }

 		}
		catch(Exception e) {
		}
		
	}
}