package com.qa.pages;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.logging.FileHandler;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import org.apache.batik.w3c.dom.events.KeyboardEvent;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.python.modules.thread.thread;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.qa.util.TestBase;


public class User extends TestBase
{

	@FindBy(xpath = "//a[text() = 'Users']")
	WebElement userLink;
	
	@FindBy(xpath = "(//*[@id='productInner']/tr/td//a)[1]")
	WebElement actionDrop;
	
	
	@FindBy(xpath="//div[@id='job_select']//div//button")
	WebElement jobtitlfilter;
	
	@FindBy(xpath = "//*[@id=\"accordion\"]/div/div[1]/a")
	WebElement morefilter;
	
	@FindBy(xpath = "//*[@id=\"ms-list-3\"]/button/span")
	WebElement userStatus;
	
	
	
	@FindBy(xpath = "//*[@id=\"learnerTableList\"]/tbody/tr/td[text()='Inactive']//following::td/div")
	WebElement inactiveuser;
	
	@FindBy(xpath = "//a[contains(text(), 'Create User')]")
	WebElement createUserButton;
	
	
	@FindBy(xpath = "//a[text() = 'Choose file']")
	WebElement chooseFileLink;
	
	@FindBy(xpath = "//a[@id = 'selFile']")
	WebElement uploadedFile;
	
	@FindBy(xpath = "//input[@id = 'first_name']")
	WebElement firstNameText;
	
	@FindBy(xpath = "//input[@id = 'last_name']")
	WebElement lastNameText;
	
	@FindBy(xpath = "//input[@id = 'unique_id']")
	WebElement userIdText;
	
	@FindBy(xpath = "//input[@id = 'email']")
	WebElement userEmailText;
	
	@FindBy(xpath = "//button[@class = 'btn btn-default red_btn_big']")
	WebElement submitButton;
	
	@FindBy(xpath = "//button[@class='btn btn-default  red_btn']")
	WebElement submitBtn;
	
	@FindBy(xpath = "//a[@class = 'action_dropdown']")
	WebElement actionDetails;
	
	
	@FindBy(xpath = "//a[@modal-title = 'Unenroll All Recurrences']")
	WebElement unenrollAllRecurrence;

	@FindBy(xpath = "//*[@id='common-btn-unenroll']")
	WebElement unenrollCourseDeleteYes;

	
	@FindBy(xpath = "//a[text() = 'Edit Assignment']")
	WebElement editAssignment;
	
	@FindBy(xpath = "//*[@id=\"customerform\"]//div[2]/a[contains(text(),'Add')]")
	WebElement add;
	
	@FindBy(xpath = "//tr[1]//a[@class = 'action_dropdown']")
	WebElement actionDetail;
	
	@FindBy(xpath = "//a[contains(text() , 'View User Details')]")
	WebElement viewDetails;
	
	@FindBy(xpath = "//a[contains(text() , 'View Courses')]")
	WebElement viewCourses;
	
	@FindBy(xpath = "//a[contains(text() , 'Edit User Details')]")
	WebElement editDetails;
	

    @FindBy(xpath = "//label[text() = 'Email']/following-sibling::span")
	WebElement viewUserEmail;

	
	@FindBy(xpath = "//*[@id=\"addAssignPop\"]")
	WebElement addAssigment;
	
	@FindBy(xpath = "//a[contains(text() , 'Edit Details')]")
	WebElement editDetail;
	
	@FindBy(xpath = "//a[contains(text() , 'Delete User')]")
	WebElement deleteUser;

	@FindBy(xpath = "//button[text() = 'Yes']")
	WebElement deleteYesButton;
	
	@FindBy(xpath = "//td[text() = 'No records are present.']")
	WebElement noRecordPresent;
	
	@FindBy(xpath = "//a[contains(text() , 'Import Demographic Data')]")
	WebElement importDataLink;
	
	@FindBy(xpath = "//label[@id='inputSearch']")
	WebElement searchText;
	
	@FindBy(xpath = "//input[@type='search']")
	WebElement searchinputText;
	
	@FindBy(xpath = "//button[@id= 'searchbtn']")
	WebElement searchButton;
	
	@FindBy(xpath = "//*[@id='learnerTableList_info']")
	WebElement learnerTableList_info;
	
	@FindBy(xpath = "(//*[@class='dataTables_info'])[2]")
	WebElement showing1to1;
	
	@FindBy(xpath = "//*[@id='learnerTableList']/tbody/tr")
	 List<WebElement> row;
	
	@FindBy(xpath = "//*[@id='learnerTableList']/tbody/tr//td[2]")
	WebElement userIDField;
	
	
	
	@FindBy(xpath = "//div[@id]/a[text()= 'Clear Search']")
	WebElement searchClear;
	
	@FindBy(xpath = "//a[@data-target = '#unitdiv']")
	WebElement[] searchResultUnitName;
	
	@FindBy(xpath = "//table[@id = 'learnerTableList']//td[4]")
	WebElement searchResultFirstName;
	@FindBy(xpath = "(//a[text()= 'Clear Search'])[2]")
	WebElement moreFilterClearSearch;
	
	@FindBy(xpath = "//table[@id = 'learnerTableList']//td[2]")
	WebElement searchResultName;
	
	@FindBy(xpath = "//table[@id = 'learnerTableList']//td[3]")
	WebElement searchResultLastName;
	
	@FindBy(xpath = "//table[@id = 'learnerTableList']//td[3]")
	WebElement searchResultemail;
	
	@FindBy(xpath = "//table[@id = 'learnerTableList']//td[8]")
	WebElement searchResultUserStatus;
	
	@FindBy(xpath = "//table[@id = 'learnerTableList']//td[7]")
	WebElement searchResultUsersStatus;
	
	@FindBy(xpath = "//input[@id = 'first_name']")
	WebElement editFirstName;

	@FindBy(xpath = "(//input[@id = 'first_name'])[2]")
	WebElement editFirstNme;

	
	@FindBy(xpath = "//*[@id='middle_name']")
	WebElement middle_name;

	
	@FindBy(xpath = "//*[@id='phone']")
	WebElement phone;
	
	@FindBy(xpath = "//*[@id='customerform']//input[@name='years_of_experience']")
	WebElement years_of_experience;
	
	
	
	@FindBy(xpath = "//input[@id = 'last_name']")
	WebElement editLastName;
	
	@FindBy(xpath = "(//input[@id='email'])[2]")
	WebElement editEmail;
	
	@FindBy(xpath = "//input[@id='email']")
	WebElement editEmail1;
	
	@FindBy(xpath = "(//input[@id = 'last_name'])[2]")
	WebElement editLastNme;
	
	@FindBy(xpath = "//a[text() = 'Edit User Details']")
	WebElement editViewDetails;
	
	@FindBy(xpath = "//a[@class = 'card-link']")
	WebElement moreFilter;

	@FindBy(xpath = "//div[@class='dataTables_scroll']/div[1]/div/table/thead//th")
	List<WebElement> AssignmentColumns;
	
	@FindBy(xpath = "//select[@id = 'statusFilter']//following-sibling::div/button")
	WebElement userStatusFilter;
	
	@FindBy(xpath = "//select[@id = 'statusFilter']//following-sibling::div//a")
	WebElement selectAllFilter;
	
	@FindBy(xpath = "//label[contains(text(),'User Status')]/following-sibling::div//input[@type = 'text']")
	WebElement userStatusFilterSearchBar;
	
	@FindBy(xpath = "//select[@id = 'statusFilter']//following-sibling::div//li[@data-search-term = 'active']")
	WebElement userStatusFilterDefaultStatus;
	
	@FindBy(xpath = "//select[@id = 'statusFilter']//following-sibling::div//li[@data-search-term = 'active']")
	WebElement userStatusFilterActiveStatus;
	
	@FindBy(xpath = "//select[@id = 'statusFilter']//following-sibling::div//li[@data-search-term = 'active']")
	WebElement userStatusFilterInActiveStatus;
	
	@FindBy(xpath = "(//button[@value= 'Search'])[2]")
	WebElement moreFilterSearch;
	
	@FindBy(xpath = "//a[text() = 'Set as Inactive ']")
	WebElement setInactive;
	
	@FindBy(xpath = "//a[text() = 'Set as Active ']")
	WebElement setActive;
	
	@FindBy(xpath = "//a[text() = 'Add to Group ']")
	WebElement addToGroup;
	
	@FindBy(xpath = "//select[@name='group']")
	WebElement groupSelect;
	
	@FindBy(xpath = "//a[@id = 'addgroupsubmit']")
	WebElement addGroupButton;
	
	@FindBy(xpath = "//a[@class = 'dropdown-item addgroup']")
	WebElement addGroupForAll;
	@FindBy(xpath = "//select[@name = 'group']")
	WebElement selectGroupDrop;
	
	@FindBy(xpath = "(//a[text() = 'Close'])[2]")
	WebElement closeButton;
	
	@FindBy(xpath = "//a[contains(text(), 'Groups')]")
	WebElement groupTab;
	
	@FindBy(xpath = "//table[@id = 'mmgroupuser']//td[1]")
	WebElement groupName;
	
	@FindBy(xpath = "//a[text() = 'Remove from Group ']")
	WebElement removeGroup;
	
	@FindBy(xpath = "//a[@id='removegroupsubmit']")
	WebElement removeGroupSubmit;
	
	@FindBy(xpath = "//input[@id='group_name']")
	WebElement searchGroup;
	
	
	@FindBy(xpath = "//div[@class = 'checkbox checkbox-primary ']//input[@type = 'checkbox']/following-sibling::label")
	WebElement checkbox;
	
	@FindBy(xpath = "//a[@id = 'removegroupsubmit']")
	WebElement removeButton;
	
	@FindBy(xpath = "//a[text() = 'Assignments']")
	WebElement assignmentTab;
	
	@FindBy(xpath = "//a[text() = 'Add Assignment ']")
	WebElement addAssignmentLink;
	
	@FindBy(xpath = "//select[@name = 'assignment']")
	WebElement selectAssignmentDrop;
	
	@FindBy(xpath = "//select[@name = 'group']")
	WebElement selectgroupDrop;
	
	
	@FindBy(xpath = "//a[text() = 'Remove Assignment ']")
	WebElement removeAssignmentLink;
	
	@FindBy(xpath = "//a[@id = 'addassignsubmit']")
	WebElement addAssignmentButton;
	@FindBy(xpath = "//div[@id = 'common_content']//button[@class = 'close']/following-sibling::div[@style][2]")
	WebElement addAssignmentMessage;
	
	
	@FindBy(xpath = "(//a[contains(text(), 'Assignments')])[2]")
	WebElement detailAssignmentTab;
	
	@FindBy(xpath = "//table[@id = 'assignmentlisting']//td[1]")
	WebElement assignmentTitle;
	
	@FindBy(xpath = "//label[contains(@for , 'remove')]")
	WebElement assignmentLabel;
	
	@FindBy(xpath = "(//a[text() = 'Remove Assignment'])[2]")
	WebElement assignmentRemovePop;
	
	@FindBy(xpath = "//button[@class = 'close']/following-sibling::div//a[contains(@class, 'top') and text() = 'Close']")
	WebElement assignmentClose;
	
	@FindBy(xpath = "//a[text()='Close']")
	WebElement Close;
	
	
	
	
	
	@FindBy(xpath = "//div[@id = 'common_content']//div[contains(@class, 'msgDisplayAlreadyAllAssignment')]")
	WebElement addAssignmentDuplicateMessage;
	
	@FindBy(xpath = "//button[@class = 'close']/following-sibling::div//div[@style]")
	WebElement removalMessage;
	
	@FindBy(xpath = "//*[@id=\"addassignclose\"]")
	WebElement assignmentClosebtn;
	
	@FindBy(xpath = "//*[@id=\"common_content\"]/div/div/div[6]/a")
	WebElement assignmentClosebn;
	
	@FindBy(xpath = "//div[@id = 'common_content']//button[@class = 'close']/following-sibling::div[3]")
	WebElement removeAssignmentMessage;
	
	@FindBy(xpath = "//h5[contains(text(), 'Remove User(s) from Groups')]")
	WebElement removeGroupForAllPopupHeader;
	
	  @FindBy(xpath = "//a[contains(text() , 'Add')]")
	    WebElement addUnitLink;

	  String unitInformation = "//select[contains(@class, 'unitLevelSelect') and @name = 'unit_";

		
		@FindBy(xpath = "//div[@id = 'common_content']//div[3]")
		WebElement addAssignmentNoCommonMessage;


	   @FindBy(xpath = "//select[@name = 'orgStructure']")
	    WebElement levelDropdown;
	    
	    @FindBy(xpath = "//button[@id = 'popup-submit-btn']")
	    WebElement levelDropdownSubmitButton;
	
	
	@FindBy(xpath = "//td[text() = 'No Assignments are present.']")
	WebElement assignmentDisplay;
	
	@FindBy(xpath = "//body[@class]")
	WebElement pageLoad;
	
	@FindBy(xpath = "//a[text() = 'Unenroll']")
	WebElement unEnrollButton;
	
	@FindBy(xpath = "//*[@id='productInner']//a[text()='Unenroll Assignment']")
	WebElement unEnrollBtn;
	
	@FindBy(xpath = "//*[@id='common-modal-content']//label")
	WebElement unenrollCheckBox;

	//*[@id="unenroll_modal"]/div[2]/label
	
	@FindBy(xpath = "//button[text()='Yes']")
	WebElement yesBtn;
	
	@FindBy(xpath = "//*[@id='ajaxdeletesuccessmsg']")
	WebElement successmsg;
	
	@FindBy(xpath = "//div[contains(@class,'alert-success')]")
	WebElement unenrollsuccessmsg;
	
	
	
	@FindBy(xpath = "//table[@id = 'no_sort']//td[1]")
	WebElement courseTitle;
	
	@FindBy(xpath = "(//a[text() = 'Close'])[3]")
	WebElement closePopUp;
	
	@FindBy(xpath = "//a[contains(text() , 'View Certificates')]")
	WebElement coursesCertificate;
	
	@FindBy(xpath = "//h1[text() = 'Current eCards']")
	WebElement eCardLabel;
	
	@FindBy(xpath = "//div[@class = 'ecard_box ecard']")
	WebElement eCardBox;
	
	@FindBy(xpath = "//div[@class='ecard_box ecard']//h1")
	WebElement eCardBoxcourse;
	
	
	
	@FindBy(xpath = "(//div[@class='tab-content ecard-wrapper']//div[2]//h1)[1]")
	WebElement eCardBoxHeader;
			


	@FindBy(xpath = "//a[text()='Active']")
	WebElement activeStatus;


	@FindBy(xpath = "(//h1)[1]")
	WebElement headerCertificates;

	@FindBy(xpath = "//div[@class='ecard_box ecard']/p[2]")
	WebElement eCardusername;
	
	@FindBy(xpath = "//div[@class = 'ecard_box ecard']//h1")
	WebElement courseName;
	
	@FindBy(xpath = "//a[@class = 'orgHierarchyUnit']")
	WebElement unitName;
	
	@FindBy(xpath = "//span[@id = 'sum_job_title_id']")
	WebElement jobTitle;
	
	@FindBy(xpath = "//span[@id = 'sum_unique_id']")
	WebElement userIdViewPage;
	@FindBy(xpath = "//ul[contains(@class, 'edit_organization_tabs')]//a[contains(text(), 'Assignments')]")
	WebElement assignmentBar;
	
	@FindBy(xpath = "//span[@id = 'sum_email']")
	WebElement userEmailViewPage;
	
	@FindBy(xpath = "//label[@for = 'checkbox_all']")
	WebElement checkAllUSer;
	
	@FindBy(xpath = "//div[@id = 'action_items']/button")
	WebElement actionDropDown;
	
	@FindBy(xpath = "//a[@class = 'dropdown-item removegroup']")
	WebElement removeGroupForAll;
	
	
	@FindBy(xpath = "//a[@class = 'dropdown-item addassign']")
	WebElement addAssignmentForAll;
	
	
	@FindBy(xpath = "//a[@class = 'dropdown-item addgroup']")
	WebElement addgroupForAll;
	
	@FindBy(xpath = "//a[@class = 'dropdown-item removegroup']")
	WebElement removegroupForAll;
	
	@FindBy(xpath = "//a[@class = 'dropdown-item removeassign']")
	WebElement removeassignForAll;
	
	@FindBy(xpath = "//input[@name='remove_groups']")
	WebElement removegroupcheckbox;
	
	
	
	
	@FindBy(xpath = "//*[@id='productInner']//a[text()='Unenroll Assignment']")
	WebElement Unenroll;
	
	@FindBy(xpath = "//div[contains(@class, 'msgDisplaySomeAssignment')]")
	WebElement addAssignmentForAllWarning;
	
	@FindBy(xpath = "//div[contains(@class, 'msgDisplayAlreadyAssignment')]")
	WebElement addAssignmentForAlreadyWarning;
	

	
	@FindBy(xpath = "//div[contains(@class, 'msgDisplaySomeGroup')]")
	WebElement addGroupForAllWarning;
	
	@FindBy(xpath = "//div[contains(@class, 'msgDisplayAlreadyGroup')]")
	WebElement addGroupAlready;
	
	
	@FindBy(xpath = "//button[@title=\"Organization\"]")
	WebElement Organization;
	
	
	@FindBy(xpath = "//*[@id=\"common_content\"]//div[3]")
	WebElement errorMsg;
	
	@FindBy(xpath = "//div[contains(@class, 'msgDisplayAlreadyAssignment')]")
	WebElement addAssignmentDuplicateWarning;
	
	@FindBy(xpath = "(//a[text() = 'Close'])[2]")
	WebElement closeWarning;
	
	@FindBy(xpath = "(//a[contains(text(), 'Assignments')])[2]")
	WebElement assignmentUnderUser;
	
	@FindBy(xpath = "(//a[text() = 'Add Assignment'])[1]")
	WebElement addAssignmentUnderUser;
	
	@FindBy(xpath = "//button[@title = 'Create New Assignment']")
	WebElement selectAssignmentButtonUnderUser;
	
	@FindBy(xpath = "(//ul[@role = 'listbox']/li[2])[2]")
	WebElement selectAssignmentDropUnderUser;
	
	@FindBy(xpath = "//a[@id = 'addAssignment']")
	WebElement addAssignmentButtonUnderUser;
	
	@FindBy(xpath = "//button[@title = 'Select Job Title']")
	WebElement addTitleDropdown;
	
	@FindBy(xpath = "//button[@title = 'Select Job Title']//following::li[2]")
	WebElement addTitleValue;
	
	@FindBy(xpath = "//table[@id = 'learnerTableList']//td[6]")
	WebElement searchResultJobTitle;
	
	@FindBy(xpath = "//input[@name = 'date_of_hire']")
	WebElement hireDate;
	
	@FindBy(xpath = "//div[@class='datepicker-days']")
	WebElement calendarProduct;
	
	@FindBy(xpath = "//input[@id = 'date_of_hire_start']")
	WebElement fromHireDate;
	
	@FindBy(xpath = "//input[@id = 'date_of_hire_end']")
	WebElement toHireDate;
	
	@FindBy(xpath = "//a[contains(text(), 'Edit')]")
	WebElement editOrgLink;
	
	@FindBy(xpath = "//select[@id = 'orgStructure']")
	WebElement editOrgLevelDrop;
	
	@FindBy(xpath = "//button[@id = 'popup-submit-btn']")
	WebElement editOrgLevelSave;
	
	@FindBy(xpath = "//table[@id = 'learnerTableList']//td[5]")
	WebElement newOrgName;
	
	@FindBy(xpath = "//table[@id = 'learnerTableList']//tr[1]/td[2]")
	WebElement searchResultUserID;
	
	@FindBy(xpath = "//a[text()='Add Admin Access ']")
	WebElement addadmin;
	

	@FindBy(xpath = "(//*[@class = 'close'])[1]")
	WebElement successCloseButton;


	@FindBy(xpath = "//*[@id='courseList']//a[text()='Close']")
	WebElement close;

	@FindBy(xpath = "//*[@id='studentDetailsForm']/div[1]/div[4]/div[2]/small[2]")
	WebElement Errormsg;
	@FindBy(xpath = "//*[@id='studentDetailsForm']/div[1]/div[4]/div[2]/small[3]")
	WebElement Errormsgctc;

	
	

	@FindBy(xpath = "//div/div[2]/ul/li[4]")
	WebElement CertificatesBtn;

	@FindBy(xpath = "//div[@class='tab-content ecard-wrapper']//h1")
	WebElement noEcard;
	
	
			@FindBy(xpath = "(//a[contains(text(),'Assignments')])[2]")
			WebElement assigmnBtn;

	@FindBy(xpath = "//*[@id='orgStructure1']")
	WebElement orgStructure;
	
	
	@FindBy(xpath = "//*[@id=\"ms-list-1\"]/button")
	WebElement levelclick;
	
	@FindBy(xpath="//button[text()='Add Admin Access']")
	WebElement addAdminBtn;
	
	
	@FindBy(xpath="//*[@id=\"deleteAction\"]")
	WebElement delete;
	
	
	
	@FindBy(xpath="//*[@id=\"admins\"]/tbody//li/a[text()='Remove Admin Role']")
	WebElement removeRole;
	
	@FindBy(xpath = "//a[@class = 'dropdown-item removeassign']")
	WebElement removeAssignmentForAll;
	
	@FindBy(xpath = "//a[@id = 'removeassignsubmit']")
	WebElement removeAssignmentButton;
	

	@FindBy(xpath = "//div[@id='action_items']//ul[@class='dropdown-menu']//li")
	List<WebElement> dropList;

	@FindBy(xpath = "//div[@class='dropdown open']//ul[@class='dropdown-menu']//li")
	List<WebElement> dropList2;

//	@FindBy(xpath = "//div[@class='dropdown open']//ul[@class='dropdown-menu']//li")
//	List<WebElement> dropList2;

	@FindBy(xpath="//*[@id=\"deleteprocess\"]")
	WebElement deleteProcess;
	
	@FindBy(xpath="//*[@id=\"orgStructure\"]")
	WebElement levl;
	
	@FindBy(xpath="//*[@id=\"unit_2\"]")
	WebElement unitLevel;
	
	
	@FindBy(xpath="//*[@id=\"popup-submit-btn\"]")
	WebElement saveBtn;
	
	
	@FindBy(xpath="//a[contains(@onclick,'inactivateAdminunit')]")
	WebElement remove;
	
	@FindBy(xpath="//*[@id=\"admins\"]/tbody/tr//td[4]/div/a")
	WebElement actionbtn;
	
	@FindBy(xpath="//a[contains(text(),'Groups')]")
	WebElement groupbtn;
	
	@FindBy(xpath = "//button[@id = 'exportbtn']")
	WebElement exportButton;
	
	@FindBy(xpath = "//div[@class = 'top']//a[text() = 'Next']")
	WebElement nextPageBUtton;
	
	@FindBy(xpath = "//label[text() = 'Rows per page ']//select")
	WebElement rowPerPageSelect;

	@FindBy(xpath = "//table[@id = 'learnerTableList']//th[text() = 'User ID']")
	WebElement userIDHeader;
	
	@FindBy(xpath = "//table[@id = 'learnerTableList']//th[text() = 'First Name']")
	WebElement userFirstHeader;
	@FindBy(xpath = "//table[@id = 'learnerTableList']//th[text() = 'Last Name']")
	WebElement userLastHeader;
	@FindBy(xpath = "//a[text() = 'Upload ']")
	WebElement uploadFileLink;
	@FindBy(xpath = "//th[@class = 'failurecount']")
	WebElement failureCount;
	
	@FindBy(xpath = "(//div[@class = 'btndiv']/a[text() = 'Close'])[1]")
	WebElement buttonClose;
	
	@FindBy(xpath="//*[@id=\"customerform\"]//small[text()='Email already exists.']")
	WebElement existEmail;
	@FindBy(xpath = "//a[@id = 'removegroupsubmit']")
	WebElement removeGroupButton;
	
	@FindBy(xpath = "//div[@id = 'learnerTableList_info']")
	WebElement userListRange;

	
	@FindBy(xpath="//a[@class='pull-right add_edit']")   ////a[@class='pull-right add_edit']
	WebElement unitinfoAdd;
	
	@FindBy(xpath="//select[@id='orgStructure']")
	WebElement LevelDP;
	
	@FindBy(xpath="//select[@id='unit_2']")
	WebElement Level2DP;
	
	@FindBy(xpath="//button[@id='popup-submit-btn']")
	WebElement Savebtn;
	@FindBy(xpath="//label[text()='Rows per page ']//select")
	WebElement RowsPerPage;
	@FindBy(xpath="//input[@id='ms-opt-45']")
	WebElement UserInactive;
	
	@FindBy(xpath="//a[text()='Cancel']")
	WebElement CancelAssignment;
	
	@FindBy(xpath = "//div[@id = 'common_content']//div[contains(@class, 'msgDisplaySomeAssignment')]")
	WebElement addAssignmentAlreadyMessage;
	
	@FindBy(xpath = "//button[@class = 'close']/following-sibling::div//a[contains(@class, 'top') and text() = 'Cancel']")
	WebElement assignmentCancel;

	
	@FindBy(xpath="//*[@id='productInner']/tr/td")
	WebElement norecordPresent;
	
	@FindBy(xpath = "//*[@id='assignmentlisting']//th")
	List<WebElement> assignmentlistingHeader;
	
	
	@FindBy(xpath = "//label[@class='assignment_switch']//input[@id='showOnlyOA']")
	WebElement showOnlyOA;

	@FindBy(xpath = "//span[@class='assignment_slider round']")
	WebElement sliderround;

	@FindBy(xpath = "//label[@for='showOnlyOA' and contains(text(),'Show OA Only')]")
	WebElement showOnlyOAlabel;

	
	@FindBy(xpath="//*[@id='assignAddModalForm']/div/div/button/span[1]")
	WebElement dropdownOption;

	@FindBy(xpath="//input[@id='ms-opt-44']")
	WebElement UserActive;
	@FindBy(xpath="//a[text()='Users']")
	WebElement UsersTab;
	@FindBy(xpath="//div[text()='The selected user(s) already has this assignment.']")
	WebElement DuplicteAssignmentError;
	
	String allGroupName = "//div[@class = 'checkbox checkbox-primary ']//label";
	By table = By.xpath("//table[@id = 'learnerTableList']/tbody/tr[1]/td");
	
	By userTable = By.xpath("//table[@id = 'learnerTableList']//tr[@class]");
	By userTableManage = By.xpath("//table[@id = 'learnerTableList']//tr[@class]//td[text()='Active']");
	By norecordfound=By.xpath("//table[@id = 'learnerTableList']//tr[@class]");
	String userRows = "//table[@id = 'learnerTableList']//tr[@class]";
	String val;
	String actionLink = "(//a[@class = 'action_dropdown'])[";
	String assignmentLink = "(//a[text() = 'Add Assignment '])[";
	String userActionDetails = "(//a[@class = 'action_dropdown'])[";
	String userGroupDetail = "(//a[text() = 'Add to Group '])[";
	String datePick = "//td[@class='day' and text() = ";
	String selectUnit = "//select[@id = 'unit_";
	String userEditDetail = "(//a[contains(text() , 'Edit User Details')])[";
	String jobtitle = "//button[@title = 'Select Job Title']/following-sibling::div//span[1]";
	String assignmentName = "//div[@class = 'checkbox checkbox-primary ']//label";
	String userStatusFilterDropdown = "//select[@id = 'statusFilter']//following-sibling::div//ul//input";
	String userStatusFilterDropdownValues = "//select[@id = 'statusFilter']//following-sibling::div//ul//label";
	String unitLevelFilter1 = "//div[@id = 'dynamic_sub_level']//button";
	String jobTitleFilter = "(//div[@id = 'static_sub_level']//button)[1]";
	String groupAvailableFilter = "(//div[@id = 'static_sub_level']//button)[2]";
	String reportTable="//*[@id=\"learnerTableList\"]/tbody/tr";
	String actionItem="']//following-sibling::td//a[@class='action_dropdown']",unenrollfront="//td[contains(text(),'",unenrollback="')]//following-sibling::td[3]/a[@title='Unenroll']";
	String assigment="//td[text()='",unenrollbtn="']//following-sibling::td//li//a[text()='Unenroll Assignment']";

	String assignmentlisting = "//*[@id='assignmentlisting']//";

	
	public static String orid="";
	String groupFilter = "//div[contains(@class,'groupselectnone')]";
	
	public static String Firstname,Lastname,childCourseName,filePath, fileName, userEail, userId,userId1,dropdn,job,userEmail,loginEmail,existingUser,orgUserEmail,adminEmailid,userFirstName,userLastName;;
	public static HashMap<String, String> data = new HashMap<>();
	public static String usrEmail[],group[],jobtile[],usrID[];;
	String orgMainFilter = "//button[@title = 'Organization']",email;
	String unitLevelMainFilter = "//div[@id = 'mainLevelFilter']//button";

	String downloadPath = System.getProperty("user.dir") + prop.getProperty("downloadPath");
	Students std;
	List<List<String>> list_UI = new ArrayList<>();
	List<List<String>> list_report = new ArrayList<>();
	@FindBy(xpath = "//select[@id = 'orgLevel']")
	WebElement orgLevelMainFilter;

	public static String  uiList[][];

		OrganizationHome	orgHome = new OrganizationHome();

	public User() 
	{
		PageFactory.initElements(driver, this);
	}
	
	public void enterFromHireDate(int num, String time)
	{
		try
		{
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
			}
			Thread.sleep(5000);
			String date = changeDateAsPerTime(num, time);
			System.out.println(date);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(fromHireDate));
			fromHireDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct)).isDisplayed();
			fromHireDate.clear();
			fromHireDate.sendKeys(date);
			fromHireDate.clear();
			String fromText = fromHireDate.getAttribute("value");
			Assert.assertEquals(fromText, "");
			fromHireDate.sendKeys(date);
		}
		catch(Exception e)
		{
			Assert.fail("Issue in hire date selection");
		}
	}
	public void clickUserSearch()
	{
		wait.until(ExpectedConditions.visibilityOf(searchButton));
		wait.until(ExpectedConditions.elementToBeClickable(searchButton));
		
		searchButton.click();
	}
	
	public void validateNoecard()
	{
		wait.until(ExpectedConditions.visibilityOf(noEcard));
//		wait.until(ExpectedConditions.elementToBeClickable(searchButton));
		
		Assert.assertEquals(noEcard.getText(), "No eCards Available.");
		
//		searchButton.click();
	}
	
	public void validateToHireDate(String date)
	{
		try
		{
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
			}
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(toHireDate));
			String fromText = toHireDate.getAttribute("value");
			Assert.assertEquals(fromText, date);
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
			}
			Thread.sleep(5000);
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	public void validateFromHireDate(String date)
	{
		try
		{
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
			}
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(fromHireDate));
			String fromText = fromHireDate.getAttribute("value");
			Assert.assertEquals(fromText, date);
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
			}
			Thread.sleep(5000);
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	public void clickUserClearSearch()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
			}
			Thread.sleep(5000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchClear));
			searchClear.click();
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
			}
			Thread.sleep(5000);
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	public void enterToHireDate(int num, String time)
	{
		try
		{
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
			}
			Thread.sleep(5000);
			String date = changeDateAsPerTime(num, time);
			System.out.println(date);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(toHireDate));
			toHireDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct)).isDisplayed();
			toHireDate.clear();
			toHireDate.sendKeys(date);
			toHireDate.clear();
			String fromText = toHireDate.getAttribute("value");
			Assert.assertEquals(fromText, "");
			toHireDate.sendKeys(date);
		}
		catch(Exception e)
		{
			Assert.fail("Issue in hire date selection");
		}
	}
	public String changeDateAsPerTime(int num, String time)
	{
		LocalDate localDate = LocalDate.now();
		LocalDate requiredDate = null;
		if(time.equalsIgnoreCase("days"))
		{
			requiredDate = localDate.plusDays(num);
		}
		else if(time.equalsIgnoreCase("month"))
		{
			requiredDate = localDate.plusMonths(num);
		}
		else if(time.equalsIgnoreCase("year"))
		{
			requiredDate = localDate.plusYears(num);
		}
		return requiredDate.format(DateTimeFormatter.ofPattern("YYYY/MM/dd")).toString();
	}
	public void validateJobLevelFilterAvailable()
	{
		try {
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
			}
			List<WebElement> unitList =  driver.findElements(By.xpath(jobTitleFilter));
			System.out.println(unitList.size());
			Assert.assertFalse("Job level filter not availabe" , unitList.size() == 0);
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();	
			Assert.fail(e.getMessage());
		}
	}
	public void unselectUnitLevelFromMainFilter(int level)
	{
		try
		{
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(unitLevelMainFilter))));
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" + unitLevelMainFilter + ")["+ level +"]"))));
			driver.findElement(By.xpath("(" + unitLevelMainFilter + ")["+ level +"]")).click();
			Thread.sleep(3000);
			driver.findElement(By.xpath("(" + unitLevelMainFilter + ")[" + level +"]//following-sibling::div//a")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("(" + unitLevelMainFilter + ")["+ level +"]")).click();
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void validateUnitLevelFilterAvailable(int count)
	{
		try {
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
			}
			List<WebElement> unitList =  driver.findElements(By.xpath("(" + unitLevelFilter + "/span[contains(text(),'selected')])[" + count + "]" ));
			System.out.println(unitList.size());
			Assert.assertFalse("Unit level " + (count +1) + "available" , unitList.size() != 1);
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}

	public void validateUnitLevelFilterNotAvailable(int count)
	{
		try {
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
			}
			List<WebElement> unitList =  driver.findElements(By.xpath("(" + unitLevelFilter + "/span[contains(text(),'selected')])[" + count + "]" ));
			System.out.println(unitList.size());
			Assert.assertFalse("Unit level " + (count +1) + "available" , unitList.size() == count );
			
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	public void unselectUnitLevelFromMoreFilter(int level)
	{
		try
		{
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(unitLevelFilter))));
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" + unitLevelFilter + ")["+ level +"]"))));
			driver.findElement(By.xpath("(" + unitLevelFilter + ")["+ level +"]")).click();
			Thread.sleep(3000);
			driver.findElement(By.xpath("(" + unitLevelFilter + ")[" + level +"]//following-sibling::div//a")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("(" + unitLevelFilter + ")["+ level +"]")).click();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
			
		}
	}
	public void clickMoreFilterClearSearch()
	{
		try 
		{
			navigateUserModule();
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
			}
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(searchClear));
			clickMoreFilter();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.elementToBeClickable(moreFilterClearSearch));
			moreFilterClearSearch.click();
			js = (JavascriptExecutor)driver;
			pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(3000);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}

	public void validateUserCount(int count)
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(userTable)));
		List<WebElement> rows = driver.findElements(userTable);
		Assert.assertTrue(rows.size() > count);
	}
	
	
	
	public void getAllUserUIListlms()
	{
		list_UI.clear();
		JavascriptExecutor js = (JavascriptExecutor)driver;
		val = js.executeScript("return document.readyState").toString();
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
		}
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userRows))));
		List<WebElement> tableRows = driver.findElements(By.xpath(userRows));
		int rowCount = tableRows.size();
		uiList = new String[rowCount][7];
		for (int i= 1; i<= rowCount; i++)
		{
			for(int j = 1; j <= 7; j++)
			{
				String textValue = driver.findElement(By.xpath("(" + userRows + ")[" + i + "]/td[" + j + "]")).getText();
				uiList[i-1][j-1] = textValue;
			}
		}
		for (String[] ints : uiList) 
		{
			System.out.println(ints.toString());
			list_UI.add(Arrays.asList(ints));
		}
	}
	public void getAllUserUIList()
	{
		list_UI.clear();
		JavascriptExecutor js = (JavascriptExecutor)driver;
		val = js.executeScript("return document.readyState").toString();
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
		}
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userRows))));
		List<WebElement> tableRows = driver.findElements(By.xpath(userRows));
		int rowCount = tableRows.size();
		uiList = new String[rowCount][7];
		for (int i= 1; i<= rowCount; i++)
		{
			for(int j = 2; j <= 8; j++)
			{
				String textValue = driver.findElement(By.xpath("(" + userRows + ")[" + i + "]/td[" + j + "]")).getText();
				uiList[i-1][j-2] = textValue;
			}
		}
		for (String[] ints : uiList) 
		{
			list_UI.add(Arrays.asList(ints));
		}
		
		
		
	}
	public void selectOrgLevelMainFilter(int level)
	{
		try
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchText));
			wait.until(ExpectedConditions.elementToBeClickable(searchText));
			Select select = new Select(orgLevelMainFilter);
			select.selectByIndex(level - 1);
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	public void searchJobTitleFilter(int level, String unitName) throws InterruptedException
	{
		try {

			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
			}
		
			wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(jobTitleFilter))));
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" + jobTitleFilter + ")["+ level +"]"))));
			int m=0;
			while(true)
			{
			 try{
				
				 wait.until(ExpectedConditions.visibilityOf(jobtitlfilter));
				 jobtitlfilter.click();		
				Thread.sleep(3000);	
				 wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" +jobTitleFilter + "/following-sibling::div//input[@type = 'text'])[" + level + "]"))));
					
			     break;
			  }
			  catch(Exception e){
				  if(m==pagload)
						break;
					else
					{
						try {
							Thread.sleep(750);
						} catch (InterruptedException k) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					m++;
			    
			  }
			}
			
			Thread.sleep(5000);
//			driver.findElement(By.xpath("(" + jobTitleFilter + ")[" + level +"]//following-sibling::div//a")).click();
//			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" +jobTitleFilter + "/following-sibling::div//input[@type = 'text'])[" + level + "]"))));
			Thread.sleep(4000);
			
			driver.findElement(By.xpath("(" +jobTitleFilter + "/following-sibling::div//input[@type = 'text'])[" + level + "]")).click();
			Thread.sleep(4000);
			
			driver.findElement(By.xpath("(" +jobTitleFilter + "/following-sibling::div//input[@type = 'text'])[" + level + "]")).clear();			
			Thread.sleep(4000);
			
			driver.findElement(By.xpath("(" +jobTitleFilter + "/following-sibling::div//input[@type = 'text'])[" + level + "]")).sendKeys(unitName);
			Thread.sleep(2000);
			driver.findElement(By.xpath("(" + jobTitleFilter + ")["+ level + "]//following-sibling::div//a")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("(" + jobTitleFilter + ")[" + level +"]")).click();
		} 
		catch (StaleElementReferenceException z) 
		{
			driver.navigate().refresh();
			Thread.sleep(5000);	
			System.out.println("StaleElementReferenceException");
			clickMoreFilter();
			Thread.sleep(3000);	
			
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
			}
		
			wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(jobTitleFilter))));
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" + jobTitleFilter + ")["+ level +"]"))));
			int m=0;
			while(true)
			{
			 try{
				
				 wait.until(ExpectedConditions.visibilityOf(jobtitlfilter));
				 jobtitlfilter.click();		
				Thread.sleep(3000);	
				 wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" +jobTitleFilter + "/following-sibling::div//input[@type = 'text'])[" + level + "]"))));
					
			     break;
			  }
			  catch(Exception e){
				  if(m==pagload)
						break;
					else
					{
						try {
							Thread.sleep(750);
						} catch (InterruptedException k) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					m++;
			    
			  }
			}
			
			Thread.sleep(5000);
//			driver.findElement(By.xpath("(" + jobTitleFilter + ")[" + level +"]//following-sibling::div//a")).click();
//			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" +jobTitleFilter + "/following-sibling::div//input[@type = 'text'])[" + level + "]"))));
			Thread.sleep(4000);
			
			driver.findElement(By.xpath("(" +jobTitleFilter + "/following-sibling::div//input[@type = 'text'])[" + level + "]")).click();
			Thread.sleep(4000);
			
			driver.findElement(By.xpath("(" +jobTitleFilter + "/following-sibling::div//input[@type = 'text'])[" + level + "]")).clear();			
			Thread.sleep(4000);
			
			driver.findElement(By.xpath("(" +jobTitleFilter + "/following-sibling::div//input[@type = 'text'])[" + level + "]")).sendKeys(unitName);
			Thread.sleep(2000);
			driver.findElement(By.xpath("(" + jobTitleFilter + ")["+ level + "]//following-sibling::div//a")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("(" + jobTitleFilter + ")[" + level +"]")).click();
			
		}
		catch (Exception e) 
		{
			Assert.fail("Error selecting job title "+e.getMessage());
		}
	}
	
	public void searchGroupFilter(int level, String unitName)
	{
		try {

			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(groupAvailableFilter))));
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" + groupAvailableFilter + ")["+ level +"]"))));
		int m=0;
			while(true)
			{
			 try{
					driver.findElement(By.xpath("(" + groupAvailableFilter + ")["+ level +"]")).click();
						     break;
			  }
			  catch(Exception e){
				  if(m==pagload)
						break;
					else
					{
						try {
							Thread.sleep(550);
						} catch (InterruptedException k) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					m++;
			  }
			}
		
//			driver.findElement(By.xpath("(" + jobTitleFilter + ")[" + level +"]//following-sibling::div//a")).click();
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" +groupAvailableFilter + "/following-sibling::div//input[@type = 'text'])[" + level + "]"))));
			driver.findElement(By.xpath("(" +groupAvailableFilter + "/following-sibling::div//input[@type = 'text'])[" + level + "]")).click();
			driver.findElement(By.xpath("(" +groupAvailableFilter + "/following-sibling::div//input[@type = 'text'])[" + level + "]")).clear();			
			driver.findElement(By.xpath("(" +groupAvailableFilter + "/following-sibling::div//input[@type = 'text'])[" + level + "]")).sendKeys(unitName);
			Thread.sleep(2000);
				
			driver.findElement(By.xpath("(" + groupAvailableFilter + ")["+ level + "]//following-sibling::div//a")).click();
			driver.findElement(By.xpath("(" + groupAvailableFilter + ")[" + level +"]")).click();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	public void validateUnitLevelFilterAvailability()
	{
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(unitLevelFilter))));
			List<WebElement> unitList =  driver.findElements(By.xpath(unitLevelFilter));
			System.out.println(unitList.size());
			for(int i = 1; i <= unitList.size(); i++)
			{
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" + unitLevelFilter + ")[" + i + "]"))));
				driver.findElement(By.xpath("(" + unitLevelFilter + ")[" + i + "]")).click();
				Thread.sleep(3000);
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" +unitLevelFilter + "/following-sibling::div//input[@type = 'text'])[" + i + "]"))));
			}
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());	
		}
	}
	public void searchUnitLevelFilter(int level, String unitName)
	{
		if(AssignmentReport. checkifParmeterAvailable(unitName))
			unitName=AssignmentReport.getParmeterAvailable(unitName);

		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(unitLevelFilter))));
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" + unitLevelFilter + ")["+ level +"]"))));
			driver.findElement(By.xpath("(" + unitLevelFilter + ")["+ level +"]")).click();
			Thread.sleep(3000);
			driver.findElement(By.xpath("(" + unitLevelFilter + ")[" + level +"]//following-sibling::div//a")).click();
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" +unitLevelFilter + "/following-sibling::div//input[@type = 'text'])[" + level + "]"))));
			driver.findElement(By.xpath("(" +unitLevelFilter + "/following-sibling::div//input[@type = 'text'])[" + level + "]")).sendKeys(unitName);
			Thread.sleep(2000);
			driver.findElement(By.xpath("(" + unitLevelFilter + ")["+ level + "]//following-sibling::div//a")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("(" + unitLevelFilter + ")[" + level +"]")).click();
			Thread.sleep(2000);
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
	}
	public void clickMoreFilterSearch()
	{
		wait.until(ExpectedConditions.elementToBeClickable(moreFilterSearch));
		
		wait.until(ExpectedConditions.visibilityOf(moreFilterSearch));
		try
		{
		Thread.sleep(3000);	
		}
		catch( Exception e)
		{
			
		}
		moreFilterSearch.click();
	}
	public void validateUserCountUnitLevel(int count)
	{
		try {
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(userTable)));
			
			List<WebElement> rows = driver.findElements(userTable);
			Assert.assertTrue(rows.size() == count);
			validateDefaultSortingUserPage("last");
		}
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
	}
	public void validateDefaultSortingUserPage(String columName)
	{
		try 
		{
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
			}
			Thread.sleep(5000);
			String sortCheck = null;
			switch (columName) {
			case "first":
				sortCheck = userFirstHeader.getAttribute("class");
				break;
			case "last":
				sortCheck = userLastHeader.getAttribute("class");
				break;	
			default:
				break;
			}
			sortCheck.equalsIgnoreCase("sorting_asc");
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	public void validateJobTitleFilterAvailability()
	{
		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(jobTitleFilter))));
		List<WebElement> unitList =  driver.findElements(By.xpath(jobTitleFilter));
		for(WebElement elem : unitList)
		{
			elem.click();
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(jobTitleFilter + "/following-sibling::div//input[@type = 'text']"))));
		}
	}
	public void validateUserStatusFilterAvailability()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(userStatusFilter));
		try {
		Thread.sleep(4000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		userStatusFilter.click();
	}
	
	public void validateusertable(String data)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		try
		{
			
		if(data.contains("UserID"))
			Assert.assertEquals(driver.findElement(By.xpath("//*[@id='learnerTableList']/tbody/tr/td[2][text()='"+User.userId+"']")).getText(),User.userId);
		else if(data.contains("UserID1"))
			Assert.assertEquals(driver.findElement(By.xpath("//*[@id='learnerTableList']/tbody/tr/td[2][text()='"+User.data.get("userId")+"']")).getText(),User.data.get("userId"));
		else if(data.contains("Jobtitle"))	
			Assert.assertEquals(driver.findElement(By.xpath("//*[@id='learnerTableList']/tbody/tr/td[6][text()='"+OrganizationSettings.titleName+"']")).getText(),OrganizationSettings.titleName);
		else if(data.contains("HireDate_Today"))
		{
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			Calendar cal = Calendar.getInstance();
//			cal.add(Calendar.DAY_OF_MONTH, -1);
			String formattedStartDate = dateFormat.format(cal.getTime());

			Assert.assertEquals(driver.findElement(By.xpath("//*[@id='learnerTableList']/tbody/tr/td[7][text()='"+formattedStartDate+"']")).getText(),formattedStartDate);
		}
		else
			Assert.assertEquals(driver.findElement(By.xpath("//*[@id='learnerTableList']/tbody/tr/td[text()='"+data+"']")).getText(),data);;
		}
		catch(Exception e)
		{
			Assert.assertEquals(driver.findElement(By.xpath("//*[@id='learnerTableList']/tbody/tr/td/a[text()='"+data+"']")).getText(),data);;
			
		}
	}
	
	public void validateusertablelms(String data)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		try
		{
			
		if(data.contains("UserID"))
			Assert.assertEquals(driver.findElement(By.xpath("//*[@id='learnerTableList']/tbody/tr/td[1][text()='"+User.userId+"']")).getText(),User.userId);
		else if(data.contains("UserID1"))
			Assert.assertEquals(driver.findElement(By.xpath("//*[@id='learnerTableList']/tbody/tr/td[1][text()='"+User.data.get("userId")+"']")).getText(),User.data.get("userId"));
		else if(data.contains("Jobtitle"))	
			Assert.assertEquals(driver.findElement(By.xpath("//*[@id='learnerTableList']/tbody/tr/td[5][text()='"+OrganizationSettings.titleName+"']")).getText(),OrganizationSettings.titleName);
		else if(data.contains("HireDate_Today"))
		{
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			Calendar cal = Calendar.getInstance();
//			cal.add(Calendar.DAY_OF_MONTH, -1);
			String formattedStartDate = dateFormat.format(cal.getTime());

			Assert.assertEquals(driver.findElement(By.xpath("//*[@id='learnerTableList']/tbody/tr/td[6][text()='"+formattedStartDate+"']")).getText(),formattedStartDate);
		}
		else
			Assert.assertEquals(driver.findElement(By.xpath("//*[@id='learnerTableList']/tbody/tr/td[text()='"+data+"']")).getText(),data);;
		}
		catch(Exception e)
		{
			Assert.assertEquals(driver.findElement(By.xpath("//*[@id='learnerTableList']/tbody/tr/td/a[text()='"+data+"']")).getText(),data);;
			
		}
	}
	
	
	public void validateUserStatusFilterFields()
	{
		String userStatusArray[];
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(userStatusFilterSearchBar));
		wait.until(ExpectedConditions.visibilityOf(userStatusFilterDefaultStatus));
		String userStatus = userStatusFilterDefaultStatus.getAttribute("class");
		Assert.assertTrue(userStatus.equalsIgnoreCase("default selected"));
		List<WebElement> userStatusList = driver.findElements(By.xpath(userStatusFilterDropdown));
		Assert.assertFalse("More than 2 status available", userStatusList.size() != 2);
		userStatusArray = new String[userStatusList.size()];
		for(int i = 1; i <= userStatusList.size(); i++)
		{
			String element = "(" + userStatusFilterDropdownValues + ")[" + i + "]";
			String status = driver.findElement(By.xpath(element)).getText().trim();
			userStatusArray[i-1] = status;
		}
		Assert.assertTrue(Arrays.asList(userStatusArray).contains("Active"));
		Assert.assertTrue(Arrays.asList(userStatusArray).contains("Inactive"));				
	}
	
	public void clickMoreFilter()
	{
		try
		{
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			wait.until(ExpectedConditions.visibilityOf(moreFilter));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", moreFilter);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	public void validateUserGroupFilterNotAvailabile()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(3000);
			Assert.assertFalse(driver.findElements(By.xpath("//select[@id = 'group_id']//following-sibling::div/button")).size() > 0);
		
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void compareActivityList()
	{
		List<List<String>> differences = new ArrayList<>(list_UI);
		differences.removeAll(list_report);
		System.out.println(differences.size());
		Assert.assertTrue("Excel list +"+list_report.toString()+" UI list "+list_report.toString(), differences.size() == 0);
	 	
	}
	public void clickUserIdHeader()
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userIDHeader));
			userIDHeader.click();
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOf(userIDHeader));
			userIDHeader.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	public void clickNextButton()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		wait.until(ExpectedConditions.visibilityOf(nextPageBUtton));
		nextPageBUtton.click();
		val = js.executeScript("return document.readyState").toString();
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
		}
	}
	
	public void getAllUserExcelList()
	{
		try 
		{
			list_report.clear();
			Thread.sleep(5000);
			File file = new File(Students.filePath);
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			List<String[]> header = csvReader.readAll();
			System.out.println(header.size());
			String userRange = userListRange.getText();
			int starting = Integer.parseInt(userRange.split(" ")[1]);
			int ending = Integer.parseInt(userRange.split(" ")[3]);
			System.out.println(starting);
			System.out.println(ending);
			
			String reportDetails[][] = new String[ending - starting +1][7];
			for(int i = 2; i <=ending - starting+2; i++)
				{
				String []excel = header.get(starting+(i-1));
				for(int j = 0; j <= 6; j++)
				{
					reportDetails[i-2][j] = excel[j].replace("\"", "").trim();
				}				
			}
			csvReader.close();
			for (String[] ints : reportDetails) {
				list_report.add(Arrays.asList(ints));
				System.out.println(Arrays.asList(ints));
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	public void clickExportButton()
	{
		wait.until(ExpectedConditions.visibilityOf(exportButton));
		val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading"))
		{
			val = pageLoad.getAttribute("class");
		}
		try
				{
				Thread.sleep(5000);	
				}
				catch(Exception e)
				{
					
				}
		wait.until(ExpectedConditions.visibilityOf(exportButton));
		exportButton.click();
	}

	public void validateGroupFilterNotDisplayed()
	{
		List<WebElement> element = driver.findElements(By.xpath(groupFilter));
		if(element.size() > 0)
			Assert.fail("Group filter is available for LMS organization");
	}
	
	@SuppressWarnings("resource")
	public void validateDetails()
	{
		try 
		{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(table)));
		File file = new File(Students.filePath); 
		List<WebElement> rows = driver.findElements(table);		
		Thread.sleep(5000);
		FileReader filereader = new FileReader(file);
		CSVReader csvReader = new CSVReader(filereader); 
		List<String[]> header = csvReader.readAll();
		ArrayList<String> rowData =new ArrayList<String>();
		ArrayList<String> reportData =new ArrayList<String>();
		String []excel = header.get(header.size() - 1);
		String data[] = excel;
		
		for (WebElement row : rows) 
		{
			if(!(row.getText().length() <= 3))
			{
				String text = row.getText();
				rowData.add(text);				
			}
			else
			{
				String xpath[] = row.toString().split("xpath:");
				String path = xpath[1].substring(0, xpath[1].length()-1);
				int index = rows.indexOf(row) + 1;
				String text = driver.findElement(By.xpath(path + "[" + index + "]")).getText().trim();
				if((text.length()>0 || rows.indexOf(row) != 0) && (!text.equals("...")))
				{
					rowData.add(text);
				}
			}
		}
		for (int i = 0; i<=data.length-1; i++) 
		{
			reportData.add(data[i].replace("\"", ""));
		}
		
		System.out.println(rowData);
		System.out.println(reportData);
		for(int i = 0; i<= rowData.size()-1; i++)
		{
			Assert.assertEquals(reportData.get(i).trim().toLowerCase(), rowData.get(i).trim().toLowerCase());
		}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	public void verifyDownloadFile()
	{
		std = new Students();
		
		boolean dwnld = false;
		int m=0;
		do 
		{
			dwnld = std.isFileDownloaded_Ext(downloadPath, ".csv");
			if(m==pagload)
				break;
			else
			{
				try {
					Thread.sleep(550);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			m++;
		}
		while(dwnld == false);
	}
	public boolean isFileDownloaded_Ext(String dirPath, String ext){
		boolean flag=false;
	    File dir = new File(dirPath);
	    File[] files = dir.listFiles();
	    if (files != null)
	    {
	    	 for (int i = 0; i < files.length; i++) 
	 	    {
	 	    	if(files[i].getName().contains(ext)&& !(files[i].getName().contains(".crdownload"))) 
	 	    	{
	 	    		fileName = files[i].getName();
	 	    		filePath = files[i].getAbsolutePath();
	 	    		filePath = filePath.replace(".crdownload", "");
					flag=true;
	 	    		break;
	 	    	}
	 	    }
	    }
	    
	    return flag;
	}
	@SuppressWarnings("resource")
	public void addFileData_LMS(int userCount)
	{
		try 
		{
			boolean dwnld = false;
			int m=0;
			do 
			{
				dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
				if(m==pagload)
					break;
				else
				{
					try {
						Thread.sleep(550);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				m++;
			}
			while(dwnld == false);
			Thread.sleep(3000);
			File file = new File(filePath); 
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader); 
			String header[] = csvReader.readNext();
			CSVWriter writer = new CSVWriter(new FileWriter(filePath));
			List<String[]> list = new ArrayList<String[]>();
			list.add(header);
			writer.writeNext(header);
			for(int i=1; i<= userCount; i++)
			{
				String date = new java.util.Date().toString();
				date = date.replace(" ", "");
				String email = date;
				String formattedEmail = email.replace(":", "");
				if(userCount == 1)
				{
					Students.email =User.getUserEmail(i + formattedEmail) ;
				}
				String row[] = {formattedEmail, "Ansh" + i, "", "G" + i, User.getUserEmail(i + formattedEmail), "", "", "", "Active", "", ""};
				list.add(row);
				writer.writeNext(row);
				Thread.sleep(2000);
			}
			System.out.println(Students.email);
			
			Thread.sleep(2000);
			writer.flush();
			Thread.sleep(2000);
			readandUpdateFile();
	} 
		catch (Exception e) 
		{
		e.printStackTrace();
		Assert.fail(e.getMessage());
		}
		
	}
	public void readandUpdateFile()
	{
		try 
		{
			String file ="";
		do 
		{
			wait.until(ExpectedConditions.visibilityOf(chooseFileLink));
			file = uploadedFile.getText();
			driver.findElement(By.xpath("//*[@id = 'upload']")).sendKeys(filePath);
			Thread.sleep(5000);
			System.out.println("file length is " + file.length());
		}
		while(!(file.length() > 0));
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	public void clickCreateUser()
	{
		wait.until(ExpectedConditions.visibilityOf(createUserButton));
		wait.until(ExpectedConditions.elementToBeClickable(createUserButton));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", createUserButton);
	}
	
	public void validateActionDropdownNotDisplayed()
	{
		List<WebElement> element = driver.findElements(By.xpath("//div[@id = 'action_items']"));
		if(element.size() > 0)
			Assert.assertFalse(actionDropDown.isDisplayed());
	}
	public void editSubAssignments()
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 10);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", actionDetails);
			wait.until(ExpectedConditions.visibilityOf(editAssignment));
			editAssignment.click();
		}
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());	
		}
	}

	public void clearSearch()
	{
		try
		{
		Thread.sleep(5000);	
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(searchClear));
		wait.until(ExpectedConditions.elementToBeClickable(searchClear));
		searchClear.click();
		Thread.sleep(5000);	
			
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	public void pageLoad()
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
	     
	      int m=0;
	      String pageValue = js.executeScript("return document.readyState").toString();
			
	      while(!(pageValue.equalsIgnoreCase("complete")))
	      {
				pageValue = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				else
				{
					int loadcounter=pagload-5;
					try
					{
						if(m>loadcounter)
						{
							Thread.sleep(1000);
							System.out.println("wait "+m);
						}
					}
					catch(Exception e)
					{
						
					}
				}
				m++;
			}
	}
	
	public void AdminOrgEmailid()
	{
		 userEmail=adminEmailid;

	}

	public void ElementWait(WebElement e)
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
	     
	      int m=0;
	
	      while(m==10)
	      {
	    	  try
	    	  {
	    			wait.until(ExpectedConditions.visibilityOf(e));
	    			break;
	    	  }
	    	  catch(Exception s)
	    	  {
	    		  
	    	  }
	    	  m++;
	      }
	}
	public int getuserNumber()
	{
	  return driver.findElements(By.xpath("//*[@id=\"learnerTableList\"]/tbody/tr")).size();
	}
	public void unenrollAllRecurenceAssignments()
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 10);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			Thread.sleep(5000);
			System.out.println(assigment+Assignments.AssgnmentName+actionItem);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(assigment+Assignments.AssgnmentName+actionItem))));
			driver.findElement(By.xpath(assigment+Assignments.AssgnmentName+actionItem)).click();
			
			wait.until(ExpectedConditions.visibilityOf(unenrollCheckBox));
			
			unenrollCheckBox.click();
		
	
			wait.until(ExpectedConditions.visibilityOf(unenrollAllRecurrence));
			unenrollAllRecurrence.click();
			wait.until(ExpectedConditions.visibilityOf(unenrollCourseDeleteYes));
			unenrollCourseDeleteYes.click();
			
	Thread.sleep(5000);
				
			
			wait.until(ExpectedConditions.visibilityOf(unenrollsuccessmsg));
			System.out.println(unenrollsuccessmsg.getText());
			Assert.assertTrue(unenrollsuccessmsg.getText().contains("Course has been successfully unenrolled."));
			wait.until(ExpectedConditions.visibilityOf(successCloseButton));
			successCloseButton.click();
		
		}
		catch (Exception e) 
		{
			
		}
	}
	public void clickEditUserFromViewPage()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(editViewDetails));
		editViewDetails.click();
	}
	public void enterUserDetails(String fname, String lName, String id)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(firstNameText));
		firstNameText.sendKeys(fname);
		lastNameText.sendKeys(lName);
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		System.out.println(formatDate + "&&" + date);
		if(userId!=null)
			User.data.put("userId", userId);
		userId =  date ;
		userIdText.sendKeys(userId);
		//formatDate = new java.util.Date().toString();
		date = date.replace(" ", "").replace(":", "").replace("-", "");
		fname = fname.replace(" ", "");
		lName = lName.replace(" ", "");
		userEmail =User.getUserEmail(date+id) ;
		existingUser=userEmail;
		userEmailText.sendKeys(userEmail);
		userFirstName = fname;
		userLastName = lName;
		System.out.println("User first name is " + userFirstName + " and last name is " + userLastName + 
				" with email" + userEmail);
	}
	
	public void enterUserDetails()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(firstNameText));
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		System.out.println(formatDate + "&&" + date);
		if(userId!=null)
			User.data.put("userId", userId);
		userId =  date ;
		userIdText.sendKeys(userId);
		//formatDate = new java.util.Date().toString();
		date = date.replace(" ", "").replace(":", "").replace("-", "");
	
		firstNameText.sendKeys(date+"F");
		lastNameText.sendKeys(date+"L");
	
	
		userEmail =User.getUserEmail(date) ;
		existingUser=userEmail;
		userEmailText.sendKeys(userEmail);
		userFirstName = date+"F";
		userLastName = date+"L";
		addUnitLink.click();
        Select select = new Select(levelDropdown);
        wait.until(ExpectedConditions.visibilityOf(levelDropdown));
        select.selectByVisibleText("Level " + 2);
        WebElement unitLevelInformation = driver.findElement(By.xpath(unitInformation + 2 + "']"));
        select = new Select(unitLevelInformation);
        select.selectByVisibleText(  OrganizationSettings.	newUnitName);
        levelDropdownSubmitButton.click();
		System.out.println("User first name is " + userFirstName + " and last name is " + userLastName + 
				" with email" + userEmail);
	}
	
	public void enterUserDetailssameuser(String fname, String lName, String id)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(firstNameText));
		firstNameText.sendKeys(fname);
		lastNameText.sendKeys(lName);
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		System.out.println(formatDate + "&&" + date);
		//formatDate = new java.util.Date().toString();
		date = date.replace(" ", "").replace(":", "").replace("-", "");
		fname = fname.replace(" ", "");
		lName = lName.replace(" ", "");
		if(userId==null)
			userId =  date ;
			
		userIdText.sendKeys(userId);
			
		if(userEmail==null)
		userEmail = User.getUserEmailid(date+id);
	
		existingUser=userEmail;
		userEmailText.sendKeys(userEmail);
		System.out.println(userEmail);
	}
	

	
	
	public void enterUserDetails(String fname, String lName, String id,String level,String unitlevel)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(firstNameText));
		firstNameText.sendKeys(fname);
		lastNameText.sendKeys(lName);
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		System.out.println(formatDate + "&&" + date);
		userId =  date ;
		userIdText.sendKeys(userId);
		//formatDate = new java.util.Date().toString();
		date = date.replace(" ", "").replace(":", "").replace("-", "");
		fname = fname.replace(" ", "");
		lName = lName.replace(" ", "");
	
		existingUser=User.getUserEmail(date+id) ;
		userEmailText.sendKeys(existingUser);
		System.out.println(existingUser);
		
		add.click();
		wait.until(ExpectedConditions.visibilityOf(levl));
		
		Select select = new Select(levl);
		
		levl.click();
		select.selectByVisibleText(level);
		
		wait.until(ExpectedConditions.visibilityOf(unitLevel));
		
		 select = new Select(unitLevel);
		
		unitLevel.click();
		
		select.selectByVisibleText(unitlevel);
		
		saveBtn.click();
	}
	public void validateAddAssignmentDuplicatePopupMessage(String message)
	{
		if(AssignmentReport.checkifParmeterAvailable(message))
			message=AssignmentReport.getParmeterAvailable(message);

		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(selectAssignmentDrop));
        selectAssignmentDrop.click();
        Select select = new Select(selectAssignmentDrop);
        select.selectByVisibleText(Assignments.AssgnmentName);;
		wait.until(ExpectedConditions.visibilityOf(assignmentClose));
		wait.until(ExpectedConditions.visibilityOf(addAssignmentDuplicateMessage));
		String actualMessage = addAssignmentDuplicateMessage.getText().trim();
		System.out.println(actualMessage);
		System.out.println(message);
		Assert.assertTrue(actualMessage.trim().contains(message.trim()));
	;
	}
	public void clickAddAssignmentButton()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(addAssignmentButton));
		addAssignmentButton.click();
	}
	
	public void closeAddAssignmentPopup()
	{
		wait.until(ExpectedConditions.visibilityOf(assignmentClose));
		assignmentClose.click();
	}
	public void existingEmailID()
	{
		userEmail = existingUser;
		
	}
	public void loginEmailID()
	{
		userEmail = loginEmail;
		
	}
	public void checklevelnotavalible(String level,String unitlevel)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		
        add.click();
		
		Select select = new Select(levl);
		wait.until(ExpectedConditions.visibilityOf(levl));
		levl.click();
	
	     	select.selectByVisibleText(level);
		
		    select = new Select(unitLevel);
			wait.until(ExpectedConditions.visibilityOf(unitLevel));
			
			try
			{
			unitLevel.click();
			select.selectByVisibleText(unitlevel);
			}
			catch(Exception e)
			{
				System.out.println("Unit should not available");
			}
			
		
		
	}
	public void enterUserDetail(String fname, String lName,String email)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(firstNameText));
		firstNameText.sendKeys(fname);
		lastNameText.sendKeys(lName);
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		System.out.println(formatDate + "&&" + date);
		userId =email;
		userIdText.sendKeys(userId);
		//formatDate = new java.util.Date().toString();
		date = date.replace(" ", "").replace(":", "").replace("-", "");
		fname = fname.replace(" ", "");
		lName = lName.replace(" ", "");
		userEmail = email;
		existingUser=userEmail;
		userEmailText.sendKeys(userEmail);
		System.out.println(userEmail);
	}
	
	public void enterUserDetailsWithSymbols(String fname, String lName, String id, String symbol)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(firstNameText));
		firstNameText.sendKeys(fname);
		lastNameText.sendKeys(lName);
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		System.out.println(formatDate + "&&" + date);
		userId = id + "_" + date;
		userIdText.sendKeys(userId);
		date = date.replace(" ", "").replace(":", "").replace("-", "");
		userEmail =User.getUserEmail(symbol + date);
		userEmailText.sendKeys(userEmail);
	}
	public void enterUserDetailsWithUnitLevel(String fname, String lName, int level)
    {
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.visibilityOf(firstNameText));
        firstNameText.sendKeys(fname);
        lastNameText.sendKeys(lName);
        Date formatDate = new java.util.Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String date = formatter.format(formatDate);
        date = date.replace(" ", "").replace(":", "").replace("-", "");
        fname = fname.replace(" ", "");
        lName = lName.replace(" ", "");
        userEmail =User.getUserEmail(date) ;
        userEmailText.sendKeys(userEmail);
        userId = userEmail;
        userIdText.sendKeys(userId);
        addUnitLink.click();
        Select select = new Select(levelDropdown);
        wait.until(ExpectedConditions.visibilityOf(levelDropdown));
        select.selectByVisibleText("Level " + level);
        WebElement unitLevelInformation = driver.findElement(By.xpath(unitInformation + level + "']"));
        select = new Select(unitLevelInformation);
        select.selectByVisibleText("Automation Test");
        levelDropdownSubmitButton.click();
    }
	public void clickOnSubmit()
	{
		wait.until(ExpectedConditions.visibilityOf(submitButton));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", submitButton);
	}
	public void enterUserDetailsAlphabeticEmail(String fname, String lName, String id)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(firstNameText));
		firstNameText.sendKeys(fname);
		lastNameText.sendKeys(lName);
		Date formatDate = new Date();
		String date = formatDate.toString().replace(" ", "").toLowerCase();
		System.out.println(formatDate + "&&" + date);
		if(userId!=null)
        {
			userId1 = id + "_" + date;
			userIdText.sendKeys(userId1);
        }
		else
		{
			userId = id + "_" + date;
			userIdText.sendKeys(userId);
		}
		//formatDate = new java.util.Date().toString();
		date = date.replace(" ", "").replace(":", "").replace("-", "");
		fname = fname.replace(" ", "");
		lName = lName.replace(" ", "");
		userEmail =User.getUserEmail(date);
		userEmailText.sendKeys(userEmail);
		System.out.println(userEmail);
	}
	public void validateRemoveGroupPopupMessage(String message)
	{
		if(AssignmentReport.checkifParmeterAvailable(message))
			message=AssignmentReport.getParmeterAvailable(message);
      
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(removeGroupForAllPopupHeader));
		wait.until(ExpectedConditions.visibilityOf(removeAssignmentMessage));
		String actualMessage = removeAssignmentMessage.getText().trim();
		System.out.println(actualMessage);
		Assert.assertTrue(actualMessage.equalsIgnoreCase(message));
	}
	public void validateCourseCountRemoveGroupPopup(int count)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		if(count > 0)
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(allGroupName)));
		List<WebElement> groupList = driver.findElements(By.xpath(allGroupName));
		System.out.println("Total course available for remove is " + groupList.size());
		Assert.assertTrue(groupList.size() == count);
	}
	public void clickRemoveGroupButton()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(removeGroupButton));
		removeGroupButton.click();
	}
	public void validateCourseListRemoveGroupPopup(String groups)
	{
		int counter = 0;
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(allGroupName)));
		List<WebElement> courseList = driver.findElements(By.xpath(allGroupName));
		String group[] = groups.split(",");
		for(int start = 0; start <= group.length - 1; start++)
		{
			for(int i = 1; i <= courseList.size(); i++)
			{
				String text = driver.findElement(By.xpath("(" + allGroupName + ")[" + i + "]")).getText().trim();
				if(text.equalsIgnoreCase(group[start].trim()))
				{
					driver.findElement(By.xpath("(" + allGroupName + ")[" + i + "]")).click();
					counter = counter + 1;
				}
			}
		}
		Assert.assertTrue(counter == group.length);
	}

	public void closeAddGroupPopup()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(closeButton));
		closeButton.click();
	}
	
	public void clickAddGroupButton()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(addGroupButton));
		addGroupButton.click();
	}
	public void selectGroupDropdown(String course)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(selectGroupDrop));
		Select select = new Select(selectGroupDrop);
		select.selectByVisibleText(course.trim());
	}
	public void validateAddGroupPopupMessage(String message)
	{
		if(AssignmentReport.checkifParmeterAvailable(message))
			message=AssignmentReport.getParmeterAvailable(message);
      
		WebDriverWait wait = new WebDriverWait(driver, 30);
//		wait.until(ExpectedConditions.visibilityOf(addGroupButton));
		
		
		if(message.contains("remaining"))
		{
			wait.until(ExpectedConditions.visibilityOf(addGroupForAllWarning));
		
			System.out.println("Validate error msg :"+addGroupForAllWarning.getText());
			Assert.assertEquals(addGroupForAllWarning.getText(),message);
			
		}
	
		else	if(message.contains("already"))
			{
				wait.until(ExpectedConditions.visibilityOf(addGroupAlready));
			
				System.out.println("Validate error msg :"+addGroupAlready.getText());
				Assert.assertEquals(addGroupAlready.getText(),message);
				
			}
		 else
		 {
				wait.until(ExpectedConditions.visibilityOf(addAssignmentMessage));
				
		 String actualMessage = addAssignmentMessage.getText().trim();
			
		System.out.println(actualMessage);
		System.out.println(message);
		Assert.assertTrue(actualMessage.equalsIgnoreCase(message));
		 }
	}
	
	public void validateCourseCountAddGroupPopup(int count)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		if(count > 0)
		{
			wait.until(ExpectedConditions.visibilityOf(selectGroupDrop));
			Select select = new Select(selectGroupDrop);
			List<WebElement> dropdown = select.getOptions();
			System.out.println("Total group available for add is " + dropdown.size());
			Assert.assertTrue(dropdown.size() == count + 1);
		}
			
		
	}
	public void validateAddGroupNames(String courses)
	{
		int counter = 0;
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(selectGroupDrop));
		Select select = new Select(selectGroupDrop);
		List<WebElement> dropdown = select.getOptions();
		String course[] = courses.split(",");
		for(int start = 0; start <= course.length - 1; start++)
		{
		for(int i =0; i<dropdown.size() ; i++)
			{
	         	String text = dropdown.get(i).getText();
	         	if(text.equalsIgnoreCase(course[start].trim()))
				{
					counter = counter + 1;
				}
			}
		}
		Assert.assertTrue(counter == course.length);
	}
	public void selectAddGroupOption()
	{
		wait.until(ExpectedConditions.visibilityOf(addGroupForAll));
		addGroupForAll.click();
	}
	
	
	public boolean checkCSVFilePresent()
	{
		std = new Students();
		boolean dwnld = std.isFileDownloaded_Ext(downloadPath, ".csv");
		return dwnld;
	}
	public void validateActionDropdownOptions(String options)
	{
		String allOptionList[] = options.split(",");
		int counter = 0;
		List<WebElement> element = driver.findElements(By.xpath("//div[@id = 'action_items']//li/a"));
		if(element.size() != 4)
			Assert.fail("Option count is more than 4");
		for(int i = 0; i <= allOptionList.length - 1; i++)
		{
			for(int j = 0; j <= element.size() - 1; j++)
			{
				String actualOption = element.get(j).getText().toString().trim();
//				System.out.println(actualOption);
//				System.out.println(allOptionList[i].trim());
				if(actualOption.equalsIgnoreCase(allOptionList[i].trim()))
				{
					counter = counter + 1;
					break;
				}
			}
		}
		
		Assert.assertTrue(counter == allOptionList.length);
		
	}
	public void closeRemoveGroupButton()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(assignmentClose));
		assignmentClose.click();
	}
	
	public void deleteUserDetails()
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			navigateUserModule();
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(deleteUser));
			deleteUser.click();
			wait.until(ExpectedConditions.visibilityOf(deleteYesButton));
			deleteYesButton.click();
			pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(noRecordPresent));
			Assert.assertTrue(noRecordPresent.isDisplayed());
			
		}
		catch (Exception e) 
		{
			
		}
	}
	public void deleteUserDetails(String msg)
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			navigateUserModule();
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(deleteUser));
			deleteUser.click();
			wait.until(ExpectedConditions.visibilityOf(deleteYesButton));
			deleteYesButton.click();
			orgHome.successmsg(msg);
			pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			
			wait.until(ExpectedConditions.visibilityOf(noRecordPresent));
			Assert.assertTrue(noRecordPresent.isDisplayed());
			
		}
		catch (Exception e) 
		{
			
		}
	}
	
	public void deleteUserDetailsWithoutAssertion()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		String val = js.executeScript("return document.readyState").toString();
		int m=0;
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			else
			{
				try
				{
				Thread.sleep(1000);	
				}
				catch(Exception e)
				{
					
				}
			}
			m++;
		}
		navigateUserModule();
		wait.until(ExpectedConditions.visibilityOf(searchClear));
		wait.until(ExpectedConditions.elementToBeClickable(searchClear));
		wait.until(ExpectedConditions.elementToBeClickable(searchClear));

		searchClear.click();
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			else
			{
				try
				{
				Thread.sleep(1000);	
				}
				catch(Exception e)
				{
					
				}
			}
			m++;
		}
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(deleteUser));
		deleteUser.click();
		wait.until(ExpectedConditions.visibilityOf(deleteYesButton));
		deleteYesButton.click();
		val = js.executeScript("return document.readyState").toString();
		 m=0;
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			m++;
		}
	}	

	public void clickImportData()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(importDataLink));
		wait.until(ExpectedConditions.elementToBeClickable(importDataLink));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		
		executor.executeScript("arguments[0].click();", importDataLink);
	}
	
	 public void prepareFileForMultipleValidation(int level)
	    {
	        boolean dwnld = false;
	        int m=0;
	        do
	        {
	            dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
	            if(m==pagload)
					break;
				else
				{
					try {
						Thread.sleep(550);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				m++;
	        }
	        while(dwnld == false);
	        addMultipleValidationData(level);
	        readandUpdateFile();        
	    }
	
	 
	  public void addMultipleValidationData(int count)
	    {
	        try
	        {
	            String level = "";
	            String nextLine[] = null;
	            String characters = "._-'";
	            String chars[]  = characters.split("");
	            int m=0;
	            boolean dwnld = false;
	            do
	            {
	                dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
	                if(m==pagload)
	    				break;
	    			else
	    			{
	    				try {
	    					Thread.sleep(550);
	    				} catch (InterruptedException e) {
	    					// TODO Auto-generated catch block
	    					e.printStackTrace();
	    				}
	    			}
					m++;
	            }
	            while(dwnld == false);
	            Thread.sleep(3000);
	            File file = new File(filePath);
	            FileReader filereader = new FileReader(file);
	            CSVReader csvReader = new CSVReader(filereader);
	            String header[] = csvReader.readNext();
	            CSVWriter writer = new CSVWriter(new FileWriter(filePath));
	            DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
	            Calendar cal = Calendar.getInstance();
	            String emailDate = dateFormat.format(cal.getTime());
	            String formattedEmail = emailDate.replace(":", "");
	            email =User.getUserEmail(formattedEmail);
	            String data[] = {email, "Ansh", "", "G", email, "", "", "", "Active", "", "","","",""};
	            List<String[]> list = new ArrayList<String[]>();
	            list.add(header);
	            String dataLevel [] = null;
	            if(count > 1)
	            {
	                for(int i = 2; i <= count; i++ )
	                    {
	                        String id = Integer.toString(i);
	                        String name = "level_" + i;
	                        level = level + id + "," + name;
	                        if(i<count)
	                            level = level + ",";
	                    }
	                dataLevel = level.split(",");
	                nextLine = new String[data.length + dataLevel.length];
	                System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
	                System.arraycopy(data, 0, nextLine, dataLevel.length, data.length);
	            }
	            list.add(nextLine);
	            list.add(nextLine); //add the duplicate row
//	            email = "Auto.G" + formattedEmail + "@yopmail.com";
	            
	            String editDuplicate[] = {email, "Anshupdate", "testtt", "Gg ", User.getUserEmail(formattedEmail), "job1", "job2", "", "Active", "11/11/2000", "Male","4","11/11/2010","11/11/2025"}; //edit the email for duplicate entry
	            nextLine = new String[editDuplicate.length + dataLevel.length];
	            System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
	            System.arraycopy(editDuplicate, 0, nextLine, dataLevel.length, editDuplicate.length);
	            list.add(nextLine);
	            nextLine = new String[data.length + dataLevel.length];
	            list.add(nextLine);
	            Thread.sleep(1000);
	             emailDate = dateFormat.format(cal.getTime());
	             formattedEmail = emailDate.replace(":", "");
	            email =User.getUserEmail(formattedEmail);
	           
	            String inactive[] = {email, "Anshupdate", "testtt", "Gg ",User.getUserEmail() , "job1", "job2", "", "Inactive", "11/11/2000", "Female","4","11/11/2010","11/11/2025"}; //edit the email for duplicate entry
	            nextLine = new String[inactive.length + dataLevel.length];
	            System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
	            System.arraycopy(inactive, 0, nextLine, dataLevel.length, inactive.length);
	            list.add(nextLine);
	            //////////////////////////////////////////edited all the details of user in/////////////////////////////////////////////////////
	            Thread.sleep(1000);
	             cal = Calendar.getInstance();
		         emailDate = dateFormat.format(cal.getTime());
	             formattedEmail = emailDate.replace(":", "");
	            email = User.getUserEmail(formattedEmail);
	            String data2[] = {email, "Anshupdate", "testtt", "Gg ", User.getUserEmail(), "job1", "job2", "", "Active", "11/11/2000", "Female","4","11/11/2010","11/11/2025"}; //edit the email for duplicate entry
	            nextLine = new String[data2.length + dataLevel.length];
	            System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
	            System.arraycopy(data2, 0, nextLine, dataLevel.length, data2.length);
	            list.add(nextLine);
	            
	            email = User.getUserEmail(formattedEmail);
	            String  data5[] = {email, "testupdate", "tett", "Test",  User.getUserEmail(), "job2021", "job2021", "", "Active", "11/11/2001", "Male","5","11/11/2011","11/11/2026"}; //edit the email for duplicate entry
	            nextLine = new String[data2.length + dataLevel.length];
	            System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
	            System.arraycopy(data5, 0, nextLine, dataLevel.length, data5.length);
	            list.add(nextLine);
	            
	            /////////////////////////////////Multipe user with same email ///////////////////////////////////////////////////////
	            email = User.getUserEmail(formattedEmail);;
	            String  data6[] = {email, "testu", "tett", "Test",  User.getUserEmail(), "job2021", "job2021", "", "Active", "11/11/2001", "Male","5","11/11/2011","11/11/2026"}; //edit the email for duplicate entry
	            nextLine = new String[data6.length + dataLevel.length];
	            System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
	            System.arraycopy(data6, 0, nextLine, dataLevel.length, data6.length);
	            list.add(nextLine);
	            
	            ////////////////////Creation of CTC  user without emailid//////////////////////
	            Thread.sleep(1000);
	             cal = Calendar.getInstance();
		         emailDate = dateFormat.format(cal.getTime());
	             formattedEmail = emailDate.replace(":", "");
	            email = User.getUserEmail(formattedEmail);;
	            String data3[] = {email, "Anshupdate", "testtt", "Gg ", "" ,"job1", "job2", "", "Inactive", "11/11/2000", "Female","4","11/11/2010","11/11/2025"}; //edit the email for duplicate entry
	            nextLine = new String[data3.length + dataLevel.length];
	            System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
	            System.arraycopy(data3, 0, nextLine, dataLevel.length, data3.length);
	            list.add(nextLine);
	            
	            ////////////////////Mandatory fiels blank//////////////////////
	            Thread.sleep(1000);
	             cal = Calendar.getInstance();
		         emailDate = dateFormat.format(cal.getTime());
	             formattedEmail = emailDate.replace(":", "");
	             email = User.getUserEmail(formattedEmail);
	            String data4[] = {"", "", "", "Gg ", User.getUserEmail() ,"", "", "", "", "", "","","",""}; //edit the email for duplicate entry
	            nextLine = new String[data4.length + dataLevel.length];
	            System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
	            System.arraycopy(data4, 0, nextLine, dataLevel.length, data4.length);
	            list.add(nextLine);
	            ////////////////////Only mandatory fields//////////////////////
		          
	            Thread.sleep(1000);
	             cal = Calendar.getInstance();
		         emailDate = dateFormat.format(cal.getTime());
	             formattedEmail = emailDate.replace(":", "");
	             email = User.getUserEmail(formattedEmail);
		          
	            String row1[] = {"","","","",email, "Ansh" + 4, "", "test", email, "", "", "", "Active", "", "","","",""}; //left last name(mandatory) as empty
	            list.add(row1);
	            
	            ////////////////////same depratment name(dpt1) under different institutions(inst2 and inst3)//////////////////////
		          
	            Thread.sleep(1000);
	             cal = Calendar.getInstance();
		         emailDate = dateFormat.format(cal.getTime());
	             formattedEmail = emailDate.replace(":", "");
	             email = User.getUserEmail(formattedEmail);
		         
	            String row2[] = {"inst3","inst3","dpt1","dpt1",email, "Ansh" + 4, "", "test", email, "", "", "", "Active", "", "","","",""}; //left last name(mandatory) as empty
	            list.add(row2);
	            
	            ////////////////////Level2 is mandatory//////////////////////
		          
	            Thread.sleep(1000);
	             cal = Calendar.getInstance();
		         emailDate = dateFormat.format(cal.getTime());
	             formattedEmail = emailDate.replace(":", "");
	             email = User.getUserEmail(formattedEmail);
		         
	            String row3[] = {"","","dpt1","dpt1",email, "Ansh" + 4, "", "test", email, "", "", "", "Active", "", "","","",""}; //left last name(mandatory) as empty
	            list.add(row3);
	            
	            
	           ////////////////////only level name//////////////////////
		          
            Thread.sleep(1000);
             cal = Calendar.getInstance();
	         emailDate = dateFormat.format(cal.getTime());
             formattedEmail = emailDate.replace(":", "");
             email = User.getUserEmail(formattedEmail);
	         
            String row4[] = {"","inst3","","dpt1",email, "Ansh" + 4, "", "test", email, "", "", "", "Active", "", "","","",""}; //left last name(mandatory) as empty
            list.add(row4);
            
	    
            ////////////////////only level code//////////////////////
	          
            Thread.sleep(1000);
             cal = Calendar.getInstance();
	         emailDate = dateFormat.format(cal.getTime());
             formattedEmail = emailDate.replace(":", "");
             email = User.getUserEmail(formattedEmail);
	         
            String row5[] = {"inst3","","dpt1","",email, "Ansh" + 4, "", "test", email, "", "", "", "Active", "", "","","",""}; //left last name(mandatory) as empty
            list.add(row5);
            
	            
	            
	            String row[] = {"1", "Ansh" + 4, "", "", email, "", "", "", "Active", "", "","","",""}; //left last name(mandatory) as empty
	            nextLine = new String[row.length + dataLevel.length];
	            System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
	            System.arraycopy(row, 0, nextLine, dataLevel.length, row.length);        
	            list.add(nextLine);
	            dateFormat = new SimpleDateFormat("MM-dd-yyyy");
	            String hireDate = dateFormat.format(cal.getTime());
	            String onlyOptional[] = {"", "", "MiddleName", "", email, "", "", hireDate, "",  "", "","","",""}; //only optional fields
	            nextLine = new String[onlyOptional.length + dataLevel.length];
	            System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
	            System.arraycopy(onlyOptional, 0, nextLine, dataLevel.length, onlyOptional.length);        
	            list.add(nextLine);
	            for(int i=2; i<= 1 + chars.length; i++) // for special characters
	            {
	                String specialChar[] = {String.valueOf(i), "Ansh" + i, "", "G" + i, User.getUserEmail(chars[i-2]+formattedEmail) , "", "", "", "Active", "", "","","",""};
	                nextLine = new String[row.length + dataLevel.length];
	                System.arraycopy(dataLevel, 0, nextLine, 0, dataLevel.length);
	                System.arraycopy(specialChar, 0, nextLine, dataLevel.length, specialChar.length);
	                list.add(nextLine);
	            }
	            writer.writeAll(list);
	            writer.flush();
	            filereader.close();
	            csvReader.close();
	    }
	        catch (Exception e)
	        {
	        e.printStackTrace();
	    	Assert.fail(e.getMessage());
	        }
	    }

	
	public void addAdminAccess(String levl,String option,String Role) throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		String val = js.executeScript("return document.readyState").toString();
		int m=0;
		while(!(val.equalsIgnoreCase("complete")))
		{
			val = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			m++;
			
		}
		if(AssignmentReport. checkifParmeterAvailable(option+prop.getProperty("environment")))
			option=AssignmentReport.getParmeterAvailable(option+prop.getProperty("environment"));

		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(orgStructure));
		Select level = new Select(orgStructure);
		level.selectByValue("2");
		Thread.sleep(3000);
		
		levelclick.click();
		if(option.contains("Select All"))
			driver.findElement(By.xpath("//a[text()='Select all']")).click();
		else
		driver.findElement(By.xpath("//input[contains(@title,'"+option+"')]")).click();
		
		Thread.sleep(3000);
		levelclick.click();
		
		
		driver.findElement(By.xpath("//*[@data-rolename='"+Role+"']")).click();
		
		Thread.sleep(3000);
		addAdminBtn.click();
		
		Thread.sleep(5000);
		
//		need to updte
		driver.findElement(By.xpath("//*[@id=\"submit_btn\"]")).click();
		
		

		Thread.sleep(5000);
		
		
	
	}

	public void userSearch(String unitName)
	{
		try 
		{
			navigateUserModule();
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchClear));
			wait.until(ExpectedConditions.elementToBeClickable(searchClear));
			searchClear.click();
			wait.until(ExpectedConditions.visibilityOf(searchText));
			wait.until(ExpectedConditions.elementToBeClickable(searchText));
			System.out.println("unit name is " + unitName);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", searchText);
			wait.until(ExpectedConditions.elementToBeClickable(searchinputText));
			if(unitName=="")
			searchinputText.sendKeys(userEmail);
			else
				searchinputText.sendKeys(unitName);
				
			executor.executeScript("arguments[0].click();", searchButton);
			
			
			js = (JavascriptExecutor)driver;
			pageValue = js.executeScript("return document.readyState").toString();
			 m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(10000);
		} 
		catch (Exception e) 
		{
			
		}
	}

	public void userSearchemail(String unitName)
	{
		try 
		{
			if(AssignmentReport. checkifParmeterAvailable(userEmail))
				userEmail=AssignmentReport.getParmeterAvailable(userEmail);
	
			navigateUserModule();
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchClear));
			wait.until(ExpectedConditions.elementToBeClickable(searchClear));
			searchClear.click();
			wait.until(ExpectedConditions.visibilityOf(searchText));
			wait.until(ExpectedConditions.elementToBeClickable(searchText));
			System.out.println("unit name is " + unitName);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", searchText);
			wait.until(ExpectedConditions.elementToBeClickable(searchinputText));
			if(unitName=="")
			searchinputText.sendKeys(userEmail);
			else
				searchinputText.sendKeys(unitName);
				
			executor.executeScript("arguments[0].click();", searchButton);
			wait.until(ExpectedConditions.visibilityOf(searchResultUnitName[searchResultUnitName.length-1]));
			String result = searchResultUnitName[searchResultUnitName.length-1].getText();
			Assert.assertEquals(unitName, result);
			js = (JavascriptExecutor)driver;
			pageValue = js.executeScript("return document.readyState").toString();
			 m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(10000);
		} 
		catch (Exception e) 
		{
			
		}
	}


	public void usersearchEmail(String unitName)
	{
		try 
		{
				if(AssignmentReport. checkifParmeterAvailable(unitName))
					 unitName=AssignmentReport.getParmeterAvailable(unitName);
		
			
//			navigateUserModule();
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchClear));
			wait.until(ExpectedConditions.elementToBeClickable(searchClear));
			searchClear.click();
			wait.until(ExpectedConditions.visibilityOf(searchText));
			wait.until(ExpectedConditions.elementToBeClickable(searchText));
			System.out.println("unit name is " + unitName);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", searchText);
			wait.until(ExpectedConditions.elementToBeClickable(searchinputText));
			if(unitName=="")
			searchinputText.sendKeys(userEmail);
			else
				searchinputText.sendKeys(unitName);
				
			executor.executeScript("arguments[0].click();", searchButton);
			wait.until(ExpectedConditions.visibilityOf(searchResultUnitName[searchResultUnitName.length-1]));
			String result = searchResultUnitName[searchResultUnitName.length-1].getText();
			Assert.assertEquals(unitName, result);
			js = (JavascriptExecutor)driver;
			pageValue = js.executeScript("return document.readyState").toString();

      		driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
      		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
      		Thread.sleep(12000);
			
			 m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				
			}
			
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
			}
        
			
		} 
		catch (Exception e) 
		{
			
		}
	}

	public void userssearchEmail(String unitName)
	{
		try 
		{
				if(AssignmentReport. checkifParmeterAvailable(unitName))
					 unitName=AssignmentReport.getParmeterAvailable(unitName);
		
			
//			navigateUserModule();
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchClear));
			wait.until(ExpectedConditions.elementToBeClickable(searchClear));
			searchClear.click();
			wait.until(ExpectedConditions.visibilityOf(searchText));
			wait.until(ExpectedConditions.elementToBeClickable(searchText));
			System.out.println("unit name is " + unitName);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", searchText);
			wait.until(ExpectedConditions.elementToBeClickable(searchinputText));
			if(unitName=="")
			searchinputText.sendKeys(userEmail);
			else
				searchinputText.sendKeys(unitName);
				
			executor.executeScript("arguments[0].click();", searchButton);
			js = (JavascriptExecutor)driver;
			pageValue = js.executeScript("return document.readyState").toString();

      		driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
      		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
      		
			 m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				
			}
			
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading"))
			{
				val = pageLoad.getAttribute("class");
			}
        
			
		} 
		catch (Exception e) 
		{
			
		}
	}

	public void usersearchEmailwithoutclearing(String unitName)
	{
		try 
		{
//			navigateUserModule();
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
//			WebDriverWait wait = new WebDriverWait(driver, 30);
//			wait.until(ExpectedConditions.visibilityOf(searchClear));
//			wait.until(ExpectedConditions.elementToBeClickable(searchClear));
//			searchClear.click();
			wait.until(ExpectedConditions.visibilityOf(searchText));
			wait.until(ExpectedConditions.elementToBeClickable(searchText));
			System.out.println("unit name is " + unitName);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", searchText);
			wait.until(ExpectedConditions.elementToBeClickable(searchinputText));
			if(unitName=="")
			searchinputText.sendKeys(userEmail);
			else
				searchinputText.sendKeys(unitName);
				
			executor.executeScript("arguments[0].click();", searchButton);
			wait.until(ExpectedConditions.visibilityOf(searchResultUnitName[searchResultUnitName.length-1]));
			String result = searchResultUnitName[searchResultUnitName.length-1].getText();
			Assert.assertEquals(unitName, result);
			
			
		} 
		catch (Exception e) 
		{
			
		}
	}
	public void addAdminAccessisnotAvailable()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(addadmin));
			Assert.fail("Add Admin Access is available");
		}
		catch(Exception e)
		{
			System.out.println("Add Admin Access is not available");
		}
	}
	
	


	public void editandunenrolloption()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			try
			{
				
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"productInner\"]/tr/td[8]/div/a"))));
				driver.findElement(By.xpath("//*[@id=\"productInner\"]/tr/td[8]/div/a")).click();
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"productInner\"]//a[text()='Edit Assignment']"))));
			Assert.fail("Add Admin Access is available");
			}
			catch(Exception e)
			{
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"productInner\"]//a[text()='Unenroll Assignment']"))));
				Assert.fail("Add Admin Access is available");
				  	
			}
		}
		catch(Exception e)
		{
			System.out.println("Add Admin Access is not available");
		}
	}
	
	public void viewDetailViewAssigmentoption()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			try
			{
				
				
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"productInner\"]//a[text()='View Activity Details']"))));
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"productInner\"]//a[text()='View Assignment']"))));
			
			}
			catch(Exception e)
			{
				Assert.fail("Add Admin Access is available");
				  	
			}
		}
		catch(Exception e)
		{
			System.out.println("Add Admin Access is not available");
		}
	}
	public void validateDetailTable(String text) throws InterruptedException
	{
		Thread.sleep(5000);
		String[] rowvalue=text.split(",");
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)");
		for(int i=1;i<rowvalue.length;i++)
		{
			if(courseListName.containsKey(text.split(",")[i]))
			{
				text.split(",")[i]=courseListName.get(text.split(",")[i]).toString();
               System.out.println();
           	Assert.assertEquals(rowvalue[i], driver.findElement(By.xpath("//table[@id=\"activityTable\"]//tbody/tr/td[text()='"+text.split(",")[0]+"']/following::td[text()='"+courseListName.get(text.split(",")[i]).toString()+"'][1]")).getText());
    		}
			else
			Assert.assertEquals(rowvalue[i], driver.findElement(By.xpath("//table[@id=\"activityTable\"]//tbody/tr/td[text()='"+text.split(",")[0]+"']/following::td[text()='"+text.split(",")[i]+"'][1]")).getText());
		}
		
		
	}
	public void RowperNumber(String pageNumber) 
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Select drpState = new Select(driver.findElement(By.xpath("//*[@id=\"assignment_reports_length\"]/label/select")));
		drpState.selectByValue(pageNumber);
		
		
		try
		{
			Thread.sleep(5000);
				wait.until(ExpectedConditions.visibilityOf(	driver.findElement(By.xpath("(//table[@id=\"assignment_reports\"]//tbody//tr[@role='row'])"))));
				
			Assert.assertEquals(String.valueOf(driver.findElements(By.xpath("(//table[@id=\"assignment_reports\"]//tbody//tr[@role='row'])")).size()), pageNumber)	;
			
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
				
	}
	
	public void assignmentReportColumnsValidation(List<String> text, String tc) throws Exception
	{
		wait.until(ExpectedConditions.visibilityOf(moreFilter));
		moreFilter.click();
		Thread.sleep(3000);
		if(tc.equalsIgnoreCase("afterSearch")) {
			
			searchButton.click();
		}
		int count = 0;
		for(WebElement tt : AssignmentColumns){
			System.out.println(tt.getAttribute("innerText"));
			Assert.assertEquals(text.get(count).toUpperCase(), tt.getAttribute("innerText"));
			count++;
		}

	}
	public void Paginationoptions(String textopt,String pageNumber) 
	{
		try
		{
		if(textopt.contains("Top"))
		{
			
					
			wait.until(ExpectedConditions.visibilityOf(	driver.findElement(By.xpath("(//*[@class=\"paginate_button \" and text()='"+pageNumber+"'])[1]"))));
			
			driver.findElement(By.xpath("(//*[@class=\"paginate_button \" and text()='"+pageNumber+"'])[1]")).click();
					
		}
		else
		{
	       wait.until(ExpectedConditions.visibilityOf(	driver.findElement(By.xpath("(//*[@class=\"paginate_button \" and text()='"+pageNumber+"'])[2]"))));
	 		driver=driver;
			driver.findElement(By.xpath("(//*[@class=\"paginate_button \" and text()='"+pageNumber+"'])[2]")).click();
		
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	public void validateDetailAssignmentTable(String text) throws InterruptedException
	{
		Thread.sleep(5000);
		String[] rowvalue=text.split(";");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Select drpState = new Select(driver.findElement(By.xpath("//*[@id=\"assignment_reports_length\"]/label/select")));
		drpState.selectByValue("100");
//		js.executeScript("window.scrollBy(0,1000)");
//		usersearchEmail(text.split(";")[0]);
		
		System.out.println("Validating data:"+text);
			for(int i=1;i<rowvalue.length;i++)
		{
			String data;
			
//			js.executeScript("arguments[0].scrollIntoView();",select);
			
			
			try
			{
				Thread.sleep(5000);
				wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//table[@aria-describedby=\"assignment_reports_info\"]//tbody/tr/td[text()='"+text.split(";")[0]+"']/following::td[text()='"+text.split(";")[i]+"'][1]"))));
				
				
				data=driver.findElement(By.xpath("//table[@aria-describedby=\"assignment_reports_info\"]//tbody/tr/td[text()='"+text.split(";")[0]+"']/following::td[text()='"+text.split(";")[i]+"'][1]")).getText();
			}
			catch(Exception e)
			{
				data=	driver.findElement(By.xpath("(//table[@aria-describedby=\"assignment_reports_info\"]//tbody/tr/td[text()='"+text.split(";")[0]+"']/following::td//a[text()='"+text.split(";")[i]+"'])[1]")).getText();
			}
			Assert.assertEquals(rowvalue[i],data);
		}
		
		
	}
	
	
	public void validateDetailTableStudent(String text) throws InterruptedException
	{
		Thread.sleep(5000);
		String[] rowvalue=text.split(",");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)");
		for(int i=1;i<rowvalue.length;i++)
		{
			
//			js.executeScript("arguments[0].scrollIntoView();",select);
			Assert.assertEquals(rowvalue[i], driver.findElement(By.xpath("//table[@id=\"no_sort\"]//tbody/tr/td[text()='"+text.split(",")[0]+"']/following::td[text()='"+text.split(",")[i]+"'][1]")).getText());
		}
		
		
	}
	
	
		
	
	public void viewDetailViewcourse(String course)
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			try
			{
				
				if(courseListName.containsKey(course+"Option"))
					course=courseListName.get(course+"Option").toString();
				
				
				
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"productInner\"]/tr//td[contains(text(),'"+course+"')]//following::td[7]//a[@class=\"action_dropdown\"]"))));
			driver.findElement(By.xpath("//*[@id=\"productInner\"]/tr//td[contains(text(),'"+course+"')]//following::td[7]//a[@class=\"action_dropdown\"]")).click();
			
			Thread.sleep(4000);
			driver.findElement(By.xpath("//*[@id='productInner']/tr//td[contains(text(),'"+course+"')]//following::td[7]//a[@class='action_dropdown']//following::ul//li//a[text()='View Activity Details']")).click();
			Thread.sleep(4000);
			
			
			Assert.assertTrue(driver.findElement(By.xpath("//*[@id=\"viewActivityModal\"]//h5//span[@id=\"courseTitle\"]")).getText().contains(course));
			
			}
			catch(Exception e)
			{
				e.printStackTrace();
				  	
			}
		}
		catch(Exception e)
		{
			System.out.println("Add Admin Access is not available");
		}
	}

	public void navigateAssigment()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(assigmnBtn));
			assigmnBtn.click();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	public void navigateAssigment_Unenroll()
	{
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(assigmnBtn));
			assigmnBtn.click();
			
			wait.until(ExpectedConditions.visibilityOf(actionDrop));
			actionDrop.click();
			wait.until(ExpectedConditions.visibilityOf(unEnrollBtn));
			
			unEnrollBtn.click();
			wait.until(ExpectedConditions.visibilityOf(yesBtn));
			yesBtn.click();
			wait.until(ExpectedConditions.visibilityOf(successmsg));
			Assert.assertEquals("Assignments unenrolled successfully", successmsg.getText());
			wait.until(ExpectedConditions.visibilityOf(successCloseButton));
			successCloseButton.click();
		
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	public void clickonEnrollbtn()
	{
		reuse.waitforsec(4);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(assigment+Assignments.AssgnmentName+actionItem))));
		driver.findElement(By.xpath(assigment+Assignments.AssgnmentName+actionItem)).click();
		
//		wait.until(ExpectedConditions.visibilityOf(unEnrollBtn));
		
		unEnrollBtn.click();
	}
	
	public void clickonEnrollbtn(String Course)
	{
		
		String AssgnmentName= dataMap.get(Course+"Assignment");
		reuse.waitforsec(4);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(assigment+AssgnmentName+actionItem))));
		driver.findElement(By.xpath(assigment+AssgnmentName+actionItem)).click();
		
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(assigment+AssgnmentName+unenrollbtn))));
		
		driver.findElement(By.xpath(assigment+AssgnmentName+unenrollbtn)).click();
		
//		unEnrollBtn.click();
	}
	public void navigateAssigmentUnenroll()
	{
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(assigmnBtn));
			assigmnBtn.click();
//			wait.until(ExpectedConditions.visibilityOf(actionDrop));
//			actionDrop.click();
			Thread.sleep(5000);
			System.out.println(assigment+Assignments.AssgnmentName+actionItem);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(assigment+Assignments.AssgnmentName+actionItem))));
			driver.findElement(By.xpath(assigment+Assignments.AssgnmentName+actionItem)).click();
			
			wait.until(ExpectedConditions.visibilityOf(unEnrollBtn));
			
			unEnrollBtn.click();
			wait.until(ExpectedConditions.visibilityOf(unenrollCheckBox));
				
			unenrollCheckBox.click();
		
			wait.until(ExpectedConditions.visibilityOf(unenrollCourseDeleteYes));
			unenrollCourseDeleteYes.click();
			Thread.sleep(5000);
				
			
			wait.until(ExpectedConditions.visibilityOf(unenrollsuccessmsg));
			System.out.println(unenrollsuccessmsg.getText());
			Assert.assertTrue(unenrollsuccessmsg.getText().contains("The selected learner(s) have successfully been unenrolled from this assignment."));
			wait.until(ExpectedConditions.visibilityOf(successCloseButton));
			successCloseButton.click();
		
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	
	public void validateifAssigmentNamedisplay()
	{
		try 
		{
			if(driver.findElement(By.xpath(assigment+Assignments.AssgnmentName+actionItem)).isDisplayed())
			{
			Assert.fail("Assigment name should not display");
			}
			else	
			{
				System.out.println("Assignment is not display");
			}
			
			
		}
		catch(Exception e)
		{
			Assert.fail("Error occur");
			
		}
	}
	
	public void validateifnorecordisplayed()
	{
		try 
		{
			
			
			wait.until(ExpectedConditions.visibilityOf(norecordPresent));
			
			Assert.assertEquals("Assignment is not unenrolled", norecordPresent.getText(), "No Assignments are present.");
		}
		catch(Exception e)
		{
			Assert.fail("Error occur");
			
		}
	}
	
	
	public void navigateCertificates()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(CertificatesBtn));
			CertificatesBtn.click();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}

	
	
	public void navigateGroup()
	{
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(groupbtn));
			groupbtn.click();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	
	
	
	public void editUserDetails()
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(editDetails));
			editDetails.click();
			wait.until(ExpectedConditions.visibilityOf(editFirstName));
			Date formatDate = new java.util.Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String date = formatter.format(formatDate);
			date = date.replace(" ", "").replace(":", "").replace("-", "");
		
			String fName = editFirstName.getAttribute("value");
			String lName = editLastName.getAttribute("value");
			userEmail = User.getUserEmail(date) ;
			userEmailText.clear();
			userEmailText.sendKeys(userEmail);
			
			
			selectHiredate();
			middle_name.sendKeys("Middle_Update");
			phone.sendKeys("21211313");
			years_of_experience.sendKeys("2");
			editFirstName.click();
			editFirstName.clear();
			editFirstName.sendKeys(fName + " update");
			editLastName.click();
			editLastName.clear();
			editLastName.sendKeys(lName + " update");
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(submitButton));
			submitButton.click();
			
			System.out.println("Updated Successfully");
		} 
		catch (Exception e) 
		{
			submitButton.click();
			e.printStackTrace();
		}
	}
	
	public String editUserEmailId()
	{
		String UserEmailid = null;
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(editDetails));
			editDetails.click();
			wait.until(ExpectedConditions.visibilityOf(editFirstName));
			Date formatDate = new java.util.Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String date = formatter.format(formatDate);
			date = date.replace(" ", "").replace(":", "").replace("-", "");
		
			
			String fName = editFirstName.getAttribute("value");
			String lName = editLastName.getAttribute("value");
			userEmail =User.getUserEmail(date);
			userEmailText.clear();
			userEmailText.sendKeys(userEmail);
			
			UserEmailid = userEmail;
			editFirstName.click();
			Thread.sleep(3000);
			
			wait.until(ExpectedConditions.visibilityOf(submitButton));
			submitButton.click();
		//	Thread.sleep(3000);
			
		//	submitButton.click();
			
			System.out.println("Updated Successfully");
		} 
		catch (Exception e) 
		{
			submitButton.click();
			e.printStackTrace();
		}
		return UserEmailid;
	}

	public void editUserDetails(String space)
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(15000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(editDetail));
			editDetail.click();
			wait.until(ExpectedConditions.visibilityOf(editFirstNme));
			String fName = editFirstNme.getAttribute("value");
			String lName = editLastNme.getAttribute("value");
			String email = editEmail.getAttribute("value");
				
			if(space.contains("space+firstname"))
			{
				
				editFirstNme.clear();
				editFirstNme.sendKeys(" "+fName);
				editFirstNme.sendKeys("\t");
			}
			if(space.contains("firstname+space"))
			{
				editFirstNme.click();
				editFirstNme.clear();
				editFirstNme.sendKeys(fName+" ");
				editFirstNme.sendKeys("\t");
			}
			
			if(space.contains("space+lastname"))
			{
			
				editLastNme.clear();
				editLastNme.sendKeys(" "+lName);
				editLastNme.sendKeys("\t");
			}
			if(space.contains("lastname+space"))
			{
				editLastNme.click();
				editLastNme.clear();
				editLastNme.sendKeys(" "+lName);
				editLastNme.sendKeys("\t");
				
			}
			
			
			

			if(space.contains("space+email"))
			{
			
				editEmail.clear();
				editEmail.sendKeys(" "+email);
				editEmail.sendKeys("\t");
				
			}
			if(space.contains("email+space+domain"))
			{
				editEmail.click();
				editEmail.clear();
				editEmail.sendKeys(email.split("@")[0]+" "+ prop.getProperty("userDomain").split("@")[1]);
				editEmail.sendKeys("\t");
				driver.findElement(By.xpath("//*[@id='year_of_exp']")).click();
				editLastNme.sendKeys("\t");
				
				Thread.sleep(5000);
				wait.until(ExpectedConditions.visibilityOf(Errormsg));
				
				Assert.assertEquals("The Contact Person email id is not a valid email address", Errormsg.getText());
					
				editEmail.click();
				editEmail.clear();
				editEmail.sendKeys(email);
				editEmail.sendKeys("\t");
				
			}
			
			if(space.contains("emailctc+space+domain"))
			{
				editEmail.click();
				editEmail.clear();
				editEmail.sendKeys(email.split("@")[0]+" "+ prop.getProperty("userDomain").split("@")[1]);
				editEmail.sendKeys("\t");
				driver.findElement(By.xpath("//*[@id='year_of_exp']")).click();
				editLastNme.sendKeys("\t");
				
				Thread.sleep(5000);
				wait.until(ExpectedConditions.visibilityOf(Errormsgctc));
				
				Assert.assertEquals("The Contact Person email id is not a valid email address", Errormsgctc.getText());
					
				editEmail.click();
				editEmail.clear();
				editEmail.sendKeys(email);
				editEmail.sendKeys("\t");
				
			}
			
			submitBtn.click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(searchResultFirstName));
			String viewName = searchResultName.getText().trim();
			String viewemail = searchResultLastName.getText().trim();
			Assert.assertEquals(fName+" "+lName, viewName);
			Assert.assertEquals(email, viewemail);
			
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
//		e.printStackTrace();	
		}
	}
	
	public void deleteAdmin() throws InterruptedException
	{

		JavascriptExecutor js = (JavascriptExecutor)driver;
		String pageValue = js.executeScript("return document.readyState").toString();
		int m=0;
		while(!(pageValue.equalsIgnoreCase("complete")))
		{
			pageValue = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			m++;
		}
		Thread.sleep(3000);
		userEmail=userEmailText.getAttribute("value");
		System.out.println(userEmail);
		
//	name 
		
     orid=		userIdText.getAttribute("value");
		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		remove.click();
		
		Thread.sleep(3000);
		
		delete.click();
		
		Thread.sleep(5000);
		
		
	}
	public void deleteacess() throws InterruptedException
	{

		JavascriptExecutor js = (JavascriptExecutor)driver;
		String pageValue = js.executeScript("return document.readyState").toString();
		int m=0;
		while(!(pageValue.equalsIgnoreCase("complete")))
		{
			pageValue = js.executeScript("return document.readyState").toString();
			if(m==pagload)
				break;
			m++;
		}
		Thread.sleep(3000);
	
		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		
		String userrow="//*[@id=\"admins\"]/tbody/tr";
			 
			Thread.sleep(5000);
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userrow))));
				
			 List<WebElement> rows = driver.findElements(By.xpath(userrow));
			 System.out.println(rows.size());
			 try
			 {
				for(int i = 0; i < rows.size(); i++)
				{
				
		actionbtn.click();
		
		Thread.sleep(3000);
		
		removeRole.click();
		
		Thread.sleep(5000);
		deleteProcess.click();
		
				}
			 }
			 catch(Exception e)
			 
			 {
				 
			 }
	}
	public void clickonaddAdmin()
	{
	
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			try
			{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(remove));
			deleteAdmin();
			}
			catch(Exception e)
			{
			}
			  orid=		userIdText.getAttribute("value");
				
			Thread.sleep(5000);
			
			wait.until(ExpectedConditions.visibilityOf(addadmin));
			
			wait.until(ExpectedConditions.elementToBeClickable(addadmin));
			addadmin.click();
			
		}
		catch(Exception e)
		{


			;	
		Assert.fail(e.getMessage());
		}
	}
	public void clickonaddAdminBtn()
	{
	
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
		
			  orid=		userIdText.getAttribute("value");
				
			WebDriverWait wait = new WebDriverWait(driver, 30);
			Thread.sleep(5000);
			
			wait.until(ExpectedConditions.visibilityOf(addadmin));
			addadmin.click();
			
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
			e.printStackTrace();	
		}
	}
	
	public void viewAndEditUser()
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(viewDetails));
			viewDetails.click();
			wait.until(ExpectedConditions.visibilityOf(editViewDetails));
			editViewDetails.click();
			wait.until(ExpectedConditions.visibilityOf(editFirstName));
			String fName = editFirstName.getAttribute("value");
			String lName = editLastName.getAttribute("value");
			editFirstName.click();
			editFirstName.clear();
			editFirstName.sendKeys(fName.replace(" update", ""));
			editLastName.click();
			editLastName.clear();
			editLastName.sendKeys(lName.replace(" update", ""));
			submitButton.click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(searchResultFirstName));
			String viewFirst = searchResultFirstName.getText().trim();
			String viewLast = searchResultLastName.getText().trim();
			Assert.assertEquals(fName.replace(" update", ""), viewFirst);
			Assert.assertEquals(lName.replace(" update", ""), viewLast);
		} 
		catch (Exception e) 
		{
			Assert.fail("ERROR updating user");
		}
	}
	public void viewAndEditUser(String msg)
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(viewDetails));
			viewDetails.click();
			wait.until(ExpectedConditions.visibilityOf(editViewDetails));
			editViewDetails.click();
			wait.until(ExpectedConditions.visibilityOf(editFirstName));
			String fName = editFirstName.getAttribute("value");
			String lName = editLastName.getAttribute("value");
			editFirstName.click();
			editFirstName.clear();
			editFirstName.sendKeys(fName.replace(" update", ""));
			editLastName.click();
			editLastName.clear();
			editLastName.sendKeys(lName.replace(" update", ""));
			submitButton.click();
			Thread.sleep(3000);
			orgHome.successmsg(msg);
			wait.until(ExpectedConditions.visibilityOf(searchResultFirstName));
			String viewFirst = searchResultFirstName.getText().trim();
			String viewLast = searchResultLastName.getText().trim();
			Assert.assertEquals(fName.replace(" update", ""), viewFirst);
			Assert.assertEquals(lName.replace(" update", ""), viewLast);
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
	}
	

	public void editUserDetailsF()
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(editDetails));
			editDetails.click();
			wait.until(ExpectedConditions.visibilityOf(editFirstName));
			Date formatDate = new java.util.Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String date = formatter.format(formatDate);
			date = date.replace(" ", "").replace(":", "").replace("-", "");
		
			String fName = editFirstName.getAttribute("value");
			String lName = editLastName.getAttribute("value");
			userEmail = User.getUserEmail(date) ;
			userEmailText.clear();
			userEmailText.sendKeys(userEmail);
			
			
			selectHiredate();
			middle_name.sendKeys("Middle_Update");
			phone.sendKeys("21211313");
			years_of_experience.sendKeys("2");
			editFirstName.click();
			editFirstName.clear();
			editFirstName.sendKeys(fName + " update");
			editLastName.click();
			editLastName.clear();
			editLastName.sendKeys(lName + " update");
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(submitButton));
			submitButton.click();
			lName=lName + " update";
			fName=fName + " update";
			Thread.sleep(3000);
			orgHome.validateSucessMesssage();
			wait.until(ExpectedConditions.visibilityOf(searchResultFirstName));
			String viewFirst = searchResultFirstName.getText().trim();
			String viewLast = searchResultLastName.getText().trim();
			Assert.assertEquals(fName, viewFirst);
			Assert.assertEquals(lName, viewLast);
			
			System.out.println("Updated Successfully");
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
	}
	
	
	public void viewdetails()
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(viewDetails));
			viewDetails.click();
			
			
			
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
	}
	
	public void validateUserDetails(String data)
	{
		if(AssignmentReport.checkifParmeterAvailable(data))
			data=AssignmentReport.getParmeterAvailable(data);


		if(data.contains("Today"))
		{
			Date formatDate = new java.util.Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
			data = formatter.format(formatDate);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@class='userstep3 viewmode active ']//*[contains(text(),'"+data+"')]"))));
			//		
			Assert.assertEquals( driver.findElement(By.xpath("//div[@class='userstep3 viewmode active ']//*[contains(text(),'"+data+"')]")).getText(),data);

		}
		else if(data.contains("tomorrow"))
		{
			
					DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
				Calendar cal = Calendar.getInstance();
				cal = Calendar.getInstance();
				cal.add(Calendar.DAY_OF_MONTH, 1);
				
				data = dateFormat.format(cal.getTime());
			
			
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@class='userstep3 viewmode active ']//*[contains(text(),'"+data+"')]"))));
			//		
			Assert.assertEquals( driver.findElement(By.xpath("//div[@class='userstep3 viewmode active ']//*[contains(text(),'"+data+"')]")).getText(),data);

		}
		else if (data.contains("userEmail"))
		{
			System.out.println("Validate the Details "+userEmail+" Actual:"+driver.findElement(By.xpath("//div[@class='userstep3 viewmode active ']//*[contains(text(),'"+userEmail+"')]")).getText());

			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@class='userstep3 viewmode active ']//*[contains(text(),'"+userEmail+"')]"))));
			//		
			Assert.assertEquals( driver.findElement(By.xpath("//div[@class='userstep3 viewmode active ']//*[contains(text(),'"+userEmail+"')]")).getText(),userEmail);

		}
		else if (data.contains("userID"))
		{
			System.out.println("Validate the Details "+userId+" Actual:"+driver.findElement(By.xpath("//div[@class='userstep3 viewmode active ']//*[contains(text(),'"+userId+"')]")).getText());

			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@class='userstep3 viewmode active ']//*[contains(text(),'"+userId+"')]"))));
			//		
			Assert.assertEquals( driver.findElement(By.xpath("//div[@class='userstep3 viewmode active ']//*[contains(text(),'"+userId+"')]")).getText(),userId);

		}
		else 
		{
			System.out.println("Validate the Details "+data+" Actual:"+driver.findElement(By.xpath("//div[@class='userstep3 viewmode active ']//*[contains(text(),'"+data+"')]")).getText());

			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@class='userstep3 viewmode active ']//*[contains(text(),'"+data+"')]"))));
			//		
			Assert.assertEquals( driver.findElement(By.xpath("//div[@class='userstep3 viewmode active ']//*[contains(text(),'"+data+"')]")).getText(),data);

		}

	}
	
	public void validatethedetails(String msg)
	{
		try 
		{
			
			//div[@class="userstep3 viewmode active "]//*[contains(text(),'level_3')]
			
			
		} 
		catch (Exception e) 
		{
			
		}
	}
	
	public void viewUserBtn()
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			try
			{
			Assert.assertFalse(editDetails.isDisplayed());
			System.out.println("Edit btn is not available in dropdown");
			}
		
		catch (Exception e) 
		{
		}
		try
		{
		wait.until(ExpectedConditions.visibilityOf(viewDetails));
			viewDetails.click();
		   Assert.assertFalse(editViewDetails.isDisplayed());
			System.out.println("Edit btn is not available in user page");
		} 
		catch (Exception e) 
		{	
		 
		} 
		}
		catch (Exception e) 
		{
//			e.getStackTrace();
//			Assert.fail(e.getMessage());
		}
	}

	public void applyMoreFilter()
	{
		try
		{
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(moreFilter));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", moreFilter);
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(userStatusFilter));
			userStatusFilter.click();
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(selectAllFilter));
			Thread.sleep(2000);
			selectAllFilter.click();
			wait.until(ExpectedConditions.visibilityOf(moreFilterSearch));
			Thread.sleep(2000);
			moreFilterSearch.click();
			Thread.sleep(3000);
		}
		catch(Exception e)
		{
			
		}
	}
	public void navigateandEditUser()
	{
		try {
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(editDetails));
			editDetails.click();
			wait.until(ExpectedConditions.visibilityOf(editFirstName));
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void navigateandViewCourse()
	{
		try {
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(viewCourses));
			viewCourses.click();
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	public void navigateEditUser()
	{
		try {
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetail));
			actionDetail.click();
			wait.until(ExpectedConditions.visibilityOf(editDetails));
			editDetails.click();
		} catch (Exception e) {
			// TODO: handle exception
			Assert.fail(e.getMessage());
		}
	}
	
	
	public void setInactive(String msg)
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", actionDetails);
			wait.until(ExpectedConditions.visibilityOf(setInactive));
			setInactive.click();
			wait.until(ExpectedConditions.visibilityOf(deleteYesButton));
			deleteYesButton.click();
			orgHome.successmsg(msg);
			driver.navigate().refresh();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(searchResultUserStatus));
			String stat = searchResultUserStatus.getText();
			Assert.assertEquals("Inactive", stat.trim());
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());	
		}
	}
	public void setInactive()
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", actionDetails);
			wait.until(ExpectedConditions.visibilityOf(setInactive));
			setInactive.click();
			wait.until(ExpectedConditions.visibilityOf(deleteYesButton));
			deleteYesButton.click();
		
			driver.navigate().refresh();
			Thread.sleep(3000);
			  int lastNameColumnPosition = getHeaderPosition("User Status");
				String value = driver.findElement(By.xpath("(" + userRows + ")[1]/td[" + lastNameColumnPosition + "]")).getText();
			Assert.assertEquals("Inactive", value.trim());
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
	}
	

	public void setInactives()
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", actionDetails);
			wait.until(ExpectedConditions.visibilityOf(setInactive));
			setInactive.click();
			wait.until(ExpectedConditions.visibilityOf(deleteYesButton));
			
			deleteYesButton.click();
			driver.navigate().refresh();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(searchResultUsersStatus));
			String stat = searchResultUsersStatus.getText();
			Assert.assertEquals("Inactive", stat.trim());
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
	}	

	public void setInactives(String msg)
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", actionDetails);
			wait.until(ExpectedConditions.visibilityOf(setInactive));
			setInactive.click();
			wait.until(ExpectedConditions.visibilityOf(deleteYesButton));
			
			deleteYesButton.click();
			
			orgHome.successmsg(msg);
			
			driver.navigate().refresh();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(searchResultUsersStatus));
			String stat = searchResultUsersStatus.getText();
			Assert.assertEquals("Inactive", stat.trim());
		} 
		catch (Exception e) 
		{
			
		}
	}	
	
	public void setActives(String msg)
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 10);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", actionDetails);
			wait.until(ExpectedConditions.visibilityOf(setActive));
			setActive.click();
			wait.until(ExpectedConditions.visibilityOf(deleteYesButton));
			deleteYesButton.click();
			orgHome.successmsg(msg);
			driver.navigate().refresh();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(searchResultUsersStatus));
			String stat = searchResultUsersStatus.getText();
			Assert.assertEquals("Active", stat.trim());
		}
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
	}

	public void setActive()
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 10);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", actionDetails);
			wait.until(ExpectedConditions.visibilityOf(setActive));
			setActive.click();
			wait.until(ExpectedConditions.visibilityOf(deleteYesButton));
			deleteYesButton.click();
			driver.navigate().refresh();
			Thread.sleep(3000);
			Thread.sleep(3000);
			  int lastNameColumnPosition = getHeaderPosition("User Status");
				String value = driver.findElement(By.xpath("(" + userRows + ")[1]/td[" + lastNameColumnPosition + "]")).getText();
			Assert.assertEquals("Active", value.trim());
		}
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
	}
	
	public void setActive(String msg)
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 10);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", actionDetails);
			wait.until(ExpectedConditions.visibilityOf(setActive));
			setActive.click();
			wait.until(ExpectedConditions.visibilityOf(deleteYesButton));
			deleteYesButton.click();
			orgHome.successmsg(msg);
			driver.navigate().refresh();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(searchResultUserStatus));
			String stat = searchResultUserStatus.getText();
			Assert.assertEquals("Active", stat.trim());
		}
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());	
		}
	}


	public void addGroup(String grpName)
	{
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(userLink));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			executor.executeScript("arguments[0].click();", userLink);
			
			User	usr = new User();
			usr.userSearch(User.userId);
			try
			{
			Thread.sleep(5000);
			}
			catch(Exception e)
			{
				
			}
			
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(addToGroup));
			addToGroup.click();
			wait.until(ExpectedConditions.visibilityOf(groupSelect));
			Select drpgroup = new Select(groupSelect);
			groupSelect.click();
			Thread.sleep(3000);
			drpgroup.selectByVisibleText(grpName);
			addGroupButton.click();
			wait.until(ExpectedConditions.visibilityOf(closeButton));
			closeButton.click();
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			driver.navigate().refresh();
			js = (JavascriptExecutor)driver;
			pageValue = js.executeScript("return document.readyState").toString();
			 m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(viewDetails));
			wait.until(ExpectedConditions.elementToBeClickable(viewDetails));
			viewDetails.click();
			wait.until(ExpectedConditions.visibilityOf(groupTab));
			groupTab.click();
			wait.until(ExpectedConditions.visibilityOf(groupName));
			String name;
			name = driver.findElement(By.xpath("//table[@id = 'mmgroupuser']//td[text()='"+grpName+"']")).getText();
				
			Assert.assertEquals(grpName.trim(), name.trim());
			executor.executeScript("arguments[0].click();", userLink);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	public void addGroups(String grpName)
	{
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(userLink));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			executor.executeScript("arguments[0].click();", userLink);
			
//			User	usr = new User();
//			usr.userSearch(User.userId);
			try
			{
			Thread.sleep(5000);
			}
			catch(Exception e)
			{
				
			}
			
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(addToGroup));
			addToGroup.click();
			wait.until(ExpectedConditions.visibilityOf(groupSelect));
			Select drpgroup = new Select(groupSelect);
			groupSelect.click();
			Thread.sleep(3000);
			drpgroup.selectByVisibleText(grpName);
			addGroupButton.click();
			wait.until(ExpectedConditions.visibilityOf(closeButton));
			closeButton.click();
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			driver.navigate().refresh();
			js = (JavascriptExecutor)driver;
			pageValue = js.executeScript("return document.readyState").toString();
			 m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(viewDetails));
			wait.until(ExpectedConditions.elementToBeClickable(viewDetails));
			viewDetails.click();
			wait.until(ExpectedConditions.visibilityOf(groupTab));
			groupTab.click();
			wait.until(ExpectedConditions.visibilityOf(groupName));
			String name;
			name = driver.findElement(By.xpath("//table[@id = 'mmgroupuser']//td[text()='"+grpName+"']")).getText();
				
			Assert.assertEquals(grpName.trim(), name.trim());
			executor.executeScript("arguments[0].click();", userLink);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	public void removeGroup()
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(removeGroup));
			removeGroup.click();
			wait.until(ExpectedConditions.visibilityOf(checkbox));
			checkbox.click();
			removeButton.click();
			wait.until(ExpectedConditions.visibilityOf(closeButton));
			closeButton.click();
			js = (JavascriptExecutor)driver;
			pageValue = js.executeScript("return document.readyState").toString();
			 m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}	
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(viewDetails));
			viewDetails.click();
			wait.until(ExpectedConditions.visibilityOf(groupTab));
			groupTab.click();
			wait.until(ExpectedConditions.visibilityOf(groupName));
			String name = groupName.getText();
			Assert.assertEquals("No Groups Found.", name.trim());
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
	}

	public void addAssignment()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", actionDetails);
		wait.until(ExpectedConditions.visibilityOf(addAssignmentLink));
		addAssignmentLink.click();
		wait.until(ExpectedConditions.visibilityOf(addAssignmentButton));
		addAssignmentButton.click();
	}

	public void validAssignmentAdded()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(userLink));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", userLink);
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewDetails));
		viewDetails.click();
		wait.until(ExpectedConditions.visibilityOf(detailAssignmentTab));
		detailAssignmentTab.click();
		wait.until(ExpectedConditions.visibilityOf(assignmentTitle));
		String name = assignmentTitle.getText();
		Assert.assertEquals(Assignments.name, name);
		
	}

	public void validateActionButton()
	{
		try
		{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(actionDropDown));
		actionDropDown.click();
		Assert.fail("Action Btn should not be present");
		}
		catch(Exception e)
		{
			
		}
		
		
		
	}
	public void removeAssignment()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(userLink));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", userLink);
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(removeAssignmentLink));
		removeAssignmentLink.click();
		wait.until(ExpectedConditions.visibilityOf(assignmentLabel));
		assignmentLabel.click();
		wait.until(ExpectedConditions.visibilityOf(assignmentRemovePop));
		assignmentRemovePop.click();
		wait.until(ExpectedConditions.visibilityOf(assignmentClose));
		assignmentClose.click();
		
	}

	public void validAssignmentRemoved()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(userLink));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", userLink);
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewDetails));
		viewDetails.click();
		wait.until(ExpectedConditions.visibilityOf(detailAssignmentTab));
		detailAssignmentTab.click();
		wait.until(ExpectedConditions.visibilityOf(assignmentDisplay));
		Assert.assertTrue(assignmentDisplay.isDisplayed());
		wait.until(ExpectedConditions.visibilityOf(userLink));
		executor.executeScript("arguments[0].click();", userLink);
	}

	public void clickOnAssignmentTab()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(assignmentTab));
		wait.until(ExpectedConditions.elementToBeClickable(assignmentTab));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", assignmentTab);
	}

	
	public void userMultipleAssgnment(Object org, Object assign, int count)
	{
		for(int i=1; i<=count; i++)
		{
			addAssignment();
			((Assignments) assign).assignmentFromUser();
		    ((Assignments) assign).createAssignment();
		    ((OrganizationHome) org).validateSucessMesssage();
		    WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userLink));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", userLink);
		}
		
	}
	
	public void multiUserEachAssignment(Object org, Object assign, int count)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		for(int i=1; i<=count; i++)
		{
			clickCreateUser();
			enterUserDetails("Ansh"+i, "G"+i, String.valueOf(i));
			clickOnSubmit();
			String action = actionLink + i + "]";
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(action)));
			WebElement wb = driver.findElement(By.xpath(action));
			executor.executeScript("arguments[0].click();", wb);
			String asgn = assignmentLink + i + "]";
			WebElement asn = driver.findElement(By.xpath(asgn));
			wait.until(ExpectedConditions.visibilityOf(asn));
			asn.click();
			wait.until(ExpectedConditions.visibilityOf(addAssignmentButton));
			addAssignmentButton.click();
			((Assignments) assign).assignmentFromUser();
		    ((Assignments) assign).createAssignment();
		    ((OrganizationHome) org).validateSucessMesssage();
		    executor.executeScript("arguments[0].click();", userLink);
		}
	}

	public void viewChildUser()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewCourses));
		viewCourses.click();
		wait.until(ExpectedConditions.visibilityOf(unEnrollButton));
		Assert.assertTrue(courseTitle.isDisplayed());
		closePopUp.click();
	}

	public void viewTrainingCertificate()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(coursesCertificate));
		coursesCertificate.click();
		wait.until(ExpectedConditions.visibilityOf(eCardLabel));
		Assert.assertTrue(eCardBox.isDisplayed());
		childCourseName = courseName.getText();
	}
	
	
	public void checkthecard(String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();

		Assert.assertTrue(eCardBoxcourse.getText().contains(course));
	
	}
	
	public void validateEcard(String course,String name)
	{
		String cname=course;
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();

//		wait.until(ExpectedConditions.visibilityOf(activeStatus));(//div[@class='ecard_box ecard']//h1[text()='QARQI_QA-MOC_2020_BLS Provider']/following::p)

		;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//h1[text()='"+course+"']//preceding::p//a[text()='Active']"))));

		Assert.assertTrue("Training Center : "+prop.getProperty("orgName")+" not found",driver.findElement(By.xpath("(//div[@class='ecard_box ecard']//h1[text()='"+course+"']/following::p)[2]")).getText().contains("Training Center : "+prop.getProperty("orgName")));
		Assert.assertTrue(name+prop.getProperty("orgName")+" not found", headerCertificates.getText().contains(name+" - "+prop.getProperty("orgName")));
		Assert.assertTrue(name+"-Certificates not found",driver.findElement(By.xpath("//div[@class='tab-content ecard-wrapper']//h4")).getText().contains(name+"-Certificates"));
		Assert.assertTrue("Current eCards header not found",eCardBoxHeader.getText().contains("Current eCards"));
		Assert.assertTrue("Course name not displayed"+driver.findElement(By.xpath("//div[@class='ecard_box ecard']//h1[text()='"+course+"']")).getText(),driver.findElement(By.xpath("//div[@class='ecard_box ecard']//h1[text()='"+course+"']")).getText().contains(course));
		Assert.assertTrue("User name not found"+driver.findElement(By.xpath("(//div[@class='ecard_box ecard']//h1[text()='"+course+"']/following::p)[1]")).getText(),eCardusername.getText().contains("for "+name));

		List<WebElement> rows = driver.findElements(By.xpath("//div[@class='ecard_box ecard']//h1[text()='"+course+"']"));
		Assert.assertEquals("We have Duplicate for course '"+course+"'",1 ,rows.size());
		
//		(//div[@class='ecard_box ecard']//h1[text()='RQI ALS Entry 2025']/following::a)[1]
		driver.findElement(By.xpath("(//div[@class='ecard_box ecard']//h1[text()='"+course+"']/following::a)[1]")).click();
		ProgressReport	prog = new ProgressReport();
		  prog.viewecardDownload(cname);
			
	}

	public void ecardisremoved(String course)
	{
		String cname=course;
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();

		wait.until(ExpectedConditions.visibilityOf(headerCertificates));
		List<WebElement> rows=	driver.findElements(By.xpath("//h1[text()='"+course+"']//preceding::p//a[text()='Active']"));
		
		Assert.assertEquals("We have ecard not removed for course '"+course+"'",0 ,rows.size());
		
//		(//div[@class='ecard_box ecard']//h1[text()='RQI ALS Entry 2025']/following::a)[1]
//		driver.findElement(By.xpath("(//div[@class='ecard_box ecard']//a)[2]")).click();
//		ProgressReport	prog = new ProgressReport();
//		  prog.viewecardshouldnotdisplay(cname);
			
	}

	public void validateEcard(String course)
	{
		String cname=course;
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();

		
//		(//div[@class='ecard_box ecard']//h1[text()='RQI ALS Entry 2025']/following::a)[1]
		driver.findElement(By.xpath("(//div[@class='ecard_box ecard']//a)[2]")).click();
		ProgressReport	prog = new ProgressReport();
		  prog.viewecardshouldnotdisplay(cname);
			
	}
	public void validatenoEcardisgenerated(String name)
	{
		
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//h1[text()='No eCards Available.']"))));

//		Assert.assertTrue("Training Center : "+prop.getProperty("orgName")+" not found",driver.findElement(By.xpath("//div[@class='ecard_box']/p[3]")).getText().contains("Training Center : "+prop.getProperty("orgName")));
		Assert.assertTrue(name+prop.getProperty("orgName")+" not found", headerCertificates.getText().contains(name+" - "+prop.getProperty("orgName")));
		Assert.assertTrue(name+"-Certificates not found",driver.findElement(By.xpath("//div[@class='tab-content']//h4")).getText().contains(name+"-Certificates"));
		
//		Assert.assertTrue("Current eCards header not found",eCardBoxHeader.getText().contains("Current eCards"));
//		Assert.assertTrue("Course name not displayed"+eCardBoxcourse.getText(),eCardBoxcourse.getText().contains(course));
//		Assert.assertTrue("User name not found"+eCardusername.getText(),eCardusername.getText().contains("for "+name));

		
	}


	public void viewUser()
	{
		try
		{
			reuse.waitforsec(10);
	
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewDetails));
		viewDetails.click();
		}
		catch(Exception e)
		{
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(viewDetails));
			viewDetails.click();
				
		}
	}
	public void getUserDetails()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(userIdViewPage));
		userId = userIdViewPage.getText();
		System.out.println("User id of created user is " + userId);
		userEmail = userEmailViewPage.getText();
		System.out.println("User email of created user is " + userEmail);
	}
	public void clickAssignmentTabUserPage()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(assignmentBar));
		assignmentBar.click();
	}
	
	
	public void editisnotavailable()
	{
		try
		{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(editDetails));
		Assert.fail("Edit btn is available");
		}
		catch(Exception e)
		{
			System.out.println("Edit btn is not available");
		}
	}
		
	public void Assigmentisnotavailable()
	{
		try
		{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(addAssigment));
		Assert.fail("Add Assigment btn is available");
		}
		catch(Exception e)
		{
			System.out.println("Add Assigment btn is not available");
		}
	}
		

	

	public void validateUnitName(int count)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(unitName));
		Assert.assertEquals("level_" + count, unitName.getText());
	}

	public void validateJobTitle(int count)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(jobTitle));
		Assert.assertEquals("Job_name_" + count, jobTitle.getText());
	}
	public void validateCourseCountAddAssignmentPopup(int count)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		if(count > 0)
		{
			wait.until(ExpectedConditions.visibilityOf(selectAssignmentDrop));
			Select select = new Select(selectAssignmentDrop);
			List<WebElement> dropdown = select.getOptions();
			System.out.println("Total course available for add is " + dropdown.size());
			Assert.assertTrue(dropdown.size() == count + 1);
		}
			
		
	}
	public void validateAddAssignmentPopupMessage(String message)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(addAssignmentButton));
		wait.until(ExpectedConditions.visibilityOf(addAssignmentMessage));
		String actualMessage = addAssignmentMessage.getText().trim();
		System.out.println(actualMessage);
		Assert.assertTrue(actualMessage.equalsIgnoreCase(message));
	}
	
	public void selectCourseAssignmentDropdown(String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
	
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(selectAssignmentDrop));
		Select select = new Select(selectAssignmentDrop);
		select.selectByVisibleText(course.trim());
	}
	
	public void validateAddAssignmentNames(String courses)
	{
		int counter = 0;
		if(courseListName.containsKey(courses+"Option"))
			courses=courseListName.get(courses+"Option").toString();
	
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(selectAssignmentDrop));
		Select select = new Select(selectAssignmentDrop);
		List<WebElement> dropdown = select.getOptions();
		String course[] = courses.split(",");
		for(int start = 0; start <= course.length - 1; start++)
		{
		for(int i =0; i<dropdown.size() ; i++)
			{
	         	String text = dropdown.get(i).getText();
	         	if(text.equalsIgnoreCase(course[start].trim()))
				{
					counter = counter + 1;
				}
			}
		}
		Assert.assertTrue(counter == course.length);
	}
	public void validateUnitLevelMainFilter(int level, int unit)
	{
		try
		{
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(unitLevelMainFilter))));
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitLevelMainFilter + "/ancestor::div[@class = 'filterPanelDiv ']/label"))));
			String unitName = driver.findElement(By.xpath(unitLevelMainFilter + "/ancestor::div[@class = 'filterPanelDiv ']/label")).getText();
		    System.out.println(unitName);
			Assert.assertTrue(unitName.equalsIgnoreCase("Level " + level + " (s) Name"));
			driver.findElement(By.xpath("(" + unitLevelMainFilter + ")["+ (level-1) +"]")).click();
			Thread.sleep(3000);
			String link = driver.findElement(By.xpath("(" + unitLevelMainFilter + ")[" + (level-1) +"]//following-sibling::div//a")).getText();
			Assert.assertTrue(link.equalsIgnoreCase("unselect all"));
			Thread.sleep(2000);
			List<WebElement> unitCount = driver.findElements(By.xpath("(" + unitLevelMainFilter + ")[" + (level-1) +"]//following-sibling::div//li"));
			Assert.assertEquals(unitCount.size(), unit);
			List<WebElement> checkboxCount = driver.findElements(By.xpath("(" + unitLevelMainFilter + ")[" + (level-1) +"]//following-sibling::div//li//input"));
			Assert.assertEquals(checkboxCount.size(), unit);
			driver.findElement(By.xpath("(" + unitLevelMainFilter + ")["+ (level-1) +"]")).click();
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
			}
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	public void validateFiltersUserPage()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
			}
			Thread.sleep(5000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(fromHireDate));
			Assert.assertTrue(searchText.isDisplayed());
			Assert.assertTrue(driver.findElement(By.xpath(orgMainFilter)).isDisplayed());
			Assert.assertTrue(driver.findElement(By.xpath(unitLevelMainFilter)).isDisplayed());
			Assert.assertTrue(fromHireDate.isDisplayed());
			Assert.assertTrue(toHireDate.isDisplayed());
			Assert.assertTrue(moreFilter.isDisplayed());
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
			}
			Thread.sleep(5000);
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	public void validateGroupFilterText(String expectedText)
	{
		try
		{
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
			}
			Thread.sleep(5000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(groupFilter))));
			String actualText = driver.findElement(By.xpath(groupFilter + "//button/span")).getText();
			Assert.assertTrue(actualText.equalsIgnoreCase(expectedText));
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	public void validateGroupFilterAvailabilityCount(int count)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(groupAvailableFilter))));
		driver.findElement(By.xpath(groupAvailableFilter)).click();
		List<WebElement> unitList =  driver.findElements(By.xpath(groupAvailableFilter + "/following-sibling::div//li"));
		if(unitList.size() != count)
			Assert.fail("More groups available than expected");
	}
	
	public void validateGroupFilterAvailable()
	{
		List<WebElement> element = driver.findElements(By.xpath(groupAvailableFilter));
		if(element.size() != 1)
			Assert.fail("Group filter is not available for LMS organization");
	}
	public void validateGroupFilterDisplayed()
	{
		List<WebElement> element = driver.findElements(By.xpath(groupFilter));
		if(element.size() != 1)
			Assert.fail("Group filter is not available for LMS organization");
	}
	
	public void getRowCount(int count)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		try
		{
		Thread.sleep(5000);	
		}
		catch(Exception e)
		{
			
		}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(userTable)));
		List<WebElement> rows = driver.findElements(userTable);
		if(count==0)
			Assert.assertEquals(rows.get(0).getText(),"No records are present.");
		else
		Assert.assertEquals(count, rows.size());
	}
	public void getRowCountLMS(int count)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		try
		{
		Thread.sleep(5000);	
		}
		catch(Exception e)
		{
			
		}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(userTableManage)));
		List<WebElement> rows = driver.findElements(userTableManage);
		if(count==0)
			Assert.assertEquals(rows.get(0).getText(),"No records are present.");
		else
		Assert.assertEquals(count, rows.size());
	}
	public void validatenorecordfound()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		try
		{
		Thread.sleep(5000);	
		}
		catch(Exception e)
		{
			
		}
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(norecordfound)));
			Assert.assertEquals(driver.findElement(norecordfound).getText(),"No records present.");
		
	}
	public void selectAddAssignmentOption()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(addAssignmentForAll));
		addAssignmentForAll.click();
	}
	public int rowsAvailable()
	{
		int count = 0;
		try 
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(userTable)));
			List<WebElement> rows = driver.findElements(By.xpath(userRows));
			String text = driver.findElement(By.xpath(userRows + "[1]/td")).getText();
			if(text.trim().equalsIgnoreCase("No records are present."))
				count = 0;
			else
				count = rows.size();
			
		} catch (Exception e) 
		{
			
		}
		return count;
	}
	
	public void userSearchById(String id)
	{
		try 
		{
			navigateUserModule();
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchClear));
			wait.until(ExpectedConditions.elementToBeClickable(searchClear));
			searchClear.click();
			wait.until(ExpectedConditions.visibilityOf(searchText));
			wait.until(ExpectedConditions.elementToBeClickable(searchText));
			System.out.println("user id is " + id);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", searchText);
			wait.until(ExpectedConditions.elementToBeClickable(searchinputText));
			searchinputText.sendKeys(id);
			executor.executeScript("arguments[0].click();", searchButton);
			wait.until(ExpectedConditions.visibilityOf(searchResultUserID));
			Thread.sleep(5000);
			String result = searchResultUserID.getText().toLowerCase().trim();
			System.out.println(id);
			System.out.println(result);
			while(!(id.equals(result))) 
			{
				result = searchResultUserID.getText();
			}
			Assert.assertEquals(id, result);
			js = (JavascriptExecutor)driver;
			pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			Thread.sleep(3000);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			
		}
	}
	public void addMultiuser(int count,Object org, String first, String last)
	{
		usrEmail=new String[count];
		usrID=new String[count];
//		if(userEmail!=null)
//		userEail=userEmail;
		for(int i=1; i<=count; i++)
		{
			clickCreateUser();
			enterUserDetails(first+i, last+i, String.valueOf(i));
			clickOnSubmit();
			((OrganizationHome) org).validateSucessMesssage();
			usrEmail[i-1]=userEmail;
			usrID[i-1]=userId;
			
		}
//		if(userEail!=null)
//		{
//		userEmail=userEail;
//		}
//		else
//		{
//			userEmail=null;
//		}
	}

	public void navigateUserModule()
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userLink));
			wait.until(ExpectedConditions.elementToBeClickable(userLink));
			Thread.sleep(3000);
			userLink.click();
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			String pageValue = executor.executeScript("return document.readyState").toString();
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = executor.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
		} 
		catch (Exception e) 
		{
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", userLink);
		}
	}
	
	public void editInactiveUser()
	{
		
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(inactiveuser));
			wait.until(ExpectedConditions.elementToBeClickable(inactiveuser));
			Thread.sleep(3000);
			inactiveuser.click();
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			String pageValue = executor.executeScript("return document.readyState").toString();
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = executor.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			
			wait.until(ExpectedConditions.visibilityOf(editDetails));
			editDetails.click();
			
			
		} 
		catch (Exception e) 
		{
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", userLink);
		}
	}
	public void searchuser(String field,String data)
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 40);
			wait.until(ExpectedConditions.visibilityOf(morefilter));
			wait.until(ExpectedConditions.elementToBeClickable(morefilter));
			Thread.sleep(3000);
			morefilter.click();
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			String pageValue = executor.executeScript("return document.readyState").toString();
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = executor.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			
			switch(field)
			{
			case "User Status" : 
				              wait.until(ExpectedConditions.elementToBeClickable(userStatus));
				
								userStatus.click();
								wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//li[@data-search-term='"+data+"']"))));
								driver.findElement(By.xpath("//li[@data-search-term='"+data+"']")).click();
								
								wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("(//div[1]/button[@value=\"Search\"])[2]"))));
								driver.findElement(By.xpath("(//div[1]/button[@value=\"Search\"])[2]")).click();
								
			}
			
			
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	public void addAvailableAssignment(int i)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		userSearch(User.usrEmail[i]);
		try {
			Thread.sleep(5000);
		}
		catch(Exception e)
		{
			
		}
		
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", actionDetails);
		wait.until(ExpectedConditions.visibilityOf(addAssignmentLink));
		addAssignmentLink.click();
		wait.until(ExpectedConditions.visibilityOf(selectAssignmentDrop));
		Select select = new Select(selectAssignmentDrop);
		selectAssignmentDrop.click();
		select.selectByVisibleText(Assignments.AssgnmentName);;
		addAssignmentButton.click();
		wait.until(ExpectedConditions.visibilityOf(assignmentClose));
		assignmentClose.click();
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.contains("loading_compliance loading_user"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
	}
	public void addAvailableAssignment()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		userSearch(User.userEmail);
		try {
			Thread.sleep(10000);
		}
		catch(Exception e)
		{
			
		}
		
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", actionDetails);
		wait.until(ExpectedConditions.visibilityOf(addAssignmentLink));
		addAssignmentLink.click();
		wait.until(ExpectedConditions.visibilityOf(selectAssignmentDrop));
		Select select = new Select(selectAssignmentDrop);
		selectAssignmentDrop.click();
		select.selectByVisibleText(Assignments.AssgnmentName);;
		
		addAssignmentButton.click();
		wait.until(ExpectedConditions.visibilityOf(assignmentClose));
		assignmentClose.click();
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.contains("loading_compliance loading_user"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
	}
	public void validatePaginationDropdown(String expectedCount)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(rowPerPageSelect));
		Select select = new Select(rowPerPageSelect);
		select.selectByValue(expectedCount);		
	}
	
	public void validateUserCountPerPage(String expectedCount)
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			WebDriverWait wait = new WebDriverWait(driver, 30);
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userRows))));
			List<WebElement> rows = driver.findElements(By.xpath(userRows));	
			Assert.assertTrue(Integer.parseInt(expectedCount) == rows.size());
			String sortCheck = userFirstHeader.getAttribute("class");
			Assert.assertTrue(sortCheck.equalsIgnoreCase("sorting"));   //"sorting_asc"
				}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	public void checkAllUser()
	{
		try {
			String val = pageLoad.getAttribute("class");
			int m=0;
			while(val.contains("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			
			wait.until(ExpectedConditions.visibilityOf(checkAllUSer));
			wait.until(ExpectedConditions.elementToBeClickable(checkAllUSer));
			Thread.sleep(5000);
			checkAllUSer.click();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	

	public void clickonAction()
	{
		try {
			String val = pageLoad.getAttribute("class");
			int m=0;
			while(val.contains("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
	}
	
	
	public void checkAllUserisnotavailable()
	{
		try {
			String val = pageLoad.getAttribute("class");
			int m=0;
			while(val.contains("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			
			  Thread.sleep(4000);
		
			boolean flge=checkAllUSer.isDisplayed();
			
			Assert.assertFalse(flge);
			
		} 
		catch (Exception e) 
		{
			System.out.println("check All User is not available");
//			e.printStackTrace();
		}
	}
	public void selectRemoveAssignmentForAll(String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
			
	
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(removeAssignmentForAll));
		removeAssignmentForAll.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(assignmentName)));
		List<WebElement> courseList = driver.findElements(By.xpath(assignmentName));
		System.out.println("Total course available for remove is " + courseList.size());
		for(int i = 1; i <= courseList.size(); i++)
		{
			String text = driver.findElement(By.xpath("(" + assignmentName + ")[" + i + "]")).getText().trim();
			if(text.equalsIgnoreCase(course))
			{
				driver.findElement(By.xpath("(" + assignmentName + ")[" + i + "]")).click();
			}
		}
		removeAssignmentButton.click();
	}
	
	public void validateErrorMessageForActivatedCourse(String expectedMessage)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(assignmentClose));
		wait.until(ExpectedConditions.visibilityOf(removalMessage));
		String actualMessage = removalMessage.getText();
		System.out.println(actualMessage);
		Assert.assertTrue(actualMessage.equalsIgnoreCase(expectedMessage));
		assignmentClose.click();
	}
	public void clickAllActionItem()
	{
		try
		{
			Thread.sleep(3000);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(actionDropDown));
		actionDropDown.click();
		}
		catch(Exception e)
		{
			
		}
	}
	public void selectRemoveGroupOption()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(removeGroupForAll));
		removeGroupForAll.click();
	}
	
	public void selectAddGroupPerNameForAll(String group)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(addGroupForAll));
		addGroupForAll.click();
		wait.until(ExpectedConditions.visibilityOf(selectGroupDrop));
		Select select = new Select(selectGroupDrop);
		select.selectByVisibleText(group.trim());
		addGroupButton.click();
		wait.until(ExpectedConditions.visibilityOf(closeButton));
		closeButton.click();
	}
	
	public void selectMultipleUser(int count)
    {
        try {
        	WebDriverWait wait = new WebDriverWait(driver, 10);
            String val = pageLoad.getAttribute("class");
            int counter = 0;
            while(val.contains("loading_compliance loading_user"))
            {
                val = pageLoad.getAttribute("class");
                Thread.sleep(2000);
    			counter++;
    			if(counter>30)
    				Assert.fail("Not able to load page after waiting for 1 minute");
            }
            Thread.sleep(5000);
            wait.until(ExpectedConditions.visibilityOf(checkAllUSer));
            for(int i = 1; i <= count; i++) {
            	driver.findElement(By.xpath(userTableRow + "[" + i + "]/td[1]//label")).click();
            }
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
        	Assert.fail(e.getMessage());
        }
    }
	
	public void clickRemoveAssignmentButton()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(removeAssignmentButton));
		removeAssignmentButton.click();
	}
	public void closeRemoveAssignmentButton()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(assignmentClose));
		assignmentClose.click();
	}
	
	public void validateCourseListRemoveAssignmentPopup(String courses)
	{
		int counter = 0;
		if(courseListName.containsKey(courses+"Option"))
			courses=courseListName.get(courses+"Option").toString();
		
		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(assignmentName)));
		List<WebElement> courseList = driver.findElements(By.xpath(assignmentName));
		String course[] = courses.split(",");
		for(int start = 0; start <= course.length - 1; start++)
		{
			for(int i = 1; i <= courseList.size(); i++)
			{
				String text = driver.findElement(By.xpath("(" + assignmentName + ")[" + i + "]")).getText().trim();
				if(text.equalsIgnoreCase(course[start].trim()))
				{
					driver.findElement(By.xpath("(" + assignmentName + ")[" + i + "]")).click();
					counter = counter + 1;
				}
			}
		}
		Assert.assertTrue(counter == course.length);
	}
	public void validateCourseCountRemoveAssignmentPopup(int count)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		if(count > 0)
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(assignmentName)));
		List<WebElement> courseList = driver.findElements(By.xpath(assignmentName));
		System.out.println("Total course available for remove is " + courseList.size());
		Assert.assertTrue(courseList.size() == count);
	}
	
	public void validateRemoveAssignmentPopupMessage(String message)
	{
		if(AssignmentReport.checkifParmeterAvailable(message))
			message=AssignmentReport.getParmeterAvailable(message);
      
		WebDriverWait wait = new WebDriverWait(driver, 30);
//		wait.until(ExpectedConditions.visibilityOf(assignmentClose));
		wait.until(ExpectedConditions.visibilityOf(removeAssignmentMessage));
		String actualMessage = removeAssignmentMessage.getText().trim();
		System.out.println(actualMessage);
		Assert.assertTrue(actualMessage.equalsIgnoreCase(message));
	}
	public void selectRemoveAssignmentOption()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(removeAssignmentForAll));
		removeAssignmentForAll.click();
	}
	public void selectremoveAssigmentForAll() throws InterruptedException
	{
		wait.until(ExpectedConditions.visibilityOf(dropList.get(0)));
		Assert.assertEquals(dropList.size(), 3);
		String drop="Add to Group,Remove from Group,Add Assignment";
		Assert.assertEquals(dropList.size(),3);
		for(int i=0;i<dropList.size();i++)
		{
			Assert.assertEquals(drop.split(",")[i], dropList.get(i).getText());
		
		}
		
		
		
	}
	
	public void validateifremoveAssigmentForuser() throws InterruptedException
	{
		wait.until(ExpectedConditions.visibilityOf(dropList2.get(0)));
		Assert.assertEquals(dropList2.size(), 9);
		String drop="View User Details,Edit User Details,Send e-mail,Set as Inactive,Add to Group,Remove from Group,Add Assignment,View Change Log,Delete User";
	
		for(int i=0;i<dropList.size();i++)
		{
			Assert.assertEquals(drop.split(",")[i], dropList2.get(i).getText().trim());
		
		}
		
		
		
	}
	public void selectAddAssignmentPerNameForAll(String course)
	{
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(addAssignmentForAll));
		addAssignmentForAll.click();
		wait.until(ExpectedConditions.visibilityOf(selectAssignmentDrop));
		Select select = new Select(selectAssignmentDrop);
//		List<WebElement> dropdown = select.getOptions();
//		for(int i =0; i<dropdown.size() ; i++){
//	         String options = dropdown.get(i).getText();
//	         System.out.println(options);
//	      }
		select.selectByVisibleText(course.trim());
		addAssignmentButton.click();
		wait.until(ExpectedConditions.visibilityOf(assignmentClose));
		assignmentClose.click();
	}
	
	public void selectAddAssignmentPerNameForAll()
	{
		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(addAssignmentForAll));
		addAssignmentForAll.click();
		wait.until(ExpectedConditions.visibilityOf(selectAssignmentDrop));
		Select select = new Select(selectAssignmentDrop);
		selectAssignmentDrop.click();
		select.selectByVisibleText(Assignments.AssgnmentName);
		addAssignmentButton.click();
		wait.until(ExpectedConditions.visibilityOf(assignmentClose));
		assignmentClose.click();
	}
	public void errorMsg(String mg)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(errorMsg));
		System.out.println("Validated Error Msg "+errorMsg.getText());
		Assert.assertEquals(errorMsg.getText(),mg);
		
		wait.until(ExpectedConditions.visibilityOf(closeButton));
		closeButton.click();
	
	}
	
	public void clickonClose()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		
		wait.until(ExpectedConditions.visibilityOf(closeButton));
		closeButton.click();
	}
	public void selectAddAssignmentForAll()
	{
		wait.until(ExpectedConditions.visibilityOf(addAssignmentForAll));
		addAssignmentForAll.click();
		
		wait.until(ExpectedConditions.visibilityOf(selectAssignmentDrop));
		Select select = new Select(selectAssignmentDrop);
		select.selectByIndex(1);
		addAssignmentButton.click();
		wait.until(ExpectedConditions.visibilityOf(assignmentClose));
		assignmentClose.click();
	}

	public void addMutipleUseAssigment(int Assigment, int userCount,int assng)
	{
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userLink));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", userLink);
			Thread.sleep(5000);
			User usr = new User();
			for(int i = assng; i < userCount+assng; i++)
			{	
				usr.userSearch(User.usrEmail[i]);
				Thread.sleep(5000);
				checkAllUser();
				clickAllActionItem();
				wait.until(ExpectedConditions.visibilityOf(addAssignmentForAll));
				addAssignmentForAll.click();
				wait.until(ExpectedConditions.visibilityOf(selectAssignmentDrop));
				Select select = new Select(selectAssignmentDrop);
				selectAssignmentDrop.click();
				select.selectByIndex(Assigment);
				selectAssignmentDrop.click();
				addAssignmentButton.click();
				
				wait.until(ExpectedConditions.visibilityOf(assignmentClose));
				assignmentClose.click();
			}
			
		} 
		catch (NoSuchElementException e) 
		{
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	public void selectAddAssignmentForAll(int group,String msg)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(addAssignmentForAll));
		addAssignmentForAll.click();
		wait.until(ExpectedConditions.visibilityOf(selectAssignmentDrop));
		Select select = new Select(selectAssignmentDrop);
		selectAssignmentDrop.click();
		select.selectByIndex(group);
		selectAssignmentDrop.click();
		
		if(msg.contains("remaining"))
		{
			
			System.out.println("Validate error msg :"+addAssignmentForAllWarning.getText());
			Assert.assertEquals(addAssignmentForAllWarning.getText(),msg);
			
		}
		else if(msg.contains("already"))
		{
			System.out.println("Validate error msg :"+addAssignmentForAlreadyWarning.getText());
			Assert.assertEquals(addAssignmentForAlreadyWarning.getText(),msg);
		}
	}
	
	public void validateifcreateAssignment()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(addAssignmentForAll));
		addAssignmentForAll.click();
		wait.until(ExpectedConditions.visibilityOf(selectAssignmentDrop));
		Select select = new Select(selectAssignmentDrop);
	 Assert.assertFalse(	select.getFirstSelectedOption().getText().contains("Create New Assignment"));;
	 wait.until(ExpectedConditions.visibilityOf(assignmentCancel));
	 assignmentCancel.click();
	}
	
	public void validateifaddAssignment()
	{
		try
		{
		Thread.sleep(5000);	
		}
		catch(Exception e)
		{
			
		}
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", actionDetails);
		wait.until(ExpectedConditions.visibilityOf(addAssignmentLink));
		addAssignmentLink.click();
		wait.until(ExpectedConditions.visibilityOf(selectAssignmentDrop));
		Select select = new Select(selectAssignmentDrop);
	    Assert.assertFalse(	select.getFirstSelectedOption().getText().contains("Create New Assignment"));;
	    wait.until(ExpectedConditions.visibilityOf(assignmentCancel));
	    assignmentCancel.click();
	}

	public void clickonAddAssigment()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		
		addAssignmentButton.click();
		
	}

	public void clickonAssigmentClose()
	{
	
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(assignmentClosebtn));
		assignmentClosebtn.click();
	}
	public void clickonAssigmentCloe()
	{
	
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(assignmentClosebn));
		assignmentClosebn.click();
	}
	
	public void selectAddGroupForAll(int group,String msg)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(addgroupForAll));
		addgroupForAll.click();
		wait.until(ExpectedConditions.visibilityOf(groupSelect));
		Select drpgroup = new Select(groupSelect);
		groupSelect.click();
		drpgroup.selectByVisibleText(User.group[group-1]);
		groupSelect.click();
			
		if(msg.contains("remaining"))
		{
			System.out.println("Validate error msg :"+addGroupForAllWarning.getText());
			Assert.assertEquals(addGroupForAllWarning.getText(),msg);
		}
		else if(msg.contains("already"))
		{
			System.out.println("Validate error msg :"+addGroupAlready.getText());
			Assert.assertEquals(addGroupAlready.getText(),msg);
			
		}
			
	}
	public void selectremoveGroupForAll(int group) throws InterruptedException
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(removegroupForAll));
		removegroupForAll.click();
		Thread.sleep(5000);
		if(!(group==0))
		{
		driver.findElement(By.xpath("//label[text()='"+User.group[group-1]+"']")).click();
//		driver.findElement(By.xpath("//label[text()='group_ThuApr0720:45:46IST2022']")).click();
		
		wait.until(ExpectedConditions.visibilityOf(removeGroupSubmit));
		removeGroupSubmit.click();
		}
		
	}
	public void selectremoveGroupForAll(String group) throws InterruptedException
	{
		wait.until(ExpectedConditions.visibilityOf(removegroupForAll));
		removegroupForAll.click();
		Thread.sleep(3000);
//		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//label[text()='"+group+"']"))));
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//label[text()='"+group+"']"))));
		driver.findElement(By.xpath("//label[text()='"+group+"']")).click();
//		driver.findElement(By.xpath("//label[text()='group_ThuApr0720:45:46IST2022']")).click();

		
		wait.until(ExpectedConditions.elementToBeClickable(removeGroupSubmit));
		
		removeGroupSubmit.click();
		
	}
	public void selectremoveAssigmentForAll(String assigment) throws InterruptedException
	{
		wait.until(ExpectedConditions.visibilityOf(removeassignForAll));
		removeassignForAll.click();
		if(!(assigment==""))
		{
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//label[text()='"+assigment+"']"))));
		driver.findElement(By.xpath("//label[text()='"+assigment+"']")).click();
//		driver.findElement(By.xpath("//label[text()='group_ThuApr0720:45:46IST2022']")).click();
		
		wait.until(ExpectedConditions.visibilityOf(assignmentRemovePop));
		assignmentRemovePop.click();
		}
		
		
	}
	public void clickAddGroup()
	{

		addGroupButton.click();
		
	}
	public void checkAssignmentAlreadyPresent()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", actionDetails);
		wait.until(ExpectedConditions.visibilityOf(addAssignmentLink));
		addAssignmentLink.click();
		wait.until(ExpectedConditions.visibilityOf(selectAssignmentDrop));
		Select select = new Select(selectAssignmentDrop);
		select.selectByIndex(1);
		wait.until(ExpectedConditions.visibilityOf(addAssignmentDuplicateWarning));
		Assert.assertTrue(addAssignmentDuplicateWarning.isDisplayed());
		wait.until(ExpectedConditions.visibilityOf(closeWarning));
		closeWarning.click();
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.contains("loading_compliance loading_user"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
	}

	public void selectAddAssignmentForAllWithoutError()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(addAssignmentForAll));
		addAssignmentForAll.click();
		wait.until(ExpectedConditions.visibilityOf(selectAssignmentDrop));
		Select select = new Select(selectAssignmentDrop);
		selectAssignmentDrop.click();
		select.selectByIndex(1);
		addAssignmentButton.click();
		wait.until(ExpectedConditions.visibilityOf(assignmentClose));
		assignmentClose.click();
	}
	
	public void selectAddAssignmentForAllWithoutErrorCreatedassignment()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(addAssignmentForAll));
		addAssignmentForAll.click();
		wait.until(ExpectedConditions.visibilityOf(selectAssignmentDrop));
		Select select = new Select(selectAssignmentDrop);
		selectAssignmentDrop.click();
		select.selectByVisibleText(Assignments.AssgnmentName);;
		addAssignmentButton.click();
		wait.until(ExpectedConditions.visibilityOf(assignmentClose));
		assignmentClose.click();
	}

	public void clickOnAssignmentTabUnderUser()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(assignmentUnderUser));
		wait.until(ExpectedConditions.elementToBeClickable(assignmentUnderUser));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", assignmentUnderUser);
	}
	
	public void addAssignmentUnderUser()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(addAssignmentUnderUser));
		addAssignmentUnderUser.click();
		wait.until(ExpectedConditions.visibilityOf(selectAssignmentButtonUnderUser));
		selectAssignmentButtonUnderUser.click();
		wait.until(ExpectedConditions.visibilityOf(selectAssignmentDropUnderUser));
		selectAssignmentDropUnderUser.click();
		addAssignmentButtonUnderUser.click();
	}
	
	public void addTitle()
	{
		wait.until(ExpectedConditions.visibilityOf(userLink));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", userLink);
		
		User	usr = new User();
		usr.userSearch(User.userId);
		try
		{
		Thread.sleep(5000);
		}
		catch(Exception e)
		{
			
		}
		wait.until(ExpectedConditions.elementToBeClickable(actionDetails));
		
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(editDetails));
		editDetails.click();
		wait.until(ExpectedConditions.visibilityOf(addTitleDropdown));
		addTitleDropdown.click();
		wait.until(ExpectedConditions.visibilityOf(addTitleValue));
		driver.findElement(By.xpath("//button[@title = 'Select Job Title']//following::li//span[text()='"+OrganizationSettings.titleName+"']")).click();
		submitButton.click();
	
		if(User.usrEmail==null)
		userSearch(userEmail);
		else
			userSearch(usrEmail[0]);
		try
		{
		Thread.sleep(5000);
		}
		catch(Exception e)
		{
			
		}
		
		wait.until(ExpectedConditions.visibilityOf(searchResultJobTitle));
		wait.until(ExpectedConditions.elementToBeClickable(searchResultJobTitle));
		String group = searchResultJobTitle.getText().trim();
		System.out.println(group);
		User.job=group;
//		User.jobtile
		Assert.assertTrue(OrganizationSettings.titleName.equalsIgnoreCase(group) || group.toLowerCase().contains("title") || OrganizationSettings.titleName == null);
	}
	
	public void addTitle(int i)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(userLink));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", userLink);
		
		userSearch(usrEmail[i]);
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(editDetails));
		editDetails.click();
		wait.until(ExpectedConditions.visibilityOf(addTitleDropdown));
		addTitleDropdown.click();
		wait.until(ExpectedConditions.visibilityOf(addTitleValue));
		driver.findElement(By.xpath("//button[@title = 'Select Job Title']//following::li//span[text()='"+OrganizationSettings.titleName+"']")).click();
		submitButton.click();
		try {
			Thread.sleep(3000);
				
		}
		catch(Exception e)
		{
			
		}
		
			userSearch(usrEmail[i]);
				
		try {
			Thread.sleep(5000);
				
		}
		catch(Exception e)
		{
			
		}
		wait.until(ExpectedConditions.visibilityOf(searchResultJobTitle));
		wait.until(ExpectedConditions.elementToBeClickable(searchResultJobTitle));
		String group = searchResultJobTitle.getText().trim();
		System.out.println(group);
		User.job=group;
//		User.jobtile
		Assert.assertTrue(OrganizationSettings.titleName.equalsIgnoreCase(group) || group.toLowerCase().contains("title") || OrganizationSettings.titleName == null);
	}
	
	public void addSpecificTitle(String job)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(userLink));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", userLink);
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(editDetails));
		editDetails.click();
		wait.until(ExpectedConditions.visibilityOf(addTitleDropdown));
		addTitleDropdown.click();
		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(jobtitle))));
		List<WebElement> elements = driver.findElements(By.xpath(jobtitle));
		for(int i = 1; i<= elements.size(); i++)
		{
			String text = driver.findElement(By.xpath("(" + jobtitle + ")[" + i + "]")).getText();
			if(job.trim().toLowerCase().contains(text.toLowerCase().trim()))
			{
				driver.findElement(By.xpath("(" + jobtitle + ")[" + i + "]")).click();
				break;
			}
		}
		submitButton.click();
		wait.until(ExpectedConditions.visibilityOf(searchResultJobTitle));
		wait.until(ExpectedConditions.elementToBeClickable(searchResultJobTitle));
		String group = searchResultJobTitle.getText().trim();
		System.out.println(group);
		Assert.assertTrue(OrganizationSettings.titleName.equalsIgnoreCase(group) || group.toLowerCase().contains("title") || OrganizationSettings.titleName == null);
	}


	public void addSpecificTitle(String job,int m)
	{
		if(User.usrEmail==null)
			userSearch(User.userEmail);
		else 
			userSearch(User.usrEmail[m-1]);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(userLink));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", userLink);
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(editDetails));
		editDetails.click();
		wait.until(ExpectedConditions.visibilityOf(addTitleDropdown));
		addTitleDropdown.click();
		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(jobtitle))));
		List<WebElement> elements = driver.findElements(By.xpath(jobtitle));
		for(int i = 1; i<= elements.size(); i++)
		{
			String text = driver.findElement(By.xpath("(" + jobtitle + ")[" + i + "]")).getText();
			if(job.trim().toLowerCase().contains(text.toLowerCase().trim()))
			{
				driver.findElement(By.xpath("(" + jobtitle + ")[" + i + "]")).click();
				break;
			}
		}
		submitButton.click();
		wait.until(ExpectedConditions.visibilityOf(searchResultJobTitle));
		wait.until(ExpectedConditions.elementToBeClickable(searchResultJobTitle));
		String group = searchResultJobTitle.getText().trim();
		System.out.println(group);
		Assert.assertTrue(OrganizationSettings.titleName.equalsIgnoreCase(group) || group.toLowerCase().contains("title") || OrganizationSettings.titleName == null);
	}
	public void clickonClear()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(searchClear));
		wait.until(ExpectedConditions.elementToBeClickable(searchClear));
		searchClear.click();
	}
	public void addMutipleUserToGroup(int groupCount, int userCount,int assng)
	{
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userLink));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", userLink);
			Thread.sleep(5000);
			User usr = new User();
			for(int i = assng; i < userCount+assng; i++)
			{	
				
				usr.userSearch(User.usrEmail[i]);
				Thread.sleep(5000);
				
				wait.until(ExpectedConditions.visibilityOf(actionDetails));
				actionDetails.click();
				wait.until(ExpectedConditions.visibilityOf(addToGroup));
				addToGroup.click();
				wait.until(ExpectedConditions.visibilityOf(groupSelect));
				
				Select drpgroup = new Select(groupSelect);
				groupSelect.click();
				Thread.sleep(5000);
				drpgroup.selectByVisibleText(User.group[groupCount-1]);
				Thread.sleep(5000);
					
				addGroupButton.click();
				wait.until(ExpectedConditions.visibilityOf(closeButton));
				closeButton.click();
				JavascriptExecutor js = (JavascriptExecutor)driver;
				String pageValue = js.executeScript("return document.readyState").toString();
				int m=0;
				while(!(pageValue.equalsIgnoreCase("complete")))
				{
					Thread.sleep(5000);
					pageValue = js.executeScript("return document.readyState").toString();
					System.out.println(pageValue);
					if(m==pagload)
						break;
					m++;
				}
			}
			
		} 
		catch (NoSuchElementException e) 
		{
			Assert.fail(e.getMessage());
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	public void addMutipleUserToGroup(int groupCount, int userCount)
	{
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userLink));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", userLink);
			Thread.sleep(5000);
			User usr = new User();
			for(int i = 1; i <= groupCount; i++)
			{	
				
				usr.userSearch(User.usrEmail[i-1]);
				Thread.sleep(5000);
				
				wait.until(ExpectedConditions.visibilityOf(actionDetails));
				actionDetails.click();
				wait.until(ExpectedConditions.visibilityOf(addToGroup));
				addToGroup.click();
				wait.until(ExpectedConditions.visibilityOf(groupSelect));
				
//				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userActionDetails + i + "]"))));
//				driver.findElement(By.xpath(userActionDetails + i + "]")).click();
//				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userGroupDetail + i + "]"))));
//				driver.findElement(By.xpath(userGroupDetail + i + "]")).click();
//				wait.until(ExpectedConditions.visibilityOf(groupSelect));
				Select drpgroup = new Select(groupSelect);
				groupSelect.click();
				Thread.sleep(5000);
				drpgroup.selectByVisibleText(User.group[i-1]);
				Thread.sleep(5000);
					
				addGroupButton.click();
				wait.until(ExpectedConditions.visibilityOf(closeButton));
				closeButton.click();
				JavascriptExecutor js = (JavascriptExecutor)driver;
				String pageValue = js.executeScript("return document.readyState").toString();
				int m=0;
				while(!(pageValue.equalsIgnoreCase("complete")))
				{
					Thread.sleep(5000);
					pageValue = js.executeScript("return document.readyState").toString();
					System.out.println(pageValue);
					if(m==pagload)
						break;
					m++;
				}
			}
			if(userCount - groupCount == 1)
			{
				for(int i = 1; i <= groupCount; i++ )
				{
					usr.userSearch(User.usrEmail[userCount-1]);
					Thread.sleep(5000);
					
					wait.until(ExpectedConditions.visibilityOf(actionDetails));
					actionDetails.click();
					wait.until(ExpectedConditions.visibilityOf(addToGroup));
					addToGroup.click();
					wait.until(ExpectedConditions.visibilityOf(groupSelect));
//					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userActionDetails + userCount + "]"))));
//					driver.findElement(By.xpath(userActionDetails + userCount + "]")).click();
//					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userGroupDetail + userCount + "]"))));
//					driver.findElement(By.xpath(userGroupDetail + userCount + "]")).click();
					wait.until(ExpectedConditions.visibilityOf(groupSelect));
					Select drpgroup = new Select(groupSelect);
					groupSelect.click();
					Thread.sleep(5000);
					drpgroup.selectByVisibleText(group[i-1]);
					addGroupButton.click();
					wait.until(ExpectedConditions.visibilityOf(closeButton));
					closeButton.click();
					JavascriptExecutor js = (JavascriptExecutor)driver;
					String pageValue = js.executeScript("return document.readyState").toString();
					int m=0;
					while(!(pageValue.equalsIgnoreCase("complete")))
					{
						Thread.sleep(5000);
						pageValue = js.executeScript("return document.readyState").toString();
						System.out.println(pageValue);
						if(m==pagload)
							break;
						m++;
					}
				}
			}
		} 
		catch (NoSuchElementException e) 
		{
			Assert.fail(e.getMessage());
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	public void addMultipleUserSameGroup(int userCount)
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userLink));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", userLink);
			Thread.sleep(5000);
			for(int i = 1; i <= userCount; i++)
			{	
				if(User.usrEmail==null)
					userSearch(User.userEmail);
				else 
					userSearch(User.usrEmail[i-1]);
				
				Thread.sleep(5000);
				wait.until(ExpectedConditions.visibilityOf(searchResultUserID));
				userId = searchResultUserID.getText();
				System.out.println("User ID is " + userId);
				wait.until(ExpectedConditions.visibilityOf(actionDetails));
				actionDetails.click();
				wait.until(ExpectedConditions.visibilityOf(addToGroup));
				addToGroup.click();
				wait.until(ExpectedConditions.visibilityOf(groupSelect));
//				wait.until(ExpectedConditions.visibilityOf(groupSelect));
				Select drpgroup = new Select(groupSelect);
			
//				drpgroup.selectByIndex(1);
				groupSelect.click();
				System.out.println(User.group[0]);
				drpgroup.selectByVisibleText(User.group[0]);
//			
				addGroupButton.click();
				wait.until(ExpectedConditions.visibilityOf(closeButton));
				closeButton.click();
			}
			 wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchClear));
			wait.until(ExpectedConditions.elementToBeClickable(searchClear));
			searchClear.click();
		
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}

	public void addMultipleUserSamGroup(int userCount)
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userLink));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", userLink);
			Thread.sleep(5000);
			for(int i = 1; i <= userCount; i++)
			{	
				if(User.usrEmail==null)
					userSearch(User.userEmail);
				else 
					userSearch(User.usrEmail[i-1]);
				
				Thread.sleep(5000);
				wait.until(ExpectedConditions.visibilityOf(searchResultUserID));
				userId = searchResultUserID.getText();
				System.out.println("User ID is " + userId);
				wait.until(ExpectedConditions.visibilityOf(actionDetails));
				actionDetails.click();
				wait.until(ExpectedConditions.visibilityOf(addToGroup));
				addToGroup.click();
				wait.until(ExpectedConditions.visibilityOf(groupSelect));
//				wait.until(ExpectedConditions.visibilityOf(groupSelect));
				Select drpgroup = new Select(groupSelect);
			
//				drpgroup.selectByValue(val);
				groupSelect.click();
				Thread.sleep(3000);
				System.out.println(OrganizationSettings.groupName);
				drpgroup.selectByVisibleText(OrganizationSettings.groupName);
//			
				addGroupButton.click();
				wait.until(ExpectedConditions.visibilityOf(closeButton));
				closeButton.click();
			}
			 wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchClear));
			wait.until(ExpectedConditions.elementToBeClickable(searchClear));
			searchClear.click();
		
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	public void addMultipleUserGroup(int userCount)
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userLink));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", userLink);
			Thread.sleep(5000);
			for(int i = 1; i <= userCount; i++)
			{	
				if(User.usrEmail==null)
					userSearch(User.userEmail);
				else 
					userSearch(User.usrEmail[i-1]);
				
				Thread.sleep(5000);
				wait.until(ExpectedConditions.visibilityOf(searchResultUserID));
				userId = searchResultUserID.getText();
				System.out.println("User ID is " + userId);
				wait.until(ExpectedConditions.visibilityOf(actionDetails));
				actionDetails.click();
				wait.until(ExpectedConditions.visibilityOf(addToGroup));
				addToGroup.click();
				wait.until(ExpectedConditions.visibilityOf(groupSelect));
//				wait.until(ExpectedConditions.visibilityOf(groupSelect));
				Select drpgroup = new Select(groupSelect);
			
				drpgroup.selectByIndex(1);
//				groupSelect.click();
//				System.out.println(User.group[0]);
//				drpgroup.selectByVisibleText(User.group[0]);
//			
				addGroupButton.click();
				wait.until(ExpectedConditions.visibilityOf(closeButton));
				closeButton.click();
			}
			 wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchClear));
			wait.until(ExpectedConditions.elementToBeClickable(searchClear));
			searchClear.click();
		
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	
	public void selectHiredate()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		DateFormat dateFormat = new SimpleDateFormat("dd");
		Calendar cal = Calendar.getInstance();
//		cal.add(Calendar.DAY_OF_MONTH, -1);
		String formattedStartDate = dateFormat.format(cal.getTime());
		
		
		hireDate.click();
		wait.until(ExpectedConditions.visibilityOf(calendarProduct));
		WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + " and not(contains(@class, 'disabled day' ))]"));
		reqDate.click();
	}
	
	public void selectHiredate(int i)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		DateFormat dateFormat = new SimpleDateFormat("dd");
		Calendar cal = Calendar.getInstance();
      	cal.add(Calendar.DAY_OF_MONTH, i);
		String formattedStartDate = dateFormat.format(cal.getTime());
		
		
		hireDate.click();
		wait.until(ExpectedConditions.visibilityOf(calendarProduct));
		WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + " and not(contains(@class, 'disabled day' ))]"));
		reqDate.click();
	}
	
	
	public void addMultiuserHireDate(int count, String first, String last)
	{
		usrEmail=new String[count];
		if(userEmail!=null)
		userEail=userEmail;
	
		for(int i=1; i<=count; i++)
		{
			clickCreateUser();
			enterUserDetails(first+i, last+i, String.valueOf(i));
			selectHiredate();
			clickOnSubmit();
			usrEmail[i-1]=userEmail;
		
			try
			{
			Thread.sleep(5000);	
			}
			catch(Exception e)
			{
				
			}
		}
		if(userEail!=null)
		{
		userEmail=userEail;
		}
		else
		{
			userEmail=null;
		}
	}
	
	public void addOrgLevel(int level,String unitName)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(userLink));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", userLink);
		
		
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(editDetails));
		editDetails.click();
		wait.until(ExpectedConditions.visibilityOf(editOrgLink));
		editOrgLink.click();
		wait.until(ExpectedConditions.visibilityOf(editOrgLevelDrop));
		Select select = new Select(editOrgLevelDrop);
		select.selectByValue(String.valueOf(level));
		for(int i = 2; i <= level; i++)
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(selectUnit + i + "']"))));
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(selectUnit + i + "']"))));
			select =new Select(driver.findElement(By.xpath(selectUnit + i + "']")));
			select.selectByIndex(1);
		}		
		wait.until(ExpectedConditions.visibilityOf(editOrgLevelSave));
		editOrgLevelSave.click();
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//span[text() = '" + unitName + "']"))));
		wait.until(ExpectedConditions.elementToBeClickable(submitButton));
		submitButton.click();
		wait.until(ExpectedConditions.visibilityOf(newOrgName));
		String group = newOrgName.getText().trim();
		Assert.assertEquals(unitName, group);
	}

	public void addMultipleUserSameJobTitle(int count)
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userLink));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", userLink);
			Thread.sleep(3000);
			for(int i = 1; i <= count; i++)
			{	
				
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userActionDetails + i + "]"))));
				driver.findElement(By.xpath(userActionDetails + i + "]")).click();
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userEditDetail + i + "]"))));
				driver.findElement(By.xpath(userEditDetail + i + "]")).click();
				wait.until(ExpectedConditions.visibilityOf(addTitleDropdown));
				addTitleDropdown.click();
				wait.until(ExpectedConditions.visibilityOf(addTitleValue));
				addTitleValue.click();
				submitButton.click();
				wait.until(ExpectedConditions.visibilityOf(searchResultJobTitle));
				String title = searchResultJobTitle.getText().trim();
				Assert.assertEquals(OrganizationSettings.titleName, title);
			}
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
		
		
	}

	public void enterMultiUser(String fname, String lName, String id)
	{
		System.out.println(fname);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(firstNameText));
		firstNameText.sendKeys(fname);
		lastNameText.sendKeys(lName);
		userIdText.sendKeys(id);
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		String email =User.getUserEmail( fname + date);
		userEmailText.sendKeys(email);
	}

	public void getUserId_ViewPage()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		viewUser();
		wait.until(ExpectedConditions.visibilityOf(userIdViewPage));
		userId = userIdViewPage.getText();
		
	}
	public void uploadFileForMultipleValidations()
	{
		WebDriverWait wait = new WebDriverWait(driver, 180);
		wait.until(ExpectedConditions.visibilityOf(uploadFileLink));
		uploadFileLink.click();
		wait.until(ExpectedConditions.visibilityOf(buttonClose));
		int count = Integer.parseInt(failureCount.getText());
		Assert.assertTrue(count == 3);
		buttonClose.click();
	}
	
//==============================================================================================================================================	

	public void DuplicteAssignmentError(String message)
	
	{
				
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(DuplicteAssignmentError));
		
		String actualMessage = DuplicteAssignmentError.getText().trim();
		System.out.println(actualMessage);
		Assert.assertTrue(actualMessage.equalsIgnoreCase(message));
		
		
	}
	
	public void AddLevel()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(unitinfoAdd));
		unitinfoAdd.click();
		
		Select select = new Select(LevelDP);
		wait.until(ExpectedConditions.visibilityOf(LevelDP));
		
		LevelDP.click();
		select.selectByVisibleText("Level 2");
		
		wait.until(ExpectedConditions.visibilityOf(Level2DP));
		Level2DP.click();
		Select selectlevel=new Select(Level2DP);
		selectlevel.selectByVisibleText("Automation Test");
		
		Savebtn.click();
	}
	public void UserMoreFileter() throws InterruptedException
	{
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(moreFilter));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", moreFilter);
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOf(userStatusFilter));
		userStatusFilter.click();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOf(UserActive));
		Thread.sleep(2000);
		UserActive.click();
		wait.until(ExpectedConditions.visibilityOf(UserInactive));
		Thread.sleep(2000);
		UserInactive.click();
		wait.until(ExpectedConditions.visibilityOf(moreFilterSearch));
		Thread.sleep(2000);
		moreFilterSearch.click();
		Thread.sleep(3000);
	}
	public void ClickonUserTab()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(UsersTab));
		wait.until(ExpectedConditions.elementToBeClickable(UsersTab));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", UsersTab);
	}
	public void deleteFile(String path)
	{
		try {
			System.out.println("delete file path is " + path);
			File file = new File(path);
			Thread.sleep(5000);
			file.delete();
			boolean dwnld = false;
			dwnld = isFileDownloaded_Ext(downloadPath, ".csv");	
			int m=0;
			while(dwnld)
			{
				file = new File(filePath);
				file.delete();
				dwnld = isFileDownloaded_Ext(downloadPath, ".csv");	
				if(m==pagload)
					break;
				m++;
				
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	//Added By Mohan.Raju
	
	public void RowsPerPage()
	{
		try {
			
			if(userRows.equals(RowsPerPage))
					{
					System.out.println("*******Row per Page is" + RowsPerPage);
					}
			else
			{
				System.out.println("UserRows"+ userRows + " and Rows Per Page" +userRows );
			}
			
		} catch (Exception e) {
			
		}
	}
	
	public void selectAddAssignmentForAll(String name) 
	{
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		System.out.println("**************Sampel Print*****************"+name);
		wait.until(ExpectedConditions.visibilityOf(addAssignmentForAll));
		addAssignmentForAll.click();
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		wait.until(ExpectedConditions.visibilityOf(selectAssignmentDrop));
		selectAssignmentDrop.click();
				
		
		Select select = new Select(selectAssignmentDrop);
		
		String[] options = select.getOptions().toString().split("\n");
				if(options.length==1)
				{
					CancelAssignment.click();
					
					clickAllActionItem();
					
					wait.until(ExpectedConditions.visibilityOf(addAssignmentForAll));
					addAssignmentForAll.click();
					
					wait.until(ExpectedConditions.visibilityOf(selectAssignmentDrop));
					selectAssignmentDrop.click();
					
				}
		
		
		System.out.println(select.getOptions().toString());
		select.selectByVisibleText(name);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		try
		{
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOf(addAssignmentButton));
			addAssignmentButton.click();
			wait.until(ExpectedConditions.visibilityOf(assignmentClose));
			assignmentClose.click();
		}
		catch(Exception e)
		{
			wait.until(ExpectedConditions.visibilityOf(addAssignmentButton));
			addAssignmentButton.click();
			wait.until(ExpectedConditions.visibilityOf(assignmentClose));
			assignmentClose.click();
		}
		
	}
	
	public void addjobTitle(int i)
	{
		try
		{
		Thread.sleep(5000);
		}
		catch(Exception e)
		{
			
		}
		wait.until(ExpectedConditions.elementToBeClickable(actionDetails));
		
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(editDetails));
		editDetails.click();
		wait.until(ExpectedConditions.visibilityOf(addTitleDropdown));
		addTitleDropdown.click();
		wait.until(ExpectedConditions.visibilityOf(addTitleValue));
		driver.findElement(By.xpath("//button[@title = 'Select Job Title']//following::li//span[text()='"+OrganizationSettings.jobTitle[i]+"']")).click();
		submitButton.click();
	
		wait.until(ExpectedConditions.visibilityOf(searchResultJobTitle));
		wait.until(ExpectedConditions.elementToBeClickable(searchResultJobTitle));
		String group = searchResultJobTitle.getText().trim();
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public void navigateAssigmentUnenrollLMS(String course)
	{
		try 
		{
			if(courseListName.containsKey(course))
				course=courseListName.get(course).toString();
		
//			wait.until(ExpectedConditions.visibilityOf(assigmnBtn));
//			assigmnBtn.click();
//			wait.until(ExpectedConditions.visibilityOf(actionDrop));
//			actionDrop.click();
			Thread.sleep(5000);
			System.out.println(unenrollfront+course+unenrollback);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unenrollfront+course+unenrollback))));
			driver.findElement(By.xpath(unenrollfront+course+unenrollback)).click();
			
			wait.until(ExpectedConditions.visibilityOf(unenrollCheckBox));
			unenrollCheckBox.click();
		
			wait.until(ExpectedConditions.visibilityOf(unenrollCourseDeleteYes));
			unenrollCourseDeleteYes.click();
			Thread.sleep(5000);
				
			
			wait.until(ExpectedConditions.visibilityOf(unenrollsuccessmsg));
			System.out.println(unenrollsuccessmsg.getText());
			Assert.assertTrue(unenrollsuccessmsg.getText().contains("Course has been successfully unenrolled."));
//			wait.until(ExpectedConditions.visibilityOf(successCloseButton));
//			successCloseButton.click();
			wait.until(ExpectedConditions.visibilityOf(close));
			
			close.click();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
			
		}
	}
	
	public void clickonEnroll(String course)
	{
		try 
		{
			if(courseListName.containsKey(course))
				course=courseListName.get(course).toString();
		
//			wait.until(ExpectedConditions.visibilityOf(assigmnBtn));
//			assigmnBtn.click();
//			wait.until(ExpectedConditions.visibilityOf(actionDrop));
//			actionDrop.click();
			Thread.sleep(5000);
			System.out.println(unenrollfront+course+unenrollback);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unenrollfront+course+unenrollback))));
			driver.findElement(By.xpath(unenrollfront+course+unenrollback)).click();
			
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
			
		}
	}
	
	public void Unenrollbtnshouldshouldbeavalble(String course)
	{
		try 
		{
			if(courseListName.containsKey(course))
				course=courseListName.get(course).toString();
		
//			wait.until(ExpectedConditions.visibilityOf(assigmnBtn));
//			assigmnBtn.click();
//			wait.until(ExpectedConditions.visibilityOf(actionDrop));
//			actionDrop.click();
			Thread.sleep(5000);
			System.out.println(unenrollfront+course+unenrollback);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unenrollfront+course+unenrollback))));
			driver.findElement(By.xpath(unenrollfront+course+unenrollback)).click();
			Assert.fail("Unenroll button should not be avalable");
		
			
		}
		catch(Exception e)
		{
			wait.until(ExpectedConditions.visibilityOf(close));
			
			close.click();
			
			
		}
	}
	

	@FindBy(xpath = "//*[@id='addAssignPop']")
	WebElement addAsignment;
	
	@FindBy(xpath = "//*[@id='assignAddModalForm']//button[@title='Create New Assignment']")
	WebElement createAssignmentDrop;
	
	
	public void navigateAssigmentViewEdit()
	{
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(assigmnBtn));
			assigmnBtn.click();
//			wait.until(ExpectedConditions.visibilityOf(actionDrop));
//			actionDrop.click();
			wait.until(ExpectedConditions.visibilityOf(addAsignment));
			
			addAsignment.click();
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOf(createAssignmentDrop));
			
			createAssignmentDrop.click();
			System.out.println(assigment+Assignments.AssgnmentName+actionItem);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='assignAddModalForm']//a/span[text()='"+Assignments.AssgnmentName+"']"))));
			
			driver.findElement(By.xpath("//*[@id='assignAddModalForm']//a/span[text()='"+Assignments.AssgnmentName+"']")).click();
			
			wait.until(ExpectedConditions.visibilityOf(addAssignmentButtonUnderUser));
			
			addAssignmentButtonUnderUser.click();
		
			wait.until(ExpectedConditions.visibilityOf(successmsg));
			
			wait.until(ExpectedConditions.visibilityOf(successmsg));
			Assert.assertTrue(successmsg.getText().contains("Assignment added successfully"));
		
			
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	
	/////////////////////////////////////////////////////////////////////////////////////
	@FindBy(xpath = "//select[@id = 'filterSelect_2']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement orgLevelFilterUnSelectAll;
	
	@FindBy(xpath = "//select[@id = 'filterSelect_2']//following-sibling::div//a[text() = 'Select all']")
	WebElement orgLevelFilterSelectAll;
	
	@FindBy(xpath = "(//select[@id = 'filterSelect_2']//following-sibling::div)//input[@type= 'text']")
	WebElement orgLevelFilterFilterSearch;
	
	String userTableRow = "//table[@id = 'learnerTableList']//tbody/tr";
	String userTableHeader = "//table[@id = 'learnerTableList']//th";
	String pagination = "(//div[@class = 'dataTables_paginate paging_simple_numbers'])";
	String jobTitleFilterButton = "//div[@id = 'job_select']//button";
	
	public void validateSortingEachColumn()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(userTableRow + "[1]/td[1]")));
		ArrayList<String> obtainedList = new ArrayList<>(); 
		ArrayList<String> sortedList = new ArrayList<>();
		ArrayList<Date> sortedListDate = new ArrayList<>();
		List<WebElement> tableHeaderRows = driver.findElements(By.xpath(userTableHeader));
		try 
		{
			for(int i = 2; i < tableHeaderRows.size(); i++)
			{
				WebElement column = driver.findElement(By.xpath(userTableHeader + "[" + i + "]"));
				js.executeScript("arguments[0].click()", column);
				Thread.sleep(5000);	
				List<WebElement> elementList= driver.findElements(By.xpath(userTableRow + "/td[" + i + "]"));
				for(WebElement we:elementList)
				{
					System.out.println(we.getText());
					obtainedList.add(we.getText());
				}
				for(String s: obtainedList)
				{
					try
					{
//						Date formatDate = new java.util.Date();
//						SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//						String date = formatter.format(formatDate);
//						
//						System.out.println(s);
						DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");;
						Date reqDate = dateFormat.parse(s);
//						System.err.println(dateFormat.parse(s));
						reqDate=	dateFormat.parse(dateFormat.format(reqDate));
//						System.err.println(dateFormat.parse(dateFormat.format(reqDate)));
						
						sortedList.add(dateFormat.format(reqDate));
					}
					catch(Exception e)
					{
						sortedList.add(s);
//						System.out.println(s);
						
					}
				}
				if(sortedList.size() > 0)
				{
					Collections.sort(sortedList);
					Assert.assertTrue(sortedList.equals(obtainedList));
				}
				else
				{
					Collections.sort(sortedListDate);
					Assert.assertTrue(sortedListDate.equals(obtainedList));
				}				
				js.executeScript("arguments[0].click()", column);
				Thread.sleep(5000);
				obtainedList.removeAll(obtainedList);
				elementList= driver.findElements(By.xpath(userTableRow + "/td[" + i + "]"));
				for(WebElement we:elementList)
				{
				   obtainedList.add(we.getText());
				}
				sortedList.removeAll(sortedList);
				sortedListDate.removeAll(sortedListDate);
				for(String s: obtainedList)
				{
					try
					{
						DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");;
						
						Date reqDate = dateFormat.parse(s);
//						sortedListDate.add(reqDate);
						System.out.println(s);
						sortedList.add(dateFormat.format(reqDate));
						
					}
					catch(Exception e)
					{
						System.out.println(s);
						sortedList.add(s);
					}
				}
				if(sortedList.size() > 0)
				{
					Collections.sort(sortedList);
					Collections.reverse(sortedList);
					Assert.assertTrue(sortedList.equals(obtainedList));
				}
				else
				{
					Collections.sort(sortedListDate);
					Collections.reverse(sortedListDate);
					Assert.assertTrue(sortedListDate.equals(obtainedList));
				}		
				obtainedList.removeAll(obtainedList);
				sortedList.removeAll(sortedList);
				sortedListDate.removeAll(sortedListDate);
			}
		} 
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}		
	}

	public void validatePageNumbers()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(rowPerPageSelect));
		int paginationOption = driver.findElements(By.xpath(pagination)).size();
		System.out.println("Pagination option available on progress report is " + paginationOption);
		Assert.assertTrue(paginationOption == 2);
	}

	public void getLocationPageNumber()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(rowPerPageSelect));
		List<WebElement> statusList = driver.findElements(By.xpath(pagination));
		Point location1 = null, location2 = null;
		for(int i = 1; i <= statusList.size(); i++)
		{
			WebElement elem = driver.findElement(By.xpath(pagination + "[" + i + "]"));
			System.out.println(elem.getLocation());
			if(location1 == null)
				location1 = elem.getLocation();
			else if(location2 == null)
				location2 = elem.getLocation();	
		}
		Assert.assertFalse(location1 == location2);
		int x1 = location1.getX();
		int x2 = location2.getX();
		System.out.println(x1);
		System.out.println(x2);
		
		Assert.assertTrue(x1 == x2);
		
		int y1 = location1.getY();
		int y2 = location2.getY();
		
		System.out.println(y1);
		System.out.println(y2);
		
		Assert.assertFalse(y1 == y2);
	}

	public void validatePaginationDropdown()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(rowPerPageSelect));
		Select select = new Select(rowPerPageSelect);
		List<WebElement> values = select.getOptions();
		for(int i = 0; i <= values.size() - 1; i++)
		{
			int value = Integer.parseInt(values.get(i).getText());
			Assert.assertTrue(value%25 == 0);
		}
	}

	public void selectPaginationDropdown()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(rowPerPageSelect));
		Select select = new Select(rowPerPageSelect);
		List<WebElement> values = select.getOptions();
		for(int i = 0; i <= values.size() - 1; i++)
		{
			int value = Integer.parseInt(values.get(i).getText());
			if(value == 50) {
				values.get(i).click();
				break;
			}
		}
		validateRowCount(50);
	}
	
	public void validateRowCount(int count)
	{
		try {
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		int counter = 0;
		val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_compliance loading_user"))
		{
			val = pageLoad.getAttribute("class");
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load page after waiting for 1 minute");
		}
		Thread.sleep(5000);
		List<WebElement> tableRows = driver.findElements(By.xpath(userTableRow));
		int rowCount = tableRows.size();
		System.out.println(rowCount);
		Assert.assertTrue(rowCount == count || rowCount < count);
		}
		catch(Exception e) {
			Assert.fail(e.getMessage());
		}
	}
	
	public void enterUserDetailsWithSpecialCharacter(String fname, String lName, String id)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(firstNameText));
		String characters = "._-'";
		firstNameText.sendKeys(fname + characters);
		lastNameText.sendKeys(lName + characters);
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		System.out.println(formatDate + "&&" + date);
		if(userId!=null)
        {
			userId1 = id + "_" + date + characters;
			userIdText.sendKeys(userId1);
        }
		else
		{
			userId = id + "_" + date;
			userIdText.sendKeys(userId + characters);
		}
		//formatDate = new java.util.Date().toString();
		date = date.replace(" ", "").replace(":", "").replace("-", "");
		fname = fname.replace(" ", "");
		lName = lName.replace(" ", "");
		userEmail =User.getUserEmail(date);
		userEmailText.sendKeys(userEmail);
		System.out.println(userEmail);
	}

	public void getUserDetailsCoursePage(int number)
	{
		try 
		{
			int rowNumber = generateRandomNumber(number);
			while(rowNumber < 1 )
			{
				rowNumber = generateRandomNumber(number);
			}
			System.out.println(rowNumber);
			Thread.sleep(5000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(" + userRows + ")[" + rowNumber + "]"))));
			int firstNameColumnPosition = getHeaderPosition("First Name");
			userFirstName = driver.findElement(By.xpath("(" + userRows + ")[" + rowNumber + "]/td[" + firstNameColumnPosition + "]")).getText();
			int lastNameColumnPosition = getHeaderPosition("Last Name");
			userLastName = driver.findElement(By.xpath("(" + userRows + ")[" + rowNumber + "]/td[" + lastNameColumnPosition + "]")).getText();
//			int userEmailColumnPosition = getHeaderPosition("Last Name");
//			userEmail = driver.findElement(By.xpath("(" + userRows + ")[" + rowNumber + "]/td[" + j + "]")).getText();
			int userIDColumnPosition = getHeaderPosition("User ID");
			userId = driver.findElement(By.xpath("(" + userRows + ")[" + rowNumber + "]/td[" + userIDColumnPosition + "]")).getText();
			System.out.println(userFirstName + ", " + userLastName + ", " + userEmail + ", " + userId);
		} 
		catch (Exception e) 
		{
			
		}
	}
	
	public void searchAndValidateUserDetailByUserID()
	{
		try {
			searchClear.click();
			WebDriverWait wait = new WebDriverWait(driver, 30);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
            executor.executeScript("arguments[0].click();", searchText);
            wait.until(ExpectedConditions.elementToBeClickable(searchinputText));
			Thread.sleep(5000);
			searchinputText.click();
			searchinputText.clear();
			searchinputText.sendKeys(User.userId);
			System.out.println("searching keyword is " + User.userId);
			searchButton.click();
			int counter = 0;
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			int userIDColumnPosition = getHeaderPosition("User ID");
			String value = driver.findElement(By.xpath("(" + userRows + ")[1]/td[" + userIDColumnPosition + "]")).getText();
			Assert.assertTrue(value.trim().equalsIgnoreCase(User.userId.trim()));			
		} 
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
			Assert.fail(e.getMessage());
		}
	}

	public void searchAndValidateUserDetailByUserFirstName()
	{
		try {
			searchClear.click();
			WebDriverWait wait = new WebDriverWait(driver, 30);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
            executor.executeScript("arguments[0].click();", searchText);
            wait.until(ExpectedConditions.elementToBeClickable(searchinputText));
			Thread.sleep(5000);
			searchinputText.click();
			searchinputText.clear();
			searchinputText.sendKeys(User.userFirstName);
			System.out.println("searching keyword is " + User.userFirstName);
			searchButton.click();
			int counter = 0;
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			int firstNameColumnPosition = getHeaderPosition("First Name");
			String value = driver.findElement(By.xpath("(" + userRows + ")[1]/td[" + firstNameColumnPosition + "]")).getText();
			Assert.assertTrue(value.trim().equalsIgnoreCase(User.userFirstName.trim()));			
		} 
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}
	}

	public void searchAndValidateUserDetailByUserLastName()
	{
		try {
			searchClear.click();
			WebDriverWait wait = new WebDriverWait(driver, 30);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
            executor.executeScript("arguments[0].click();", searchText);
            wait.until(ExpectedConditions.elementToBeClickable(searchinputText));
			Thread.sleep(5000);
			searchinputText.click();
			searchinputText.clear();
			searchinputText.sendKeys(User.userLastName);
			System.out.println("searching keyword is " + User.userLastName);
			searchButton.click();
			int counter = 0;
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			int lastNameColumnPosition = getHeaderPosition("Last Name");
			String value = driver.findElement(By.xpath("(" + userRows + ")[1]/td[" + lastNameColumnPosition + "]")).getText();
			Assert.assertTrue(value.trim().equalsIgnoreCase(User.userLastName.trim()));			
		} 
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
			Assert.fail(e.getMessage());
		}
	}
	public int generateRandomNumber(int number)
	{
		Random objGenerator = new Random();
		int randomNumber = objGenerator.nextInt(number);
		return randomNumber;
	}
	
	public int getHeaderPosition(String header)
	{
		
		int columnCount = 0;
		try {
		//WebDriverWait wait = new WebDriverWait(driver, 30);
		//wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableLabel))));
		List<WebElement> tableHeaderRows = driver.findElements(By.xpath(userTableHeader));
		for(int i = 1; i <=tableHeaderRows.size(); i++)
		{
			String headerName = driver.findElement(By.xpath(userTableHeader + "[" + i +"]")).getText();
			if(headerName.equalsIgnoreCase(header))
			{
				columnCount = i;
				break;				
			}				
		}
		System.out.println("The column position for " + header +" is " + columnCount);
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return columnCount;
	}

	public void enterUserDetailsWithAnotherUnitLevel(String fname, String lName, int level)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(firstNameText));
		firstNameText.sendKeys(fname);
		lastNameText.sendKeys(lName);
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		date = date.replace(" ", "").replace(":", "").replace("-", "");
		fname = fname.replace(" ", "");
		lName = lName.replace(" ", "");
		userEmail =User.getUserEmail(date);
		userEmailText.sendKeys(userEmail);
		userId = userEmail;
		userIdText.sendKeys(userId);
		addUnitLink.click();
		Select select = new Select(levelDropdown);
		wait.until(ExpectedConditions.visibilityOf(levelDropdown));
		select.selectByVisibleText("Level " + level);
		WebElement unitLevelInformation = driver.findElement(By.xpath(unitInformation + level + "']"));
		select = new Select(unitLevelInformation);
		select.selectByVisibleText(OrganizationSettings.newUnitName);
		levelDropdownSubmitButton.click();
	}
	public void validateOrgLevelFilterName(int level) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(unitLevelMainFilter))));
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitLevelMainFilter + "/ancestor::div[@class = 'filterPanelDiv ']/label"))));
		String unitName = driver.findElement(By.xpath(unitLevelMainFilter + "/ancestor::div[@class = 'filterPanelDiv ']/label")).getText();
		Assert.assertTrue(unitName.equalsIgnoreCase("Level " + level + " (s) Name"));
	}
	
	public void validateOrgLevelFilterFilterAvailability()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitLevelMainFilter))));
		driver.findElement(By.xpath(unitLevelMainFilter)).click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	
	public void validateRecordAvailable()
	{
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		String text = driver.findElement(By.xpath(userTableRow + "[1]/td[1]")).getText();
		System.out.println(text);
		Assert.assertFalse(text.equals("No records are present."));
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	
	public void validateRecordNotAvailable()
	{
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		String text = driver.findElement(By.xpath(userTableRow + "[1]/td[1]")).getText();
		System.out.println(text);
		Assert.assertTrue(text.equals("No records are present."));
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	}
	
	public void enterDefaultHireDate()
	{
		try
		{
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(5000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(toHireDate));
			String fromDate = fromHireDate.getAttribute("placeholder");
			Assert.assertEquals("From", fromDate);
			String toDate = toHireDate.getAttribute("placeholder");
			Assert.assertEquals("To Date", toDate );
		}
		catch(Exception e)
		{
			Assert.fail("Issue in hire date selection");
		}
	}

///////////////////////////////////// Org Level //////////////////////////////////////////////////////	
	String unitLevelFilter = "(//select[@id = 'filterSelect_2']//following-sibling::div//ul//label)";

	public void selectSingleOrgLevelFilter() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitLevelFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(unitLevelFilter));
		for (int i = 1; i <= statusList.size(); i++) {
			WebElement elem = driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if (flag == true)
				driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]")).click();
		}
		driver.findElement(
				By.xpath(unitLevelFilter + "//input[contains(@title,'" + OrganizationSettings.newUnitName + "')]"))
				.click();
	}

	public void selectMultiOrgLevelFilter() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitLevelFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(unitLevelFilter));
		for (int i = 1; i <= statusList.size(); i++) {
			WebElement elem = driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if (flag == false) {
				driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]")).click();
				break;
			}
		}

	}

	public void unSelectAllOrgLevelFilter() {
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while (val.equalsIgnoreCase("loading_compliance loading_user")) {
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if (counter > 12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			List<WebElement> statusList = driver.findElements(By.xpath(unitLevelFilter));
			for (int i = 1; i <= statusList.size(); i++) {
				WebElement elem = driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]"));
				boolean flag = elem.isSelected();
				if (flag == false)
					driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]")).click();
			}
			wait.until(ExpectedConditions.visibilityOf(orgLevelFilterUnSelectAll));
			orgLevelFilterUnSelectAll.click();
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void selectAllOrgLevelFilter() {
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while (val.equalsIgnoreCase("loading_compliance loading_user")) {
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if (counter > 12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(orgLevelFilterSelectAll));
			orgLevelFilterSelectAll.click();
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void searchOrgLevelFilter(String courseName) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(orgLevelFilterFilterSearch));
			int counter = 0;
			orgLevelFilterFilterSearch.click();
			orgLevelFilterFilterSearch.clear();
			orgLevelFilterFilterSearch.sendKeys(courseName);
			List<WebElement> statusList = driver
					.findElements(By.xpath(unitLevelFilter + "/parent::li[not(contains(@class,'hidden'))]"));
			while (statusList.size() > 1) {
				statusList = driver
						.findElements(By.xpath(unitLevelFilter + "/parent::li[not(contains(@class,'hidden'))]"));
				Thread.sleep(2000);
				if (counter > 12)
					Assert.fail("Search functionality for user status is not working");
				counter++;
			}
			driver.findElement(By.xpath(unitLevelFilter + "//input[contains(@title,'" + courseName + "')]")).click();
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}

	}
//////////////////////////////////////////////////Job Filter /////////////////////////////

	@FindBy(xpath = "//select[@id = 'job_title_id']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement jobFilterUnSelectAll;

	@FindBy(xpath = "//select[@id = 'job_title_id']//following-sibling::div//a[text() = 'Select all']")
	WebElement jobFilterSelectAll;

	@FindBy(xpath = "(//select[@id = 'job_title_id']//following-sibling::div)//input[@type= 'text']")
	WebElement jobFilterFilterSearch;

	String userJobFilter = "(//select[@id = 'job_title_id']//following-sibling::div//ul//label)";

	String unitLevelMoreFilter = "(//div[@id = 'dynamic_sub_level']/div)[1]//button";
	String unitChildLevelFilter = "(//div[@id = 'dynamic_sub_level']/div)//button";

	public void validateJobFilterFilterAvailability() {
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while (val.equalsIgnoreCase("loading_compliance loading_user")) {
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if (counter > 12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(jobTitleFilterButton))));
			driver.findElement(By.xpath(jobTitleFilterButton)).click();
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void selectSingleJobFilter() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userJobFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userJobFilter));
		for (int i = 1; i <= statusList.size(); i++) {
			WebElement elem = driver.findElement(By.xpath("(" + userJobFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if (flag == true)
				driver.findElement(By.xpath("(" + userJobFilter + "/input)[" + i + "]")).click();
		}
		if (OrganizationSettings.titleName != null)
			driver.findElement(
					By.xpath(userJobFilter + "//input[contains(@title,'" + OrganizationSettings.titleName + "')]"))
					.click();
		else
			driver.findElement(By.xpath("(" + userJobFilter + "//input)[1]")).click();
	}

	public void selectMultiJobFilter() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userJobFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userJobFilter));
		for (int i = 1; i <= statusList.size(); i++) {
			WebElement elem = driver.findElement(By.xpath("(" + userJobFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if (flag == false) {
				driver.findElement(By.xpath("(" + userJobFilter + "/input)[" + i + "]")).click();
				break;
			}
		}

	}

	public void unSelectAllJobFilter() {
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while (val.equalsIgnoreCase("loading_compliance loading_user")) {
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if (counter > 12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			List<WebElement> statusList = driver.findElements(By.xpath(userJobFilter));
			for (int i = 1; i <= statusList.size(); i++) {
				WebElement elem = driver.findElement(By.xpath("(" + userJobFilter + "/input)[" + i + "]"));
				boolean flag = elem.isSelected();
				if (flag == false)
					driver.findElement(By.xpath("(" + userJobFilter + "/input)[" + i + "]")).click();
			}
			wait.until(ExpectedConditions.visibilityOf(jobFilterUnSelectAll));
			jobFilterUnSelectAll.click();
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void selectAllJobFilter() {
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while (val.equalsIgnoreCase("loading_compliance loading_user")) {
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if (counter > 12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(jobFilterSelectAll));
			jobFilterSelectAll.click();
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void searchJobFilter() {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(jobFilterFilterSearch));
			int counter = 0;
			jobFilterFilterSearch.click();
			jobFilterFilterSearch.clear();
			if (OrganizationSettings.titleName == null)
				OrganizationSettings.titleName = driver.findElement(By.xpath(userJobFilter + "[1]")).getText().trim();
			System.out.println(OrganizationSettings.titleName);
			jobFilterFilterSearch.sendKeys(OrganizationSettings.titleName);
			List<WebElement> statusList = driver
					.findElements(By.xpath(userJobFilter + "/parent::li[not(contains(@class,'hidden'))]"));
			while (statusList.size() > 1) {
				statusList = driver
						.findElements(By.xpath(userJobFilter + "/parent::li[not(contains(@class,'hidden'))]"));
				Thread.sleep(2000);
				if (counter > 12)
					Assert.fail("Search functionality for user status is not working");
				counter++;
			}
			driver.findElement(
					By.xpath(userJobFilter + "//input[contains(@title,'" + OrganizationSettings.titleName + "')]"))
					.click();
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}

	}
////////////////////////////////////////////////Org Level Sub Filter //////////////////////////////	

	public void validateOrgLevelSubFilterAvailability() {
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while (val.equalsIgnoreCase("loading_compliance loading_user")) {
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if (counter > 12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitLevelMoreFilter))));
			driver.findElement(By.xpath(unitLevelMoreFilter)).click();
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void selectSingleOrgLevelSubFilter() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitLevelMoreFilter + "[1]"))));
		List<WebElement> statusList = driver
				.findElements(By.xpath(unitLevelMoreFilter + "/following-sibling::div//li//input"));
		for (int i = 1; i <= statusList.size(); i++) {
			WebElement elem = driver.findElement(
					By.xpath("(" + unitLevelMoreFilter + "/following-sibling::div//li//input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if (flag == true)
				driver.findElement(
						By.xpath("(" + unitLevelMoreFilter + "/following-sibling::div//li//input)[" + i + "]")).click();
		}
		driver.findElement(By.xpath(unitLevelMoreFilter + "/following-sibling::div//li//input[contains(@title,'"
				+ OrganizationSettings.newUnitName + "')]")).click();
	}

	public void selectMultiOrgLevelSubFilter() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitLevelMoreFilter + "[1]"))));
		List<WebElement> statusList = driver
				.findElements(By.xpath(unitLevelMoreFilter + "/following-sibling::div//li//input"));
		for (int i = 1; i <= statusList.size(); i++) {
			WebElement elem = driver.findElement(
					By.xpath("(" + unitLevelMoreFilter + "/following-sibling::div//li//input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if (flag == false) {
				driver.findElement(
						By.xpath("(" + unitLevelMoreFilter + "/following-sibling::div//li//input)[" + i + "]")).click();
				break;
			}
		}

	}

	public void unSelectAllOrgLevelSubFilter() {
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while (val.equalsIgnoreCase("loading_compliance loading_user")) {
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if (counter > 12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			List<WebElement> statusList = driver
					.findElements(By.xpath(unitLevelMoreFilter + "/following-sibling::div//li//input"));
			for (int i = 1; i <= statusList.size(); i++) {
				WebElement elem = driver.findElement(
						By.xpath("(" + unitLevelMoreFilter + "/following-sibling::div//li//input)[" + i + "]"));
				boolean flag = elem.isSelected();
				if (flag == false)
					driver.findElement(
							By.xpath("(" + unitLevelMoreFilter + "/following-sibling::div//li//input)[" + i + "]"))
							.click();
			}
			wait.until(ExpectedConditions.visibilityOf(orgLevelFilterUnSelectAll));
			orgLevelFilterUnSelectAll.click();
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void selectAllOrgLevelSubFilter() {
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while (val.equalsIgnoreCase("loading_compliance loading_user")) {
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if (counter > 12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(orgLevelFilterSelectAll));
			orgLevelFilterSelectAll.click();
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void searchOrgLevelSubFilter(String courseName) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(orgLevelFilterFilterSearch));
			int counter = 0;
			orgLevelFilterFilterSearch.click();
			orgLevelFilterFilterSearch.clear();
			orgLevelFilterFilterSearch.sendKeys(courseName);
			List<WebElement> statusList = driver
					.findElements(By.xpath(unitLevelMoreFilter + "/following-sibling::div//input[@type = 'text']"));
			while (statusList.size() > 1) {
				statusList = driver
						.findElements(By.xpath(unitLevelMoreFilter + "/following-sibling::div//input[@type = 'text']"));
				Thread.sleep(2000);
				if (counter > 12)
					Assert.fail("Search functionality for user status is not working");
				counter++;
			}
			driver.findElement(By.xpath(
					unitLevelMoreFilter + "/following-sibling::div//li//input[contains(@title,'" + courseName + "')]"))
					.click();
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}

	}

////////////////////////////////////////////More Filter ////////////////////////////////////////////////////

	String orgLevelFilter = "//label[text() = 'Organization Level']/parent::div//button";

	public void validateChildLevelCount() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(orgLevelFilter))));
		driver.findElement(By.xpath(orgLevelFilter)).click();
		int count = driver.findElements(By.xpath(orgLevelFilter + "/following-sibling::div//li")).size();
		int childCount = driver.findElements(By.xpath(unitChildLevelFilter)).size();
		Assert.assertTrue(childCount == count - 1);
	}

/////////////////////////////////////////////// User Status /////////////////////////////////////////////////////////

	@FindBy(xpath = "//select[@id = 'statusFilter']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement userUnSelectAll;

	@FindBy(xpath = "//select[@id = 'statusFilter']//following-sibling::div//a[text() = 'Select all']")
	WebElement userSelectAll;

	@FindBy(xpath = "(//select[@id = 'statusFilter']//following-sibling::div)//input[@type= 'text']")
	WebElement userFilterSearch;

	String userStatus1 = "(//select[@id = 'statusFilter']//following-sibling::div//ul//label)";


	public void selectSingleUserStatusFilter(String status) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userStatus1 + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userStatus1));
		for (int i = 1; i <= statusList.size(); i++) {
			WebElement elem = driver.findElement(By.xpath("(" + userStatus1 + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if (flag == true)
				driver.findElement(By.xpath("(" + userStatus1 + "/input)[" + i + "]")).click();
		}
		driver.findElement(By.xpath(userStatus1 + "//input[contains(@title,'" + status + "')]")).click();
	}

	public void selectMultiUserStatusFilter(String status) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userStatus1 + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userStatus1));
		for (int i = 1; i <= statusList.size(); i++) {
			WebElement elem = driver.findElement(By.xpath(userStatus1 + "//input[contains(@title,'" + status + "')]"));
			boolean flag = elem.isSelected();
			if (flag == false)
				driver.findElement(By.xpath(userStatus1 + "//input[contains(@title,'" + status + "')]")).click();
		}

	}

	public void unSelectAllStatus() {
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while (val.equalsIgnoreCase("loading_compliance")) {
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if (counter > 12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userUnSelectAll));
			userUnSelectAll.click();
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void selectAllStatus() {
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while (val.equalsIgnoreCase("loading_compliance")) {
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if (counter > 12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userSelectAll));
			userSelectAll.click();
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void searchUserStatus(String status) {
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while (val.equalsIgnoreCase("loading_compliance")) {
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if (counter > 12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(userFilterSearch));
			counter = 0;
			userFilterSearch.click();
			userFilterSearch.clear();
			userFilterSearch.sendKeys(status);
			List<WebElement> statusList = driver
					.findElements(By.xpath(userStatus1 + "/parent::li[not(contains(@class,'hidden'))]"));
			while (statusList.size() > 1) {
				statusList = driver.findElements(By.xpath(userStatus1 + "/parent::li[not(contains(@class,'hidden'))]"));
				Thread.sleep(2000);
				if (counter > 12)
					Assert.fail("Search functionality for user status is not working");
				counter++;
			}
			driver.findElement(By.xpath(userStatus1 + "//input[contains(@title,'" + status + "')]")).click();
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}

	}

/////////////////////////////////////////////////////////// Group Filter /////////////////////////////////////////////

	@FindBy(xpath = "//select[@id = 'group_id']//following-sibling::div/button")
	WebElement groupFilter1;

	@FindBy(xpath = "//select[@id = 'group_id']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement groupFilterUnSelectAll;

	@FindBy(xpath = "//select[@id = 'group_id']//following-sibling::div//a[text() = 'Select all']")
	WebElement groupFilterSelectAll;

	@FindBy(xpath = "(//select[@id = 'group_id']//following-sibling::div)//input[@type= 'text']")
	WebElement groupFilterFilterSearch;

	String userGroupFilter = "(//select[@id = 'group_id']//following-sibling::div//ul//label)";

	public void validateUserGroupFilterAvailability() {
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while (val.equalsIgnoreCase("loading_compliance loading_user")) {
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if (counter > 12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(groupFilter1));
			groupFilter1.click();
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void selectSingleUserGroupFilter() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userGroupFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userGroupFilter));
		for (int i = 1; i <= statusList.size(); i++) {
			WebElement elem = driver.findElement(By.xpath("(" + userGroupFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if (flag == true)
				driver.findElement(By.xpath("(" + userGroupFilter + "/input)[" + i + "]")).click();
		}
		driver.findElement(
				By.xpath(userGroupFilter + "//input[contains(@title,'" + OrganizationSettings.groupName1 + "')]"))
				.click();
	}

	public void selectMultiUserGroupFilter() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userGroupFilter + "[1]"))));
		List<WebElement> statusList = driver.findElements(By.xpath(userGroupFilter));
		for (int i = 1; i <= statusList.size(); i++) {
			WebElement elem = driver.findElement(By.xpath("(" + userGroupFilter + "/input)[" + i + "]"));
			boolean flag = elem.isSelected();
			if (flag == false) {
				driver.findElement(By.xpath("(" + userGroupFilter + "/input)[" + i + "]")).click();
				break;
			}
		}

	}

	public void unSelectAllGroupFilter() {
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while (val.equalsIgnoreCase("loading_compliance")) {
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if (counter > 12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			List<WebElement> statusList = driver.findElements(By.xpath(userGroupFilter));
			for (int i = 1; i <= statusList.size(); i++) {
				WebElement elem = driver.findElement(By.xpath("(" + userGroupFilter + "/input)[" + i + "]"));
				boolean flag = elem.isSelected();
				if (flag == false)
					driver.findElement(By.xpath("(" + userGroupFilter + "/input)[" + i + "]")).click();
			}
			wait.until(ExpectedConditions.visibilityOf(groupFilterUnSelectAll));
			groupFilterUnSelectAll.click();
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void selectAllGroupFilter() {
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while (val.equalsIgnoreCase("loading_compliance")) {
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if (counter > 12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(groupFilterSelectAll));
			groupFilterSelectAll.click();
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public void searchGroupFilter() {
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while (val.equalsIgnoreCase("loading_compliance")) {
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if (counter > 12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(groupFilterFilterSearch));
			counter = 0;
			groupFilterFilterSearch.click();
			groupFilterFilterSearch.clear();
			groupFilterFilterSearch.sendKeys(OrganizationSettings.groupName1);
			List<WebElement> statusList = driver
					.findElements(By.xpath(userGroupFilter + "/parent::li[not(contains(@class,'hidden'))]"));
			while (statusList.size() > 1) {
				statusList = driver
						.findElements(By.xpath(userGroupFilter + "/parent::li[not(contains(@class,'hidden'))]"));
				Thread.sleep(2000);
				if (counter > 12)
					Assert.fail("Search functionality for user status is not working");
				counter++;
			}
			driver.findElement(
					By.xpath(userGroupFilter + "//input[contains(@title,'" + OrganizationSettings.groupName1 + "')]"))
					.click();
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}

	}

	public void validateActionDropDown() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(addAssignmentForAll));
		Assert.assertTrue(addAssignmentForAll.isDisplayed());
		Assert.assertTrue(removeAssignmentForAll.isDisplayed());
		Assert.assertTrue(addGroupForAll.isDisplayed());
		Assert.assertTrue(removegroupForAll.isDisplayed());
	}
	
	public void validateNoCommonAssignmentPopupMessage(String message)
	{
		if(AssignmentReport.checkifParmeterAvailable(message))
			message=AssignmentReport.getParmeterAvailable(message);
      
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(assignmentClose));
		wait.until(ExpectedConditions.visibilityOf(addAssignmentNoCommonMessage));
		String actualMessage = addAssignmentNoCommonMessage.getText().trim();
		System.out.println(actualMessage);
		Assert.assertTrue(actualMessage.trim().contains(message.trim()));
		assignmentClose.click();
	}
	
	

	public void validateAddAssignmentSomePopupMessage(String message)
	{
		if(AssignmentReport.checkifParmeterAvailable(message))
			message=AssignmentReport.getParmeterAvailable(message);
      
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(selectAssignmentDrop));
        selectAssignmentDrop.click();
        Select select = new Select(selectAssignmentDrop);
        select.selectByVisibleText(Assignments.AssgnmentName);;
		wait.until(ExpectedConditions.visibilityOf(assignmentCancel));
		wait.until(ExpectedConditions.visibilityOf(addAssignmentAlreadyMessage));
		String actualMessage = addAssignmentAlreadyMessage.getText().trim();
		Assert.assertTrue(actualMessage.trim().contains(message.trim()));
		addAssignmentButton.click();
	}
	
	public void viewAndEditUserUpdateEmail()
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			int counter = 0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(viewDetails));
			viewDetails.click();
			wait.until(ExpectedConditions.visibilityOf(editViewDetails));
			editViewDetails.click();
			wait.until(ExpectedConditions.visibilityOf(editFirstName));
			String email = editEmail1.getAttribute("value");
			editEmail1.click();
			editEmail1.clear();
			editEmail1.sendKeys(email.replace("@", "_update@"));
			userEmail = email.replace("@", "_update@");
			wait.until(ExpectedConditions.visibilityOf(submitButton));
			Thread.sleep(3000);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", submitButton);
			//submitButton.click();			
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(viewDetails));
			viewDetails.click();
			wait.until(ExpectedConditions.visibilityOf(viewUserEmail));
			String viewEmail = viewUserEmail.getText().trim();
			Assert.assertEquals(email.replace("@", "_update@"), viewEmail);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
	}
	public void validateCourseCountAddGroupPopup()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		if(OrganizationSettings.groupCount > 0)
		{
			wait.until(ExpectedConditions.visibilityOf(selectGroupDrop));
			Select select = new Select(selectGroupDrop);
			List<WebElement> dropdown = select.getOptions();
			System.out.println("Total group available for add is " + dropdown.size());
			Assert.assertTrue(dropdown.size() == OrganizationSettings.groupCount + 1);
		}
		else
			Assert.fail("Groups are not found");
		
	}
	public void validateCourseListRemoveAssignmentPopup()
	{
		int counter = 0;
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(assignmentName)));
		List<WebElement> courseList = driver.findElements(By.xpath(assignmentName));
		for(int i = 1; i <= courseList.size(); i++)
			{
				driver.findElement(By.xpath("(" + assignmentName + ")[" + i + "]")).click();
				counter = counter + 1;
			}
		Assert.assertTrue(counter == courseList.size());
	}
	public void cancelGroupPopup()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(assignmentCancel));
		assignmentCancel.click();
	}
	
	public void validateifActionitem(String item,String Status)
	{
		List<WebElement> actionitem = driver.findElements(By.xpath("//*[@id='action_items']//a"));
		Boolean flag=false;
		for(int i=0;i<actionitem.size();i++)
		{
			if(actionitem.get(i).getText().contains(item))
			{
				flag=true;	
				break;
			}
		}
		if(Status.equals("Present"))
			Assert.assertTrue("Not Present"+item,flag);
		else
			Assert.assertFalse("Present"+item,flag);
	}
	public void clickonActionDetail()
	{
		try
		{
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		actionDetails.click();
		}
		catch (Exception e) {
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
		}
		
	}
	public void validationifdropdown(String item,String Status)
	{
		
		List<WebElement> actionitem = driver.findElements(By.xpath("//*[@id='learnerTableList']//ul//a"));
		Boolean flag=false;
		reuse.waitforsec(8);
		for(int i=0;i<actionitem.size();i++)
		{
			if(actionitem.get(i).getText().contains(item))
			{
				flag=true;	
				break;
			}
		}
		if(Status.equals("Present"))
			Assert.assertTrue("Not Present"+item,flag);
		else
			Assert.assertFalse("Present"+item,flag);
	}
	
	 
	public void validateifviewDetailsAssignment()
	{
		try 
		{
			wait.until(ExpectedConditions.visibilityOf(assigmnBtn));
			assigmnBtn.click();
//			wait.until(ExpectedConditions.visibilityOf(actionDrop));
//			actionDrop.click();
			wait.until(ExpectedConditions.visibilityOf(addAsignment));
			
			addAsignment.click();
			Thread.sleep(5000);
			Assert.assertFalse(dropdownOption.getText().contains("Create New Assignment"));
		
			
		    wait.until(ExpectedConditions.visibilityOf(Close));
		    Close.click();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
			
		}
	}
	public void getAllUserUIListForLMS()
	{
		try {
			val = pageLoad.getAttribute("class");
			int counter = 0;
			while(val.equalsIgnoreCase("loading_compliance loading_user"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
		}
		catch(Exception e) {
		}
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userRows))));
		List<WebElement> tableRows = driver.findElements(By.xpath(userRows));
		int rowCount = tableRows.size();
		List<WebElement> tableHeaderRows = driver.findElements(By.xpath(userTableHeader));
		uiList = new String[rowCount][tableHeaderRows.size() - 1];
		for (int i= 1; i<= rowCount; i++)
		{
			for(int j = 1; j <= tableHeaderRows.size() - 1; j++)
			{
				String textValue = driver.findElement(By.xpath("(" + userRows + ")[" + i + "]/td[" + j + "]")).getText();
				uiList[i-1][j-1] = textValue;
			}
		}
		for (String[] ints : uiList) 
		{
			list_UI.add(Arrays.asList(ints));
		}
	}
	
	@FindBy(xpath = "//h5[@id = 'exampleModalLongTitle' and contains(text(),'View Course')]")
	WebElement viewCoursesPopup;
	
	@FindBy(xpath = "//h5[@id = 'exampleModalLongTitle']//following-sibling::div//a[text() = 'Close']")
	WebElement viewCoursesCloseButton;
	
	public void viewCourses()
	{
		try 
		{
			String val = pageLoad.getAttribute("class");
            int counter = 0;
            while(val.contains("loading_compliance loading_user"))
            {
                val = pageLoad.getAttribute("class");
                Thread.sleep(3000);
    			counter++;
    			if(counter>20)
    				Assert.fail("Not able to load page after waiting for 1 minute");
            }
			WebDriverWait wait = new WebDriverWait(driver, 10);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", actionDetails);
			wait.until(ExpectedConditions.visibilityOf(viewCourses));
			viewCourses.click();
			wait.until(ExpectedConditions.visibilityOf(viewCoursesPopup));
			
		}
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
	}
	
	public void validateViewCourseHeader()
	{
		try 
		{
			String val = pageLoad.getAttribute("class");
            int counter = 0;
            while(val.contains("loading_compliance loading_user"))
            {
                val = pageLoad.getAttribute("class");
                Thread.sleep(3000);
    			counter++;
    			if(counter>20)
    				Assert.fail("Not able to load page after waiting for 1 minute");
            }
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(viewCoursesPopup));
			Assert.assertTrue(driver.findElements(By.xpath("//th[text() = 'Course Name']")).size() > 0);
			Assert.assertTrue(driver.findElements(By.xpath("//th[text() = 'Status']")).size() > 0);
			Assert.assertTrue(driver.findElements(By.xpath("//th[text() = 'Start Date']")).size() > 0);
			Assert.assertTrue(driver.findElements(By.xpath("//a[text() = 'View activities']")).size() > 0);
			viewCoursesCloseButton.click();
		}
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
	}
	
	public void viewAndEditUserEmail()
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			int counter = 0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(viewDetails));
			viewDetails.click();
			wait.until(ExpectedConditions.visibilityOf(editViewDetails));
			editViewDetails.click();
			wait.until(ExpectedConditions.visibilityOf(editFirstName));
			try
			{
			String email = editEmail.getAttribute("value");
			editEmail.click();
			editEmail.clear();
			editEmail.sendKeys(email.toUpperCase());
			}
			catch(Exception e)
			{
				String email = editEmail1.getAttribute("value");
				editEmail1.click();
				editEmail1.clear();
				editEmail1.sendKeys(email.toUpperCase());
			}
			Thread.sleep(5000);
			
			submitButton.click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(viewDetails));
			viewDetails.click();
			wait.until(ExpectedConditions.visibilityOf(viewUserEmail));
			String viewLast = viewUserEmail.getText().trim();
			Assert.assertEquals(email.toUpperCase(), viewLast);
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
		}
	}
	@FindBy(xpath = "//input[@id='searchbox_name_email']")
	WebElement Searchbox_NameEmail;
	
	@FindBy (xpath = "//button[@id=\"searchbtn\"]")
	WebElement SearchButton;
	
	public void searchboxNameEmail(String value) {
		try {
			Thread.sleep(2000);
			Searchbox_NameEmail.clear();
			Searchbox_NameEmail.sendKeys(value);
			SearchButton.click();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	public void ClearTheSearchField()
	{
		try 
		{
			Thread.sleep(2000);
			searchinputText.clear();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}	
	public void searchUser(String userName)
	{
		try 
		{
			Thread.sleep(2000);
			searchinputText.sendKeys(userName);	
		}catch (Exception e) {
			e.printStackTrace();
		}
	}	
	public static String getUserEmail(String formattedEmail)
	{
		String uq=String.valueOf( prop.getProperty("ExecutedBy").toCharArray()[0]) +String.valueOf(prop.getProperty("environment").toCharArray()[0]);
			System.out.println(uq);

			String  email = "";
            if(prop.getProperty("environment").equals("Spartans")) {
                email =prop.getProperty("userDomain").replace("<adduniquestringhere>",formattedEmail);
            }
            else {
                email =prop.getProperty("userDomain").replace("<adduniquestringhere>",formattedEmail+uq);
            }
//		String  email =prop.getProperty("userDomain").replace("<adduniquestringhere>",formattedEmail+uq);
//		String  email =prop.getProperty("userDomain").replace("<adduniquestringhere>",
//				(formattedEmail+uq).substring(1, (formattedEmail+uq).length()));
		Log_User_Name(email);
		
		return email;
	}
	
	public static String getUserEmailid(String id)
	{
		String uq=String.valueOf( prop.getProperty("ExecutedBy").toCharArray()[0]) +String.valueOf(prop.getProperty("environment").toCharArray()[0]);
			System.out.println(uq);

		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		System.out.println(formatDate + "&&" + date);
		//formatDate = new java.util.Date().toString();
		date = date.replace(" ", "").replace(":", "").replace("-", "");
		String email;
		 if(prop.getProperty("environment").equals("Spartans")) {
             email  =prop.getProperty("userDomain").replace("<adduniquestringhere>",date+id);
         }
         else {
             email =prop.getProperty("userDomain").replace("<adduniquestringhere>",date+id+uq);
         }
		Log_User_Name(email);
		
		return email;
	}
	public static String getUserEmail()
	{
		String uq=String.valueOf( prop.getProperty("ExecutedBy").toCharArray()[0]) +String.valueOf(prop.getProperty("environment").toCharArray()[0]);
		System.out.println(uq);
       Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		System.out.println(formatDate + "&&" + date);
		//formatDate = new java.util.Date().toString();
		date = date.replace(" ", "").replace(":", "").replace("-", "");
		String email ;
		
		  if(prop.getProperty("environment").equals("Spartans")) {
              email =prop.getProperty("userDomain").replace("<adduniquestringhere>",date);
          }
          else {
              email =prop.getProperty("userDomain").replace("<adduniquestringhere>",date+uq);
          }
		Log_User_Name(email);
		return email;
	}
	
	public static void Log_User_Name(String useremil)
	{
		try
		{
		String date = new java.util.Date().toString();
		date = date.replace(" ", "");
		date = date.replace(":", "");
		  LocalDateTime myDateObj = LocalDateTime.now();
		    DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("yyyyMMMdd");

		    String formattedDate = myDateObj.format(myFormatObj);

		 FileHandler handler = new FileHandler("ExceptionandOrgLogFolder\\CreateUserEmail"+formattedDate+".log", true);
		 
	        Logger logger = Logger.getLogger("com.qa.pages.User");
	        logger.addHandler(handler);
	        logger.setUseParentHandlers(false);
		    
	        handler.setFormatter(new SimpleFormatter() {
	            private static final String format
	                = "[%1$tF %1$tT] [%2$-7s] %3$s %n";
	 
	            // Override format method
	            @Override
	            public synchronized String format(
	                LogRecord logRecord)
	            {
	                return String.format(
	                    format, new Date(logRecord.getMillis()),
	                    logRecord.getLevel().getLocalizedName(),
	                    logRecord.getMessage());
	            }
	        });
	 
	        logger.info("User email "+TestBase.prop.getProperty("orgName")+" : "+useremil);
	        
			  handler.close();
			  
	       
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
		}
	 
	}
	
	public void deleteUserDedtail()
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			navigateUserModule();
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(deleteUser));
			deleteUser.click();
			wait.until(ExpectedConditions.visibilityOf(deleteYesButton));
			deleteYesButton.click();
			pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(noRecordPresent));
			Assert.assertTrue(noRecordPresent.isDisplayed());
			
		}
		catch (Exception e) 
		{
			
		}
	}
	public void delete_UserDetail()
	{
		try 
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			navigateUserModule();
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(actionDetails));
			actionDetails.click();
			wait.until(ExpectedConditions.visibilityOf(deleteUser));
			deleteUser.click();
			wait.until(ExpectedConditions.visibilityOf(deleteYesButton));
			deleteYesButton.click();
			pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(noRecordPresent));
			Assert.assertTrue(noRecordPresent.isDisplayed());
			
		}
		catch (Exception e) 
		{
		Assert.fail(e.getMessage());	
		}
	}


	public void userSearchinUserPage(String userEmail)
	{
		try 
		{
			navigateUserModule();
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			System.out.println(pageValue);
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(searchClear));
			wait.until(ExpectedConditions.elementToBeClickable(searchClear));
			searchClear.click();
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(searchText));
			wait.until(ExpectedConditions.elementToBeClickable(searchText));
			System.out.println("unit name is " + unitName);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", searchText);
			wait.until(ExpectedConditions.elementToBeClickable(searchinputText));
			searchinputText.sendKeys(userEmail);
				
			executor.executeScript("arguments[0].click();", searchButton);
			
			
			js = (JavascriptExecutor)driver;
			pageValue = js.executeScript("return document.readyState").toString();
			 m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
				if(m==pagload)
					break;
				m++;
			}
			Thread.sleep(10000);
			
			assertEquals(learnerTableList_info.getText(), "Showing 1 to 1 of 1 entries");

			assertEquals(showing1to1.getText(), "Showing 1 to 1 of 1 entries");
			assertEquals(row.size(),1,"Number of row incorrect");
//			assertEquals(userIDField.getText(),userId,"Searched user incorrect");
			
			
		} 
		catch (Exception e) 
		{
		
			Assert.fail("Error "+e.getMessage());
		}
	}

	
	
	public void validate_if_unenrollAllRecurenceoptions()
	{
		
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			reuse.waitforsec(3);
//			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 10);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			
			reuse.waitforsec(3);
			System.out.println(assigment+Assignments.AssgnmentName+actionItem);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(assigment+Assignments.AssgnmentName+actionItem))));
			driver.findElement(By.xpath(assigment+Assignments.AssgnmentName+actionItem)).click();
			
//			wait.until(ExpectedConditions.visibilityOf(unenrollCheckBox));

	
			wait.until(ExpectedConditions.visibilityOf(dropList2.get(0)));
			Assert.assertEquals(dropList2.size(), 5);
			String drop="Manage Assignment,Unenroll Assignment,Stop Recurrence,View Activity Details,View Change Log";
		
			for(int i=0;i<dropList.size();i++)
			{
				Assert.assertEquals(drop.split(",")[i], dropList2.get(i).getText().trim());
			
			}

	}
	
	public void validate_if_Unenroll_Assignment()
	{
		
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				System.out.println(pageValue);
			}
			reuse.waitforsec(3);
//			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driver, 10);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			
			reuse.waitforsec(3);
			System.out.println(assigment+Assignments.AssgnmentName+actionItem);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(assigment+Assignments.AssgnmentName+actionItem))));
			driver.findElement(By.xpath(assigment+Assignments.AssgnmentName+actionItem)).click();
			
//			wait.until(ExpectedConditions.visibilityOf(unenrollCheckBox));

	
			wait.until(ExpectedConditions.visibilityOf(dropList2.get(0)));
			Assert.assertEquals(dropList2.size(), 4);
			String drop="Manage Assignment,Unenroll Assignment,View Activity Details,View Change Log";
		
			for(int i=0;i<dropList.size();i++)
			{
				Assert.assertEquals(drop.split(",")[i], dropList2.get(i).getText().trim());
			
			}

	}
	public void validateassignmentlistingTable(String header,String value)
	{
		reuse.validatethedetails(header, assignmentlisting+"th", value, assignmentlisting+"td","Assignment Title",Assignments.AssgnmentName);
	}

	public void validateHeaderforassignmentlistingHeader (List<String> list) 
	{
		try
		{
		wait.until(ExpectedConditions.visibilityOfAllElements(assignmentlistingHeader));
		reuse.validateTable(list, assignmentlistingHeader);
		}
		catch(Exception e)
		{
		Assert.fail(e.getMessage());
		}
	}
	
	public void clickonshowOnlyOAlabel () 
	{
		
//		wait.until(ExpectedConditions.visibilityOf(showOnlyOA));
		wait.until(ExpectedConditions.visibilityOf(sliderround));
		wait.until(ExpectedConditions.visibilityOf(showOnlyOAlabel));
		
		sliderround.click();
		
	}
	public static String getUserEmailforLMS(String formattedEmail)
	{
		String uq=String.valueOf( prop.getProperty("ExecutedBy").toCharArray()[0]) +String.valueOf(prop.getProperty("environment").toCharArray()[0]);
			System.out.println(uq);


			Date formatDate = new java.util.Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String date = formatter.format(formatDate);
			System.out.println(formatDate + "&&" + date);
			//formatDate = new java.util.Date().toString();
			date = date.replace(" ", "").replace(":", "").replace("-", "");
			
		String  email =date+uq+prop.getProperty("userDomainLMS");
		Log_User_Name(email);
		
		return email;
	}
	
	
	
}
