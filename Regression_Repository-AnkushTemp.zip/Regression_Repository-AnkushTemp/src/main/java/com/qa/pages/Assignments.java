package com.qa.pages;

import java.io.File;
import java.io.FileReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.junit.Assert;

import com.opencsv.CSVReader;
import com.qa.util.TestBase;

public class Assignments extends TestBase
{
	
	@FindBy(xpath = "//button[@id = 'table_export']")
	WebElement exportButton;
	
	@FindBy(xpath = "//*[@id='manualchk']//label[@for='checkbox_all']")
	WebElement checkall;
	
	
	
	@FindBy(xpath = "//button[@id='table_delete']")
	WebElement deleteBtn;
	
	@FindBy(xpath = "//div[contains(@class,'alert-success')]")
	WebElement updateAssignmentSuccessMsg;
	
	@FindBy(xpath = "(//*[@class = 'close'])[1]")
	WebElement successMsgCloseButton;
	
	
	@FindBy(xpath = "//div[contains(@class,'alert-success')]")
	WebElement deleteAssignmentSuccessMsg;
	
	@FindBy(xpath = "//*[@id='ajaxdeletefail']")
	WebElement deleteAlreadyAssignmentSuccessMsg;
	
	

	User usr; 
	
	@FindBy(xpath = "//p[text() = 'Assignment title already exists, please provide a different title.']")
	WebElement assignmentTitleError;
	
	String downloadPath = System.getProperty("user.dir") + prop.getProperty("downloadPath");
	
	@FindBy(xpath="//div/h1[text()='Assignments']")
	WebElement AssignmentTitle;
	
	@FindBy(xpath = "//a[@class ='action_link']")
	WebElement removeUserIcon;
	@FindBy(xpath="//p[@id='searchitemnotfound']//p")
	WebElement NoMatchingStudents;

	@FindBy(xpath = "//button[text() = 'Add']")
	WebElement LearnersAddButton;
	
	@FindBy(xpath = "//button[text() = 'Cancel']")
	WebElement LearnersCancelButton;
	
	@FindBy(xpath = "//a[text()='Assigned Learners ']")
	WebElement assignedLearnersBtn;
	
	
	@FindBy(xpath = "//a[contains(@class,'action_dropdown')]/following::ul[@class='dropdown-menu']//a[text()='Unenroll Assignment']")
	WebElement unenroll;
	
	@FindBy(xpath = "//*[@id='common-modal-content']//label")
	WebElement unenrollCheckBox;

	@FindBy(xpath = "//*[@id='ajaxdeletesuccessmsg']")
	WebElement successmsg;
	
	@FindBy(xpath = "//div[contains(@class,'alert-success')]")
	WebElement unenrollsuccessmsg;
	
	@FindBy(xpath = "//div[contains(@class,'alert-danger')]")
	WebElement unenrollerrormsg;
	
	
	@FindBy(xpath = "//*[@id='common-btn-unenroll']")
	WebElement unenrollCourseDeleteYes;

	@FindBy(xpath = "(//*[@class = 'close'])[1]")
	WebElement successCloseButton;

	@FindBy(xpath = "//*[@id='assgined_learners']/tbody/tr/td")
	WebElement noStudentAreAvailable;

	

	@FindBy(xpath = "//*[@id='selected_user']/tbody/tr/td")
	WebElement noStudentsAreAvailable;

	@FindBy(xpath = "//*[@id='assgined_learners']/tbody/tr/td")
	WebElement noStudentsAreAvailablemessage;
	

	
	
	@FindBy(xpath = "//*[@id='assgined_learners']/tbody/tr/td")
	List<WebElement> assgined_learners;
	
	
	@FindBy(xpath = "//label[@for='checkbox_all']")
	WebElement selectAllUser;
	
	
	
	@FindBy(xpath = "//button[@id='table_delete' and contains(text(),'Remove Learner')]")
	WebElement RemoveLearner;
	
	@FindBy(xpath = "//div[@id='action_items']//button")
	WebElement actionBtn;
	
	
	
	@FindBy(xpath = "//a[@id='unenrollBulkAssignments']")
	WebElement unenrollBulkAssignments;
	
	
	@FindBy(xpath = "//button[@id='add-learners']")
	WebElement AddLearnersButton;
	
	
	
	
	
	@FindBy(xpath = "//*[@id='accordion']//a[text()='More Filters  ']")
	WebElement moreFilters;
	
	@FindBy(xpath = "//*[@id='addLearnersSection']")
	WebElement nextSection;
	
	@FindBy(xpath = "//table[@id = 'selected_user']//td[4]")
	WebElement studentFirstAddResult;

	@FindBy(xpath=("//input[@id='optionsRadios1']"))
	WebElement Assign_Today;
	
	@FindBy(xpath=("//input[@name='due_date']"))
	WebElement Noduedate;
    
	@FindBy(xpath="//input[@id='automatic']")
	WebElement Automatic;
	
	
	@FindBy(xpath="(//div[@class='alert alert-success alert-dismissable'])[1]")
	WebElement AssignSucc;
	
	@FindBy(xpath="//select[@id='0_criteria']")
	WebElement Criteria0;

	@FindBy(xpath="//select[@id='1_criteria']")
	WebElement Criteria1;
	
	@FindBy(xpath="//select[@id='2_criteria']")
	WebElement Criteria2;
	
	@FindBy(xpath="//a[@id='plusbutton']")
	WebElement AddCriteriabtn;
	
	@FindBy(xpath="//a[@id='addassignment']")
	WebElement CreateAssignment;
	
	
	@FindBy(xpath="//textarea[@id='description']")
	WebElement AssignDes;
	
	@FindBy (xpath="//input[@id='optionsRadios3']") //(//button[@class='btn dropdown-toggle btn-default'])[2]")
	WebElement RelativedateDP;
	
	@FindBy(xpath="//span[text()='12 Weeks']")
	WebElement Weekstwelve;
	
	
	
	@FindBy(xpath= "(//span[@class='caret'])[2]")
	WebElement Coursedp;
	
	
	
	@FindBy(xpath= "//span[text()='RQI BLS Entry 2025']")
	WebElement CourseName;
	
	
	@FindBy(xpath = "//a[text() = 'Create Assignment']")
	WebElement createAssignment;

	@FindBy(xpath="//a[text()='Create Assignment']")
	WebElement CreateAssignBtn;
	
	@FindBy(xpath = "//input[@name = 'createAssignment' and @id = 'automatic']")
	WebElement automatic;
	
	@FindBy(xpath = "//body[@class]")
	WebElement pageLoad;
	
	@FindBy(xpath = "//button[@title = 'Select course/curriculum']/span")
	WebElement selectCourseDrp;
	
//	@FindBy(xpath = "//*[@id=\"assignment_name\"]")
//	WebElement assignmentname;
//	
//	
	@FindBy(xpath = "(//a[@role = 'option'])[2]/span")
	WebElement selectCourseName;
	
	@FindBy(xpath = "//input[@name = 'assignment_name']")
	WebElement assignmentName;
	
	@FindBy(xpath = "(//a[text() = 'Create Assignment'])[1]")
	WebElement createAssignmentButton;
	
	
	@FindBy(xpath = "(//a[text() = 'Create Assignment'])[2]")
	WebElement createAutoAssignmentButton;
	
	@FindBy(xpath = "(//a[text() = 'Create Assignment'])[1]")
	WebElement AssignmentBtn;
	
	
			@FindBy(xpath = "(//a[text() = 'Update Assignment'])[2]")
			WebElement updateAssignmentButton;

	@FindBy(xpath = "//table[@id = 'assignmentlisting']//td[1]")
	WebElement assignmentTitle;
	
	@FindBy(xpath = "//div[@class = 'dropdown']/a")
	WebElement assignmentDropdown;
	
	
	
	@FindBy(xpath = "//*[@id='assignmentlisting_info']")
	WebElement assignmentlisting_info;
	
	@FindBy(xpath = "//a[@title = 'Edit Assignment']")
	WebElement assignmentEditOption;
	
	@FindBy(xpath = "//a[text() = 'Manage Assignment']")
	WebElement assignmentViewOption;
	
	@FindBy(xpath = "//a[text() = 'Manage Assignment']")
	WebElement assignmentManageOption;
	
	 
	
	@FindBy(xpath = "//input[@name = 'student_name_search']")
	WebElement studentSearchText;
	
	@FindBy(xpath = "//span[@role = 'status']")
	WebElement studentSearchResult;
	
	@FindBy(xpath = "//li[@role = 'presentation']")
	WebElement studentSearchOption;
	
	@FindBy(xpath = "//a[text() = 'Add']")
	WebElement studentAddButton;
	
	
	
	
	@FindBy(xpath = "//*[@id='save_assignment']//button[@title='Select Plan']")
	WebElement subscriptionPlan;
	
	@FindBy(xpath = "//*[@class='dropdown-menu open']//input")
	WebElement subscriptionPlanInput;
	
	
	@FindBy(xpath = "//*[@id='save_assignment']//label[text()='Student Pay']")
	WebElement studentPayRadio;
	
	@FindBy(xpath = "//label[text()='Organization Pay']")
	WebElement OrganizationPayRadio;
	
	
	@FindBy(xpath = "//table[@id = 'selected_user']//td")  //table[@id = 'selected_user']//td[3]
	WebElement studentAddResult;
	
	@FindBy(xpath = "//p[@id = 'searchitemnotfound']")
	WebElement errorMessage;
	
	@FindBy(xpath = "//*[@id='coursenotfound']")
	WebElement courseMessage;
	
	
	@FindBy(xpath ="//div[@id = 'update-btn']//a[text() = 'Update Assignment']") //section[@id = 'automaticSection']//a[text() = 'Update Assignment']")  //(//a[text() = 'Update Assignment'])[2]
	WebElement updateAutoAssignment;
	
	@FindBy(xpath = "//input[@value = 'specific_due_date']//parent::label")
	WebElement radioSpecificDate;
	
	@FindBy(xpath = "//input[@name = 'assignment_name']")
	WebElement assignmentTitleSearchBox;
	//*]
	
	@FindBy(xpath = "//input[@value='specific_Date']//parent::label")
	WebElement radioStartSpecificDate;
	
	@FindBy(xpath = "//input[@name = 'assignment_specific_due_date']")
	WebElement specificDate;
	

	@FindBy(xpath = "//input[@name = 'assignment_specific_date']")
	WebElement StartspecificDate;
	
	
	
	@FindBy(xpath = "//div[@class='datepicker-days']")
	WebElement calendarProduct;
	
	@FindBy(xpath="//input[@id='starthiredate']")   //(   // 
	WebElement HireDateCalendar;
	
	

	@FindBy(xpath="//*[@id='endhiredate']")   //(   // 
	WebElement HireendDateCalendar;
	
	
	@FindBy(xpath = "//input[@value = 'relative_date']//parent::label") //     ////input[@id='optionsRadios3']
	WebElement radioRelativeDate;
	
	@FindBy(xpath = "//select[@id = 'relative_due_date']")
	WebElement selectRelativeDate;
	
	@FindBy(xpath = "//input[@value='relative_due_date']")
	WebElement disableRelativeDate;
	
	
	@FindBy (xpath="(//button[@class='btn dropdown-toggle btn-default'])[2]")
	WebElement RelavtiveDateNew;
	@FindBy(xpath = "//button[@title = '1 Week']/span[text()]")
	WebElement selectDateDrp;
	
	@FindBy(xpath = "//table[@id = 'selected_user']//td[9]")
	WebElement studentAddDelete;
	
	@FindBy(xpath = "//input[@id = 'grid_search']")
	WebElement studentSearchBox;
	
	@FindBy(xpath = "//select[@id = 'manual_delivery']")
	WebElement studentSearchAssignmentDelivery;
	
	@FindBy(xpath = "//table[@id = 'selected_user']//td[1]")
	WebElement NoStudentAvailable;
	
	@FindBy(xpath = "(//a[text() = 'Update Assignment'])[2]")
	WebElement updateManualAssignment;
	
	@FindBy(xpath = "//select[@id = '0_criteria']")
	WebElement selectCriteriaDropdown;
	
	@FindBy(xpath = "//select[@id = '1_criterias_data_list']")
	WebElement selectCriteriaValueDropdown;
	
	
	
	@FindBy(xpath = "//input[@id = 'grid_search_auto']")
	WebElement studentAutoSearchBox;
	
	@FindBy(xpath = "//table[@id = 'auto_selected_user']//td[3]")
	WebElement studentAutoAddResult;
	
	@FindBy(xpath = "//*[@id='auto_selected_user']/tbody/tr[1]/td[6]")
	WebElement deliveryValue;
	
	
	@FindBy(xpath = "//table[@id = 'auto_selected_user']//td[6]")
	WebElement studentAutoAssignmentResult;
	
	
	@FindBy(xpath = "//table[@id = 'auto_selected_user']//td[3]")
	WebElement studentAutoUnitLevel;
	
	@FindBy(xpath = "(//select[@disabled])[1]")
	WebElement editSelectCriteria;
	
	
	@FindBy(xpath = "//a[@class = 'action_dropdown']")
	WebElement actionDetails;
	
	@FindBy(xpath = "//a[text() = 'Manage Assignment']")
	WebElement editAssignmentViewPage;
	
	@FindBy(xpath = "//a[text() = 'Manage Assignment']")
	WebElement viewAssignmentPage;
	
	@FindBy(xpath = "//a[text() = 'Add Criteria']")
	WebElement addCriteriaButton;
	
	@FindBy(xpath = "//table[@id = 'assignmentlisting']//td[6]")
	WebElement assignmentStudentCount;
	
	@FindBy(xpath = "//input[@id='starthiredate']")   //    //input[@name = 'firsthiredate']
	WebElement hireDate;
	
	@FindBy(xpath = "//*[@id='endhiredate']")   //    //input[@name = 'firsthiredate']
	WebElement endhiredate;
	
	
	@FindBy(xpath = "//a[text() = '+ Add Criteria']")
	WebElement addCriteria;
	
	
	@FindBy(xpath = "//a[text() = '+ Add Criteria']")
	WebElement add_Criteria;
	

	@FindBy(xpath = "//a[text() = 'Delete Assignment']")
	WebElement assignmentDeleteOption;
	
	@FindBy(xpath = "//button[text() = 'Yes']")
	WebElement deleteYesButton;
	
	@FindBy(xpath = "(//input[@name = 'is_recurrence']//parent::label)[1]")
	WebElement enableRecurrenceYes;
	
	@FindBy(xpath = "(//input[@name = 'is_recurrence']//parent::label)[2]")
	WebElement enableRecurrenceNo;

	@FindBy(xpath = "//input[@name = 'recurrence_end_date']")
	WebElement recurrenceEndDate;
	
	@FindBy(xpath = "//input[@id = 'recurrence_end_date_type_2']")
	WebElement recurrenceSpecificEndDate;
	
	@FindBy(xpath = "//input[@id = 'recurrence_end_date_occurences']")
	WebElement recurrenceSpecificEndDateCount;
	
	@FindBy(xpath = "//input[@id = 'recurrence_frequency_number']")
	WebElement recurrenceFreqNumb;
	
	@FindBy(xpath = "//select[@id = 'recurrence_frequency_unit']")
	WebElement recurrenceFreqUnit;
	
	@FindBy(xpath = "//select[@id = 'recurrence_frequency_based_on']")
	WebElement recurrenceFreqBased;
	
	
	@FindBy(xpath = "(//input[@name = 'recurrence_due_date_type']//parent::label)[1]")
	WebElement recurrenceOriginalDueDate;
	
	@FindBy(xpath = "(//input[@name = 'recurrence_due_date_type']//parent::label)[2]")
	WebElement recurrenceRelativeDueDate;
	
	@FindBy(xpath = "//input[@id = 'recurrence_due_date_number']")
	WebElement recurrenceRelativeDueDateNumber;
	
	@FindBy(xpath = "//select[@id = 'recurrence_due_date_unit']")
	WebElement recurrenceRelativeDueDateUnit;
	
	@FindBy(xpath = "//*[@id='assgined_learners_length']//select")
	WebElement pagination;
	
	@FindBy(xpath = "//*[@id='selected_user_length']//select")
	WebElement editpagination;
	

	@FindBy(xpath = "//*[@id='alert_model_body']")
	WebElement popupMessage;

	
	
	@FindBy(xpath = "//button[@id = 'table_export_auto']")
	WebElement exportAutoButton;
	
	
	@FindBy(xpath="//*[@id='studentFigures']/div")
	WebElement errorMsg;
	
	@FindBy(xpath="//*[@id='manualSection']/div[1]/strong")
	WebElement manualSectionStrong;
	
	@FindBy(xpath="//*[@id='manualSection']//div[contains(@class,'title')]")
	WebElement manualSectiontitle;
	
	
	
	@FindBy(xpath = "//*[@id=\"studentFigures\"]/div[@class=\"alert bgGray col-md-8 text-uppercase\"]")
	WebElement alert;
	
	@FindBy(xpath = "//input[@id = 'grid_search']")
	WebElement studentManSearchBox;
	
	@FindBy(xpath = "//div[@id = 'selected_user_info']")
	WebElement userListRange;


	@FindBy(xpath = "//div[@id = 'auto_selected_user_info']")
	WebElement userAutoListRange;

	
	@FindBy(xpath = "//*[@id='selected_user']/tbody/tr[1]/td[7]")
	WebElement manualdeliveryValue;
	
	@FindBy(xpath = "//p[@id='assignmentTab']")
	WebElement assignmentStep1;
	
	
	
	@FindBy(xpath = "//*[@id='collapseOne']//button[text()='Search']")
	WebElement SearchButton;
	
	
	@FindBy(xpath = "//p[@class='tab-learner']")
	WebElement assignmentStep2;
	
	@FindBy(xpath = "//a[@title='Edit Assignment']")
	WebElement EditAssignmentBtn;
	
	
	String autoTotalUser = "//*[@id='assgined_learners']//tbody//tr";
	
	String manTotalUser = "//*[@id='selected_user']//tbody//tr";
	
	
	String val;
	String dropdown="//*[@id=\"productInner\"]/tr[1]/td[8]/div/ul/li";
	String datePick = "//td[contains(@class, 'day' ) and text() = ";
	String relativedate = "(//a[@role = 'option'])[";
	String userTable = "//table[@id = 'selected_user']//tbody//tr";
	String studentTable = "//table[@id = 'auto_selected_user']//tbody//tr";
	String criteria = "//select[@id = '";
	String criteriaValue = "//select[@id = '";
	String courseList = "//button[@title = 'Select course/curriculum']/following-sibling::div//span[1]";
	String assignmentRows = "//table[@id = 'assignmentlisting']//tbody//tr";
	String selectCriteriaDropdown1 = "//select[@id = '";//
	String selectCriteriaValueDropdown1 = "//select[@id = '";//1_criterias_data_list']";
	String relation="(//*[@id='relation'])[";
	By table = By.xpath("//table[@id = 'selected_user']/tbody/tr[1]/td");
	
	String userRows = "//table[@id = 'selected_user']//tr[@class]";
	String autoUserRows = "//table[@id = 'auto_selected_user']//tr[@class]";

	String selected_user = "//table[@id='selected_user']//";

	String showentries = "(//div[@class='dataTables_info'])";
//	String selected_user = "//table[@id='selected_user']//";

	String headerxpth="(//*[@aria-describedby='assgined_learners_info']//tr)[1]/";
//	String table="(//*[@id='purchase_history_report']//tr[@role='row'])";
	String tablesmultiple="(//*[@aria-describedby='assgined_learners_info']//tbody//tr[@role='row'])";

	
	
	List<List<String>> list_UI = new ArrayList<>();
	List<List<String>> list_report = new ArrayList<>();
	public static String  uiList[][];
	public static int studentCount;

	String remove="(//*[@id='selected_user']//a[@title='Remove Student'])";
	public static String name,AssgnmentName,titleName;
	
	public Assignments() 
	{
		PageFactory.initElements(driver, this);
		driver.manage().timeouts().setScriptTimeout(20, TimeUnit.SECONDS);
	}
	
	public void validatewarning()
	{
		if(alert.isDisplayed())
		{
		System.out.println(alert.getText());	
	    }
		else
			Assert.fail("Message not displayed");
		
	}
	public void selectEnableRecurrence(String recurrence)
	{
		String val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
		}
		switch(recurrence.toLowerCase().trim())
		{
			case "yes":
				wait.until(ExpectedConditions.visibilityOf(enableRecurrenceYes));
				enableRecurrenceYes.click();
				break;
			case "no":
				wait.until(ExpectedConditions.visibilityOf(enableRecurrenceNo));
				enableRecurrenceNo.click();
				break;
		}
	}
	public void selectRecurrenceSpecificDate(int count, String dateFreq)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(recurrenceEndDate));
		String val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
		}
		LocalDate localDate = LocalDate.now();
		switch(dateFreq.toLowerCase().trim())
		{
		case "days":
			LocalDate addedDays = localDate.plusDays(count);
			recurrenceEndDate.sendKeys(addedDays.toString());
			break;
		case "months":
			LocalDate addedMonths = localDate.plusMonths(count);
			recurrenceEndDate.sendKeys(addedMonths.toString());
			break;
		case "weeks":
			LocalDate addedWeeks = localDate.plusWeeks(count);
			recurrenceEndDate.sendKeys(addedWeeks.toString());
			break;		
		}
	}
	public void selectRecurrenceSpecificNumber(int count)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(recurrenceEndDate));
		String val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
		}
		recurrenceSpecificEndDate.click();
		wait.until(ExpectedConditions.visibilityOf(recurrenceSpecificEndDateCount));
		recurrenceSpecificEndDateCount.click();
		recurrenceSpecificEndDateCount.clear();
		recurrenceSpecificEndDateCount.sendKeys(Integer.toString(count));
	}
	public void selectRecurrenceDueDate(String recurrenceDueDateType, int number,String unit)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		
		String val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
		}
		switch(recurrenceDueDateType.trim())
		{
			case "Based on Original Due Date":
				wait.until(ExpectedConditions.visibilityOf(recurrenceOriginalDueDate));
				recurrenceOriginalDueDate.click();
				break;
			case "Relative Due Date":
				reuse.waitforsec(7);
				wait.until(ExpectedConditions.visibilityOf(recurrenceRelativeDueDate));
				recurrenceRelativeDueDate.click();
				wait.until(ExpectedConditions.visibilityOf(recurrenceRelativeDueDateNumber));
//				recurrenceRelativeDueDateNumber.click();
				js.executeScript("arguments[0].click();", recurrenceRelativeDueDateNumber);

				recurrenceRelativeDueDateNumber.clear();
				recurrenceRelativeDueDateNumber.sendKeys(Integer.toString(number));
				reuse.waitforsec(6);
				Select selectUnit = new Select(recurrenceRelativeDueDateUnit);
				selectUnit.selectByValue(unit.toUpperCase());
				break;
		}		
	}
	public void enterRecurrenceFrequency(int number,String unit, String basis)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		String val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
		}
		wait.until(ExpectedConditions.visibilityOf(recurrenceFreqNumb));
		recurrenceFreqNumb.click();
		recurrenceFreqNumb.clear();
		recurrenceFreqNumb.sendKeys(Integer.toString(number));
		Select selectUnit = new Select(recurrenceFreqUnit);
		selectUnit.selectByValue(unit.toUpperCase());
		Select selectBasedOn = new Select(recurrenceFreqBased);
		if(basis.equalsIgnoreCase("assignment start date"))
			selectBasedOn.selectByValue("START_DATE");
		else
			selectBasedOn.selectByValue(basis.toUpperCase().trim().replace(" ", "_"));
	}
	public void selectRecurrenceDueDateWithString(String recurrenceDueDateType, String number,String unit)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		String val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
		}
		switch(recurrenceDueDateType.trim())
		{
			case "Based on Original Due Date":
				wait.until(ExpectedConditions.visibilityOf(recurrenceOriginalDueDate));
				recurrenceOriginalDueDate.click();
				break;
			case "Relative Due Date":
				wait.until(ExpectedConditions.visibilityOf(recurrenceRelativeDueDate));
				recurrenceRelativeDueDate.click();
				wait.until(ExpectedConditions.visibilityOf(recurrenceRelativeDueDateNumber));
				recurrenceRelativeDueDateNumber.click();
				recurrenceRelativeDueDateNumber.clear();
				recurrenceRelativeDueDateNumber.sendKeys(number);
				Select selectUnit = new Select(recurrenceRelativeDueDateUnit);
				selectUnit.selectByValue(unit.toUpperCase());
				break;
		}		
	}
	public void clickOnCreateAssignment()
	{
		wait.until(ExpectedConditions.elementToBeClickable(createAssignment));
//		wait.until(ExpectedConditions.visibilityOf(createAssignment));
		createAssignment.click();
	}
	public void CreateAssignmentBtnshouldnotbeAvailable()
	{
		try
		{
		wait.until(ExpectedConditions.visibilityOf(createAssignment));
		wait = new WebDriverWait(driver, 30);
		createAssignment.click();
		Assert.fail("Create Btn available");
		
		}
		catch (Exception e) {
		
			System.out.println("Create btn/Delete Btn is should not avalible");
		}
	}
	
//	clickonActionDetail
	public void clickonActionDetail()
	{
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		wait.until(ExpectedConditions.elementToBeClickable(actionDetails));
		actionDetails.click();
		
	
	}
	public void validationifdropdown(String option,String Status)
	{
	
				List<WebElement> dropdn = driver.findElements(By.xpath(dropdown));
				Boolean flag=false;
				
			for(int i=0;i<dropdn.size();i++)
			{
				if(dropdn.get(i).getText().contains(option))
				{
					flag=true;	
					break;
					
				}
			}
			
			if(Status.equals("Present"))
				Assert.assertTrue("Not Present"+option,flag);
			else
				Assert.assertFalse("Present"+option,flag);
		
		
	}
	public void verifyDownloadFile() {
		try {
			usr = new User();
			int counter = 0;
			boolean dwnld = false;
			do {
				Thread.sleep(5000);
				dwnld = usr.isFileDownloaded_Ext(downloadPath, ".csv");
				counter = counter + 1;
				if(counter==pagload)
					break;
				else
				{
					try {
						Thread.sleep(550);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			} while (dwnld == false);
		} catch (Exception e) {
			Assert.fail(e.getMessage());
			System.out.println(e.getMessage());
		}
	}
	
	
	
	
	public void selectAutomatic()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(automatic));
		wait.until(ExpectedConditions.elementToBeClickable(automatic));
		String val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
		}
		automatic.click();
	}
	
	public void assignmentFromUser()
	{
		wait.until(ExpectedConditions.visibilityOf(selectCourseDrp));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", selectCourseDrp);
		wait.until(ExpectedConditions.visibilityOf(selectCourseName));
		executor.executeScript("arguments[0].click();", selectCourseName);
		
		String date = new java.util.Date().toString();
		date = date.replace(" ", "");
		assignmentName.sendKeys(date);
		
	}
	
	public void assignmentFromUser(String course)
	{
		String assigment=course;
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
			
		course=course.replace("Â","");
		
		System.out.println(course);
		wait.until(ExpectedConditions.visibilityOf(selectCourseDrp));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", selectCourseDrp);
		try
		{
			Thread.sleep(4000);
		
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//li/a/span[text()='"+course+"']"))));
			executor.executeScript("arguments[0].click();", driver.findElement(By.xpath("//li/a/span[text()='"+course+"']")));
			
		}
		catch(Exception e)
		{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//li/a/span[contains(text(),'"+course+"')]"))));
			executor.executeScript("arguments[0].click();", driver.findElement(By.xpath("//li/a/span[contains(text(),'"+course+"')]")));
				
		}
		
		
			
		String date = new java.util.Date().toString();
		date = date.replace(" ", "");
		assignmentName.clear();
		assignmentName.sendKeys(assigment+date);
		AssgnmentName=assigment+date;
	}


	public void assignmentFromUserSpecificCourse(String course)
	{
		String assigment=course;
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
		
		course=course.replace("Â", "");
		System.out.println(course);
		
		wait.until(ExpectedConditions.visibilityOf(selectCourseDrp));
		int m=0;
		String val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		Boolean flg=false;
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", selectCourseDrp);
		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(courseList))));
		List<WebElement> elements = driver.findElements(By.xpath(courseList));
		for(int i = 1; i<= elements.size(); i++)
		{
			String text = driver.findElement(By.xpath("(" + courseList + ")[" + i + "]")).getText();
			System.out.println(text);
			if(course.trim().toLowerCase().equals(text.toLowerCase().trim()))
			{
		
				driver.findElement(By.xpath("(" + courseList + ")[" + i + "]")).click();
				flg=true;
				break;
			}
		}
		Assert.assertTrue("Course not found", flg);
		String date = new java.util.Date().toString();
		date = date.replace(" ", "");
		assignmentName.clear();
		assignmentName.sendKeys(assigment+date);
		AssgnmentName=assigment+date;
	}
	
	public void assignmentFromUserSpecificCourseE(String course)
	{
		String assigment=course;
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
		
		course=course.replace("Â", "");
		System.out.println(course);
		
		wait.until(ExpectedConditions.visibilityOf(selectCourseDrp));
		int m=0;
		String val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", selectCourseDrp);
		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(courseList))));
		List<WebElement> elements = driver.findElements(By.xpath(courseList));
		for(int i = 1; i<= elements.size(); i++)
		{
			String text = driver.findElement(By.xpath("(" + courseList + ")[" + i + "]")).getText();
			System.out.println(text);
			if(course.trim().toLowerCase().equals(text.toLowerCase().trim()))
			{
		
				driver.findElement(By.xpath("(" + courseList + ")[" + i + "]")).click();
				break;
			}
		}
		
		String date = new java.util.Date().toString();
		date = date.replace(" ", "");
		assignmentName.clear();
		assignmentName.sendKeys(assigment+date);
		
	}
	
	public void createAssignment()
	{
			wait.until(ExpectedConditions.visibilityOf(AssignmentBtn));
		int m=0;
		String val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==50)
				break;
			else
			{
				try
				{
					Thread.sleep(1000);
				}
				catch(Exception e)
				{
					
				}
			}
			m++;
		}
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", AssignmentBtn);
		
			 getAssignmentName();
		

		
	}
	public void Click_on_createAssignmentBtn()
	{
			wait.until(ExpectedConditions.visibilityOf(AssignmentBtn));
		int m=0;
		String val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==50)
				break;
			else
			{
				try
				{
					Thread.sleep(1000);
				}
				catch(Exception e)
				{
					
				}
			}
			m++;
		}
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", AssignmentBtn);
		
			 getAssignmentName();
		 
		

		
	}
	public void createManualAssignment()
	{
			wait.until(ExpectedConditions.visibilityOf(createAssignmentButton));
		int m=0;
		String val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==50)
				break;
			else
			{
				try
				{
					Thread.sleep(1000);
				}
				catch(Exception e)
				{
					
				}
			}
			m++;
		}
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", createAssignmentButton);
//		getAssignmentName();
	}
	public void validateRecurrence(String status)
	{
		
	
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//tbody[@id='productInner']//td[text()='"+AssgnmentName+"']//following-sibling::td[3]"))));
		
		Assert.assertEquals(driver.findElement(By.xpath("//tbody[@id='productInner']//td[text()='"+AssgnmentName+"']//following-sibling::td[3]")).getText(), status);
	}
	public void updateAssignment()
	{
			wait.until(ExpectedConditions.visibilityOf(createAssignmentButton));
		int m=0;
		String val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==50)
				break;
			else
			{
				try
				{
					Thread.sleep(1000);
				}
				catch(Exception e)
				{
					
				}
			}
			m++;
		}
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", createAssignmentButton);
		getAssignmentName();
	}
	
	public void validateStudentAssignment(String count)
	{
		try
		{
		Thread.sleep(5000);	
		}
		catch(Exception e)
		{
			
		}
    
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//td[text()='"+AssgnmentName+"']//following::td[5]"))));
		Assert.assertTrue("Assignment not assigned", Integer.parseInt(driver.findElement(By.xpath("//td[text()='"+AssgnmentName+"']//following::td[5]")).getText())>=Integer.parseInt(count));
		
	}
	
	public void validateunrollStudentAssignment(String count)
	{
		try
		{
		Thread.sleep(5000);	
		}
		catch(Exception e)
		{
			
		}
    
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//td[text()='"+AssgnmentName+"']//following::td[5]"))));
		Assert.assertTrue("Assignment not assigned", Integer.parseInt(driver.findElement(By.xpath("//td[text()='"+AssgnmentName+"']//following::td[5]")).getText())==Integer.parseInt(count));
		
	}
	public void Assignmentname(String count)
	{
	int i=0;	
		while(i<110)
		{
		try
		{
			Thread.sleep(3000);	
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//td[text()='"+AssgnmentName+"']//following::td[5][text()='"+count+"']"))));
		break;
		
		}
		catch(Exception e)
		{
	
			driver.navigate().refresh();
				
		}
		i++;
		}
	
	}
	public void createAutoAssignment()
	{
       wait.until(ExpectedConditions.visibilityOf(createAutoAssignmentButton));
		int m=0;
		String val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			else
			{
				try
				{
				Thread.sleep(1000);	
				}
				catch (Exception e) {
					// TODO: handle exception
				}
			}
			m++;
		}
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", createAutoAssignmentButton);
		getAssignmentName();
	}
	
	public void getAssignmentName()
	{
		wait.until(ExpectedConditions.visibilityOf(assignmentTitle));
		name = assignmentTitle.getText();
		AssgnmentName=name;
		System.out.println(name);
		
	}
	
	public void DeleteassignmentActiondetails(String course)
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		if(courseListName.containsKey(course+"Option"))
			course=courseListName.get(course+"Option").toString();
		int count=Integer.parseInt( assignmentlisting_info.getText().split(" ")[5]);
	
		User usr = new User();
		usr.clickOnAssignmentTab();
		try 
		{
			int m=0;
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
				
			}
			
			
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"productInner\"]/tr/td[text()='"+course+"']/following::td[7]/div/a"))));
			driver.findElement(By.xpath("//*[@id=\"productInner\"]/tr/td[text()='"+course+"']/following::td[7]/div/a")).click();
			Thread.sleep(5000);
			deleteAssignment();
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
			
		}
		
		
	}
	
	public void assignmentActiondetails(String Course)
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		User usr = new User();
		usr.clickOnAssignmentTab();
		try 
		{
			int m=0;
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
				
			}
			Thread.sleep(5000);
//			if(courseListName.containsKey(Course+"Option"))
//				Course=courseListName.get(Course+"Option").toString();
//			
			String AssgnmentName= dataMap.get(Course+"Assignment");
			
		
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"productInner\"]/tr/td[text()='"+AssgnmentName+"']/following::td[7]/div/a"))));
			driver.findElement(By.xpath("//*[@id=\"productInner\"]/tr/td[text()='"+AssgnmentName+"']/following::td[7]/div/a")).click();
		
//			wait.until(ExpectedConditions.visibilityOf(assignmentDropdown));
//			assignmentDropdown.click();
			
		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
			
//			js.executeScript("arguments[0].click()", assignmentDropdown);
		}
	}
	
	public void assignmentActiondetails()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		User usr = new User();
		usr.clickOnAssignmentTab();
		try 
		{
			int m=0;
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
				
			}
			Thread.sleep(5000);
			wait.until(ExpectedConditions.visibilityOf(assignmentDropdown));
			assignmentDropdown.click();
			
//			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"productInner\"]/tr/td[text()='"+course+"']/following::td[7]/div/a"))));
//			driver.findElement(By.xpath("//*[@id=\"productInner\"]/tr/td[text()='"+course+"']/following::td[7]/div/a")).click();

		} 
		catch (Exception e) 
		{
			Assert.fail(e.getMessage());
			
//			js.executeScript("arguments[0].click()", assignmentDropdown);
		}
	}

	

	public void validateHeader(String header)
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='save_assignment']//h3[text()='"+header+"']"))));
		
		Assert.assertEquals("Data not matching",driver.findElement(By.xpath("//*[@id='save_assignment']//h3[text()='"+header+"']")).getText(),header);
	}

	public void validatenotHeader(String header)
	{
		try
		{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='save_assignment']//h3[text()='"+header+"']"))));
		
		Assert.fail("Header should not available"+header);
		}
		catch(Exception e)
		{
			System.out.println("Validate if header is not available");
		}
	
	}

	public void validateLable(String label)
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='save_assignment']//label[text()='"+label+"']"))));
		
		Assert.assertEquals("Data not matching",driver.findElement(By.xpath("//*[@id='save_assignment']//label[text()='"+label+"']")).getText(),label);
	}
	
	public void validatedata(String data)
	{

		if(AssignmentReport. checkifParmeterAvailable(data))
			data=AssignmentReport.getParmeterAvailable(data);

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='save_assignment']//span[contains(text(),'"+data+"')]"))));
		
		Assert.assertEquals("Data not matching",driver.findElement(By.xpath("//*[@id='save_assignment']//span[contains(text(),'"+data+"')]")).getText(),data);
	}
	
	public void clickEditAssignmentOption()
	{
		wait.until(ExpectedConditions.visibilityOf(assignmentManageOption));
		assignmentManageOption.click();
		wait.until(ExpectedConditions.visibilityOf(assignmentEditOption));
		assignmentEditOption.click();
		
		
		
		
	}
	
	public void clickViewAssignmentOption()
	{
		   
		  		wait.until(ExpectedConditions.visibilityOf(assignmentManageOption));
		  		assignmentManageOption.click();
		
		
	}
	

	public void clickViewAssignmentOption(String Course)
	{
		   
//		  		wait.until(ExpectedConditions.visibilityOf(assignmentManageOption));
//		  		assignmentManageOption.click();
		String AssgnmentName= dataMap.get(Course+"Assignment");
		
		  		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='productInner']/tr/td[text()='"+AssgnmentName+"']/following::td[7]/div/ul//a[text()='Manage Assignment']"))));
		  		driver.findElement(By.xpath("//*[@id='productInner']/tr/td[text()='"+AssgnmentName+"']/following::td[7]/div/ul//a[text()='Manage Assignment']")).click();

		  		
		
	}
	public void addStudent(String userName)
	{
		wait.until(ExpectedConditions.visibilityOf(studentSearchText));
		String val = pageLoad.getAttribute("class");
		User usr=new User();
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==302)
				break;
			m++;
		}
		try
		{
		Thread.sleep(3000);
		}
		catch(Exception e)
		{
			
		}
		studentSearchText.click();
		
		 if(usr.usrEmail!=null)
		{
			int j=Integer.parseInt(userName.split("_")[1]);
			for(int i=0;i<usr.usrEmail[j-1].length();i++)
			studentSearchText.sendKeys(String.valueOf(usr.usrEmail[j-1].charAt(i)));
		}
		 else if(userName.contains("_")&&usr.usrEmail!=null)
		 {
			 int j=Integer.parseInt(userName.split("_")[1]);
				
				for(int i=0;i<usr.usrEmail[j-1].length();i++)
					studentSearchText.sendKeys(String.valueOf(usr.usrEmail[j-1].charAt(i)));
				
		 }
		else
		{
			for(int i=0;i<User.userEmail.length();i++)
				studentSearchText.sendKeys(String.valueOf(User.userEmail.charAt(i)));
		
		}
			try
			{
		String result = studentSearchResult.getText();
		val = pageLoad.getAttribute("class");
		int k=0;
	
		while(result.length() == 0)
		{
			result = studentSearchResult.getText();
			if(k==232)
				break;
			k++;
			
		}
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", studentSearchOption);
		}
		catch(Exception e)
			{
			
			}
		studentAddButton.click();
	}
	
	public void addStudents(String userName,int count)
	{
		wait.until(ExpectedConditions.visibilityOf(studentSearchText));
		String val = pageLoad.getAttribute("class");
		User usr=new User();
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==302)
				break;
			m++;
		}
		try
		{
		Thread.sleep(4000);
		}
		catch(Exception e)
		{
			
		}
		studentSearchText.clear();
		studentSearchText.click();
		System.out.println(User.usrEmail[count]);
		for(int i=0;i<User.usrEmail[count].length();i++)
			studentSearchText.sendKeys(String.valueOf(User.usrEmail[count].charAt(i)));
	
		
			try
			{
		
				Thread.sleep(4000);
			String result = studentSearchResult.getText();
		val = pageLoad.getAttribute("class");
		int k=0;
		Thread.sleep(4000);
		while(result.length() == 0)
		{
			result = studentSearchResult.getText();
			if(k==232)
				break;
			k++;
			
		}
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", studentSearchOption);
		}
		catch(Exception e)
			{
			e.printStackTrace();
			}
		studentAddButton.click();
	}
	
	
	public void errorMessage()
	{
		wait.until(ExpectedConditions.visibilityOf(errorMessage));
		}
	
	public void errorMessage(String msg)
	{
		if(AssignmentReport. checkifParmeterAvailable(msg))
			 msg=AssignmentReport.getParmeterAvailable(msg);

		try
		{
	
			Thread.sleep(4000);
		}
		catch(Exception e)
		{
			
		}
		wait.until(ExpectedConditions.visibilityOf(errorMessage));
		Assert.assertEquals(errorMessage.getText(), msg);
	}
	
	public void courseLimitMessage(String msg)
	{
		if(AssignmentReport. checkifParmeterAvailable(msg))
			 msg=AssignmentReport.getParmeterAvailable(msg);

		try
		{
	
			Thread.sleep(4000);
		}
		catch(Exception e)
		{
			
		}
		wait.until(ExpectedConditions.visibilityOf(courseMessage));
		Assert.assertEquals(courseMessage.getText(), msg);
	}
	

	
	

	public void popuperrorMessage(String msg)
	{
		if(AssignmentReport. checkifParmeterAvailable(msg))
			 msg=AssignmentReport.getParmeterAvailable(msg);

		wait.until(ExpectedConditions.visibilityOf(popupMessage));
		Assert.assertEquals(popupMessage.getText(), msg);
	}
	
	
	public void addStudent(int i)
	{
		wait.until(ExpectedConditions.visibilityOf(studentSearchText));
		String val = pageLoad.getAttribute("class");
		User usr=new User();
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==102)
				break;
			m++;
		}
		try
		{
		Thread.sleep(3000);
		studentSearchText.clear();
		}
		catch(Exception e)
		{
			
		}
		wait.until(ExpectedConditions.visibilityOf(studentSearchText));
		studentSearchText.click();
		
		System.out.println(User.usrEmail[i]);
			for(int j=0;j<User.usrEmail[i].length();j++)
			{
				studentSearchText.sendKeys(String.valueOf(User.usrEmail[i].charAt(j)));
			
			}
			
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			
			
			try
			{
		String result = studentSearchResult.getText();
		val = pageLoad.getAttribute("class");
		int k=0;
//	
		while(result.length() == 0)
		{
			result = studentSearchResult.getText();
			if(k==232)
				break;
			k++;
			
		}
		Thread.sleep(2000);
		
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", studentSearchOption);
		}
		catch(Exception e)
			{
			
			}
		studentAddButton.click();
	}
	public void addStudent()
	{
		wait.until(ExpectedConditions.visibilityOf(studentSearchText));
		String val = pageLoad.getAttribute("class");
		User usr=new User();
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}

		for(int i=0;i<User.userEmail.length();i++)
		{
			studentSearchText.sendKeys(String.valueOf(User.userEmail.charAt(i)));
			
		}
		
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		
		
//		studentSearchText.sendKeys(User.userEmail);
		
		wait.until(ExpectedConditions.visibilityOf(NoMatchingStudents));
		
		String errmsg=NoMatchingStudents.getText();
		System.out.println(errmsg);
		Assert.assertEquals("No Matching Students!",errmsg);
		//td[text()='No Students are available.']
//		System.out.println( driver.findElement(By.xpath("//td[text()='No Students are available.']")).getText());
//		Assert.assertEquals("No Students are available.", driver.findElement(By.xpath("//td[text()='No Students are available.']")).getText());	
		
	}
	public void verifyAddStudent(String userName)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==212)
				break;
			m++;
		}
//		String uName = studentAddResult.getText();
//		Assert.assertEquals(userName.replace("_", ""), uName);
		
	}
	public void editAssignmentTitle()
	{
		wait.until(ExpectedConditions.visibilityOf(assignmentTitleSearchBox));
		assignmentTitleSearchBox.click();
		assignmentTitleSearchBox.clear();
		titleName = new java.util.Date().toString();
		titleName = titleName.replace(" ", "").replace(":", "");
		assignmentTitleSearchBox.sendKeys(titleName);
	
	}
	
	public void addDuplicateUser(String userName)
	{
		addStudent(userName);
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			else
			{
				try
				{
				Thread.sleep(1000);	
				}
				catch(Exception e)
				{
					
				}
			}
			m++;
		}
		String msg = errorMessage.getText();
		Assert.assertEquals(msg, "Student is already added to the list");
	}

	public void editAutomaticAssignment()
	{
		wait.until(ExpectedConditions.visibilityOf(assignmentName));
//		String val = pageLoad.getAttribute("class");
//		int m=0;
//		while(val.equalsIgnoreCase("loading_assignment"))
//		{
//			val = pageLoad.getAttribute("class");
//			if(m==pagload)
//				break;
//			m++;
//		}
		String name = assignmentName.getAttribute("value");
		System.out.println("Assignment name before edit " + name);
		assignmentName.click();
		assignmentName.clear();
		assignmentName.sendKeys(name + "_update");
		wait.until(ExpectedConditions.elementToBeClickable(updateAutoAssignment));
		updateAutoAssignment.click();
		User usr = new User();
		usr.clickOnAssignmentTab();
		getAssignmentName();
		Assert.assertEquals(name + "_update", Assignments.name);
	}
	public void editAutomaticAssignmentBtn()
	{
		wait.until(ExpectedConditions.visibilityOf(assignmentName));
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		wait.until(ExpectedConditions.elementToBeClickable(updateAssignmentButton));
		updateAssignmentButton.click();
	}
	public void selectAssignmentDueDate(String dueDate)
	{
//		String val = pageLoad.getAttribute("class");
//		while(val.equalsIgnoreCase("loading_assignment"))
//		{
//			val = pageLoad.getAttribute("class");
//		}
		switch(dueDate.toLowerCase().trim())
		{
		case "specific date":
			addSpecificDate();
			break;
		case "relative date":
			selectRelativeDate(1);
			break;
		}
	}

	public void selectAssignmentDueDate(String dueDate,int days)
	{
		String val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
		}
		switch(dueDate.toLowerCase().trim())
		{
		case "specific date":
			addSpecificDate(days);
			break;
		case "relative date":
			selectRelativeDate(days);
			break;
		}
	}

	public void selectrecurrencespecificEndDate(int days)
	{
		String val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
		}
		
			addSpecificDate(days);
		
	}

	
	public void selectsubscriptionPlan(String subscription)
	{
		String val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
		}
		
		subscriptionPlan.click();
		wait.until(ExpectedConditions.visibilityOf(subscriptionPlanInput));
		
		subscriptionPlanInput.sendKeys(subscription);
		
		;
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='save_assignment']//a/span[text()='"+subscription+"']"))));
			
		driver.findElement(By.xpath("//*[@id='save_assignment']//a/span[text()='"+subscription+"']")).click();
		
	}

	public void selectStudentPay()
	{
		String val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
		}
		
		
		wait.until(ExpectedConditions.visibilityOf(studentPayRadio));
		
		studentPayRadio.click();		
	}

	public void selectOrganizationPayRadio()
	{
		String val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
		}
		
		
		wait.until(ExpectedConditions.visibilityOf(OrganizationPayRadio));
		
		OrganizationPayRadio.click();		
	}
	
	public void validatedIfOrganizationPayRadio()
	{
		
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(OrganizationPayRadio));
		Assert.fail("Organization Pay Radio Should be not present");
		}
		catch(Exception e)
		{
			System.out.println("Organization Pay Radio not present");
		}
		
	}
	
	
	public void addSpecificDate()
	{
//		String val = pageLoad.getAttribute("class");
		int m=0;
//		while(val.equalsIgnoreCase("loading_assignment"))
//		{
//			val = pageLoad.getAttribute("class");
//			if(m==pagload)
//				break;
//			else
//			{
//				try
//				{
//				Thread.sleep(1000);	
//				}
//				catch(Exception e)
//				{
//					
//				}
//			}
//			m++;
//		}
		wait.until(ExpectedConditions.visibilityOf(radioSpecificDate));
		radioSpecificDate.click();
//		wait.until(ExpectedConditions.visibilityOf(specificDate));
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date date = new Date();
		Calendar cal = Calendar.getInstance();
		String formattedStartDate = dateFormat.format(date);
		cal.add(Calendar.DAY_OF_MONTH, 12); 
		String formattedEndDate = dateFormat.format(cal.getTime());
		System.out.println("Current date is " + formattedStartDate + " and end date is " + formattedEndDate);
//		specificDate.click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		
		js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", specificDate,"value",formattedEndDate);

//		wait.until(ExpectedConditions.visibilityOf(calendarProduct));
//		WebElement reqDate = driver.findElement(By.xpath(datePick + formattedEndDate + " and not(contains(@class, 'disabled day' ))]"));
//		reqDate.click();
	}
	
	
	public void addSpecificDate(int days)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			else
			{
				try
				{
				Thread.sleep(1000);	
				}
				catch(Exception e)
				{
					
				}
			}
			m++;
		}
		wait.until(ExpectedConditions.visibilityOf(radioSpecificDate));
		radioSpecificDate.click();
//		wait.until(ExpectedConditions.visibilityOf(specificDate));
		DateFormat dateFormat = new SimpleDateFormat("dd");
		Date date = new Date();
		Calendar cal = Calendar.getInstance();
		String formattedStartDate = dateFormat.format(date);
		cal.add(Calendar.DAY_OF_MONTH, days); 
		String formattedEndDate = dateFormat.format(cal.getTime());
		System.out.println("Current date is " + formattedStartDate + " and end date is " + formattedEndDate);
		specificDate.click();
		wait.until(ExpectedConditions.visibilityOf(calendarProduct));
		WebElement reqDate = driver.findElement(By.xpath(datePick + formattedEndDate + " and not(contains(@class, 'disabled day' ))]"));
		reqDate.click();
	}
	public void validateSpecificDate(int days)
	{
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date date = new Date();
		Calendar cal = Calendar.getInstance();
		String formattedStartDate = dateFormat.format(date);
		cal.add(Calendar.DAY_OF_MONTH, days); 
		String formattedate = dateFormat.format(cal.getTime());
		
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//tbody[@id='productInner']//td[text()='"+AssgnmentName+"']//following-sibling::td[4]"))));
	    Assert.assertEquals(driver.findElement(By.xpath("//tbody[@id='productInner']//td[text()='"+AssgnmentName+"']//following-sibling::td[4]")).getText(), formattedate);
		
	}
	
	public void validateAssignmentDate(int days)
	{
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date date = new Date();
		Calendar cal = Calendar.getInstance();
		String formattedStartDate = dateFormat.format(date);
		cal.add(Calendar.DAY_OF_MONTH, days); 
		String formattedate = dateFormat.format(cal.getTime());
		
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//tbody[@id='productInner']//td[text()='"+AssgnmentName+"']//following-sibling::td[2]"))));
	    Assert.assertEquals(driver.findElement(By.xpath("//tbody[@id='productInner']//td[text()='"+AssgnmentName+"']//following-sibling::td[2]")).getText(), formattedate);
		
	}
	
	public void addStartSpecificDate()
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			else
			{
				try
				{
				Thread.sleep(1000);	
				}
				catch(Exception e)
				{
					
				}
			}
			m++;
		}
		wait.until(ExpectedConditions.visibilityOf(radioStartSpecificDate));
		radioStartSpecificDate.click();
		wait.until(ExpectedConditions.visibilityOf(StartspecificDate));
		DateFormat dateFormat = new SimpleDateFormat("dd");
		Date date = new Date();
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_MONTH, 1); 
		
		String formattedStartDate =dateFormat.format(cal.getTime());;
		System.out.println("Current date is " + formattedStartDate + " and end date is " + formattedStartDate);
		StartspecificDate.click();
		wait.until(ExpectedConditions.visibilityOf(calendarProduct));
		WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + " and not(contains(@class, 'disabled day' ))]"));
		reqDate.click();
	}
	
	public void selectRelativeDate(int i)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
//		String val = pageLoad.getAttribute("class");
//		try {
//			int counter = 0;
//		while(val.equalsIgnoreCase("loading_assignment"))
//		{
//			val = pageLoad.getAttribute("class");
//			Thread.sleep(5000);
//			counter++;
//			if(counter>12)
//				Assert.fail("Not able to load page after waiting for 1 minute");
//		}
//		}
//		catch(Exception e) {
//			
//		}
		wait.until(ExpectedConditions.visibilityOf(radioRelativeDate));
		radioRelativeDate.click();
		Select selectRelative = new Select(selectRelativeDate);
		selectRelative.selectByValue(Integer.toString(i));
	}
	
	public void selectRelativeDatedisable()
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
//		String val = pageLoad.getAttribute("class");
//		try {
//			int counter = 0;
//		while(val.equalsIgnoreCase("loading_assignment"))
//		{
//			val = pageLoad.getAttribute("class");
//			Thread.sleep(5000);
//			counter++;
//			if(counter>12)
//				Assert.fail("Not able to load page after waiting for 1 minute");
//		}
//		}
//		catch(Exception e) {
//			
//		}
		
		Assert.assertTrue(disableRelativeDate.getAttribute("type").contains("hidden"));
	}
	
	
	public void deleteAddStudent()
	{
		try
		{
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			else
			{
				try
				{
					Thread.sleep(1000);
				}
				catch(Exception e)
				{
					
				}
			}
			m++;
		}
		studentAddDelete.click();
		}
		catch(Exception e)
		{
			Assert.fail(e.getMessage());
			
		}
	}

	
	public void searchUserByName(String first)
	{
		wait.until(ExpectedConditions.visibilityOf(studentSearchBox));
		studentSearchBox.sendKeys(first);
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		verifyAddStudent(first);
		studentSearchBox.clear();
	}
	
	public void searchUserByDelivery(String first)
	{
		wait.until(ExpectedConditions.visibilityOf(studentSearchAssignmentDelivery));
		Select select = new Select(studentSearchAssignmentDelivery);
		select.selectByVisibleText("Yes");
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		verifyAddStudent(first);
		select.selectByVisibleText("No");
		val = pageLoad.getAttribute("class");
		 m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		String result = NoStudentAvailable.getText();
		Assert.assertEquals("No Students are available.", result);
	}

	public void countUserRows(int count)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		String tableRow = userTable;
		By row = By.xpath(tableRow);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(row)));
		List<WebElement> rows = driver.findElements(row);
		Assert.assertEquals(count, rows.size());
		wait.until(ExpectedConditions.elementToBeClickable(updateManualAssignment));
		updateManualAssignment.click();
	}

	public void verifyNewAddedStudent(String userName, int count)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			else
			{
				try
				{
					Thread.sleep(1000);
				}
				catch (Exception e) {
					// TODO: handle exception
				}
			}
			m++;
		}
		String uName = driver.findElement(By.xpath(userTable + "[" + count + "]/td[4]")).getText();
		Assert.assertEquals(userName+count, uName);
	}
	

	public void verifyNewAddedStudent(String userName)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			else
			{
				try
				{
					Thread.sleep(1000);
				}
				catch (Exception e) {
					// TODO: handle exception
				}
			}
			m++;
		}
		String uName = driver.findElement(By.xpath("//table[@id = 'selected_user']//tbody//tr//td[3][text()='"+userName+"']")).getText();
		Assert.assertEquals(userName, uName);
	}
	
	
	public void updateManualAssignment()
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			else
			{
				try
				{
				Thread.sleep(1000);	
				}
				catch(Exception e)
				{
					
				}
				

			}
			m++;
		}
		wait.until(ExpectedConditions.elementToBeClickable(updateManualAssignment));
		updateManualAssignment.click();
	}

	public void countUserRowsWithoutUpdate(int count)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		String tableRow = userTable;
		By row = By.xpath(tableRow);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(row)));
		List<WebElement> rows = driver.findElements(row);
		Assert.assertEquals(count, rows.size());
		
	}
	
	public void countUserRowsWithoutUpdateCreate(int count)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		String tableRow = studentTable;
		By row = By.xpath(tableRow);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(row)));
		List<WebElement> rows = driver.findElements(row);
		Assert.assertEquals(count, rows.size());
		
	}
	
	public void selectCriteria(String name)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		wait.until(ExpectedConditions.elementToBeClickable(selectCriteriaDropdown));
		Select select = new Select(selectCriteriaDropdown);
		select.selectByVisibleText(name);
		System.out.println(name.toLowerCase().trim());
		name=name.toLowerCase().trim();
		if (!name.equalsIgnoreCase("hire date"))
		{
			try
			{
			Thread.sleep(5000);
			}
			catch(Exception e)
			{
				
			}
			wait.until(ExpectedConditions.elementToBeClickable(selectCriteriaValueDropdown));
			select = new Select(selectCriteriaValueDropdown);
			selectCriteriaValueDropdown.click();
			if(name.equalsIgnoreCase("Group"))
				select.selectByVisibleText(OrganizationSettings.groupName);
				else if(name.equalsIgnoreCase("Organization"))
					select.selectByIndex(1);
				else
					select.selectByVisibleText(OrganizationSettings.titleName);
			
				
		}
		else
		{
			DateFormat dateFormat1 = new SimpleDateFormat("dd");
			 Calendar cal = Calendar.getInstance();
		       
			 cal.add(Calendar.DATE, 1);
			String formattedStartDate = dateFormat1.format(cal.getTime());
			
           wait.until(ExpectedConditions.elementToBeClickable(hireDate));
			
			val = pageLoad.getAttribute("class");
			 m=0;
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			hireDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + " and not(contains(@class, 'disabled day' ))]"));
			reqDate.click();
		}
		val = pageLoad.getAttribute("class");
		 m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
	}
	
	public void searchAutoUserByName(String first, String value)
	{
		wait.until(ExpectedConditions.visibilityOf(studentAutoSearchBox));
		wait.until(ExpectedConditions.elementToBeClickable(studentAutoSearchBox));
		
		if(User.userEmail!=null)
		{
		studentAutoSearchBox.sendKeys(User.userEmail);
		}
		else if(first.contains("_"))
		{
			int i=Integer.parseInt(first.split("_")[1]);
			
			studentAutoSearchBox.sendKeys(User.usrEmail[i-1]);
		}	
		else
		{
			
			studentAutoSearchBox.sendKeys(User.usrEmail[0]);
		}	
			
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		verifyAutoAddStudent(first.replace("_", ""));
	}
	

	public void searchAutoUserByDelivery( String value)
	{
		wait.until(ExpectedConditions.visibilityOf(studentAutoSearchBox));
		wait.until(ExpectedConditions.elementToBeClickable(studentAutoSearchBox));
		
		
		Select drpState = new Select(driver.findElement(By.xpath("//*[@id=\"auto_delivery\"]")));
		drpState.selectByValue(value);
			
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		verifyDelivery(value);
	}
	
	public void verifyAutoAddStudent(String userName)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			else
			{
				try
				{
					Thread.sleep(1000);
				}
				catch(Exception e)
				{
					
				}

			}
				
			m++;
		}
		
		String uName = studentAutoAddResult.getText();
		Assert.assertEquals(userName.trim(), uName.trim());
		
	}

	public void verifyDelivery(String value)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		String uName = deliveryValue.getText();
		Assert.assertEquals(value.trim(), uName.trim());
		
	}
	
	public void verifyAutoUnitLevel(String level)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		String uLevel = studentAutoUnitLevel.getText().trim();
		Assert.assertEquals(level, uLevel);
		
	}
	
	public void verifyAssignmentDelivery(String value)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		String uName = studentAutoAssignmentResult.getText();
		Assert.assertEquals(value.toLowerCase().trim(), uName.toLowerCase().trim());
	}
	
	public void validateCriteriaDisabled()
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		Assert.assertFalse(editSelectCriteria.isEnabled());
	}
	
	public void clickOnEditAssignment()
	{
		wait.until(ExpectedConditions.visibilityOf(editAssignmentViewPage));
		wait.until(ExpectedConditions.elementToBeClickable(editAssignmentViewPage));
		editAssignmentViewPage.click();
	}
	
	public void ViewAssignmentBtavailable()
	{
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		wait.until(ExpectedConditions.elementToBeClickable(actionDetails));
		actionDetails.click();
		wait.until(ExpectedConditions.visibilityOf(viewAssignmentPage));
		wait.until(ExpectedConditions.elementToBeClickable(viewAssignmentPage));
		viewAssignmentPage.click();
		
	
	}
	public void EditAssignmentBtnnotavailable()
	{
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		wait.until(ExpectedConditions.elementToBeClickable(actionDetails));
		actionDetails.click();
	try
	{
		Assert.assertFalse(editAssignmentViewPage.isDisplayed());
	}
	catch(Exception e)
	{
		System.out.println("Edit button is not available");
	}
	
	}
	
	
	public void clickOnEditAssignmnt()
	{
		wait.until(ExpectedConditions.visibilityOf(actionDetails));
		wait.until(ExpectedConditions.elementToBeClickable(actionDetails));
		actionDetails.click();
		clickOnEditAssignment();
		
	}
	public void searchUserByNameViewPage(String first)
	{
		wait.until(ExpectedConditions.visibilityOf(studentSearchBox));
		studentSearchBox.sendKeys(first);
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		verifyAutoAddStudent(first);
		studentSearchBox.clear();
	}

	public void selectMultipleCriteria(String name, int count)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		for(int i = 0; i < count; i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(criteria + i + "_criteria']"))));
			Select select = new Select(driver.findElement(By.xpath(criteria + i + "_criteria']")));
			select.selectByVisibleText(name);
			String value = criteriaValue + (i+1) + "_criterias_data_list']";
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(value))));
			select = new Select(driver.findElement(By.xpath(value)));
			select.selectByVisibleText(User.group[i]);;
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
			}
			if(i < count-1)
			{
			wait.until(ExpectedConditions.elementToBeClickable(addCriteriaButton));
			addCriteriaButton.click();
			}
		}
		
	}

	public void getStudentCount(int count)
	{
		wait.until(ExpectedConditions.visibilityOf(assignmentStudentCount));
		String countActual = assignmentStudentCount.getText();
		System.out.println("NUmber of assigned user " + countActual);
	}

	public void selectDifferentMultipleCriteria(String criterias)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			else
			{
				try
				{
				Thread.sleep(1000);	
				}
				catch(Exception e)
				{
					
				}
			}
			m++;
		}
		String criteriaList[] = criterias.split(",");
		for(int i = 0; i < criteriaList.length; i++)
		{
			if (!criteriaList[i].equalsIgnoreCase("hire date"))
			{
				wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(criteria + i + "_criteria']"))));
				Select select = new Select(driver.findElement(By.xpath(criteria + i + "_criteria']")));
				select.selectByVisibleText(criteriaList[i]);
				String value = criteriaValue + (i+1) + "_criterias_data_list']";
				wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(value))));
				select = new Select(driver.findElement(By.xpath(value)));
				driver.findElement(By.xpath(value)).click();
				if(User.group==null)
				{
					
					if(criteriaList[i].contains("Job Title"))
					{
						
						select.selectByVisibleText(OrganizationSettings.titleName);;
						
							
					}
					if(criteriaList[i].contains("Level"))
					{
						try
						{
					select.selectByVisibleText("Automation Test");;
						}
						catch(Exception e)
						{
							driver.findElement(By.xpath(value)).click();
							try {
								Thread.sleep(3000);
							} catch (InterruptedException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
							select.selectByVisibleText("Automation Test");;
						}
					}		
				}
				else
				{
					if(criteriaList[i].contains("Job Title"))
					{
						if(User.job==null)
						select.selectByVisibleText(OrganizationSettings.titleName);
						else
							select.selectByVisibleText(User.job);
					}
					else if(criteriaList[i].contains("Level"))
					{
					select.selectByVisibleText("Automation Test");;
					}	
					else
					{
					select.selectByVisibleText(User.group[0]);;
					}	
				}
			}
			else
			{
				wait.until(ExpectedConditions.elementToBeClickable(selectCriteriaDropdown));
				Select select = new Select(selectCriteriaDropdown);
				select.selectByVisibleText(criteriaList[i]);
				DateFormat dateFormat = new SimpleDateFormat("dd");
				Date date = new Date();
				String formattedStartDate = dateFormat.format(date);
				hireDate.click();
				wait.until(ExpectedConditions.visibilityOf(calendarProduct));
				WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + " and not(contains(@class, 'disabled day' ))]"));
				reqDate.click();
			}
			val = pageLoad.getAttribute("class");
			 m=0;
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			User u=new User();
			if(i < criteriaList.length-1)
			{
				u.ElementWait(addCriteriaButton);
		     	addCriteriaButton.click();
			}
		}
		
	}
	public void selectDifferentMultipleCriteiaisnot(String criterias)
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			else
			{
				try
				{
				Thread.sleep(1000);	
				}
				catch(Exception e)
				{
					
				}
			}
			m++;
		}
		String criteriaList[] = criterias.split(",");
		for(int i = 0; i < criteriaList.length; i++)
		{
			if (!criteriaList[i].equalsIgnoreCase("hire date"))
			{
				wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(criteria + i + "_criteria']"))));
				Select select = new Select(driver.findElement(By.xpath(criteria + i + "_criteria']")));
				select.selectByVisibleText(criteriaList[i]);
				String value = criteriaValue + (i+1) + "_criterias_data_list']";
				wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(value))));
				select = new Select(driver.findElement(By.xpath("//*[@id=\"relation\"]")));

				driver.findElement(By.xpath("//*[@id=\"0_row\"]/div[3]")).click();
				select.selectByVisibleText("is not");
				 m=0;
				while(val.equalsIgnoreCase("loading_assignment"))
				{
					val = pageLoad.getAttribute("class");
					if(m==pagload)
						break;
					else
					{
						try
						{
						Thread.sleep(1000);	
						}
						catch(Exception e)
						{
							
						}
					}
					m++;
				}
				try
				{
				Thread.sleep(15000);	
				}
				catch(Exception e)
				{
					
				}
				select = new Select(driver.findElement(By.xpath(value)));
				driver.findElement(By.xpath(value)).click();
				if(User.group==null)
				{
					
					if(criteriaList[i].contains("Job Title"))
					{
						
						select.selectByVisibleText(OrganizationSettings.titleName);;
						
						
						
					
							
					}
					if(criteriaList[i].contains("Level"))
					{
						try
						{
					select.selectByVisibleText("Automation Test");;
						}
						catch(Exception e)
						{
							driver.findElement(By.xpath(value)).click();
							try {
								Thread.sleep(3000);
							} catch (InterruptedException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
							select.selectByVisibleText("Automation Test");;
						}
					}		
				}
				else
				{
					if(criteriaList[i].contains("Job Title"))
					{
						if(User.job==null)
						select.selectByVisibleText(OrganizationSettings.titleName);
						else
							select.selectByVisibleText(User.job);
						
						select = new Select(driver.findElement(By.xpath("//*[@id=\"relation\"]")));
						driver.findElement(By.xpath("//*[@id=\"relation\"]")).click();
						
						select.selectByVisibleText("is not");
						
					}
					else if(criteriaList[i].contains("Level"))
					{
					select.selectByVisibleText("Automation Test");;
					}	
					else
					{
					select.selectByVisibleText(User.group[0]);;
					}	
				}
			}
			else
			{
				
				
				wait.until(ExpectedConditions.elementToBeClickable(selectCriteriaDropdown));
				Select select = new Select(selectCriteriaDropdown);
				select.selectByVisibleText(criteriaList[i]);
				DateFormat dateFormat = new SimpleDateFormat("dd");
				Date date = new Date();
				String formattedStartDate = dateFormat.format(date);
				hireDate.click();
				
				wait.until(ExpectedConditions.visibilityOf(calendarProduct));
				WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + " and not(contains(@class, 'disabled day' ))]"));
				reqDate.click();
				
				select = new Select(driver.findElement(By.xpath("//*[@id=\"relation\"]")));
				try
				{
				Thread.sleep(10000);	
				}
				catch(Exception e)
				{
					
				}
				driver.findElement(By.xpath("//*[@id=\"0_row\"]/div[3]")).click();
				select.selectByVisibleText("after");
				
			}
			val = pageLoad.getAttribute("class");
			 m=0;
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			User u=new User();
			if(i < criteriaList.length-1)
			{
				u.ElementWait(addCriteriaButton);
		     	addCriteriaButton.click();
			}
		}
		
	}
	public void selectjobtitle()
	{
		String val = pageLoad.getAttribute("class");
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==pagload)
				break;
			m++;
		}
		String criteriaList = "Job Title";
				wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(criteria + 0 + "_criteria']"))));
				Select select = new Select(driver.findElement(By.xpath(criteria + 0 + "_criteria']")));
				select.selectByVisibleText(criteriaList);
				String value = criteriaValue + (1) + "_criterias_data_list']";
				wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(value))));
				select = new Select(driver.findElement(By.xpath(value)));
				driver.findElement(By.xpath(value)).click();
				if(User.group==null)
				{
					
					if(criteriaList.contains("Job Title"))
					{
						if(OrganizationSettings.titleName==" ")
					{
						try {
					select.selectByVisibleText(OrganizationSettings.titleName);;
					Assert.fail("Found Blank option");
						}
						catch(Exception e)
						{
							
						}
					}
					}
				}
				else
				{
					if(criteriaList.contains("Job Title"))
					{
						if(OrganizationSettings.titleName==" ")
					{
						try {
					select.selectByVisibleText(OrganizationSettings.titleName);;
					Assert.fail("Found Blank option");
						}
						catch(Exception e)
						{
							
						}
					}
					else
						select.selectByVisibleText(OrganizationSettings.titleName);;
							
					
}
					else if(criteriaList.contains("Level"))
					{
					select.selectByVisibleText("Automation Test");;
					}	
					else
					{
					select.selectByVisibleText(User.group[0]);;
					}	
				}
			
			
			
		
		
	}
	public void deleteAssignment()
	{
		try
		{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		wait.until(ExpectedConditions.visibilityOf(assignmentDeleteOption));
		assignmentDeleteOption.click();
		wait.until(ExpectedConditions.visibilityOf(deleteYesButton));
		deleteYesButton.click();
		try
		{
			val = pageLoad.getAttribute("class");
			int m=0;
			while(val.equalsIgnoreCase("loading"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			m=0;
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
		}
		catch(Exception e)
		{
			int m=0;
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail(e.getMessage());
			
		}
		
	}
	public void validateDeleteSuccessMsg(String msg) {
		try {
			if(AssignmentReport. checkifParmeterAvailable(msg))
				msg=AssignmentReport.getParmeterAvailable(msg);

			WebDriverWait wait = new WebDriverWait(driver, 30);
			System.out.println("Validate Message " + msg);
			if(msg.contains("already"))
			{
				wait.until(ExpectedConditions.visibilityOf(deleteAlreadyAssignmentSuccessMsg));
				System.out.println("Message in UI " + deleteAlreadyAssignmentSuccessMsg.getText());
				Assert.assertTrue("Message in UI dont match",deleteAlreadyAssignmentSuccessMsg.getText().contains(msg));
				
			}
			else
			{
				wait.until(ExpectedConditions.visibilityOf(deleteAssignmentSuccessMsg));
				System.out.println("Message in UI " + deleteAssignmentSuccessMsg.getText());
				Assert.assertTrue("Message in UI dont match",deleteAssignmentSuccessMsg.getText().contains(msg));
				wait.until(ExpectedConditions.visibilityOf(successMsgCloseButton));
				successMsgCloseButton.click();
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Error while deleting assignments");
		}

	}
	public int rowsAvailable()
	{
		int count = 0;
		try 
		{
			
			
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(assignmentRows))));
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(assignmentRows))));
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(assignmentRows))));
			
			List<WebElement> rows = driver.findElements(By.xpath(assignmentRows));
			String text = driver.findElement(By.xpath(assignmentRows + "[1]/td")).getText();
			if(text.trim().equalsIgnoreCase("No Assignments are present."))
				count = 0;
			else
				count = rows.size();
		} catch (Exception e) 
		{
			Assert.fail(e.getMessage());
			
		}
		return count;
	}
	
	public void selectCriteria(String name, int criteriaRow)
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		String val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
		}
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement criteria = driver.findElement(By.xpath(selectCriteriaDropdown1 + criteriaRow + "_criteria']"));
		wait.until(ExpectedConditions.elementToBeClickable(criteria));
		Select select = new Select(criteria);
		select.selectByVisibleText(name.trim());
		
		System.out.println(name.toLowerCase().trim());
		if (!name.equalsIgnoreCase("hire date"))
		{
			WebElement criteriaValue = driver.findElement(By.xpath(selectCriteriaValueDropdown1 + (criteriaRow + 1) + "_criterias_data_list']"));
			wait.until(ExpectedConditions.elementToBeClickable(criteriaValue));
			select = new Select(criteriaValue);
			if(name.equalsIgnoreCase("Group"))
			select.selectByVisibleText(OrganizationSettings.groupName);
			else if(name.equalsIgnoreCase("Job Title"))
				select.selectByVisibleText(OrganizationSettings.titleName);
			else 
			{
				select.selectByIndex(1);
			}
		}
		else
		{
			DateFormat dateFormat = new SimpleDateFormat("dd");
			Date date = new Date();
			Calendar cal = Calendar.getInstance();
			String formattedStartDate = dateFormat.format(date);
			cal.add(Calendar.DAY_OF_MONTH, 1); 
			String formattedEndDate = dateFormat.format(cal.getTime());
			System.out.println("Current date is " + formattedStartDate + " and end date is " + formattedEndDate);
		
		   wait.until(ExpectedConditions.visibilityOf(hireDate));
			
			js.executeScript("arguments[0].click();", HireDateCalendar);
			wait.until(ExpectedConditions.elementToBeClickable(HireDateCalendar));
			HireDateCalendar.click();
			wait.until(ExpectedConditions.elementToBeClickable(calendarProduct));
//			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			js.executeScript("arguments[0].click();", hireDate);
//			hireDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			WebElement reqDate = driver.findElement(By.xpath(datePick + formattedEndDate + " and not(contains(@class, 'disabled day' ))]"));
			js.executeScript("arguments[0].click();", reqDate);

//			reqDate.click();
		}
		val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
		}
	}

	public void clickOnAddCriteria()
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		
		executor.executeScript("arguments[0].click();", addCriteria);
	}
	public void selectSameCriteria(String name, int criteriaRow)
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		String val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
		}
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement criteria = driver.findElement(By.xpath(selectCriteriaDropdown1 + criteriaRow + "_criteria']"));
		wait.until(ExpectedConditions.elementToBeClickable(criteria));
		Select select = new Select(criteria);
		select.selectByVisibleText(name.trim());
		System.out.println(name.toLowerCase().trim());
		if (!name.equalsIgnoreCase("hire date"))
		{
			WebElement criteriaValue = driver.findElement(By.xpath(selectCriteriaValueDropdown1 + (criteriaRow + 1) + "_criterias_data_list']"));
			wait.until(ExpectedConditions.elementToBeClickable(criteriaValue));
			select = new Select(criteriaValue);
			name=name.toLowerCase().trim();
			if(!name.equalsIgnoreCase("Group"))
				select.selectByIndex(1);
			else
			{
				select.selectByIndex(criteriaRow + 1); 
				
			}
		}
		else
		{
			DateFormat dateFormat = new SimpleDateFormat("dd");
			Date date = new Date();
			String formattedStartDate = dateFormat.format(date);
			js.executeScript("arguments[0].click();", hireDate);
			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + " and not(contains(@class, 'disabled day' ))]"));
			js.executeScript("arguments[0].click();", reqDate);
		}
		val = pageLoad.getAttribute("class");
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
		}
	}
//	======================================================New ==================================================================================
	public void Course()
	{
		wait.until(ExpectedConditions.visibilityOf(Coursedp));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", Coursedp);
		wait.until(ExpectedConditions.visibilityOf(selectCourseName));
		executor.executeScript("arguments[0].click();", CourseName);
		String CourseDesc=CourseName.getText();
		
	}
	
	public void AssignDesc()
	{
		String AssignDesc=CourseName.getText();
		AssignDes.sendKeys(AssignDesc);
	}
	
	
	public void assignmentFromUserSpecificCourseWithAssignName(String course) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(selectCourseDrp));
		String val = pageLoad.getAttribute("class");
		while (val.equalsIgnoreCase("loading_assignment")) {
			val = pageLoad.getAttribute("class");
		}
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", selectCourseDrp);
		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(courseList))));
		List<WebElement> elements = driver.findElements(By.xpath(courseList));
		// System.out.println("The value is "+elements);
		for (int i = 1; i <= elements.size(); i++) {
			String text = driver.findElement(By.xpath("(" + courseList + ")[" + i + "]")).getText();
			course = course.replaceAll("registered", "\u00AE");
			 if (course.trim().toLowerCase().equals(text.toLowerCase().trim())) {
				driver.findElement(By.xpath("(" + courseList + ")[" + i + "]")).click();
				break;
			}
		}
	}
	
	public void RelativeDate()
	{
		wait.until(ExpectedConditions.visibilityOf(radioRelativeDate));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", radioRelativeDate);
		wait.until(ExpectedConditions.visibilityOf(RelativedateDP));
		JavascriptExecutor executor1 = (JavascriptExecutor)driver;
		executor1.executeScript("arguments[0].click();", RelativedateDP);
		
		
		
	}
	
	public void CriteriaZero()
	{
		
//		wait.until(ExpectedConditions.visibilityOf(Criteria0));
		wait.until(ExpectedConditions.elementToBeClickable(Criteria0));
		JavascriptExecutor executor2 = (JavascriptExecutor)driver;
		executor2.executeScript("arguments[0].click();", Criteria0);
		Select select = new Select(Criteria0);
		select.selectByVisibleText("Job Title");
		
	}
	
	public void Criteriaone()
	{
		wait.until(ExpectedConditions.elementToBeClickable(Criteria1));		
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();",Criteria1);
		wait.until(ExpectedConditions.visibilityOf(Criteria1));
		Select select = new Select(Criteria1);
		select.selectByVisibleText("Job Title");
		
	}
	
	public void Criteriatwo()
	{
		
		wait.until(ExpectedConditions.elementToBeClickable(Criteria2));
		JavascriptExecutor executor2 = (JavascriptExecutor)driver;
		executor2.executeScript("arguments[0].click();", Criteria2);
		wait.until(ExpectedConditions.visibilityOf(Criteria2));
		Select select = new Select(Criteria2);
		select.selectByVisibleText("Job Title");
		
	}
	
	public void AddCriteriabtn()
	{
		wait.until(ExpectedConditions.elementToBeClickable(AddCriteriabtn));
		JavascriptExecutor executor2 = (JavascriptExecutor)driver;
		executor2.executeScript("arguments[0].click();", AddCriteriabtn);
		AddCriteriabtn.click();
	}
	
	
	public void validateExistsAssignmentTitleMessage(String message) throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, 60);
		// wait.until(ExpectedConditions.visibilityOf(assignmentTitle));
		if(AssignmentReport. checkifParmeterAvailable(message))
			message=AssignmentReport.getParmeterAvailable(message);

		Thread.sleep(3000);
		
		wait.until(ExpectedConditions.visibilityOf(assignmentTitleError));
		String actualMessage = assignmentTitleError.getText().trim();
		System.out.println(actualMessage);
		// Assert.assertTrue(actualMessage.equalsIgnoreCase(message));
		Assert.assertEquals(actualMessage, message);
	}
	
	
	
	
	
	public void CreateAssignBtn()
	{
		wait.until(ExpectedConditions.visibilityOf(CreateAssignment));
		CreateAssignment.click();
	}
	
	//Added by Mohan.R 
		public void ManualAutoCourse()
		{
			wait.until(ExpectedConditions.elementToBeClickable(CreateAssignBtn));
			CreateAssignBtn.click();
			
			if((Assign_Today).isSelected() && (Noduedate).isSelected())
			{
//				System.out.println("Manual course default vaule is "+ Assign_Today.getAttribute(name) + Noduedate.getAttribute(name) );
				
				wait.until(ExpectedConditions.visibilityOf(Automatic));
				Automatic.click();
				if(Noduedate.isSelected())
				{
					System.out.println("Automatic Defualt values is selected"+ Noduedate.getText());
				}
				else
				{
					System.out.println("Expected Radio buttons are not selected by default for Automatic course ");
				}			
				
			}
			else
			{
				System.out.println("Expected Radio buttons are not selected by default for manual course ");
			}
			
		}
		public void AssignmentSuccess()
		{
			String successmessage=AssignSucc.getText();
			System.out.println(successmessage);	
			
		}
		public void clickExportButton() {
			String val = pageLoad.getAttribute("class");
			int m=0;
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				else
				{
					try
					{
					Thread.sleep(1000);	
					}
					catch(Exception e)
					{
						
					}
				}
				m++;
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(exportButton));
			exportButton.click();
		}
		
		public void clickExportAutoButton() {
			String val = pageLoad.getAttribute("class");
			int m=0;
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				else
				{
					try
					{
					Thread.sleep(1000);	
					}
					catch(Exception e)
					{
						
					}
				}
				m++;
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(exportAutoButton));
			exportAutoButton.click();
		}
		
		
		public void clickCheckallButton() {
			String val = pageLoad.getAttribute("class");
			int m=0;
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				else
				{
					try
					{
					Thread.sleep(1000);	
					}
					catch(Exception e)
					{
						
					}
				}
				m++;
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(checkall));
			checkall.click();
		}
		
		public void clickDeleteButton() {
			String val = pageLoad.getAttribute("class");
			int m=0;
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				else
				{
					try
					{
					Thread.sleep(1000);	
					}
					catch(Exception e)
					{
						
					}
				}
				m++;
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(deleteBtn));
			deleteBtn.click();
		}
		public void validateUpdateSuccessMsg(String msg) {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 30);
				System.out.println("Validate Message " + msg);
				wait.until(ExpectedConditions.visibilityOf(updateAssignmentSuccessMsg));
				System.out.println("Message in UI" + updateAssignmentSuccessMsg.getText());
				Assert.assertTrue(updateAssignmentSuccessMsg.getText().contains(msg));
				wait.until(ExpectedConditions.visibilityOf(successMsgCloseButton));
				successMsgCloseButton.click();
			} catch (Exception e) {
				e.printStackTrace();
				Assert.fail("Error while updating assignment");
			}

		}
//		Added by Mohan Raju
		public void AssignTitle()
		{
			wait.until(ExpectedConditions.visibilityOf(AssignmentTitle));
//			driver.findElement(By.xpath(AssignmentTitle))
//			Assert.assertEquals(AssignTitle, AssignTitle);
			String Assigntitle=AssignmentTitle.getText();
			System.out.println(Assigntitle);
			if(AssignmentTitle.equals(Assigntitle))
			{
				System.out.println("User is on the *********" +Assigntitle+ "********page" );
			}
		}
		
		public void removeUserAndUpdateAssignment() {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(removeUserIcon));
			removeUserIcon.click();
			wait.until(ExpectedConditions.visibilityOf(createAssignmentButton));
			createAssignmentButton.click();
		}
		
		
		

		public void addrecurrenceSpecificDate(int days)
		{
			String val = pageLoad.getAttribute("class");
			int m=0;
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				else
				{
					try
					{
					Thread.sleep(1000);	
					}
					catch(Exception e)
					{
						
					}
				}
				m++;
			}
		
//			wait.until(ExpectedConditions.visibilityOf(specificDate));
			DateFormat dateFormat = new SimpleDateFormat("dd");
			Date date = new Date();
			Calendar cal = Calendar.getInstance();
			String formattedStartDate = dateFormat.format(date);
			cal.add(Calendar.DAY_OF_MONTH, days); 
			String formattedEndDate = dateFormat.format(cal.getTime());
			System.out.println("Current date is " + formattedStartDate + " and end date is " + formattedEndDate);
			specificDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			WebElement reqDate = driver.findElement(By.xpath(datePick + formattedEndDate + " and not(contains(@class, 'disabled day' ))]"));
			reqDate.click();
		}
		
		public void validateTotalUser(String type,String noofUser) {
		
			List<WebElement>  TotalUser;
			try
			{
			Thread.sleep(5000);	
			}
			catch(Exception e)
			{
				
			}
			if(type.contains("manual"))
			{
			TotalUser=driver.findElements(By.xpath(manTotalUser));
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(manTotalUser))));
			}
			else if(type.contains("ViewManual"))
			{
			TotalUser=driver.findElements(By.xpath(autoTotalUser));
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(autoTotalUser))));
			} 
			else
			{

				reuse.waitforsec(5);
				 TotalUser=driver.findElements(By.xpath(autoTotalUser));
					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(autoTotalUser))));
					
							
			}
			
			System.out.println(TotalUser.size());
			Assert.assertTrue("Validate Total User", Integer.parseInt(noofUser)==TotalUser.size());
			
		
			
		}
		
		
		public void pagination(String number) {
			
			reuse.waitforsec(4);
			Select drpState;
			try
			{
			wait.until(ExpectedConditions.visibilityOf(pagination));
			 drpState = new Select(pagination);
			}
			catch(Exception e)
			{
				wait.until(ExpectedConditions.visibilityOf(editpagination));
			 drpState = new Select(editpagination);
				
			}
			drpState.selectByValue(number);
		}
		
		public void criteriaMsgs(String msg)
		{

			if(AssignmentReport. checkifParmeterAvailable( msg))
				 msg=AssignmentReport.getParmeterAvailable( msg);

			WebDriverWait wait = new WebDriverWait(driver, 30);
		
			wait.until(ExpectedConditions.visibilityOf(manualSectionStrong));
			System.out.println(manualSectionStrong.getText());
	     Assert.assertEquals("Automatic Learner(s) Section Criteria", manualSectionStrong.getText());;
	     
	     Assert.assertEquals(msg, manualSectiontitle.getText());;
	     
		}
		
		public void criteriaMsg(String msg)
		{

			if(AssignmentReport. checkifParmeterAvailable( msg))
				 msg=AssignmentReport.getParmeterAvailable( msg);

			WebDriverWait wait = new WebDriverWait(driver, 30);
		
			wait.until(ExpectedConditions.visibilityOf(errorMsg));
			System.out.println(errorMsg.getText());
	     Assert.assertEquals(msg, errorMsg.getText());;
		}
		
		
		
		public void selectCriteria(String name, int criteriaRow,String rlation)
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			WebElement criteria = driver.findElement(By.xpath(selectCriteriaDropdown1 + criteriaRow + "_criteria']"));
			wait.until(ExpectedConditions.elementToBeClickable(criteria));
			Select select = new Select(criteria);
			select.selectByVisibleText(name.trim());
			 criteria = driver.findElement(By.xpath(relation+(criteriaRow+1) +"]"));
				wait.until(ExpectedConditions.elementToBeClickable(criteria));
				
			 select = new Select(criteria);
			select.selectByVisibleText(rlation.trim());
			
			
			System.out.println(name.toLowerCase().trim());
			if (!name.equalsIgnoreCase("hire date"))
			{
				WebElement criteriaValue = driver.findElement(By.xpath(selectCriteriaValueDropdown1 + (criteriaRow + 1) + "_criterias_data_list']"));
				wait.until(ExpectedConditions.elementToBeClickable(criteriaValue));
				select = new Select(criteriaValue);
				if(name.equalsIgnoreCase("Group"))
				select.selectByVisibleText(OrganizationSettings.groupName);
				else if(name.equalsIgnoreCase("Job Title"))
					select.selectByVisibleText(OrganizationSettings.titleName);
				else 
				{
					select.selectByIndex(1);
				}
			}
			else
			{
				DateFormat dateFormat = new SimpleDateFormat("dd");
				Date date = new Date();
				Calendar cal = Calendar.getInstance();
				String formattedStartDate = dateFormat.format(date);
				if(rlation.equalsIgnoreCase("before") )
				{
				cal.add(Calendar.DAY_OF_MONTH, 1); 
				}
				else
				{
					cal.add(Calendar.DAY_OF_MONTH, -3); 
			    }
						
				 formattedStartDate = dateFormat.format(cal.getTime());
			
			   wait.until(ExpectedConditions.visibilityOf(hireDate));
				
				js.executeScript("arguments[0].click();", HireDateCalendar);
				wait.until(ExpectedConditions.elementToBeClickable(HireDateCalendar));
				val = pageLoad.getAttribute("class");
				while(val.equalsIgnoreCase("loading_assignment"))
				{
					val = pageLoad.getAttribute("class");
				}
				HireDateCalendar.click();
				wait.until(ExpectedConditions.elementToBeClickable(calendarProduct));
//				wait.until(ExpectedConditions.visibilityOf(calendarProduct));
				js.executeScript("arguments[0].click();", hireDate);
//				hireDate.click();
				wait.until(ExpectedConditions.visibilityOf(calendarProduct));
				WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + " and not(contains(@class, 'disabled day' ))]"));
				js.executeScript("arguments[0].click();", reqDate);
				
				if(rlation.equalsIgnoreCase("between") )
				{
					cal = Calendar.getInstance();
				 formattedStartDate = dateFormat.format(date);
				cal.add(Calendar.DAY_OF_MONTH, 2); 
				String formattedEndDate = dateFormat.format(cal.getTime());
				
				js.executeScript("arguments[0].click();", HireendDateCalendar);
				wait.until(ExpectedConditions.elementToBeClickable(HireendDateCalendar));
				HireendDateCalendar.click();
				
				js.executeScript("arguments[0].click();", endhiredate);
//				hireDate.click();
				wait.until(ExpectedConditions.visibilityOf(calendarProduct));
				 reqDate = driver.findElement(By.xpath(datePick + formattedEndDate + " and not(contains(@class, 'disabled day' ))]"));
				js.executeScript("arguments[0].click();", reqDate);
				}

				
				
//				reqDate.click();
			}
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
			}
		}
		
		public void selectmultiCriteria(String name, int criteriaRow,String values)
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
			}
			WebDriverWait wait = new WebDriverWait(driver, 30);
			WebElement criteria = driver.findElement(By.xpath(selectCriteriaDropdown1 + criteriaRow + "_criteria']"));
			wait.until(ExpectedConditions.elementToBeClickable(criteria));
			Select select = new Select(criteria);
			select.selectByVisibleText(name.trim());
				
			
			
			System.out.println(name.toLowerCase().trim());
			if (!name.equalsIgnoreCase("hire date"))
			{
				WebElement criteriaValue = driver.findElement(By.xpath(selectCriteriaValueDropdown1 + (criteriaRow + 1) + "_criterias_data_list']"));
				wait.until(ExpectedConditions.elementToBeClickable(criteriaValue));
				select = new Select(criteriaValue);
				if(name.equalsIgnoreCase("Group"))
					select.selectByVisibleText(OrganizationSettings.groupNames[Integer.parseInt(values)-1]);
				else if(name.equalsIgnoreCase("Job Title"))
				{
					select.selectByVisibleText(OrganizationSettings.jobTitle[Integer.parseInt(values)-1]);
				}
				else 
				{
					select.selectByIndex(1);
				}
			}
			else
			{
				DateFormat dateFormat = new SimpleDateFormat("dd");
				Date date = new Date();
				Calendar cal = Calendar.getInstance();
				String formattedStartDate = dateFormat.format(date);
				
				cal.add(Calendar.DAY_OF_MONTH, -1); 
				 formattedStartDate = dateFormat.format(cal.getTime());
			
			   wait.until(ExpectedConditions.visibilityOf(hireDate));
				
				js.executeScript("arguments[0].click();", HireDateCalendar);
				wait.until(ExpectedConditions.elementToBeClickable(HireDateCalendar));
				val = pageLoad.getAttribute("class");
				while(val.equalsIgnoreCase("loading_assignment"))
				{
					val = pageLoad.getAttribute("class");
				}
				HireDateCalendar.click();
				wait.until(ExpectedConditions.elementToBeClickable(calendarProduct));
//				wait.until(ExpectedConditions.visibilityOf(calendarProduct));
				js.executeScript("arguments[0].click();", hireDate);
//				hireDate.click();
				wait.until(ExpectedConditions.visibilityOf(calendarProduct));
				WebElement reqDate = driver.findElement(By.xpath(datePick + formattedStartDate + " and not(contains(@class, 'disabled day' ))]"));
				js.executeScript("arguments[0].click();", reqDate);
				
				
				
				
//				reqDate.click();
			}
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
			}
		}
		public void searchUserByDeliveryManual( String value)
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			
			wait.until(ExpectedConditions.visibilityOf(studentManSearchBox));
			wait.until(ExpectedConditions.elementToBeClickable(studentManSearchBox));
			
			
			Select drpState = new Select(driver.findElement(By.xpath("//*[@id='manual_delivery']")));
			drpState.selectByValue(value);
				
			String val = pageLoad.getAttribute("class");
			try {
				int counter = 0;
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			}
			catch(Exception e) {
				
			}
			verifymanualDelivery(value);
		}
		
		public void validatetheAssignmentDeliveryFilters( String value)
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='manual_delivery']"))));
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='manual_delivery']"))));
			
			
			Select drpState = new Select(driver.findElement(By.xpath("//*[@id='manual_delivery']")));
			drpState.selectByValue(value);
				
			String val = pageLoad.getAttribute("class");
			try {
				int counter = 0;
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			}
			catch(Exception e) {
				
			}
//			verifymanualDelivery(value);
		}
		
		
	
		public void clickonSearchButton()
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			
			wait.until(ExpectedConditions.visibilityOf(SearchButton));
			wait.until(ExpectedConditions.elementToBeClickable(SearchButton));
			SearchButton.click();
		
		}
	
		public void verifymanualDelivery(String value)
		{
			String val = pageLoad.getAttribute("class");
			try {
				int counter = 0;
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			}
			catch(Exception e) {
				
			}
		WebDriverWait wait = new WebDriverWait(driver, 30);
			
			wait.until(ExpectedConditions.visibilityOf(manualdeliveryValue));
		
			String uName = manualdeliveryValue.getText();
			Assert.assertEquals(value.trim(), uName.trim());
			
		}
		
		public void verifymanual_Delivery(String value)
		{
			String val = pageLoad.getAttribute("class");
			try {
				int counter = 0;
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			}
			catch(Exception e) {
				
			}
		WebDriverWait wait = new WebDriverWait(driver, 30);
			
			wait.until(ExpectedConditions.visibilityOf(manualdeliveryValue));
		
			String uName = manualdeliveryValue.getText();
			Assert.assertEquals(value.trim(), uName.trim());
			
		}
		public void  selectAssignmentDueDatePrevious(String dueDate)
		{
			String val = pageLoad.getAttribute("class");
			try {
				int counter = 0;
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			}
			catch(Exception e) {
				
			}
			switch(dueDate.toLowerCase().trim())
			{
			case "specific date":
				addSpecificDatePrevious();
				break;
			case "relative date":
				selectRelativeDate(1);
				break;
			}
		}
		public void addSpecificDatePrevious()
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			String val = pageLoad.getAttribute("class");
			try {
				int counter = 0;
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			}
			catch(Exception e) {
				
			}
			wait.until(ExpectedConditions.visibilityOf(radioSpecificDate));
			radioSpecificDate.click();
			wait.until(ExpectedConditions.visibilityOf(specificDate));
			DateFormat dateFormat = new SimpleDateFormat("d");
			Date date = new Date();
			Calendar cal = Calendar.getInstance();
			String formattedStartDate = dateFormat.format(date);
			cal.add(Calendar.DAY_OF_MONTH, -1); 
			String formattedEndDate = dateFormat.format(cal.getTime());
			System.out.println("Current date is " + formattedStartDate + " and end date is " + formattedEndDate);
			specificDate.click();
			wait.until(ExpectedConditions.visibilityOf(calendarProduct));
			WebElement reqDate = driver.findElement(By.xpath(datePick + formattedEndDate + " and (contains(@class, 'disabled day'  ) or contains(@class, 'old disabled day'  ))]"));
			wait.until(ExpectedConditions.visibilityOf(reqDate));
		}
		
		public void removeUser(int i)
		{
	   wait.until(ExpectedConditions.visibilityOf(studentSearchText));
		String val = pageLoad.getAttribute("class");
		User usr=new User();
		int m=0;
		while(val.equalsIgnoreCase("loading_assignment"))
		{
			val = pageLoad.getAttribute("class");
			if(m==302)
				break;
			m++;
		}
		try
		{
		Thread.sleep(3000);
		}
		catch(Exception e)
		{
			
		}


			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(remove+"["+i+"]"))));
			driver.findElement(By.xpath(remove+"["+i+"]")).click();
		}
		public void editAssignmentTitleAlreadyAvailable()
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			String val = pageLoad.getAttribute("class");
			
			int m=0;
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				if(m==302)
					break;
				m++;
			}
			try
			{
			Thread.sleep(3000);
			}
			catch(Exception e)
			{
				
			}
			wait.until(ExpectedConditions.visibilityOf(assignmentTitleSearchBox));
			wait.until(ExpectedConditions.elementToBeClickable(assignmentTitleSearchBox));
			assignmentTitleSearchBox.click();
			assignmentTitleSearchBox.clear();
			assignmentTitleSearchBox.sendKeys(AssgnmentName);
			
			wait.until(ExpectedConditions.visibilityOf(nextSection));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", nextSection);
	
		}
		
		public void getAllUserUIList()
		{
			list_UI.clear();
			JavascriptExecutor js = (JavascriptExecutor)driver;
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(userRows))));
			List<WebElement> tableRows = driver.findElements(By.xpath(userRows));
			int rowCount = tableRows.size();
			uiList = new String[rowCount][7];
			for (int i= 1; i<= rowCount; i++)
			{
				for(int j = 2; j <= 8; j++)
				{
					String textValue = driver.findElement(By.xpath("(" + userRows + ")[" + i + "]/td[" + j + "]")).getText();
					uiList[i-1][j-2] = textValue;
				}
			}
			for (String[] ints : uiList) 
			{
				list_UI.add(Arrays.asList(ints));
			}
			
			
			
		}
		
		public void getAllAutoUserUIList()
		{
			list_UI.clear();
			JavascriptExecutor js = (JavascriptExecutor)driver;
			val = js.executeScript("return document.readyState").toString();
			while(!(val.equalsIgnoreCase("complete")))
			{
				val = js.executeScript("return document.readyState").toString();
			}
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(autoUserRows))));
			List<WebElement> tableRows = driver.findElements(By.xpath(autoUserRows));
			int rowCount = tableRows.size();
			uiList = new String[rowCount][7];
			for (int i= 1; i<= rowCount; i++)
			{
				for(int j = 1; j <= 7; j++)
				{
					String textValue = driver.findElement(By.xpath("(" + autoUserRows + ")[" + i + "]/td[" + j + "]")).getText();
					uiList[i-1][j-1] = textValue;
				}
			}
			for (String[] ints : uiList) 
			{
				list_UI.add(Arrays.asList(ints));
			}
			
			
			
		}
		
		
		

		public void getAllAutoUserExcelList()
		{
			try 
			{
				list_report.clear();
				Thread.sleep(5000);
				File file = new File(User.filePath);
				FileReader filereader = new FileReader(file);
				CSVReader csvReader = new CSVReader(filereader); 
				List<String[]> header = csvReader.readAll();
				System.out.println(header.size());
				String userRange = userAutoListRange.getText();
				int starting = Integer.parseInt(userRange.split(" ")[1]);
				int ending = Integer.parseInt(userRange.split(" ")[3]);
				System.out.println(starting);
				System.out.println(ending);
				
				String reportDetails[][] = new String[ending - starting +1][7];
				for(int i = 3; i <=ending - starting+3; i++)
					{
					String excelData[] = header.get(starting+(i-1));
					System.out.println(Arrays.toString(header.get(starting+(i-1))));
					String []excel = excelData[0].split(";");
					for(int j = 0; j <= 6; j++)
					{
						
							System.out.println( excel[j].replace("\"", "").trim());
							
						reportDetails[i-3][j] = excel[j].replace("\"", "").trim();
					}				
				}
				csvReader.close();
				for (String[] ints : reportDetails) {
					list_report.add(Arrays.asList(ints));
					System.out.println(Arrays.asList(ints));
				}
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
				Assert.fail(e.getMessage());
				
			}
		}
		
		public void getAllUserExcelList()
		{
			try 
			{
				list_report.clear();
				Thread.sleep(5000);
				File file = new File(User.filePath);
				FileReader filereader = new FileReader(file);
				CSVReader csvReader = new CSVReader(filereader); 
				List<String[]> header = csvReader.readAll();
				System.out.println(header.size());
				String userRange = userListRange.getText();
				int starting = Integer.parseInt(userRange.split(" ")[1]);
				int ending = Integer.parseInt(userRange.split(" ")[3]);
				System.out.println(starting);
				System.out.println(ending);
				
				String reportDetails[][] = new String[ending - starting +1][7];
				for(int i = 3; i <=ending - starting+3; i++)
					{
					String excelData[] = header.get(starting+(i-1));
					System.out.println(Arrays.toString(header.get(starting+(i-1))));
					String []excel = excelData[0].split(";");
					for(int j = 0; j <= 6; j++)
					{
						
							System.out.println( excel[j].replace("\"", "").trim());
							
						reportDetails[i-3][j] = excel[j].replace("\"", "").trim();
					}				
				}
				csvReader.close();
				for (String[] ints : reportDetails) {
					list_report.add(Arrays.asList(ints));
					System.out.println(Arrays.asList(ints));
				}
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
				Assert.fail(e.getMessage());
				
			}
		}
		
		public void compareActivityList()
		{
			List<List<String>> differences = new ArrayList<>(list_UI);
			differences.removeAll(list_report);
			System.out.println(differences.size());
			Assert.assertTrue(differences.size() == 0);
		}
		public void getStudentAssignmentCount()
	    {
	        try
	        {
	        	Thread.sleep(4000);
		        WebDriverWait wait = new WebDriverWait(driver, 30);
		        wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//td[text()='"+AssgnmentName+"']//following::td[5]"))));        
		        studentCount = Integer.parseInt(driver.findElement(By.xpath("//td[text()='"+AssgnmentName+"']//following::td[5]")).getText());
		        System.out.println("Studentcount ion assignment page for assignment title " + AssgnmentName + " is " + studentCount );
	        }
	        catch(Exception e)
	        {
	            Assert.fail(e.getMessage());
	        } 
	    }

		public void assignmentFromUserSpecificCourseWithSubscription(String course,String plan)
		{
			if(courseListName.containsKey(course+"Option"))
				course=courseListName.get(course+"Option").toString();

			course=course.replace("Â", "");
			System.out.println(course);

			wait.until(ExpectedConditions.visibilityOf(selectCourseDrp));
			int m=0;
			String val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", selectCourseDrp);
			wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(courseList))));
			List<WebElement> elements = driver.findElements(By.xpath(courseList));
			for(int i = 1; i<= elements.size(); i++)
			{
				String text = driver.findElement(By.xpath("(" + courseList + ")[" + i + "]")).getText();
				System.out.println(text);
				if(course.trim().toLowerCase().equals(text.toLowerCase().trim()))
				{

					driver.findElement(By.xpath("(" + courseList + ")[" + i + "]")).click();
					break;
				}
			}

			String date = new java.util.Date().toString();
			date = date.replace(" ", "");
			assignmentName.sendKeys(date);
			if(course.contains("Entry") || course.contains("Ready") || course.contains("Prep")) {
				selectsubscriptionPlan(plan);
			}
		}
		
		public void createOrgPayAssignmentCourseName(String course) {
			if(courseListName.containsKey(course+"Option"))
				course=courseListName.get(course+"Option").toString();

			course=course.replace("Â", "");
			System.out.println(course);

			wait.until(ExpectedConditions.visibilityOf(selectCourseDrp));
			int m=0;
			String val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", selectCourseDrp);
			wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(courseList))));
			List<WebElement> elements = driver.findElements(By.xpath(courseList));
			for(int i = 1; i<= elements.size(); i++)
			{
				String text = driver.findElement(By.xpath("(" + courseList + ")[" + i + "]")).getText();
				System.out.println(text);
				if(course.trim().toLowerCase().equals(text.toLowerCase().trim()))
				{

					driver.findElement(By.xpath("(" + courseList + ")[" + i + "]")).click();
					break;
				}
			}

			String date = new java.util.Date().toString();
			date = date.replace(" ", "");
			assignmentName.sendKeys(date);
			selectOrganizationPayRadio();
		}
		
		public void assignmentFromUserSpecificCourses(String course)
		{
			if(courseListName.containsKey(course+"Option"))
				course=courseListName.get(course+"Option").toString();

			course=course.replace("Â", "");
			System.out.println(course);

			wait.until(ExpectedConditions.visibilityOf(selectCourseDrp));
			int m=0;
			String val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				if(m==pagload)
					break;
				m++;
			}
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", selectCourseDrp);
			wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(courseList))));
			List<WebElement> elements = driver.findElements(By.xpath(courseList));
			for(int i = 1; i<= elements.size(); i++)
			{
				String text = driver.findElement(By.xpath("(" + courseList + ")[" + i + "]")).getText();
				System.out.println(text);
				if(course.trim().toLowerCase().equals(text.toLowerCase().trim()))
				{

					driver.findElement(By.xpath("(" + courseList + ")[" + i + "]")).click();
					break;
				}
			}

			String date = new java.util.Date().toString();
			date = date.replace(" ", "");
			assignmentName.sendKeys(date);
		
		}
		
		public void Click_on_nextSection()
		{
			editAssignmentTitle();
			reuse.waitforsec(4);
			wait.until(ExpectedConditions.visibilityOf(nextSection));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", nextSection);
	
		
		}
		public void addLearners(String userName)
		{
			WebDriverWait wait = new WebDriverWait(driver, 40);
			
			
			wait.until(ExpectedConditions.visibilityOf(AddLearnersButton));
			
			AddLearnersButton.click();
			
//			
//			String val = pageLoad.getAttribute("class");
//			try {
//				int counter = 0;
//			while(val.equalsIgnoreCase("loading_assignment"))
//			{
//				val = pageLoad.getAttribute("class");
//				Thread.sleep(5000);
//				counter++;
//				if(counter>12)
//					Assert.fail("Not able to load page after waiting for 1 minute");
//			}
//			}
//			catch(Exception e) {
//				
//			}
			reuse.waitforsec(4);
			wait.until(ExpectedConditions.visibilityOf(studentSearchText));
			studentSearchText.click();
			studentSearchText.sendKeys(userName);
			String result = studentSearchResult.getText();
			val = pageLoad.getAttribute("class");
			try {
			int counter = 0;
			while(result.length() == 0)
			{
				result = studentSearchResult.getText();
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			}
			catch(Exception e) {
			}
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", studentSearchOption);
			try {
			Thread.sleep(5000);
		}
		catch(Exception e) {
		}
			LearnersAddButton.click();
			
		}
		
		
		public void addLearners(int i)
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			
			wait.until(ExpectedConditions.visibilityOf(AddLearnersButton));
			
			AddLearnersButton.click();
			
			wait.until(ExpectedConditions.visibilityOf(studentSearchText));
			String val = pageLoad.getAttribute("class");
			try {
				int counter = 0;
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			}
			catch(Exception e) {
				
			}
			try
			{
			Thread.sleep(3000);
			studentSearchText.clear();
			}
			catch(Exception e)
			{
				
			}
			wait.until(ExpectedConditions.visibilityOf(studentSearchText));
			studentSearchText.click();
			
			System.out.println(User.usrEmail[i]);
				for(int j=0;j<User.usrEmail[i].length();j++)
				{
					studentSearchText.sendKeys(String.valueOf(User.usrEmail[i].charAt(j)));
				}
				try {
					int counter = 0;
				while(val.equalsIgnoreCase("loading_assignment"))
				{
					val = pageLoad.getAttribute("class");
					Thread.sleep(5000);
					counter++;
					if(counter>12)
						Assert.fail("Not able to load page after waiting for 1 minute");
				}
				}
				catch(Exception e) {	
				}						
				try
				{
			String result = studentSearchResult.getText();
			val = pageLoad.getAttribute("class");
			int counter = 0;//	
			while(result.length() == 0)
			{
				result = studentSearchResult.getText();
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load student after waiting for 1 minute");
				
			}
			Thread.sleep(2000);
			
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", studentSearchOption);
			}
			catch(Exception e)
				{
				
				}
				LearnersAddButton.click();
		}
		public void addLearners(String userName,int count)
		{
			reuse.waitforsec(4);
			wait.until(ExpectedConditions.visibilityOf(AddLearnersButton));
			
			AddLearnersButton.click();
			wait.until(ExpectedConditions.visibilityOf(studentSearchText));
			String val = pageLoad.getAttribute("class");
			try {
				int counter = 0;
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			}
			catch(Exception e) {
				
			}
			studentSearchText.click();
			studentSearchText.clear();
			System.out.println(User.usrEmail[count]);
			for(int i=0;i<User.usrEmail[count].length();i++)
				studentSearchText.sendKeys(String.valueOf(User.usrEmail[count].charAt(i)));
		
			try {
				Thread.sleep(3000);
			}
			catch(Exception e) {
			}
			String result = studentSearchResult.getText();
			val = pageLoad.getAttribute("class");
			try {
			int counter = 0;
			while(result.length() == 0)
			{
				result = studentSearchResult.getText();
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			}
			catch(Exception e) {
			}
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", studentSearchOption);
			try {
			Thread.sleep(5000);
		}
		catch(Exception e) {
		}
			LearnersAddButton.click();
			
		}
		
		public void click_on_cancel()
		{
			
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(LearnersCancelButton));
			LearnersCancelButton.click();
		
		}
		
		public void click_on_AddLearnersButton()
		{
			
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(AddLearnersButton));
			AddLearnersButton.click();
		
		}


		public void addLearners()
		{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			
			
			wait.until(ExpectedConditions.visibilityOf(AddLearnersButton));
			
			AddLearnersButton.click();
			wait.until(ExpectedConditions.visibilityOf(studentSearchText));
			String val = pageLoad.getAttribute("class");
			try {
				int counter = 0;
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			}
			catch(Exception e) {
				
			}
			studentSearchText.click();
			for(int i=0;i<User.userEmail.length();i++)
			{
				studentSearchText.sendKeys(String.valueOf(User.userEmail.charAt(i)));
				
			}
			
			wait.until(ExpectedConditions.visibilityOf(NoMatchingStudents));
			
			String errmsg=NoMatchingStudents.getText();
			System.out.println(errmsg);
			Assert.assertEquals("No Matching Students!",errmsg);
			try {
			Thread.sleep(5000);
		}
		catch(Exception e) {
		}
			LearnersAddButton.click();
			
		}
		public void verifyAddStudentFirst(String userName)
		{
			reuse.waitforsec(4);
			String val = pageLoad.getAttribute("class");
			try {
				int counter = 0;
			while(val.equalsIgnoreCase("loading_assignment"))
			{
				val = pageLoad.getAttribute("class");
				Thread.sleep(5000);
				counter++;
				if(counter>12)
					Assert.fail("Not able to load page after waiting for 1 minute");
			}
			}
			catch(Exception e) {
				
			}
			String uName = studentFirstAddResult.getText();
			Assert.assertEquals(userName, uName);
			
		}
		
		public void clickAssignedLearners() {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(assignedLearnersBtn));
			assignedLearnersBtn.click();
		}
		
		public void clickactionDropDown() {
			reuse.waitforsec(4);
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//td[text()='"+User.userId+"']/following::td//a[@class='action_dropdown ']"))));
			driver.findElement(By.xpath("//td[text()='"+User.userId+"']/following::td//a[@class='action_dropdown ']")).click();
		}
		
		public void clickactionDropDownisdisabled() {
			reuse.waitforsec(4);
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//td[text()='"+User.userId+"']/following::td//a[@class='action_dropdown disabled']"))));
//			driver.findElement(By.xpath("//td[text()='"+User.userId+"']/following::td//a[@class='action_dropdown disabled']")).click();
		}
		
		 
		
		public void validate_if_unenroll_disable() {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(unenroll));
		 Assert.assertEquals(unenroll.getAttribute("class"), "disabled");	
		}
		
		
		public void noStudentareAvailable() {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(noStudentAreAvailable));
		 Assert.assertEquals(noStudentAreAvailable.getText(), "No Students are available.");	
		}
		
		public void noStudentareAvailablewhileadduser() {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			reuse.waitforsec(3);
			wait.until(ExpectedConditions.visibilityOf(noStudentsAreAvailable));
		 Assert.assertEquals(noStudentsAreAvailable.getText(), "No Students are available.");	
           	
			Assert.assertEquals("Showing entries is incorrect","Showing "+0+" to "+0+" of "+0+" entries" , driver.findElement(By.xpath("("+showentries+")[1]")).getText());
			Assert.assertEquals("Showing entries is incorrect","Showing "+0+" to "+0+" of "+0+" entries" , driver.findElement(By.xpath("("+showentries+")[2]")).getText());
		
		}
		
		public void noStudentareAvailableassignLearn() {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			reuse.waitforsec(3);
			wait.until(ExpectedConditions.visibilityOf(noStudentsAreAvailablemessage));
		 Assert.assertEquals(noStudentsAreAvailablemessage.getText(), "No Students are available.");	
           	
			Assert.assertEquals("Showing entries is incorrect","Showing "+0+" to "+0+" of "+0+" entries" , driver.findElement(By.xpath("("+showentries+")[1]")).getText());
			Assert.assertEquals("Showing entries is incorrect","Showing "+0+" to "+0+" of "+0+" entries" , driver.findElement(By.xpath("("+showentries+")[2]")).getText());
		
		}
		
		
		public void recordareAvalable() {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(assgined_learners.get(1)));
		 Assert.assertEquals(assgined_learners.get(1).getText(),User.userId);	
		 Assert.assertEquals(assgined_learners.size(),10);	
		}
		
		public void validate_if_unenroll_disableforAction() {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(selectAllUser));
			selectAllUser.click();
			
			wait.until(ExpectedConditions.visibilityOf(actionBtn));
			actionBtn.click();
			
		 Assert.assertEquals(unenrollBulkAssignments.getAttribute("class"), "disabled");	
		}
		
		public void enroll_user() {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(unenroll));
			unenroll.click();
			wait.until(ExpectedConditions.visibilityOf(unenrollCheckBox));
			
			unenrollCheckBox.click();
		
			wait.until(ExpectedConditions.visibilityOf(unenrollCourseDeleteYes));
			unenrollCourseDeleteYes.click();
			reuse.waitforsec(5);
			
			wait.until(ExpectedConditions.visibilityOf(unenrollsuccessmsg));
			System.out.println(unenrollsuccessmsg.getText());
			Assert.assertTrue(unenrollsuccessmsg.getText().contains("The selected learner(s) have successfully been unenrolled from this assignment."));
			wait.until(ExpectedConditions.visibilityOf(successCloseButton));
			successCloseButton.click();
		
			
		
		}
		
		
		public void clickonenroll_user() {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(unenroll));
			unenroll.click();
			
			
		
		}
		
		public void clickenroll_userAction() {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(selectAllUser));
			selectAllUser.click();
			
			wait.until(ExpectedConditions.visibilityOf(actionBtn));
			actionBtn.click();
			
			unenrollBulkAssignments.click();
     	}
		
		public void enroll_userAction() {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(selectAllUser));
			selectAllUser.click();
			
			wait.until(ExpectedConditions.visibilityOf(actionBtn));
			actionBtn.click();
			
			unenrollBulkAssignments.click();
         wait.until(ExpectedConditions.visibilityOf(unenrollCheckBox));
			
			unenrollCheckBox.click();
		
			wait.until(ExpectedConditions.visibilityOf(unenrollCourseDeleteYes));
			unenrollCourseDeleteYes.click();
			reuse.waitforsec(5);
			
			wait.until(ExpectedConditions.visibilityOf(unenrollsuccessmsg));
			System.out.println(unenrollsuccessmsg.getText());
			Assert.assertTrue(unenrollsuccessmsg.getText().contains("The selected learner(s) have successfully been unenrolled from this assignment."));
			wait.until(ExpectedConditions.visibilityOf(successCloseButton));
			successCloseButton.click();
		}
		
		public void enroll_userActionunableEnroll() {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(selectAllUser));
			selectAllUser.click();
			
			wait.until(ExpectedConditions.visibilityOf(actionBtn));
			actionBtn.click();
			
			unenrollBulkAssignments.click();
            wait.until(ExpectedConditions.visibilityOf(unenrollCheckBox));
			
			unenrollCheckBox.click();
		
			wait.until(ExpectedConditions.visibilityOf(unenrollCourseDeleteYes));
			unenrollCourseDeleteYes.click();
			reuse.waitforsec(5);
			
			wait.until(ExpectedConditions.visibilityOf(unenrollerrormsg));
			System.out.println(unenrollerrormsg.getText());
			Assert.assertTrue(unenrollerrormsg.getText().contains("Unable to unenroll course."));
			wait.until(ExpectedConditions.visibilityOf(successCloseButton));
			successCloseButton.click();
		}
		
		public void validateStep1isdisplayed()
		{
			wait.until(ExpectedConditions.elementToBeClickable(assignmentStep1));
//			wait.until(ExpectedConditions.visibilityOf(createAssignment));
			System.out.println(assignmentStep1.getText());
			Assert.assertTrue("Assignment Details is not displayed", assignmentStep1.getText().contains("Assignment Details"));
			Assert.assertTrue("Step 1 is not displayed", assignmentStep1.getText().contains("Step 1"));
			
		}
		
		public void validateStep2isdisplayed()
		{
			wait.until(ExpectedConditions.elementToBeClickable(assignmentStep2));
//			wait.until(ExpectedConditions.visibilityOf(createAssignment));
			System.out.println(assignmentStep2.getText());
			
			Assert.assertTrue("Add Learners is not displayed", assignmentStep2.getText().contains("Add Learners"));
			Assert.assertTrue("Step 2 is not displayed", assignmentStep2.getText().contains("Step 2"));
		}
		
		public void selectallUser() {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(selectAllUser));
			selectAllUser.click();
		}
		
		public void RemoveLearnerButton() {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(RemoveLearner));
			RemoveLearner.click();
		}
		
		public void moreFiltersButton() {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(moreFilters));
			moreFilters.click();
		}
		
		
		public void validateaLearnerslistingTable(String header,String value)
		{
			if(header.contains("Date of Hire")&&value==null )
			{
				DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
				Calendar cal = Calendar.getInstance();
//				cal.add(Calendar.DAY_OF_MONTH, -1);
				String formattedStartDate = dateFormat.format(cal.getTime());
				System.out.println(formattedStartDate);
				value=formattedStartDate;
			}
			else if(header.contains("User ID")&&value==null)
			{
			
				value=User.userId;
			}
			else if(header.contains("Last Name")&&value==null)
			{
	
				value=User.userLastName;
			}
			else if(header.contains("First Name")&&value==null)
			{
	
				value=User.userFirstName;
			}
			else if(header.contains("Unit Name")&&value==null)
			{
	
				value= OrganizationSettings.	newUnitName;
			}
			else if(header.contains("Job Title")&&value==null)
			{
	
				value=OrganizationSettings.titleName;
			}
			reuse.validatethedetails(header, selected_user+"th", value, selected_user+"td","User ID",User.userId);
		}
		
		public void validateisNoofrecords(int row) {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(driver.findElements(By.xpath(selected_user+"tbody//tr")).get(0)));
			Assert.assertEquals("Number of record is incorrect", row, driver.findElements(By.xpath(selected_user+"tbody//tr")).size());
			
			Assert.assertEquals("Showing entries is incorrect","Showing "+row+" to "+row+" of "+row+" entries" , driver.findElement(By.xpath("("+showentries+")[1]")).getText());
			Assert.assertEquals("Showing entries is incorrect","Showing "+row+" to "+row+" of "+row+" entries" , driver.findElement(By.xpath("("+showentries+")[2]")).getText());
			
		}
		
		public void validateis_Noofrecords(int row) {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOf(driver.findElements(By.xpath("//table[@id='assgined_learners']//tbody//tr")).get(0)));
			Assert.assertEquals("Number of record is incorrect", row, driver.findElements(By.xpath("//table[@id='assgined_learners']//tbody//tr")).size());
			
			Assert.assertEquals("Showing entries is incorrect","Showing 1 to "+row+" of "+row+" entries" , driver.findElement(By.xpath("("+showentries+")[1]")).getText());
			Assert.assertEquals("Showing entries is incorrect","Showing 1 to "+row+" of "+row+" entries" , driver.findElement(By.xpath("("+showentries+")[2]")).getText());
			
		}
		
		public void validateaAssignedlistingTable(String header,String value,int m)
		{
			if(header.contains("Date of Hire")&&value==null )
			{
				DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
				Calendar cal = Calendar.getInstance();
//				cal.add(Calendar.DAY_OF_MONTH, -1);
				String formattedStartDate = dateFormat.format(cal.getTime());
				System.out.println(formattedStartDate);
				value=formattedStartDate;
			}
			else if(header.contains("User ID")&&value==null)
			{
			
				value=User.userId;
			}
			else if(header.contains("Last Name")&&value==null)
			{
	
				value=User.userLastName;
			}
			else if(header.contains("First Name")&&value==null)
			{
	
				value=User.userFirstName;
			}
			else if(header.contains("Unit Name")&&value==null)
			{
	
				value= OrganizationSettings.	newUnitName;
			}
			else if(header.contains("Job Title")&&value==null)
			{
	
				value=OrganizationSettings.titleName;
			}
			else if(header.contains("Unit Name"))
			{
				if(value!=null)
				{
					if(value.equals("OrgName"))
					value=TestBase.prop.getProperty("orgName");
				}
			}
					
			
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tablesmultiple))));
			List<WebElement> tableRows = driver.findElements(By.xpath(tablesmultiple));
			boolean flag=false;
			for(int i=1;i<=tableRows.size();i++)
			{
				System.out.println(driver.findElement(By.xpath(tablesmultiple+"["+i+"]")).getText());
				System.out.println("header "+header+ " "+value);
				System.out.println("header "+header+ " userID"+User.usrID[m]);
				
				
				if(validatethedetailstablesmultiple(header, headerxpth+"th", value, tablesmultiple+"["+i+"]//td","User ID",User.usrID[m])==true)
				{
					
					flag=true;
					break;
				}
			}
			Assert.assertTrue("Unable to find UserID"+flag,flag);
			
		}
		
		public boolean validatethedetailstablesmultiple(String header,String tableHeader,String value,String tablerow,String EmailHeader,String UserID)
		{
//			wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(tableHeader))));
			List<WebElement> tableRows = driver.findElements(By.xpath(tablerow));
			boolean flag=false;
//			System.out.println(tableRows.get(getHeaderPosition(header,tableHeader)-1).getText());
			if(tableRows.get(reuse.getHeaderPosition(EmailHeader,tableHeader)-1).getText().contains(UserID))
			{
				
			Assert.assertEquals(tableRows.get(reuse.getHeaderPosition(header,tableHeader)-1).getText(), value);
			flag=true;
			
			}
			
			return flag;
		}
		
		public void clickOnEditAssignmentBtn()
		{
			wait.until(ExpectedConditions.visibilityOf(EditAssignmentBtn));
			wait.until(ExpectedConditions.elementToBeClickable(EditAssignmentBtn));
			EditAssignmentBtn.click();
			
		}
}

		
		

