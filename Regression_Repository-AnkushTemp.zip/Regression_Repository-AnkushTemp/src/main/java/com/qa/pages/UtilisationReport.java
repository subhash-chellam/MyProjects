package com.qa.pages;

import java.io.File;
import java.io.FileReader;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.python.modules.thread.thread;
import org.testng.asserts.SoftAssert;

import com.opencsv.CSVReader;
import com.qa.util.TestBase;

public class UtilisationReport extends TestBase {

//	@FindBy(xpath = "//button[@id = 'exportbtn']")
	@FindBy(xpath = "")
	WebElement exportButton;
	
	@FindBy(xpath = "//*[@id=\"container_download_report\"]//a[contains(text(),'Download Report')]")
	WebElement downloadReport;
	

	@FindBy(xpath = "//*[@id='container_download_report']//h1")
	WebElement downloadHeader;
	
	//*[@id="container_download_report"]//span

	@FindBy(xpath = "//*[@id='container_download_report']//span")
	WebElement downloadBody;
	
    
	@FindBy(xpath = "//input[@id='from_start_date']")
	WebElement fromDate;
	
	@FindBy(xpath = "//input[@id = 'to_start_date']")
	WebElement toDate;

	@FindBy(xpath = "//div[contains(@class, 'datepicker ')]")
	WebElement calendarMainBody;
	
	@FindBy(xpath = "//div[@class = 'datepicker-days']//th[contains(@class, 'datepicker-switch')]")
	WebElement calendarMonthYear;
	
	@FindBy(xpath = "//div[@class = 'datepicker-days']//td[contains(@class, 'active')]")
	WebElement calendarSelectedDay;
	
	@FindBy(xpath = "//div[@class = 'datepicker-months']//th[contains(@class, 'datepicker-switch')]")
	WebElement calendarSelectedYear;
	
	@FindBy(xpath = "//div[@class = 'datepicker-years']//th[@class = 'prev']")
	WebElement calendarRequiredYear;
	
	@FindBy(xpath = "//body[@class]")
    WebElement pageLoad;
    
	@FindBy(xpath = "//a[contains(text(), 'Reports')]")
	WebElement reportLink;
	
	@FindBy(xpath = "//a[text()='Utilization Report']")
	WebElement utilisationReportLink;
	
	@FindBy(xpath = "//div[@id='product_list']//button[@type='button']")
	WebElement productNameFilter;
	
	@FindBy(xpath = "//div[@id='product_list']//button[@type='button']")
	WebElement productNameFilterPlaceHolder;
	
	@FindBy(xpath = "//a[text()='Select all']")
	WebElement selectAllFilter;
	@FindBy(xpath = "//a[text()='Unselect all']")
	WebElement unselectAllFilter;
	
	@FindBy(xpath = "(//input[@placeholder = 'Search'])[1]")
	WebElement productSearch;
	
	@FindBy(xpath = "//button[@id='searchBtn']")
	WebElement buttonSearch;
	
	@FindBy(xpath = "(//button[@name])[2]")
	WebElement buttonSearch2;
	
	@FindBy(xpath = "//*[@id='product_list']//button")
	WebElement productName;
	
	@FindBy(xpath = "//button[@title='Select Organization']")
    WebElement orgfield;
	
	@FindBy(xpath = "//input[@placeholder = 'Search Org ID/Name, SFID']")
	WebElement orgsearch;
	
	
	

	@FindBy(xpath = "//*[@id='include_child_stl']/div/span")
	WebElement showchildcheckbox;
	
	
	

	
	@FindBy(xpath = "//a[contains(text(),'Organization Unit Filters')]")
	WebElement orgUnitFilter;
	
	@FindBy(xpath = "//select[@id = 'filterSelect_2']//following-sibling::div/button")
	WebElement orgLevelFilter;

	@FindBy(xpath = "//select[@id = 'filterSelect_2']//following-sibling::div//a[text() = 'Unselect all']")
	WebElement orgLevelFilterUnSelectAll;

	@FindBy(xpath = "//select[@id = 'filterSelect_2']//following-sibling::div//a[text() = 'Select all']")
	WebElement orgLevelFilterSelectAll;

	@FindBy(xpath = "(//select[@id = 'filterSelect_2']//following-sibling::div)//input[@type= 'text']")
	WebElement orgLevelFilterFilterSearch;
	
	@FindBy(xpath = "//table[@id='subscription_report']")
	WebElement subscription_reportTable;
	
	@FindBy(xpath = "//*[@id='customerform']//span[@data-toggle='tooltip']")
    WebElement tooltips;
	
	@FindBy(xpath = "//*[@role='tooltip']/div[2]")
    WebElement tooltipsMsg;
	
	@FindBy(xpath = "//*[@id=\"clear_search\"]")
	WebElement clear;
	

	@FindBy(xpath = "(//*[@id='selected_org_name'])[2]")
	WebElement orgName;
	
	@FindBy(xpath = "//div[@role = 'document']/div")
	WebElement exportDialogue;
	
	@FindBy(xpath = "//div[@role = 'document']/div//h4")
	WebElement exportDialogueHeading;
	
	@FindBy(xpath = "//div[@role = 'document']/div//span")
	WebElement exportDialogueBody;
	
	@FindBy(xpath = "//div[@role = 'document']//div[3]/button")
	WebElement exportDialogueCloseButton;
	
	@FindBy(xpath = "//*[@id='subscription_report']//th")
	List<WebElement> subscription_reportHeader;
	
	

	
    String val;
	public static String filePath, fileName,checkproduct,OrgCreateDate;
	String downloadPath = System.getProperty("user.dir") + prop.getProperty("downloadPath");
	String reportTable = "";
    String reportHeader = "";
//    String calendarDay = "(//div[@class = 'datepicker-days']//td[@class = 'day'])";
	String calendarMonthOptions = "//div[@class = 'datepicker-months']//td/span[contains(text(), '";
	String calendarYearOptions = "//div[@class = 'datepicker-years']//td/span[contains(text(), '";
	String orgList = "(//ul[@role='listbox']//li[@class= 'active'])";
	
	String unitLevelFilter = "(//select[@id = 'filterSelect_2']//following-sibling::div//ul//label)";
	String calendarDay = "(//div[@class = 'datepicker-days']//td[contains(@class, 'day')][not(contains(@class,'new')) and not(contains(@class,'old')) and text() = '";	
	JavascriptExecutor js = (JavascriptExecutor) driver;
		
	int productNumber=0;
	public static String dateFrom,dateTo;
	public UtilisationReport() 
	{
		PageFactory.initElements(driver, this);
	}
	
//==================
		public void clickExportButton()
		{
			wait.until(ExpectedConditions.visibilityOf(exportButton));
			val = pageLoad.getAttribute("class");
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
			}
			exportButton.click();
		}
		
		public void clickDownloadButton()
		{
			wait.until(ExpectedConditions.visibilityOf(downloadReport));
			val = pageLoad.getAttribute("class");
			
			Assert.assertEquals("Download Report",downloadHeader.getText());
			Assert.assertEquals("The report will download shortly.If it does not start automatically, please use the option below.",downloadBody.getText());
			
			while(val.equalsIgnoreCase("loading_compliance"))
			{
				val = pageLoad.getAttribute("class");
			}
               downloadReport.click();
		}
		
		
		public void validateEmailDialogueBox(String email) {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(exportDialogue));
			String heading = exportDialogueHeading.getText();
			Assert.assertTrue(heading.equals("Notice!"));
			String expectedBody = "A link to this report will be sent to your email address (<email>) when it is ready for download.";
			String body = exportDialogueBody.getText();
			Assert.assertTrue(body.equals(expectedBody.replace("<email>", email)));
		}
		public void verifyDownloadFile()
		{
			try 
			{
				int counter = 0;
				boolean dwnld = false;
				do 
				{
					Thread.sleep(5000);
					dwnld = isFileDownloaded_Ext(downloadPath, ".csv");
					counter = counter +1;
					if(counter==pagload)
						break;
					else
					{
						try {
							Thread.sleep(550);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
				while(dwnld == false);
			} 
			catch (InterruptedException e) 
			{
				System.out.println(e.getMessage());
				Assert.fail(e.getMessage());
				
			}
		}
		
		public void compareDetails()
		{
			try
			{
				JavascriptExecutor js = (JavascriptExecutor)driver;
				String  uiList[][];
				int counter = 0;
				val = js.executeScript("return document.readyState").toString();
				while(!(val.equalsIgnoreCase("complete")))
				{
					val = js.executeScript("return document.readyState").toString();
					counter++;
					if(counter>12)
						Assert.fail("Not able to load page after waiting for 1 minute");
				}
				driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
				WebDriverWait wait = new WebDriverWait(driver, 30);
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(reportTable))));
				List<WebElement> tableRows = driver.findElements(By.xpath(reportTable));
				List<List<String>> list_UI = new ArrayList<>();
				List<List<String>> list_report = new ArrayList<>();
				File file = new File(filePath);
				FileReader filereader = new FileReader(file,StandardCharsets.UTF_8);
				CSVReader csvReader = new CSVReader(filereader); 
				List<String[]> header = csvReader.readAll();
				int rowCount = tableRows.size();
				uiList = new String[rowCount][5];
				String reportDetails[][] = new String[header.size() - 2][5];
				String textValue = null;
				for (int i= 1; i<= rowCount; i++)
				{
					for(int j = 1; j <= 5; j++)
					{
						textValue = driver.findElement(By.xpath("(" + reportTable + ")[" + i + "]/td[" + j + "]")).getText();
						uiList[i-1][j-1] = textValue;
					}
				}
				for (String[] ints : uiList) 
				{
					list_UI.add(Arrays.asList(ints));
				}
				for(int i = 0; i < header.size() - 2; i++)
				{
					String []excel = header.get(i+2);
					for(int j = 0; j <= 4; j++)
					{
						reportDetails[i][j] = excel[j].replace("\"", "").trim();
					}				
				}
				csvReader.close();
				for (String[] ints : reportDetails) {
					list_report.add(Arrays.asList(ints));
				}
				List<List<String>> differences = new ArrayList<>(list_UI);
				differences.removeAll(list_report);
				System.out.println(list_report);
				System.out.println(list_UI);
				Assert.assertTrue(differences.size() == 0);
			}
			catch(Exception e)
			{
				e.printStackTrace();
				Assert.fail(e.getMessage());
			}
		}
		
		public boolean isFileDownloaded_Ext(String dirPath, String ext){
			boolean flag=false;
		    File dir = new File(dirPath);
		    File[] files = dir.listFiles();
		    if (files != null)
		    {
		    	 for (int i = 0; i < files.length; i++) 
		 	    {
		 	    	if(files[i].getName().contains(ext)&& !(files[i].getName().contains(".crdownload"))) 
		 	    	{
		 	    		fileName = files[i].getName();
		 	    		filePath = files[i].getAbsolutePath();
		 	    		filePath = filePath.replace(".crdownload", "");
						flag=true;
		 	    		break;
		 	    	}
		 	    }
		    }
		    Assert.assertTrue("filename formate incorrect",fileName.contains("Utilization_Report_"+TestBase.prop.getProperty("orgName")+"_"+dateFrom+"_"+dateTo+".csv"));
		    return flag;
		}
		
		public void validFromDateValue() {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(fromDate));
			fromDate.click();
			DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd");	
			LocalDate date = LocalDate.parse(OrgCreateDate, dateFormat);
			System.out.println(date.format(dateFormat).toString() + " " + date.getMonth().toString() + " " + Integer.toString(date.getYear()) + " " + Integer.toString(date.getDayOfMonth()));
			pickCalendarDate(date.format(dateFormat).toString(), date.getMonth().toString(), Integer.toString(date.getYear()), Integer.toString(date.getDayOfMonth()));
			String dateActual = fromDate.getAttribute("value");
			System.out.println(dateActual);
			
//			DateTimeFormatter dateFormat2 = DateTimeFormatter.ofPattern("MM/dd/yyyy");	
			
			System.out.println(date.format(dateFormat).toString());
			Assert.assertTrue(dateActual.equals(date.format(dateFormat).toString()));
			dateFrom=dateActual;
		}
		
		
		public void validFromDatePlaceHolder() {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(fromDate));
//			fromDate.click();
//			DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd");	
//			LocalDate date = LocalDate.parse("2021/07/15", dateFormat);
//			System.out.println(date.format(dateFormat).toString() + " " + date.getMonth().toString() + " " + Integer.toString(date.getYear()) + " " + Integer.toString(date.getDayOfMonth()));
//			pickCalendarDate(date.format(dateFormat).toString(), date.getMonth().toString(), Integer.toString(date.getYear()), Integer.toString(date.getDayOfMonth()));
		
			
			String dataActual = driver.findElement(By.xpath("(//*[@id='searchFilters']//label)[1]")).getText();
			System.out.println(dataActual);
			Assert.assertEquals("From Label incorrect", dataActual,"Select Date Range *");

			String dateActual = fromDate.getAttribute("placeholder");
			Assert.assertEquals("From Placeholder incorrect", dateActual,"From");
			
			 dateActual = fromDate.getAttribute("value");
			System.out.println(dateActual);
			Assert.assertTrue(dateActual.equals(""));
//			DateTimeFormatter dateFormat2 = DateTimeFormatter.ofPattern("MM/dd/yyyy");	
//			dateActual
//			System.out.println(date.format(dateFormat).toString());
		
		}
		
		public void validateOrgFieldPlaceHolder() {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(orgfield));
//			fromDate.click();
//			DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd");	
//			LocalDate date = LocalDate.parse("2021/07/15", dateFormat);
//			System.out.println(date.format(dateFormat).toString() + " " + date.getMonth().toString() + " " + Integer.toString(date.getYear()) + " " + Integer.toString(date.getDayOfMonth()));
//			pickCalendarDate(date.format(dateFormat).toString(), date.getMonth().toString(), Integer.toString(date.getYear()), Integer.toString(date.getDayOfMonth()));
			
			
			
					String dataActual = driver.findElement(By.xpath("(//*[@id='searchFilters']//label)[3]")).getText();
					Assert.assertEquals("From Placeholder incorrect", dataActual,"Organization *");
					
			String dateActual = driver.findElement(By.xpath("//*[@id='searchFilters']//button[@title='Select Organization']/span[1]")).getText();
			Assert.assertEquals("From Placeholder incorrect", dateActual,"Select Organization");
			
			orgsearch.getAttribute("placeholder");
			Assert.assertEquals("From Placeholder incorrect", orgsearch.getAttribute("placeholder"),"Search Org ID/Name, SFID");
			 String value = driver.findElement(By.xpath("(//*[@id='org_wrapper']/div[1]/button//span)[1]")).getText();
         	
			Assert.assertEquals("From Placeholder incorrect", value,"Select Organization");
			
			
		}
		
		public void validToDatePlaceHolder() {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(toDate));
//			fromDate.click();
//			DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd");	
//			LocalDate date = LocalDate.parse("2021/07/15", dateFormat);
//			System.out.println(date.format(dateFormat).toString() + " " + date.getMonth().toString() + " " + Integer.toString(date.getYear()) + " " + Integer.toString(date.getDayOfMonth()));
//			pickCalendarDate(date.format(dateFormat).toString(), date.getMonth().toString(), Integer.toString(date.getYear()), Integer.toString(date.getDayOfMonth()));
			String dateActual = toDate.getAttribute("placeholder");
			Assert.assertEquals("From Placeholder incorrect", dateActual,"To Date");
		}
		
		public void validatePlaceHolderProduct()
		{
			try {
				driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
				wait.until(ExpectedConditions.visibilityOf(productNameFilter));
//				productNameFilter.click();
				Thread.sleep(2000);
				
				
				String dateActual = productNameFilterPlaceHolder.getText();
				Assert.assertEquals("From Placeholder incorrect", "Select Product(s)",dateActual);

			
				
			}		
			catch(Exception e)
			{
				Assert.fail(e.getMessage());
				
			}
		}
		
		public void validatePlaceHolderProduct(String placeholder)
		{
			try {
				driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
				wait.until(ExpectedConditions.visibilityOf(productNameFilter));
//				productNameFilter.click();
				Thread.sleep(2000);
				
				if(courseListName.containsKey(placeholder+"Option"))
					placeholder=courseListName.get(placeholder+"Option").toString();

				if(placeholder.equals("(list) selected"))
					placeholder=placeholder.replace("(list)",String.valueOf(productNumber));
				
				String dateActual = productNameFilterPlaceHolder.getText();
				Assert.assertEquals("From Placeholder incorrect", placeholder,dateActual);
//				dateActual.
			
				
			}		
			catch(Exception e)
			{
				Assert.fail(e.getMessage());
				
			}
		}
		
		public void validEndDateValue() {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(toDate));
			toDate.click();
			LocalDate localDate = LocalDate.now();
			LocalDate addedDays = localDate.plusDays(-1);
			DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd");		
			String dateString = addedDays.format(dateFormat);
			LocalDate date = LocalDate.parse(dateString, dateFormat);
			System.out.println(date.format(dateFormat).toString() + " " + date.getMonth().toString() + " " + Integer.toString(date.getYear()) + " " + Integer.toString(date.getDayOfMonth()));
			pickCalendarDate(date.format(dateFormat).toString(), date.getMonth().toString(), Integer.toString(date.getYear()), Integer.toString(date.getDayOfMonth()));
			String dateActual = toDate.getAttribute("value");
			Assert.assertTrue(dateActual.equals(date.format(dateFormat).toString()));
			dateTo=dateActual;
		}
		
		
		public void validEndDateValueasToday() {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(toDate));
			toDate.click();
			LocalDate localDate = LocalDate.now();
			DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd");		
			String dateString = localDate.format(dateFormat);
			LocalDate date = LocalDate.parse(dateString, dateFormat);
			
			System.out.println(date.format(dateFormat).toString() + " " + date.getMonth().toString() + " " + Integer.toString(date.getYear()) + " " + Integer.toString(date.getDayOfMonth()));
			pickCalendarDate_shouldbeDisable(date.format(dateFormat).toString(), date.getMonth().toString(), Integer.toString(date.getYear()), Integer.toString(date.getDayOfMonth()));
//			String dateActual = toDate.getAttribute("value");
//			Assert.assertTrue(dateActual.equals(date.format(dateFormat).toString()));
		}
		
		
		public void validFromDateValuebeforeorgcreatedDate() {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(fromDate));
			fromDate.click();
//			fromDate.sendKeys("dsadsa");
			DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd");	
			LocalDate date = LocalDate.parse(OrgCreateDate, dateFormat);
//			date.
			date=date.plusDays(-1);
			System.out.println(date.format(dateFormat).toString() + " " + date.getMonth().toString() + " " + Integer.toString(date.getYear()) + " " + Integer.toString(date.getDayOfMonth()));
			pickCalendarDate_shouldbeDisable(date.format(dateFormat).toString(), date.getMonth().toString(), Integer.toString(date.getYear()), Integer.toString(date.getDayOfMonth()));
//			String dateActual = fromDate.getAttribute("value");
//			Assert.assertTrue(dateActual.equals(date.format(dateFormat).toString()));
		}
		
		public void validateHeaderfor_subscription_reportHeader (List<String> list) 
		{
			try
			{
			wait.until(ExpectedConditions.visibilityOfAllElements(subscription_reportHeader));
			reuse.validateTable(list, subscription_reportHeader);
			}
			catch(Exception e)
			{
			Assert.fail(e.getMessage());
			}
		}
		public void validFromDateValuebefore() {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(fromDate));
			fromDate.click();
			DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd");	
			LocalDate date = LocalDate.parse("2023/10/18", dateFormat);
			System.out.println(date.format(dateFormat).toString() + " " + date.getMonth().toString() + " " + Integer.toString(date.getYear()) + " " + Integer.toString(date.getDayOfMonth()));
			pickCalendarDate_shouldbeDisable(date.format(dateFormat).toString(), date.getMonth().toString(), Integer.toString(date.getYear()), Integer.toString(date.getDayOfMonth()));
//			String dateActual = fromDate.getAttribute("value");
//			Assert.assertTrue(dateActual.equals(date.format(dateFormat).toString()));
		}
		public void pickCalendarDate(String date, String month, String year, String day) {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(calendarMainBody));
			wait.until(ExpectedConditions.visibilityOf(calendarMonthYear));
			month = month.toLowerCase();
			if(month.length() > 3) {
				month = month.substring(0, 3);
			}
			month = month.replace(month.split("")[0], month.split("")[0].toUpperCase());
			String currentMonth = calendarMonthYear.getText().split(" ")[0];
			String currentYear = calendarMonthYear.getText().split(" ")[1];
			
//			String currentDay = day;
			if(currentYear.equals(year)) {
				if(currentMonth.contains(month)) {
					driver.findElement(By.xpath(calendarDay + "" + day + "'])")).click();
//					driver.findElement(By.xpath(calendarDay + "" + day + "]")).click();
					
//					String ifSelected = driver.findElement(By.xpath(calendarDay + "" + day + "'])")).getAttribute("class").trim().toLowerCase();
//					Assert.assertTrue(ifSelected.contains("active"));
				}
				else {
					calendarMonthYear.click();
					WebElement requiredMonth = driver.findElement(By.xpath(calendarMonthOptions + month + "')]"));
					requiredMonth.click();
					currentMonth = calendarMonthYear.getText().split(" ")[0];
					Assert.assertTrue(currentMonth.contains(month));
//					driver.findElement(By.xpath(calendarDay + "[" + day + "]")).click();
					
					driver.findElement(By.xpath(calendarDay + "" + day + "'])")).click();
//					
				}
			}
			else {
				calendarMonthYear.click();
				calendarSelectedYear.click();
				int yearInt = Integer.parseInt(year);
				if((2009 <= yearInt) && (yearInt <= 2018)){
					calendarRequiredYear.click();
				}
				WebElement requiredYear = driver.findElement(By.xpath(calendarYearOptions + year + "')]"));
				requiredYear.click();
				WebElement requiredMonth = driver.findElement(By.xpath(calendarMonthOptions + month + "')]"));
				requiredMonth.click();
				driver.findElement(By.xpath(calendarDay + "" + day + "'])")).click();
			}
		}
		
		public void navigateUtilisationReport()
		{
			JavascriptExecutor js = (JavascriptExecutor)driver;
			
			try
			{
			wait.until(ExpectedConditions.visibilityOf(reportLink));
			wait.until(ExpectedConditions.elementToBeClickable(reportLink));
			js.executeScript("window.scrollBy(0,-250)", "");
			
			reportLink.click();
			wait.until(ExpectedConditions.visibilityOf(utilisationReportLink));
			utilisationReportLink.click();
			String pageValue = js.executeScript("return document.readyState").toString();
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
			}
			
			 driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			  	
				if(!driver.getCurrentUrl().contains("utilization_report"))
				{
					  js.executeScript("arguments[0].click();", reportLink);
						
					wait.until(ExpectedConditions.visibilityOf(utilisationReportLink));
					utilisationReportLink.click();
					

				}
				
				
				
			}
			catch(Exception e)
			{
				  js.executeScript("arguments[0].click();", reportLink);
				  wait.until(ExpectedConditions.visibilityOf(utilisationReportLink));
				  utilisationReportLink.click();
					
			}
		}
		
		public void selectAllProducts()
		{
			try {
				driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
				wait.until(ExpectedConditions.visibilityOf(productNameFilter));
				productNameFilter.click();
				Thread.sleep(2000);
				wait.until(ExpectedConditions.visibilityOf(selectAllFilter));
				Thread.sleep(2000);
				selectAllFilter.click();
				wait.until(ExpectedConditions.visibilityOf(buttonSearch));
				Thread.sleep(2000);
				wait.until(ExpectedConditions.visibilityOf(unselectAllFilter));
				
				List<WebElement> options = driver.findElements(By.xpath("//div[@id='product_list']//ul//li//label"));
				
				productNumber=options.size();
				productName.click();
				Thread.sleep(3000);
			
				
			}		
			catch(Exception e)
			{
				Assert.fail(e.getMessage());
				
			}
		}
		
		
		public void selectProductpartial(String product)
		{
			try {
				
				if(courseListName.containsKey(product+"Option"))
					product=courseListName.get(product+"Option").toString();
		
				driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
				wait.until(ExpectedConditions.visibilityOf(productNameFilter));
				productNameFilter.click();
				Thread.sleep(2000);
				wait.until(ExpectedConditions.visibilityOf(productSearch));
				Thread.sleep(2000);
				productSearch.sendKeys(product.substring(0,product.length()-4));;
//				.substring(0,OrganizationHome.exceptionid.length()-2)
				
//				List<WebElement> options = driver.findElements(By.tagName("li"));
				List<WebElement> options = driver.findElements(By.xpath("//div[@id='product_list']//ul//li//label"));
				
				int i=0;
				boolean flg=false;
				for (WebElement option : options)
				{
					String productname=	option.getText();
					if(productname.equals(product))
					{
						option.click();
						flg=true;
						break;
					}
					i++;
				}
				wait.until(ExpectedConditions.visibilityOf(buttonSearch));
				Thread.sleep(2000);
				productNameFilter.click();
				Thread.sleep(3000);
				Assert.assertTrue("Product list is not missing"+product ,flg);
				
				
			}		
			catch(Exception e)
			{
				Assert.fail(e.getMessage());
				
			}
		}
		public void selectProduct(String product)
		{
			try {
				
				if(courseListName.containsKey(product+"Option"))
					product=courseListName.get(product+"Option").toString();
		
				driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
				wait.until(ExpectedConditions.visibilityOf(productNameFilter));
				productNameFilter.click();
				Thread.sleep(2000);
				wait.until(ExpectedConditions.visibilityOf(productSearch));
				Thread.sleep(2000);
				productSearch.sendKeys(product);;
				
//				List<WebElement> options = driver.findElements(By.tagName("li"));
				List<WebElement> options = driver.findElements(By.xpath("//div[@id='product_list']//ul//li//label"));
				
				int i=0;
				boolean flg=false;
				for (WebElement option : options)
				{
					String productname=	option.getText();
					if(productname.equals(product))
					{
						option.click();
						flg=true;
						break;
					}
					i++;
				}
				wait.until(ExpectedConditions.visibilityOf(buttonSearch));
				Thread.sleep(2000);
				productNameFilter.click();
				Thread.sleep(3000);
				Assert.assertTrue("Product list is not missing"+product ,flg);
				
				
			}		
			catch(Exception e)
			{
				Assert.fail(e.getMessage());
				
			}
		}
		
		public void selectProductwithout(String product)
		{
			try {
				
				if(courseListName.containsKey(product+"Option"))
					product=courseListName.get(product+"Option").toString();
		
				driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
				wait.until(ExpectedConditions.visibilityOf(productNameFilter));
				productNameFilter.click();
				Thread.sleep(2000);
				wait.until(ExpectedConditions.visibilityOf(productSearch));
				Thread.sleep(2000);
//				productSearch.sendKeys(product);;
				
//				List<WebElement> options = driver.findElements(By.tagName("li"));
				List<WebElement> options = driver.findElements(By.xpath("//div[@id='product_list']//ul//li//label"));
				
				int i=0;
				boolean flg=false;
				for (WebElement option : options)
				{
					String productname=	option.getText();
					if(productname.equals(product))
					{
						option.click();
						flg=true;
						break;
					}
					i++;
				}
				wait.until(ExpectedConditions.visibilityOf(buttonSearch));
				Thread.sleep(2000);
				productNameFilter.click();
				Thread.sleep(3000);
				Assert.assertTrue("Product list is not missing"+product ,flg);
				
				
			}		
			catch(Exception e)
			{
				Assert.fail(e.getMessage());
				
			}
		}
		
		
		
		public void BlockedProduct()
		{
			try {
				
		
				driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
				wait.until(ExpectedConditions.visibilityOf(productNameFilter));
				productNameFilter.click();
				Thread.sleep(2000);
				wait.until(ExpectedConditions.visibilityOf(productSearch));
				Thread.sleep(2000);
				
				
	        	
				productSearch.sendKeys(dataMap.get(OrganizationHome.exceptionid+"BlockedproductName"));;
	
				String value = driver.findElement(By.xpath("//div[@id='searchFilters']//ul[@role='listbox' and @class='dropdown-menu inner']//li[@class='no-results']")).getText();
//	            
	        	Assert.assertEquals(value, "No results matched \""+dataMap.get(OrganizationHome.exceptionid+"BlockedproductName")+"\"");

				wait.until(ExpectedConditions.visibilityOf(buttonSearch));
				Thread.sleep(2000);
				productNameFilter.click();
				Thread.sleep(3000);
				
				
			}		
			catch(Exception e)
			{
				Assert.fail(e.getMessage());
				
			}
		}
		
		public void getAllProducts()
		{
			try {
				driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
				wait.until(ExpectedConditions.visibilityOf(productNameFilter));
				productNameFilter.click();
				Thread.sleep(2000);
				wait.until(ExpectedConditions.visibilityOf(selectAllFilter));
				Thread.sleep(2000);
				
				int size=Integer.valueOf( dataMap.get(OrganizationHome.exceptionid+"productCount"))  ;
				
				String[] uiList = new String[size];
				
				List<WebElement> options = driver.findElements(By.xpath("//div[@id='product_list']//ul//li//label"));
				int i=0;
				for (WebElement option : options)
				{
					uiList[i]=	option.getText();
					i++;
				}
				Boolean flg=false;
				for(int k=0;k<size;k++)
				{
					
				for(int j=0;j<uiList.length;j++)
				{
					String productName=dataMap.get(OrganizationHome.exceptionid+"product"+j+"productName")  ;
					String productStatus=dataMap.get(OrganizationHome.exceptionid+"product"+j+"productStatus")  ;
					if(productStatus.equals("Active"))
					{
					if(uiList[k].equals(productName))
					{
						flg=true;
						break;
					}
					}
					else
					{
						flg=true;
						break;
						
					}
				}
				Assert.assertTrue("Product list is not missing"+uiList[k] ,flg);
				}
				Thread.sleep(2000);
				
				
			}		
			catch(Exception e)
			{
				Assert.fail(e.getMessage());
				
			}
		}
		
		
		public void getAllProducts(String productList)
		{
			try {
				driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
				Thread.sleep(4000);
				
				wait.until(ExpectedConditions.visibilityOf(productNameFilter));
				productNameFilter.click();
				Thread.sleep(2000);
				wait.until(ExpectedConditions.visibilityOf(selectAllFilter));
				Thread.sleep(2000);
				
				int size=productList.split(",").length  ;
				
				String[] uiList = new String[size];
				String[] dataList = new String[size];
		
				
				List<WebElement> options = driver.findElements(By.xpath("//div[@id='product_list']//ul//li//label"));
						System.out.println(options.size());
				int i=0;
				for (WebElement option : options)
				{
					uiList[i]=	option.getText();
					i++;
				}
				i=0;
				for (String option : productList.split(","))
				{
					if(courseListName.containsKey(option+"Option"))
						option=courseListName.get(option+"Option").toString();

                 System.out.println(option);
					dataList[i]=	option;
					i++;
				}
				Boolean flg=false;
				for(int k=0;k<size;k++)
				{
					
				for(int j=0;j<uiList.length;j++)
				{
					if(uiList[k].equals(dataList[j]))
					{
						flg=true;
						break;
					}
				
				}
				Assert.assertTrue("Product list is not missing"+uiList[k] ,flg);
				}
				Thread.sleep(2000);
				productNameFilter.click();
				
				
			}		
			catch(Exception e)
			{
//				e.print
//				e.printStackTrace();
				Assert.fail(e.getMessage());
				
			}
		}
		
		
		 public void clickOnOrganizationdropDown() throws Exception
		 {
			    Thread.sleep(2000);
	            WebDriverWait wait = new WebDriverWait(driver, 30);
	            wait.until(ExpectedConditions.visibilityOf(orgfield));
	            orgfield.click();    
	            wait.until(ExpectedConditions.visibilityOf(orgsearch));
	            orgsearch.click();
		 }
		 
		 public void getOrgCreateDate() throws Exception
		 {
			    Thread.sleep(2000);
	            WebDriverWait wait = new WebDriverWait(driver, 30);
	            wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='tablelisting']//td[text()='"+TestBase.prop.getProperty("orgName")+"']/following::td[4]"))));
	            OrgCreateDate=    driver.findElement(By.xpath("//*[@id='tablelisting']//td[text()='"+TestBase.prop.getProperty("orgName")+"']/following::td[4]")).getText();
		 
	            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd");
	            Date date1 = simpleDateFormat.parse(OrgCreateDate);
	            Date date2 = simpleDateFormat.parse("2023/10/19");
	     
	            System.out.println(date1.before(date2));
	            
	            if(date1.before(date2))
	            {
	            	OrgCreateDate="2023/10/19";
	            }
//	            System.out.println(date1.equals(date2));
//	            System.out.println(date1.after(date2));
		 }	
		

		 public void clickOnOrganizationdropDownddisabled() throws Exception
		 {
			    Thread.sleep(2000);
	            WebDriverWait wait = new WebDriverWait(driver, 30);
//	            wait.until(ExpectedConditions.visibilityOf(orgfield));
//	            System.out.println(orgfield.);
//	            wait.until(ExpectedConditions.invisibilityOf(orgfield));
	           
	            try
	            {
	            	
	            	 wait.until(ExpectedConditions.visibilityOf(orgfield));
	  	           Assert.fail("Organization dropDownd");
	            }
	            catch(Exception e)
	            {
	            	
	            }
//	            String dateActual = driver.findElement(By.xpath("//*[@id='searchFilters']//button[@title='Select Organization']/span[1]")).getText();
//				Assert.assertEquals("From Placeholder incorrect", dateActual,TestBase.prop.get("orgName").toString());
//				Assert.assertTrue("Button is not disabled",orgfield.getClass().toString().contains("disabled"));
//	            cxc
		 }
		 
		 public void shouldNotdisplayOrgName() throws Exception
		 {
			    Thread.sleep(2000);
	            WebDriverWait wait = new WebDriverWait(driver, 30);
//	            wait.until(ExpectedConditions.visibilityOf(orgfield));
	            
	            
	            String dateActual = driver.findElement(By.xpath("//*[@id='searchFilters']//button[@title='Select Organization']/span[1]")).getText();
				Assert.assertEquals("From Placeholder incorrect", dateActual,TestBase.prop.get("orgName").toString());
				Assert.assertTrue("Button is not disabled",orgfield.getClass().toString().contains("disabled"));
//	            cxc
		 }
		
		 public void OrganizationNamefield() throws Exception
		 {
			    Thread.sleep(2000);
	            WebDriverWait wait = new WebDriverWait(driver, 30);
	            wait.until(ExpectedConditions.visibilityOf(orgName));
	              
	            String org_Name = orgName.getAttribute("value");
				Assert.assertEquals("From Placeholder incorrect", org_Name,TestBase.prop.get("orgName").toString());
				Assert.assertTrue("Button is not disabled",!(orgName.getAttribute("disabled").equals("null")));
//	            cxc
		 }
		 
		 
		 public void organizationUnitFiltersdisabled() throws Exception
		 {
			    Thread.sleep(2000);
	            WebDriverWait wait = new WebDriverWait(driver, 30);
	            wait.until(ExpectedConditions.visibilityOf(orgUnitFilter));
	           
	            try
	            {
	            	 orgUnitFilter.click();
	            	 Assert.fail("Organization Unit Filters should be disabled");
	            }
	            catch(ElementClickInterceptedException e)
	            {
	            	
	            }
		 }
		 
		 public void clickorganizationUnitFilters() throws Exception
		 {
			    Thread.sleep(2000);
	            WebDriverWait wait = new WebDriverWait(driver, 30);
	            wait.until(ExpectedConditions.visibilityOf(orgUnitFilter));
	           
	            	 orgUnitFilter.click();
	            
		 }
		
		
		public void clickOnsearchbutton() throws InterruptedException {
		
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(buttonSearch));
			buttonSearch.click();
			Thread.sleep(4000);
		}
		
		public void clickOn_searchbutton() throws InterruptedException {
			
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(buttonSearch2));
			buttonSearch2.click();
			Thread.sleep(4000);
		}
		 public void selectSalesForceIDByName()
		    {
		        try
		        {
		            val = js.executeScript("return document.readyState").toString();

		            WebDriverWait wait = new WebDriverWait(driver, 30);
			           
		            
//		            orgbtn
		            orgsearch.sendKeys(OrganizationDetails.SalesforceName);
		            Thread.sleep(5000);
		            
		            List<WebElement> options = driver.findElements(By.xpath(orgList));
		            int  counter = 0;
		            while(!(options.size() == 1))
		            {
		            	options = driver.findElements(By.xpath(orgList + "[@class= 'active']"));
		            	Thread.sleep(5000);
		            	counter++;
		            	if(counter>12)
		            		Assert.fail("Not able to search product after waiting for 1 minute");
		            }
		            
		            for(int i = 1; i <= options.size(); i++)
		            {
		            	String element = "(" + orgList + "[@class= 'active'])[" + i + "]";
		            	String value = driver.findElement(By.xpath(element)).getText();
		            	if(value.toLowerCase().trim().contains(OrganizationDetails.SalesforceName.toLowerCase().trim()))
		            	{
		            		Thread.sleep(2000);
		            		System.out.println(driver.findElement(By.xpath(element)).getText());
		            		System.err.println(OrganizationHome.exceptionid+"-"+OrganizationHome.exceptionorg+"\n"+OrganizationDetails.SalesforceName.trim());
		            		Assert.assertEquals(driver.findElement(By.xpath(element)).getText(), OrganizationHome.exceptionid+"-"+OrganizationHome.exceptionorg+"\n"+OrganizationDetails.SalesforceName.trim());
		      	           
		            		driver.findElement(By.xpath(element)).click();
		            		break;
		            	}
		            }
		            
		            counter = 0;
		            while(val.contains("loading_consumption") )
		            {
		            	val = pageLoad.getAttribute("class");
		            	Thread.sleep(5000);
		            	counter++;
		            	if(counter>12)
		            		Assert.fail("Not able to load page after waiting for 1 minute");
		            }
		            Thread.sleep(5000);
//		            consumptionReport.click();
		        
  String value = driver.findElement(By.xpath("(//*[@id='org_wrapper']/div[1]/button//span)[2]")).getText();
	            	
		            Assert.assertEquals(OrganizationHome.exceptionid+"-"+OrganizationHome.exceptionorg, value);
	           
	           
		        }
		        catch (Exception e)
		        {
		        	Assert.fail(e.getMessage());
		        }
		        
		    }
		 

		 public void selectSalesForceIDByName(String text)
		    {
		        try
		        {
		            val = js.executeScript("return document.readyState").toString();

		            WebDriverWait wait = new WebDriverWait(driver, 30);
			           
		            orgsearch.sendKeys(text);
		            Thread.sleep(5000);
		            
		            List<WebElement> options = driver.findElements(By.xpath(orgList));
		            int  counter = 0;
		            while(!(options.size() == 1))
		            {
		            	options = driver.findElements(By.xpath(orgList + "[@class= 'active']"));
		            	Thread.sleep(5000);
		            	counter++;
		            	if(counter>12)
		            		Assert.fail("Not able to search product after waiting for 1 minute");
		            }
		            
		            for(int i = 1; i <= options.size(); i++)
		            {
		            	String element = "(" + orgList + "[@class= 'active'])[" + i + "]";
		            	String value = driver.findElement(By.xpath(element)).getText();
			            	System.out.println(value);
		            	if(value.toLowerCase().trim().contains(OrganizationDetails.SalesforceName.toLowerCase().trim()))
		            	{
		            		Thread.sleep(4000);
		            		System.out.println(driver.findElement(By.xpath(element)).getText());
		            		System.err.println(OrganizationHome.exceptionid+"-"+OrganizationHome.exceptionorg+"\n"+OrganizationDetails.SalesforceName.trim());
		            		Assert.assertEquals(driver.findElement(By.xpath(element)).getText(), OrganizationHome.exceptionid+"-"+OrganizationHome.exceptionorg+"\n"+OrganizationDetails.SalesforceName.trim());
		      	           System.out.println(element);
		      	           driver.findElement(By.xpath(element)).click();
		            		break;
		            	}
		            }
		            
		            counter = 0;
		            while(val.contains("loading_consumption") )
		            {
		            	val = pageLoad.getAttribute("class");
		            	Thread.sleep(5000);
		            	counter++;
		            	if(counter>12)
		            		Assert.fail("Not able to load page after waiting for 1 minute");
		            }
		            Thread.sleep(5000);
//		            consumptionReport.click();
		              String value = driver.findElement(By.xpath("(//*[@id='org_wrapper']/div[1]/button//span)[2]")).getText();
		            	
			            Assert.assertEquals(OrganizationHome.exceptionid+"-"+OrganizationHome.exceptionorg, value);
		           	
	           
		        }
		        catch (Exception e)
		        {
		        	Assert.fail(e.getMessage());
		        }
		        
		    }
		 public void selectOrgID()
		    {
		        try
		        {
		            val = js.executeScript("return document.readyState").toString();

		            WebDriverWait wait = new WebDriverWait(driver, 30);
			           
//		            exceptionorg=resultOrgName.getText();
//		    		exceptionid=resultOrgID.getText();
		            orgsearch.sendKeys(OrganizationHome.exceptionid);
		            Thread.sleep(5000);
		            
		            List<WebElement> options = driver.findElements(By.xpath(orgList));
		            int  counter = 0;
		            while(!(options.size() == 1))
		            {
		            	options = driver.findElements(By.xpath(orgList + "[@class= 'active']"));
		            	Thread.sleep(5000);
		            	counter++;
		            	if(counter>12)
		            		Assert.fail("Not able to search product after waiting for 1 minute");
		            }
		            
		            for(int i = 1; i <= options.size(); i++)
		            {
		            	String element = "(" + orgList + "[@class= 'active'])[" + i + "]";
		            	String value = driver.findElement(By.xpath(element)).getText();
		            	if(value.toLowerCase().trim().contains(OrganizationHome.exceptionid.toLowerCase().trim()))
		            	{
		            		Thread.sleep(2000);
		            		System.out.println(driver.findElement(By.xpath(element)).getText());
		            		System.err.println(OrganizationHome.exceptionid+"-"+OrganizationHome.exceptionorg+"\n"+OrganizationDetails.SalesforceName.trim());
		            		Assert.assertEquals(driver.findElement(By.xpath(element)).getText(), OrganizationHome.exceptionid+"-"+OrganizationHome.exceptionorg+"\n"+OrganizationDetails.SalesforceName.trim());
		      	           
		            		driver.findElement(By.xpath(element)).click();
		            		break;
		            	}
		            }
		            
		            counter = 0;
		            while(val.contains("loading_consumption") )
		            {
		            	val = pageLoad.getAttribute("class");
		            	Thread.sleep(5000);
		            	counter++;
		            	if(counter>12)
		            		Assert.fail("Not able to load page after waiting for 1 minute");
		            }
		            Thread.sleep(5000);
//		            consumptionReport.click();
		            
		           
  String value = driver.findElement(By.xpath("(//*[@id='org_wrapper']/div[1]/button//span)[2]")).getText();
	            	
		            Assert.assertEquals(OrganizationHome.exceptionid+"-"+OrganizationHome.exceptionorg, value);
	           
		        }
		        catch (Exception e)
		        {
		        	e.printStackTrace();
		        	Assert.fail(e.getMessage());
		        }
		        
		    }
		 
		 public void selectOrgID(String org)
		    {
		        try
		        {
		            val = js.executeScript("return document.readyState").toString();

		            WebDriverWait wait = new WebDriverWait(driver, 30);
			           
//		            exceptionorg=resultOrgName.getText();
//		    		exceptionid=resultOrgID.getText();
		            orgsearch.sendKeys(OrganizationHome.exceptionid);
		            Thread.sleep(5000);
		            
		            List<WebElement> options = driver.findElements(By.xpath(orgList));
		            int  counter = 0;
		            while(!(options.size() == 1))
		            {
		            	options = driver.findElements(By.xpath(orgList + "[@class= 'active']"));
		            	Thread.sleep(5000);
		            	counter++;
		            	if(counter>12)
		            		Assert.fail("Not able to search product after waiting for 1 minute");
		            }
		            
		            for(int i = 1; i <= options.size(); i++)
		            {
		            	String element = "(" + orgList + "[@class= 'active'])[" + i + "]";
		            	String value = driver.findElement(By.xpath(element)).getText();
		            	if(value.toLowerCase().trim().contains(OrganizationHome.exceptionid.toLowerCase().trim()))
		            	{
		            		Thread.sleep(2000);
		            		System.out.println(driver.findElement(By.xpath(element)).getText());
		            		System.err.println(OrganizationHome.exceptionid+"-"+OrganizationHome.exceptionorg+"\n"+OrganizationDetails.SalesforceName.trim());
		            		Assert.assertEquals(driver.findElement(By.xpath(element)).getText(), OrganizationHome.exceptionid+"-"+OrganizationHome.exceptionorg+"\n"+OrganizationDetails.SalesforceName.trim());
		      	           
		            		driver.findElement(By.xpath(element)).click();
		            		break;
		            	}
		            }
		            
		            counter = 0;
		            while(val.contains("loading_consumption") )
		            {
		            	val = pageLoad.getAttribute("class");
		            	Thread.sleep(5000);
		            	counter++;
		            	if(counter>12)
		            		Assert.fail("Not able to load page after waiting for 1 minute");
		            }
		            Thread.sleep(5000);
//		            consumptionReport.click();
		            
		            
  String value = driver.findElement(By.xpath("(//*[@id='org_wrapper']/div[1]/button//span)[2]")).getText();
	            	
		            Assert.assertEquals(OrganizationHome.exceptionid+"-"+OrganizationHome.exceptionorg, value);
	           
		        }
		        catch (Exception e)
		        {
		        	Assert.fail(e.getMessage());
		        }
		        
		    }
		 public void selectOrgName(String text)
		    {
		        try
		        {
		            val = js.executeScript("return document.readyState").toString();

		            WebDriverWait wait = new WebDriverWait(driver, 30);
			           
		            orgsearch.sendKeys(text);
		            Thread.sleep(5000);
		            
		            List<WebElement> options = driver.findElements(By.xpath(orgList));
		            int  counter = 0;
		            while(!(options.size() == 1))
		            {
		            	options = driver.findElements(By.xpath(orgList + "[@class= 'active']"));
		            	Thread.sleep(5000);
		            	counter++;
		            	if(counter>12)
		            		Assert.fail("Not able to search product after waiting for 1 minute");
		            }
		            
		            for(int i = 1; i <= options.size(); i++)
		            {
//		            	String element = "(" + orgList + "[" + i + "]";
		             	String element = "(" + orgList + "[@class= 'active'])[" + i + "]";
				           
		            	String value = driver.findElement(By.xpath(element)).getText();
		            	if(value.toLowerCase().trim().contains(OrganizationHome.exceptionorg.toLowerCase().trim()))
		            	{
		            		Thread.sleep(2000);
		            		System.out.println(driver.findElement(By.xpath(element)).getText());
		            		System.err.println(OrganizationHome.exceptionid+"-"+OrganizationHome.exceptionorg+"\n"+OrganizationDetails.SalesforceName.trim());
		            		Assert.assertEquals(driver.findElement(By.xpath(element)).getText(), OrganizationHome.exceptionid+"-"+OrganizationHome.exceptionorg+"\n"+OrganizationDetails.SalesforceName.trim());
		      	           
		            		driver.findElement(By.xpath(element)).click();
		            		break;
		            	}
		            }
		            
		            counter = 0;
		            while(val.contains("loading_consumption") )
		            {
		            	val = pageLoad.getAttribute("class");
		            	Thread.sleep(5000);
		            	counter++;
		            	if(counter>12)
		            		Assert.fail("Not able to load page after waiting for 1 minute");
		            }
		            Thread.sleep(5000);
		            
  String value = driver.findElement(By.xpath("(//*[@id='org_wrapper']/div[1]/button//span)[2]")).getText();
	            	
		            Assert.assertEquals(OrganizationHome.exceptionid+"-"+OrganizationHome.exceptionorg, value);
	           
		        }
		        catch (Exception e)
		        {
		        	e.printStackTrace();
		        	Assert.fail(e.getMessage());
		        }
		        
		    }
		 
		 public void selectOrgNamenotfound()
		    {
		        try
		        {
		            val = js.executeScript("return document.readyState").toString();

		            WebDriverWait wait = new WebDriverWait(driver, 30);
			           
		            orgsearch.sendKeys(TestBase.prop.get("orgName").toString());
		            Thread.sleep(5000);
		            
		            List<WebElement> options = driver.findElements(By.xpath(orgList));
		            int  counter = 0;
		            while(!(options.size() == 0))
		            {
		            	options = driver.findElements(By.xpath(orgList + "[@class= 'active']"));
		            	Thread.sleep(5000);
		            	counter++;
		            	if(counter>12)
		            		Assert.fail("Not able to search product after waiting for 1 minute");
		            }
		            System.out.println(options.size());
		            
		          
		        	String value = driver.findElement(By.xpath("//div[@id='searchFilters']//ul[@role='listbox' and @class='dropdown-menu inner']//li[@class='no-results']")).getText();
//		            
		        	Assert.assertEquals(value, "No results matched \""+TestBase.prop.getProperty("orgName")+"\"");
//		            for(int i = 1; i <= options.size(); i++)
//		            {
//		            	String element = "" + orgList + "[" + i + "]";
//		            	String value = driver.findElement(By.xpath(element)).getText();
//		            	System.out.println(value);
//		            	if(value.toLowerCase().trim().equalsIgnoreCase(OrganizationHome.exceptionorg.toLowerCase().trim()))
//		            	{
//		            		Thread.sleep(2000);
//		            		driver.findElement(By.xpath(element)).click();
//		            		Assert.fail("Deleted or inactivated or blocked org should not display");
//		            		break;
//		            	}
//		            }
		            
		            counter = 0;
		            while(val.contains("loading_consumption") )
		            {
		            	val = pageLoad.getAttribute("class");
		            	Thread.sleep(5000);
		            	counter++;
		            	if(counter>12)
		            		Assert.fail("Not able to load page after waiting for 1 minute");
		            }
		            Thread.sleep(5000);
		            
	           
		        }
		        catch (Exception e)
		        {
		        	Assert.fail(e.getMessage());
		        }
		        
		    }
		 public void selectOrgName()
		    {
		        try
		        {
		            val = js.executeScript("return document.readyState").toString();

		            WebDriverWait wait = new WebDriverWait(driver, 30);
			           
		            orgsearch.sendKeys(OrganizationHome.exceptionorg);
		            Thread.sleep(5000);
		            
		            List<WebElement> options = driver.findElements(By.xpath(orgList));
		            int  counter = 0;
		            while(!(options.size() == 1))
		            {
		            	options = driver.findElements(By.xpath(orgList + "[@class= 'active']"));
		            	Thread.sleep(5000);
		            	counter++;
		            	if(counter>12)
		            		Assert.fail("Not able to search product after waiting for 1 minute");
		            }
		            
		            for(int i = 1; i <= options.size(); i++)
		            {
		            	String element = "(" + orgList + "[@class= 'active'])[" + i + "]";
		            	String value = driver.findElement(By.xpath(element)).getText();
		            	if(value.toLowerCase().trim().contains(OrganizationHome.exceptionorg.toLowerCase().trim()))
		            	{
		            		Thread.sleep(2000);
		            		System.out.println(driver.findElement(By.xpath(element)).getText());
		            		System.err.println(OrganizationHome.exceptionid+"-"+OrganizationHome.exceptionorg+"\n"+OrganizationDetails.SalesforceName.trim());
		            		Assert.assertEquals(driver.findElement(By.xpath(element)).getText(), OrganizationHome.exceptionid+"-"+OrganizationHome.exceptionorg+"\n"+OrganizationDetails.SalesforceName.trim());
		      	           
		            		driver.findElement(By.xpath(element)).click();
		            		
		            		break;
		            	}
		            }
		            
		            counter = 0;
		            while(val.contains("loading_consumption") )
		            {
		            	val = pageLoad.getAttribute("class");
		            	Thread.sleep(5000);
		            	counter++;
		            	if(counter>12)
		            		Assert.fail("Not able to load page after waiting for 1 minute");
		            }
		            Thread.sleep(5000);
		            
		            String value = driver.findElement(By.xpath("(//*[@id='org_wrapper']/div[1]/button//span)[2]")).getText();
	            	
		            Assert.assertEquals(OrganizationHome.exceptionid+"-"+OrganizationHome.exceptionorg, value);
	           
		        }
		        catch (Exception e)
		        {
		        	Assert.fail(e.getMessage());
		        }
		        
		    }
		 
		 public void clickorgUnitFilter()
			{
				try
				{
					Thread.sleep(5000);
					driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
					WebDriverWait wait = new WebDriverWait(driver, 30);
					wait.until(ExpectedConditions.visibilityOf(orgUnitFilter));
					JavascriptExecutor executor = (JavascriptExecutor)driver;
					executor.executeScript("arguments[0].click();", orgUnitFilter);
					Thread.sleep(2000);
				}
				catch(Exception e)
				{
					
				Assert.fail(e.getMessage());	
				}
			}
		 
		 public void selectSingleOrgLevelFilter(String courseName)
			{
				WebDriverWait wait = new WebDriverWait(driver, 30);
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitLevelFilter + "[1]"))));
				List<WebElement> statusList = driver.findElements(By.xpath(unitLevelFilter));
				for(int i = 1; i <= statusList.size(); i++)
				{
					WebElement elem = driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]"));
					boolean flag = elem.isSelected();
					if(flag == true)
						driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]")).click();
				}
				driver.findElement(By.xpath(unitLevelFilter + "//input[contains(@title,'" + courseName + "')]")).click();
			}

			public void selectMultiOrgLevelFilter()
			{
				WebDriverWait wait = new WebDriverWait(driver, 30);
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(unitLevelFilter + "[1]"))));
				List<WebElement> statusList = driver.findElements(By.xpath(unitLevelFilter));
				boolean flg=false;
				for(int i = 1; i <= statusList.size(); i++)
				{
					WebElement elem = driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]"));
					boolean flag = elem.isSelected();
					if(flag == false) {
						driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]")).click();
						flg=true;
						break;
					}
				}
				
				Assert.assertTrue("Error setting Multi Org Level Filter", flg);

			}

			public void unSelectAllOrgLevelFilter()
			{
				try
				{
					val = pageLoad.getAttribute("class");
					int counter = 0;
					while(val.equalsIgnoreCase("loading_compliance"))
					{
						val = pageLoad.getAttribute("class");
						Thread.sleep(5000);
						counter++;
						if(counter>12)
							Assert.fail("Not able to load page after waiting for 1 minute");
					}
					WebDriverWait wait = new WebDriverWait(driver, 30);
					List<WebElement> statusList = driver.findElements(By.xpath(unitLevelFilter));
					for(int i = 1; i <= statusList.size(); i++)
					{
						WebElement elem = driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]"));
						boolean flag = elem.isSelected();
						if(flag == false)
							driver.findElement(By.xpath("(" + unitLevelFilter + "/input)[" + i + "]")).click();
					}
					wait.until(ExpectedConditions.visibilityOf(orgLevelFilterUnSelectAll));
					orgLevelFilterUnSelectAll.click();
				}
				catch(Exception e)
				{
					Assert.fail(e.getMessage());
				}
			}

			public void selectAllOrgLevelFilter()
			{
				try
				{
					val = pageLoad.getAttribute("class");
					int counter = 0;
					while(val.equalsIgnoreCase("loading_compliance"))
					{
						val = pageLoad.getAttribute("class");
						Thread.sleep(5000);
						counter++;
						if(counter>12)
							Assert.fail("Not able to load page after waiting for 1 minute");
					}
					WebDriverWait wait = new WebDriverWait(driver, 30);
					wait.until(ExpectedConditions.visibilityOf(orgLevelFilterSelectAll));
					orgLevelFilterSelectAll.click();
				}
				catch(Exception e)
				{
					Assert.fail(e.getMessage());
				}
			}

			public void searchOrgLevelFilter(String courseName)
			{
				try {
					WebDriverWait wait = new WebDriverWait(driver, 30);
					wait.until(ExpectedConditions.visibilityOf(orgLevelFilterFilterSearch));
					int counter = 0;
					orgLevelFilterFilterSearch.click();
					orgLevelFilterFilterSearch.clear();
					orgLevelFilterFilterSearch.sendKeys(courseName);
					List<WebElement> statusList = driver.findElements(By.xpath(unitLevelFilter + "/parent::li[not(contains(@class,'hidden'))]"));
					while(statusList.size() > 1)
					{
						statusList = driver.findElements(By.xpath(unitLevelFilter + "/parent::li[not(contains(@class,'hidden'))]"));
						Thread.sleep(2000);
						if(counter > 12)
							Assert.fail("Search functionality for user status is not working");
						counter++;
					}
					driver.findElement(By.xpath(unitLevelFilter + "//input[contains(@title,'" + courseName + "')]")).click();
				}
				catch(Exception e) {
					Assert.fail(e.getMessage());
				}

			}	
			
			public void validateOrgLevelFilterFilterAvailability()
			{
				try
				{
					val = pageLoad.getAttribute("class");
					int counter = 0;
					while(val.equalsIgnoreCase("loading_compliance"))
					{
						val = pageLoad.getAttribute("class");
						Thread.sleep(5000);
						counter++;
						if(counter>12)
							Assert.fail("Not able to load page after waiting for 1 minute");
					}
					Thread.sleep(3000);
					WebDriverWait wait = new WebDriverWait(driver, 30);
					wait.until(ExpectedConditions.visibilityOf(orgLevelFilter));
					orgLevelFilter.click();
				}
				catch(Exception e)
				{
					Assert.fail(e.getMessage());
				}
			}
			
			public void validateUtilisationTable(String headers,String Cell,String org)
			{
				try 
				{

					WebDriverWait wait = new WebDriverWait(driver, 30);
					wait.until(ExpectedConditions.visibilityOf(subscription_reportTable));
					int count=0;
					while(subscription_reportTable.getText().contains("Processing"))
					{
						if(count>=pagload)
							break;
						Thread.sleep(100);
						count++;
					}

					try
					{
						subscription_reportTable.findElements(By.xpath(".//tbody//tr")).get(0);
					}
					catch(Exception e)
					{
						reuse.waitforsec(4);
					}
					System.out.println("Header Passed"+headers);

					System.out.println("Cell Passed"+Cell);
					List<WebElement> header=subscription_reportTable.findElements(By.xpath(".//th"));
					int header_no=-1;
					System.out.println(header.size());
					for(int i=0;i<header.size();i++)
					{


						System.out.println("Web element "+header.get(i).getText());
						if(header.get(i).getText().equals(headers))
						{
							header_no=i;
							break;
						}

					}



					List<WebElement> row=subscription_reportTable.findElements(By.xpath(".//tbody//tr"));

					System.out.println(row.size());
					

					for(int i=0;i<row.size();i++)
					{
					 
					if(org.contains(row.get(i-1).findElements(By.xpath(".//td")).get(0).getText()))
					{
						System.err.println("Web element Row data "+row.get(i-1).findElements(By.xpath(".//td")).get(header_no).getText());

					switch(headers)
					{
					case "ORG NAME" :Assert.assertEquals( TestBase.prop.getProperty("orgName"),row.get(i-1).findElements(By.xpath(".//td")).get(header_no).getText());
									break;

					default :
						Assert.assertEquals( Cell,row.get(i-1).findElements(By.xpath(".//td")).get(header_no).getText());
					}
					}
					
					}


				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					Assert.fail(e.getMessage());
				}

			}
			
			public void validate_toolTip(String tooltip)
		    {
				WebDriverWait wait = new WebDriverWait(driver, 30);
		        wait.until(ExpectedConditions.visibilityOf(tooltips));
		        
		        Actions action = new Actions(driver);

		      //Performing the mouse hover action on the target element.
		      action.moveToElement(tooltips).perform();
		      System.out.println(tooltipsMsg.getText());
		      Assert.assertEquals("validate Pseudo anonymization Tooltip msg",tooltipsMsg.getText(), tooltip);
		      System.out.println(tooltips.getAttribute("data-original-title").replace("\n", ""));
		      
		      Assert.assertEquals("validate Pseudo anonymization Tooltip msg",tooltips.getAttribute("data-original-title").replace("\n", ""), tooltip);
		        
		      
		        
		        
		    }
			
			
			public void pickCalendarDate_shouldbeDisable(String date, String month, String year, String day) {
				WebDriverWait wait = new WebDriverWait(driver, 10);
				wait.until(ExpectedConditions.visibilityOf(calendarMainBody));
				wait.until(ExpectedConditions.visibilityOf(calendarMonthYear));
				month = month.toLowerCase();
				if(month.length() > 3) {
					month = month.substring(0, 3);
				}
				month = month.replace(month.split("")[0], month.split("")[0].toUpperCase());
				String currentMonth = calendarMonthYear.getText().split(" ")[0];
				String currentYear = calendarMonthYear.getText().split(" ")[1];
				String currentDay = day;
				if(currentYear.equals(year)) {
					if(currentMonth.contains(month)) {
						if(currentDay.equals(day)) {
							try
							{
						    driver.findElement(By.xpath(calendarDay + "" + day + "'])")).click();
						   
							Assert.assertTrue("Should not be able to "+currentDay,driver.findElement(By.xpath(calendarDay + "" + day + "'])")).getAttribute("class").contains("disabled day"));
							}
							catch(NoSuchElementException e)
							{
								
							}
	
						}
//						String ifSelected = driver.findElement(By.xpath(calendarDay + "[" + day + "]")).getAttribute("class").trim().toLowerCase();
//						Assert.assertTrue(ifSelected.contains("active"));
					}
					else {
						calendarMonthYear.click();
						WebElement requiredMonth = driver.findElement(By.xpath(calendarMonthOptions + month + "')]"));
						requiredMonth.click();
						currentMonth = calendarMonthYear.getText().split(" ")[0];
						Assert.assertTrue(currentMonth.contains(month));
						try
						{
							Assert.assertTrue("Should not be able to "+currentDay,driver.findElement(By.xpath(calendarDay + "" + day + "'])")).getAttribute("class").contains("disabled day"));
							}
						catch(NoSuchElementException e)
						{
							
						}
					    
						
					}
				}
				else {
					calendarMonthYear.click();
					calendarSelectedYear.click();
					int yearInt = Integer.parseInt(year);
					if((2009 <= yearInt) && (yearInt <= 2018)){
						calendarRequiredYear.click();
					}
					WebElement requiredYear = driver.findElement(By.xpath(calendarYearOptions + year + "')]"));
					requiredYear.click();
					WebElement requiredMonth = driver.findElement(By.xpath(calendarMonthOptions + month + "')]"));
					requiredMonth.click();
//					driver.findElement(By.xpath(calendarDay + "" + day + "'])")).click();
					try
					{
						Assert.assertTrue("Should not be able to "+currentDay,driver.findElement(By.xpath(calendarDay + "" + day + "'])")).getAttribute("class").contains("disabled day"));
					}
					catch(NoSuchElementException e)
					{
						
					}
//					driver.findElement(By.xpath(calendarDay + "[" + day + "]")).click();
				}
			}
			
			public void clickonClear()
			{
//		      val =  pageLoad.getAttribute("class");
//				 int counter=0;
//				 System.out.println(val);
			  
			    	wait.until(ExpectedConditions.visibilityOf(clear));
			    	
				clear.click();
			}
			
			public void clickonCheck()
			{
			    	wait.until(ExpectedConditions.visibilityOf(clear));
			    	
				clear.click();
			}
			
			
			public void validateLabel(String label)
			{
				
				
				try {
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[contains(text(),'"+label+"')]"))));
				}
				catch (NoSuchElementException e) {
				Assert.fail(label);
				
				}
			}
			
			public void validatefooterloadmessage(String label)
			{
				
				
				try {
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//p[contains(text(),'"+label+"')]"))));
				}
				catch (NoSuchElementException e) {
				Assert.fail(label);
				
				}
			}
			

			

			public void validateLabelnotdisplay(String label)
			{
				
				
				try {
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[contains(text(),'"+label+"')]"))));
				Assert.fail("should not displaye"+label);
				}
				catch (NoSuchElementException e) {
				
				
				}
			}
			
			
			public void validateLevel2PlaceHolder() {
				WebDriverWait wait = new WebDriverWait(driver, 10);
//				wait.until(ExpectedConditions.visibilityOf(orgfield));
//				fromDate.click();
//				DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd");	
//				LocalDate date = LocalDate.parse("2021/07/15", dateFormat);
//				System.out.println(date.format(dateFormat).toString() + " " + date.getMonth().toString() + " " + Integer.toString(date.getYear()) + " " + Integer.toString(date.getDayOfMonth()));
//				pickCalendarDate(date.format(dateFormat).toString(), date.getMonth().toString(), Integer.toString(date.getYear()), Integer.toString(date.getDayOfMonth()));
				
				
				
						String dataActual = driver.findElement(By.xpath("(//*[@id='dropdownContainer']//label)[2]")).getText();
						Assert.assertEquals("From Label incorrect", dataActual,"Level 2(s) Name");
						
				String dateActual = driver.findElement(By.xpath("(//*[@id='dropdownContainer']//button/span)[1]")).getText();
//				Assert.assertEquals("From Placeholder incorrect", dateActual,"Select Level 2(s)");
				
				driver.findElement(By.xpath("(//*[@id='dropdownContainer']//button)[1]")).click();
//				(//*[@id='dropdownContainer']//button)[1]/parent::div//ul//li
				
				orgsearch.getAttribute("placeholder");
				Assert.assertEquals("From Placeholder incorrect", driver.findElement(By.xpath("(//*[@id='dropdownContainer']//button)[1]/parent::div//input")).getAttribute("placeholder"),"Search");
				
				
			}
		
			public void validateLevel3PlaceHolder() {
				WebDriverWait wait = new WebDriverWait(driver, 10);
//				wait.until(ExpectedConditions.visibilityOf(orgfield));
//				fromDate.click();
//				DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd");	
//				LocalDate date = LocalDate.parse("2021/07/15", dateFormat);
//				System.out.println(date.format(dateFormat).toString() + " " + date.getMonth().toString() + " " + Integer.toString(date.getYear()) + " " + Integer.toString(date.getDayOfMonth()));
//				pickCalendarDate(date.format(dateFormat).toString(), date.getMonth().toString(), Integer.toString(date.getYear()), Integer.toString(date.getDayOfMonth()));
				
				
				
						String dataActual = driver.findElement(By.xpath("(//*[@id='dropdownContainer']//label)[3]")).getText();
						Assert.assertEquals("From Label incorrect", dataActual,"Level 3(s) Name");
						
				String dateActual = driver.findElement(By.xpath("(//*[@id='dropdownContainer']//button/span)[2]")).getText();
				Assert.assertEquals("From Placeholder incorrect", dateActual,"Select Level 3(s)");
				
				driver.findElement(By.xpath("(//*[@id='dropdownContainer']//button)[2]")).click();
//				(//*[@id='dropdownContainer']//button)[1]/parent::div//ul//li
				
				orgsearch.getAttribute("placeholder");
				Assert.assertEquals("From Placeholder incorrect", driver.findElement(By.xpath("(//*[@id='dropdownContainer']//button)[2]/parent::div//input")).getAttribute("placeholder"),"Search");
				
				
			}
		
			 public void selectunitfilter(int k,String unitname)
			    {
			        try
			        {
			            val = js.executeScript("return document.readyState").toString();

			            WebDriverWait wait = new WebDriverWait(driver, 30);
				           
			            wait.until(ExpectedConditions.visibilityOf(driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)")).get(k-1)));
//						
			            
			            driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)")).get(k-1).click();
			            
			            wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//*[@id='dropdownContainer']//button)["+k+"]/parent::div//input"))));
//						
			            driver.findElement(By.xpath("(//*[@id='dropdownContainer']//button)["+k+"]/parent::div//input")).sendKeys(unitname);
			            
			            
			            
//				        
			            List<WebElement> options = driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)["+k+"]/parent::div//li"));
			            int  counter = 0;
			            while(!(options.size() == 1))
			            {
			            	options = driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)["+k+"]/parent::div//li"));
			            	Thread.sleep(5000);
			            	counter++;
			            	if(counter>12)
			            		Assert.fail("Not able to search product after waiting for 1 minute");
			            }
			            
			            for(int i = 1; i <= options.size(); i++)
			            {
			            	String element ="(//*[@id='dropdownContainer']//button)["+k+"]/parent::div//li["+i+"]";
			            	String value = driver.findElement(By.xpath(element)).getText();
			            	if(value.toLowerCase().trim().equalsIgnoreCase(unitname))
			            	{
			            		Thread.sleep(2000);
			            		driver.findElement(By.xpath(element)).click();
			            		break;
			            	}
			            }
			            
			            driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)")).get(k-1).click();
			            Thread.sleep(5000);
//			            consumptionReport.click();
			            
		           
			        }
			        catch (Exception e)
			        {
			        	Assert.fail(e.getMessage());
			        }
			        
			    }

			 
			 public void selectPlaceholderunitfilter(int k)
			    {
			        try
			        {
			            val = js.executeScript("return document.readyState").toString();

			            WebDriverWait wait = new WebDriverWait(driver, 30);
				           
			            wait.until(ExpectedConditions.visibilityOf(driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)")).get(k-1)));
//						
			            
			            driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)")).get(k-1).click();
			            
			            driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)")).get(k-1).findElement(By.xpath(".//span")).getText();
			            
			            Assert.assertEquals("Only 1 Immediate parent Unit must be selected to view this level unit list.", driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)")).get(k-1).findElement(By.xpath(".//span[1]")).getText());
			            
			            try
			            {
			            	wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//*[@id='dropdownContainer']//button)["+k+"]/parent::div//input"))));
							Assert.fail("Inputs should not avalible")	;
			            }
			            catch(Exception e)
			            {
			            	
			            }
//			            driver.findElement(By.xpath("(//*[@id='dropdownContainer']//button)["+k+"]/parent::div//input")).sendKeys(unitname);
			            
			            
			            
//				        
//			            List<WebElement> options = driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)["+k+"]/parent::div//li"));
//			            int  counter = 0;
//			            while(!(options.size() == 1))
//			            {
//			            	options = driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)["+k+"]/parent::div//li"));
//			            	Thread.sleep(5000);
//			            	counter++;
//			            	if(counter>12)
//			            		Assert.fail("Not able to search product after waiting for 1 minute");
//			            }
//			            
			            String element ="(//*[@id='dropdownContainer']//button)["+k+"]/parent::div//li["+1+"]";
		            	String value = driver.findElement(By.xpath(element)).getText();
		            	
		                Assert.assertEquals("Only 1 Immediate parent Unit must be selected to view this level unit list.",value);
				        
//			            for(int i = 1; i <= options.size(); i++)
//			            {
//			            	if(value.toLowerCase().trim().equalsIgnoreCase(unitname))
//			            	{
//			            		Thread.sleep(2000);
//			            		driver.findElement(By.xpath(element)).click();
//			            		break;
//			            	}
//			            }
			            
			            driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)")).get(k-1).click();
			            Thread.sleep(5000);
//			            consumptionReport.click();
			            
		           
			        }
			        catch (Exception e)
			        {
			        	Assert.fail(e.getMessage());
			        }
			        
			    }

			 
			 public void selectunitfilter(int k)
			    {
			        try
			        {
			            val = js.executeScript("return document.readyState").toString();

			            WebDriverWait wait = new WebDriverWait(driver, 30);
				           
			            wait.until(ExpectedConditions.visibilityOf(driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)")).get(k-1)));
//						
			            
			            driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)")).get(k-1).click();
			            
			            wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//*[@id='dropdownContainer']//button)["+k+"]/parent::div//input"))));
//						
			            driver.findElement(By.xpath("(//*[@id='dropdownContainer']//button)["+k+"]/parent::div//a[text()='Select all']")).click();
			            
			            
			            
//				        
			           
			            driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)")).get(k-1).click();
			            Thread.sleep(5000);
//			            consumptionReport.click();
			            
		           
			        }
			        catch (Exception e)
			        {
			        	Assert.fail(e.getMessage());
			        }
			        
			    }

			 
			 public void selectshouldbedisable(int k)
			    {
			        try
			        {
			            val = js.executeScript("return document.readyState").toString();

			            WebDriverWait wait = new WebDriverWait(driver, 30);
				           
			            wait.until(ExpectedConditions.visibilityOf(driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)")).get(k-1)));
//						
			            
			            driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)")).get(k-1).click();
			            
			            wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//*[@id='dropdownContainer']//button)["+k+"]/parent::div//input"))));
//						
//			            driver.findElement(By.xpath("(//*[@id='dropdownContainer']//button)["+k+"]/parent::div//input")).sendKeys(unitname);
			            
						
			        	Assert.assertTrue("Button is not disabled",driver.findElement(By.xpath("(//*[@id='dropdownContainer']//button)["+k+"]/parent::div//a[text()='Select all']")).getClass().toString().contains("disabled"));

			            
			          
			            Thread.sleep(5000);
//			            consumptionReport.click();
			            
		           
			        }
			        catch (Exception e)
			        {
			        	Assert.fail(e.getMessage());
			        }
			        
			    }

			 public void selectshouldberemove(int k)
			    {
			        try
			        {
			            val = js.executeScript("return document.readyState").toString();

			            WebDriverWait wait = new WebDriverWait(driver, 30);
				           
			            wait.until(ExpectedConditions.visibilityOf(driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)")).get(k-1)));
//						
			            
			            driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)")).get(k-1).click();
			            
			            wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//*[@id='dropdownContainer']//button)["+k+"]/parent::div//input"))));
//						
//			            driver.findElement(By.xpath("(//*[@id='dropdownContainer']//button)["+k+"]/parent::div//input")).sendKeys(unitname);
			            
						
			        	Assert.assertEquals("Button is not disabled",0,driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)["+k+"]/parent::div//a[text()='Select all']")).size());

			            
			          
			            Thread.sleep(5000);
//			            consumptionReport.click();
			            
		           
			        }
			        catch (Exception e)
			        {
			        	Assert.fail(e.getMessage());
			        }
			        
			    }


			public void validateNumber(int size) {
				WebDriverWait wait = new WebDriverWait(driver, 10);
				wait.until(ExpectedConditions.visibilityOf(driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)")).get(0)));
						
				int lenght = driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)")).size();
				Assert.assertEquals("Number of filter is incorrect", size,lenght);
				
				
			}
			public void validatelabel() {
				WebDriverWait wait = new WebDriverWait(driver, 10);
				wait.until(ExpectedConditions.visibilityOf(showchildcheckbox));
							
				String label = driver.findElement(By.xpath("(//*[@id='include_child_stl']/div//span)[1]")).getText();
				Assert.assertEquals("Validate the label", "Show direct utilization count",label);
				 label = driver.findElement(By.xpath("(//*[@id=\"include_child_stl\"]//span)[2]")).getText();
				 Assert.assertEquals("Validate the label", "This will only include data for those who belong directly to the unit selected",label);
					
				
				
			}
			
			public void Bydefault() {
				WebDriverWait wait = new WebDriverWait(driver, 10);
				wait.until(ExpectedConditions.visibilityOf(showchildcheckbox));
				 Assert.assertEquals("Validate the label", "This will only include data for those who belong directly to the unit selected",showchildcheckbox);
							
				
				
				
			}
			public void get_unit_level(String unitname) {
				WebDriverWait wait = new WebDriverWait(driver, 60);
				reuse.waitforsec(4);
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//table[@id='tablelisting']//tbody//tr"))));
				
				int size =driver.findElements(By.xpath("//table[@id='tablelisting']//tbody//tr")).size();
				
				
				List<WebElement> row=driver.findElements(By.xpath("//table[@id='tablelisting']//tbody//tr"));

				
				
				String unitName=null;
				for(int i=0;i<size;i++)
				{
					System.out.println(row.get(i).findElements(By.xpath(".//td")).get(0).getText());
					System.out.println(row.get(i).findElements(By.xpath(".//td")).get(2).getText());
					System.out.println(row.get(i).findElements(By.xpath(".//td")).get(1).getText());
					System.out.println(row.get(i).findElements(By.xpath(".//td")).get(3).getText());
					String unitnme=row.get(i).findElements(By.xpath(".//td")).get(0).getText();
					String unitcode=row.get(i).findElements(By.xpath(".//td")).get(2).getText();
					
					if(unitName==null)
					{
						unitName=unitcode+" - "+unitnme;
					}
					else
						unitName=unitName+","+unitcode+" - "+unitnme;;
				}
			
				dataMap.put(OrganizationHome.exceptionid+unitname,unitName)  ;
				
				dataMap.put(OrganizationHome.exceptionid+unitname+"size",String.valueOf(size))  ;
				
				System.out.println(dataMap.keySet(). toString());

				System.out.println(dataMap.values(). toString());
			}
			
		
			public void validatetheoption(int k)
		    {
		        try
		        {
		            val = js.executeScript("return document.readyState").toString();

		            WebDriverWait wait = new WebDriverWait(driver, 30);
			           
		            wait.until(ExpectedConditions.visibilityOf(driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)")).get(k-1)));
//					
		            
		            driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)")).get(k-1).click();
		            
		            wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//*[@id='dropdownContainer']//button)["+k+"]/parent::div//input"))));
//					
		            
		            List<WebElement> options = driver.findElements(By.xpath("(//*[@id='dropdownContainer']//button)["+k+"]/parent::div//li"));
		          
		            int count=(k+1); 
		        	String size= dataMap.get(OrganizationHome.exceptionid+"Level_"+count+"size");
		            Assert.assertEquals("Incorrect level count",size, options.size());
		          
		            Thread.sleep(5000);
//		            consumptionReport.click();
		            
	           
		        }
		        catch (Exception e)
		        {
		        	Assert.fail(e.getMessage());
		        }
		        
		    }
			
			
			public void validateUtilisationTable(String keyset)
			{
				try 
				{

					reuse.validateTable(keyset);
					WebDriverWait wait = new WebDriverWait(driver, 30);
					wait.until(ExpectedConditions.visibilityOf(subscription_reportTable));
					int count=0;
					while(subscription_reportTable.getText().contains("Processing"))
					{
						if(count>=pagload)
							break;
						Thread.sleep(100);
						count++;
					}

					try
					{
						subscription_reportTable.findElements(By.xpath(".//tbody//tr")).get(0);
					}
					catch(Exception e)
					{
						reuse.waitforsec(4);
					}




					List<WebElement> row=subscription_reportTable.findElements(By.xpath(".//tbody//tr"));

					System.out.println(row.size());
					
//					System.err.println("Web element Row data "+row.get(i-1).findElements(By.xpath(".//td")).get(header_no).getText());
					SoftAssert softAssert = new SoftAssert(); 
			        
					dataMap.get("row"+count);
					
					 dataMap.get("rowsize");
	                 
					for(int i=0;i<row.size();i++)
					{
						System.out.println();
//						System.out.println(e);
						  boolean flag=false;
						  System.out.println(row.get(i).getText());
						for(int j=0;j<Integer.valueOf(dataMap.get("rowsize"));j++)
						{    
							System.out.println(j);
							System.err.println(dataMap.get("row"+j));
						if(row.get(i).getText().toString().equals(dataMap.get("row"+j)))
						{
							 flag=true;
						
						}
						}
						softAssert.assertTrue(flag,"Data didnt match UI "+row.get(i).getText().toString()); 
					}
//					
//					rowData
					
			        softAssert.assertAll(); 

					

				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					Assert.fail(e.getMessage());
				}

			}
			
}
