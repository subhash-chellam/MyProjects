package com.qa.pages;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.qa.util.*;



public class OrganizationAccess extends TestBase
{
	
	@FindBy(xpath = "//div[@class = 'user_details pt0']//span[2]")
	WebElement orgID;
	
	
	
	@FindBy(xpath = "//a[@class=\"orgHierarchyUnit\"]")
	WebElement orgHierarchyUnit;
	
	
	
	@FindBy(xpath = "//*[@id='hierarchyStructure']")
	WebElement hierarchyStructure;
	
	@FindBy(xpath = "//*[@id=\"dynamic_unit_name\"]")
	WebElement Unitname;
	
	@FindBy(xpath = "//a[text() = 'Organization Settings']")
	WebElement orgSetting;
	
	@FindBy(xpath = "//div[contains(@class, 'user_details')]//a[contains(text(),'Logout')]")
	WebElement logout;
	
	@FindBy(xpath = "//div[contains(@class, 'user_details')]//a[text() = 'Switch Organization']")
	WebElement switchOrg;
	
	@FindBy(xpath = "//div[contains(@class, 'user_details')]//a[@data-toggle='dropdown']")
	WebElement menuOption;
	@FindBy(xpath = "//a[contains(text(),'Go to Admin Dashboard')]")
	WebElement gotoadminlink;
	User user;
	
	//Initialize Page objects
	public OrganizationAccess()
	{
		PageFactory.initElements(driver, this);
	}
	
	public void gotoadmindashboard()
	{
	wait.until(ExpectedConditions.visibilityOf(menuOption));
	wait.until(ExpectedConditions.elementToBeClickable(menuOption));
	menuOption.click();
	wait = new WebDriverWait(driver, 10);
	wait.until(ExpectedConditions.visibilityOf(gotoadminlink));
	gotoadminlink.click();
	}
	
	public void validateOrgID(String originalID)
	{
		wait.until(ExpectedConditions.visibilityOf(orgID));
		String newId = orgID.getText();
		Assert.assertTrue(newId.contains(originalID));
	}
	
	public void validateHierarchy(String levels)
	{
		
		for(int i=0;i<levels.split(",").length;i++)
		{
			try
			{
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@class='left-nav tab-content']//a[contains(text(),'"+levels.split(",")[i]+"') and contains(@href,'manage_units')]"))));

			driver.findElement(By.xpath("//div[@class='left-nav tab-content']//a[contains(text(),'"+levels.split(",")[i]+"') and contains(@href,'manage_units')]")).click();
			
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//li//a[contains(text(),'"+levels.split(",")[i]+"') and @class='active']"))));
		
		driver.findElement(By.xpath("//li//a[contains(text(),'"+levels.split(",")[i]+"') and @class='active']")).click();
			}
			catch(Exception e)
			{
				
				e.printStackTrace();
				Assert.fail("Hierarchy is not matching");
			}
		
		}
	}
	public void validateHierarchyinunit(String levels)
	{
		if(AssignmentReport. checkifParmeterAvailable(levels))
			levels=AssignmentReport.getParmeterAvailable(levels);

	
		wait.until(ExpectedConditions.visibilityOf(orgHierarchyUnit));

		orgHierarchyUnit.click();
		
		Assert.assertEquals(Unitname.getText(),"Automation Test");
		try
		{
		Thread.sleep(5000);
		wait.until(ExpectedConditions.visibilityOf(hierarchyStructure));
			Assert.assertEquals(hierarchyStructure.getText().replace("\n",",").replace(",,", ","),levels);
		
		}
		catch(Exception e)
		{
			
		}

		
		
		
	}
	public void navigateOrgSetting()
	{
		try {
		wait.until(ExpectedConditions.visibilityOf(orgSetting));
		wait.until(ExpectedConditions.elementToBeClickable(orgSetting));
		orgSetting.click();
		}
		catch(Exception e) 
		{
			wait.until(ExpectedConditions.visibilityOf(orgSetting));
			wait.until(ExpectedConditions.elementToBeClickable(orgSetting));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", orgSetting);
		}
	}
	
	public void logout()
	{
		try 
		{
			user = new User();
			user.navigateUserModule();
			Thread.sleep(5000);
			JavascriptExecutor js = (JavascriptExecutor)driver;
			String pageValue = js.executeScript("return document.readyState").toString();
			int m=0;
			while(!(pageValue.equalsIgnoreCase("complete")))
			{
				pageValue = js.executeScript("return document.readyState").toString();
				if(m==pagload)
					break;
				m++;
			}
			wait.until(ExpectedConditions.visibilityOf(menuOption));
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("arguments[0].click()", menuOption);
			wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOf(logout));
			logout.click();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	public void switchOrganisation()
	{
		wait.until(ExpectedConditions.visibilityOf(menuOption));
		wait.until(ExpectedConditions.elementToBeClickable(menuOption));
		reuseableCode.waitforsec(3);
		menuOption.click();
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(switchOrg));
		switchOrg.click();
	}
	public void validateTabs(String item,String Status)
	{
		List<WebElement> actionitem = driver.findElements(By.xpath("//ul[contains(@class,'edit_organization_tabs')]//a"));
		Boolean flag=false;
		for(int i=0;i<actionitem.size();i++)
		{
			System.out.println(actionitem.get(i).getText());
			
			if(actionitem.get(i).getText().contains(item))
			{
				flag=true;	
				break;
			}
			else if(actionitem.get(i).getText().contains("Manage Admins"))
			{
				flag=true;	
				break;
		
			}
		}
		if(Status.equals("Present"))
			Assert.assertTrue("Not Present"+item,flag);
		else
			Assert.assertFalse("Present"+item,flag);
	}
	
	public void validateOrganisationHierarchy(String item,String Status)
	{
		List<WebElement> actionitem = driver.findElements(By.xpath("//div[@class='organization-tab-content']//a"));
		Boolean flag=false;
		for(int i=0;i<actionitem.size();i++)
		{
			System.out.println(actionitem.get(i).getText());
			
			if(actionitem.get(i).getText().contains(item))
			{
				flag=true;	
				break;
			}
			
		}
		if(Status.equals("Present"))
			Assert.assertTrue("Not Present"+item,flag);
		else
			Assert.assertFalse("Present"+item,flag);
	}

	public void validateUnit(String item,String Status) throws InterruptedException
	{
		if(AssignmentReport. checkifParmeterAvailable(item+prop.getProperty("environment")))
			item=AssignmentReport.getParmeterAvailable(item+prop.getProperty("environment"));

		
		Thread.sleep(3000);
		List<WebElement> actionitem = driver.findElements(By.xpath("//*[contains(@id,'tablelisting')]//td"));
		Boolean flag=false;
		for(int i=0;i<actionitem.size();i++)
		{
			System.out.println(actionitem.get(i).getText());
			if(actionitem.get(i).getText().contains(item))
			{
				flag=true;	
				break;
			}
			
		}
		if(Status.equals("Present"))
			Assert.assertTrue("Not Present"+item,flag);
		else
			Assert.assertFalse("Present"+item,flag);
		
	}
	
	public void validateifduplicateUnit(String item) throws InterruptedException
	{
		
		Thread.sleep(3000);
		List<WebElement> actionitem = driver.findElements(By.xpath("//*[contains(@id,'tablelisting')]//td//a[@class='orgHierarchyUnit']"));
		Boolean flag=false;
		for(int i=0;i<actionitem.size();i++)
		{
			System.out.println(actionitem.get(i).getText());
			if(actionitem.get(i).getText().contains(item))
			{
				if(flag==true)
					Assert.fail("Duplicate unit found");
				else
				flag=true;	
				
			}
			
		}
		
		
		Assert.assertTrue("Not Present"+item,flag);
	}

	

}
