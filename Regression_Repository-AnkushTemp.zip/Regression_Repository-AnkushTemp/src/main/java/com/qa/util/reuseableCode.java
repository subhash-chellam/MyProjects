package com.qa.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

//import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellRangeAddress;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.w3c.dom.Document;

import com.qa.pages.User;

public class reuseableCode extends TestBase {

	public JSONObject getjsonObject(String key)
	{
		JSONParser jsonParser = new JSONParser();
	    JSONObject jsonparmeter;
	    JSONObject tableDetails = null;
		
		try (FileReader reader = new FileReader(  System.getProperty("user.dir")+prop.getProperty("downloadPath")+"\\ValidateTableDetails"+prop.getProperty("environment")+".json"))
		{
			//Read JSON file
			Object obj = jsonParser.parse(reader);
			
			jsonparmeter = (JSONObject) obj;
			tableDetails = (JSONObject) jsonparmeter.get(key);
			
		
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			Assert.fail(e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
			Assert.fail(e.getMessage());
		} catch (ParseException e) {
			e.printStackTrace();
			Assert.fail(e.getMessage());
		}
		return tableDetails;
	}
	
	public static String getMailTemplate(String Mail)
	{
		String mail=null;
		try   
		{  
			String env=prop.getProperty("environment");
		//creating a constructor of file class and parsing an XML file  
		File file = new File(System.getProperty("user.dir") + "\\src\\main\\java\\com\\qa\\config\\mail.Templates\\"+env+"MailTemplates.xml");  
		//an instance of factory that gives a document builder  
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
		//an instance of builder to parse the specified xml file  
		DocumentBuilder db = dbf.newDocumentBuilder();  
		Document doc = db.parse(file);  
		doc.getDocumentElement().normalize();  
		 mail = doc.getElementsByTagName(Mail).item(0).getTextContent();
		return mail;
		}
		// nodeList is not iterable, so we are using for loop  
		
		catch (Exception e)   
		{  
		e.printStackTrace();  
		}  
		return mail;
	}

	public void createJsonFile(JSONArray userDetails,String arrayName, String fileName) {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(arrayName, userDetails);
	    try {
	        FileWriter file = new FileWriter(System.getProperty("user.dir") + "\\src\\test\\java\\resources\\" + fileName + ".json");
	          file.write(jsonObject.toJSONString());
	          file.close();
	       } catch (IOException e) {
	          // TODO Auto-generated catch block
	          e.printStackTrace();
	       }		
		
	}
	
	public void validateTable(List<String> text, List<WebElement> Columns) throws Exception
	{
		Thread.sleep(5000);
		Thread.sleep(3000);
		
		int count = 0;
		Assert.assertEquals(text.size(), Columns.size());
		for(WebElement tt : Columns){
			System.out.println(tt.getAttribute("innerText"));
			Assert.assertEquals(text.get(count).toUpperCase(), tt.getAttribute("innerText").trim());
			count++;
		}

	}

	public void waitfor1min(int d)
	{
		try {
			Thread.sleep(60000*d);

		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	

	public static void waitforsec(int d)
	{
		try {
			Thread.sleep(1000*d);

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public static String getUserEmail()
	{
		Date formatDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(formatDate);
		System.out.println(formatDate + "&&" + date);
		//formatDate = new java.util.Date().toString();
		date = date.replace(" ", "").replace(":", "").replace("-", "");
		String email =prop.getProperty("userDomain").replace("<adduniquestringhere>",date);
		return email;
	}
	
	public static String getUserEmail(String formattedEmail)
	{
		String  email =prop.getProperty("userDomain").replace("<adduniquestringhere>",formattedEmail);
		return email;
	}
	public void validatethedetails(String header,String tableHeader,String value,String tablerow,String EmailHeader)
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableHeader))));
		List<WebElement> tableRows = driver.findElements(By.xpath(tablerow));
		
		Assert.assertEquals(tableRows.get(getHeaderPosition(EmailHeader,tableHeader)-1).getText(), User.userEmail);
		Assert.assertEquals(tableRows.get(getHeaderPosition(header,tableHeader)-1).getText(), value);
	}

	
	public void validatethedetails(String header,String tableHeader,String value,String tablerow,String EmailHeader,String rowData)
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableHeader))));
		List<WebElement> tableRows = driver.findElements(By.xpath(tablerow));
		
		Assert.assertEquals(tableRows.get(getHeaderPosition(EmailHeader,tableHeader)-1).getText(), rowData);
		Assert.assertEquals(tableRows.get(getHeaderPosition(header,tableHeader)-1).getText(), value);
	}
	
	public void validatethedetails(String header,String tableHeader,String value,String tablerow)
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableHeader))));
		List<WebElement> tableRows = driver.findElements(By.xpath(tablerow));
		
		System.out.println(tableRows.size());
		System.out.println(header);

		System.out.println(tableHeader);
		System.out.println(tableRows.get(getHeaderPosition(header,tableHeader)-1).getText());
		Assert.assertEquals(tableRows.get(getHeaderPosition(header,tableHeader)-1).getText(), value);
	}

	
	
	public int getHeaderPosition(String header,String tableHeader)
	{
		scrollLeft();
		
		
		int columnCount = 0;
		try {
			Thread.sleep(5000);
//			try
//			{			
//		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(tableHeader))));
//			}
//			catch(Exception e)
//			{
//				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(tableHeader))));
//						
//			}
		List<WebElement> tableHeaderRows = driver.findElements(By.xpath(tableHeader));
		for(int i = 1; i <=tableHeaderRows.size(); i++)
		{
			String headerName = driver.findElement(By.xpath(tableHeader + "[" + i +"]")).getText();
			if(headerName.trim().equalsIgnoreCase(header))
			{
				columnCount = i;
				break;				
			}				
		}
		int counter = 0;
		
		while(columnCount == 0) {
			scrollRight();
			
		       tableHeaderRows = driver.findElements(By.xpath(tableHeader));
				for(int i = 1; i <=tableHeaderRows.size(); i++)
				{
					String headerName = driver.findElement(By.xpath(tableHeader + "[" + i +"]")).getText();
					if(headerName.trim().equalsIgnoreCase(header))
					{
						columnCount = i;
						break;				
					}				
				}
			
//			columnCount = getHeaderPosition(header,tableHeader);
			Thread.sleep(5000);
			counter++;
			if(counter>12)
				Assert.fail("Not able to load page after waiting for 1 minute");
		}
		System.out.println("The column position for " + header +" is " + columnCount);
		}
		catch(Exception e) {
			e.printStackTrace();
			Assert.fail(tableHeader);
		}
		return columnCount;
	}
	
	public void scrollRight()
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
		executor.executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", scrollArea);
	}
//	
	
	public void createJsonFile() {
		JSONObject jsonObject = new JSONObject();
		try {
	        FileWriter file = new FileWriter(System.getProperty("user.dir") + "\\src\\test\\java\\resources\\MailUsers2.json");
	          file.write(jsonObject.toJSONString());
	          file.close();
	       } catch (IOException e) {
	          // TODO Auto-generated catch block
	          e.printStackTrace();
	       }		
		
	}
	public void scrollLeft()
	{
		try
		{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebElement scrollArea = driver.findElement(By.className("dataTables_scrollBody"));
		executor.executeScript("arguments[0].scrollLeft = -arguments[0].offsetWidth", scrollArea);
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	 private static byte[] key;
	  private static SecretKeySpec secretKey;

	  public static void setKey(final String myKey) {
	    MessageDigest sha = null;
	    try {
	      key = myKey.getBytes("UTF-8");
	      sha = MessageDigest.getInstance("SHA-1");
	      key = sha.digest(key);
	      key = Arrays.copyOf(key, 16);
	      secretKey = new SecretKeySpec(key, "AES");
	    } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
	      e.printStackTrace();
	    }
	  }

	  public  String encrypt(final String strToEncrypt, final String secret) {
	    try {
	      setKey(secret);
	      Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
	      cipher.init(Cipher.ENCRYPT_MODE, secretKey);
	      return Base64.getEncoder()
	        .encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
	    } catch (Exception e) {
	      System.out.println("Error while encrypting: " + e.toString());
	    }
	    return null;
	  }

	  public  String decrypt(final String strToDecrypt, final String secret) {
	    try {
	      setKey(secret);
	      Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
	      cipher.init(Cipher.DECRYPT_MODE, secretKey);
	      return new String(cipher.doFinal(Base64.getDecoder()
	        .decode(strToDecrypt)));
	    } catch (Exception e) {
	      System.out.println("Error while decrypting: " + e.toString());
	    }
	    return null;
	  }

		public static String getPdfContent(String filename) throws Exception {


			File file = new File(filename);
			PDDocument doc = PDDocument.load(file);;

			PDFTextStripper strip = new PDFTextStripper();
			System.out.println(doc.getDocument().toString());
			String stripText = strip.getText(doc);

			System.out.println(stripText);

			doc.close();

			return stripText;

			}
		
		public static void validateTable(String keyset)
		{
			File xlsxFile = new File(System.getProperty("user.dir") + "\\src\\test\\java\\resources\\UtilizationReport"+prop.getProperty("environment")+".xlsx");
	        
	        //New students records to update in excel file
	    
	        try {
	            //Creating input stream
	            FileInputStream inputStream = new FileInputStream(xlsxFile);
	             
	            //Creating workbook from input stream
	            Workbook workbook = WorkbookFactory.create(inputStream);
	 
	            //Reading first sheet of excel file
	            Sheet sheet = null;
//	            if(FeatureName.contains("Smoke"))
	            	sheet = 	workbook.getSheetAt(0);
//	            else
//	            	sheet = 	workbook.getSheetAt(1);
	            	
	            	
	            	Iterator<Row> rowIterator = sheet.iterator();
	            	   while(rowIterator.hasNext()) {
	            	            
	            	            Row row = rowIterator.next();
	            	            
	            	            Iterator<Cell> cellIterator = row.iterator();               
	            	                        
	            	            while(cellIterator.hasNext()) {
	            	                Cell currentCell = cellIterator.next();
	            	                
	            	                // To get values of the merged cells
	            	                
	            	                for(int i = 0; i < sheet.getNumMergedRegions(); i++) {
	            	                    
	            	                    CellRangeAddress region = sheet.getMergedRegion(i);
	            	                    
	            	                    int colIndex = region.getFirstColumn(); // no of columns merged
	            	                    int rownum = region.getFirstRow();      // no of rows merged
	            	                    
	            	                    int last = region.getLastRow(); // no of columns merged
//	            	                    int lastcol = region.getLastColumn();      // no of rows merged
	            	                    
//	            	                    System.out.println(i);
	            	                    
	            	                    if(rownum == currentCell.getRowIndex() && colIndex == currentCell.getColumnIndex()) {
	            	                    	 System.out.println(region.getFirstRow() + " " + region.getLastRow());
	              	                       
	            	                    	System.out.println(region.getFirstColumn() + " " + region.getLastColumn());
	            	                    	String data= sheet.getRow(rownum).getCell(colIndex).getStringCellValue();
	            	                        if(keyset.equals(data))
	            	                        {
	            	                        	 int count=0;
	                  	                       	
	            	                        for(int m=rownum;m<=last;m++)
	            	                        {	
	            	                        	String rowdata=null;
	            	                        	for(int n=1;n<8;n++)
	                	                   {
	            	                        String dta=null;
	            	                        Row rw=sheet.getRow(m); //returns the logical row  
	            	                        Cell cll=rw.getCell(n); //getting the cell representing the given column  
	            	                      
	            	                        if(cll.getCellType().toString().equals("NUMERIC"))
	            	                        {
	            	                        if(rowdata==null)
	            	                        	rowdata=String.valueOf( cll.getNumericCellValue()).replace(".0", ""); 	
	            	                        else
	            	                        	rowdata=rowdata+" "+String.valueOf( cll.getNumericCellValue()).replace(".0", "");
	            	                        }
	            	                        else
	            	                        {
	            	                        	 if(rowdata==null)
	                 	                        	rowdata=cll.getStringCellValue().toString(); 	
	                 	                        else
	                 	                        	rowdata=rowdata+" "+cll.getStringCellValue().toString();
	                 	                        	
	            	                        }
	            	                    	}
	            	                       System.out.println("row"+count+" : "+rowdata);
	            	                       dataMap.put("row"+count, rowdata);
	            	                       count++;
	                    	                        	
	            	                    	}
	            	                        dataMap.put("rowsize", String.valueOf(count));
		            	                       
	            	                        }
	            	                        
	            	                        }
	            	                    }
	            	                }
	            	            }
	            	        
	        }
	        catch(Exception e)
	        {
	        
	        	
	        	e.printStackTrace();
	        Assert.fail(e.getMessage());
	        }
		}
				
}
