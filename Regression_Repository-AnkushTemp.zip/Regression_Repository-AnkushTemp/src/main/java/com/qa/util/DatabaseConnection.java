package com.qa.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Properties;

import jakarta.activation.DataHandler;
import jakarta.activation.DataSource;
import jakarta.activation.FileDataSource;
import jakarta.mail.BodyPart;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.Multipart;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeBodyPart;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.internet.MimeMultipart;

import org.openqa.selenium.WebDriver;

public class DatabaseConnection {

//	public static Properties prop;
	public static FileInputStream fis;
	public static Connection dbcon;
	public static Statement st;
	public static int Master_counter;
	public static int passcount=0;
	public static int failcount=0;
	
	@SuppressWarnings("restriction")
	public static String getUserName() throws Exception {

		/*Process exec = Runtime.getRuntime().exec("cmd /c wmic ComputerSystem get UserName".split(" "));
	      String user;
	        try (BufferedReader bw = new BufferedReader(new InputStreamReader(exec.getInputStream()))) {
	            String username = bw.readLine() + bw.readLine() + bw.readLine();
	            user = username.replaceAll("UserName ", "");
	        }*/

		com.sun.security.auth.module.NTSystem NTSystem = new com.sun.security.auth.module.NTSystem();
		String user = NTSystem.getName();
		return user;
	}

	public void insertMasterTableDetails() throws Exception {

		dbcon = DriverManager.getConnection("jdbc:mysql://lblr-prod-use1-rds-automation-testcase-executiontracker.cqndk3xkwl7s.us-east-1.rds.amazonaws.com:3306/ExecutionTracker", "naveen.b", "MpO0Qak1#baPAxg2!bYa5!1J");
		System.out.println("Database is connected !");
		st =  dbcon.createStatement();
		ResultSet res =  st.executeQuery("SELECT Max(Execution_id) as EID FROM `Execution_Master`");
		res.next();
		System.out.println(res.getInt(1));
		if(res.getInt(1)==0)
			Master_counter = 1;
		else
			Master_counter = res.getInt(1)+1;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		System.out.println(dtf.format(now));
		String query1 = "INSERT INTO Execution_Master (Execution_Id,Project_Name,Suite_Type,Execution_Start_Date,Execution_End_Date,Executed_By,Execution_Environment,Created_By,Created_On) VALUES ("+Master_counter+",'"+ TestBase. prop.getProperty("ProjectName")+"','"+TestBase.prop.getProperty("SuitType")+"','"+dtf.format(now)+"','"+dtf.format(now)+"','"+TestBase.prop.getProperty("ExecutedBy")+"','"+TestBase.prop.getProperty("environment")+"','"+getUserName()+"','"+dtf.format(now)+"');";
		System.out.println(query1);
		st.executeUpdate(query1);
	}

	public void UpdateMasterExecutionEndDate() throws Exception {
		
		System.out.println("Pass count "+passcount);
		System.out.println("fail count "+failcount);
		
		Statement st =  dbcon.createStatement();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		System.out.println(dtf.format(now));
		st.executeUpdate("UPDATE Execution_Master SET Execution_End_Date= '"+dtf.format(now)+"' WHERE Execution_Id= "+Master_counter+";");
	}

	public void insertExecutionDetails(String suiteType, String ModuleName, String testCaseName,String status) throws Exception {
		Statement st1 =  dbcon.createStatement();
		if(suiteType.equalsIgnoreCase("SMOKE")){
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
			LocalDateTime now = LocalDateTime.now();  
			System.out.println("Test Smoke");
			String query = "INSERT INTO Execution_Sanity_Details (Execution_Id,Test_Case_Name,Execution_Start_Date,Execution_End_Date) VALUES ("+Master_counter+",'"+testCaseName+"','"+dtf.format(now)+"','"+dtf.format(now)+"');";
			st1.executeUpdate(query);
		}else {

			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
			LocalDateTime now = LocalDateTime.now();  
			System.out.println("Test Regression");
			String query1 = "INSERT INTO Execution_Regression_Details (Execution_Id,Module_Name,TestCase_Name,Execution_Start_Date,Execution_End_Date) VALUES ("+Master_counter+",'"+ModuleName+"','"+testCaseName+"','"+dtf.format(now)+"','"+dtf.format(now)+"');";
			st1.executeUpdate(query1);

		}
	}

	public void insertExecutionScenarioStatus(String testCaseName,String status,String Exception,String Error) throws Exception {
		
		Statement st1 =  dbcon.createStatement();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		System.out.println("Test Smoke");
		String query = "INSERT INTO Execution_Result (Execution_Id,Scenario_Name,Result,Exception,Error) VALUES ("+Master_counter+",'"+testCaseName+"','"+status+"','"+Exception+"','"+Error+"');";
		st1.executeUpdate(query);

	}

	
	
	public void UpdateExecutionEndDate(String Type) throws Exception {
		Statement st =  dbcon.createStatement();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		System.out.println(dtf.format(now));
		if(Type.equalsIgnoreCase("smoke")) {
			st.executeUpdate("UPDATE Execution_Sanity_Details SET Execution_End_Date= '"+dtf.format(now)+"' WHERE Execution_Id= "+Master_counter+";");
		}else {
			st.executeUpdate("UPDATE Execution_Regression_Details SET Execution_End_Date= '"+dtf.format(now)+"' WHERE Execution_Id= "+Master_counter+";");
		}
	}
	public static void  SendingMail()
	{

		File f = new File(System.getProperty("user.dir")+"\\Report");
		  
        String[] files = f.list();

        

        SimpleDateFormat formatter = new SimpleDateFormat("MMM-YY");  
        Date date = new Date();  
        LocalDateTime now = LocalDateTime.now();
        System.out.println(formatter.format(date)); 
     	String filename=null;
        
     	Boolean flag=false;
        for (int i = 0; i < files.length; i++) {
            if(files[i].contains(formatter.format(date)))
            {  
            	filename=  files[i];
            	flag=true;
            
            }
        }
        
        try
        {
        File  f2 = new File(System.getProperty("user.dir")+"\\target\\cucumber.html");
        f = new File(System.getProperty("user.dir")+"\\Report\\"+filename+"\\Report\\ExtentPdf.pdf");
//    	SendMail(f.getPath(),f2.getPath());
        }
        catch(Exception e)
        {
        e.printStackTrace();	
        }
        
	}
	public static void  SendMail(String path1,String path2)
	{

		//provide recipient's email ID
	      String to = "automation-qa-d74525+20230907162935AP@inbox.mailtrap.io";
	      //provide sender's email ID
	      String from = "AutomationTeam@rqimail.laerdalblr.in";
	      //provide Mailtrap's username
	      final String username = "AutomationTeam@rqimail.laerdalblr.in";
	      //provide Mailtrap's password
	      final String password = "Automation@123";
	      //provide Mailtrap's host address
	      String host = "rqimail.laerdalblr.in";
	      //configure Mailtrap's SMTP server details
	      Properties props = new Properties();
	      props.put("mail.smtp.auth", "true");
	      props.put("mail.smtp.starttls.enable", "true");
	      props.put("mail.smtp.host", host);
	      props.put("mail.smtp.port", "587");
	      //create the Session object
	      Session session = Session.getInstance(props,
	         new jakarta.mail.Authenticator() {
	            protected PasswordAuthentication getPasswordAuthentication() {
	               return new PasswordAuthentication(username, password);
	    }
	         });
	      try {
	    //create a MimeMessage object
	    Message message = new MimeMessage(session);
	    //set From email field
	    message.setFrom(new InternetAddress(from));
	    //set To email field
	    message.setRecipients(Message.RecipientType.TO,
	               InternetAddress.parse(to));
	    //set email subject field
	    SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-YY");  
        Date date = new Date();  
        LocalDateTime now = LocalDateTime.now();
        System.out.println(formatter.format(date)); 
     
        message.setSubject("Automation Test Execution Report "+formatter.format(date));
	   
	    
	    
	    BodyPart messageBodyPart = new MimeBodyPart();
	    //set the actual message
	    messageBodyPart.setContent("<p style='margin-bottom:10px;'>Hi Team,<br><br>Please find attached Execution Report <br><br>Result---<br><strong style='font-family: Comic Sans MS;color:green;font-size: 15px;'>Passed:"+passcount+"</strong><br> <strong style='font-family: Comic Sans MS;font-size: 15px;color:red'>Failed:"+failcount+"</strong><br><br>  <strong style='font-family: Comic Sans MS;font-size: 15px;'>Thank you,<br>AutoClan Team</strong></p>","text/html");
	    //create an instance of multipart object
	    Multipart multipart = new MimeMultipart();
	    //set the first text message part
	    multipart.addBodyPart(messageBodyPart);
	    //set the second part, which is the attachment
	    messageBodyPart = new MimeBodyPart();
	    DataSource source = new FileDataSource(path1);
	    messageBodyPart.setDataHandler(new DataHandler(source));
	    messageBodyPart.setFileName("ReportPDF");
	    multipart.addBodyPart(messageBodyPart);
		    
	    DataSource source2 = new FileDataSource(path2);
	    messageBodyPart.setDataHandler(new DataHandler(source2));
	    messageBodyPart.setFileName("CucumberReport");
	    
	    multipart.addBodyPart(messageBodyPart);
	    //send the entire message parts
	    message.setContent(multipart);
	    //send the email message 
	
	    Transport.send(message);
	    System.out.println("Email Message Sent Successfully");
	      } catch (MessagingException e) {
	    	  e.printStackTrace();	
	         throw new RuntimeException(e);
	      }
	
	}
}
