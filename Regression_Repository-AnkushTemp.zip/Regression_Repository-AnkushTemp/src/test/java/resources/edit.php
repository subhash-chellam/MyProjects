<!DOCTYPE html>

<html  dir="ltr" lang="en" xml:lang="en">
<head>
    <title>Moodle-Stage: Add a new course</title>
    <link rel="shortcut icon" href="https://moodle-stage.laerdalblr.in/theme/image.php/boost/theme/1617770024/favicon" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="moodle, Moodle-Stage: Add a new course" />
<link rel="stylesheet" type="text/css" href="https://moodle-stage.laerdalblr.in/theme/yui_combo.php?rollup/3.17.2/yui-moodlesimple-min.css" /><script id="firstthemesheet" type="text/css">/** Required in order to fix style inclusion problems in IE with YUI **/</script><link rel="stylesheet" type="text/css" href="https://moodle-stage.laerdalblr.in/theme/styles.php/boost/1617770024_1/all" />
<script>
//<![CDATA[
var M = {}; M.yui = {};
M.pageloadstarttime = new Date();
M.cfg = {"wwwroot":"https:\/\/moodle-stage.laerdalblr.in","sesskey":"fZoB308Em3","sessiontimeout":"7200","themerev":"1617770024","slasharguments":1,"theme":"boost","iconsystemmodule":"core\/icon_system_fontawesome","jsrev":"1617770024","admin":"admin","svgicons":true,"usertimezone":"Europe\/London","contextid":958,"langrev":1617770024,"templaterev":"1617770024"};var yui1ConfigFn = function(me) {if(/-skin|reset|fonts|grids|base/.test(me.name)){me.type='css';me.path=me.path.replace(/\.js/,'.css');me.path=me.path.replace(/\/yui2-skin/,'/assets/skins/sam/yui2-skin')}};
var yui2ConfigFn = function(me) {var parts=me.name.replace(/^moodle-/,'').split('-'),component=parts.shift(),module=parts[0],min='-min';if(/-(skin|core)$/.test(me.name)){parts.pop();me.type='css';min=''}
if(module){var filename=parts.join('-');me.path=component+'/'+module+'/'+filename+min+'.'+me.type}else{me.path=component+'/'+component+'.'+me.type}};
YUI_config = {"debug":false,"base":"https:\/\/moodle-stage.laerdalblr.in\/lib\/yuilib\/3.17.2\/","comboBase":"https:\/\/moodle-stage.laerdalblr.in\/theme\/yui_combo.php?","combine":true,"filter":null,"insertBefore":"firstthemesheet","groups":{"yui2":{"base":"https:\/\/moodle-stage.laerdalblr.in\/lib\/yuilib\/2in3\/2.9.0\/build\/","comboBase":"https:\/\/moodle-stage.laerdalblr.in\/theme\/yui_combo.php?","combine":true,"ext":false,"root":"2in3\/2.9.0\/build\/","patterns":{"yui2-":{"group":"yui2","configFn":yui1ConfigFn}}},"moodle":{"name":"moodle","base":"https:\/\/moodle-stage.laerdalblr.in\/theme\/yui_combo.php?m\/1617770024\/","combine":true,"comboBase":"https:\/\/moodle-stage.laerdalblr.in\/theme\/yui_combo.php?","ext":false,"root":"m\/1617770024\/","patterns":{"moodle-":{"group":"moodle","configFn":yui2ConfigFn}},"filter":null,"modules":{"moodle-core-formchangechecker":{"requires":["base","event-focus","moodle-core-event"]},"moodle-core-dragdrop":{"requires":["base","node","io","dom","dd","event-key","event-focus","moodle-core-notification"]},"moodle-core-notification":{"requires":["moodle-core-notification-dialogue","moodle-core-notification-alert","moodle-core-notification-confirm","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-core-notification-dialogue":{"requires":["base","node","panel","escape","event-key","dd-plugin","moodle-core-widget-focusafterclose","moodle-core-lockscroll"]},"moodle-core-notification-alert":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-confirm":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-exception":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-ajaxexception":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-tooltip":{"requires":["base","node","io-base","moodle-core-notification-dialogue","json-parse","widget-position","widget-position-align","event-outside","cache-base"]},"moodle-core-actionmenu":{"requires":["base","event","node-event-simulate"]},"moodle-core-blocks":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification"]},"moodle-core-popuphelp":{"requires":["moodle-core-tooltip"]},"moodle-core-languninstallconfirm":{"requires":["base","node","moodle-core-notification-confirm","moodle-core-notification-alert"]},"moodle-core-event":{"requires":["event-custom"]},"moodle-core-chooserdialogue":{"requires":["base","panel","moodle-core-notification"]},"moodle-core-maintenancemodetimer":{"requires":["base","node"]},"moodle-core-lockscroll":{"requires":["plugin","base-build"]},"moodle-core-handlebars":{"condition":{"trigger":"handlebars","when":"after"}},"moodle-core_availability-form":{"requires":["base","node","event","event-delegate","panel","moodle-core-notification-dialogue","json"]},"moodle-backup-backupselectall":{"requires":["node","event","node-event-simulate","anim"]},"moodle-backup-confirmcancel":{"requires":["node","node-event-simulate","moodle-core-notification-confirm"]},"moodle-course-dragdrop":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification","moodle-course-coursebase","moodle-course-util"]},"moodle-course-modchooser":{"requires":["moodle-core-chooserdialogue","moodle-course-coursebase"]},"moodle-course-util":{"requires":["node"],"use":["moodle-course-util-base"],"submodules":{"moodle-course-util-base":{},"moodle-course-util-section":{"requires":["node","moodle-course-util-base"]},"moodle-course-util-cm":{"requires":["node","moodle-course-util-base"]}}},"moodle-course-management":{"requires":["base","node","io-base","moodle-core-notification-exception","json-parse","dd-constrain","dd-proxy","dd-drop","dd-delegate","node-event-delegate"]},"moodle-course-categoryexpander":{"requires":["node","event-key"]},"moodle-course-formatchooser":{"requires":["base","node","node-event-simulate"]},"moodle-form-shortforms":{"requires":["node","base","selector-css3","moodle-core-event"]},"moodle-form-dateselector":{"requires":["base","node","overlay","calendar"]},"moodle-form-passwordunmask":{"requires":[]},"moodle-question-chooser":{"requires":["moodle-core-chooserdialogue"]},"moodle-question-searchform":{"requires":["base","node"]},"moodle-question-preview":{"requires":["base","dom","event-delegate","event-key","core_question_engine"]},"moodle-availability_completion-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_date-form":{"requires":["base","node","event","io","moodle-core_availability-form"]},"moodle-availability_grade-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_group-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_grouping-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_profile-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-mod_assign-history":{"requires":["node","transition"]},"moodle-mod_quiz-dragdrop":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification","moodle-mod_quiz-quizbase","moodle-mod_quiz-util-base","moodle-mod_quiz-util-page","moodle-mod_quiz-util-slot","moodle-course-util"]},"moodle-mod_quiz-util":{"requires":["node","moodle-core-actionmenu"],"use":["moodle-mod_quiz-util-base"],"submodules":{"moodle-mod_quiz-util-base":{},"moodle-mod_quiz-util-slot":{"requires":["node","moodle-mod_quiz-util-base"]},"moodle-mod_quiz-util-page":{"requires":["node","moodle-mod_quiz-util-base"]}}},"moodle-mod_quiz-quizbase":{"requires":["base","node"]},"moodle-mod_quiz-toolboxes":{"requires":["base","node","event","event-key","io","moodle-mod_quiz-quizbase","moodle-mod_quiz-util-slot","moodle-core-notification-ajaxexception"]},"moodle-mod_quiz-autosave":{"requires":["base","node","event","event-valuechange","node-event-delegate","io-form"]},"moodle-mod_quiz-questionchooser":{"requires":["moodle-core-chooserdialogue","moodle-mod_quiz-util","querystring-parse"]},"moodle-mod_quiz-modform":{"requires":["base","node","event"]},"moodle-message_airnotifier-toolboxes":{"requires":["base","node","io"]},"moodle-filter_glossary-autolinker":{"requires":["base","node","io-base","json-parse","event-delegate","overlay","moodle-core-event","moodle-core-notification-alert","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-filter_mathjaxloader-loader":{"requires":["moodle-core-event"]},"moodle-editor_atto-rangy":{"requires":[]},"moodle-editor_atto-editor":{"requires":["node","transition","io","overlay","escape","event","event-simulate","event-custom","node-event-html5","node-event-simulate","yui-throttle","moodle-core-notification-dialogue","moodle-core-notification-confirm","moodle-editor_atto-rangy","handlebars","timers","querystring-stringify"]},"moodle-editor_atto-plugin":{"requires":["node","base","escape","event","event-outside","handlebars","event-custom","timers","moodle-editor_atto-menu"]},"moodle-editor_atto-menu":{"requires":["moodle-core-notification-dialogue","node","event","event-custom"]},"moodle-report_eventlist-eventfilter":{"requires":["base","event","node","node-event-delegate","datatable","autocomplete","autocomplete-filters"]},"moodle-report_loglive-fetchlogs":{"requires":["base","event","node","io","node-event-delegate"]},"moodle-gradereport_grader-gradereporttable":{"requires":["base","node","event","handlebars","overlay","event-hover"]},"moodle-gradereport_history-userselector":{"requires":["escape","event-delegate","event-key","handlebars","io-base","json-parse","moodle-core-notification-dialogue"]},"moodle-tool_capability-search":{"requires":["base","node"]},"moodle-tool_lp-dragdrop-reorder":{"requires":["moodle-core-dragdrop"]},"moodle-tool_monitor-dropdown":{"requires":["base","event","node"]},"moodle-assignfeedback_editpdf-editor":{"requires":["base","event","node","io","graphics","json","event-move","event-resize","transition","querystring-stringify-simple","moodle-core-notification-dialog","moodle-core-notification-alert","moodle-core-notification-warning","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-atto_accessibilitychecker-button":{"requires":["color-base","moodle-editor_atto-plugin"]},"moodle-atto_accessibilityhelper-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_align-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_bold-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_charmap-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_clear-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_collapse-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_emojipicker-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_emoticon-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_equation-button":{"requires":["moodle-editor_atto-plugin","moodle-core-event","io","event-valuechange","tabview","array-extras"]},"moodle-atto_h5p-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_html-button":{"requires":["promise","moodle-editor_atto-plugin","moodle-atto_html-beautify","moodle-atto_html-codemirror","event-valuechange"]},"moodle-atto_html-codemirror":{"requires":["moodle-atto_html-codemirror-skin"]},"moodle-atto_html-beautify":{},"moodle-atto_image-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_indent-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_italic-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_link-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_managefiles-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_managefiles-usedfiles":{"requires":["node","escape"]},"moodle-atto_media-button":{"requires":["moodle-editor_atto-plugin","moodle-form-shortforms"]},"moodle-atto_noautolink-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_orderedlist-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_recordrtc-button":{"requires":["moodle-editor_atto-plugin","moodle-atto_recordrtc-recording"]},"moodle-atto_recordrtc-recording":{"requires":["moodle-atto_recordrtc-button"]},"moodle-atto_rtl-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_strike-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_subscript-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_superscript-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_table-button":{"requires":["moodle-editor_atto-plugin","moodle-editor_atto-menu","event","event-valuechange"]},"moodle-atto_title-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_underline-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_undo-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_unorderedlist-button":{"requires":["moodle-editor_atto-plugin"]}}},"gallery":{"name":"gallery","base":"https:\/\/moodle-stage.laerdalblr.in\/lib\/yuilib\/gallery\/","combine":true,"comboBase":"https:\/\/moodle-stage.laerdalblr.in\/theme\/yui_combo.php?","ext":false,"root":"gallery\/1617770024\/","patterns":{"gallery-":{"group":"gallery"}}}},"modules":{"core_filepicker":{"name":"core_filepicker","fullpath":"https:\/\/moodle-stage.laerdalblr.in\/lib\/javascript.php\/1617770024\/repository\/filepicker.js","requires":["base","node","node-event-simulate","json","async-queue","io-base","io-upload-iframe","io-form","yui2-treeview","panel","cookie","datatable","datatable-sort","resize-plugin","dd-plugin","escape","moodle-core_filepicker","moodle-core-notification-dialogue"]},"core_comment":{"name":"core_comment","fullpath":"https:\/\/moodle-stage.laerdalblr.in\/lib\/javascript.php\/1617770024\/comment\/comment.js","requires":["base","io-base","node","json","yui2-animation","overlay","escape"]},"mathjax":{"name":"mathjax","fullpath":"https:\/\/cdn.jsdelivr.net\/npm\/mathjax@2.7.8\/MathJax.js?delayStartupUntil=configured"}}};
M.yui.loader = {modules: {}};

//]]>
</script>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body  id="page-course-edit" class="format-site  path-course chrome dir-ltr lang-en yui-skin-sam yui3-skin-sam moodle-stage-laerdalblr-in pagelayout-admin course-1 context-958 drawer-open-left">
<div class="toast-wrapper mx-auto py-0 fixed-top" role="status" aria-live="polite"></div>

<div id="page-wrapper" class="d-print-block">

    <div>
    <a class="sr-only sr-only-focusable" href="#maincontent">Skip to main content</a>
</div><script src="https://moodle-stage.laerdalblr.in/lib/javascript.php/1617770024/lib/babel-polyfill/polyfill.min.js"></script>
<script src="https://moodle-stage.laerdalblr.in/lib/javascript.php/1617770024/lib/mdn-polyfills/polyfill.js"></script>
<script src="https://moodle-stage.laerdalblr.in/theme/yui_combo.php?rollup/3.17.2/yui-moodlesimple-min.js"></script><script src="https://moodle-stage.laerdalblr.in/lib/javascript.php/1617770024/lib/javascript-static.js"></script>
<script>
//<![CDATA[
document.body.className += ' jsenabled';
//]]>
</script>



    <nav class="fixed-top navbar navbar-light bg-white navbar-expand moodle-has-zindex" aria-label="Site navigation">
    
            <div data-region="drawer-toggle" class="d-inline-block mr-3">
                <button aria-expanded="true" aria-controls="nav-drawer" type="button" class="btn nav-link float-sm-left mr-1 btn-light bg-gray" data-action="toggle-drawer" data-side="left" data-preference="drawer-open-nav"><i class="icon fa fa-bars fa-fw " aria-hidden="true"  ></i><span class="sr-only">Side panel</span></button>
            </div>
    
            <a href="https://moodle-stage.laerdalblr.in" class="navbar-brand 
                    d-none d-sm-inline
                    ">
                <span class="site-name d-none d-md-inline">Moodle-Stage</span>
            </a>
    
            <ul class="navbar-nav d-none d-md-flex">
                <!-- custom_menu -->
                
                <!-- page_heading_menu -->
                
            </ul>
            <ul class="nav navbar-nav ml-auto">
                <li class="d-none d-lg-block">
                    
                </li>
                <!-- navbar_plugin_output -->
                <li class="nav-item">
                    <div class="popover-region collapsed popover-region-notifications"
    id="nav-notification-popover-container" data-userid="130"
    data-region="popover-region">
    <div class="popover-region-toggle nav-link"
        data-region="popover-region-toggle"
        role="button"
        aria-controls="popover-region-container-65781ca72c92365781ca719c2e2"
        aria-haspopup="true"
        aria-label="Show notification window with no new notifications"
        tabindex="0">
                <i class="icon fa fa-bell fa-fw "  title="Toggle notifications menu" aria-label="Toggle notifications menu"></i>
        <div class="count-container hidden" data-region="count-container"
        aria-label="There are 0 unread notifications">0</div>

    </div>
    <div 
        id="popover-region-container-65781ca72c92365781ca719c2e2"
        class="popover-region-container"
        data-region="popover-region-container"
        aria-expanded="false"
        aria-hidden="true"
        aria-label="Notification window"
        role="region">
        <div class="popover-region-header-container">
            <h3 class="popover-region-header-text" data-region="popover-region-header-text">Notifications</h3>
            <div class="popover-region-header-actions" data-region="popover-region-header-actions">        <a class="mark-all-read-button"
           href="#"
           title="Mark all as read"
           data-action="mark-all-read"
           role="button"
           aria-label="Mark all as read">
            <span class="normal-icon"><i class="icon fa fa-check fa-fw " aria-hidden="true"  ></i></span>
            <span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
        </a>
        <a href="https://moodle-stage.laerdalblr.in/message/notificationpreferences.php?userid=130"
           title="Notification preferences"
           aria-label="Notification preferences">
            <i class="icon fa fa-cog fa-fw " aria-hidden="true"  ></i>
        </a>
</div>
        </div>
        <div class="popover-region-content-container" data-region="popover-region-content-container">
            <div class="popover-region-content" data-region="popover-region-content">
                        <div class="all-notifications"
            data-region="all-notifications"
            role="log"
            aria-busy="false"
            aria-atomic="false"
            aria-relevant="additions"></div>
        <div class="empty-message" tabindex="0" data-region="empty-message">You have no notifications</div>

            </div>
            <span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
        </div>
                <a class="see-all-link"
                    href="https://moodle-stage.laerdalblr.in/message/output/popup/notifications.php">
                    <div class="popover-region-footer-container">
                        <div class="popover-region-seeall-text">See all</div>
                    </div>
                </a>
    </div>
</div><div class="popover-region collapsed" data-region="popover-region-messages">
    <a id="message-drawer-toggle-65781ca73117865781ca719c2e3" class="nav-link d-inline-block popover-region-toggle position-relative" href="#"
            role="button">
        <i class="icon fa fa-comment fa-fw "  title="Toggle messaging drawer" aria-label="Toggle messaging drawer"></i>
        <div class="count-container hidden" data-region="count-container"
        aria-label="There are 0 unread conversations">0</div>
    </a>
    <span class="sr-only sr-only-focusable" data-region="jumpto" tabindex="-1"></span></div>
                </li>
                <!-- user_menu -->
                <li class="nav-item d-flex align-items-center">
                    <div class="usermenu"><div class="action-menu moodle-actionmenu nowrap-items d-inline" id="action-menu-1" data-enhance="moodle-core-actionmenu">

        <div class="menubar d-flex " id="action-menu-1-menubar" role="menubar">

            


                <div class="action-menu-trigger">
                    <div class="dropdown">
                        <a href="#" tabindex="0" class=" dropdown-toggle icon-no-margin" id="action-menu-toggle-1" aria-label="User menu" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" aria-controls="action-menu-1-menu">
                            
                            <span class="userbutton"><span class="usertext mr-1">Test Auto</span><span class="avatars"><span class="avatar current"><img src="https://moodle-stage.laerdalblr.in/theme/image.php/boost/core/1617770024/u/f2" class="userpicture defaultuserpic" width="35" height="35" aria-hidden="true" /></span></span></span>
                                
                            <b class="caret"></b>
                        </a>
                            <div class="dropdown-menu dropdown-menu-right menu  align-tr-br" id="action-menu-1-menu" data-rel="menu-content" aria-labelledby="action-menu-toggle-1" role="menu" data-align="tr-br">
                                                                <a href="https://moodle-stage.laerdalblr.in/my/" class="dropdown-item menu-action" role="menuitem" data-title="mymoodle,admin" aria-labelledby="actionmenuaction-1">
                                <i class="icon fa fa-tachometer fa-fw " aria-hidden="true"  ></i>
                                <span class="menu-action-text" id="actionmenuaction-1">Dashboard</span>
                        </a>
                    <div class="dropdown-divider" role="presentation"><span class="filler">&nbsp;</span></div>
                                                                <a href="https://moodle-stage.laerdalblr.in/user/profile.php?id=130" class="dropdown-item menu-action" role="menuitem" data-title="profile,moodle" aria-labelledby="actionmenuaction-2">
                                <i class="icon fa fa-user fa-fw " aria-hidden="true"  ></i>
                                <span class="menu-action-text" id="actionmenuaction-2">Profile</span>
                        </a>
                                                                <a href="https://moodle-stage.laerdalblr.in/grade/report/overview/index.php" class="dropdown-item menu-action" role="menuitem" data-title="grades,grades" aria-labelledby="actionmenuaction-3">
                                <i class="icon fa fa-table fa-fw " aria-hidden="true"  ></i>
                                <span class="menu-action-text" id="actionmenuaction-3">Grades</span>
                        </a>
                                                                <a href="https://moodle-stage.laerdalblr.in/message/index.php" class="dropdown-item menu-action" role="menuitem" data-title="messages,message" aria-labelledby="actionmenuaction-4">
                                <i class="icon fa fa-comment fa-fw " aria-hidden="true"  ></i>
                                <span class="menu-action-text" id="actionmenuaction-4">Messages</span>
                        </a>
                                                                <a href="https://moodle-stage.laerdalblr.in/user/preferences.php" class="dropdown-item menu-action" role="menuitem" data-title="preferences,moodle" aria-labelledby="actionmenuaction-5">
                                <i class="icon fa fa-wrench fa-fw " aria-hidden="true"  ></i>
                                <span class="menu-action-text" id="actionmenuaction-5">Preferences</span>
                        </a>
                                                                <a href="https://moodle-stage.laerdalblr.in/login/logout.php?sesskey=fZoB308Em3" class="dropdown-item menu-action" role="menuitem" data-title="logout,moodle" aria-labelledby="actionmenuaction-6">
                                <i class="icon fa fa-sign-out fa-fw " aria-hidden="true"  ></i>
                                <span class="menu-action-text" id="actionmenuaction-6">Log out</span>
                        </a>
                    <div class="dropdown-divider" role="presentation"><span class="filler">&nbsp;</span></div>
                                                                <a href="https://moodle-stage.laerdalblr.in/course/switchrole.php?id=1&amp;switchrole=-1&amp;returnurl=%2Fcourse%2Fedit.php%3Fcategory%3D0" class="dropdown-item menu-action" role="menuitem" data-title="switchroleto,moodle" aria-labelledby="actionmenuaction-7">
                                <i class="icon fa fa-user-secret fa-fw " aria-hidden="true"  ></i>
                                <span class="menu-action-text" id="actionmenuaction-7">Switch role to...</span>
                        </a>
                            </div>
                    </div>
                </div>

        </div>

</div></div>
                </li>
            </ul>
            <!-- search_box -->
    </nav>
    
    <div id="nav-drawer" data-region="drawer" class="d-print-none moodle-has-zindex " aria-hidden="false" tabindex="-1">
        <nav class="list-group" aria-label="Site">
            <ul>
                    <li>
                        <a class="list-group-item list-group-item-action  " href="https://moodle-stage.laerdalblr.in/my/" data-key="myhome" data-isexpandable="0" data-indent="0" data-showdivider="0" data-type="1" data-nodetype="1" data-collapse="0" data-forceopen="1" data-isactive="0" data-hidden="0" data-preceedwithhr="0" >
                            <div class="ml-0">
                                <div class="media">
                                        <span class="media-left">
                                            <i class="icon fa fa-tachometer fa-fw " aria-hidden="true"  ></i>
                                        </span>
                                    <span class="media-body ">Dashboard</span>
                                </div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a class="list-group-item list-group-item-action  " href="https://moodle-stage.laerdalblr.in/?redirect=0" data-key="home" data-isexpandable="0" data-indent="0" data-showdivider="0" data-type="70" data-nodetype="0" data-collapse="0" data-forceopen="0" data-isactive="0" data-hidden="0" data-preceedwithhr="0" data-parent-key="myhome">
                            <div class="ml-0">
                                <div class="media">
                                        <span class="media-left">
                                            <i class="icon fa fa-home fa-fw " aria-hidden="true"  ></i>
                                        </span>
                                    <span class="media-body ">Site home</span>
                                </div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a class="list-group-item list-group-item-action  " href="https://moodle-stage.laerdalblr.in/calendar/view.php?view=month" data-key="calendar" data-isexpandable="0" data-indent="0" data-showdivider="0" data-type="60" data-nodetype="0" data-collapse="0" data-forceopen="0" data-isactive="0" data-hidden="0" data-preceedwithhr="0" data-parent-key="1">
                            <div class="ml-0">
                                <div class="media">
                                        <span class="media-left">
                                            <i class="icon fa fa-calendar fa-fw " aria-hidden="true"  ></i>
                                        </span>
                                    <span class="media-body ">Calendar</span>
                                </div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a class="list-group-item list-group-item-action  " href="https://moodle-stage.laerdalblr.in/user/files.php" data-key="privatefiles" data-isexpandable="0" data-indent="0" data-showdivider="0" data-type="70" data-nodetype="0" data-collapse="0" data-forceopen="0" data-isactive="0" data-hidden="0" data-preceedwithhr="0" data-parent-key="1">
                            <div class="ml-0">
                                <div class="media">
                                        <span class="media-left">
                                            <i class="icon fa fa-file-o fa-fw " aria-hidden="true"  ></i>
                                        </span>
                                    <span class="media-body ">Private files</span>
                                </div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <div class="list-group-item " data-key="mycourses" data-isexpandable="1" data-indent="0" data-showdivider="0" data-type="0" data-nodetype="1" data-collapse="0" data-forceopen="1" data-isactive="0" data-hidden="0" data-preceedwithhr="0" data-parent-key="myhome">
                            <div class="ml-0">
                                <div class="media">
                                        <span class="media-left">
                                            <i class="icon fa fa-graduation-cap fa-fw " aria-hidden="true"  ></i>
                                        </span>
                                    <span class="media-body">My courses</span>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li>
                        <a class="list-group-item list-group-item-action  " href="https://moodle-stage.laerdalblr.in/course/view.php?id=214" data-key="214" data-isexpandable="1" data-indent="1" data-showdivider="0" data-type="20" data-nodetype="1" data-collapse="0" data-forceopen="0" data-isactive="0" data-hidden="0" data-preceedwithhr="0" data-parent-key="mycourses">
                            <div class="ml-1">
                                <div class="media">
                                        <span class="media-left">
                                            <i class="icon fa fa-graduation-cap fa-fw " aria-hidden="true"  ></i>
                                        </span>
                                    <span class="media-body ">RQI for NRP Essentials Prep2212:38:16</span>
                                </div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a class="list-group-item list-group-item-action  " href="https://moodle-stage.laerdalblr.in/course/view.php?id=213" data-key="213" data-isexpandable="1" data-indent="1" data-showdivider="0" data-type="20" data-nodetype="1" data-collapse="0" data-forceopen="0" data-isactive="0" data-hidden="0" data-preceedwithhr="0" data-parent-key="mycourses">
                            <div class="ml-1">
                                <div class="media">
                                        <span class="media-left">
                                            <i class="icon fa fa-graduation-cap fa-fw " aria-hidden="true"  ></i>
                                        </span>
                                    <span class="media-body ">RQI for NRP Essentials Prep2121:49:28</span>
                                </div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a class="list-group-item list-group-item-action  " href="https://moodle-stage.laerdalblr.in/course/view.php?id=212" data-key="212" data-isexpandable="1" data-indent="1" data-showdivider="0" data-type="20" data-nodetype="1" data-collapse="0" data-forceopen="0" data-isactive="0" data-hidden="0" data-preceedwithhr="0" data-parent-key="mycourses">
                            <div class="ml-1">
                                <div class="media">
                                        <span class="media-left">
                                            <i class="icon fa fa-graduation-cap fa-fw " aria-hidden="true"  ></i>
                                        </span>
                                    <span class="media-body ">RQI for NRP Essentials Prep2121:45:07</span>
                                </div>
                            </div>
                        </a>
                    </li>
                    </ul>
                    </nav>
                    <nav class="list-group mt-1" aria-label="Site settings">
                    <ul>
                    <li>
                        <a class="list-group-item list-group-item-action  root_node " href="https://moodle-stage.laerdalblr.in/admin/search.php" data-key="sitesettings" data-isexpandable="0" data-indent="0" data-showdivider="1" data-type="71" data-nodetype="1" data-collapse="0" data-forceopen="1" data-isactive="0" data-hidden="0" data-preceedwithhr="0" >
                            <div class="ml-0">
                                <div class="media">
                                        <span class="media-left">
                                            <i class="icon fa fa-wrench fa-fw " aria-hidden="true"  ></i>
                                        </span>
                                    <span class="media-body ">Site administration</span>
                                </div>
                            </div>
                        </a>
                    </li>
            </ul>
        </nav>
    </div>

    <div id="page" class="container-fluid d-print-block">
        <header id="page-header" class="row">
    <div class="col-12 pt-3 pb-3">
        <div class="card ">
            <div class="card-body ">
                <div class="d-flex align-items-center">
                    <div class="mr-auto">
                        <div class="page-context-header"><div class="page-header-headings"><h1>Moodle-Stage</h1></div></div>
                    </div>

                    <div class="header-actions-container flex-shrink-0" data-region="header-actions-container">
                    </div>
                </div>
                <div class="d-flex flex-wrap">
                    <div id="page-navbar">
                        <nav aria-label="Navigation bar">
    <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="https://moodle-stage.laerdalblr.in/my/"  >Dashboard</a>
                </li>
                <li class="breadcrumb-item">
                    <a href="https://moodle-stage.laerdalblr.in/admin/search.php"  >Site administration</a>
                </li>
                <li class="breadcrumb-item">
                    <a href="https://moodle-stage.laerdalblr.in/admin/category.php?category=courses"  >Courses</a>
                </li>
                <li class="breadcrumb-item">
                    <a href="https://moodle-stage.laerdalblr.in/course/management.php"  >Manage courses and categories</a>
                </li>
                <li class="breadcrumb-item">Add a new course</li>
    </ol>
</nav>
                    </div>
                    <div class="ml-auto d-flex">
                        
                    </div>
                    <div id="course-header">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

        <div id="page-content" class="row pb-3 d-print-block">
            <div id="region-main-box" class="col-12">
                <section id="region-main"  aria-label="Content">

                    <span class="notifications" id="user-notifications"></span>
                    <div role="main"><span id="maincontent"></span><h2>Add a new course</h2>
<form autocomplete="off" action="https://moodle-stage.laerdalblr.in/course/edit.php" method="post" accept-charset="utf-8" id="mform1_2UgX3cbcrCd9RgL" class="mform">
	<div style="display: none;"><input name="returnto" type="hidden" value="0" />
<input name="returnurl" type="hidden" value="https://moodle-stage.laerdalblr.in/course/" />
<input name="mform_isexpanded_id_descriptionhdr" type="hidden" value="1" />
<input name="addcourseformatoptionshere" type="hidden" value="" />
<input name="id" type="hidden" value="" />
<input name="sesskey" type="hidden" value="fZoB308Em3" />
<input name="_qf__course_edit_form" type="hidden" value="1" />
<input name="mform_isexpanded_id_general" type="hidden" value="1" />
<input name="mform_isexpanded_id_courseformathdr" type="hidden" value="0" />
<input name="mform_isexpanded_id_appearancehdr" type="hidden" value="0" />
<input name="mform_isexpanded_id_filehdr" type="hidden" value="0" />
<input name="mform_isexpanded_id_completionhdr" type="hidden" value="0" />
<input name="mform_isexpanded_id_groups" type="hidden" value="0" />
<input name="mform_isexpanded_id_rolerenaming" type="hidden" value="0" />
<input name="mform_isexpanded_id_tagshdr" type="hidden" value="0" />
</div>

	<div class="collapsible-actions"><span class="collapseexpand">Expand all</span></div>

	<fieldset class="clearfix collapsible"  id="id_general">
		<legend class="ftoggler">General</legend>
		<div class="fcontainer clearfix">
		<div id="fitem_id_fullname" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            <abbr class="initialism text-danger" title="Required"><i class="icon fa fa-exclamation-circle text-danger fa-fw "  title="Required" aria-label="Required"></i></abbr>
            
            <a class="btn btn-link p-0" role="button"
    data-container="body" data-toggle="popover"
    data-placement="right" data-content="&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;The full name of the course is displayed at the top of each page in the course and in the list of courses.&lt;/p&gt;
&lt;/div&gt; "
    data-html="true" tabindex="0" data-trigger="focus">
  <i class="icon fa fa-question-circle text-info fa-fw "  title="Help with Course full name" aria-label="Help with Course full name"></i>
</a>
        </span>
        
                <label class="col-form-label d-inline " for="id_fullname">
                    Course full name
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="text">
        <input type="text"
                class="form-control "
                name="fullname"
                id="id_fullname"
                value=""
                size="50"
                maxlength="254" >
        <div class="form-control-feedback invalid-feedback" id="id_error_fullname" >
            
        </div>
    </div>
</div><div id="fitem_id_shortname" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            <abbr class="initialism text-danger" title="Required"><i class="icon fa fa-exclamation-circle text-danger fa-fw "  title="Required" aria-label="Required"></i></abbr>
            
            <a class="btn btn-link p-0" role="button"
    data-container="body" data-toggle="popover"
    data-placement="right" data-content="&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;The short name of the course is displayed in the navigation and is used in the subject line of course email messages.&lt;/p&gt;
&lt;/div&gt; "
    data-html="true" tabindex="0" data-trigger="focus">
  <i class="icon fa fa-question-circle text-info fa-fw "  title="Help with Course short name" aria-label="Help with Course short name"></i>
</a>
        </span>
        
                <label class="col-form-label d-inline " for="id_shortname">
                    Course short name
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="text">
        <input type="text"
                class="form-control "
                name="shortname"
                id="id_shortname"
                value=""
                size="20"
                maxlength="100" >
        <div class="form-control-feedback invalid-feedback" id="id_error_shortname" >
            
        </div>
    </div>
</div><div id="fitem_id_category" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            <a class="btn btn-link p-0" role="button"
    data-container="body" data-toggle="popover"
    data-placement="right" data-content="&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;This setting determines the category in which the course will appear in the list of courses.&lt;/p&gt;
&lt;/div&gt; "
    data-html="true" tabindex="0" data-trigger="focus">
  <i class="icon fa fa-question-circle text-info fa-fw "  title="Help with Course category" aria-label="Help with Course category"></i>
</a>
        </span>
        
                <label class="col-form-label d-inline " for="id_category">
                    Course category
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="select">
        <select class="custom-select
                       
                       "
            name="category"
            id="id_category"
            
            
             >
            <option value="6" selected 
                >TR P1 Reproduce</option>
            <option value="3"  
                >QA</option>
            <option value="7"  
                >Prod courses</option>
            <option value="2"  
                >Pre-prod</option>
            <option value="5"  
                >NRP Courses</option>
            <option value="1"  
                >Miscellaneous</option>
            <option value="4"  
                >LLP-courses</option>
            <option value="8"  
                >NLN RQI BLS Ready 2025_StudentPay</option>
            <option value="9"  
                >L3</option>
        </select>
        <div class="form-control-feedback invalid-feedback" id="id_error_category" >
            
        </div>
    </div>
</div><div id="fitem_id_visible" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            <a class="btn btn-link p-0" role="button"
    data-container="body" data-toggle="popover"
    data-placement="right" data-content="&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;This setting determines whether the course appears in the list of courses and whether students can access it. If set to Hide, then access is restricted to users with the capability to view hidden courses (such as teachers).&lt;/p&gt;
&lt;/div&gt; "
    data-html="true" tabindex="0" data-trigger="focus">
  <i class="icon fa fa-question-circle text-info fa-fw "  title="Help with Course visibility" aria-label="Help with Course visibility"></i>
</a>
        </span>
        
                <label class="col-form-label d-inline " for="id_visible">
                    Course visibility
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="select">
        <select class="custom-select
                       
                       "
            name="visible"
            id="id_visible"
            
            
             >
            <option value="0"  
                >Hide</option>
            <option value="1" selected 
                >Show</option>
        </select>
        <div class="form-control-feedback invalid-feedback" id="id_error_visible" >
            
        </div>
    </div>
</div><div id="fitem_id_startdate" class="form-group row  fitem   " data-groupname="startdate">
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            <a class="btn btn-link p-0" role="button"
    data-container="body" data-toggle="popover"
    data-placement="right" data-content="&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;This setting determines the start of the first week for a course in weekly format. It also determines the earliest date that logs of course activities are available for. If the course is reset and the course start date changed, all dates in the course will be moved in relation to the new start date.&lt;/p&gt;
&lt;/div&gt; "
    data-html="true" tabindex="0" data-trigger="focus">
  <i class="icon fa fa-question-circle text-info fa-fw "  title="Help with Course start date" aria-label="Help with Course start date"></i>
</a>
        </span>
                    <p id="id_startdate_label" class="col-form-label d-inline" aria-hidden="true">
                Course start date
            </p>

    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="date_time_selector">
        <fieldset class="m-0 p-0 border-0" id="id_startdate">
            <legend class="sr-only">Course start date</legend>
            <div class="fdate_time_selector d-flex flex-wrap align-items-center">
                
                <div class="form-group  fitem  " >
        <label class="col-form-label sr-only" for="id_startdate_day">
            Day
        </label>
    <span>
        
        
        
    </span>
    <span data-fieldtype="select">
    <select class="custom-select
                   
                   "
        name="startdate[day]"
        id="id_startdate_day"
        
        
         >
        <option value="1"   >1</option>
        <option value="2"   >2</option>
        <option value="3"   >3</option>
        <option value="4"   >4</option>
        <option value="5"   >5</option>
        <option value="6"   >6</option>
        <option value="7"   >7</option>
        <option value="8"   >8</option>
        <option value="9"   >9</option>
        <option value="10"   >10</option>
        <option value="11"   >11</option>
        <option value="12"   >12</option>
        <option value="13" selected  >13</option>
        <option value="14"   >14</option>
        <option value="15"   >15</option>
        <option value="16"   >16</option>
        <option value="17"   >17</option>
        <option value="18"   >18</option>
        <option value="19"   >19</option>
        <option value="20"   >20</option>
        <option value="21"   >21</option>
        <option value="22"   >22</option>
        <option value="23"   >23</option>
        <option value="24"   >24</option>
        <option value="25"   >25</option>
        <option value="26"   >26</option>
        <option value="27"   >27</option>
        <option value="28"   >28</option>
        <option value="29"   >29</option>
        <option value="30"   >30</option>
        <option value="31"   >31</option>
    </select>
    </span>
    <div class="form-control-feedback invalid-feedback" id="id_error_startdate_day" >
        
    </div>
</div>
                &nbsp;
                <div class="form-group  fitem  " >
        <label class="col-form-label sr-only" for="id_startdate_month">
            Month
        </label>
    <span>
        
        
        
    </span>
    <span data-fieldtype="select">
    <select class="custom-select
                   
                   "
        name="startdate[month]"
        id="id_startdate_month"
        
        
         >
        <option value="1"   >January</option>
        <option value="2"   >February</option>
        <option value="3"   >March</option>
        <option value="4"   >April</option>
        <option value="5"   >May</option>
        <option value="6"   >June</option>
        <option value="7"   >July</option>
        <option value="8"   >August</option>
        <option value="9"   >September</option>
        <option value="10"   >October</option>
        <option value="11"   >November</option>
        <option value="12" selected  >December</option>
    </select>
    </span>
    <div class="form-control-feedback invalid-feedback" id="id_error_startdate_month" >
        
    </div>
</div>
                &nbsp;
                <div class="form-group  fitem  " >
        <label class="col-form-label sr-only" for="id_startdate_year">
            Year
        </label>
    <span>
        
        
        
    </span>
    <span data-fieldtype="select">
    <select class="custom-select
                   
                   "
        name="startdate[year]"
        id="id_startdate_year"
        
        
         >
        <option value="1900"   >1900</option>
        <option value="1901"   >1901</option>
        <option value="1902"   >1902</option>
        <option value="1903"   >1903</option>
        <option value="1904"   >1904</option>
        <option value="1905"   >1905</option>
        <option value="1906"   >1906</option>
        <option value="1907"   >1907</option>
        <option value="1908"   >1908</option>
        <option value="1909"   >1909</option>
        <option value="1910"   >1910</option>
        <option value="1911"   >1911</option>
        <option value="1912"   >1912</option>
        <option value="1913"   >1913</option>
        <option value="1914"   >1914</option>
        <option value="1915"   >1915</option>
        <option value="1916"   >1916</option>
        <option value="1917"   >1917</option>
        <option value="1918"   >1918</option>
        <option value="1919"   >1919</option>
        <option value="1920"   >1920</option>
        <option value="1921"   >1921</option>
        <option value="1922"   >1922</option>
        <option value="1923"   >1923</option>
        <option value="1924"   >1924</option>
        <option value="1925"   >1925</option>
        <option value="1926"   >1926</option>
        <option value="1927"   >1927</option>
        <option value="1928"   >1928</option>
        <option value="1929"   >1929</option>
        <option value="1930"   >1930</option>
        <option value="1931"   >1931</option>
        <option value="1932"   >1932</option>
        <option value="1933"   >1933</option>
        <option value="1934"   >1934</option>
        <option value="1935"   >1935</option>
        <option value="1936"   >1936</option>
        <option value="1937"   >1937</option>
        <option value="1938"   >1938</option>
        <option value="1939"   >1939</option>
        <option value="1940"   >1940</option>
        <option value="1941"   >1941</option>
        <option value="1942"   >1942</option>
        <option value="1943"   >1943</option>
        <option value="1944"   >1944</option>
        <option value="1945"   >1945</option>
        <option value="1946"   >1946</option>
        <option value="1947"   >1947</option>
        <option value="1948"   >1948</option>
        <option value="1949"   >1949</option>
        <option value="1950"   >1950</option>
        <option value="1951"   >1951</option>
        <option value="1952"   >1952</option>
        <option value="1953"   >1953</option>
        <option value="1954"   >1954</option>
        <option value="1955"   >1955</option>
        <option value="1956"   >1956</option>
        <option value="1957"   >1957</option>
        <option value="1958"   >1958</option>
        <option value="1959"   >1959</option>
        <option value="1960"   >1960</option>
        <option value="1961"   >1961</option>
        <option value="1962"   >1962</option>
        <option value="1963"   >1963</option>
        <option value="1964"   >1964</option>
        <option value="1965"   >1965</option>
        <option value="1966"   >1966</option>
        <option value="1967"   >1967</option>
        <option value="1968"   >1968</option>
        <option value="1969"   >1969</option>
        <option value="1970"   >1970</option>
        <option value="1971"   >1971</option>
        <option value="1972"   >1972</option>
        <option value="1973"   >1973</option>
        <option value="1974"   >1974</option>
        <option value="1975"   >1975</option>
        <option value="1976"   >1976</option>
        <option value="1977"   >1977</option>
        <option value="1978"   >1978</option>
        <option value="1979"   >1979</option>
        <option value="1980"   >1980</option>
        <option value="1981"   >1981</option>
        <option value="1982"   >1982</option>
        <option value="1983"   >1983</option>
        <option value="1984"   >1984</option>
        <option value="1985"   >1985</option>
        <option value="1986"   >1986</option>
        <option value="1987"   >1987</option>
        <option value="1988"   >1988</option>
        <option value="1989"   >1989</option>
        <option value="1990"   >1990</option>
        <option value="1991"   >1991</option>
        <option value="1992"   >1992</option>
        <option value="1993"   >1993</option>
        <option value="1994"   >1994</option>
        <option value="1995"   >1995</option>
        <option value="1996"   >1996</option>
        <option value="1997"   >1997</option>
        <option value="1998"   >1998</option>
        <option value="1999"   >1999</option>
        <option value="2000"   >2000</option>
        <option value="2001"   >2001</option>
        <option value="2002"   >2002</option>
        <option value="2003"   >2003</option>
        <option value="2004"   >2004</option>
        <option value="2005"   >2005</option>
        <option value="2006"   >2006</option>
        <option value="2007"   >2007</option>
        <option value="2008"   >2008</option>
        <option value="2009"   >2009</option>
        <option value="2010"   >2010</option>
        <option value="2011"   >2011</option>
        <option value="2012"   >2012</option>
        <option value="2013"   >2013</option>
        <option value="2014"   >2014</option>
        <option value="2015"   >2015</option>
        <option value="2016"   >2016</option>
        <option value="2017"   >2017</option>
        <option value="2018"   >2018</option>
        <option value="2019"   >2019</option>
        <option value="2020"   >2020</option>
        <option value="2021"   >2021</option>
        <option value="2022"   >2022</option>
        <option value="2023" selected  >2023</option>
        <option value="2024"   >2024</option>
        <option value="2025"   >2025</option>
        <option value="2026"   >2026</option>
        <option value="2027"   >2027</option>
        <option value="2028"   >2028</option>
        <option value="2029"   >2029</option>
        <option value="2030"   >2030</option>
        <option value="2031"   >2031</option>
        <option value="2032"   >2032</option>
        <option value="2033"   >2033</option>
        <option value="2034"   >2034</option>
        <option value="2035"   >2035</option>
        <option value="2036"   >2036</option>
        <option value="2037"   >2037</option>
        <option value="2038"   >2038</option>
        <option value="2039"   >2039</option>
        <option value="2040"   >2040</option>
        <option value="2041"   >2041</option>
        <option value="2042"   >2042</option>
        <option value="2043"   >2043</option>
        <option value="2044"   >2044</option>
        <option value="2045"   >2045</option>
        <option value="2046"   >2046</option>
        <option value="2047"   >2047</option>
        <option value="2048"   >2048</option>
        <option value="2049"   >2049</option>
        <option value="2050"   >2050</option>
    </select>
    </span>
    <div class="form-control-feedback invalid-feedback" id="id_error_startdate_year" >
        
    </div>
</div>
                &nbsp;
                <div class="form-group  fitem  " >
        <label class="col-form-label sr-only" for="id_startdate_hour">
            Hour
        </label>
    <span>
        
        
        
    </span>
    <span data-fieldtype="select">
    <select class="custom-select
                   
                   "
        name="startdate[hour]"
        id="id_startdate_hour"
        
        
         >
        <option value="0" selected  >00</option>
        <option value="1"   >01</option>
        <option value="2"   >02</option>
        <option value="3"   >03</option>
        <option value="4"   >04</option>
        <option value="5"   >05</option>
        <option value="6"   >06</option>
        <option value="7"   >07</option>
        <option value="8"   >08</option>
        <option value="9"   >09</option>
        <option value="10"   >10</option>
        <option value="11"   >11</option>
        <option value="12"   >12</option>
        <option value="13"   >13</option>
        <option value="14"   >14</option>
        <option value="15"   >15</option>
        <option value="16"   >16</option>
        <option value="17"   >17</option>
        <option value="18"   >18</option>
        <option value="19"   >19</option>
        <option value="20"   >20</option>
        <option value="21"   >21</option>
        <option value="22"   >22</option>
        <option value="23"   >23</option>
    </select>
    </span>
    <div class="form-control-feedback invalid-feedback" id="id_error_startdate_hour" >
        
    </div>
</div>
                &nbsp;
                <div class="form-group  fitem  " >
        <label class="col-form-label sr-only" for="id_startdate_minute">
            Minute
        </label>
    <span>
        
        
        
    </span>
    <span data-fieldtype="select">
    <select class="custom-select
                   
                   "
        name="startdate[minute]"
        id="id_startdate_minute"
        
        
         >
        <option value="0" selected  >00</option>
        <option value="1"   >01</option>
        <option value="2"   >02</option>
        <option value="3"   >03</option>
        <option value="4"   >04</option>
        <option value="5"   >05</option>
        <option value="6"   >06</option>
        <option value="7"   >07</option>
        <option value="8"   >08</option>
        <option value="9"   >09</option>
        <option value="10"   >10</option>
        <option value="11"   >11</option>
        <option value="12"   >12</option>
        <option value="13"   >13</option>
        <option value="14"   >14</option>
        <option value="15"   >15</option>
        <option value="16"   >16</option>
        <option value="17"   >17</option>
        <option value="18"   >18</option>
        <option value="19"   >19</option>
        <option value="20"   >20</option>
        <option value="21"   >21</option>
        <option value="22"   >22</option>
        <option value="23"   >23</option>
        <option value="24"   >24</option>
        <option value="25"   >25</option>
        <option value="26"   >26</option>
        <option value="27"   >27</option>
        <option value="28"   >28</option>
        <option value="29"   >29</option>
        <option value="30"   >30</option>
        <option value="31"   >31</option>
        <option value="32"   >32</option>
        <option value="33"   >33</option>
        <option value="34"   >34</option>
        <option value="35"   >35</option>
        <option value="36"   >36</option>
        <option value="37"   >37</option>
        <option value="38"   >38</option>
        <option value="39"   >39</option>
        <option value="40"   >40</option>
        <option value="41"   >41</option>
        <option value="42"   >42</option>
        <option value="43"   >43</option>
        <option value="44"   >44</option>
        <option value="45"   >45</option>
        <option value="46"   >46</option>
        <option value="47"   >47</option>
        <option value="48"   >48</option>
        <option value="49"   >49</option>
        <option value="50"   >50</option>
        <option value="51"   >51</option>
        <option value="52"   >52</option>
        <option value="53"   >53</option>
        <option value="54"   >54</option>
        <option value="55"   >55</option>
        <option value="56"   >56</option>
        <option value="57"   >57</option>
        <option value="58"   >58</option>
        <option value="59"   >59</option>
    </select>
    </span>
    <div class="form-control-feedback invalid-feedback" id="id_error_startdate_minute" >
        
    </div>
</div>
                &nbsp;
                <a class="visibleifjs" name="startdate[calendar]" href="#" id="id_startdate_calendar"><i class="icon fa fa-calendar fa-fw "  title="Calendar" aria-label="Calendar"></i></a>
            </div>
        </fieldset>
        <div class="form-control-feedback invalid-feedback" id="id_error_startdate" >
            
        </div>
    </div>
</div><div id="fitem_id_enddate" class="form-group row  fitem   " data-groupname="enddate">
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            <a class="btn btn-link p-0" role="button"
    data-container="body" data-toggle="popover"
    data-placement="right" data-content="&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;The course end date is used for determining whether a course should be included in a user&#039;s list of courses. When the end date is past, the course is no longer listed in the navigation and is listed as past in the course overview. The course end date may also be used by custom reports. Users can still enter the course after the end date; in other words the date does not restrict access.&lt;/p&gt;
&lt;/div&gt; "
    data-html="true" tabindex="0" data-trigger="focus">
  <i class="icon fa fa-question-circle text-info fa-fw "  title="Help with Course end date" aria-label="Help with Course end date"></i>
</a>
        </span>
                    <p id="id_enddate_label" class="col-form-label d-inline" aria-hidden="true">
                Course end date
            </p>

    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="date_time_selector">
        <fieldset class="m-0 p-0 border-0" id="id_enddate">
            <legend class="sr-only">Course end date</legend>
            <div class="fdate_time_selector d-flex flex-wrap align-items-center">
                
                <div class="form-group  fitem  " >
        <label class="col-form-label sr-only" for="id_enddate_day">
            Day
        </label>
    <span>
        
        
        
    </span>
    <span data-fieldtype="select">
    <select class="custom-select
                   
                   "
        name="enddate[day]"
        id="id_enddate_day"
        
        
         >
        <option value="1"   >1</option>
        <option value="2"   >2</option>
        <option value="3"   >3</option>
        <option value="4"   >4</option>
        <option value="5"   >5</option>
        <option value="6"   >6</option>
        <option value="7"   >7</option>
        <option value="8"   >8</option>
        <option value="9"   >9</option>
        <option value="10"   >10</option>
        <option value="11"   >11</option>
        <option value="12" selected  >12</option>
        <option value="13"   >13</option>
        <option value="14"   >14</option>
        <option value="15"   >15</option>
        <option value="16"   >16</option>
        <option value="17"   >17</option>
        <option value="18"   >18</option>
        <option value="19"   >19</option>
        <option value="20"   >20</option>
        <option value="21"   >21</option>
        <option value="22"   >22</option>
        <option value="23"   >23</option>
        <option value="24"   >24</option>
        <option value="25"   >25</option>
        <option value="26"   >26</option>
        <option value="27"   >27</option>
        <option value="28"   >28</option>
        <option value="29"   >29</option>
        <option value="30"   >30</option>
        <option value="31"   >31</option>
    </select>
    </span>
    <div class="form-control-feedback invalid-feedback" id="id_error_enddate_day" >
        
    </div>
</div>
                &nbsp;
                <div class="form-group  fitem  " >
        <label class="col-form-label sr-only" for="id_enddate_month">
            Month
        </label>
    <span>
        
        
        
    </span>
    <span data-fieldtype="select">
    <select class="custom-select
                   
                   "
        name="enddate[month]"
        id="id_enddate_month"
        
        
         >
        <option value="1"   >January</option>
        <option value="2"   >February</option>
        <option value="3"   >March</option>
        <option value="4"   >April</option>
        <option value="5"   >May</option>
        <option value="6"   >June</option>
        <option value="7"   >July</option>
        <option value="8"   >August</option>
        <option value="9"   >September</option>
        <option value="10"   >October</option>
        <option value="11"   >November</option>
        <option value="12" selected  >December</option>
    </select>
    </span>
    <div class="form-control-feedback invalid-feedback" id="id_error_enddate_month" >
        
    </div>
</div>
                &nbsp;
                <div class="form-group  fitem  " >
        <label class="col-form-label sr-only" for="id_enddate_year">
            Year
        </label>
    <span>
        
        
        
    </span>
    <span data-fieldtype="select">
    <select class="custom-select
                   
                   "
        name="enddate[year]"
        id="id_enddate_year"
        
        
         >
        <option value="1900"   >1900</option>
        <option value="1901"   >1901</option>
        <option value="1902"   >1902</option>
        <option value="1903"   >1903</option>
        <option value="1904"   >1904</option>
        <option value="1905"   >1905</option>
        <option value="1906"   >1906</option>
        <option value="1907"   >1907</option>
        <option value="1908"   >1908</option>
        <option value="1909"   >1909</option>
        <option value="1910"   >1910</option>
        <option value="1911"   >1911</option>
        <option value="1912"   >1912</option>
        <option value="1913"   >1913</option>
        <option value="1914"   >1914</option>
        <option value="1915"   >1915</option>
        <option value="1916"   >1916</option>
        <option value="1917"   >1917</option>
        <option value="1918"   >1918</option>
        <option value="1919"   >1919</option>
        <option value="1920"   >1920</option>
        <option value="1921"   >1921</option>
        <option value="1922"   >1922</option>
        <option value="1923"   >1923</option>
        <option value="1924"   >1924</option>
        <option value="1925"   >1925</option>
        <option value="1926"   >1926</option>
        <option value="1927"   >1927</option>
        <option value="1928"   >1928</option>
        <option value="1929"   >1929</option>
        <option value="1930"   >1930</option>
        <option value="1931"   >1931</option>
        <option value="1932"   >1932</option>
        <option value="1933"   >1933</option>
        <option value="1934"   >1934</option>
        <option value="1935"   >1935</option>
        <option value="1936"   >1936</option>
        <option value="1937"   >1937</option>
        <option value="1938"   >1938</option>
        <option value="1939"   >1939</option>
        <option value="1940"   >1940</option>
        <option value="1941"   >1941</option>
        <option value="1942"   >1942</option>
        <option value="1943"   >1943</option>
        <option value="1944"   >1944</option>
        <option value="1945"   >1945</option>
        <option value="1946"   >1946</option>
        <option value="1947"   >1947</option>
        <option value="1948"   >1948</option>
        <option value="1949"   >1949</option>
        <option value="1950"   >1950</option>
        <option value="1951"   >1951</option>
        <option value="1952"   >1952</option>
        <option value="1953"   >1953</option>
        <option value="1954"   >1954</option>
        <option value="1955"   >1955</option>
        <option value="1956"   >1956</option>
        <option value="1957"   >1957</option>
        <option value="1958"   >1958</option>
        <option value="1959"   >1959</option>
        <option value="1960"   >1960</option>
        <option value="1961"   >1961</option>
        <option value="1962"   >1962</option>
        <option value="1963"   >1963</option>
        <option value="1964"   >1964</option>
        <option value="1965"   >1965</option>
        <option value="1966"   >1966</option>
        <option value="1967"   >1967</option>
        <option value="1968"   >1968</option>
        <option value="1969"   >1969</option>
        <option value="1970"   >1970</option>
        <option value="1971"   >1971</option>
        <option value="1972"   >1972</option>
        <option value="1973"   >1973</option>
        <option value="1974"   >1974</option>
        <option value="1975"   >1975</option>
        <option value="1976"   >1976</option>
        <option value="1977"   >1977</option>
        <option value="1978"   >1978</option>
        <option value="1979"   >1979</option>
        <option value="1980"   >1980</option>
        <option value="1981"   >1981</option>
        <option value="1982"   >1982</option>
        <option value="1983"   >1983</option>
        <option value="1984"   >1984</option>
        <option value="1985"   >1985</option>
        <option value="1986"   >1986</option>
        <option value="1987"   >1987</option>
        <option value="1988"   >1988</option>
        <option value="1989"   >1989</option>
        <option value="1990"   >1990</option>
        <option value="1991"   >1991</option>
        <option value="1992"   >1992</option>
        <option value="1993"   >1993</option>
        <option value="1994"   >1994</option>
        <option value="1995"   >1995</option>
        <option value="1996"   >1996</option>
        <option value="1997"   >1997</option>
        <option value="1998"   >1998</option>
        <option value="1999"   >1999</option>
        <option value="2000"   >2000</option>
        <option value="2001"   >2001</option>
        <option value="2002"   >2002</option>
        <option value="2003"   >2003</option>
        <option value="2004"   >2004</option>
        <option value="2005"   >2005</option>
        <option value="2006"   >2006</option>
        <option value="2007"   >2007</option>
        <option value="2008"   >2008</option>
        <option value="2009"   >2009</option>
        <option value="2010"   >2010</option>
        <option value="2011"   >2011</option>
        <option value="2012"   >2012</option>
        <option value="2013"   >2013</option>
        <option value="2014"   >2014</option>
        <option value="2015"   >2015</option>
        <option value="2016"   >2016</option>
        <option value="2017"   >2017</option>
        <option value="2018"   >2018</option>
        <option value="2019"   >2019</option>
        <option value="2020"   >2020</option>
        <option value="2021"   >2021</option>
        <option value="2022"   >2022</option>
        <option value="2023"   >2023</option>
        <option value="2024" selected  >2024</option>
        <option value="2025"   >2025</option>
        <option value="2026"   >2026</option>
        <option value="2027"   >2027</option>
        <option value="2028"   >2028</option>
        <option value="2029"   >2029</option>
        <option value="2030"   >2030</option>
        <option value="2031"   >2031</option>
        <option value="2032"   >2032</option>
        <option value="2033"   >2033</option>
        <option value="2034"   >2034</option>
        <option value="2035"   >2035</option>
        <option value="2036"   >2036</option>
        <option value="2037"   >2037</option>
        <option value="2038"   >2038</option>
        <option value="2039"   >2039</option>
        <option value="2040"   >2040</option>
        <option value="2041"   >2041</option>
        <option value="2042"   >2042</option>
        <option value="2043"   >2043</option>
        <option value="2044"   >2044</option>
        <option value="2045"   >2045</option>
        <option value="2046"   >2046</option>
        <option value="2047"   >2047</option>
        <option value="2048"   >2048</option>
        <option value="2049"   >2049</option>
        <option value="2050"   >2050</option>
    </select>
    </span>
    <div class="form-control-feedback invalid-feedback" id="id_error_enddate_year" >
        
    </div>
</div>
                &nbsp;
                <div class="form-group  fitem  " >
        <label class="col-form-label sr-only" for="id_enddate_hour">
            Hour
        </label>
    <span>
        
        
        
    </span>
    <span data-fieldtype="select">
    <select class="custom-select
                   
                   "
        name="enddate[hour]"
        id="id_enddate_hour"
        
        
         >
        <option value="0" selected  >00</option>
        <option value="1"   >01</option>
        <option value="2"   >02</option>
        <option value="3"   >03</option>
        <option value="4"   >04</option>
        <option value="5"   >05</option>
        <option value="6"   >06</option>
        <option value="7"   >07</option>
        <option value="8"   >08</option>
        <option value="9"   >09</option>
        <option value="10"   >10</option>
        <option value="11"   >11</option>
        <option value="12"   >12</option>
        <option value="13"   >13</option>
        <option value="14"   >14</option>
        <option value="15"   >15</option>
        <option value="16"   >16</option>
        <option value="17"   >17</option>
        <option value="18"   >18</option>
        <option value="19"   >19</option>
        <option value="20"   >20</option>
        <option value="21"   >21</option>
        <option value="22"   >22</option>
        <option value="23"   >23</option>
    </select>
    </span>
    <div class="form-control-feedback invalid-feedback" id="id_error_enddate_hour" >
        
    </div>
</div>
                &nbsp;
                <div class="form-group  fitem  " >
        <label class="col-form-label sr-only" for="id_enddate_minute">
            Minute
        </label>
    <span>
        
        
        
    </span>
    <span data-fieldtype="select">
    <select class="custom-select
                   
                   "
        name="enddate[minute]"
        id="id_enddate_minute"
        
        
         >
        <option value="0" selected  >00</option>
        <option value="1"   >01</option>
        <option value="2"   >02</option>
        <option value="3"   >03</option>
        <option value="4"   >04</option>
        <option value="5"   >05</option>
        <option value="6"   >06</option>
        <option value="7"   >07</option>
        <option value="8"   >08</option>
        <option value="9"   >09</option>
        <option value="10"   >10</option>
        <option value="11"   >11</option>
        <option value="12"   >12</option>
        <option value="13"   >13</option>
        <option value="14"   >14</option>
        <option value="15"   >15</option>
        <option value="16"   >16</option>
        <option value="17"   >17</option>
        <option value="18"   >18</option>
        <option value="19"   >19</option>
        <option value="20"   >20</option>
        <option value="21"   >21</option>
        <option value="22"   >22</option>
        <option value="23"   >23</option>
        <option value="24"   >24</option>
        <option value="25"   >25</option>
        <option value="26"   >26</option>
        <option value="27"   >27</option>
        <option value="28"   >28</option>
        <option value="29"   >29</option>
        <option value="30"   >30</option>
        <option value="31"   >31</option>
        <option value="32"   >32</option>
        <option value="33"   >33</option>
        <option value="34"   >34</option>
        <option value="35"   >35</option>
        <option value="36"   >36</option>
        <option value="37"   >37</option>
        <option value="38"   >38</option>
        <option value="39"   >39</option>
        <option value="40"   >40</option>
        <option value="41"   >41</option>
        <option value="42"   >42</option>
        <option value="43"   >43</option>
        <option value="44"   >44</option>
        <option value="45"   >45</option>
        <option value="46"   >46</option>
        <option value="47"   >47</option>
        <option value="48"   >48</option>
        <option value="49"   >49</option>
        <option value="50"   >50</option>
        <option value="51"   >51</option>
        <option value="52"   >52</option>
        <option value="53"   >53</option>
        <option value="54"   >54</option>
        <option value="55"   >55</option>
        <option value="56"   >56</option>
        <option value="57"   >57</option>
        <option value="58"   >58</option>
        <option value="59"   >59</option>
    </select>
    </span>
    <div class="form-control-feedback invalid-feedback" id="id_error_enddate_minute" >
        
    </div>
</div>
                &nbsp;
                <a class="visibleifjs" name="enddate[calendar]" href="#" id="id_enddate_calendar"><i class="icon fa fa-calendar fa-fw "  title="Calendar" aria-label="Calendar"></i></a>
                &nbsp;
                <label class="form-check  fitem  ">
<input type="checkbox" name="enddate[enabled]" class="form-check-input "
    id="id_enddate_enabled"
        value="1"
    checked
     >
    Enable
</label>

<span class="form-control-feedback invalid-feedback" id="id_error_enddate_enabled" >
    
</span>
            </div>
        </fieldset>
        <div class="form-control-feedback invalid-feedback" id="id_error_enddate" >
            
        </div>
    </div>
</div><div id="fitem_id_idnumber" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            <a class="btn btn-link p-0" role="button"
    data-container="body" data-toggle="popover"
    data-placement="right" data-content="&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;The ID number of a course is only used when matching the course against external systems and is not displayed anywhere on the site. If the course has an official code name it may be entered, otherwise the field can be left blank.&lt;/p&gt;
&lt;/div&gt; "
    data-html="true" tabindex="0" data-trigger="focus">
  <i class="icon fa fa-question-circle text-info fa-fw "  title="Help with Course ID number" aria-label="Help with Course ID number"></i>
</a>
        </span>
        
                <label class="col-form-label d-inline " for="id_idnumber">
                    Course ID number
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="text">
        <input type="text"
                class="form-control "
                name="idnumber"
                id="id_idnumber"
                value=""
                size="10"
                maxlength="100" >
        <div class="form-control-feedback invalid-feedback" id="id_error_idnumber" >
            
        </div>
    </div>
</div>
		</div></fieldset>
	<fieldset class="clearfix collapsible"  id="id_descriptionhdr">
		<legend class="ftoggler">Description</legend>
		<div class="fcontainer clearfix">
		<div id="fitem_id_summary_editor" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            <a class="btn btn-link p-0" role="button"
    data-container="body" data-toggle="popover"
    data-placement="right" data-content="&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;The course summary is displayed in the list of courses. A course search searches course summary text in addition to course names.&lt;/p&gt;
&lt;/div&gt; "
    data-html="true" tabindex="0" data-trigger="focus">
  <i class="icon fa fa-question-circle text-info fa-fw "  title="Help with Course summary" aria-label="Help with Course summary"></i>
</a>
        </span>
        
                <label class="col-form-label d-inline " for="id_summary_editor">
                    Course summary
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="editor">
        <div><div>
<textarea id="id_summary_editor" name="summary_editor[text]" class="form-control" rows="15" cols="80" spellcheck="true" ></textarea>
</div>
<div>
        <input name="summary_editor[format]" id="menusummary_editorformat" type="hidden" value="1"/>
</div><input type="hidden" name="summary_editor[itemid]" value="126736362" /><noscript><div><object type='text/html' data='https://moodle-stage.laerdalblr.in/repository/draftfiles_manager.php?action=browse&amp;env=editor&amp;itemid=126736362&amp;subdirs=0&amp;maxbytes=0&amp;areamaxbytes=-1&amp;maxfiles=-1&amp;ctx_id=958&amp;course=1&amp;sesskey=fZoB308Em3' height='160' width='600' style='border:1px solid #000'></object></div></noscript></div>
        <div class="form-control-feedback invalid-feedback" id="id_error_summary_editor" >
            
        </div>
    </div>
</div><div id="fitem_id_overviewfiles_filemanager" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            <a class="btn btn-link p-0" role="button"
    data-container="body" data-toggle="popover"
    data-placement="right" data-content="&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;The course image is displayed in the course overview on the Dashboard. Additional accepted file types and more than one file may be enabled by a site administrator. If so, these files will be displayed next to the course summary on the list of courses page.&lt;/p&gt;
&lt;/div&gt; "
    data-html="true" tabindex="0" data-trigger="focus">
  <i class="icon fa fa-question-circle text-info fa-fw "  title="Help with Course image" aria-label="Help with Course image"></i>
</a>
        </span>
                    <p id="id_overviewfiles_filemanager_label" class="col-form-label d-inline" aria-hidden="true">
                Course image
            </p>

    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="filemanager">
        <fieldset class="w-100 m-0 p-0 border-0" id="id_overviewfiles_filemanager_fieldset">
            <legend class="sr-only">Course image</legend>
            <div id="filemanager-65781ca7b1a62" class="filemanager w-100 fm-loading">
    <div class="fp-restrictions">
        <span>Maximum file size: 20MB, maximum number of files: 1</span>
        <span class="dnduploadnotsupported-message"> - drag and drop not supported<a class="btn btn-link p-0" role="button"
    data-container="body" data-toggle="popover"
    data-placement="right" data-content="&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;If there are multiple files in the folder, the main file is the one that appears on the view page. Other files such as images or videos may be embedded in it. In filemanager the main file is indicated with a title in bold.&lt;/p&gt;
&lt;/div&gt; "
    data-html="true" tabindex="0" data-trigger="focus">
  <i class="icon fa fa-question-circle text-info fa-fw "  title="Help with Set main file" aria-label="Help with Set main file"></i>
</a></span>
    </div>
    <div class="fp-navbar bg-faded card mb-0">
        <div class="filemanager-toolbar icon-no-spacing">
            <div class="fp-toolbar">
                <div class="fp-btn-add">
                    <a role="button" title="Add..." class="btn btn-secondary btn-sm" href="#">
                        <i class="icon fa fa-file-o fa-fw " aria-hidden="true"  ></i>
                    </a>
                </div>
                <div class="fp-btn-mkdir">
                    <a role="button" title="Create folder" class="btn btn-secondary btn-sm" href="#">
                        <i class="icon fa fa-folder-o fa-fw " aria-hidden="true"  ></i>
                    </a>
                </div>
                <div class="fp-btn-download">
                    <a role="button" title="Download all" class="btn btn-secondary btn-sm" href="#">
                        <i class="icon fa fa-download fa-fw " aria-hidden="true"  ></i>
                    </a>
                </div>
                <span class="fp-img-downloading">
                    <span class="sr-only">Loading...</span>
                    <i class="icon fa fa-circle-o-notch fa-spin fa-fw " aria-hidden="true"  ></i>
                </span>
            </div>
            <div class="fp-viewbar btn-group float-sm-right">
                <a title="Display folder with file icons" class="fp-vb-icons btn btn-secondary btn-sm" href="#">
                    <i class="icon fa fa-th fa-fw " aria-hidden="true"  ></i>
                </a>
                <a title="Display folder with file details" class="fp-vb-details btn btn-secondary btn-sm" href="#">
                    <i class="icon fa fa-list fa-fw " aria-hidden="true"  ></i>
                </a>
                <a title="Display folder as file tree" class="fp-vb-tree btn btn-secondary btn-sm" href="#">
                    <i class="icon fa fa-folder fa-fw " aria-hidden="true"  ></i>
                </a>
            </div>
        </div>
        <div class="fp-pathbar">
            <span class="fp-path-folder"><a class="fp-path-folder-name" href="#"></a></span>
        </div>
    </div>
    <div class="filemanager-loading mdl-align"><i class="icon fa fa-circle-o-notch fa-spin fa-fw " aria-hidden="true"  ></i><span class="sr-only">Loading...</span></div>
    <div class="filemanager-container card" >
        <div class="fm-content-wrapper">
            <div class="fp-content"></div>
            <div class="fm-empty-container">
                <div class="dndupload-message">You can drag and drop files here to add them.<br/><div class="dndupload-arrow"></div></div>
            </div>
            <div class="dndupload-target">Drop files here to upload<br/><div class="dndupload-arrow"></div></div>
            <div class="dndupload-progressbars"></div>
            <div class="dndupload-uploadinprogress"><i class="icon fa fa-circle-o-notch fa-spin fa-fw " aria-hidden="true"  ></i><span class="sr-only">Loading...</span></div>
        </div>
        <div class="filemanager-updating"><i class="icon fa fa-circle-o-notch fa-spin fa-fw " aria-hidden="true"  ></i><span class="sr-only">Loading...</span></div>
    </div>
</div><noscript><div><object type='text/html' data='https://moodle-stage.laerdalblr.in/repository/draftfiles_manager.php?env=filemanager&amp;action=browse&amp;itemid=673427866&amp;subdirs=0&amp;maxbytes=20971520&amp;areamaxbytes=-1&amp;maxfiles=1&amp;ctx_id=958&amp;course=1&amp;sesskey=fZoB308Em3' height='160' width='600' style='border:1px solid #000'></object></div></noscript><input value="673427866" name="overviewfiles_filemanager" type="hidden" id="id_overviewfiles_filemanager" /><p>Accepted file types:</p><div class="form-filetypes-descriptions w-100">
    <ul class="list-unstyled unstyled">
        <li>Image (GIF) <small class="text-muted muted">.gif</small></li>
        <li>Image (JPEG) <small class="text-muted muted">.jpg</small></li>
        <li>Image (PNG) <small class="text-muted muted">.png</small></li>
    </ul>
</div>
        </fieldset>
        <div class="form-control-feedback invalid-feedback" id="id_error_overviewfiles_filemanager" >
            
        </div>
    </div>
</div>
		</div></fieldset>
	<fieldset class="clearfix collapsible collapsed"  id="id_courseformathdr">
		<legend class="ftoggler">Course format</legend>
		<div class="fcontainer clearfix">
		<div id="fitem_id_format" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            <a class="btn btn-link p-0" role="button"
    data-container="body" data-toggle="popover"
    data-placement="right" data-content="&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;The course format determines the layout of the course page.&lt;/p&gt;

&lt;ul&gt;&lt;li&gt;Single activity format - For displaying a single activity or resource (such as a Quiz or SCORM package) on the course page&lt;/li&gt;
&lt;li&gt;Social format - A forum is displayed on the course page&lt;/li&gt;
&lt;li&gt;Topics format - The course page is organised into topic sections&lt;/li&gt;
&lt;li&gt;Weekly format - The course page is organised into weekly sections, with the first week starting on the course start date&lt;/li&gt;
&lt;/ul&gt;&lt;/div&gt; "
    data-html="true" tabindex="0" data-trigger="focus">
  <i class="icon fa fa-question-circle text-info fa-fw "  title="Help with Format" aria-label="Help with Format"></i>
</a>
        </span>
        
                <label class="col-form-label d-inline " for="id_format">
                    Format
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="select">
        <select class="custom-select
                       
                       "
            name="format"
            id="id_format"
            
            
             >
            <option value="singleactivity"  
                >Single activity format</option>
            <option value="social"  
                >Social format</option>
            <option value="topics" selected 
                >Topics format</option>
            <option value="weeks"  
                >Weekly format</option>
        </select>
        <div class="form-control-feedback invalid-feedback" id="id_error_format" >
            
        </div>
    </div>
</div><div id="fitem_id_updatecourseformat" class="form-group row  fitem femptylabel  " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            
        </span>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="submit">
            <input type="submit"
                class="btn
                        btn-primary
                        
                    
                    
                    "
                name="updatecourseformat"
                id="id_updatecourseformat"
                value="Update format"
                data-skip-validation="1" data-no-submit="1" onclick="skipClientValidation = true;" >
        <div class="form-control-feedback invalid-feedback" id="id_error_updatecourseformat" >
            
        </div>
    </div>
</div><div id="fitem_id_numsections" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            
        </span>
        
                <label class="col-form-label d-inline " for="id_numsections">
                    Number of sections
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="select">
        <select class="custom-select
                       
                       "
            name="numsections"
            id="id_numsections"
            
            
             >
            <option value="0"  
                >0</option>
            <option value="1"  
                >1</option>
            <option value="2"  
                >2</option>
            <option value="3"  
                >3</option>
            <option value="4" selected 
                >4</option>
            <option value="5"  
                >5</option>
            <option value="6"  
                >6</option>
            <option value="7"  
                >7</option>
            <option value="8"  
                >8</option>
            <option value="9"  
                >9</option>
            <option value="10"  
                >10</option>
            <option value="11"  
                >11</option>
            <option value="12"  
                >12</option>
            <option value="13"  
                >13</option>
            <option value="14"  
                >14</option>
            <option value="15"  
                >15</option>
            <option value="16"  
                >16</option>
            <option value="17"  
                >17</option>
            <option value="18"  
                >18</option>
            <option value="19"  
                >19</option>
            <option value="20"  
                >20</option>
            <option value="21"  
                >21</option>
            <option value="22"  
                >22</option>
            <option value="23"  
                >23</option>
            <option value="24"  
                >24</option>
            <option value="25"  
                >25</option>
            <option value="26"  
                >26</option>
            <option value="27"  
                >27</option>
            <option value="28"  
                >28</option>
            <option value="29"  
                >29</option>
            <option value="30"  
                >30</option>
            <option value="31"  
                >31</option>
            <option value="32"  
                >32</option>
            <option value="33"  
                >33</option>
            <option value="34"  
                >34</option>
            <option value="35"  
                >35</option>
            <option value="36"  
                >36</option>
            <option value="37"  
                >37</option>
            <option value="38"  
                >38</option>
            <option value="39"  
                >39</option>
            <option value="40"  
                >40</option>
            <option value="41"  
                >41</option>
            <option value="42"  
                >42</option>
            <option value="43"  
                >43</option>
            <option value="44"  
                >44</option>
            <option value="45"  
                >45</option>
            <option value="46"  
                >46</option>
            <option value="47"  
                >47</option>
            <option value="48"  
                >48</option>
            <option value="49"  
                >49</option>
            <option value="50"  
                >50</option>
            <option value="51"  
                >51</option>
            <option value="52"  
                >52</option>
        </select>
        <div class="form-control-feedback invalid-feedback" id="id_error_numsections" >
            
        </div>
    </div>
</div><div id="fitem_id_hiddensections" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            <a class="btn btn-link p-0" role="button"
    data-container="body" data-toggle="popover"
    data-placement="right" data-content="&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;This setting determines whether hidden sections are displayed to students in collapsed form (perhaps for a course in weekly format to indicate holidays) or are completely hidden.&lt;/p&gt;
&lt;/div&gt; "
    data-html="true" tabindex="0" data-trigger="focus">
  <i class="icon fa fa-question-circle text-info fa-fw "  title="Help with Hidden sections" aria-label="Help with Hidden sections"></i>
</a>
        </span>
        
                <label class="col-form-label d-inline " for="id_hiddensections">
                    Hidden sections
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="select">
        <select class="custom-select
                       
                       "
            name="hiddensections"
            id="id_hiddensections"
            
            
             >
            <option value="0" selected 
                >Hidden sections are shown in collapsed form</option>
            <option value="1"  
                >Hidden sections are completely invisible</option>
        </select>
        <div class="form-control-feedback invalid-feedback" id="id_error_hiddensections" >
            
        </div>
    </div>
</div><div id="fitem_id_coursedisplay" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            <a class="btn btn-link p-0" role="button"
    data-container="body" data-toggle="popover"
    data-placement="right" data-content="&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;This setting determines whether the whole course is displayed on one page or split over several pages.&lt;/p&gt;
&lt;/div&gt; "
    data-html="true" tabindex="0" data-trigger="focus">
  <i class="icon fa fa-question-circle text-info fa-fw "  title="Help with Course layout" aria-label="Help with Course layout"></i>
</a>
        </span>
        
                <label class="col-form-label d-inline " for="id_coursedisplay">
                    Course layout
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="select">
        <select class="custom-select
                       
                       "
            name="coursedisplay"
            id="id_coursedisplay"
            
            
             >
            <option value="0" selected 
                >Show all sections on one page</option>
            <option value="1"  
                >Show one section per page</option>
        </select>
        <div class="form-control-feedback invalid-feedback" id="id_error_coursedisplay" >
            
        </div>
    </div>
</div>
		</div></fieldset>
	<fieldset class="clearfix collapsible collapsed"  id="id_appearancehdr">
		<legend class="ftoggler">Appearance</legend>
		<div class="fcontainer clearfix">
		<div id="fitem_id_lang" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            
        </span>
        
                <label class="col-form-label d-inline " for="id_lang">
                    Force language
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="select">
        <select class="custom-select
                       
                       "
            name="lang"
            id="id_lang"
            
            
             >
            <option value="" selected 
                >Do not force</option>
            <option value="en"  
                >English ‎(en)‎</option>
        </select>
        <div class="form-control-feedback invalid-feedback" id="id_error_lang" >
            
        </div>
    </div>
</div><div id="fitem_id_newsitems" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            <a class="btn btn-link p-0" role="button"
    data-container="body" data-toggle="popover"
    data-placement="right" data-content="&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;The announcements forum is a special forum which is created automatically in the course, has forced subscription set by default, and only users with appropriate permissions (by default teachers) can post in it.&lt;/p&gt;

&lt;p&gt;This setting determines how many recent announcements appear in the latest announcements block.&lt;/p&gt;

&lt;p&gt;If an announcements forum is not required in the course, this setting should be set to zero.&lt;/p&gt;
&lt;/div&gt; "
    data-html="true" tabindex="0" data-trigger="focus">
  <i class="icon fa fa-question-circle text-info fa-fw "  title="Help with Number of announcements" aria-label="Help with Number of announcements"></i>
</a>
        </span>
        
                <label class="col-form-label d-inline " for="id_newsitems">
                    Number of announcements
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="select">
        <select class="custom-select
                       
                       "
            name="newsitems"
            id="id_newsitems"
            
            
             >
            <option value="0"  
                >0</option>
            <option value="1"  
                >1</option>
            <option value="2"  
                >2</option>
            <option value="3"  
                >3</option>
            <option value="4"  
                >4</option>
            <option value="5" selected 
                >5</option>
            <option value="6"  
                >6</option>
            <option value="7"  
                >7</option>
            <option value="8"  
                >8</option>
            <option value="9"  
                >9</option>
            <option value="10"  
                >10</option>
        </select>
        <div class="form-control-feedback invalid-feedback" id="id_error_newsitems" >
            
        </div>
    </div>
</div><div id="fitem_id_showgrades" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            <a class="btn btn-link p-0" role="button"
    data-container="body" data-toggle="popover"
    data-placement="right" data-content="&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;Many activities in the course allow grades to be set. This setting determines whether a student can view a list of all their grades for the course via a grades link in the navigation drawer or block.&lt;/p&gt;
&lt;/div&gt; "
    data-html="true" tabindex="0" data-trigger="focus">
  <i class="icon fa fa-question-circle text-info fa-fw "  title="Help with Show gradebook to students" aria-label="Help with Show gradebook to students"></i>
</a>
        </span>
        
                <label class="col-form-label d-inline " for="id_showgrades">
                    Show gradebook to students
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="selectyesno">
        <select class="custom-select
                       
                       "
            name="showgrades"
            id="id_showgrades"
            
            
             >
            <option value="0"  
                >No</option>
            <option value="1" selected 
                >Yes</option>
        </select>
        <div class="form-control-feedback invalid-feedback" id="id_error_showgrades" >
            
        </div>
    </div>
</div><div id="fitem_id_showreports" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            <a class="btn btn-link p-0" role="button"
    data-container="body" data-toggle="popover"
    data-placement="right" data-content="&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;Activity reports are available for each participant that show their activity in the course. As well as listings of their contributions, such as forum posts or assignment submissions, these reports also include access logs. This setting determines whether a student can view their own activity reports via their profile page.&lt;/p&gt;
&lt;/div&gt; "
    data-html="true" tabindex="0" data-trigger="focus">
  <i class="icon fa fa-question-circle text-info fa-fw "  title="Help with Show activity reports" aria-label="Help with Show activity reports"></i>
</a>
        </span>
        
                <label class="col-form-label d-inline " for="id_showreports">
                    Show activity reports
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="selectyesno">
        <select class="custom-select
                       
                       "
            name="showreports"
            id="id_showreports"
            
            
             >
            <option value="0" selected 
                >No</option>
            <option value="1"  
                >Yes</option>
        </select>
        <div class="form-control-feedback invalid-feedback" id="id_error_showreports" >
            
        </div>
    </div>
</div>
		</div></fieldset>
	<fieldset class="clearfix collapsible collapsed"  id="id_filehdr">
		<legend class="ftoggler">Files and uploads</legend>
		<div class="fcontainer clearfix">
		<div id="fitem_id_maxbytes" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            <a class="btn btn-link p-0" role="button"
    data-container="body" data-toggle="popover"
    data-placement="right" data-content="&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;This setting determines the largest size of file that can be uploaded to the course, limited by the site-wide setting set by an administrator. Activity modules also include a maximum upload size setting for further restricting the file size.&lt;/p&gt;
&lt;/div&gt; "
    data-html="true" tabindex="0" data-trigger="focus">
  <i class="icon fa fa-question-circle text-info fa-fw "  title="Help with Maximum upload size" aria-label="Help with Maximum upload size"></i>
</a>
        </span>
        
                <label class="col-form-label d-inline " for="id_maxbytes">
                    Maximum upload size
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="select">
        <select class="custom-select
                       
                       "
            name="maxbytes"
            id="id_maxbytes"
            
            
             >
            <option value="0" selected 
                >Site upload limit (20MB)</option>
            <option value="20971520"  
                >20MB</option>
            <option value="10485760"  
                >10MB</option>
            <option value="5242880"  
                >5MB</option>
            <option value="2097152"  
                >2MB</option>
            <option value="1048576"  
                >1MB</option>
            <option value="512000"  
                >500KB</option>
            <option value="102400"  
                >100KB</option>
            <option value="51200"  
                >50KB</option>
            <option value="10240"  
                >10KB</option>
        </select>
        <div class="form-control-feedback invalid-feedback" id="id_error_maxbytes" >
            
        </div>
    </div>
</div>
		</div></fieldset>
	<fieldset class="clearfix collapsible collapsed"  id="id_completionhdr">
		<legend class="ftoggler">Completion tracking</legend>
		<div class="fcontainer clearfix">
		<div id="fitem_id_enablecompletion" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            <a class="btn btn-link p-0" role="button"
    data-container="body" data-toggle="popover"
    data-placement="right" data-content="&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;If enabled, activity completion conditions may be set in the activity settings and/or course completion conditions may be set. It is recommended to have this enabled so that meaningful data is displayed in the course overview on the Dashboard.&lt;/p&gt;
&lt;/div&gt; "
    data-html="true" tabindex="0" data-trigger="focus">
  <i class="icon fa fa-question-circle text-info fa-fw "  title="Help with Enable completion tracking" aria-label="Help with Enable completion tracking"></i>
</a>
        </span>
        
                <label class="col-form-label d-inline " for="id_enablecompletion">
                    Enable completion tracking
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="selectyesno">
        <select class="custom-select
                       
                       "
            name="enablecompletion"
            id="id_enablecompletion"
            
            
             >
            <option value="0"  
                >No</option>
            <option value="1" selected 
                >Yes</option>
        </select>
        <div class="form-control-feedback invalid-feedback" id="id_error_enablecompletion" >
            
        </div>
    </div>
</div>
		</div></fieldset>
	<fieldset class="clearfix collapsible collapsed"  id="id_groups">
		<legend class="ftoggler">Groups</legend>
		<div class="fcontainer clearfix">
		<div id="fitem_id_groupmode" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            <a class="btn btn-link p-0" role="button"
    data-container="body" data-toggle="popover"
    data-placement="right" data-content="&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;This setting has 3 options:&lt;/p&gt;

&lt;ul&gt;&lt;li&gt;No groups&lt;/li&gt;
&lt;li&gt;Separate groups - Each group member can only see their own group, others are invisible&lt;/li&gt;
&lt;li&gt;Visible groups - Each group member works in their own group, but can also see other groups&lt;/li&gt;
&lt;/ul&gt;&lt;p&gt;The group mode defined at course level is the default mode for all activities within the course. Each activity that supports groups can also define its own group mode, though if the group mode is forced at course level, the group mode setting for each activity is ignored.&lt;/p&gt;
&lt;/div&gt; "
    data-html="true" tabindex="0" data-trigger="focus">
  <i class="icon fa fa-question-circle text-info fa-fw "  title="Help with Group mode" aria-label="Help with Group mode"></i>
</a>
        </span>
        
                <label class="col-form-label d-inline " for="id_groupmode">
                    Group mode
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="select">
        <select class="custom-select
                       
                       "
            name="groupmode"
            id="id_groupmode"
            
            
             >
            <option value="0" selected 
                >No groups</option>
            <option value="1"  
                >Separate groups</option>
            <option value="2"  
                >Visible groups</option>
        </select>
        <div class="form-control-feedback invalid-feedback" id="id_error_groupmode" >
            
        </div>
    </div>
</div><div id="fitem_id_groupmodeforce" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            <a class="btn btn-link p-0" role="button"
    data-container="body" data-toggle="popover"
    data-placement="right" data-content="&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;If group mode is forced, then the course group mode is applied to every activity in the course. Group mode settings in each activity are then ignored.&lt;/p&gt;
&lt;/div&gt; "
    data-html="true" tabindex="0" data-trigger="focus">
  <i class="icon fa fa-question-circle text-info fa-fw "  title="Help with Force group mode" aria-label="Help with Force group mode"></i>
</a>
        </span>
        
                <label class="col-form-label d-inline " for="id_groupmodeforce">
                    Force group mode
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="selectyesno">
        <select class="custom-select
                       
                       "
            name="groupmodeforce"
            id="id_groupmodeforce"
            
            
             >
            <option value="0" selected 
                >No</option>
            <option value="1"  
                >Yes</option>
        </select>
        <div class="form-control-feedback invalid-feedback" id="id_error_groupmodeforce" >
            
        </div>
    </div>
</div><div id="fitem_id_defaultgroupingid" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            
        </span>
        
                <label class="col-form-label d-inline " for="id_defaultgroupingid">
                    Default grouping
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="select">
        <select class="custom-select
                       
                       "
            name="defaultgroupingid"
            id="id_defaultgroupingid"
            
            
             >
            <option value="0"  
                >None</option>
        </select>
        <div class="form-control-feedback invalid-feedback" id="id_error_defaultgroupingid" >
            
        </div>
    </div>
</div>
		</div></fieldset>
	<fieldset class="clearfix collapsible collapsed"  id="id_rolerenaming">
		<legend class="ftoggler">Role renaming<a class="btn btn-link p-0" role="button"
    data-container="body" data-toggle="popover"
    data-placement="right" data-content="&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;This setting allows the displayed names for roles used in the course to be changed. Only the displayed name is changed - role permissions are not affected.  New role names will appear on the course participants page and elsewhere within the course. If the renamed role is one that the administrator has selected as a course manager role, then the new role name will also appear as part of the course listings.&lt;/p&gt;
&lt;/div&gt; "
    data-html="true" tabindex="0" data-trigger="focus">
  <i class="icon fa fa-question-circle text-info fa-fw "  title="Help with Role renaming" aria-label="Help with Role renaming"></i>
</a></legend>
		<div class="fcontainer clearfix">
		<div id="fitem_id_role_1" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            
        </span>
        
                <label class="col-form-label d-inline " for="id_role_1">
                    Your word for 'Manager'
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="text">
        <input type="text"
                class="form-control "
                name="role_1"
                id="id_role_1"
                value=""
                
                 >
        <div class="form-control-feedback invalid-feedback" id="id_error_role_1" >
            
        </div>
    </div>
</div><div id="fitem_id_role_2" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            
        </span>
        
                <label class="col-form-label d-inline " for="id_role_2">
                    Your word for 'Course creator'
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="text">
        <input type="text"
                class="form-control "
                name="role_2"
                id="id_role_2"
                value=""
                
                 >
        <div class="form-control-feedback invalid-feedback" id="id_error_role_2" >
            
        </div>
    </div>
</div><div id="fitem_id_role_3" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            
        </span>
        
                <label class="col-form-label d-inline " for="id_role_3">
                    Your word for 'Teacher'
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="text">
        <input type="text"
                class="form-control "
                name="role_3"
                id="id_role_3"
                value=""
                
                 >
        <div class="form-control-feedback invalid-feedback" id="id_error_role_3" >
            
        </div>
    </div>
</div><div id="fitem_id_role_4" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            
        </span>
        
                <label class="col-form-label d-inline " for="id_role_4">
                    Your word for 'Non-editing teacher'
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="text">
        <input type="text"
                class="form-control "
                name="role_4"
                id="id_role_4"
                value=""
                
                 >
        <div class="form-control-feedback invalid-feedback" id="id_error_role_4" >
            
        </div>
    </div>
</div><div id="fitem_id_role_5" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            
        </span>
        
                <label class="col-form-label d-inline " for="id_role_5">
                    Your word for 'Student'
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="text">
        <input type="text"
                class="form-control "
                name="role_5"
                id="id_role_5"
                value=""
                
                 >
        <div class="form-control-feedback invalid-feedback" id="id_error_role_5" >
            
        </div>
    </div>
</div><div id="fitem_id_role_6" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            
        </span>
        
                <label class="col-form-label d-inline " for="id_role_6">
                    Your word for 'Guest'
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="text">
        <input type="text"
                class="form-control "
                name="role_6"
                id="id_role_6"
                value=""
                
                 >
        <div class="form-control-feedback invalid-feedback" id="id_error_role_6" >
            
        </div>
    </div>
</div><div id="fitem_id_role_7" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            
        </span>
        
                <label class="col-form-label d-inline " for="id_role_7">
                    Your word for 'Authenticated user'
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="text">
        <input type="text"
                class="form-control "
                name="role_7"
                id="id_role_7"
                value=""
                
                 >
        <div class="form-control-feedback invalid-feedback" id="id_error_role_7" >
            
        </div>
    </div>
</div><div id="fitem_id_role_8" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            
        </span>
        
                <label class="col-form-label d-inline " for="id_role_8">
                    Your word for 'Authenticated user on frontpage'
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="text">
        <input type="text"
                class="form-control "
                name="role_8"
                id="id_role_8"
                value=""
                
                 >
        <div class="form-control-feedback invalid-feedback" id="id_error_role_8" >
            
        </div>
    </div>
</div>
		</div></fieldset>
	<fieldset class="clearfix collapsible collapsed"  id="id_tagshdr">
		<legend class="ftoggler">Tags</legend>
		<div class="fcontainer clearfix">
		<div id="fitem_id_tags" class="form-group row  fitem   " >
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            
        </span>
        
                <label class="col-form-label d-inline " for="id_tags">
                    Tags
                </label>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="tags">
        <input type="hidden" name="tags" value="_qf__force_multiselect_submission">
        <select class="custom-select " name="tags[]"
            id="id_tags"
            multiple
             >
        </select>
            <a href="https://moodle-stage.laerdalblr.in/tag/manage.php?tc=1">Manage standard tags</a>
        <div class="form-control-feedback invalid-feedback" id="id_error_tags" >
            
        </div>
    </div>
</div>
		</div></fieldset><div id="fgroup_id_buttonar" class="form-group row  fitem femptylabel  " data-groupname="buttonar">
    <div class="col-md-3">
        <span class="float-sm-right text-nowrap">
            
            
            
        </span>
        
    </div>
    <div class="col-md-9 form-inline felement" data-fieldtype="group">
        <fieldset class="w-100 m-0 p-0 border-0">
            <legend class="sr-only"></legend>
            <div class="d-flex flex-wrap align-items-center">
                
                <div class="form-group  fitem  form-submit" >
    <span>
        
        
        
    </span>
    <span data-fieldtype="submit">
        <input type="submit"
                class="btn
                        btn-primary
                        
                    
                    "
                name="saveanddisplay"
                id="id_saveanddisplay"
                value="Save and display"
                 >
    </span>
    <div class="form-control-feedback invalid-feedback" id="id_error_saveanddisplay" >
        
    </div>
</div>
                 
                <div class="form-group  fitem   btn-cancel" >
    <span>
        
        
        
    </span>
    <span data-fieldtype="submit">
        <input type="submit"
                class="btn
                        
                        btn-secondary
                    
                    "
                name="cancel"
                id="id_cancel"
                value="Cancel"
                data-skip-validation="1" data-cancel="1" onclick="skipClientValidation = true; return true;" >
    </span>
    <div class="form-control-feedback invalid-feedback" id="id_error_cancel" >
        
    </div>
</div>
            </div>
        </fieldset>
        <div class="form-control-feedback invalid-feedback" id="fgroup_id_error_buttonar" >
            
        </div>
    </div>
</div>
		<div class="fdescription required">There are required fields in this form marked <i class="icon fa fa-exclamation-circle text-danger fa-fw "  title="Required field" aria-label="Required field"></i>.</div>
</form>
<script>var skipClientValidation = false;</script></div>
                    
                    

                </section>
            </div>
        </div>
    </div>
    <div
    id="drawer-65781ca73823865781ca719c2e13"
    class=" drawer bg-white hidden"
    aria-expanded="false"
    aria-hidden="true"
    data-region="right-hand-drawer"
    role="region"
    tabindex="0"
>
            <div id="message-drawer-65781ca73823865781ca719c2e13" class="message-app" data-region="message-drawer" role="region">
            <div class="header-container position-relative" data-region="header-container">
                <div class="hidden border-bottom px-2 py-3" aria-hidden="true" data-region="view-contacts">
                    <div class="d-flex align-items-center">
                        <div class="align-self-stretch">
                            <a class="h-100 d-flex align-items-center mr-2" href="#" data-route-back role="button">
                                <div class="icon-back-in-drawer">
                                    <span class="dir-rtl-hide"><i class="icon fa fa-chevron-left fa-fw " aria-hidden="true"  ></i></span>
                                    <span class="dir-ltr-hide"><i class="icon fa fa-chevron-right fa-fw " aria-hidden="true"  ></i></span>
                                </div>
                                <div class="icon-back-in-app">
                                    <span class="dir-rtl-hide"><i class="icon fa fa-times fa-fw " aria-hidden="true"  ></i></span>
                                </div>                            </a>
                        </div>
                        <div>
                            Contacts
                        </div>
                        <div class="ml-auto">
                            <a href="#" data-route="view-search" role="button" aria-label="Search">
                                <i class="icon fa fa-search fa-fw " aria-hidden="true"  ></i>
                            </a>
                        </div>
                    </div>
                </div>                
                <div
                    class="hidden bg-white position-relative border-bottom px-2 py-2"
                    aria-hidden="true"
                    data-region="view-conversation"
                >
                    <div class="hidden" data-region="header-content"></div>
                    <div class="hidden" data-region="header-edit-mode">
                        
                        <div class="d-flex p-2 align-items-center">
                            Messages selected:
                            <span class="ml-1" data-region="message-selected-court">1</span>
                            <button type="button" class="ml-auto close" aria-label="Cancel message selection"
                                data-action="cancel-edit-mode">
                                    <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    </div>
                    <div data-region="header-placeholder">
                        <div class="d-flex">
                            <div
                                class="ml-2 rounded-circle bg-pulse-grey align-self-center"
                                style="height: 38px; width: 38px"
                            >
                            </div>
                            <div class="ml-2 " style="flex: 1">
                                <div
                                    class="mt-1 bg-pulse-grey w-75"
                                    style="height: 16px;"
                                >
                                </div>
                            </div>
                            <div
                                class="ml-2 bg-pulse-grey align-self-center"
                                style="height: 16px; width: 20px"
                            >
                            </div>
                        </div>
                    </div>
                    <div
                        class="hidden position-absolute"
                        data-region="confirm-dialogue-container"
                        style="top: 0; bottom: -1px; right: 0; left: 0; background: rgba(0,0,0,0.3);"
                    ></div>
                </div>                <div class="border-bottom px-2 py-3" aria-hidden="false"  data-region="view-overview">
                    <div class="d-flex align-items-center">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text pr-2 bg-white">
                                    <i class="icon fa fa-search fa-fw " aria-hidden="true"  ></i>
                                </span>
                            </div>
                            <input
                                type="text"
                                class="form-control border-left-0"
                                placeholder="Search"
                                aria-label="Search"
                                data-region="view-overview-search-input"
                            >
                        </div>
                        <div class="ml-2">
                            <a
                                href="#"
                                data-route="view-settings"
                                data-route-param="130"
                                aria-label="Settings"
                                role="button"
                            >
                                <i class="icon fa fa-cog fa-fw " aria-hidden="true"  ></i>
                            </a>
                        </div>
                    </div>
                    <div class="text-right mt-3">
                        <a href="#" data-route="view-contacts" role="button">
                            <i class="icon fa fa-user fa-fw " aria-hidden="true"  ></i>
                            Contacts
                            <span class="badge badge-primary bg-primary ml-2 hidden"
                            data-region="contact-request-count"
                            aria-label="There are 0 pending contact requests">
                                0
                            </span>
                        </a>
                    </div>
                </div>
                
                <div class="hidden border-bottom px-2 py-3 view-search"  aria-hidden="true" data-region="view-search">
                    <div class="d-flex align-items-center">
                        <a
                            class="mr-2 align-self-stretch d-flex align-items-center"
                            href="#"
                            data-route-back
                            data-action="cancel-search"
                            role="button"
                        >
                            <div class="icon-back-in-drawer">
                                <span class="dir-rtl-hide"><i class="icon fa fa-chevron-left fa-fw " aria-hidden="true"  ></i></span>
                                <span class="dir-ltr-hide"><i class="icon fa fa-chevron-right fa-fw " aria-hidden="true"  ></i></span>
                            </div>
                            <div class="icon-back-in-app">
                                <span class="dir-rtl-hide"><i class="icon fa fa-times fa-fw " aria-hidden="true"  ></i></span>
                            </div>                        </a>
                        <div class="input-group">
                            <input
                                type="text"
                                class="form-control"
                                placeholder="Search"
                                aria-label="Search"
                                data-region="search-input"
                            >
                            <div class="input-group-append">
                                <button
                                    class="btn btn-outline-secondary"
                                    type="button"
                                    data-action="search"
                                    aria-label="Search"
                                >
                                    <span data-region="search-icon-container">
                                        <i class="icon fa fa-search fa-fw " aria-hidden="true"  ></i>
                                    </span>
                                    <span class="hidden" data-region="loading-icon-container">
                                        <span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
                                    </span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>                
                <div class="hidden border-bottom px-2 py-3" aria-hidden="true" data-region="view-settings">
                    <div class="d-flex align-items-center">
                        <div class="align-self-stretch" >
                            <a class="h-100 d-flex mr-2 align-items-center" href="#" data-route-back role="button">
                                <div class="icon-back-in-drawer">
                                    <span class="dir-rtl-hide"><i class="icon fa fa-chevron-left fa-fw " aria-hidden="true"  ></i></span>
                                    <span class="dir-ltr-hide"><i class="icon fa fa-chevron-right fa-fw " aria-hidden="true"  ></i></span>
                                </div>
                                <div class="icon-back-in-app">
                                    <span class="dir-rtl-hide"><i class="icon fa fa-times fa-fw " aria-hidden="true"  ></i></span>
                                </div>                            </a>
                        </div>
                        <div>
                            Settings
                        </div>
                    </div>
                </div>
            </div>
            <div class="body-container position-relative" data-region="body-container">
                
                <div
                    class="hidden"
                    data-region="view-contact"
                    aria-hidden="true"
                >
                    <div class="p-2 pt-3" data-region="content-container"></div>
                </div>                <div class="hidden h-100" data-region="view-contacts" aria-hidden="true" data-user-id="130">
                    <div class="d-flex flex-column h-100">
                        <div class="p-3 border-bottom">
                            <ul class="nav nav-pills nav-fill" role="tablist">
                                <li class="nav-item">
                                    <a
                                        id="contacts-tab-65781ca73823865781ca719c2e13"
                                        class="nav-link active"
                                        href="#contacts-tab-panel-65781ca73823865781ca719c2e13"
                                        data-toggle="tab"
                                        data-action="show-contacts-section"
                                        role="tab"
                                        aria-controls="contacts-tab-panel-65781ca73823865781ca719c2e13"
                                        aria-selected="true"
                                    >
                                        Contacts
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a
                                        id="requests-tab-65781ca73823865781ca719c2e13"
                                        class="nav-link"
                                        href="#requests-tab-panel-65781ca73823865781ca719c2e13"
                                        data-toggle="tab"
                                        data-action="show-requests-section"
                                        role="tab"
                                        aria-controls="requests-tab-panel-65781ca73823865781ca719c2e13"
                                        aria-selected="false"
                                    >
                                        Requests
                                        <span class="badge badge-primary bg-primary ml-2 hidden"
                                        data-region="contact-request-count"
                                        aria-label="There are 0 pending contact requests">
                                            0
                                        </span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-content d-flex flex-column h-100">
                                            <div
                    class="tab-pane fade show active h-100 lazy-load-list"
                    aria-live="polite"
                    data-region="lazy-load-list"
                    data-user-id="130"
                                        id="contacts-tab-panel-65781ca73823865781ca719c2e13"
                    data-section="contacts"
                    role="tabpanel"
                    aria-labelledby="contacts-tab-65781ca73823865781ca719c2e13"

                >
                    
                    <div class="hidden text-center p-2" data-region="empty-message-container">
                        No contacts
                    </div>
                    <div class="hidden list-group" data-region="content-container">
                        
                    </div>
                    <div class="list-group" data-region="placeholder-container">
                        
                    </div>
                    <div class="w-100 text-center p-3 hidden" data-region="loading-icon-container" >
                        <span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
                    </div>
                </div>
                
                                            <div
                    class="tab-pane fade h-100 lazy-load-list"
                    aria-live="polite"
                    data-region="lazy-load-list"
                    data-user-id="130"
                                        id="requests-tab-panel-65781ca73823865781ca719c2e13"
                    data-section="requests"
                    role="tabpanel"
                    aria-labelledby="requests-tab-65781ca73823865781ca719c2e13"

                >
                    
                    <div class="hidden text-center p-2" data-region="empty-message-container">
                        No contact requests
                    </div>
                    <div class="hidden list-group" data-region="content-container">
                        
                    </div>
                    <div class="list-group" data-region="placeholder-container">
                        
                    </div>
                    <div class="w-100 text-center p-3 hidden" data-region="loading-icon-container" >
                        <span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
                    </div>
                </div>
                        </div>
                    </div>
                </div>                
                <div
                    class="view-conversation hidden h-100"
                    aria-hidden="true"
                    data-region="view-conversation"
                    data-user-id="130"
                    data-midnight="1702339200"
                    data-message-poll-min="10"
                    data-message-poll-max="120"
                    data-message-poll-after-max="300"
                    style="overflow-y: auto; overflow-x: hidden"
                >
                    <div class="position-relative h-100" data-region="content-container" style="overflow-y: auto; overflow-x: hidden">
                        <div class="content-message-container hidden h-100 px-2 pt-0" data-region="content-message-container" role="log" style="overflow-y: auto; overflow-x: hidden">
                            <div class="py-3 sticky-top z-index-1 border-bottom text-center hidden" data-region="contact-request-sent-message-container">
                                <p class="m-0">Contact request sent</p>
                                <p class="font-italic font-weight-light" data-region="text"></p>
                            </div>
                            <div class="p-3 text-center hidden" data-region="self-conversation-message-container">
                                <p class="m-0">Personal space</p>
                                <p class="font-italic font-weight-light" data-region="text">Save draft messages, links, notes etc. to access later.</p>
                           </div>
                            <div class="hidden text-center p-3" data-region="more-messages-loading-icon-container"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
</div>
                        </div>
                        <div class="p-4 w-100 h-100 hidden position-absolute" data-region="confirm-dialogue-container" style="top: 0; background: rgba(0,0,0,0.3);">
                            
                            <div class="p-3 bg-white" data-region="confirm-dialogue" role="alert">
                                <p class="text-muted" data-region="dialogue-text"></p>
                                <div class="mb-2 custom-control custom-checkbox hidden" data-region="delete-messages-for-all-users-toggle-container">
                                    <input type="checkbox" class="custom-control-input" id="delete-messages-for-all-users" data-region="delete-messages-for-all-users-toggle">
                                    <label class="custom-control-label text-muted" for="delete-messages-for-all-users">
                                        Delete for me and for everyone else
                                    </label>
                                </div>
                                <button type="button" class="btn btn-primary btn-block hidden" data-action="confirm-block">
                                    <span data-region="dialogue-button-text">Block</span>
                                    <span class="hidden" data-region="loading-icon-container"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
</span>
                                </button>
                                <button type="button" class="btn btn-primary btn-block hidden" data-action="confirm-unblock">
                                    <span data-region="dialogue-button-text">Unblock</span>
                                    <span class="hidden" data-region="loading-icon-container"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
</span>
                                </button>
                                <button type="button" class="btn btn-primary btn-block hidden" data-action="confirm-remove-contact">
                                    <span data-region="dialogue-button-text">Remove</span>
                                    <span class="hidden" data-region="loading-icon-container"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
</span>
                                </button>
                                <button type="button" class="btn btn-primary btn-block hidden" data-action="confirm-add-contact">
                                    <span data-region="dialogue-button-text">Add</span>
                                    <span class="hidden" data-region="loading-icon-container"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
</span>
                                </button>
                                <button type="button" class="btn btn-primary btn-block hidden" data-action="confirm-delete-selected-messages">
                                    <span data-region="dialogue-button-text">Delete</span>
                                    <span class="hidden" data-region="loading-icon-container"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
</span>
                                </button>
                                <button type="button" class="btn btn-primary btn-block hidden" data-action="confirm-delete-conversation">
                                    <span data-region="dialogue-button-text">Delete</span>
                                    <span class="hidden" data-region="loading-icon-container"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
</span>
                                </button>
                                <button type="button" class="btn btn-primary btn-block hidden" data-action="request-add-contact">
                                    <span data-region="dialogue-button-text">Send contact request</span>
                                    <span class="hidden" data-region="loading-icon-container"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
</span>
                                </button>
                                <button type="button" class="btn btn-primary btn-block hidden" data-action="accept-contact-request">
                                    <span data-region="dialogue-button-text">Accept and add to contacts</span>
                                    <span class="hidden" data-region="loading-icon-container"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
</span>
                                </button>
                                <button type="button" class="btn btn-secondary btn-block hidden" data-action="decline-contact-request">
                                    <span data-region="dialogue-button-text">Decline</span>
                                    <span class="hidden" data-region="loading-icon-container"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
</span>
                                </button>
                                <button type="button" class="btn btn-primary btn-block" data-action="okay-confirm">OK</button>
                                <button type="button" class="btn btn-secondary btn-block" data-action="cancel-confirm">Cancel</button>
                            </div>
                        </div>
                        <div class="px-2 pb-2 pt-0" data-region="content-placeholder">
                            <div class="h-100 d-flex flex-column">
                                <div
                                    class="px-2 pb-2 pt-0 bg-light h-100"
                                    style="overflow-y: auto"
                                >
                                    <div class="mt-4">
                                        <div class="mb-4">
                                            <div class="mx-auto bg-white" style="height: 25px; width: 100px"></div>
                                        </div>
                                        <div class="d-flex flex-column p-2 bg-white rounded mb-2">
                                            <div class="d-flex align-items-center mb-2">
                                                <div class="mr-2">
                                                    <div class="rounded-circle bg-pulse-grey" style="height: 35px; width: 35px"></div>
                                                </div>
                                                <div class="mr-4 w-75 bg-pulse-grey" style="height: 16px"></div>
                                                <div class="ml-auto bg-pulse-grey" style="width: 35px; height: 16px"></div>
                                            </div>
                                            <div class="bg-pulse-grey w-100" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-75 mt-2" style="height: 16px"></div>
                                        </div>
                                        <div class="d-flex flex-column p-2 bg-white rounded mb-2">
                                            <div class="d-flex align-items-center mb-2">
                                                <div class="mr-2">
                                                    <div class="rounded-circle bg-pulse-grey" style="height: 35px; width: 35px"></div>
                                                </div>
                                                <div class="mr-4 w-75 bg-pulse-grey" style="height: 16px"></div>
                                                <div class="ml-auto bg-pulse-grey" style="width: 35px; height: 16px"></div>
                                            </div>
                                            <div class="bg-pulse-grey w-100" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-75 mt-2" style="height: 16px"></div>
                                        </div>
                                        <div class="d-flex flex-column p-2 bg-white rounded mb-2">
                                            <div class="d-flex align-items-center mb-2">
                                                <div class="mr-2">
                                                    <div class="rounded-circle bg-pulse-grey" style="height: 35px; width: 35px"></div>
                                                </div>
                                                <div class="mr-4 w-75 bg-pulse-grey" style="height: 16px"></div>
                                                <div class="ml-auto bg-pulse-grey" style="width: 35px; height: 16px"></div>
                                            </div>
                                            <div class="bg-pulse-grey w-100" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-75 mt-2" style="height: 16px"></div>
                                        </div>
                                    </div>                                    <div class="mt-4">
                                        <div class="mb-4">
                                            <div class="mx-auto bg-white" style="height: 25px; width: 100px"></div>
                                        </div>
                                        <div class="d-flex flex-column p-2 bg-white rounded mb-2">
                                            <div class="d-flex align-items-center mb-2">
                                                <div class="mr-2">
                                                    <div class="rounded-circle bg-pulse-grey" style="height: 35px; width: 35px"></div>
                                                </div>
                                                <div class="mr-4 w-75 bg-pulse-grey" style="height: 16px"></div>
                                                <div class="ml-auto bg-pulse-grey" style="width: 35px; height: 16px"></div>
                                            </div>
                                            <div class="bg-pulse-grey w-100" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-75 mt-2" style="height: 16px"></div>
                                        </div>
                                        <div class="d-flex flex-column p-2 bg-white rounded mb-2">
                                            <div class="d-flex align-items-center mb-2">
                                                <div class="mr-2">
                                                    <div class="rounded-circle bg-pulse-grey" style="height: 35px; width: 35px"></div>
                                                </div>
                                                <div class="mr-4 w-75 bg-pulse-grey" style="height: 16px"></div>
                                                <div class="ml-auto bg-pulse-grey" style="width: 35px; height: 16px"></div>
                                            </div>
                                            <div class="bg-pulse-grey w-100" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-75 mt-2" style="height: 16px"></div>
                                        </div>
                                        <div class="d-flex flex-column p-2 bg-white rounded mb-2">
                                            <div class="d-flex align-items-center mb-2">
                                                <div class="mr-2">
                                                    <div class="rounded-circle bg-pulse-grey" style="height: 35px; width: 35px"></div>
                                                </div>
                                                <div class="mr-4 w-75 bg-pulse-grey" style="height: 16px"></div>
                                                <div class="ml-auto bg-pulse-grey" style="width: 35px; height: 16px"></div>
                                            </div>
                                            <div class="bg-pulse-grey w-100" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-75 mt-2" style="height: 16px"></div>
                                        </div>
                                    </div>                                    <div class="mt-4">
                                        <div class="mb-4">
                                            <div class="mx-auto bg-white" style="height: 25px; width: 100px"></div>
                                        </div>
                                        <div class="d-flex flex-column p-2 bg-white rounded mb-2">
                                            <div class="d-flex align-items-center mb-2">
                                                <div class="mr-2">
                                                    <div class="rounded-circle bg-pulse-grey" style="height: 35px; width: 35px"></div>
                                                </div>
                                                <div class="mr-4 w-75 bg-pulse-grey" style="height: 16px"></div>
                                                <div class="ml-auto bg-pulse-grey" style="width: 35px; height: 16px"></div>
                                            </div>
                                            <div class="bg-pulse-grey w-100" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-75 mt-2" style="height: 16px"></div>
                                        </div>
                                        <div class="d-flex flex-column p-2 bg-white rounded mb-2">
                                            <div class="d-flex align-items-center mb-2">
                                                <div class="mr-2">
                                                    <div class="rounded-circle bg-pulse-grey" style="height: 35px; width: 35px"></div>
                                                </div>
                                                <div class="mr-4 w-75 bg-pulse-grey" style="height: 16px"></div>
                                                <div class="ml-auto bg-pulse-grey" style="width: 35px; height: 16px"></div>
                                            </div>
                                            <div class="bg-pulse-grey w-100" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-75 mt-2" style="height: 16px"></div>
                                        </div>
                                        <div class="d-flex flex-column p-2 bg-white rounded mb-2">
                                            <div class="d-flex align-items-center mb-2">
                                                <div class="mr-2">
                                                    <div class="rounded-circle bg-pulse-grey" style="height: 35px; width: 35px"></div>
                                                </div>
                                                <div class="mr-4 w-75 bg-pulse-grey" style="height: 16px"></div>
                                                <div class="ml-auto bg-pulse-grey" style="width: 35px; height: 16px"></div>
                                            </div>
                                            <div class="bg-pulse-grey w-100" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-75 mt-2" style="height: 16px"></div>
                                        </div>
                                    </div>                                    <div class="mt-4">
                                        <div class="mb-4">
                                            <div class="mx-auto bg-white" style="height: 25px; width: 100px"></div>
                                        </div>
                                        <div class="d-flex flex-column p-2 bg-white rounded mb-2">
                                            <div class="d-flex align-items-center mb-2">
                                                <div class="mr-2">
                                                    <div class="rounded-circle bg-pulse-grey" style="height: 35px; width: 35px"></div>
                                                </div>
                                                <div class="mr-4 w-75 bg-pulse-grey" style="height: 16px"></div>
                                                <div class="ml-auto bg-pulse-grey" style="width: 35px; height: 16px"></div>
                                            </div>
                                            <div class="bg-pulse-grey w-100" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-75 mt-2" style="height: 16px"></div>
                                        </div>
                                        <div class="d-flex flex-column p-2 bg-white rounded mb-2">
                                            <div class="d-flex align-items-center mb-2">
                                                <div class="mr-2">
                                                    <div class="rounded-circle bg-pulse-grey" style="height: 35px; width: 35px"></div>
                                                </div>
                                                <div class="mr-4 w-75 bg-pulse-grey" style="height: 16px"></div>
                                                <div class="ml-auto bg-pulse-grey" style="width: 35px; height: 16px"></div>
                                            </div>
                                            <div class="bg-pulse-grey w-100" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-75 mt-2" style="height: 16px"></div>
                                        </div>
                                        <div class="d-flex flex-column p-2 bg-white rounded mb-2">
                                            <div class="d-flex align-items-center mb-2">
                                                <div class="mr-2">
                                                    <div class="rounded-circle bg-pulse-grey" style="height: 35px; width: 35px"></div>
                                                </div>
                                                <div class="mr-4 w-75 bg-pulse-grey" style="height: 16px"></div>
                                                <div class="ml-auto bg-pulse-grey" style="width: 35px; height: 16px"></div>
                                            </div>
                                            <div class="bg-pulse-grey w-100" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-75 mt-2" style="height: 16px"></div>
                                        </div>
                                    </div>                                    <div class="mt-4">
                                        <div class="mb-4">
                                            <div class="mx-auto bg-white" style="height: 25px; width: 100px"></div>
                                        </div>
                                        <div class="d-flex flex-column p-2 bg-white rounded mb-2">
                                            <div class="d-flex align-items-center mb-2">
                                                <div class="mr-2">
                                                    <div class="rounded-circle bg-pulse-grey" style="height: 35px; width: 35px"></div>
                                                </div>
                                                <div class="mr-4 w-75 bg-pulse-grey" style="height: 16px"></div>
                                                <div class="ml-auto bg-pulse-grey" style="width: 35px; height: 16px"></div>
                                            </div>
                                            <div class="bg-pulse-grey w-100" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-75 mt-2" style="height: 16px"></div>
                                        </div>
                                        <div class="d-flex flex-column p-2 bg-white rounded mb-2">
                                            <div class="d-flex align-items-center mb-2">
                                                <div class="mr-2">
                                                    <div class="rounded-circle bg-pulse-grey" style="height: 35px; width: 35px"></div>
                                                </div>
                                                <div class="mr-4 w-75 bg-pulse-grey" style="height: 16px"></div>
                                                <div class="ml-auto bg-pulse-grey" style="width: 35px; height: 16px"></div>
                                            </div>
                                            <div class="bg-pulse-grey w-100" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-75 mt-2" style="height: 16px"></div>
                                        </div>
                                        <div class="d-flex flex-column p-2 bg-white rounded mb-2">
                                            <div class="d-flex align-items-center mb-2">
                                                <div class="mr-2">
                                                    <div class="rounded-circle bg-pulse-grey" style="height: 35px; width: 35px"></div>
                                                </div>
                                                <div class="mr-4 w-75 bg-pulse-grey" style="height: 16px"></div>
                                                <div class="ml-auto bg-pulse-grey" style="width: 35px; height: 16px"></div>
                                            </div>
                                            <div class="bg-pulse-grey w-100" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
                                            <div class="bg-pulse-grey w-75 mt-2" style="height: 16px"></div>
                                        </div>
                                    </div>                                </div>
                            </div>                        </div>
                    </div>
                </div>
                
                <div
                    class="hidden"
                    aria-hidden="true"
                    data-region="view-group-info"
                >
                    <div
                        class="pt-3 h-100 d-flex flex-column"
                        data-region="group-info-content-container"
                        style="overflow-y: auto"
                    ></div>
                </div>                <div class="h-100 view-overview-body" aria-hidden="false" data-region="view-overview"  data-user-id="130">
                    <div id="message-drawer-view-overview-container-65781ca73823865781ca719c2e13" class="d-flex flex-column h-100" style="overflow-y: auto">
                            
                            
                            <div
                                class="section border-0 card"
                                data-region="view-overview-favourites"
                            >
                                <div id="view-overview-favourites-toggle" class="card-header p-0" data-region="toggle">
                                    <button
                                        class="btn btn-link w-100 text-left p-2 d-flex align-items-center overview-section-toggle collapsed"
                                        data-toggle="collapse"
                                        data-target="#view-overview-favourites-target-65781ca73823865781ca719c2e13"
                                        aria-expanded="false"
                                        aria-controls="view-overview-favourites-target-65781ca73823865781ca719c2e13"
                                    >
                                        <span class="collapsed-icon-container">
                                            <i class="icon fa fa-caret-right fa-fw " aria-hidden="true"  ></i>
                                        </span>
                                        <span class="expanded-icon-container">
                                            <i class="icon fa fa-caret-down fa-fw " aria-hidden="true"  ></i>
                                        </span>
                                        <span class="font-weight-bold">Starred</span>
                                        <small class="hidden ml-1" data-region="section-total-count-container"
                                        aria-label=" total conversations">
                                            (<span data-region="section-total-count"></span>)
                                        </small>
                                        <span class="hidden ml-2" data-region="loading-icon-container">
                                            <span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
                                        </span>
                                        <span class="hidden badge badge-pill badge-primary ml-auto bg-primary"
                                        data-region="section-unread-count"
                                        >
                                            
                                        </span>
                                    </button>
                                </div>
                                                            <div
                                class="collapse border-bottom  lazy-load-list"
                                aria-live="polite"
                                data-region="lazy-load-list"
                                data-user-id="130"
                                            id="view-overview-favourites-target-65781ca73823865781ca719c2e13"
            aria-labelledby="view-overview-favourites-toggle"
            data-parent="#message-drawer-view-overview-container-65781ca73823865781ca719c2e13"

                            >
                                
                                <div class="hidden text-center p-2" data-region="empty-message-container">
                                            <p class="text-muted mt-2">No starred conversations</p>

                                </div>
                                <div class="hidden list-group" data-region="content-container">
                                    
                                </div>
                                <div class="list-group" data-region="placeholder-container">
                                            <div class="text-center py-2"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
</div>

                                </div>
                                <div class="w-100 text-center p-3 hidden" data-region="loading-icon-container" >
                                    <span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
                                </div>
                            </div>
                            </div>
                            
                            
                            <div
                                class="section border-0 card"
                                data-region="view-overview-group-messages"
                            >
                                <div id="view-overview-group-messages-toggle" class="card-header p-0" data-region="toggle">
                                    <button
                                        class="btn btn-link w-100 text-left p-2 d-flex align-items-center overview-section-toggle collapsed"
                                        data-toggle="collapse"
                                        data-target="#view-overview-group-messages-target-65781ca73823865781ca719c2e13"
                                        aria-expanded="false"
                                        aria-controls="view-overview-group-messages-target-65781ca73823865781ca719c2e13"
                                    >
                                        <span class="collapsed-icon-container">
                                            <i class="icon fa fa-caret-right fa-fw " aria-hidden="true"  ></i>
                                        </span>
                                        <span class="expanded-icon-container">
                                            <i class="icon fa fa-caret-down fa-fw " aria-hidden="true"  ></i>
                                        </span>
                                        <span class="font-weight-bold">Group</span>
                                        <small class="hidden ml-1" data-region="section-total-count-container"
                                        aria-label=" total conversations">
                                            (<span data-region="section-total-count"></span>)
                                        </small>
                                        <span class="hidden ml-2" data-region="loading-icon-container">
                                            <span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
                                        </span>
                                        <span class="hidden badge badge-pill badge-primary ml-auto bg-primary"
                                        data-region="section-unread-count"
                                        >
                                            
                                        </span>
                                    </button>
                                </div>
                                                            <div
                                class="collapse border-bottom  lazy-load-list"
                                aria-live="polite"
                                data-region="lazy-load-list"
                                data-user-id="130"
                                            id="view-overview-group-messages-target-65781ca73823865781ca719c2e13"
            aria-labelledby="view-overview-group-messages-toggle"
            data-parent="#message-drawer-view-overview-container-65781ca73823865781ca719c2e13"

                            >
                                
                                <div class="hidden text-center p-2" data-region="empty-message-container">
                                            <p class="text-muted mt-2">No group conversations</p>

                                </div>
                                <div class="hidden list-group" data-region="content-container">
                                    
                                </div>
                                <div class="list-group" data-region="placeholder-container">
                                            <div class="text-center py-2"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
</div>

                                </div>
                                <div class="w-100 text-center p-3 hidden" data-region="loading-icon-container" >
                                    <span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
                                </div>
                            </div>
                            </div>
                            
                            
                            <div
                                class="section border-0 card"
                                data-region="view-overview-messages"
                            >
                                <div id="view-overview-messages-toggle" class="card-header p-0" data-region="toggle">
                                    <button
                                        class="btn btn-link w-100 text-left p-2 d-flex align-items-center overview-section-toggle collapsed"
                                        data-toggle="collapse"
                                        data-target="#view-overview-messages-target-65781ca73823865781ca719c2e13"
                                        aria-expanded="false"
                                        aria-controls="view-overview-messages-target-65781ca73823865781ca719c2e13"
                                    >
                                        <span class="collapsed-icon-container">
                                            <i class="icon fa fa-caret-right fa-fw " aria-hidden="true"  ></i>
                                        </span>
                                        <span class="expanded-icon-container">
                                            <i class="icon fa fa-caret-down fa-fw " aria-hidden="true"  ></i>
                                        </span>
                                        <span class="font-weight-bold">Private</span>
                                        <small class="hidden ml-1" data-region="section-total-count-container"
                                        aria-label=" total conversations">
                                            (<span data-region="section-total-count"></span>)
                                        </small>
                                        <span class="hidden ml-2" data-region="loading-icon-container">
                                            <span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
                                        </span>
                                        <span class="hidden badge badge-pill badge-primary ml-auto bg-primary"
                                        data-region="section-unread-count"
                                        >
                                            
                                        </span>
                                    </button>
                                </div>
                                                            <div
                                class="collapse border-bottom  lazy-load-list"
                                aria-live="polite"
                                data-region="lazy-load-list"
                                data-user-id="130"
                                            id="view-overview-messages-target-65781ca73823865781ca719c2e13"
            aria-labelledby="view-overview-messages-toggle"
            data-parent="#message-drawer-view-overview-container-65781ca73823865781ca719c2e13"

                            >
                                
                                <div class="hidden text-center p-2" data-region="empty-message-container">
                                            <p class="text-muted mt-2">No private conversations</p>

                                </div>
                                <div class="hidden list-group" data-region="content-container">
                                    
                                </div>
                                <div class="list-group" data-region="placeholder-container">
                                            <div class="text-center py-2"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
</div>

                                </div>
                                <div class="w-100 text-center p-3 hidden" data-region="loading-icon-container" >
                                    <span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
                                </div>
                            </div>
                            </div>
                    </div>
                </div>
                
                <div
                    data-region="view-search"
                    aria-hidden="true"
                    class="h-100 hidden"
                    data-user-id="130"
                    data-users-offset="0"
                    data-messages-offset="0"
                    style="overflow-y: auto"
                    
                >
                    <div class="hidden" data-region="search-results-container" style="overflow-y: auto">
                        
                        <div class="d-flex flex-column">
                            <div class="mb-3 bg-white" data-region="all-contacts-container">
                                <div data-region="contacts-container"  class="pt-2">
                                    <h4 class="h6 px-2">Contacts</h4>
                                    <div class="list-group" data-region="list"></div>
                                </div>
                                <div data-region="non-contacts-container" class="pt-2 border-top">
                                    <h4 class="h6 px-2">Non-contacts</h4>
                                    <div class="list-group" data-region="list"></div>
                                </div>
                                <div class="text-right">
                                    <button class="btn btn-link text-primary" data-action="load-more-users">
                                        <span data-region="button-text">Load more</span>
                                        <span data-region="loading-icon-container" class="hidden"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
</span>
                                    </button>
                                </div>
                            </div>
                            <div class="bg-white" data-region="messages-container">
                                <h4 class="h6 px-2 pt-2">Messages</h4>
                                <div class="list-group" data-region="list"></div>
                                <div class="text-right">
                                    <button class="btn btn-link text-primary" data-action="load-more-messages">
                                        <span data-region="button-text">Load more</span>
                                        <span data-region="loading-icon-container" class="hidden"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
</span>
                                    </button>
                                </div>
                            </div>
                            <p class="hidden p-3 text-center" data-region="no-results-container">No results</p>
                        </div>                    </div>
                    <div class="hidden" data-region="loading-placeholder">
                        <div class="text-center pt-3 icon-size-4"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
</div>
                    </div>
                    <div class="p-3 text-center" data-region="empty-message-container">
                        <p>Search people and messages</p>
                    </div>
                </div>                
                <div class="h-100 hidden bg-white" aria-hidden="true" data-region="view-settings">
                    <div class="hidden" data-region="content-container">
                        
                        <div data-region="settings" class="p-3">
                            <h3 class="h6 font-weight-bold">Privacy</h3>
                            <p>You can restrict who can message you</p>
                            <div data-preference="blocknoncontacts" class="mb-3">
                                <fieldset>
                                    <legend class="sr-only">Accept messages from:</legend>
                                        <div class="custom-control custom-radio mb-2">
                                            <input
                                                type="radio"
                                                name="message_blocknoncontacts"
                                                class="custom-control-input"
                                                id="block-noncontacts-65781ca73823865781ca719c2e13-1"
                                                value="1"
                                            >
                                            <label class="custom-control-label ml-2" for="block-noncontacts-65781ca73823865781ca719c2e13-1">
                                                My contacts only
                                            </label>
                                        </div>
                                        <div class="custom-control custom-radio mb-2">
                                            <input
                                                type="radio"
                                                name="message_blocknoncontacts"
                                                class="custom-control-input"
                                                id="block-noncontacts-65781ca73823865781ca719c2e13-0"
                                                value="0"
                                            >
                                            <label class="custom-control-label ml-2" for="block-noncontacts-65781ca73823865781ca719c2e13-0">
                                                My contacts and anyone in my courses
                                            </label>
                                        </div>
                                </fieldset>
                            </div>
                        
                            <div class="hidden" data-region="notification-preference-container">
                                <h3 class="mb-2 mt-4 h6 font-weight-bold">Notification preferences</h3>
                            </div>
                        
                            <h3 class="mb-2 mt-4 h6 font-weight-bold">General</h3>
                            <div data-preference="entertosend">
                                <span class="switch">
                                    <input type="checkbox"
                                        id="enter-to-send-65781ca73823865781ca719c2e13"
                                        checked
                                    >
                                    <label for="enter-to-send-65781ca73823865781ca719c2e13">
                                        Use enter to send
                                    </label>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div data-region="placeholder-container">
                        
                        <div class="d-flex flex-column p-3">
                            <div class="w-25 bg-pulse-grey h6" style="height: 18px"></div>
                            <div class="w-75 bg-pulse-grey mb-4" style="height: 18px"></div>
                            <div class="mb-3">
                                <div class="w-100 d-flex mb-3">
                                    <div class="bg-pulse-grey rounded-circle" style="width: 18px; height: 18px"></div>
                                    <div class="bg-pulse-grey w-50 ml-2" style="height: 18px"></div>
                                </div>
                                <div class="w-100 d-flex mb-3">
                                    <div class="bg-pulse-grey rounded-circle" style="width: 18px; height: 18px"></div>
                                    <div class="bg-pulse-grey w-50 ml-2" style="height: 18px"></div>
                                </div>
                                <div class="w-100 d-flex mb-3">
                                    <div class="bg-pulse-grey rounded-circle" style="width: 18px; height: 18px"></div>
                                    <div class="bg-pulse-grey w-50 ml-2" style="height: 18px"></div>
                                </div>
                            </div>
                            <div class="w-50 bg-pulse-grey h6 mb-3 mt-2" style="height: 18px"></div>
                            <div class="mb-4">
                                <div class="w-100 d-flex mb-2 align-items-center">
                                    <div class="bg-pulse-grey w-25" style="width: 18px; height: 27px"></div>
                                    <div class="bg-pulse-grey w-25 ml-2" style="height: 18px"></div>
                                </div>
                                <div class="w-100 d-flex mb-2 align-items-center">
                                    <div class="bg-pulse-grey w-25" style="width: 18px; height: 27px"></div>
                                    <div class="bg-pulse-grey w-25 ml-2" style="height: 18px"></div>
                                </div>
                            </div>
                            <div class="w-25 bg-pulse-grey h6 mb-3 mt-2" style="height: 18px"></div>
                            <div class="mb-3">
                                <div class="w-100 d-flex mb-2 align-items-center">
                                    <div class="bg-pulse-grey w-25" style="width: 18px; height: 27px"></div>
                                    <div class="bg-pulse-grey w-50 ml-2" style="height: 18px"></div>
                                </div>
                            </div>
                        </div>                    </div>
                </div>            </div>
            <div class="footer-container position-relative" data-region="footer-container">
                
                <div
                    class="hidden border-top bg-white position-relative"
                    aria-hidden="true"
                    data-region="view-conversation"
                    data-enter-to-send="1"
                >
                    <div class="hidden p-2" data-region="content-messages-footer-container">
                        
                            <div
                                class="emoji-auto-complete-container w-100 hidden"
                                data-region="emoji-auto-complete-container"
                                aria-live="polite"
                                aria-hidden="true"
                            >
                            </div>
                        <div class="d-flex mt-1">
                            <textarea
                                dir="auto"
                                data-region="send-message-txt"
                                class="form-control bg-light"
                                rows="3"
                                data-auto-rows
                                data-min-rows="3"
                                data-max-rows="5"
                                aria-label="Write a message..."
                                placeholder="Write a message..."
                                style="resize: none"
                                maxlength="4096"
                            ></textarea>
                        
                            <div class="position-relative d-flex flex-column">
                                    <div
                                        data-region="emoji-picker-container"
                                        class="emoji-picker-container hidden"
                                        aria-hidden="true"
                                    >
                                        
                                        <div
                                            data-region="emoji-picker"
                                            class="card shadow emoji-picker"
                                        >
                                            <div class="card-header px-1 pt-1 pb-0 d-flex justify-content-between flex-shrink-0">
                                                <button
                                                    class="btn btn-outline-secondary icon-no-margin category-button selected"
                                                    data-action="show-category"
                                                    data-category="Recent"
                                                    title="Recent"
                                                >
                                                    <i class="icon fa fa-clock-o fa-fw " aria-hidden="true"  ></i>
                                                </button>
                                                <button
                                                    class="btn btn-outline-secondary icon-no-margin category-button"
                                                    data-action="show-category"
                                                    data-category="Smileys & People"
                                                    title="Smileys & people"
                                                >
                                                    <i class="icon fa fa-smile-o fa-fw " aria-hidden="true"  ></i>
                                                </button>
                                                <button
                                                    class="btn btn-outline-secondary icon-no-margin category-button"
                                                    data-action="show-category"
                                                    data-category="Animals & Nature"
                                                    title="Animals & nature"
                                                >
                                                    <i class="icon fa fa-leaf fa-fw " aria-hidden="true"  ></i>
                                                </button>
                                                <button
                                                    class="btn btn-outline-secondary icon-no-margin category-button"
                                                    data-action="show-category"
                                                    data-category="Food & Drink"
                                                    title="Food & drink"
                                                >
                                                    <i class="icon fa fa-cutlery fa-fw " aria-hidden="true"  ></i>
                                                </button>
                                                <button
                                                    class="btn btn-outline-secondary icon-no-margin category-button"
                                                    data-action="show-category"
                                                    data-category="Travel & Places"
                                                    title="Travel & places"
                                                >
                                                    <i class="icon fa fa-plane fa-fw " aria-hidden="true"  ></i>
                                                </button>
                                                <button
                                                    class="btn btn-outline-secondary icon-no-margin category-button"
                                                    data-action="show-category"
                                                    data-category="Activities"
                                                    title="Activities"
                                                >
                                                    <i class="icon fa fa-futbol-o fa-fw " aria-hidden="true"  ></i>
                                                </button>
                                                <button
                                                    class="btn btn-outline-secondary icon-no-margin category-button"
                                                    data-action="show-category"
                                                    data-category="Objects"
                                                    title="Objects"
                                                >
                                                    <i class="icon fa fa-lightbulb-o fa-fw " aria-hidden="true"  ></i>
                                                </button>
                                                <button
                                                    class="btn btn-outline-secondary icon-no-margin category-button"
                                                    data-action="show-category"
                                                    data-category="Symbols"
                                                    title="Symbols"
                                                >
                                                    <i class="icon fa fa-heart fa-fw " aria-hidden="true"  ></i>
                                                </button>
                                                <button
                                                    class="btn btn-outline-secondary icon-no-margin category-button"
                                                    data-action="show-category"
                                                    data-category="Flags"
                                                    title="Flags"
                                                >
                                                    <i class="icon fa fa-flag fa-fw " aria-hidden="true"  ></i>
                                                </button>
                                            </div>
                                            <div class="card-body p-2 d-flex flex-column overflow-hidden">
                                                <div class="input-group mb-1 flex-shrink-0">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text pr-0 bg-white text-muted">
                                                            <i class="icon fa fa-search fa-fw " aria-hidden="true"  ></i>
                                                        </span>
                                                    </div>
                                                    <input
                                                        type="text"
                                                        class="form-control border-left-0"
                                                        placeholder="Search"
                                                        aria-label="Search"
                                                        data-region="search-input"
                                                    >
                                                </div>
                                                <div class="flex-grow-1 overflow-auto emojis-container h-100" data-region="emojis-container">
                                                    <div class="position-relative" data-region="row-container"></div>
                                                </div>
                                                <div class="flex-grow-1 overflow-auto search-results-container h-100 hidden" data-region="search-results-container">
                                                    <div class="position-relative" data-region="row-container"></div>
                                                </div>
                                            </div>
                                            <div
                                                class="card-footer d-flex flex-shrink-0"
                                                data-region="footer"
                                            >
                                                <div class="emoji-preview" data-region="emoji-preview"></div>
                                                <div data-region="emoji-short-name" class="emoji-short-name text-muted text-wrap ml-2"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <button
                                        class="btn btn-link btn-icon icon-size-3 ml-1"
                                        aria-label="Toggle emoji picker"
                                        data-action="toggle-emoji-picker"
                                    >
                                        <i class="icon fa fa-smile-o fa-fw " aria-hidden="true"  ></i>
                                    </button>
                                <button
                                    class="btn btn-link btn-icon icon-size-3 ml-1 mt-auto"
                                    aria-label="Send message"
                                    data-action="send-message"
                                >
                                    <span data-region="send-icon-container"><i class="icon fa fa-paper-plane fa-fw " aria-hidden="true"  ></i></span>
                                    <span class="hidden" data-region="loading-icon-container"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
</span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="hidden p-2" data-region="content-messages-footer-edit-mode-container">
                        
                        <div class="d-flex p-3 justify-content-end">
                            <button
                                class="btn btn-link btn-icon my-1 icon-size-4"
                                data-action="delete-selected-messages"
                                data-toggle="tooltip"
                                data-placement="top"
                                title="Delete selected messages"
                            >
                                <span data-region="icon-container"><i class="icon fa fa-trash fa-fw " aria-hidden="true"  ></i></span>
                                <span class="hidden" data-region="loading-icon-container"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
</span>
                                <span class="sr-only">Delete selected messages</span>
                            </button>
                        </div>                    </div>
                    <div class="hidden bg-secondary p-3" data-region="content-messages-footer-require-contact-container">
                        
                        <div class="p-3 bg-white">
                            <p data-region="title"></p>
                            <p class="text-muted" data-region="text"></p>
                            <button type="button" class="btn btn-primary btn-block" data-action="request-add-contact">
                                <span data-region="dialogue-button-text">Send contact request</span>
                                <span class="hidden" data-region="loading-icon-container"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
</span>
                            </button>
                        </div>
                    </div>
                    <div class="hidden bg-secondary p-3" data-region="content-messages-footer-require-unblock-container">
                        
                        <div class="p-3 bg-white">
                            <p class="text-muted" data-region="text">You have blocked this user.</p>
                            <button type="button" class="btn btn-primary btn-block" data-action="request-unblock">
                                <span data-region="dialogue-button-text">Unblock user</span>
                                <span class="hidden" data-region="loading-icon-container"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw "  title="Loading" aria-label="Loading"></i></span>
</span>
                            </button>
                        </div>
                    </div>
                    <div class="hidden bg-secondary p-3" data-region="content-messages-footer-unable-to-message">
                        
                        <div class="p-3 bg-white">
                            <p class="text-muted" data-region="text">You are unable to message this user</p>
                        </div>
                    </div>
                    <div class="p-2" data-region="placeholder-container">
                        <div class="d-flex">
                            <div class="bg-pulse-grey w-100" style="height: 80px"></div>
                            <div class="mx-2 mb-2 align-self-end bg-pulse-grey" style="height: 20px; width: 20px"></div>
                        </div>                    </div>
                    <div
                        class="hidden position-absolute"
                        data-region="confirm-dialogue-container"
                        style="top: -1px; bottom: 0; right: 0; left: 0; background: rgba(0,0,0,0.3);"
                    ></div>
                </div>                    <div data-region="view-overview" class="text-center">
                        <a href="https://moodle-stage.laerdalblr.in/message/index.php">
                            See all
                        </a>
                    </div>
            </div>
        </div>

</div>
    <footer id="page-footer" class="py-3 bg-dark text-light">
        <div class="container">
            <div id="course-footer"></div>
    
                <p class="helplink"><a href="https://docs.moodle.org/38/en/course/edit"><i class="icon fa fa-info-circle fa-fw iconhelp icon-pre" aria-hidden="true"  ></i>Moodle Docs for this page</a></p>
    
            <div class="logininfo">You are logged in as <a href="https://moodle-stage.laerdalblr.in/user/profile.php?id=130" title="View profile">Test Auto</a> (<a href="https://moodle-stage.laerdalblr.in/login/logout.php?sesskey=fZoB308Em3">Log out</a>)</div>
            <div class="tool_usertours-resettourcontainer"></div>
            <div class="homelink"><a href="https://moodle-stage.laerdalblr.in/">Home</a></div>
            <nav class="nav navbar-nav d-md-none" aria-label="Custom menu">
                    <ul class="list-unstyled pt-3">
                    </ul>
            </nav>
            <div class="tool_dataprivacy"><a href="https://moodle-stage.laerdalblr.in/admin/tool/dataprivacy/summary.php">Data retention summary</a></div><a href="https://download.moodle.org/mobile?version=2019111808.02&amp;lang=en&amp;iosappid=633359593&amp;androidappid=com.moodle.moodlemobile">Get the mobile app</a>
            <script>
//<![CDATA[
var require = {
    baseUrl : 'https://moodle-stage.laerdalblr.in/lib/requirejs.php/1617770024/',
    // We only support AMD modules with an explicit define() statement.
    enforceDefine: true,
    skipDataMain: true,
    waitSeconds : 0,

    paths: {
        jquery: 'https://moodle-stage.laerdalblr.in/lib/javascript.php/1617770024/lib/jquery/jquery-3.5.1.min',
        jqueryui: 'https://moodle-stage.laerdalblr.in/lib/javascript.php/1617770024/lib/jquery/ui-1.12.1/jquery-ui.min',
        jqueryprivate: 'https://moodle-stage.laerdalblr.in/lib/javascript.php/1617770024/lib/requirejs/jquery-private'
    },

    // Custom jquery config map.
    map: {
      // '*' means all modules will get 'jqueryprivate'
      // for their 'jquery' dependency.
      '*': { jquery: 'jqueryprivate' },
      // Stub module for 'process'. This is a workaround for a bug in MathJax (see MDL-60458).
      '*': { process: 'core/first' },

      // 'jquery-private' wants the real jQuery module
      // though. If this line was not here, there would
      // be an unresolvable cyclic dependency.
      jqueryprivate: { jquery: 'jquery' }
    }
};

//]]>
</script>
<script src="https://moodle-stage.laerdalblr.in/lib/javascript.php/1617770024/lib/requirejs/require.min.js"></script>
<script>
//<![CDATA[
M.util.js_pending("core/first");require(['core/first'], function() {
;
require(["media_videojs/loader"], function(loader) {
    loader.setUp(function(videojs) {
        videojs.options.flash.swf = "https://moodle-stage.laerdalblr.in/media/player/videojs/videojs/video-js.swf";
videojs.addLanguage('en', {
  "Audio Player": "Audio Player",
  "Video Player": "Video Player",
  "Play": "Play",
  "Pause": "Pause",
  "Replay": "Replay",
  "Current Time": "Current Time",
  "Duration": "Duration",
  "Remaining Time": "Remaining Time",
  "Stream Type": "Stream Type",
  "LIVE": "LIVE",
  "Seek to live, currently behind live": "Seek to live, currently behind live",
  "Seek to live, currently playing live": "Seek to live, currently playing live",
  "Loaded": "Loaded",
  "Progress": "Progress",
  "Progress Bar": "Progress Bar",
  "progress bar timing: currentTime={1} duration={2}": "{1} of {2}",
  "Fullscreen": "Fullscreen",
  "Non-Fullscreen": "Non-Fullscreen",
  "Mute": "Mute",
  "Unmute": "Unmute",
  "Playback Rate": "Playback Rate",
  "Subtitles": "Subtitles",
  "subtitles off": "subtitles off",
  "Captions": "Captions",
  "captions off": "captions off",
  "Chapters": "Chapters",
  "Descriptions": "Descriptions",
  "descriptions off": "descriptions off",
  "Audio Track": "Audio Track",
  "Volume Level": "Volume Level",
  "You aborted the media playback": "You aborted the media playback",
  "A network error caused the media download to fail part-way.": "A network error caused the media download to fail part-way.",
  "The media could not be loaded, either because the server or network failed or because the format is not supported.": "The media could not be loaded, either because the server or network failed or because the format is not supported.",
  "The media playback was aborted due to a corruption problem or because the media used features your browser did not support.": "The media playback was aborted due to a corruption problem or because the media used features your browser did not support.",
  "No compatible source was found for this media.": "No compatible source was found for this media.",
  "The media is encrypted and we do not have the keys to decrypt it.": "The media is encrypted and we do not have the keys to decrypt it.",
  "Play Video": "Play Video",
  "Close": "Close",
  "Close Modal Dialog": "Close Modal Dialog",
  "Modal Window": "Modal Window",
  "This is a modal window": "This is a modal window",
  "This modal can be closed by pressing the Escape key or activating the close button.": "This modal can be closed by pressing the Escape key or activating the close button.",
  ", opens captions settings dialog": ", opens captions settings dialog",
  ", opens subtitles settings dialog": ", opens subtitles settings dialog",
  ", opens descriptions settings dialog": ", opens descriptions settings dialog",
  ", selected": ", selected",
  "captions settings": "captions settings",
  "subtitles settings": "subititles settings",
  "descriptions settings": "descriptions settings",
  "Text": "Text",
  "White": "White",
  "Black": "Black",
  "Red": "Red",
  "Green": "Green",
  "Blue": "Blue",
  "Yellow": "Yellow",
  "Magenta": "Magenta",
  "Cyan": "Cyan",
  "Background": "Background",
  "Window": "Window",
  "Transparent": "Transparent",
  "Semi-Transparent": "Semi-Transparent",
  "Opaque": "Opaque",
  "Font Size": "Font Size",
  "Text Edge Style": "Text Edge Style",
  "None": "None",
  "Raised": "Raised",
  "Depressed": "Depressed",
  "Uniform": "Uniform",
  "Dropshadow": "Dropshadow",
  "Font Family": "Font Family",
  "Proportional Sans-Serif": "Proportional Sans-Serif",
  "Monospace Sans-Serif": "Monospace Sans-Serif",
  "Proportional Serif": "Proportional Serif",
  "Monospace Serif": "Monospace Serif",
  "Casual": "Casual",
  "Script": "Script",
  "Small Caps": "Small Caps",
  "Reset": "Reset",
  "restore all settings to the default values": "restore all settings to the default values",
  "Done": "Done",
  "Caption Settings Dialog": "Caption Settings Dialog",
  "Beginning of dialog window. Escape will cancel and close the window.": "Beginning of dialog window. Escape will cancel and close the window.",
  "End of dialog window.": "End of dialog window.",
  "{1} is loading.": "{1} is loading."
});

    });
});;

require(['jquery', 'message_popup/notification_popover_controller'], function($, controller) {
    var container = $('#nav-notification-popover-container');
    var controller = new controller(container);
    controller.registerEventListeners();
    controller.registerListNavigationEventListeners();
});
;

require(
[
    'jquery',
    'core_message/message_popover'
],
function(
    $,
    Popover
) {
    var toggle = $('#message-drawer-toggle-65781ca73117865781ca719c2e3');
    Popover.init(toggle);
});
;

require(['jquery', 'core_message/message_drawer'], function($, MessageDrawer) {
    var root = $('#message-drawer-65781ca73823865781ca719c2e13');
    MessageDrawer.init(root, '65781ca73823865781ca719c2e13', false);
});
;

M.util.js_pending('theme_boost/loader');
require(['theme_boost/loader'], function() {
  M.util.js_complete('theme_boost/loader');
});
M.util.js_pending('theme_boost/drawer');
require(['theme_boost/drawer'], function(mod) {
    mod.init();
  M.util.js_complete('theme_boost/drawer');
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_fullname");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_shortname");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_category");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_visible");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_startdate_day");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_startdate_month");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_startdate_year");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_startdate_hour");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_startdate_minute");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_startdate");
});
;

require(['jquery'], function($) {
    $('#id_startdate_label').css('cursor', 'default');
    $('#id_startdate_label').click(function() {
        $('#id_startdate')
            .find('button, a, input:not([type="hidden"]), select, textarea, [tabindex]')
            .filter(':not([disabled]):not([tabindex="0"]):not([tabindex="-1"])')
            .first().focus();
    });
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_enddate_day");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_enddate_month");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_enddate_year");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_enddate_hour");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_enddate_minute");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_enddate_enabled");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_enddate");
});
;

require(['jquery'], function($) {
    $('#id_enddate_label').css('cursor', 'default');
    $('#id_enddate_label').click(function() {
        $('#id_enddate')
            .find('button, a, input:not([type="hidden"]), select, textarea, [tabindex]')
            .filter(':not([disabled]):not([tabindex="0"]):not([tabindex="-1"])')
            .first().focus();
    });
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_idnumber");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_summary_editor");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_overviewfiles_filemanager");
});
;

(function() {
    var label = document.getElementById('id_overviewfiles_filemanager_label');
    if (label) {
        label.style.cursor = 'default';
        label.addEventListener('click', function() {
            document.querySelectorAll('#id_overviewfiles_filemanager_fieldset div.fp-toolbar a')[0].focus();
        });
    }
})();
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_format");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_updatecourseformat");
});
;

        require(['core_form/submit'], function(Submit) {
            Submit.init("id_updatecourseformat");
        });
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_numsections");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_hiddensections");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_coursedisplay");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_lang");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_newsitems");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_showgrades");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_showreports");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_maxbytes");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_enablecompletion");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_groupmode");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_groupmodeforce");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_defaultgroupingid");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_role_1");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_role_2");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_role_3");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_role_4");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_role_5");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_role_6");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_role_7");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_role_8");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_tags");
});
;

require(['core/form-autocomplete'], function(module) {
    module.enhance("#id_tags",
                   1,
                   "",
                   "Enter tags...",
                   0,
                   1,
                   "No selection");
});
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_saveanddisplay");
});
;

        require(['core_form/submit'], function(Submit) {
            Submit.init("id_saveanddisplay");
        });
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("id_cancel");
});
;

        require(['core_form/submit'], function(Submit) {
            Submit.init("id_cancel");
        });
;

require(['theme_boost/form-display-errors'], function(module) {
    module.enhance("fgroup_id_buttonar");
});
;

require(['jquery'], function($) {
    $('#fgroup_id_buttonar_label').css('cursor', 'default');
    $('#fgroup_id_buttonar_label').click(function() {
        $('#fgroup_id_buttonar')
            .find('button, a, input:not([type="hidden"]), select, textarea, [tabindex]')
            .filter(':not([disabled]):not([tabindex="0"]):not([tabindex="-1"])')
            .first().focus();
    });
});
;


require(["core/event", "jquery"], function(Event, $) {

    function qf_errorHandler(element, _qfMsg, escapedName) {
        var event = $.Event(Event.Events.FORM_FIELD_VALIDATION);
        $(element).trigger(event, _qfMsg);
        if (event.isDefaultPrevented()) {
            return _qfMsg == '';
        } else {
            // Legacy mforms.
            var div = element.parentNode;

            if ((div == undefined) || (element.name == undefined)) {
                // No checking can be done for undefined elements so let server handle it.
                return true;
            }

            if (_qfMsg != '') {
                var errorSpan = document.getElementById('id_error_' + escapedName);
                if (!errorSpan) {
                    errorSpan = document.createElement("span");
                    errorSpan.id = 'id_error_' + escapedName;
                    errorSpan.className = "error";
                    element.parentNode.insertBefore(errorSpan, element.parentNode.firstChild);
                    document.getElementById(errorSpan.id).setAttribute('TabIndex', '0');
                    document.getElementById(errorSpan.id).focus();
                }

                while (errorSpan.firstChild) {
                    errorSpan.removeChild(errorSpan.firstChild);
                }

                errorSpan.appendChild(document.createTextNode(_qfMsg.substring(3)));

                if (div.className.substr(div.className.length - 6, 6) != " error"
                        && div.className != "error") {
                    div.className += " error";
                    linebreak = document.createElement("br");
                    linebreak.className = "error";
                    linebreak.id = 'id_error_break_' + escapedName;
                    errorSpan.parentNode.insertBefore(linebreak, errorSpan.nextSibling);
                }

                return false;
            } else {
                var errorSpan = document.getElementById('id_error_' + escapedName);
                if (errorSpan) {
                    errorSpan.parentNode.removeChild(errorSpan);
                }
                var linebreak = document.getElementById('id_error_break_' + escapedName);
                if (linebreak) {
                    linebreak.parentNode.removeChild(linebreak);
                }

                if (div.className.substr(div.className.length - 6, 6) == " error") {
                    div.className = div.className.substr(0, div.className.length - 6);
                } else if (div.className == "error") {
                    div.className = "";
                }

                return true;
            } // End if.
        } // End if.
    } // End function.
    
    function validate_course_edit_form_fullname(element, escapedName) {
      if (undefined == element) {
         //required element was not found, then let form be submitted without client side validation
         return true;
      }
      var value = '';
      var errFlag = new Array();
      var _qfGroups = {};
      var _qfMsg = '';
      var frm = element.parentNode;
      if ((undefined != element.name) && (frm != undefined)) {
          while (frm && frm.nodeName.toUpperCase() != "FORM") {
            frm = frm.parentNode;
          }
          value = frm.elements['fullname'].value;
  if (value == '' && !errFlag['fullname']) {
    errFlag['fullname'] = true;
    _qfMsg = _qfMsg + '\n - Missing full name';
  }

          return qf_errorHandler(element, _qfMsg, escapedName);
      } else {
        //element name should be defined else error msg will not be displayed.
        return true;
      }
    }

    document.getElementById('id_fullname').addEventListener('blur', function(ev) {
        validate_course_edit_form_fullname(ev.target, 'fullname')
    });
    document.getElementById('id_fullname').addEventListener('change', function(ev) {
        validate_course_edit_form_fullname(ev.target, 'fullname')
    });

    function validate_course_edit_form_shortname(element, escapedName) {
      if (undefined == element) {
         //required element was not found, then let form be submitted without client side validation
         return true;
      }
      var value = '';
      var errFlag = new Array();
      var _qfGroups = {};
      var _qfMsg = '';
      var frm = element.parentNode;
      if ((undefined != element.name) && (frm != undefined)) {
          while (frm && frm.nodeName.toUpperCase() != "FORM") {
            frm = frm.parentNode;
          }
          value = frm.elements['shortname'].value;
  if (value == '' && !errFlag['shortname']) {
    errFlag['shortname'] = true;
    _qfMsg = _qfMsg + '\n - Missing short name';
  }

          return qf_errorHandler(element, _qfMsg, escapedName);
      } else {
        //element name should be defined else error msg will not be displayed.
        return true;
      }
    }

    document.getElementById('id_shortname').addEventListener('blur', function(ev) {
        validate_course_edit_form_shortname(ev.target, 'shortname')
    });
    document.getElementById('id_shortname').addEventListener('change', function(ev) {
        validate_course_edit_form_shortname(ev.target, 'shortname')
    });


    function validate_course_edit_form() {
      if (skipClientValidation) {
         return true;
      }
      var ret = true;

      var frm = document.getElementById('mform1_2UgX3cbcrCd9RgL')
      var first_focus = false;
    
      ret = validate_course_edit_form_fullname(frm.elements['fullname'], 'fullname') && ret;
      if (!ret && !first_focus) {
        first_focus = true;
        Y.use('moodle-core-event', function() {
            Y.Global.fire(M.core.globalEvents.FORM_ERROR, {formid: 'mform1_2UgX3cbcrCd9RgL',
                                                           elementid: 'mform1_2UgX3cbcrCd9RgL'});
            document.getElementById('mform1_2UgX3cbcrCd9RgL').focus();
        });
      }

      ret = validate_course_edit_form_shortname(frm.elements['shortname'], 'shortname') && ret;
      if (!ret && !first_focus) {
        first_focus = true;
        Y.use('moodle-core-event', function() {
            Y.Global.fire(M.core.globalEvents.FORM_ERROR, {formid: 'mform1_2UgX3cbcrCd9RgL',
                                                           elementid: 'mform1_2UgX3cbcrCd9RgL'});
            document.getElementById('mform1_2UgX3cbcrCd9RgL').focus();
        });
      }
;
      return ret;
    }

    var form = $(document.getElementById('mform1_2UgX3cbcrCd9RgL')).closest('form');
    form.on(M.core.event.FORM_SUBMIT_AJAX, function() {
        try {
            var myValidator = validate_course_edit_form;
        } catch(e) {
            return true;
        }
        if (myValidator) {
            myValidator();
        }
    });

    document.getElementById('mform1_2UgX3cbcrCd9RgL').addEventListener('submit', function(ev) {
        try {
            var myValidator = validate_course_edit_form;
        } catch(e) {
            return true;
        }
        if (typeof window.tinyMCE !== 'undefined') {
            window.tinyMCE.triggerSave();
        }
        if (!myValidator()) {
            ev.preventDefault();
        }
    });

});
;
M.util.js_pending('core/notification'); require(['core/notification'], function(amd) {amd.init(958, []); M.util.js_complete('core/notification');});;
M.util.js_pending('core/log'); require(['core/log'], function(amd) {amd.setConfig({"level":"warn"}); M.util.js_complete('core/log');});;
M.util.js_pending('core/page_global'); require(['core/page_global'], function(amd) {amd.init(); M.util.js_complete('core/page_global');});M.util.js_complete("core/first");
});
//]]>
</script>
<script>
//<![CDATA[
M.yui.add_module({"core_filepicker":{"name":"core_filepicker","fullpath":"https:\/\/moodle-stage.laerdalblr.in\/lib\/javascript.php\/1617770024\/repository\/filepicker.js","requires":["base","node","node-event-simulate","json","async-queue","io-base","io-upload-iframe","io-form","yui2-treeview","panel","cookie","datatable","datatable-sort","resize-plugin","dd-plugin","escape","moodle-core_filepicker","moodle-core-notification-dialogue"]},"core_dndupload":{"name":"core_dndupload","fullpath":"https:\/\/moodle-stage.laerdalblr.in\/lib\/javascript.php\/1617770024\/lib\/form\/dndupload.js","requires":["node","event","json","core_filepicker"]},"form_filemanager":{"name":"form_filemanager","fullpath":"https:\/\/moodle-stage.laerdalblr.in\/lib\/javascript.php\/1617770024\/lib\/form\/filemanager.js","requires":["moodle-core-notification-dialogue","core_filepicker","base","io-base","node","json","core_dndupload","panel","resize-plugin","dd-plugin"]},"mform":{"name":"mform","fullpath":"https:\/\/moodle-stage.laerdalblr.in\/lib\/javascript.php\/1617770024\/lib\/form\/form.js","requires":["base","node"]}});

//]]>
</script>
<script src="https://moodle-stage.laerdalblr.in/lib/h5p/js/h5p-resizer.js"></script>
<script>
//<![CDATA[
M.str = {"moodle":{"lastmodified":"Last modified","name":"Name","error":"Error","info":"Information","yes":"Yes","no":"No","cancel":"Cancel","changesmadereallygoaway":"You have made changes. Are you sure you want to navigate away and lose your changes?","collapseall":"Collapse all","expandall":"Expand all","warning":"Warning","edit":"Edit","uploadformlimit":"Uploaded file {$a} exceeded the maximum size limit set by the form","droptoupload":"Drop files here to upload","maxfilesreached":"You are allowed to attach a maximum of {$a} file(s) to this item","dndenabled_inbox":"You can drag and drop files here to add them.","fileexists":"There is already a file called {$a}","sizegb":"GB","sizemb":"MB","sizekb":"KB","sizeb":"bytes","maxareabytesreached":"The file (or the total size of several files) is larger than the space remaining in this area.","complete":"Complete","confirm":"Confirm","areyousure":"Are you sure?","closebuttontitle":"Close","unknownerror":"Unknown error","file":"File","url":"URL"},"repository":{"type":"Type","size":"Size","invalidjson":"Invalid JSON string","nofilesattached":"No files attached","filepicker":"File picker","logout":"Logout","nofilesavailable":"No files available","norepositoriesavailable":"Sorry, none of your current repositories can return files in the required format.","fileexistsdialogheader":"File exists","fileexistsdialog_editor":"A file with that name has already been attached to the text you are editing.","fileexistsdialog_filemanager":"A file with that name has already been attached","renameto":"Rename to \"{$a}\"","referencesexist":"There are {$a} alias\/shortcut files that use this file as their source","select":"Select","confirmdeletefile":"Are you sure you want to delete this file?","draftareanofiles":"Cannot be downloaded because there is no files attached","entername":"Please enter folder name","enternewname":"Please enter the new file name","popupblockeddownload":"The downloading window is blocked, please allow the popup window, and try again.","unknownoriginal":"Unknown","confirmdeletefolder":"Are you sure you want to delete this folder? All files and subfolders will be deleted.","confirmdeletefilewithhref":"Are you sure you want to delete this file? There are {$a} alias\/shortcut files that use this file as their source. If you proceed then those aliases will be converted to true copies.","confirmrenamefolder":" Are you sure you want to move\/rename this folder? Any alias\/shortcut files that reference files in this folder will be converted into true copies.","confirmrenamefile":"Are you sure you want to rename\/move this file? There are {$a} alias\/shortcut files that use this file as their source. If you proceed then those aliases will be converted to true copies.","newfolder":"New folder"},"admin":{"confirmdeletecomments":"You are about to delete comments, are you sure?","confirmation":"Confirmation"},"atto_collapse":{"showmore":"Show more buttons","showfewer":"Show fewer buttons","pluginname":"Show\/hide advanced buttons"},"atto_title":{"h3":"Heading (large)","h4":"Heading (medium)","h5":"Heading (small)","pre":"Pre-formatted","p":"Paragraph","pluginname":"Paragraph styles"},"atto_bold":{"pluginname":"Bold"},"atto_italic":{"pluginname":"Italic"},"atto_unorderedlist":{"pluginname":"Unordered list"},"atto_orderedlist":{"pluginname":"Ordered list"},"atto_link":{"createlink":"Create link","unlink":"Unlink","enterurl":"Enter a URL","browserepositories":"Browse repositories...","openinnewwindow":"Open in new window","pluginname":"Link"},"atto_image":{"alignment":"Alignment","alignment_bottom":"Bottom","alignment_left":"Left","alignment_middle":"Middle","alignment_right":"Right","alignment_top":"Top","browserepositories":"Browse repositories...","constrain":"Auto size","saveimage":"Save image","imageproperties":"Image properties","customstyle":"Custom style","enterurl":"Enter URL","enteralt":"Describe this image for someone who cannot see it","height":"Height","presentation":"Description not necessary","presentationoraltrequired":"Images must have a description, except if the description is marked as not necessary.","size":"Size","width":"Width","uploading":"Uploading, please wait...","pluginname":"Insert or edit image"},"atto_media":{"add":"Add","addcaptionstrack":"Add caption track","addchapterstrack":"Add chapter track","adddescriptionstrack":"Add description track","addmetadatatrack":"Add metadata track","addsource":"Add alternative source","addsubtitlestrack":"Add subtitle track","addtrack":"Add track","advancedsettings":"Advanced settings","audio":"Audio","audiosourcelabel":"Audio source URL","autoplay":"Play automatically","browserepositories":"Browse repositories...","captions":"Captions","captionssourcelabel":"Caption track URL","chapters":"Chapters","chapterssourcelabel":"Chapter track URL","controls":"Show controls","createmedia":"Insert media","default":"Default","descriptions":"Descriptions","descriptionssourcelabel":"Description track URL","displayoptions":"Display options","entername":"Enter name","entertitle":"Enter title","entersource":"Source URL","enterurl":"Enter URL","height":"Height","kind":"Type","label":"Label","languagesavailable":"Languages available","languagesinstalled":"Languages installed","link":"Link","loop":"Loop","metadata":"Metadata","metadatasourcelabel":"Metadata track URL","mute":"Muted","poster":"Thumbnail URL","remove":"Remove","size":"Size","srclang":"Language","subtitles":"Subtitles","subtitlessourcelabel":"Subtitle track URL","track":"Track URL","tracks":"Subtitles and captions","video":"Video","videoheight":"Video height","videosourcelabel":"Video source URL","videowidth":"Video width","width":"Width","pluginname":"Insert or edit an audio\/video file"},"atto_recordrtc":{"audiortc":"Record audio","videortc":"Record video","nowebrtc_title":"WebRTC not supported","nowebrtc":"Your browser offers limited or no support for WebRTC technologies yet, and cannot be used with this plugin. Please switch or upgrade your browser","gumabort_title":"Something happened","gumabort":"Something strange happened which prevented the webcam\/microphone from being used","gumnotallowed_title":"Wrong permissions","gumnotallowed":"The user must allow the browser access to the webcam\/microphone","gumnotfound_title":"Device missing","gumnotfound":"There is no input device connected or enabled","gumnotreadable_title":"Hardware error","gumnotreadable":"Something is preventing the browser from accessing the webcam\/microphone","gumnotsupported":"Your browser does not support recording over an insecure connection and must close the plugin","gumnotsupported_title":"No support for insecure connection","gumoverconstrained_title":"Problem with constraints","gumoverconstrained":"The current webcam\/microphone can not produce a stream with the required constraints","gumsecurity_title":"No support for insecure connection","gumsecurity":"Your browser does not support recording over an insecure connection and must close the plugin","gumtype_title":"No constraints specified","gumtype":"Tried to get stream from the webcam\/microphone, but no constraints were specified","insecurealert_title":"Insecure connection!","insecurealert":"Your browser might not allow this plugin to work unless it is used either over HTTPS or from localhost","startrecording":"Start recording","recordagain":"Record again","stoprecording":"Stop recording","recordingfailed":"Recording failed, try again","attachrecording":"Attach recording","norecordingfound_title":"No recording found","norecordingfound":"Something appears to have gone wrong, it seems nothing has been recorded","nearingmaxsize_title":"Recording stopped","nearingmaxsize":"You have attained the maximum size limit for file uploads","uploadprogress":"completed","uploadfailed":"Upload failed:","uploadfailed404":"Upload failed: file too large","uploadaborted":"Upload aborted:","pluginname":"RecordRTC"},"atto_managefiles":{"managefiles":"Manage files","pluginname":"Manage files"},"atto_h5p":{"browserepositories":"Browse repositories...","copyrightbutton":"Copyright button","downloadbutton":"Allow download","instructions":"You can insert H5P content by <strong>either<\/strong> entering a URL <strong>or<\/strong> by uploading an H5P file.","embedbutton":"Embed button","h5pfile":"H5P file upload","h5poptions":"H5P options","h5purl":"H5P URL","h5pfileorurl":"H5P URL or file upload","invalidh5purl":"Invalid URL","noh5pcontent":"No H5P content added","pluginname":"Insert H5P"},"atto_underline":{"pluginname":"Underline"},"atto_strike":{"pluginname":"Strike through"},"atto_subscript":{"pluginname":"Subscript"},"atto_superscript":{"pluginname":"Superscript"},"atto_align":{"center":"Center","leftalign":"Left align","rightalign":"Right align","pluginname":"Text align"},"atto_indent":{"indent":"Indent","outdent":"Outdent","pluginname":"Indent"},"atto_equation":{"saveequation":"Save equation","editequation":"Edit equation using <a href=\"{$a}\" target=\"_blank\">TeX<\/a>","preview":"Equation preview","cursorinfo":"An arrow indicates the position that new elements from the element library will be inserted.","update":"Update","librarygroup1":"Operators","librarygroup2":"Arrows","librarygroup3":"Greek symbols","librarygroup4":"Advanced","pluginname":"Equation editor"},"atto_charmap":{"amacron":"a - macron","emacron":"e - macron","imacron":"i - macron","omacron":"o - macron","umacron":"u - macron","amacron_caps":"A - macron","emacron_caps":"E - macron","imacron_caps":"I - macron","omacron_caps":"O - macron","umacron_caps":"U - macron","interrobang":"interrobang","insertcharacter":"Insert character","nobreakspace":"no-break space","ampersand":"ampersand","quotationmark":"quotation mark","centsign":"cent sign","eurosign":"euro sign","poundsign":"pound sign","yensign":"yen sign","copyrightsign":"copyright sign","registeredsign":"registered sign","trademarksign":"trade mark sign","permillesign":"per mille sign","microsign":"micro sign","middledot":"middle dot","bullet":"bullet","threedotleader":"three dot leader","minutesfeet":"minutes \/ feet","secondsinches":"seconds \/ inches","sectionsign":"section sign","paragraphsign":"paragraph sign","sharpsesszed":"sharp s \/ ess-zed","singleleftpointinganglequotationmark":"single left-pointing angle quotation mark","singlerightpointinganglequotationmark":"single right-pointing angle quotation mark","leftpointingguillemet":"left pointing guillemet","rightpointingguillemet":"right pointing guillemet","leftsinglequotationmark":"left single quotation mark","rightsinglequotationmark":"right single quotation mark","leftdoublequotationmark":"left double quotation mark","rightdoublequotationmark":"right double quotation mark","singlelow9quotationmark":"single low-9 quotation mark","doublelow9quotationmark":"double low-9 quotation mark","lessthansign":"less-than sign","greaterthansign":"greater-than sign","lessthanorequalto":"less-than or equal to","greaterthanorequalto":"greater-than or equal to","endash":"en dash","emdash":"em dash","macron":"macron","overline":"overline","currencysign":"currency sign","brokenbar":"broken bar","diaeresis":"diaeresis","invertedexclamationmark":"inverted exclamation mark","turnedquestionmark":"turned question mark","circumflexaccent":"circumflex accent","smalltilde":"small tilde","degreesign":"degree sign","minussign":"minus sign","plusminussign":"plus-minus sign","divisionsign":"division sign","fractionslash":"fraction slash","multiplicationsign":"multiplication sign","superscriptone":"superscript one","superscripttwo":"superscript two","superscriptthree":"superscript three","fractiononequarter":"fraction one quarter","fractiononehalf":"fraction one half","fractionthreequarters":"fraction three quarters","functionflorin":"function \/ florin","integral":"integral","narysumation":"n-ary sumation","infinity":"infinity","squareroot":"square root","almostequalto":"almost equal to","notequalto":"not equal to","identicalto":"identical to","naryproduct":"n-ary product","notsign":"not sign","intersection":"intersection","partialdifferential":"partial differential","acuteaccent":"acute accent","cedilla":"cedilla","feminineordinalindicator":"feminine ordinal indicator","masculineordinalindicator":"masculine ordinal indicator","dagger":"dagger","doubledagger":"double dagger","agrave_caps":"A - grave","aacute_caps":"A - acute","acircumflex_caps":"A - circumflex","atilde_caps":"A - tilde","adiaeresis_caps":"A - diaeresis","aringabove_caps":"A - ring above","ligatureae_caps":"ligature AE","ccedilla_caps":"C - cedilla","egrave_caps":"E - grave","eacute_caps":"E - acute","ecircumflex_caps":"E - circumflex","ediaeresis_caps":"E - diaeresis","igrave_caps":"I - grave","iacute_caps":"I - acute","icircumflex_caps":"I - circumflex","idiaeresis_caps":"I - diaeresis","eth_caps":"ETH","ntilde_caps":"N - tilde","ograve_caps":"O - grave","oacute_caps":"O - acute","ocircumflex_caps":"O - circumflex","otilde_caps":"O - tilde","odiaeresis_caps":"O - diaeresis","oslash_caps":"O - slash","ligatureoe_caps":"ligature OE","scaron_caps":"S - caron","ugrave_caps":"U - grave","uacute_caps":"U - acute","ucircumflex_caps":"U - circumflex","udiaeresis_caps":"U - diaeresis","yacute_caps":"Y - acute","ydiaeresis_caps":"Y - diaeresis","thorn_caps":"THORN","agrave":"a - grave","aacute":"a - acute","acircumflex":"a - circumflex","atilde":"a - tilde","adiaeresis":"a - diaeresis","aringabove":"a - ring above","ligatureae":"ligature ae","ccedilla":"c - cedilla","egrave":"e - grave","eacute":"e - acute","ecircumflex":"e - circumflex","ediaeresis":"e - diaeresis","igrave":"i - grave","iacute":"i - acute","icircumflex":"i - circumflex","idiaeresis":"i - diaeresis","eth":"eth","ntilde":"n - tilde","ograve":"o - grave","oacute":"o - acute","ocircumflex":"o - circumflex","otilde":"o - tilde","odiaeresis":"o - diaeresis","oslash":"o slash","ligatureoe":"ligature oe","scaron":"s - caron","ugrave":"u - grave","uacute":"u - acute","ucircumflex":"u - circumflex","udiaeresis":"u - diaeresis","yacute":"y - acute","thorn":"thorn","ydiaeresis":"y - diaeresis","alpha_caps":"Alpha","beta_caps":"Beta","gamma_caps":"Gamma","delta_caps":"Delta","epsilon_caps":"Epsilon","zeta_caps":"Zeta","eta_caps":"Eta","theta_caps":"Theta","iota_caps":"Iota","kappa_caps":"Kappa","lambda_caps":"Lambda","mu_caps":"Mu","nu_caps":"Nu","xi_caps":"Xi","omicron_caps":"Omicron","pi_caps":"Pi","rho_caps":"Rho","sigma_caps":"Sigma","tau_caps":"Tau","upsilon_caps":"Upsilon","phi_caps":"Phi","chi_caps":"Chi","psi_caps":"Psi","omega_caps":"Omega","alpha":"alpha","beta":"beta","gamma":"gamma","delta":"delta","epsilon":"epsilon","zeta":"zeta","eta":"eta","theta":"theta","iota":"iota","kappa":"kappa","lambda":"lambda","mu":"mu","nu":"nu","xi":"xi","omicron":"omicron","pi":"pi","rho":"rho","finalsigma":"final sigma","sigma":"sigma","tau":"tau","upsilon":"upsilon","phi":"phi","chi":"chi","psi":"psi","omega":"omega","leftwardsarrow":"leftwards arrow","upwardsarrow":"upwards arrow","rightwardsarrow":"rightwards arrow","downwardsarrow":"downwards arrow","leftrightarrow":"left right arrow","lozenge":"lozenge","blackspadesuit":"black spade suit","blackclubsuit":"black club suit","blackheartsuit":"black heart suit","blackdiamondsuit":"black diamond suit","pluginname":"Insert character"},"atto_table":{"createtable":"Create table","updatetable":"Update table","appearance":"Appearance","headers":"Define headers on","caption":"Caption","columns":"Columns","rows":"Rows","numberofcolumns":"Number of columns","numberofrows":"Number of rows","both":"Both","edittable":"Edit table","addcolumnafter":"Insert column after","addrowafter":"Insert row after","movecolumnright":"Move column right","movecolumnleft":"Move column left","moverowdown":"Move row down","moverowup":"Move row up","deleterow":"Delete row","deletecolumn":"Delete column","captionposition":"Caption position","borders":"Borders","bordersize":"Size of borders","bordercolour":"Border colour","borderstyles":"Style of borders","none":"None","all":"Around each cell","backgroundcolour":"Background colour","width":"Table width (in %)","outer":"Around table","noborder":"No border","themedefault":"Theme default","dotted":"Dotted","dashed":"Dashed","solid":"Solid","pluginname":"Table"},"editor":{"top":"Top","bottom":"Bottom"},"atto_clear":{"pluginname":"Clear formatting"},"atto_undo":{"redo":"Redo","undo":"Undo","pluginname":"Undo\/Redo"},"atto_accessibilitychecker":{"nowarnings":"Congratulations, no accessibility problems found!","report":"Accessibility report:","imagesmissingalt":"Images require alternative text. To fix this warning, add an alt attribute to your img tags. An empty alt attribute may be used, but only when the image is purely decorative and carries no information.","needsmorecontrast":"The colours of the foreground and background text do not have enough contrast. To fix this warning, change either foreground or background colour of the text so that it is easier to read.","needsmoreheadings":"There is a lot of text with no headings. Headings will allow screen reader users to navigate through the page easily and will make the page more usable for everyone.","tableswithmergedcells":"Tables should not contain merged cells. Despite being standard markup for tables for many years, some screen readers still do not fully support complex tables. When possible, try to \"flatten\" the table and avoid merged cells.","tablesmissingcaption":"Tables should have captions. While it is not necessary for each table to have a caption, a caption is generally very helpful.","emptytext":"Empty text","entiredocument":"Entire document","tablesmissingheaders":"Tables should use row and\/or column headers.","pluginname":"Accessibility checker"},"atto_accessibilityhelper":{"liststyles":"Styles for current selection:","nostyles":"No styles","listlinks":"Links in text editor:","nolinks":"No links","selectlink":"Select link","listimages":"Images in text editor:","noimages":"No images","selectimage":"Select image","pluginname":"Screenreader helper"},"atto_html":{"pluginname":"HTML"},"editor_atto":{"editor_command_keycode":"Cmd + {$a}","editor_control_keycode":"Ctrl + {$a}","plugin_title_shortcut":"{$a->title} [{$a->shortcut}]","textrecovered":"A draft version of this text was automatically restored.","autosavefailed":"Could not connect to the server. If you submit this page now, your changes may be lost.","autosavesucceeded":"Draft saved.","errortextrecovery":"Unfortunately the draft version could not be restored."},"error":{"maxbytesfile":"The file {$a->file} is too large. The maximum size you can upload is {$a->size}.","serverconnection":"Error connecting to the server"},"debug":{"debuginfo":"Debug info","line":"Line","stacktrace":"Stack trace"},"langconfig":{"labelsep":": "}};
//]]>
</script>
<script>
//<![CDATA[
(function() {Y.use("moodle-filter_mathjaxloader-loader",function() {M.filter_mathjaxloader.configure({"mathjaxconfig":"\r\nMathJax.Hub.Config({\r\n    config: [\"Accessible.js\", \"Safe.js\"],\r\n    errorSettings: { message: [\"!\"] },\r\n    skipStartupTypeset: true,\r\n    messageStyle: \"none\"\r\n});\r\n","lang":"en"});
});
Y.use("moodle-course-formatchooser",function() {M.course.init_formatchooser({"formid":"mform1_2UgX3cbcrCd9RgL"});
});
M.util.help_popups.setup(Y);
Y.use("moodle-core-formchangechecker",function() {M.core_formchangechecker.init({"formid":"mform1_2UgX3cbcrCd9RgL","initialdirtystate":false});
});
Y.use("moodle-form-shortforms",function() {M.form.shortforms({"formid":"mform1_2UgX3cbcrCd9RgL"});
});
Y.use("moodle-form-dateselector",function() {M.form.dateselector.init_date_selectors({"firstdayofweek":1,"mon":"Mon","tue":"Tue","wed":"Wed","thu":"Thu","fri":"Fri","sat":"Sat","sun":"Sun","january":"January","february":"February","march":"March","april":"April","may":"May","june":"June","july":"July","august":"August","september":"September","october":"October","november":"November","december":"December"});
});
 M.util.js_pending('random65781ca719c2e14'); Y.on('domready', function() {  M.util.js_pending('random65781ca719c2e14'); Y.use('core_filepicker', function(Y) { M.core_filepicker.set_templates(Y, {"generallayout":"<div class=\"container\">\r\n    <div tabindex=\"0\" class=\"file-picker fp-generallayout row\" role=\"dialog\" aria-live=\"assertive\">\r\n        <div class=\"fp-repo-area col-md-3 pr-2 nav nav-pills flex-column\" role=\"tablist\">\r\n                <div class=\"fp-repo nav-item\" role=\"tab\" aria-selected=\"false\" tabindex=\"-1\">\r\n                    <a href=\"#\" class=\"nav-link\" tabindex=\"-1\"><img class=\"fp-repo-icon\" alt=\" \" width=\"16\" height=\"16\" \/>&nbsp;<span class=\"fp-repo-name\"><\/span><\/a>\r\n                <\/div>\r\n\r\n        <\/div>\r\n        <div class=\"col-md-9 p-0\">\r\n            <div class=\"fp-repo-items\" tabindex=\"0\">\r\n                <div class=\"fp-navbar bg-faded card mb-0 clearfix icon-no-spacing\">\r\n                    <div>\r\n                        <div class=\"fp-toolbar\">\r\n                            <div class=\"fp-tb-back\">\r\n                                <a href=\"#\" class=\"btn btn-secondary btn-sm\">Back<\/a>\r\n                            <\/div>\r\n                            <div class=\"fp-tb-search\">\r\n                                <form><\/form>\r\n                            <\/div>\r\n                            <div class=\"fp-tb-refresh\">\r\n                                <a title=\"Refresh\" class=\"btn btn-secondary btn-sm\" href=\"#\">\r\n                                    <i class=\"icon fa fa-refresh fa-fw \" aria-hidden=\"true\"  ><\/i>\r\n                                <\/a>\r\n                            <\/div>\r\n                            <div class=\"fp-tb-logout\">\r\n                                <a title=\"Logout\" class=\"btn btn-secondary btn-sm\" href=\"#\">\r\n                                    <i class=\"icon fa fa-sign-out fa-fw \" aria-hidden=\"true\"  ><\/i>\r\n                                <\/a>\r\n                            <\/div>\r\n                            <div class=\"fp-tb-manage\">\r\n                                <a title=\"Manage\" class=\"btn btn-secondary btn-sm\" href=\"#\">\r\n                                    <i class=\"icon fa fa-cog fa-fw \" aria-hidden=\"true\"  ><\/i>\r\n                                <\/a>\r\n                            <\/div>\r\n                            <div class=\"fp-tb-help\">\r\n                                <a title=\"Help\" class=\"btn btn-secondary btn-sm\" href=\"#\">\r\n                                    <i class=\"icon fa fa-question-circle text-info fa-fw \" aria-hidden=\"true\"  ><\/i>\r\n                                <\/a>\r\n                            <\/div>\r\n                            <div class=\"fp-tb-message\"><\/div>\r\n                        <\/div>\r\n                        <div class=\"fp-viewbar btn-group float-sm-right\">\r\n                            <a role=\"button\" title=\"Display folder with file icons\" class=\"fp-vb-icons btn btn-secondary btn-sm\" href=\"#\">\r\n                                <i class=\"icon fa fa-th fa-fw \" aria-hidden=\"true\"  ><\/i>\r\n                            <\/a>\r\n                            <a role=\"button\" title=\"Display folder with file details\" class=\"fp-vb-details btn btn-secondary btn-sm\" href=\"#\">\r\n                                <i class=\"icon fa fa-list fa-fw \" aria-hidden=\"true\"  ><\/i>\r\n                            <\/a>\r\n                            <a role=\"button\" title=\"Display folder as file tree\" class=\"fp-vb-tree btn btn-secondary btn-sm\" href=\"#\">\r\n                                <i class=\"icon fa fa-folder fa-fw \" aria-hidden=\"true\"  ><\/i>\r\n                            <\/a>\r\n                        <\/div>\r\n                        <div class=\"fp-clear-left\"><\/div>\r\n                    <\/div>\r\n                    <div class=\"fp-pathbar\">\r\n                        <span class=\"fp-path-folder\"><a class=\"fp-path-folder-name\" href=\"#\"><\/a><\/span>\r\n                    <\/div>\r\n                <\/div>\r\n                <div class=\"fp-content card\"><\/div>\r\n            <\/div>\r\n        <\/div>\r\n    <\/div>\r\n<\/div>","iconfilename":"\r\n<a class=\"fp-file\" href=\"#\" >\r\n    <div style=\"position:relative;\">\r\n        <div class=\"fp-thumbnail\"><\/div>\r\n        <div class=\"fp-reficons1\"><\/div>\r\n        <div class=\"fp-reficons2\"><\/div>\r\n    <\/div>\r\n    <div class=\"fp-filename-field\">\r\n        <p class=\"fp-filename text-truncate\"><\/p>\r\n    <\/div>\r\n<\/a>","listfilename":"\r\n<span class=\"fp-filename-icon\">\r\n    <a href=\"#\">\r\n        <span class=\"fp-icon\"><\/span>\r\n        <span class=\"fp-filename\"><\/span>\r\n    <\/a>\r\n<\/span>","nextpage":"\r\n<div class=\"fp-nextpage\">\r\n    <div class=\"fp-nextpage-link\"><a href=\"#\">more<\/a><\/div>\r\n    <div class=\"fp-nextpage-loading\">\r\n        <i class=\"icon fa fa-circle-o-notch fa-spin fa-fw \" aria-hidden=\"true\"  ><\/i>\r\n    <\/div>\r\n<\/div>","selectlayout":"<div class=\"file-picker fp-select\">\r\n    <div class=\"fp-select-loading\">\r\n        <span class=\"sr-only\">Loading...<\/span>\r\n        <i class=\"icon fa fa-circle-o-notch fa-spin fa-fw \" aria-hidden=\"true\"  ><\/i>\r\n    <\/div>\r\n    <div class=\"container\">\r\n        <form>\r\n            <fieldset class=\"form-group row flex-column\">\r\n                <div class=\"form-check fp-linktype-2\">\r\n                    <label class=\"form-check-label\">\r\n                        <input class=\"form-check-input\" type=\"radio\">\r\n                        Make a copy of the file\r\n                    <\/label>\r\n                <\/div>\r\n                <div class=\"form-check fp-linktype-1\">\r\n                    <label class=\"form-check-label\">\r\n                        <input class=\"form-check-input\" type=\"radio\">\r\n                        Link to the file directly\r\n                    <\/label>\r\n                <\/div>\r\n                <div class=\"form-check fp-linktype-4\">\r\n                    <label class=\"form-check-label\">\r\n                        <input class=\"form-check-input\" type=\"radio\">\r\n                        Create an alias\/shortcut to the file\r\n                    <\/label>\r\n                <\/div>\r\n                <div class=\"form-check fp-linktype-8\">\r\n                    <label class=\"form-check-label\">\r\n                        <input class=\"form-check-input\" type=\"radio\">\r\n                        Create an access controlled link to the file\r\n                    <\/label>\r\n                <\/div>\r\n            <\/fieldset>\r\n            <div class=\"fp-saveas form-group row\">\r\n                <label class=\"col-form-label\">Save as<\/label>\r\n                <input class=\"form-control\" type=\"text\">\r\n            <\/div>\r\n            <div class=\"fp-setauthor form-group row\">\r\n                <label class=\"col-form-label\">Author<\/label>\r\n                <input class=\"form-control\" type=\"text\">\r\n            <\/div>\r\n            <div class=\"fp-setlicense form-group row\">\r\n                <label class=\"col-form-label\">Choose license<\/label>\r\n                <select class=\"custom-select\"><\/select>\r\n            <\/div>\r\n            <div class=\"form-group row\">\r\n                <div class=\"fp-select-buttons\">\r\n                    <button class=\"fp-select-confirm btn-primary btn\">Select this file<\/button>\r\n                    <button class=\"fp-select-cancel btn-secondary btn\">Cancel<\/button>\r\n                <\/div>\r\n            <\/div>\r\n        <\/form>\r\n    <\/div>\r\n    <div class=\"fp-info clearfix\">\r\n        <hr>\r\n        <p class=\"fp-thumbnail\"><\/p>\r\n        <div class=\"fp-fileinfo\">\r\n            <div class=\"fp-datemodified\">Last modified<span class=\"fp-value\"><\/span><\/div>\r\n            <div class=\"fp-datecreated\">Created<span class=\"fp-value\"><\/span><\/div>\r\n            <div class=\"fp-size\">Size<span class=\"fp-value\"><\/span><\/div>\r\n            <div class=\"fp-license\">License<span class=\"fp-value\"><\/span><\/div>\r\n            <div class=\"fp-author\">Author<span class=\"fp-value\"><\/span><\/div>\r\n            <div class=\"fp-dimensions\">Dimensions<span class=\"fp-value\" dir=\"ltr\"><\/span><\/div>\r\n        <\/div>\r\n    <\/div>\r\n<\/div>","uploadform":"<div class=\"fp-upload-form\">\r\n    <div class=\"fp-content-center\">\r\n        <form enctype=\"multipart\/form-data\" method=\"POST\" class=\"form\">\r\n            <div class=\"fp-formset\">\r\n                <div class=\"fp-file form-group\">\r\n                    <label>Attachment<\/label>\r\n                    <div class=\"p-x-1\">\r\n                        <input  type=\"file\"\/>\r\n                    <\/div>\r\n                <\/div>\r\n                <div class=\"fp-saveas form-group\">\r\n                    <label>Save as<\/label>\r\n                    <input type=\"text\" class=\"form-control\"\/>\r\n                <\/div>\r\n                <div class=\"fp-setauthor form-group\">\r\n                    <label>Author<\/label>\r\n                    <input type=\"text\" class=\"form-control\"\/>\r\n                <\/div>\r\n                <div class=\"fp-setlicense control-group\">\r\n                    <label>Choose license<\/label>\r\n                    <select class=\"custom-select\"><\/select>\r\n                <\/div>\r\n            <\/div>\r\n        <\/form>\r\n        <div class=\"mdl-align\">\r\n            <button class=\"fp-upload-btn btn-primary btn\">Upload this file<\/button>\r\n        <\/div>\r\n    <\/div>\r\n<\/div>","loading":"\r\n<div class=\"fp-content-loading\">\r\n    <div class=\"fp-content-center\">\r\n        <i class=\"icon fa fa-circle-o-notch fa-spin fa-fw \" aria-hidden=\"true\"  ><\/i>\r\n    <\/div>\r\n<\/div>","error":"\r\n<div class=\"fp-content-error\" ><div class=\"fp-error\"><\/div><\/div>","message":"\r\n<div class=\"file-picker fp-msg\" role=\"alertdialog\" aria-live=\"assertive\" aria-labelledby=\"fp-msg-labelledby\">\r\n    <p class=\"fp-msg-text\" id=\"fp-msg-labelledby\"><\/p>\r\n    <button class=\"fp-msg-butok btn-primary btn\">OK<\/button>\r\n<\/div>","processexistingfile":"<div class=\"file-picker fp-dlg\">\r\n    <p class=\"fp-dlg-text\"><\/p>\r\n    <div class=\"fp-dlg-buttons\">\r\n        <button class=\"fp-dlg-butoverwrite btn btn-primary mb-1\">Overwrite<\/button>\r\n        <button class=\"fp-dlg-butrename btn btn-primary mb-1\"><\/button>\r\n        <button class=\"fp-dlg-butcancel btn btn-secondary mb-1\">Cancel<\/button>\r\n    <\/div>\r\n<\/div>","processexistingfilemultiple":"<div class=\"file-picker fp-dlg\">\r\n    <p class=\"fp-dlg-text\"><\/p>\r\n    <a class=\"fp-dlg-butoverwrite btn btn-primary\" href=\"#\">Overwrite<\/a>\r\n    <a class=\"fp-dlg-butrename btn btn-primary\" href=\"#\"><\/a>\r\n    <a class=\"fp-dlg-butcancel btn btn-secondary\" href=\"#\">Cancel<\/a>\r\n    <br\/>\r\n    <a class=\"fp-dlg-butoverwriteall btn btn-primary\" href=\"#\">Overwrite all<\/a>\r\n    <a class=\"fp-dlg-butrenameall btn btn-primary\" href=\"#\">Rename all<\/a>\r\n<\/div>","loginform":"<div class=\"fp-login-form\">\r\n    <div class=\"fp-content-center\">\r\n        <form class=\"form\">\r\n            <div class=\"fp-formset\">\r\n                <div class=\"fp-login-popup form-group\">\r\n                    <div class=\"fp-popup\">\r\n                        <p class=\"mdl-align\">\r\n                            <button class=\"fp-login-popup-but btn-primary btn\">Log in to your account<\/button>\r\n                        <\/p>\r\n                    <\/div>\r\n                <\/div>\r\n                <div class=\"fp-login-textarea form-group\">\r\n                    <textarea class=\"form-control\"><\/textarea>\r\n                <\/div>\r\n                <div class=\"fp-login-select form-group\">\r\n                    <label class=\"form-control-label\"><\/label>\r\n                    <select class=\"custom-select\"><\/select>\r\n                <\/div>\r\n                <div class=\"fp-login-input form-group\">\r\n                    <label class=\"form-control-label\"><\/label>\r\n                    <input class=\"form-control\"\/>\r\n                <\/div>\r\n                <div class=\"fp-login-radiogroup form-group\">\r\n                    <label class=\"form-control-label\"><\/label>\r\n                    <div class=\"fp-login-radio\"><input class=\"form-control\" \/> <label><\/label><\/div>\r\n                <\/div>\r\n                <div class=\"fp-login-checkbox form-group form-inline\">\r\n                    <label class=\"form-control-label\"><\/label>\r\n                    <input class=\"form-control\"\/>\r\n                <\/div>\r\n            <\/div>\r\n            <p class=\"mdl-align\"><button class=\"fp-login-submit btn-primary btn\">Submit<\/button><\/p>\r\n        <\/form>\r\n    <\/div>\r\n<\/div>"});  M.util.js_complete('random65781ca719c2e14'); });  M.util.js_complete('random65781ca719c2e14'); });
Y.use("moodle-filter_mathjaxloader-loader",function() {M.filter_mathjaxloader.typeset();
});
Y.use("moodle-editor_atto-editor","moodle-atto_collapse-button","moodle-atto_title-button","moodle-atto_bold-button","moodle-atto_italic-button","moodle-atto_unorderedlist-button","moodle-atto_orderedlist-button","moodle-atto_link-button","moodle-atto_image-button","moodle-atto_media-button","moodle-atto_recordrtc-button","moodle-atto_managefiles-button","moodle-atto_h5p-button","moodle-atto_underline-button","moodle-atto_strike-button","moodle-atto_subscript-button","moodle-atto_superscript-button","moodle-atto_align-button","moodle-atto_indent-button","moodle-atto_equation-button","moodle-atto_charmap-button","moodle-atto_table-button","moodle-atto_clear-button","moodle-atto_undo-button","moodle-atto_accessibilitychecker-button","moodle-atto_accessibilityhelper-button","moodle-atto_html-button",function() {Y.M.editor_atto.Editor.init({"elementid":"id_summary_editor","content_css":"https:\/\/moodle-stage.laerdalblr.in\/theme\/styles.php\/boost\/1617770024_1\/editor","contextid":958,"autosaveEnabled":true,"autosaveFrequency":"60","language":"en","directionality":"ltr","filepickeroptions":{"h5p":{"defaultlicense":"allrightsreserved","licenses":[{"shortname":"unknown","fullname":"Other"},{"shortname":"allrightsreserved","fullname":"All rights reserved"},{"shortname":"public","fullname":"Public domain"},{"shortname":"cc","fullname":"Creative Commons"},{"shortname":"cc-nd","fullname":"Creative Commons - NoDerivs"},{"shortname":"cc-nc-nd","fullname":"Creative Commons - No Commercial NoDerivs"},{"shortname":"cc-nc","fullname":"Creative Commons - No Commercial"},{"shortname":"cc-nc-sa","fullname":"Creative Commons - No Commercial ShareAlike"},{"shortname":"cc-sa","fullname":"Creative Commons - ShareAlike"}],"author":"Test Auto","repositories":{"1":{"id":"1","name":"Embedded files","type":"areafiles","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_areafiles\/1617770024\/icon","supported_types":[],"return_types":1,"defaultreturntype":2,"sortorder":1},"2":{"id":"2","name":"Server files","type":"local","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_local\/1617770024\/icon","supported_types":[],"return_types":6,"defaultreturntype":2,"sortorder":2},"3":{"id":"3","name":"Recent files","type":"recent","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_recent\/1617770024\/icon","supported_types":[],"return_types":2,"defaultreturntype":2,"sortorder":3},"4":{"id":"4","name":"Upload a file","type":"upload","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_upload\/1617770024\/icon","supported_types":[],"return_types":2,"defaultreturntype":2,"sortorder":4},"6":{"id":"6","name":"Private files","type":"user","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_user\/1617770024\/icon","supported_types":[],"return_types":6,"defaultreturntype":2,"sortorder":6},"7":{"id":"7","name":"Wikimedia","type":"wikimedia","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_wikimedia\/1617770024\/icon","supported_types":[],"return_types":3,"defaultreturntype":2,"sortorder":7}},"externallink":true,"userprefs":{"recentrepository":"4","recentlicense":"allrightsreserved","recentviewmode":""},"accepted_types":[".h5p"],"return_types":15,"context":{"id":958,"contextlevel":40,"instanceid":"6","path":"\/1\/958","depth":"2","locked":false},"client_id":"65781ca79b228","maxbytes":"0","areamaxbytes":-1,"env":"editor","itemid":126736362},"image":{"defaultlicense":"allrightsreserved","licenses":[{"shortname":"unknown","fullname":"Other"},{"shortname":"allrightsreserved","fullname":"All rights reserved"},{"shortname":"public","fullname":"Public domain"},{"shortname":"cc","fullname":"Creative Commons"},{"shortname":"cc-nd","fullname":"Creative Commons - NoDerivs"},{"shortname":"cc-nc-nd","fullname":"Creative Commons - No Commercial NoDerivs"},{"shortname":"cc-nc","fullname":"Creative Commons - No Commercial"},{"shortname":"cc-nc-sa","fullname":"Creative Commons - No Commercial ShareAlike"},{"shortname":"cc-sa","fullname":"Creative Commons - ShareAlike"}],"author":"Test Auto","repositories":{"1":{"id":"1","name":"Embedded files","type":"areafiles","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_areafiles\/1617770024\/icon","supported_types":[],"return_types":1,"defaultreturntype":2,"sortorder":1},"2":{"id":"2","name":"Server files","type":"local","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_local\/1617770024\/icon","supported_types":[],"return_types":6,"defaultreturntype":2,"sortorder":2},"3":{"id":"3","name":"Recent files","type":"recent","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_recent\/1617770024\/icon","supported_types":[],"return_types":2,"defaultreturntype":2,"sortorder":3},"4":{"id":"4","name":"Upload a file","type":"upload","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_upload\/1617770024\/icon","supported_types":[],"return_types":2,"defaultreturntype":2,"sortorder":4},"5":{"id":"5","name":"URL downloader","type":"url","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_url\/1617770024\/icon","supported_types":[".gif",".jpe",".jpeg",".jpg",".png",".svg",".svgz"],"return_types":3,"defaultreturntype":2,"sortorder":5},"6":{"id":"6","name":"Private files","type":"user","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_user\/1617770024\/icon","supported_types":[],"return_types":6,"defaultreturntype":2,"sortorder":6},"7":{"id":"7","name":"Wikimedia","type":"wikimedia","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_wikimedia\/1617770024\/icon","supported_types":[],"return_types":3,"defaultreturntype":2,"sortorder":7}},"externallink":true,"userprefs":{"recentrepository":"4","recentlicense":"allrightsreserved","recentviewmode":""},"accepted_types":[".gif",".jpe",".jpeg",".jpg",".png",".svg",".svgz"],"return_types":15,"context":{"id":958,"contextlevel":40,"instanceid":"6","path":"\/1\/958","depth":"2","locked":false},"client_id":"65781ca7991f1","maxbytes":"0","areamaxbytes":-1,"env":"editor","itemid":126736362},"media":{"defaultlicense":"allrightsreserved","licenses":[{"shortname":"unknown","fullname":"Other"},{"shortname":"allrightsreserved","fullname":"All rights reserved"},{"shortname":"public","fullname":"Public domain"},{"shortname":"cc","fullname":"Creative Commons"},{"shortname":"cc-nd","fullname":"Creative Commons - NoDerivs"},{"shortname":"cc-nc-nd","fullname":"Creative Commons - No Commercial NoDerivs"},{"shortname":"cc-nc","fullname":"Creative Commons - No Commercial"},{"shortname":"cc-nc-sa","fullname":"Creative Commons - No Commercial ShareAlike"},{"shortname":"cc-sa","fullname":"Creative Commons - ShareAlike"}],"author":"Test Auto","repositories":{"1":{"id":"1","name":"Embedded files","type":"areafiles","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_areafiles\/1617770024\/icon","supported_types":[],"return_types":1,"defaultreturntype":2,"sortorder":1},"2":{"id":"2","name":"Server files","type":"local","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_local\/1617770024\/icon","supported_types":[],"return_types":6,"defaultreturntype":2,"sortorder":2},"3":{"id":"3","name":"Recent files","type":"recent","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_recent\/1617770024\/icon","supported_types":[],"return_types":2,"defaultreturntype":2,"sortorder":3},"4":{"id":"4","name":"Upload a file","type":"upload","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_upload\/1617770024\/icon","supported_types":[],"return_types":2,"defaultreturntype":2,"sortorder":4},"6":{"id":"6","name":"Private files","type":"user","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_user\/1617770024\/icon","supported_types":[],"return_types":6,"defaultreturntype":2,"sortorder":6},"7":{"id":"7","name":"Wikimedia","type":"wikimedia","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_wikimedia\/1617770024\/icon","supported_types":[],"return_types":3,"defaultreturntype":2,"sortorder":7}},"externallink":true,"userprefs":{"recentrepository":"4","recentlicense":"allrightsreserved","recentviewmode":""},"accepted_types":[".3gp",".avi",".dv",".dif",".flv",".f4v",".mov",".movie",".mp4",".m4v",".mpeg",".mpe",".mpg",".ogv",".qt",".rmvb",".rv",".swf",".swfl",".webm",".wmv",".asf",".aac",".aif",".aiff",".aifc",".au",".flac",".m3u",".mp3",".m4a",".oga",".ogg",".ra",".ram",".rm",".wav",".wma"],"return_types":15,"context":{"id":958,"contextlevel":40,"instanceid":"6","path":"\/1\/958","depth":"2","locked":false},"client_id":"65781ca799b2c","maxbytes":"0","areamaxbytes":-1,"env":"editor","itemid":126736362},"link":{"defaultlicense":"allrightsreserved","licenses":[{"shortname":"unknown","fullname":"Other"},{"shortname":"allrightsreserved","fullname":"All rights reserved"},{"shortname":"public","fullname":"Public domain"},{"shortname":"cc","fullname":"Creative Commons"},{"shortname":"cc-nd","fullname":"Creative Commons - NoDerivs"},{"shortname":"cc-nc-nd","fullname":"Creative Commons - No Commercial NoDerivs"},{"shortname":"cc-nc","fullname":"Creative Commons - No Commercial"},{"shortname":"cc-nc-sa","fullname":"Creative Commons - No Commercial ShareAlike"},{"shortname":"cc-sa","fullname":"Creative Commons - ShareAlike"}],"author":"Test Auto","repositories":{"1":{"id":"1","name":"Embedded files","type":"areafiles","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_areafiles\/1617770024\/icon","supported_types":[],"return_types":1,"defaultreturntype":2,"sortorder":1},"2":{"id":"2","name":"Server files","type":"local","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_local\/1617770024\/icon","supported_types":[],"return_types":6,"defaultreturntype":2,"sortorder":2},"3":{"id":"3","name":"Recent files","type":"recent","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_recent\/1617770024\/icon","supported_types":[],"return_types":2,"defaultreturntype":2,"sortorder":3},"4":{"id":"4","name":"Upload a file","type":"upload","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_upload\/1617770024\/icon","supported_types":[],"return_types":2,"defaultreturntype":2,"sortorder":4},"5":{"id":"5","name":"URL downloader","type":"url","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_url\/1617770024\/icon","supported_types":[".gif",".jpe",".jpeg",".jpg",".png",".svg",".svgz"],"return_types":3,"defaultreturntype":2,"sortorder":5},"6":{"id":"6","name":"Private files","type":"user","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_user\/1617770024\/icon","supported_types":[],"return_types":6,"defaultreturntype":2,"sortorder":6},"7":{"id":"7","name":"Wikimedia","type":"wikimedia","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_wikimedia\/1617770024\/icon","supported_types":[],"return_types":3,"defaultreturntype":2,"sortorder":7}},"externallink":true,"userprefs":{"recentrepository":"4","recentlicense":"allrightsreserved","recentviewmode":""},"accepted_types":[],"return_types":15,"context":{"id":958,"contextlevel":40,"instanceid":"6","path":"\/1\/958","depth":"2","locked":false},"client_id":"65781ca79a23e","maxbytes":"0","areamaxbytes":-1,"env":"editor","itemid":126736362},"subtitle":{"defaultlicense":"allrightsreserved","licenses":[{"shortname":"unknown","fullname":"Other"},{"shortname":"allrightsreserved","fullname":"All rights reserved"},{"shortname":"public","fullname":"Public domain"},{"shortname":"cc","fullname":"Creative Commons"},{"shortname":"cc-nd","fullname":"Creative Commons - NoDerivs"},{"shortname":"cc-nc-nd","fullname":"Creative Commons - No Commercial NoDerivs"},{"shortname":"cc-nc","fullname":"Creative Commons - No Commercial"},{"shortname":"cc-nc-sa","fullname":"Creative Commons - No Commercial ShareAlike"},{"shortname":"cc-sa","fullname":"Creative Commons - ShareAlike"}],"author":"Test Auto","repositories":{"1":{"id":"1","name":"Embedded files","type":"areafiles","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_areafiles\/1617770024\/icon","supported_types":[],"return_types":1,"defaultreturntype":2,"sortorder":1},"2":{"id":"2","name":"Server files","type":"local","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_local\/1617770024\/icon","supported_types":[],"return_types":6,"defaultreturntype":2,"sortorder":2},"3":{"id":"3","name":"Recent files","type":"recent","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_recent\/1617770024\/icon","supported_types":[],"return_types":2,"defaultreturntype":2,"sortorder":3},"4":{"id":"4","name":"Upload a file","type":"upload","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_upload\/1617770024\/icon","supported_types":[],"return_types":2,"defaultreturntype":2,"sortorder":4},"6":{"id":"6","name":"Private files","type":"user","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_user\/1617770024\/icon","supported_types":[],"return_types":6,"defaultreturntype":2,"sortorder":6},"7":{"id":"7","name":"Wikimedia","type":"wikimedia","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_wikimedia\/1617770024\/icon","supported_types":[],"return_types":3,"defaultreturntype":2,"sortorder":7}},"externallink":true,"userprefs":{"recentrepository":"4","recentlicense":"allrightsreserved","recentviewmode":""},"accepted_types":[".vtt"],"return_types":15,"context":{"id":958,"contextlevel":40,"instanceid":"6","path":"\/1\/958","depth":"2","locked":false},"client_id":"65781ca79aae4","maxbytes":"0","areamaxbytes":-1,"env":"editor","itemid":126736362}},"plugins":[{"group":"collapse","plugins":[{"name":"collapse","params":[],"showgroups":"5"}]},{"group":"style1","plugins":[{"name":"title","params":[]},{"name":"bold","params":[]},{"name":"italic","params":[]}]},{"group":"list","plugins":[{"name":"unorderedlist","params":[]},{"name":"orderedlist","params":[]}]},{"group":"links","plugins":[{"name":"link","params":[]}]},{"group":"files","plugins":[{"name":"image","params":[]},{"name":"media","params":[],"langs":{"installed":[{"lang":"English \u200e(en)\u200e","code":"en","default":true}],"available":[{"lang":"Afar \u200e(aa)\u200e","code":"aa"},{"lang":"Abkhazian \u200e(ab)\u200e","code":"ab"},{"lang":"Avestan \u200e(ae)\u200e","code":"ae"},{"lang":"Afrikaans \u200e(af)\u200e","code":"af"},{"lang":"Akan \u200e(ak)\u200e","code":"ak"},{"lang":"Amharic \u200e(am)\u200e","code":"am"},{"lang":"Aragonese \u200e(an)\u200e","code":"an"},{"lang":"Arabic \u200e(ar)\u200e","code":"ar"},{"lang":"Assamese \u200e(as)\u200e","code":"as"},{"lang":"Avaric \u200e(av)\u200e","code":"av"},{"lang":"Aymara \u200e(ay)\u200e","code":"ay"},{"lang":"Azerbaijani \u200e(az)\u200e","code":"az"},{"lang":"Bashkir \u200e(ba)\u200e","code":"ba"},{"lang":"Belarusian \u200e(be)\u200e","code":"be"},{"lang":"Bulgarian \u200e(bg)\u200e","code":"bg"},{"lang":"Bihari languages \u200e(bh)\u200e","code":"bh"},{"lang":"Bislama \u200e(bi)\u200e","code":"bi"},{"lang":"Bambara \u200e(bm)\u200e","code":"bm"},{"lang":"Bengali \u200e(bn)\u200e","code":"bn"},{"lang":"Tibetan \u200e(bo)\u200e","code":"bo"},{"lang":"Breton \u200e(br)\u200e","code":"br"},{"lang":"Bosnian \u200e(bs)\u200e","code":"bs"},{"lang":"Catalan; Valencian \u200e(ca)\u200e","code":"ca"},{"lang":"Chechen \u200e(ce)\u200e","code":"ce"},{"lang":"Chamorro \u200e(ch)\u200e","code":"ch"},{"lang":"Corsican \u200e(co)\u200e","code":"co"},{"lang":"Cree \u200e(cr)\u200e","code":"cr"},{"lang":"Czech \u200e(cs)\u200e","code":"cs"},{"lang":"Church Slavic; Old Slavonic \u200e(cu)\u200e","code":"cu"},{"lang":"Chuvash \u200e(cv)\u200e","code":"cv"},{"lang":"Welsh \u200e(cy)\u200e","code":"cy"},{"lang":"Danish \u200e(da)\u200e","code":"da"},{"lang":"German \u200e(de)\u200e","code":"de"},{"lang":"Divehi; Dhivehi; Maldivian \u200e(dv)\u200e","code":"dv"},{"lang":"Dzongkha \u200e(dz)\u200e","code":"dz"},{"lang":"Ewe \u200e(ee)\u200e","code":"ee"},{"lang":"Greek, Modern (1453-) \u200e(el)\u200e","code":"el"},{"lang":"English \u200e(en)\u200e","code":"en"},{"lang":"Esperanto \u200e(eo)\u200e","code":"eo"},{"lang":"Spanish; Castilian \u200e(es)\u200e","code":"es"},{"lang":"Estonian \u200e(et)\u200e","code":"et"},{"lang":"Basque \u200e(eu)\u200e","code":"eu"},{"lang":"Persian \u200e(fa)\u200e","code":"fa"},{"lang":"Fulah \u200e(ff)\u200e","code":"ff"},{"lang":"Finnish \u200e(fi)\u200e","code":"fi"},{"lang":"Fijian \u200e(fj)\u200e","code":"fj"},{"lang":"Faroese \u200e(fo)\u200e","code":"fo"},{"lang":"French \u200e(fr)\u200e","code":"fr"},{"lang":"Western Frisian \u200e(fy)\u200e","code":"fy"},{"lang":"Irish \u200e(ga)\u200e","code":"ga"},{"lang":"Gaelic; Scottish Gaelic \u200e(gd)\u200e","code":"gd"},{"lang":"Galician \u200e(gl)\u200e","code":"gl"},{"lang":"Guarani \u200e(gn)\u200e","code":"gn"},{"lang":"Gujarati \u200e(gu)\u200e","code":"gu"},{"lang":"Manx \u200e(gv)\u200e","code":"gv"},{"lang":"Hausa \u200e(ha)\u200e","code":"ha"},{"lang":"Hebrew \u200e(he)\u200e","code":"he"},{"lang":"Hindi \u200e(hi)\u200e","code":"hi"},{"lang":"Hiri Motu \u200e(ho)\u200e","code":"ho"},{"lang":"Croatian \u200e(hr)\u200e","code":"hr"},{"lang":"Haitian; Haitian Creole \u200e(ht)\u200e","code":"ht"},{"lang":"Hungarian \u200e(hu)\u200e","code":"hu"},{"lang":"Armenian \u200e(hy)\u200e","code":"hy"},{"lang":"Herero \u200e(hz)\u200e","code":"hz"},{"lang":"Interlingua (IALA) \u200e(ia)\u200e","code":"ia"},{"lang":"Indonesian \u200e(id)\u200e","code":"id"},{"lang":"Interlingue; Occidental \u200e(ie)\u200e","code":"ie"},{"lang":"Igbo \u200e(ig)\u200e","code":"ig"},{"lang":"Sichuan Yi; Nuosu \u200e(ii)\u200e","code":"ii"},{"lang":"Inupiaq \u200e(ik)\u200e","code":"ik"},{"lang":"Ido \u200e(io)\u200e","code":"io"},{"lang":"Icelandic \u200e(is)\u200e","code":"is"},{"lang":"Italian \u200e(it)\u200e","code":"it"},{"lang":"Inuktitut \u200e(iu)\u200e","code":"iu"},{"lang":"Japanese \u200e(ja)\u200e","code":"ja"},{"lang":"Javanese \u200e(jv)\u200e","code":"jv"},{"lang":"Georgian \u200e(ka)\u200e","code":"ka"},{"lang":"Kongo \u200e(kg)\u200e","code":"kg"},{"lang":"Kikuyu; Gikuyu \u200e(ki)\u200e","code":"ki"},{"lang":"Kuanyama; Kwanyama \u200e(kj)\u200e","code":"kj"},{"lang":"Kazakh \u200e(kk)\u200e","code":"kk"},{"lang":"Kalaallisut; Greenlandic \u200e(kl)\u200e","code":"kl"},{"lang":"Central Khmer \u200e(km)\u200e","code":"km"},{"lang":"Kannada \u200e(kn)\u200e","code":"kn"},{"lang":"Korean \u200e(ko)\u200e","code":"ko"},{"lang":"Kanuri \u200e(kr)\u200e","code":"kr"},{"lang":"Kashmiri \u200e(ks)\u200e","code":"ks"},{"lang":"Kurdish \u200e(ku)\u200e","code":"ku"},{"lang":"Komi \u200e(kv)\u200e","code":"kv"},{"lang":"Cornish \u200e(kw)\u200e","code":"kw"},{"lang":"Kirghiz; Kyrgyz \u200e(ky)\u200e","code":"ky"},{"lang":"Latin \u200e(la)\u200e","code":"la"},{"lang":"Luxembourgish \u200e(lb)\u200e","code":"lb"},{"lang":"Ganda \u200e(lg)\u200e","code":"lg"},{"lang":"Limburgan \u200e(li)\u200e","code":"li"},{"lang":"Lingala \u200e(ln)\u200e","code":"ln"},{"lang":"Lao \u200e(lo)\u200e","code":"lo"},{"lang":"Lithuanian \u200e(lt)\u200e","code":"lt"},{"lang":"Luba-Katanga \u200e(lu)\u200e","code":"lu"},{"lang":"Latvian \u200e(lv)\u200e","code":"lv"},{"lang":"Malagasy \u200e(mg)\u200e","code":"mg"},{"lang":"Marshallese \u200e(mh)\u200e","code":"mh"},{"lang":"Maori \u200e(mi)\u200e","code":"mi"},{"lang":"Macedonian \u200e(mk)\u200e","code":"mk"},{"lang":"Malayalam \u200e(ml)\u200e","code":"ml"},{"lang":"Mongolian \u200e(mn)\u200e","code":"mn"},{"lang":"Marathi \u200e(mr)\u200e","code":"mr"},{"lang":"Malay \u200e(ms)\u200e","code":"ms"},{"lang":"Maltese \u200e(mt)\u200e","code":"mt"},{"lang":"Burmese \u200e(my)\u200e","code":"my"},{"lang":"Nauru \u200e(na)\u200e","code":"na"},{"lang":"Norwegian Bokm\u00e5l \u200e(nb)\u200e","code":"nb"},{"lang":"Ndebele, North \u200e(nd)\u200e","code":"nd"},{"lang":"Nepali \u200e(ne)\u200e","code":"ne"},{"lang":"Ndonga \u200e(ng)\u200e","code":"ng"},{"lang":"Dutch; Flemish \u200e(nl)\u200e","code":"nl"},{"lang":"Norwegian Nynorsk \u200e(nn)\u200e","code":"nn"},{"lang":"Norwegian \u200e(no)\u200e","code":"no"},{"lang":"Ndebele, South \u200e(nr)\u200e","code":"nr"},{"lang":"Navajo; Navaho \u200e(nv)\u200e","code":"nv"},{"lang":"Chichewa \u200e(ny)\u200e","code":"ny"},{"lang":"Occitan (post 1500); Proven\u00e7al \u200e(oc)\u200e","code":"oc"},{"lang":"Ojibwa \u200e(oj)\u200e","code":"oj"},{"lang":"Oromo \u200e(om)\u200e","code":"om"},{"lang":"Oriya \u200e(or)\u200e","code":"or"},{"lang":"Ossetian; Ossetic \u200e(os)\u200e","code":"os"},{"lang":"Panjabi; Punjabi \u200e(pa)\u200e","code":"pa"},{"lang":"Pali \u200e(pi)\u200e","code":"pi"},{"lang":"Polish \u200e(pl)\u200e","code":"pl"},{"lang":"Pushto; Pashto \u200e(ps)\u200e","code":"ps"},{"lang":"Portuguese \u200e(pt)\u200e","code":"pt"},{"lang":"Quechua \u200e(qu)\u200e","code":"qu"},{"lang":"Romansh \u200e(rm)\u200e","code":"rm"},{"lang":"Rundi \u200e(rn)\u200e","code":"rn"},{"lang":"Romanian; Moldavian; Moldovan \u200e(ro)\u200e","code":"ro"},{"lang":"Russian \u200e(ru)\u200e","code":"ru"},{"lang":"Kinyarwanda \u200e(rw)\u200e","code":"rw"},{"lang":"Sanskrit \u200e(sa)\u200e","code":"sa"},{"lang":"Sardinian \u200e(sc)\u200e","code":"sc"},{"lang":"Sindhi \u200e(sd)\u200e","code":"sd"},{"lang":"Northern Sami \u200e(se)\u200e","code":"se"},{"lang":"Sango \u200e(sg)\u200e","code":"sg"},{"lang":"Sinhala; Sinhalese \u200e(si)\u200e","code":"si"},{"lang":"Slovak \u200e(sk)\u200e","code":"sk"},{"lang":"Slovenian \u200e(sl)\u200e","code":"sl"},{"lang":"Samoan \u200e(sm)\u200e","code":"sm"},{"lang":"Shona \u200e(sn)\u200e","code":"sn"},{"lang":"Somali \u200e(so)\u200e","code":"so"},{"lang":"Albanian \u200e(sq)\u200e","code":"sq"},{"lang":"Serbian \u200e(sr)\u200e","code":"sr"},{"lang":"Swati \u200e(ss)\u200e","code":"ss"},{"lang":"Sotho, Southern \u200e(st)\u200e","code":"st"},{"lang":"Sundanese \u200e(su)\u200e","code":"su"},{"lang":"Swedish \u200e(sv)\u200e","code":"sv"},{"lang":"Swahili \u200e(sw)\u200e","code":"sw"},{"lang":"Tamil \u200e(ta)\u200e","code":"ta"},{"lang":"Telugu \u200e(te)\u200e","code":"te"},{"lang":"Tajik \u200e(tg)\u200e","code":"tg"},{"lang":"Thai \u200e(th)\u200e","code":"th"},{"lang":"Tigrinya \u200e(ti)\u200e","code":"ti"},{"lang":"Turkmen \u200e(tk)\u200e","code":"tk"},{"lang":"Tagalog \u200e(tl)\u200e","code":"tl"},{"lang":"Tswana \u200e(tn)\u200e","code":"tn"},{"lang":"Tonga (Tonga Islands) \u200e(to)\u200e","code":"to"},{"lang":"Turkish \u200e(tr)\u200e","code":"tr"},{"lang":"Tsonga \u200e(ts)\u200e","code":"ts"},{"lang":"Tatar \u200e(tt)\u200e","code":"tt"},{"lang":"Twi \u200e(tw)\u200e","code":"tw"},{"lang":"Tahitian \u200e(ty)\u200e","code":"ty"},{"lang":"Uighur; Uyghur \u200e(ug)\u200e","code":"ug"},{"lang":"Ukrainian \u200e(uk)\u200e","code":"uk"},{"lang":"Urdu \u200e(ur)\u200e","code":"ur"},{"lang":"Uzbek \u200e(uz)\u200e","code":"uz"},{"lang":"Venda \u200e(ve)\u200e","code":"ve"},{"lang":"Vietnamese \u200e(vi)\u200e","code":"vi"},{"lang":"Volap\u00fck \u200e(vo)\u200e","code":"vo"},{"lang":"Walloon \u200e(wa)\u200e","code":"wa"},{"lang":"Wolof \u200e(wo)\u200e","code":"wo"},{"lang":"Xhosa \u200e(xh)\u200e","code":"xh"},{"lang":"Yiddish \u200e(yi)\u200e","code":"yi"},{"lang":"Yoruba \u200e(yo)\u200e","code":"yo"},{"lang":"Zhuang; Chuang \u200e(za)\u200e","code":"za"},{"lang":"Chinese \u200e(zh)\u200e","code":"zh"},{"lang":"Zulu \u200e(zu)\u200e","code":"zu"}]},"help":{"addsource":"<a class=\"btn btn-link p-0\" role=\"button\"\r\n    data-container=\"body\" data-toggle=\"popover\"\r\n    data-placement=\"right\" data-content=\"&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;It is recommended that an alternative media source is provided, since desktop and mobile browsers vary in which file formats they support.&lt;\/p&gt;\n&lt;\/div&gt; \"\r\n    data-html=\"true\" tabindex=\"0\" data-trigger=\"focus\">\r\n  <i class=\"icon fa fa-question-circle text-info fa-fw \"  title=\"Help with Add alternative source\" aria-label=\"Help with Add alternative source\"><\/i>\r\n<\/a>","tracks":"<a class=\"btn btn-link p-0\" role=\"button\"\r\n    data-container=\"body\" data-toggle=\"popover\"\r\n    data-placement=\"right\" data-content=\"&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;Subtitles, captions, chapters and descriptions can be added via a WebVTT (Web Video Text Tracks) format file. Track labels will be shown in the selection drop-down menu. For each type of track, any track set as default will be pre-selected at the start of the video.&lt;\/p&gt;\n&lt;\/div&gt; \"\r\n    data-html=\"true\" tabindex=\"0\" data-trigger=\"focus\">\r\n  <i class=\"icon fa fa-question-circle text-info fa-fw \"  title=\"Help with Subtitles and captions\" aria-label=\"Help with Subtitles and captions\"><\/i>\r\n<\/a>","subtitles":"<a class=\"btn btn-link p-0\" role=\"button\"\r\n    data-container=\"body\" data-toggle=\"popover\"\r\n    data-placement=\"right\" data-content=\"&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;Subtitles may be used to provide a transcription or translation of the dialogue.&lt;\/p&gt;\n&lt;\/div&gt; \"\r\n    data-html=\"true\" tabindex=\"0\" data-trigger=\"focus\">\r\n  <i class=\"icon fa fa-question-circle text-info fa-fw \"  title=\"Help with Subtitles\" aria-label=\"Help with Subtitles\"><\/i>\r\n<\/a>","captions":"<a class=\"btn btn-link p-0\" role=\"button\"\r\n    data-container=\"body\" data-toggle=\"popover\"\r\n    data-placement=\"right\" data-content=\"&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;Captions may be used to describe everything happening in the track, including non-verbal sounds such as a phone ringing.&lt;\/p&gt;\n&lt;\/div&gt; \"\r\n    data-html=\"true\" tabindex=\"0\" data-trigger=\"focus\">\r\n  <i class=\"icon fa fa-question-circle text-info fa-fw \"  title=\"Help with Captions\" aria-label=\"Help with Captions\"><\/i>\r\n<\/a>","descriptions":"<a class=\"btn btn-link p-0\" role=\"button\"\r\n    data-container=\"body\" data-toggle=\"popover\"\r\n    data-placement=\"right\" data-content=\"&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;Audio descriptions may be used to provide a narration which explains visual details not apparent from the audio alone.&lt;\/p&gt;\n&lt;\/div&gt; \"\r\n    data-html=\"true\" tabindex=\"0\" data-trigger=\"focus\">\r\n  <i class=\"icon fa fa-question-circle text-info fa-fw \"  title=\"Help with Descriptions\" aria-label=\"Help with Descriptions\"><\/i>\r\n<\/a>","chapters":"<a class=\"btn btn-link p-0\" role=\"button\"\r\n    data-container=\"body\" data-toggle=\"popover\"\r\n    data-placement=\"right\" data-content=\"&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;Chapter titles may be provided for use in navigating the media resource.&lt;\/p&gt;\n&lt;\/div&gt; \"\r\n    data-html=\"true\" tabindex=\"0\" data-trigger=\"focus\">\r\n  <i class=\"icon fa fa-question-circle text-info fa-fw \"  title=\"Help with Chapters\" aria-label=\"Help with Chapters\"><\/i>\r\n<\/a>","metadata":"<a class=\"btn btn-link p-0\" role=\"button\"\r\n    data-container=\"body\" data-toggle=\"popover\"\r\n    data-placement=\"right\" data-content=\"&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;Metadata tracks, for use from a script, may be used only if the player supports metadata.&lt;\/p&gt;\n&lt;\/div&gt; \"\r\n    data-html=\"true\" tabindex=\"0\" data-trigger=\"focus\">\r\n  <i class=\"icon fa fa-question-circle text-info fa-fw \"  title=\"Help with Metadata\" aria-label=\"Help with Metadata\"><\/i>\r\n<\/a>"}},{"name":"recordrtc","params":[],"contextid":958,"sesskey":"fZoB308Em3","allowedtypes":"both","audiobitrate":"128000","videobitrate":"2500000","timelimit":"120","audiortcicon":"i\/audiortc","videortcicon":"i\/videortc","maxrecsize":20971520},{"name":"managefiles","params":[],"disabled":false,"area":{"context":958,"areamaxbytes":-1,"maxbytes":"0","subdirs":0,"return_types":15,"removeorphaneddrafts":false},"usercontext":1404},{"name":"h5p","params":[],"allowedmethods":"upload","storeinrepo":true}]},{"group":"style2","plugins":[{"name":"underline","params":[]},{"name":"strike","params":[]},{"name":"subscript","params":[]},{"name":"superscript","params":[]}]},{"group":"align","plugins":[{"name":"align","params":[]}]},{"group":"indent","plugins":[{"name":"indent","params":[]}]},{"group":"insert","plugins":[{"name":"equation","params":[],"texfilteractive":true,"contextid":958,"library":{"group1":{"groupname":"librarygroup1","elements":"\r\n\\cdot\r\n\\times\r\n\\ast\r\n\\div\r\n\\diamond\r\n\\pm\r\n\\mp\r\n\\oplus\r\n\\ominus\r\n\\otimes\r\n\\oslash\r\n\\odot\r\n\\circ\r\n\\bullet\r\n\\asymp\r\n\\equiv\r\n\\subseteq\r\n\\supseteq\r\n\\leq\r\n\\geq\r\n\\preceq\r\n\\succeq\r\n\\sim\r\n\\simeq\r\n\\approx\r\n\\subset\r\n\\supset\r\n\\ll\r\n\\gg\r\n\\prec\r\n\\succ\r\n\\infty\r\n\\in\r\n\\ni\r\n\\forall\r\n\\exists\r\n\\neq\r\n"},"group2":{"groupname":"librarygroup2","elements":"\r\n\\leftarrow\r\n\\rightarrow\r\n\\uparrow\r\n\\downarrow\r\n\\leftrightarrow\r\n\\nearrow\r\n\\searrow\r\n\\swarrow\r\n\\nwarrow\r\n\\Leftarrow\r\n\\Rightarrow\r\n\\Uparrow\r\n\\Downarrow\r\n\\Leftrightarrow\r\n"},"group3":{"groupname":"librarygroup3","elements":"\r\n\\alpha\r\n\\beta\r\n\\gamma\r\n\\delta\r\n\\epsilon\r\n\\zeta\r\n\\eta\r\n\\theta\r\n\\iota\r\n\\kappa\r\n\\lambda\r\n\\mu\r\n\\nu\r\n\\xi\r\n\\pi\r\n\\rho\r\n\\sigma\r\n\\tau\r\n\\upsilon\r\n\\phi\r\n\\chi\r\n\\psi\r\n\\omega\r\n\\Gamma\r\n\\Delta\r\n\\Theta\r\n\\Lambda\r\n\\Xi\r\n\\Pi\r\n\\Sigma\r\n\\Upsilon\r\n\\Phi\r\n\\Psi\r\n\\Omega\r\n"},"group4":{"groupname":"librarygroup4","elements":"\r\n\\sum{a,b}\r\n\\sqrt[a]{b+c}\r\n\\int_{a}^{b}{c}\r\n\\iint_{a}^{b}{c}\r\n\\iiint_{a}^{b}{c}\r\n\\oint{a}\r\n(a)\r\n[a]\r\n\\lbrace{a}\\rbrace\r\n\\left| \\begin{matrix} a_1 & a_2 \\ a_3 & a_4 \\end{matrix} \\right|\r\n\\frac{a}{b+c}\r\n\\vec{a}\r\n\\binom {a} {b}\r\n{a \\brack b}\r\n{a \\brace b}\r\n"}},"texdocsurl":"https:\/\/docs.moodle.org\/38\/en\/Using_TeX_Notation"},{"name":"charmap","params":[]},{"name":"table","params":[],"allowBorders":false,"allowWidth":false,"allowBackgroundColour":false},{"name":"clear","params":[]}]},{"group":"undo","plugins":[{"name":"undo","params":[]}]},{"group":"accessibility","plugins":[{"name":"accessibilitychecker","params":[]},{"name":"accessibilityhelper","params":[]}]},{"group":"other","plugins":[{"name":"html","params":[]}]}],"pageHash":"c232ff7be4d4f99d683646a9464eb877e8517550"});
});
 M.util.js_pending('random65781ca719c2e15'); Y.on('domready', function() {  M.util.js_pending('random65781ca719c2e15'); Y.use('form_filemanager', function(Y) { M.form_filemanager.set_templates(Y, {"iconfilename":"\r\n<div class=\"fp-file\">\r\n    <a href=\"#\">\r\n    <div style=\"position:relative;\">\r\n        <div class=\"fp-thumbnail\"><\/div>\r\n        <div class=\"fp-reficons1\"><\/div>\r\n        <div class=\"fp-reficons2\"><\/div>\r\n    <\/div>\r\n    <div class=\"fp-filename-field\">\r\n        <div class=\"fp-filename text-truncate\"><\/div>\r\n    <\/div>\r\n    <\/a>\r\n    <a class=\"fp-contextmenu\" href=\"#\"><i class=\"icon fa fa-ellipsis-v fa-fw \"  title=\"\u25b6\" aria-label=\"\u25b6\"><\/i><\/a>\r\n<\/div>","listfilename":"\r\n<span class=\"fp-filename-icon\">\r\n    <a href=\"#\">\r\n    <span class=\"fp-icon\"><\/span>\r\n    <span class=\"fp-reficons1\"><\/span>\r\n    <span class=\"fp-reficons2\"><\/span>\r\n    <span class=\"fp-filename\"><\/span>\r\n    <\/a>\r\n    <a class=\"fp-contextmenu\" href=\"#\" onclick=\"return false;\"><i class=\"icon fa fa-ellipsis-v fa-fw \"  title=\"\u25b6\" aria-label=\"\u25b6\"><\/i><\/a>\r\n<\/span>","mkdir":"\r\n<div class=\"filemanager fp-mkdir-dlg\" role=\"dialog\" aria-live=\"assertive\" aria-labelledby=\"fp-mkdir-dlg-title\">\r\n    <div class=\"fp-mkdir-dlg-text\">\r\n        <label id=\"fp-mkdir-dlg-title\">New folder name<\/label><br\/>\r\n        <input type=\"text\" \/>\r\n    <\/div>\r\n    <button class=\"fp-dlg-butcreate btn-primary btn\">Create folder<\/button>\r\n    <button class=\"fp-dlg-butcancel btn-cancel btn\">Cancel<\/button>\r\n<\/div>","message":"\r\n<div class=\"file-picker fp-msg\" role=\"alertdialog\" aria-live=\"assertive\" aria-labelledby=\"fp-msg-labelledby\">\r\n    <p class=\"fp-msg-text\" id=\"fp-msg-labelledby\"><\/p>\r\n    <button class=\"fp-msg-butok btn-primary btn\">OK<\/button>\r\n<\/div>","fileselectlayout":"<div class=\"filemanager fp-select\">\r\n    <div class=\"fp-select-loading\">\r\n        <i class=\"icon fa fa-circle-o-notch fa-spin fa-fw \" aria-hidden=\"true\"  ><\/i>\r\n    <\/div>\r\n    <form class=\"mform clearfix\">\r\n        <div class=\"form-group mx-0\">\r\n            <button class=\"fp-file-download btn btn-secondary\">Download<\/button>\r\n            <button class=\"fp-file-delete btn btn-secondary\">Delete<\/button>\r\n            <button class=\"fp-file-setmain btn btn-secondary\">Set main file<\/button>\r\n            <span class=\"fp-file-setmain-help\"><a class=\"btn btn-link p-0\" role=\"button\"\r\n    data-container=\"body\" data-toggle=\"popover\"\r\n    data-placement=\"right\" data-content=\"&lt;div class=&quot;no-overflow&quot;&gt;&lt;p&gt;If there are multiple files in the folder, the main file is the one that appears on the view page. Other files such as images or videos may be embedded in it. In filemanager the main file is indicated with a title in bold.&lt;\/p&gt;\n&lt;\/div&gt; \"\r\n    data-html=\"true\" tabindex=\"0\" data-trigger=\"focus\">\r\n  <i class=\"icon fa fa-question-circle text-info fa-fw \"  title=\"Help with Set main file\" aria-label=\"Help with Set main file\"><\/i>\r\n<\/a><\/span>\r\n            <button class=\"fp-file-zip btn btn-secondary\">Zip<\/button>\r\n            <button class=\"fp-file-unzip btn btn-secondary\">Unzip<\/button>\r\n        <\/div>\r\n\r\n                <div class=\"fp-saveas form-group row mx-0\">\r\n                    <label class=\"form-control-label col-4 px-0\">Name<\/label>\r\n                    <div class=\"col-8 form-inline\"><input class=\"form-control\" type=\"text\"\/><\/div>\r\n                <\/div>\r\n                <div class=\"fp-author form-group row mx-0\">\r\n                    <label class=\"form-control-label col-4 px-0\">Author<\/label>\r\n                    <div class=\"col-8 form-inline\"><input class=\"form-control\" type=\"text\"\/><\/div>\r\n\r\n                <\/div>\r\n                <div class=\"fp-license form-group row mx-0\">\r\n                    <label class=\"form-control-label col-4 px-0\">Choose license<\/label>\r\n                    <div class=\"col-8 form-inline pr-0\">\r\n                        <select class=\"custom-select form-control\"><\/select>\r\n                    <\/div>\r\n                <\/div>\r\n                <div class=\"fp-path form-group row mx-0\">\r\n                    <label class=\"form-control-label col-4 px-0\">Path<\/label>\r\n                    <div class=\"col-8 form-inline pr-0\">\r\n                        <select class=\"custom-select form-control\"><\/select>\r\n                    <\/div>\r\n                <\/div>\r\n                <div class=\"fp-original form-group row mx-0\">\r\n                    <div class=\"form-control-label col-4 px-0\">Original<\/div>\r\n                    <div class=\"col-8 form-inline\">\r\n                        <span class=\"fp-originloading\"><i class=\"icon fa fa-circle-o-notch fa-spin fa-fw \" aria-hidden=\"true\"  ><\/i> Loading...<\/span><span class=\"fp-value\"><\/span>\r\n                    <\/div>\r\n                <\/div>\r\n                <div class=\"fp-reflist form-group row mx-0\">\r\n                    <div class=\"form-control-label col-4 px-0\">Aliases\/Shortcuts<\/div>\r\n                    <div class=\"col-8 form-inline\">\r\n                        <p class=\"fp-refcount\"><\/p>\r\n                        <span class=\"fp-reflistloading\"><i class=\"icon fa fa-circle-o-notch fa-spin fa-fw \" aria-hidden=\"true\"  ><\/i> Loading...<\/span>\r\n                        <ul class=\"fp-value\"><\/ul>\r\n                    <\/div>\r\n                <\/div>\r\n        <div class=\"fp-select-buttons form-group\">\r\n            <button class=\"fp-file-update btn-primary btn\">Update<\/button>\r\n            <button class=\"fp-file-cancel btn-secondary btn\">Cancel<\/button>\r\n        <\/div>\r\n    <\/form>\r\n    <div class=\"fp-info clearfix\">\r\n        <hr>\r\n        <p class=\"fp-thumbnail\"><\/p>\r\n        <div class=\"fp-fileinfo\">\r\n            <div class=\"fp-datemodified\">Last modified <span class=\"fp-value\"><\/span><\/div>\r\n            <div class=\"fp-datecreated\">Created <span class=\"fp-value\"><\/span><\/div>\r\n            <div class=\"fp-size\">Size <span class=\"fp-value\"><\/span><\/div>\r\n            <div class=\"fp-dimensions\">Dimensions <span class=\"fp-value\"><\/span><\/div>\r\n        <\/div>\r\n    <\/div>\r\n<\/div>","confirmdialog":"<div class=\"filemanager fp-dlg\">\r\n    <p class=\"fp-dlg-text\"><\/p>\r\n    <button class=\"fp-dlg-butconfirm btn-primary btn\">OK<\/button>\r\n    <button class=\"fp-dlg-butcancel btn-secondary btn\">Cancel<\/button>\r\n<\/div>"});  M.util.js_complete('random65781ca719c2e15'); });  M.util.js_complete('random65781ca719c2e15'); });
 M.util.js_pending('random65781ca719c2e16'); Y.on('domready', function() {  M.util.js_pending('random65781ca719c2e16'); Y.use('form_filemanager', function(Y) { M.form_filemanager.init(Y, {"path":[{"name":"Files","path":"\/"}],"itemid":673427866,"list":[],"filecount":0,"mainfile":"","maxbytes":20971520,"maxfiles":"1","client_id":"65781ca7b1a62","subdirs":0,"target":"id_overviewfiles_filemanager","accepted_types":[".jpg",".gif",".png"],"return_types":14,"context":{"id":958,"contextlevel":40,"instanceid":"6","path":"\/1\/958","depth":"2","locked":false},"areamaxbytes":-1,"author":"Test Auto","licenses":[{"shortname":"unknown","fullname":"Other"},{"shortname":"allrightsreserved","fullname":"All rights reserved"},{"shortname":"public","fullname":"Public domain"},{"shortname":"cc","fullname":"Creative Commons"},{"shortname":"cc-nd","fullname":"Creative Commons - NoDerivs"},{"shortname":"cc-nc-nd","fullname":"Creative Commons - No Commercial NoDerivs"},{"shortname":"cc-nc","fullname":"Creative Commons - No Commercial"},{"shortname":"cc-nc-sa","fullname":"Creative Commons - No Commercial ShareAlike"},{"shortname":"cc-sa","fullname":"Creative Commons - ShareAlike"}],"defaultlicense":"allrightsreserved","userprefs":{"recentviewmode":""},"filepicker":{"defaultlicense":"allrightsreserved","licenses":[{"shortname":"unknown","fullname":"Other"},{"shortname":"allrightsreserved","fullname":"All rights reserved"},{"shortname":"public","fullname":"Public domain"},{"shortname":"cc","fullname":"Creative Commons"},{"shortname":"cc-nd","fullname":"Creative Commons - NoDerivs"},{"shortname":"cc-nc-nd","fullname":"Creative Commons - No Commercial NoDerivs"},{"shortname":"cc-nc","fullname":"Creative Commons - No Commercial"},{"shortname":"cc-nc-sa","fullname":"Creative Commons - No Commercial ShareAlike"},{"shortname":"cc-sa","fullname":"Creative Commons - ShareAlike"}],"author":"Test Auto","repositories":{"2":{"id":"2","name":"Server files","type":"local","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_local\/1617770024\/icon","supported_types":[],"return_types":6,"defaultreturntype":2,"sortorder":2},"3":{"id":"3","name":"Recent files","type":"recent","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_recent\/1617770024\/icon","supported_types":[],"return_types":2,"defaultreturntype":2,"sortorder":3},"4":{"id":"4","name":"Upload a file","type":"upload","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_upload\/1617770024\/icon","supported_types":[],"return_types":2,"defaultreturntype":2,"sortorder":4},"5":{"id":"5","name":"URL downloader","type":"url","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_url\/1617770024\/icon","supported_types":[".gif",".jpe",".jpeg",".jpg",".png",".svg",".svgz"],"return_types":3,"defaultreturntype":2,"sortorder":5},"6":{"id":"6","name":"Private files","type":"user","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_user\/1617770024\/icon","supported_types":[],"return_types":6,"defaultreturntype":2,"sortorder":6},"7":{"id":"7","name":"Wikimedia","type":"wikimedia","icon":"https:\/\/moodle-stage.laerdalblr.in\/theme\/image.php\/boost\/repository_wikimedia\/1617770024\/icon","supported_types":[],"return_types":3,"defaultreturntype":2,"sortorder":7}},"externallink":true,"userprefs":{"recentrepository":"4","recentlicense":"allrightsreserved","recentviewmode":""},"accepted_types":[".jpg",".gif",".png"],"return_types":14}});  M.util.js_complete('random65781ca719c2e16'); });  M.util.js_complete('random65781ca719c2e16'); });
 M.util.js_pending('random65781ca719c2e17'); Y.on('domready', function() {  M.util.js_pending('random65781ca719c2e17'); Y.use('mform', function(Y) { M.form.initFormDependencies(Y, "mform1_2UgX3cbcrCd9RgL", {"enddate[enabled]":{"notchecked":{"1":[["enddate[day]","enddate[month]","enddate[year]","enddate[hour]","enddate[minute]","enddate[calendar]"]]}}});  M.util.js_complete('random65781ca719c2e17'); });  M.util.js_complete('random65781ca719c2e17'); });
 M.util.js_pending('random65781ca719c2e18'); Y.on('domready', function() { M.util.js_complete("init");  M.util.js_complete('random65781ca719c2e18'); });
})();
//]]>
</script>

        </div>
    </footer>
</div>

</body>
</html>