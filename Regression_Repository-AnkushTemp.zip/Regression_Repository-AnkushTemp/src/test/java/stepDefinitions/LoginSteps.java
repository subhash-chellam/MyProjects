package stepDefinitions;


import java.io.FileInputStream;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FilenameUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.support.ui.FluentWait;

import com.qa.pages.Admin;
import com.qa.pages.EndUser;
import com.qa.pages.LoginPage;
import com.qa.pages.OrganizationHome;
import com.qa.pages.OrganizationSettings;
import com.qa.pages.Products;
import com.qa.pages.Scrom;
import com.qa.pages.User;
import com.qa.util.DatabaseConnection;
import com.qa.util.ScreenCapture;
import com.qa.util.TestBase;
import com.qa.pages.KeyClock;
import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps extends TestBase {

	LoginPage loginpage;
	String downloadPath = System.getProperty("user.dir") + prop.getProperty("downloadPath");

//	ScreenCapture screen;


	@Before
	public void updateEndExecutionTime(Scenario scenario) throws Exception
	{   
		
				try {
//					driver.quit();
					String scenarioName = scenario.getName();
					String featureName = scenario.getId();
					System.out.println("******************************Start of Sceanrio*****************************************");
					System.out.println("Feature file scenario is *********** " + scenarioName);
					System.out.println(featureName);
					String name = FilenameUtils.getName(featureName);
					System.out.println(name);
					
					String result = name.split(":")[0];
					System.out.println("Feature file name is *********** " + result);
					System.out.println("Deleting the zip and other files");
					Products.isFileDownloaded_Ext (downloadPath, ".zip");
					Products.isFileDownloaded_Ext (downloadPath, ".csv");
					Products.isFileDownloaded_Ext (downloadPath, ".pdf");
				
					
				} catch (Exception e) {
					e.printStackTrace();
				}
	}
	@After
	public void updateEdExecutionTime(Scenario scenari) throws Exception
	{   
		
				try {
					
//					driver.quit();
//					Products.isFileDownloaded_Ext (downloadPath, ".zip");
//					Products.isFileDownloaded_Ext (downloadPath, ".csv");
//					
//					TestBase.networkLog();;	
					if(scenari.isFailed())
					{
						
						((JavascriptExecutor)driver).executeScript("document.body.style.zoom='50%';");
					final byte[] screenshot = ((TakesScreenshot) TestBase.driver).getScreenshotAs(OutputType.BYTES);
						scenari.attach(screenshot, "image/png", "image"); 
						if(!(OrganizationHome.exceptionid==null))
						  {

						scenari.log("Org ID:"+OrganizationHome.exceptionid);
						System.out.println(OrganizationHome.exceptionid);
						scenari.log("Org Name: "+OrganizationHome.exceptionorg);
						System.out.println(User.userEmail);
						scenari.log("User Name: "+User.userEmail);
						scenari.log("URL "+driver.getCurrentUrl());
						}
						((JavascriptExecutor)driver).executeScript("document.body.style.zoom='100%';");
						DatabaseConnection.failcount++;
						
					}
					else
						DatabaseConnection.passcount++;
					System.out.println("******************************End of Sceanrio*****************************************");
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				System.out.println("modifying end date");
			
					
	}
	
	public static boolean flag = false;
	@Given("Browser is launched")
	public void browser_is_launched() 
	{
//		screen = new ScreenCapture();
		TestBase.initialization();
		loginpage = new LoginPage();
//		screen.screen();	
		User.usrEmail=null;
		User.jobtile=null;
		User.userEail=null;
		User.userEmail=null;
		
		User.usrEmail=null;
		User.jobtile=null;
		User.userEail=null;
		User.userEmail=null;
		Admin.email=null;
		Scrom.email=null;
		EndUser.secondaryEmail=null;
		OrganizationSettings.titleName=null;
		TestBase.dataMap.clear();
	}
	
	@Given("Browser is launched or Uses Existing Session")
	public void browser_is_launched_or_Using() 
	{
//		screen = new ScreenCapture();
//		
		try
		{
			
			driver.navigate().to((prop.getProperty("url"+prop.getProperty("environment"))));
			System.out.println(driver.getCurrentUrl());
			System.out.println(prop.getProperty("url"+prop.getProperty("environment")));
			driver.navigate().to((prop.getProperty("url"+prop.getProperty("environment"))));
			System.out.println("navigate "+driver.getCurrentUrl());
			loginpage = new LoginPage();
			loginpage.clickOnAdminSignIn();
			if(driver.getCurrentUrl().contains("/admin/organizations/chooseDashboard"))
				System.out.println("In the chooseDashboard ");
			else
				loginpage.credentials(prop.getProperty("userEmailId"+prop.getProperty("environment")), prop.getProperty("userPassword"+prop.getProperty("environment")));
		
		
		}
		catch(Exception e)
		{
			if(driver!=null)
			{
				driver.quit();	
			}
			
			TestBase.initialization();
			loginpage = new LoginPage();
			loginpage.clickOnAdminSignIn();
			loginpage.credentials(prop.getProperty("userEmailId"+prop.getProperty("environment")), prop.getProperty("userPassword"+prop.getProperty("environment")));

		}
		User.usrEmail=null;
		User.jobtile=null;
		User.userEail=null;
		User.userEmail=null;
		Admin.email=null;
		Scrom.email=null;
		EndUser.secondaryEmail=null;
		OrganizationSettings.titleName=null;
		TestBase.dataMap.clear();
	}

	@When("User clicks on sign In button")
	public void user_clicks_on_sign_In_button() {
		loginpage = new LoginPage();
		loginpage.clickOnAdminSignIn();
	}

	@Then("User login to application")
	public void user_login_to_application() {
		loginpage.credentials(prop.getProperty("userEmailId"+prop.getProperty("environment")), prop.getProperty("userPassword"+prop.getProperty("environment")));
	}

	@Then("select the user role")
	public void select_the_user_role() {
		loginpage.selectUserRole();
	}
	 @Then("select the user role as {string}")
	    public void select_the_user_role_as(String role)
	    {
		 loginpage.selectUserRoleOnly(role);
	    }

@Then("select organization panel")
public void select_organization_panel() {
  loginpage.selectOrgpanel1();
}

	@Then("select the user role {string}")
	public void select_the_user_role(String role) {
		loginpage.selectUserRole(role);
	}

	@Then("select the user role only")
	public void select_the_user_role_only() {
		loginpage.selectUserRoleOnly();
		User.group=null;
		
	}
	
	@Then("Verfiy the home page")
	public void verfiy_the_home_page() {
		loginpage.verfiy_the_home_page();
		
		
	}

	@Then("user logout from application")
	public void user_logout_from_application() 
	{
//		screen = new ScreenCapture();
//		screen.stopRecording();
		loginpage.user_logout_from_application();
		flag = true;
		
	}

	@Then("user logout from application without quit")
	public void user_logout_from_application_without_quit() {
		loginpage.user_logout_from_application_without_quit();
		User.group=null;
		User.usrEmail=null;
		User.jobtile=null;
		User.userEail=null;
					
	}
	
	@Then("user close the browser")
	public void user_close_the_browser() 
	{
//		screen = new ScreenCapture();
//		screen.stopRecording();
		loginpage.user_close_the_browser();
		flag = true;
		
	}
	
	@Given("Browser is launched for end user")
	public void browser_is_launched_end_user() {
		TestBase.initializationEndUser();
	}
		
	@When("User clicks on sign In button for end user")
	public void user_clicks_on_sign_In_button_end_user() {
		loginpage = new LoginPage();
		loginpage.clickOnAdminSignInEndUser();
	}
	
	@Then("User login to application for end user")
	public void user_login_to_application_end_user() {
		System.out.println(prop.getProperty("EndUserPassword"));
		loginpage.credentialsEndUser(prop.getProperty("EndUserEmail"), prop.getProperty("EndUserPassword"));
	}

	@Then("select the user role as RQI")
	public void select_the_user_role_as_rqi() 
	{
	    loginpage.selectUserAsRQI();
	}

	@Then("select the user role as Super implementor")
	public void select_the_user_role_as_Superimplementor() 
	{
	    loginpage.selectUserAsSuperImplementer();
	}
	@Then("user logout from dashboard")
	public void user_logout_from_dashboard() 
	{
	    if(loginpage == null)
	    	loginpage = new LoginPage();
//	    screen = new ScreenCapture();
//	    screen.stopRecording();
	    loginpage.user_logout_from_dashboard();
	}
	
	@Then("navigate to application url")
	public void navigate_to_application_url() {
		if(loginpage == null)
	    	loginpage = new LoginPage();
		loginpage.navigateApplication();
	}
	
	@Then("validate the footer text")
	public void validate_the_footer_text() {
		if(loginpage == null)
	    	loginpage = new LoginPage();
		loginpage.validateFooter("footerText");
	}
	
	@Then("navigate to application admin url")
	public void navigate_to_application_admin_url() {
		if(loginpage == null)
	    	loginpage = new LoginPage();
		loginpage.navigateApplicationAdmin();
	}
	
	@Then("validate support downdown is not available")
	public void validate_support_downdown_is_not_available() {
		if(loginpage == null)
	    	loginpage = new LoginPage();
		loginpage.verifySupportDropNotAvailable();
	}
	
	@Then("user logout from dashboard without quit")
	public void user_logout_from_dashboard_without_quit() 
	{
	    if(loginpage == null)
	    	loginpage = new LoginPage();
	    loginpage.user_logout_from_dashboard_without_quit();
	}
	
	@Then("login to rqip as new user")
	public void login_to_rqip_as_new_user() {
		if(loginpage == null)
	    	loginpage = new LoginPage();
		loginpage.credentials(User.userEmail, KeyClock.pwd);
	}
	
}
