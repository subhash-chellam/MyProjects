package stepDefinitions;

import com.qa.pages.Admin;
import com.qa.pages.Assignments;
import com.qa.pages.OrganizationHome;
import com.qa.pages.OrganizationSettings;
import com.qa.pages.Products;
import com.qa.pages.Students;
import com.qa.pages.User;
import com.qa.util.TestBase;
import com.qa.util.reuseableCode;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class AssignmentSteps 
{
	Products prod;
	User usr;
	Assignments assign;
	OrganizationHome org;
	OrganizationSettings orgSet;

	@Then("add the product automatic")
	public void add_the_product_automatic() 
	{
		User usr=new User();
		usr.pageLoad();
	    prod = new Products();
	    
	    prod.clickOnAddProductsButton();
	    prod.enterProductDetails("automatic");
	}
	
	@Then("add the automatic assignment with course name {string}")
	public void add_the_automatic_assignment_with_course_name(String course) {
		assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.selectAutomatic();
	    assign.assignmentFromUserSpecificCourse(course);
	
	}
	@Then("navigate to User page") 
	public void navigate_to_User_page()
	{
		usr = new User();
	    usr.pageLoad();
	    usr.ClickonUserTab();
	}
	
	@Then("click on delete assignment")
	public void click_on_delete_assignment() {
		assign = new Assignments();
		assign.deleteAssignment();
	}
	@Then("select the assignment due date as {string}")
	public void select_the_assignment_due_date_as(String dueDate) 
	{
	    assign.selectAssignmentDueDate(dueDate);
	}
	
	@Then("select the assignment due date as {string} for {int} days")
	public void select_the_assignment_due_date_as(String dueDate,int days) 
	{
	    assign.selectAssignmentDueDate(dueDate,days);
	}
	
	@Then("select assignment start date as {string}")
	public void select_assignment_start_date_as(String dateType) 
	{
	    if(dateType.equals("specific date"))
	    	assign.addSpecificDate();
	}
	
	
	@Then("select the product {string} for {string} assignment")
	public void select_the_product_for_assignment(String courseName, String type) 
	{
	    if(type.equalsIgnoreCase("automatic"))
	    	assign.selectAutomatic();
	    assign.assignmentFromUserSpecificCourse(courseName);
	    
	}
	@Then("click on create assignment button")
	public void click_on_create_assignment_button() 
	{
		if(assign == null)
			assign = new Assignments();
		assign.clickOnCreateAssignment();
	}
	
	@Then("navigate to assignment page")
	public void navigate_to_assignment_page() 
	{
	    usr = new User();
	    usr.pageLoad();
	    usr.clickOnAssignmentTab();
	}
	@Then("add the automatic assignment with same criteria {string} and course name {string}")
	public void add_the_automatic_assignment_with_same_org_criteria(String name, String course) 
	{
		assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.selectAutomatic();
	    assign.assignmentFromUserSpecificCourse(course);

		 assign.Click_on_nextSection();
	    String criteria[] = name.split(",");
	    for(int i = 0; i <= criteria.length - 1; i++)
	    {
	    	assign.selectSameCriteria(criteria[i].trim(), i);
	    	assign.clickOnAddCriteria();
	    }	    
	}
	
//	@Then("add the automatic assignment with different multiple criteria {string}")
//	public void add_the_automatic_assignment_with_different_multiple_criteria_group_count(String criterias) 
//	{
//		User usr=new User();
//		usr.pageLoad();
//		assign = new Assignments();
//	    assign.clickOnCreateAssignment();
//	    assign.selectAutomatic();
//	    assign.assignmentFromUser();
//		assign.selectDifferentMultipleCriteria(criterias);
//	}

	@Then("add multiple automatic assignments with course name {string} and specific date and criteria {string}")
	public void add_multiple_automatic_assignments_with_course_name_and_specific_date_and_with_user_email(String courseName, String criterias) 
	{
		if(assign == null)
			assign = new Assignments();
		String course[] = courseName.split(",");
		for(int i = 0; i <= course.length-1; i++)
		{
			 assign.clickOnCreateAssignment();
			 assign.selectAutomatic();
			 assign.assignmentFromUserSpecificCourse(course[i]);

			 assign.Click_on_nextSection();
			 assign.addSpecificDate();
			 assign.selectDifferentMultipleCriteria(criterias);
		}
	}
	@Then("enter the manual assignment details with user email and by course name {string} {string}")
	public void enter_the_manual_assignment_details_with_user_email_and_by_course_name(String first, String courseName)
	{
		if(assign == null)
			assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.assignmentFromUserSpecificCourse(courseName);

		 assign.Click_on_nextSection();
	    	if(User.userEmail != null)
			{
				assign.addLearners(User.userEmail);
			}
			else
			{
				assign.addLearners(Students.email);
			}	
//	    	assign.click_on_cancel();
		    assign.verifyAddStudentFirst(first);

//	    	assign.editAssignmentTitle();	
		    assign.createAssignment();
		
	}
	
	@Then("add multiple manual assignments with course name {string} and specific date and with user email {string}")
	public void add_multiple_manual_assignments_with_course_name_and_specific_date_and_with_user_email(String courseName, String first) 
	{
		if(assign == null)
			assign = new Assignments();
		String course[] = courseName.split(",");
		for(int i = 0; i <= course.length-1; i++)
		{
			 assign.clickOnCreateAssignment();
			 assign.assignmentFromUserSpecificCourse(course[i]);
			 assign.addSpecificDate();
			 assign.Click_on_nextSection();
			 assign.addLearners(User.userEmail);
//			 assign.click_on_cancel();
			 assign.verifyAddStudentFirst(first);
//			 assign.editAssignmentTitle();	
			 assign.createAssignment();
		}
	}
	@Then("assign all manual products as per name {string} and user email as assignment to the user {string}")
	public void assign_all_manual_products_as_per_name_and_user_email_as_assignment_to_the_user(String names, String first) 
	{
		if(assign == null)
			assign = new Assignments();
		String course[] = names.split(",");
		for(int i = 0; i <= course.length-1; i++)
		{
	    assign.clickOnCreateAssignment();
	    assign.assignmentFromUserSpecificCourse(course[i]);
	    	 
			assign.Click_on_nextSection();
			assign.addLearners(User.userEmail);
//			 assign.click_on_cancel();
			assign.verifyAddStudentFirst(first);
			   assign.Click_on_createAssignmentBtn();
		
		}
	}
	
	@Then("add the automatic assignment with criteria {string} and course name {string}")
	public void add_the_automatic_assignment_with_org_criteria(String name, String course) 
	{
		assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.selectAutomatic();
	    assign.assignmentFromUserSpecificCourse(course);
	    	assign.Click_on_nextSection();
		 
	    String criteria[] = name.split(",");
	    for(int i = 0; i <= criteria.length - 1; i++)
	    {
	    	assign.selectCriteria(criteria[i], i);
	    	assign.clickOnAddCriteria();
	    }	    
	}
	
	@Then("Select multiple criteria {string}")
	public void selectmultipleCriteria(String name) 
	{
    	assign.Click_on_nextSection();
    	
		   String criteria[] = name.split(",");
		    for(int i = 0; i <= criteria.length - 1; i++)
		    {
		    	assign.selectCriteria(criteria[i], i);
		    	assign.clickOnAddCriteria();
		    }	  
	}

	@Then("add the manual assignment")
	public void add_the_manual_assignment() 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.assignmentFromUser();
	    assign.Click_on_nextSection();
	    assign.createAssignment();
	}


	@Then("add the manual assignment for course {string}")
	public void add_themanual_assignment(String course) 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.assignmentFromUser(course);
	  		 
			assign.Click_on_nextSection();
			   assign.Click_on_createAssignmentBtn();
	
	}

	@Then("create assignment Btn should not be available")
	public void add_themanual_assignment() 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new Assignments();
	    assign.CreateAssignmentBtnshouldnotbeAvailable();
	  
	}
	@Then("Edit assignment Btn should not be available")
	public void addthemanual_assignment() 
	{
		User usr=new User();
		usr.pageLoad();
		
		assign = new Assignments();
	    assign.EditAssignmentBtnnotavailable();
	  
	}

	@Then("Validate the drop down Action option {string} is {string} from assignment screen")
	public void navigateto_add_group_popup(String drop,String status) 
	{
		if(usr == null)
			usr = new User();
		assign.clickonActionDetail();
		for(int i=0;i<drop.split(",").length;i++)
			assign.validationifdropdown(drop.split(",")[i],status);
	}
	@Then("View assignment Btn should available")
	public void themanual_assignment() 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new Assignments();
	    assign.ViewAssignmentBtavailable();
	  
	}

	@Then("assign all manual products {string}")
	public void assign_all_manual_products_as_assignment_to_the_user(String names) 
	{
		if(assign == null)
			assign = new Assignments();
		String course[] = names.split(",");
		User usr=new User();
		usr.pageLoad();
		for(int i = 0; i <= course.length-1; i++)
		{
	    assign.clickOnCreateAssignment();
	    assign.assignmentFromUser(course[i]);
	    assign.Click_on_nextSection();
	    assign.createAssignment();
		}
	}
	@Then("add the automatic assignment")
	public void add_the_automatic_assignment() 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.selectAutomatic();
	    assign.assignmentFromUser();
	    assign.Click_on_nextSection();
	    assign.createAutoAssignment();
	}
	
	@Then("user navigate to Manage Assignment page")
	@Then("user navigate to edit assignment page")
	public void user_navigate_to_edit_assignment_page() 
	{
		User usr=new User();
		usr.pageLoad();
	    if(assign == null)
	    	assign = new Assignments();
	    assign.assignmentActiondetails();
	    assign.clickEditAssignmentOption();
	}

	@Then("edit the assignment and save {string}")
	public void edit_the_assignment_and_save(String first) 
	{
		User usr=new User();
		usr.pageLoad();
	    assign.addLearners(first);
//	    assign.click_on_cancel();
		
	    assign.verifyAddStudentFirst(first);
	}
	
	@Then("try to add duplicate user")
	public void try_to_add_duplicate_user() 
	{
		User usr=new User();
		usr.pageLoad();
	    assign.addDuplicateUser("Ansh");
	}
	
	@Then("edit the automatic assignment")
	public void edit_the_automatic_assignment() 
	{
		User usr=new User();
		usr.pageLoad();
	    assign.editAutomaticAssignment();
	}

	@Then("add the manual assignment with user {string}")
	public void add_the_manual_assignment_with_user(String first) 
	{
		User usr=new User();
		usr.pageLoad();
		if(assign == null)
			assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.assignmentFromUser();
	    assign.Click_on_nextSection();
	    assign.addLearners(User.userEmail);
//	    assign.click_on_cancel();
		
	    assign.verifyAddStudentFirst(first);
	    assign.createAssignment();
	}
	
	@Then("add the manual assignment with user {string} and course {string}")
	public void ad_the_manual_assignment_with_user_and_course(String first, String course) 
	{
		User usr=new User();
		usr.pageLoad();
		if(assign == null)
			assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.assignmentFromUserSpecificCourse(course);
	    assign.Click_on_nextSection();
		assign.addLearners(User.userEmail);
//		 assign.click_on_cancel();
			
	    assign.verifyAddStudentFirst(first);
	    assign.createAssignment();
	}

	@Then("select the enable recurrence as {string}")
	public void select_the_enable_recurrence_as(String recurrence) 
	{
	    assign.selectEnableRecurrence(recurrence);
	}
	@Then("enter recurrence frequency details {int} {string} {string}")
	public void enter_recurrence_frequency_details(Integer number, String unit, String based) 
	{
	    assign.enterRecurrenceFrequency(number, unit, based);
	}
	@Then("select recurrence due date as {string} with {string} {string}")
	public void select_recurrence_due_date_as_with(String recurrenceDueDateType, String number, String unit) 
	{
		assign.selectRecurrenceDueDateWithString(recurrenceDueDateType,number, unit);
	}
	@Then("select recurrence due date as {string} with {int} {string}")
	public void select_recurrence_due_date_as_with(String recurrenceDueDateType, Integer number, String unit) 
	{
	    assign.selectRecurrenceDueDate(recurrenceDueDateType,number, unit);
	}
	@Then("select recurrence end date as specific number {int}")
	public void select_recurrence_end_date_as_specific_number(Integer number) 
	{
	    assign.selectRecurrenceSpecificNumber(number);
	}
	
	
	@Then("select the criteria as per name {string}")
	public void select_the_criteria_as_per_name(String criteria) 
	{
		assign.selectCriteria(criteria);
	}
	
	
	@Then("select Subscription Plan as {string}")
	public void select_Subscription_as(String subscription) 
	{
		assign.selectsubscriptionPlan(subscription);
	}
	
	@Then("select Student Pay")
	public void select_Student_pay() 
	{
		assign.selectStudentPay();
	}
	
	@Then("select Organization Pay")
	public void select_OrganizationPay_pay() 
	{
		assign.selectOrganizationPayRadio();
	}
	
	@Then("Validated If Organization Pay Radio not present")
	public void validatedIfOrganizationPayRadio() 
	{
		assign.validatedIfOrganizationPayRadio();
	}
	
	
	@Then("select recurrence end date as {int} {string}")
	public void select_recurrence_end_date_as(Integer number, String freq) 
	{
	    assign.selectRecurrenceSpecificDate(number, freq);
	}
	@Then("create the {string} assignment")
	public void create_the_assignment(String type) 
	{
	    if(type.equalsIgnoreCase("manual"))
	    	assign.createAssignment();
	    else if(type.equalsIgnoreCase("automatic"))
	    	assign.createAutoAssignment();
	}
	@Then("validate the Recurrence Status {string} assignment")
	public void create_theassignment(String status) 
	{
	   
	    	assign.validateRecurrence(status);;
	 
	}
	
	
	@Then("add the created {int} user to the assignment {string}")
	public void add_the_user_o_the_assignment(int user,String first) 
	{
		for(int i=0;i<user;i++)
		{
			System.out.println(i);
			
		    assign.addLearners(first,i);
		
		}   
//		 assign.click_on_cancel();
			
		
	}

	@Then("add the mnual assignment with user {string} and course {string}")
	public void add_the_manual_assignment_with_user_and_course(String first, String course) 
	{
		User usr=new User();
		usr.pageLoad();
		if(assign == null)
			assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.assignmentFromUserSpecificCourse(course);
	   
	}
	@Then("add the manual assignment with user and specific date {string}")
	public void add_the_manual_assignment_with_user_and_specific_date(String first) 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.assignmentFromUser();
	    assign.addSpecificDate();
	    assign.Click_on_nextSection();
	    assign.addLearners(User.userEmail);
//	    assign.click_on_cancel();
	    assign.verifyAddStudentFirst(first);
	    assign.createAssignment();
	}
	
	@Then("add the manual assignment with user and due date {string}")
	public void add_the_manual_assignment_with_user_and_due_date(String first) 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.assignmentFromUser();
	    assign.addSpecificDate();
	    assign.Click_on_nextSection();
		   
	    assign.addLearners(User.userEmail);
//	    assign.click_on_cancel();
		
	    assign.verifyAddStudentFirst(first);
	    assign.createAssignment();
	}


	@Then("add the manual assignment with user and Relative date {string} {int}")
	public void add_the_manual_assignment_with_user_and_Relative_date(String first, int weeks) 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.assignmentFromUser();
	    assign.selectRelativeDate(weeks);
	    assign.Click_on_nextSection();
		
	    assign.addLearners(User.userEmail);
//	    assign.click_on_cancel();
		
	    assign.verifyAddStudentFirst(first);
	    assign.createAssignment();
	}

	@Then("enter the manual assignment details with user {string}")
	public void enter_the_manual_assignment_details_with_user(String first) 
	{
		User usr=new User();
		usr.pageLoad();
		if(assign == null)
			assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.assignmentFromUser();
	    assign.Click_on_nextSection();
		
	    assign.addLearners(User.userEmail);
//	     assign.click_on_cancel();

	    assign.verifyAddStudentFirst(first);
	    
	}
	
	@Then("delete the user available")
	public void delete_the_user_available() 
	{
		User usr=new User();
		usr.pageLoad();
	    assign.deleteAddStudent();
	}

	@Then("add the user {string}")
	public void add_the_user(String first) 
	{
		User usr=new User();
		usr.pageLoad();
		if(assign == null)
			assign = new Assignments();
		assign.addLearners(User.userEmail);
//		 assign.click_on_cancel();
			
	    assign.verifyAddStudentFirst(first);
	}

	
	@Then("add the Learners by {string}")
	public void add_the_Learners(String Learners) 
	{
		User usr=new User();
		usr.pageLoad();
		if(assign == null)
			assign = new Assignments();
		if(Learners.contains("Email"))
		{
		assign.addLearners(User.userEmail);
//		 assign.click_on_cancel();
		}
		else if(Learners.contains("Firstname"))
		{
			assign.addLearners(User.userFirstName);
//			 assign.click_on_cancel();
		}
		else
		{
			assign.addLearners(User.userLastName);
			 assign.click_on_cancel();
		}
			
	    assign.verifyAddStudentFirst(usr.userFirstName);
	}
	@Then("create the manual assignment")
	public void create_the_manual_assignment() 
	{
		User usr=new User();
		usr.pageLoad();
		if(assign == null)
			assign = new Assignments();
		assign.createAssignment();
	}
	
	@Then("create the assignment")
	public void create_the_assignment() 
	{
		User usr=new User();
		usr.pageLoad();
		if(assign == null)
			assign = new Assignments();
		assign.createAutoAssignment();
	}
	
	@Then("create the assignment Button")
	public void create_the_assignment_btn() 
	{
		User usr=new User();
		usr.pageLoad();
		if(assign == null)
			assign = new Assignments();
		 assign.createAssignment();
	}
	

	
	
	@Then("click on Cancel in Add Learner")
	public void clickonCancel_in_Add_learner() 
	{
		
		if(assign == null)
			assign = new Assignments();
		assign.click_on_cancel();
	}
	
	@Then("search the user {string}")
	public void search_the_user(String first) 
	{
		User usr=new User();
		usr.pageLoad();
	    assign.searchUserByName(first);
	    assign.searchUserByDelivery(first);
	}

	@Then("count the rows {int}")
	public void count_the_rows(Integer count) 
	{
	    assign.countUserRows(count);
	}
	
	@Then("Validate Assignment Student count {string}")
	public void count_he_rows(String count) 
	{
	    assign.validateStudentAssignment(count);
	}
	@Then("Validate exact Assignment Student count {string}")
	@Then("Validate if is unenroll Assignment Student count {string}")
	public void counthe_rows(String count) 
	{
	    assign.validateunrollStudentAssignment(count);
	}
	@Then("Validate Specific Day {int}")
	public void count_the_rows(int count) 
	{
	    assign.validateSpecificDate(count);
	}
	@Then("Validate Assignment Date {int}")
	public void count_therows(int count) 
	{
		
	    assign.validateAssignmentDate(count);
	}
	
	
	
	
	@Then("wait for automatic Assignment to load {string}")
	public void count_rows(String count) 
	{
	    assign.Assignmentname(count);
	}
	@Then("add the manual assignment with first user {string} {int}")
	public void add_the_manual_assignment_with_first_user(String first, int count) 
	{
		User usr=new User();
		usr.pageLoad();
		if(assign == null)
			assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.assignmentFromUser();
	    assign.Click_on_nextSection();
	    assign.addLearners(first,count);
//	    assign.click_on_cancel();
	    assign.verifyAddStudentFirst(first+count);
	    assign.createAssignment();
	}

	@Then("edit the assignment and add another user {string} {int}")
	public void edit_the_assignment_and_add_another_user(String first, int count) 
	{
		User usr=new User();
		usr.pageLoad();
	    assign.addLearners(first,count);
//	    assign.click_on_cancel();
		
	    assign.verifyNewAddedStudent(first, count);
	}

	@Then("add multiple user {int}")
	public void add_multiple_user(int count) 
	{
		User usr=new User();
		usr.pageLoad();
		  assign.Click_on_nextSection();
			
		for(int i=0;i<count;i++)
		{
			  
	    assign.addLearners(i);
	   
		}
//		  assign.click_on_cancel();
		  try
		    {
		    Thread.sleep(5000);	
		    }
		    catch(Exception e)
		    {
		    	
		    }  
		for(int i=0;i<count;i++)
		{
		    assign.verifyNewAddedStudent("Ansh"+(i+1));
			
		}
	}
	@Then("add user")
	public void add_multiple_user() 
	{
		User usr=new User();
		usr.pageLoad();
		  assign.Click_on_nextSection();
			
	    assign.addLearners(0);
	    assign.click_on_cancel();
		
	   assign.errorMessage();
	}
	

	@Then("navigate to user page")
	public void navigate_to_user_page() 
	{
		if(usr == null)
			usr = new User();
		usr.pageLoad();
	    usr.navigateUserModule();
	}

	@Then("Search {string} in {string} field to user page")
	public void search_to_user_page(String data,String field) 
	{
		if(usr == null)
			usr = new User();
		usr.pageLoad();
	    usr.searchuser(field,data);
	}
	
	@Then("Edit any inactive user in user page")
	public void searchto_user_page() 
	{
		if(usr == null)
			usr = new User();
		usr.pageLoad();
	    usr.editInactiveUser();;
	}
	@Then("count the rows without update {int}")
	public void count_the_rows_without_update(int count) 
	{
		User usr=new User();
		usr.pageLoad();
	    assign.countUserRowsWithoutUpdate(count);
	}

	@Then("update the assignment")
	public void update_the_assignment() 
	{
		User usr=new User();
		usr.pageLoad();
		assign.updateManualAssignment();
	}

	@Then("add the automatic assignment with criteria {string}")
	public void add_the_automatic_assignment_with_org_criteria(String name) 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.selectAutomatic();
	    assign.assignmentFromUser();
	    assign.Click_on_nextSection();
		
	    assign.selectCriteria(name);
	}
	@Then("add the automatic assignment {string} with criteria {string}")
	public void add_theautomatic_assignment_with_org_criteria(String course,String name) 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.selectAutomatic();
	    assign.assignmentFromUser(course);
	    assign.Click_on_nextSection();
		
	    assign.selectCriteria(name);
	}

		
	@Then("validate the search functionality {string} {string}")
	public void validate_the_search_functionality(String name, String value) 
	{
		User usr=new User();
		usr.pageLoad();
	    assign.searchAutoUserByName(name, value);
	}
	@Then("validate the search functionality {string}")
	public void validate_the_search_functionality( String value) 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new Assignments();
		 
	    assign.searchAutoUserByDelivery( value);
	}
	
	@Then("User validate the level {string}")
	public void user_validate_the_level(String level) 
	{
		User usr=new User();
		usr.pageLoad();
	    assign.verifyAutoUnitLevel(level);
	}
	
	@Then("select specific date")
	public void select_specific_date() 
	{
		User usr=new User();
		usr.pageLoad();
	    assign.addSpecificDate();
	}
	@Then("select Start specific date")
	public void select_Start_specific_date() 
	{
		User usr=new User();
		usr.pageLoad();
	    assign.addStartSpecificDate();
	}
	
	@Then("select relative date {int}")
	public void select_relative_date(int week) 
	{
		User usr=new User();
		usr.pageLoad();
		assign.selectRelativeDate(week);
	}
	
	@Then("select relative date is disabled")
	public void select_relative_datedisabled() 
	{
		User usr=new User();
		usr.pageLoad();
		assign.selectRelativeDatedisable();
	}
	
	@Then("validate criteria is disabled")
	public void validate_criteria_is_disabled() 
	{
		User usr=new User();
		usr.pageLoad();
	    assign.validateCriteriaDisabled();
	}
	
	@Then("user navigate to view assignment page")
	public void user_navigate_to_view_assignment_page() 
	{
		User usr=new User();
		usr.pageLoad();
	    if(assign == null)
	    	assign = new Assignments();
	    assign.assignmentActiondetails();
	    assign.clickViewAssignmentOption();
	}
	
	@Then("validate the search functionality on view page {string}")
	public void validate_the_search_functionality_on_view_page(String first) 
	{
		User usr=new User();
		usr.pageLoad();
		assign.searchUserByNameViewPage(first);
	}
	
	@Then("view and edit the automatic assignment")
	public void view_and_edit_the_automatic_assignment() 
	{
		User usr=new User();
		usr.pageLoad();
	    assign.clickOnEditAssignment();
	}
	@Then("Manage Assignment")
	@Then("edit assignment")
	public void editthe_automatic_assignment() 
	{
		User usr=new User();
		usr.pageLoad();
		 if(assign == null)
		    	assign = new Assignments();
	    assign.clickOnEditAssignmnt();
	}

	@Then("Click on Edit Assignment Details")
	public void editthe_EditAssignmentDetailst() 
	{
		 if(assign == null)
		    	assign = new Assignments();
	    assign.clickOnEditAssignmentBtn();
	}
	

	
	
	
	@Then("edit assignment and add user {string}")
	public void edittheautomatic_assignment(String first) 
	{
		User usr=new User();
		usr.pageLoad();
		 if(assign == null)
		    	assign = new Assignments();
	    assign.clickOnEditAssignmnt();
	    assign.clickAssignedLearners();
	    assign.addLearners(User.userEmail);
//	    assign.click_on_cancel();
	    assign.verifyAddStudentFirst(first);
	    assign.editAutomaticAssignment();
	   
	}

	@Then("update the assignment Button")
	public void update_the_assignment_btn() 
	{
		User usr=new User();
		usr.pageLoad();
		if(assign == null)
			assign = new Assignments();
		 assign.editAutomaticAssignmentBtn();;
	}
	
	@Then("add user {string} to assignment")
	public void edittheautomaticassignment(String first) 
	{
		User usr=new User();
		usr.pageLoad();
		 if(assign == null)
		    	assign = new Assignments();
	    assign.clickOnEditAssignmnt();
	    assign.clickAssignedLearners();
	    assign.addLearners(User.userEmail);
//	    assign.click_on_cancel();
	    assign.verifyAddStudentFirst(first);
	    assign.editAutomaticAssignmentBtn();
	   
	}
	@Then("add user from diffrent level to assignment")
	public void edittheautomatassignment() 
	{
		User usr=new User();
		usr.pageLoad();
		 if(assign == null)
		    	assign = new Assignments();
	    assign.clickOnEditAssignmnt();
//	    assign.addStudent();
	    
	    assign.clickAssignedLearners();
	    assign.addLearners();
//	    assign.click_on_cancel();
	
	     
	}
	@Then("validate if warning is display")
	public void validate_warning() 
	{
		User usr=new User();
		usr.pageLoad();
	    assign.validatewarning();
	}
	@Then("user create multiple groups {int}")
	public void user_create_multiple_groups(int count) 
	{
		User usr=new User();
		usr.pageLoad();
	    orgSet = new OrganizationSettings();
	    orgSet.createMultipleGroups(count);
	}
	
	@Then("Group Button should not be available")
	public void user_create_multiple_groups() 
	{
		User usr=new User();
		usr.pageLoad();
	    orgSet = new OrganizationSettings();
	    orgSet.crateMultipleGroups();
	}
	@Then("add the automatic assignment with same multiple criteria {string} {int}")
	public void add_the_automatic_assignment_with_same_multiple_criteria(String name, int count) 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.selectAutomatic();
	    assign.assignmentFromUser();
	    assign.Click_on_nextSection();
		
	    assign.selectMultipleCriteria(name, count);
	}

	@Then("count the rows without update while creating {int}")
	public void count_the_rows_without_update_while_creating(int count) 
	{
		User usr=new User();
		usr.pageLoad();
	    assign.countUserRowsWithoutUpdateCreate(count);
	}
	
	@Then("verify the assignment student count {int}")
	public void verify_the_assignment_student_count(int count) 
	{
		User usr=new User();
		usr.pageLoad();
	    assign.getStudentCount(count);
	}
	
	@Then("add the automatic assignment with different multiple criteria {string}")
	public void add_the_automatic_assignment_with_different_multiple_criteria_group_count(String criterias) 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.selectAutomatic();
	    assign.assignmentFromUser();
	    assign.Click_on_nextSection();
		
		assign.selectDifferentMultipleCriteria(criterias);
	}
	
	@Then("add the automatic assignment with different multiple criteria is not {string}")
	public void add_the_automatic_assignment_with_differentmultiple_criteria_group_count(String criterias) 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.selectAutomatic();
	    assign.assignmentFromUser();
	    assign.Click_on_nextSection();
		
		assign.selectDifferentMultipleCriteiaisnot(criterias);
	}
	
	
	
	
	

	@Then("add the automatic assignment for job title")
	public void add_the_automatic_assignment_with_job_title() 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.selectAutomatic();
	    assign.assignmentFromUser();
	    assign.Click_on_nextSection();
		
		assign.selectjobtitle();
	}
	@Then("add the manual assignment with criteria {string}")
	public void add_the_manual_assignment_with_org_criteria(String name) 
	{
		User usr=new User();
		usr.pageLoad();
		assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.assignmentFromUser();
	    assign.Click_on_nextSection();
		
	    assign.selectCriteria(name);
	}

	@Then("add the manual assignment with different user {string} {int}")
	public void add_the_manual_assignment_with_different_user(String first, int count) 
	{
		User usr=new User();
		usr.pageLoad();
		if(assign == null)
			assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.assignmentFromUser();
	    assign.Click_on_nextSection();
		
	    assign.addLearners(first,count);
//	    assign.click_on_cancel();
		
	    assign.verifyAddStudentFirst(first+"_"+count);
	    assign.createAssignment();
	}
	
	@Then("assign all manual products {string} as assignment to the user {string}")
	public void assign_all_manual_products_as_assignment_to_the_user(String names, String first) 
	{
		User usr=new User();
		usr.pageLoad();
		if(assign == null)
			assign = new Assignments();
		String course[] = names.split(",");
		for(int i = 0; i <= course.length-1; i++)
		{
	    assign.clickOnCreateAssignment();
	    assign.assignmentFromUser(course[i]);
	    assign.Click_on_nextSection();
		
	    assign.addLearners(User.userEmail);
//	    assign.click_on_cancel();
		
	    assign.verifyAddStudentFirst(first);
	    assign.createAssignment();
		TestBase. dataMap.put(course[i]+"Assignment",assign. AssgnmentName);
		
		}
	}
	
	@Then("delete the assignment")
	public void delete_the_assignment() 
	{
		User usr=new User();
		usr.pageLoad();
		if(assign == null)
			assign = new Assignments();
		assign.assignmentActiondetails();
	    assign.deleteAssignment();
	}

	@Then("Create assignment")
	public void Create_assignment() 
	{
		User usr=new User();
		usr.pageLoad();
		if(assign == null)
			assign = new Assignments();
		 assign.clickOnCreateAssignment();
		    
	}
	@Then("Create assignment for {string}")
	public void Create_assignment(String course) 
	{
		User usr=new User();
		usr.pageLoad();
		if(assign == null)
			assign = new Assignments();
		assign.clickOnCreateAssignment();
		  assign.assignmentFromUser(course);
		      
	}


	@Then("add the automatic assignment with {int} different user {string} and same product")
	public void add_the_automatic_assignment_with_different_user_and_same_product(Integer count, String first) 
	{
		User usr=new User();
		usr.pageLoad();
		if(assign == null)
			assign = new Assignments();

		for(int i = 1; i <= count; i++)
		{
			assign.clickOnCreateAssignment();
		    assign.assignmentFromUser();
		    assign.Click_on_nextSection();
		    assign.addLearners(first,i);
//			 assign.click_on_cancel();
				
		    assign.verifyAddStudentFirst(first+i);
		    assign.createAssignment();
		}
	    
	}
	
	@Then("add the automatic assignment with {int} different user {string} and same product {string}")
	public void add_the_automatic_assignment_with_different_user_and_same_product(Integer count, String first, String course) 
	{    
		User usr=new User();
		usr.pageLoad();
		if(assign == null)
			assign = new Assignments();
		for(int i = 1; i <= count; i++)
		{
			assign.clickOnCreateAssignment();
		    assign.assignmentFromUserSpecificCourse(course);
		    assign.Click_on_nextSection();
		
		    assign.addLearners(first,i);
//			 assign.click_on_cancel();

		    assign.verifyAddStudentFirst(first+i);
		    assign.createAssignment();
		}
	    
	}

	@Then("delete the multi assignment {int}")
	public void delete_the_multi_assignment(int count) 
	{
		User usr=new User();
		usr.pageLoad();
		if(assign == null)
			assign = new Assignments();
		if(org == null)
			org = new OrganizationHome();
		for(int i = 1; i <= count; i++)
		{
			assign.assignmentActiondetails();
		    assign.deleteAssignment();
		}
		
	}
	
	@Then("Delete the assignment if available")
	public void Delete_the_assignment_if_available()
	{
		User usr=new User();
		usr.pageLoad();
		if(assign == null)
			assign = new Assignments();
		if(org == null)
			org = new OrganizationHome();
		int count = assign.rowsAvailable();
		System.out.println("Rows avaialble on assignment page " + count);
		if(count >= 1)
		{
			assign.assignmentActiondetails();
			for(int i = 0; i <= count-1; i++)
			{
				try
				{
					Thread.sleep(3000);
				}
				catch(Exception e)
				{
				assign.deleteAssignment();
				}
			}
		}
		
	}
	
//	++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	
	@Then("add manual assignments with course name {string} with user name {string}")
	public void add_manual_assignments_with_course_name_with_user_name(String courseName, String first) throws Exception 
	{
		if(assign == null)
			assign = new Assignments();
			 assign.clickOnCreateAssignment();
			 assign.assignmentFromUserSpecificCourse(courseName);
			 assign.Click_on_nextSection();
				
			 assign.addLearners(User.userEmail);
//			 assign.click_on_cancel();
				
			 assign.verifyAddStudentFirst(first);
	}
	
	@Then("add manual assignments with course name {string} with user name {string} and assignment")
	public void add_manual_assignments_with_course_name_with_assign_name_and_assignment(String courseName, String first) throws Exception 
	{
		if(assign == null)
			assign = new Assignments();
			 assign.clickOnCreateAssignment();
			 //assign.assignmentFromUserSpecificCourse(TestBase.courseProp.getProperty(courseName));
			 assign.assignmentFromUserSpecificCourseWithAssignName(courseName);
			 //assign.addStudentToList(first);
	}
	
	
	
	
	
	@Then("create the assignment and validate the message {string}")
	public void create_the_assignment_and_validate_the_message(String message) throws Exception {
		assign = new Assignments();
		//assign.createAutoAssignment();
		assign.clickOnCreateAssignment();
		assign.validateExistsAssignmentTitleMessage(message);
	}
	
	@Then("user navigate to view assignment page and validate")
	public void user_navigate_to_view_assignment_page_and_validate() {
		assign = new Assignments();
		assign.assignmentActiondetails();
		assign.clickViewAssignmentOption();
		assign.clickAssignedLearners();
	}
	
	@Then("user navigate to view assignment page and validate of course {string}")
	public void user_navigate_to_view_assignment_page_and_validae(String course) {
		assign = new Assignments();
		assign.assignmentActiondetails(course);
		assign.clickViewAssignmentOption(course);
		assign.clickAssignedLearners();
	}
	@Then("validate the header in assignment view screen {string}")
	public void user_navigate_to_view_assignment_page_and_validate(String header) {
		assign = new Assignments();
		assign.validateHeader(header);
	
		
	}
	@Then("validate not header in assignment view screen {string}")
	public void user_navigateto_view_assignment_page_and_validate(String header) {
		assign = new Assignments();
		assign.validatenotHeader(header);
	
		
	}
	
	
	@Then("validate the label in assignment view screen {string}")
	public void user_label_assignment_page_and_validate(String label) {
		assign = new Assignments();
		assign.validateLable(label);
	
	}
	@Then("validate the data in assignment view screen {string}")
	public void user_data_assignment_page_and_validate(String data) {
		assign = new Assignments();
		assign.validatedata(data);
	
	}
	
	
	@Then("update the assignment with message {string}")
	public void update_the_assignment_with_message(String message) {
		assign = new Assignments();
		assign.removeUserAndUpdateAssignment();
		assign.validateUpdateSuccessMsg(message);
	}
	
	
	@Then("Delete all the user in edit Assignment Screen")
	public void update_the_assignment_with_messagesc() {
		assign = new Assignments();
		assign.clickCheckallButton();
		assign.clickDeleteButton();;
		 assign.editAutomaticAssignmentBtn();
		   
	}
	
	
	
	@Then("add multiple manual assignments with course name {string} with user email {string}")
	public void add_multiple_manual_assignments_with_course_name_with_user_email(String courseName, String first) 
	{
		if(assign == null)
			assign = new Assignments();
		String course[] = courseName.split(",");
		for(int i = 0; i <= course.length-1; i++)
		{
			 assign.clickOnCreateAssignment();
			 assign.assignmentFromUserSpecificCourse(course[i]);
			 assign.Click_on_nextSection();

			 assign.addLearners(User.userEmail);
//			 assign.click_on_cancel();
				
			 assign.verifyAddStudentFirst(first);
			 
			 assign.createAssignment();
		}
	}
	
	@Then("click on export and validate")
	public void click_on_export_and_validate() 
	{
		if(usr == null)
			usr = new User();
		boolean flag = usr.checkCSVFilePresent();
		int m=0;
		while(flag == true)
		{
			usr.deleteFile(User.filePath);
			flag = usr.checkCSVFilePresent();
			if(m==80)
				break;
			m++;
		}			
		assign.clickExportButton();
		assign.verifyDownloadFile();
//		assign.validateDetails();
	}
	@Then("click on export Automatic User and validate")
	public void click_on_eport_and_validate() 
	{
		if(usr == null)
			usr = new User();
		boolean flag = usr.checkCSVFilePresent();
		int m=0;
		while(flag == true)
		{
			usr.deleteFile(User.filePath);
			flag = usr.checkCSVFilePresent();
			if(m==80)
				break;
			m++;
		}			
		assign.clickExportAutoButton();
		assign.verifyDownloadFile();
//		assign.validateDetails();
	}
	
	
	
	@Then("user verifies Manual and Automatic courses with default radio buttons")
	public void user_verifies_Manual_and_Automatic_courses_with_default_radio_buttons()
	{
		assign = new Assignments();
		assign.ManualAutoCourse();
	}
	@Then("add the manual assignment with inactive user") 
	public void add_the_manual_assignment_with_inactive_user()
	{
		User usr=new User();
		usr.pageLoad();
		if(assign == null)
			assign = new Assignments();
	    assign.clickOnCreateAssignment();
	    assign.assignmentFromUser();
	    assign.Click_on_nextSection();
	    assign.addLearners();
//		 assign.click_on_cancel();
	
	}
	@Then("User validates the Assignment success message") 
	public void User_validates_the_Assignment_success_message()
	{
		assign.AssignmentSuccess();
	}
	
	@Then("validate the user on Assignment screen") 
	public void validate_the_user_on_Assignment_screen()
	{
		assign.AssignTitle();
	}
	//Added by Mohan.R 07-Nov-22
	
	
			@And("User clicks on CreateAssignment Button")
			public void User_clicks_on_CreateAssignment_Button()
			{
				assign = new Assignments();
				assign.clickOnCreateAssignment();
			}
			
			@And("User selects the Automatic Radio Button") 
			public void User_selects_the_Automatic_Radio_Button()
			{
				assign = new Assignments();
				assign.selectAutomatic();
			}
			
			@ And("User selects the Course from the dropdown") 
			public void User_selects_the_Course_from_the_dropdown()
			{
				assign = new Assignments();
				assign.Course();
			}
			
			@And("User enters the Assignment Description") 
			public void User_enters_the_Assignment_Description()
			{
				assign = new Assignments();
				assign.AssignDesc();
			}
			
			@And("User selects the DueDate as RelativeDate Radio Button") 
			public void User_selects_the_DueDate_as_RelativeDate_Radio_Button()
			{
				assign = new Assignments();
				assign.RelativeDate();
			}
			
			@And("User selects the CriteriaZero from the dropdown") 
			public void User_selects_the_CriteriaZero_from_the_dropdown()
			{
				assign = new Assignments();
				assign.CriteriaZero();
			}
			
			@And("User selects the CriteriaOne from the dropdown") 
			public void User_selects_the_CriteriaOne_from_the_dropdown()
			{
				assign = new Assignments();
				assign.Criteriaone();
			}
			
			@And("User selects the CriteriaTwo from the dropdown") 
			public void User_selects_the_CriteriaTwo_from_the_dropdown()
			{
				assign = new Assignments();
				assign.Criteriatwo();
			}
			
			
			
			@And("User clicks on Add Criteria Button")
			public void User_clicks_on_Add_Criteria_Button()
			{
				assign = new Assignments();
				assign.AddCriteriabtn();
			}
			
			@And("User clicks on Create Assignment Button") 
			public void User_clicks_on_Create_Assignment_Button()
			{
				assign = new Assignments();
				assign.CreateAssignBtn();
			}
			
			
			@And("Select Criteria Button {string}")
			public void User_clicks_on_AddCriteria_Button(String Criteria)
			{
				assign = new Assignments();
				 assign.Click_on_nextSection();
				 assign.selectCriteria(Criteria);
			}
			
			@And("Validated the number of user in {string} Edit or View Screen for {string} Assignment")
			public void Usr_clicks_on_AddCriteria_Button(String user,String type)
			{
				assign = new Assignments();
				 assign.validateTotalUser(type,user);
			}
			
			
			@And("Pagination Number {string} in Edit or View Screen Assignment Screen")
			public void Usr_clicks_on_AddCriteriaButton(String number)
			{
				assign = new Assignments();
				 assign.pagination(number);
			}
			
			@Then("validate the Criteria message {string}")
			public void validate_the_criteria_message(String msg) 
			{
			    assign.criteriaMsg(msg);
			}
			
			@Then("validate the Criteria message {string} in Assigned Learners")
			public void validate_the_criteria_messageAssignedLearners(String msg) 
			{
			    assign.criteriaMsgs(msg);
			}
			
			@Then("select the criteria {string} and relation {string}")
			public void select_the_criteria_as_per_name(String name,String relation) 
			{
				  assign.Click_on_nextSection();
				   String criteria[] = name.split(",");
				    for(int i = 0; i <= criteria.length - 1; i++)
				    {
				    	assign.selectCriteria(criteria[i].trim(), i,relation);
				    	assign.clickOnAddCriteria();
				    }	 
			}
			
			@Then("select the criteria {string} and multiple value {string}")
			public void select_the_criteria_as_pername(String name,String value) 
			{
				  assign.Click_on_nextSection();
				   String criteria[] = name.split(",");
				    for(int i = 0; i <= criteria.length - 1; i++)
				    {
				    	assign.selectmultiCriteria(criteria[i].trim(), i,value.split(",")[i].replace(criteria[i].trim(), ""));
				    	assign.clickOnAddCriteria();
				    }	 
			}
			
			@Then("validate the search functionality {string} for manual")
			public void validate_the_user_search_functionality( String value) 
			{
				User usr=new User();
				
				assign = new Assignments();
				 
			    assign.searchUserByDeliveryManual(value);
			}
			
			@Then("validate the Assignment Delivery Filters {string} in Assigned Learners")
			public void validate_the_user_search_functionalityAssignedLearners( String value) 
			{
				User usr=new User();
				
				assign = new Assignments();
				 
			    assign.validatetheAssignmentDeliveryFilters(value);
			    assign.clickonSearchButton();
			}
			
			@Then("select the assignment due date as Previous day {string}")
			public void select_the_assignment_due_date_asPrevious_day(String dueDate) 
			{
			    assign.selectAssignmentDueDatePrevious(dueDate);
			}
			
			@Then("check the msg {string}")
			public void add_multiple_user(String msg) 
			{
				User usr=new User();
				usr.pageLoad();
			
			   assign.errorMessage(msg);
			}
			
			@Then("check the course is limited msg {string}")
			public void add_multipleuser(String msg) 
			{
				User usr=new User();
				usr.pageLoad();
			
			   assign.courseLimitMessage(msg);
			}
			
			
			@Then("check the already course activate msg {string}")
			public void add_multipe_user(String msg) 
			{
				User usr=new User();
				usr.pageLoad();
			
			   assign.popuperrorMessage(msg);
			}
			
			@Then("Delete user {int} in Assignment")
			public void add_multiple_usr(int count) 
			{
				User usr=new User();
				usr.pageLoad();
			
			   assign.removeUser(count);
			}
			@Then("create the assignment with courseName {string} and validate the message {string}")
			public void create_the_assignment_and_validate_the_message(String courseName,String message) throws Exception {
				assign = new Assignments();
				assign.clickOnCreateAssignment();
				assign.assignmentFromUserSpecificCourseE(courseName);
				assign.editAssignmentTitleAlreadyAvailable();
//		    	assign.Click_on_nextSection();
				assign.validateExistsAssignmentTitleMessage(message);
			}
			
			@Then("validate the user details with exported file in Assignment Screen")
			public void validate_the_user_details_with_exported_file_from_user_page() 
			{
				if(usr == null)
			    	usr = new User();
				assign.getAllUserUIList();
				assign.getAllUserExcelList();
				assign.compareActivityList();
				Students std=new Students();
				  std.deleteFile(User.filePath);
			}
			
			@Then("validate the Automatic user details with exported file in Assignment Screen")
			public void validate_the_use_details_with_exported_file_from_user_page() 
			{
				if(usr == null)
			    	usr = new User();
				assign.getAllAutoUserUIList();
				assign.getAllAutoUserExcelList();
				assign.compareActivityList();
				Students std=new Students();
				  std.deleteFile(User.filePath);
			}
			
			@Then("click on delete assignment with message {string}")
			public void click_on_delete_assignment(String message) {
				assign = new Assignments();
				assign.assignmentActiondetails();
				assign.deleteAssignment();
				assign.validateDeleteSuccessMsg(message);
			}

			@Then("add multiple manual assignments with course name {string} and relative date of {int} weeks and with user email {string}")
			public void add_multiple_manual_assignments_with_course_name_and_relative_date_of_weeksand_with_user_email(String courseName, int week, String first) 
			{
				if(assign == null)
					assign = new Assignments();
				String course[] = courseName.split(",");
				for(int i = 0; i <= course.length-1; i++)
				{
					 assign.clickOnCreateAssignment();
					 assign.assignmentFromUserSpecificCourse(course[i]);
					 assign.selectRelativeDate(week);
					 assign.Click_on_nextSection();
					 assign.addLearners(User.userEmail);
//					 assign.click_on_cancel();
					 assign.verifyAddStudentFirst(first);
//					 assign.editAssignmentTitle();	
					 assign.createAssignment();
				}
			}
			@Then("get Assignment Student count")
		    public void count_the_rows()
		    {
		        assign.getStudentAssignmentCount();
		    }

			@Then("add multiple manual assignments with course name {string} with user email {string} and subscription {string}")
			public void add_multiple_manual_assignments_with_course_name_with_user_email_subscription(String courseName, String first, String plan) 
			{
				if(assign == null)
					assign = new Assignments();
				String course[] = courseName.split(",");
				for(int i = 0; i <= course.length-1; i++)
				{
					 assign.clickOnCreateAssignment();
					 assign.assignmentFromUserSpecificCourseWithSubscription(course[i],plan);
					 assign.Click_on_nextSection();
					 assign.addLearners(User.userEmail);
//					 assign.click_on_cancel();
					 assign.verifyAddStudentFirst(first);
//					 assign.editAssignmentTitle();	
					 assign.createAssignment();
				}
			}
			
			@Then("add multiple manual assignments for org pay with course name {string} with user email {string}")
			public void add_multiple_manual_assignments_for_org_pay_with_course_name_with_user_email(String courseName, String first) {
				if(assign == null)
					assign = new Assignments();
				String course[] = courseName.split(",");
				for(int i = 0; i <= course.length-1; i++)
				{
					 assign.clickOnCreateAssignment();
					 assign.createOrgPayAssignmentCourseName(course[i]);
					 assign.Click_on_nextSection();
					 assign.addLearners(User.userEmail);
//					 assign.click_on_cancel();
					 assign.verifyAddStudentFirst(first);
//					 assign.editAssignmentTitle();	
					 assign.createAssignment();
				}
			}
			
			@Then("add multiple manual assignments for Student pay with course name {string} with user email {string} and subscription {string}")
			public void add_multiple_manual_assignments_for_Student_pay_with_course_name_with_user_email(String courseName, String first, String plan) {
				if(assign == null)
					assign = new Assignments();
				String course[] = courseName.split(",");
				for(int i = 0; i <= course.length-1; i++)
				{
					 assign.clickOnCreateAssignment();
					 assign.assignmentFromUserSpecificCourses(course[i]);
					 assign.selectStudentPay();
					 assign.selectsubscriptionPlan(plan);
					 assign.Click_on_nextSection();
					 assign.addLearners(User.userEmail);
//					 assign.click_on_cancel();
					 assign.verifyAddStudentFirst(first);
//					 assign.editAssignmentTitle();	
					 assign.createAssignment();
				}
			}
			
			@Then("add multiple manual assignments for Student pay with course name {string} with user email {string}")
			public void add_multiple_manual_assignments_for_Student_pay_with_course_name_with_user_email(String courseName, String first) {
				if(assign == null)
					assign = new Assignments();
				String course[] = courseName.split(",");
				for(int i = 0; i <= course.length-1; i++)
				{
					 assign.clickOnCreateAssignment();
					 assign.assignmentFromUserSpecificCourses(course[i]);
					 assign.selectStudentPay();
					 assign.Click_on_nextSection();
					 assign.addLearners(User.userEmail);
//					 assign.click_on_cancel();
					 assign.verifyAddStudentFirst(first);
//					 assign.editAssignmentTitle();	
					 assign.createAssignment();
				}
			}
			
			
			@Then("Click on Assigned Learners")
		    public void click_on_Assigned()
		    {
		        assign.clickAssignedLearners();
		    }
		
			
			@Then("Select all User in Learners screen")
		    public void select_all_User()
		    {
		        assign.selectallUser();
		    }
			
			@Then("Click on Remove Learner Button")
		    public void Remove_Learner_Button()
		    {
		        assign.RemoveLearnerButton();
		    }
			
			

			@Then("Click on Action DropDown")
		    public void click_onAssigned()
		    {
		        assign.clickactionDropDown();
		    }

			@Then("Check if Action DropDown is disabled")
		    public void click_onAssignedisdisabled()
		    {
		        assign.clickactionDropDownisdisabled();
		    }
			@Then("Check if Unenroll Assignment is disabled")
		    public void click_onAUnenrollssigned()
		    {
		        assign.validate_if_unenroll_disable();
		    }

			@Then("Check if Unenroll Assignment is disabled for Action Button")
		    public void click_onAUnenrollssignedaCTION()
		    {
		        assign.validate_if_unenroll_disableforAction();
		    }
			
			@Then("Unenroll Assignment in Assigned Learners screen")
		    public void click_onAUnenrollssignedaCTIONscreen()
		    {
		        assign.enroll_user();
		    }	
			
			@Then("Unenroll Assignment using Action item in Assigned Learners screen")
		    public void click_onAUnenrollssisgnedaCTIONscreen()
		    {
		        assign.enroll_userAction();
		    }

			@Then("click on Unenroll Assignment in Assigned Learners screen")
		    public void click_onAUnenrollssignedaCTIOscreen()
		    {
				 assign.clickactionDropDown();
		        assign.clickonenroll_user();
		    }	
			
			@Then("click on Unenroll Assignment using Action item in Assigned Learners screen")
		    public void click_onAUnenrollssisgnedaCTIOscreen()
		    {
//				assign.clickAssignedLearners();
		        assign.clickenroll_userAction();
		    }

			

			@Then("Click on more Filter in Assigned Learner Screen")
		    public void moreFiltersButton()
		    {
		        assign.moreFiltersButton();
		    }

			@Then("Check if Admin is unable to Unenroll Assignment using Action item in Assigned Learners screen")
		    public void click_nAUnenrollssisgnedaCTIONscreen()
		    {
		        assign.enroll_userActionunableEnroll();
		    }

			
			@Then("Validate if no Student available displayed")
		    public void noStudentareAvailable()
		    {
		        assign.noStudentareAvailable();
		    }
			
			@Then("Validate if No Students are available displayed")
		    public void noStNoStudentsareavailableudentasreAvailable()
		    {
		        assign.noStudentareAvailablewhileadduser();
		    }
			
			
			@Then("Validate if No Students are available displayed in Assigned Learners")
		    public void noStNoStudentsareavailableudentasreAvailableAssignedLearners()
		    {
		        assign.noStudentareAvailableassignLearn();
		    }
			
			
			
			@Then("Validate User Record is displayed")
		    public void noStudentasreAvailable()
		    {
		        assign.recordareAvalable();
		    }
			
			@Then("add the automatic assignment with criteria {string} and multiple course name {string}")
			public void add_the_automatic_assignment_with_org_multiplecriteria(String name, String courseName) 
			{
				assign = new Assignments();
				String course[] = courseName.split(",");
				for(int i = 0; i <= course.length-1; i++)
				{
				
			    assign.clickOnCreateAssignment();
			    assign.selectAutomatic();
			    assign.assignmentFromUserSpecificCourse(course[i]);
			    	 
					assign.Click_on_nextSection();
				String criteria[] = name.split(",");
			    for(int j = 0; j <= criteria.length - 1; j++)
			    {
			    	assign.selectCriteria(criteria[j], j);
			    	assign.clickOnAddCriteria();
			    }	  
			    assign.createAssignment();
				}
			}
			
			
			@Then("add the user to the assignment {string}")
			public void add_the_user_to_the_assignment(String first) 
			{
				
			  		 
					assign.Click_on_nextSection();
					if(Admin.email == null)
					{
						if(User.userEmail != null)
						{
							assign.addLearners(User.userEmail);
//							 assign.click_on_cancel();
							
						}
						else
						{
							assign.addLearners(Students.email);
//							 assign.click_on_cancel();
							
						}	
						
					}
					else
					{
						assign.addLearners(Admin.email);
						
					
					}
				
					assign.verifyAddStudentFirst(first);
				
				
			}
			
			@Then("add user to the assignment {string}")
			public void add_the_user_to_the_assignments(String first) 
			{
				
			  		 
					assign.Click_on_nextSection();
							if(User.userEmail != null)
						{
							assign.addLearners(User.userEmail);
//							 assign.click_on_cancel();
							
						}
						else
						{
							assign.addLearners(Students.email);
//							 assign.click_on_cancel();
							
						}	
						
					
						assign.verifyAddStudentFirst(first);
				
				
			}
			
			@Then("add the user to the assignment {string} is Assigned Learners")
			public void add_the_user_to_the_assignmentAssigned(String first) 
			{
				
			  		 
					assign.clickAssignedLearners();
					if(Admin.email == null)
					{
						if(User.userEmail != null)
						{
							assign.addLearners(User.userEmail);
//							 assign.click_on_cancel();
							
						}
						else
						{
							assign.addLearners(Students.email);
//							 assign.click_on_cancel();
							
						}	
						
					}
					else
					{
						assign.addLearners(Admin.email);
						
					
					}
				
					assign.verifyAddStudentFirst(first);
				
				
			}
			
			@Then("add the created {int} user to the assignment {string} is Assigned Learners")
			public void add_the_user_o_the_assignment_is_Assigned_Learners(int user,String first) 
			{
				assign.clickAssignedLearners();
				
				for(int i=0;i<user;i++)
				{
					System.out.println(i);
					
				    assign.addLearners(first,i);
				
				}   
//				 assign.click_on_cancel();
					
				
			}
			
			@Then("add the user to the assignment {string} already Assignment user")
			public void add_the_user_to_the_assignmentss(String first) 
			{
				
			  		 
					assign.Click_on_nextSection();
					if(Admin.email == null)
					{
						if(User.userEmail != null)
						{
							assign.addLearners(User.userEmail);
//							 assign.click_on_cancel();
							
						}
						else
						{
							assign.addLearners(Students.email);
//							 assign.click_on_cancel();
							
						}	
						
					}
					else
					{
						assign.addLearners(Admin.email);
						
					
					}
				
//					assign.verifyAddStudentFirst(first);
				
				
			}
			@Then("add the user to the assignment {string} is Assigned Learners already exists user")
			public void add_the_user_to_the_assignmentAssignedalready(String first) 
			{
				
			  		 
					assign.clickAssignedLearners();
					if(Admin.email == null)
					{
						if(User.userEmail != null)
						{
							assign.addLearners(User.userEmail);
//							 assign.click_on_cancel();
							
						}
						else
						{
							assign.addLearners(Students.email);
//							 assign.click_on_cancel();
							
						}	
						
					}
					else
					{
						assign.addLearners(Admin.email);
						
					
					}
				
//					assign.verifyAddStudentFirst(first);
				
				
			}
			@Then("add the automatic assignment in assignment Screen")
			public void add_the_automatic_assignment_with_org_criteriaa() 
			{
				User usr=new User();
				usr.pageLoad();
				assign = new Assignments();
			    assign.clickOnCreateAssignment();
			    assign.selectAutomatic();
			    assign.assignmentFromUser();
//			    assign.Click_on_nextSection();
//				
//			    assign.selectCriteria(name);
			}
			

			@Then("Click on Next Button in assignment Screen")
		    public void Click_on_nextSection()
		    {
		        assign.Click_on_nextSection();
		    }
			
			@Then("Check the Assignment Details Step 1 is displayed")
			public void click_on_create_assignment_buttondisplayed() 
			{
				if(assign == null)
					assign = new Assignments();
				assign.validateStep1isdisplayed();
			}
			
			@Then("Check the Add learners Step 2 is displayed")
			public void click_on_create_assignment_buttondisplayed2() 
			{
				if(assign == null)
					assign = new Assignments();
				assign.validateStep2isdisplayed();
			}
			
			
			
			
			@Then("Validate success message is displayed {string}")
			public void Validate_success_message_is_displayed(String msg) 
			{
				
					OrganizationHome	orghome = new OrganizationHome();
					orghome .validateSucessMesssage(msg);
				
				
			}
			
			
			@Then("validate table detail in Learners listing tab")
			public void validate_table_detail_in_student_tab(DataTable table) {
			
				reuseableCode.waitforsec(4);
				for(int j=0;j<table.height();j++)
					assign.validateaLearnerslistingTable(table.column(0).get(j),table.column(1).get(j));
			
			}
			
			@Then("validate table detail in Assigned Learners tab")
			public void validate_table_detail_in_Assigned_tab(DataTable table) {
			
				reuseableCode.waitforsec(4);
				for(int j=1;j<table.height();j++)
					for(int i=0;i<table.width();i++)
					{
					assign.validateaAssignedlistingTable(table.column(i).get(0),table.column(i).get(j),j-1);
					}
			
			}
			@Then("validate if {int} row is displayed in Add Learners Screen")
			public void validate_table_detail_in_student_tab(int row) {
			
				reuseableCode.waitforsec(4);
			
					assign.validateisNoofrecords(row);
			
			}
			
			@Then("validate if {int} row is displayed in Assigned Learners Screen")
			public void validate_table_detail_in_Assigned_tab(int row) {
			
				reuseableCode.waitforsec(4);
			
					assign.validateis_Noofrecords(row);
			
			}
}
