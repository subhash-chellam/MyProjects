package stepDefinitions;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;

import com.mysql.cj.jdbc.Driver;
import com.qa.pages.Admin;
import com.qa.pages.EndUser;
import com.qa.pages.Products;
import com.qa.pages.Scrom;
import com.qa.pages.Students;

import com.qa.pages.User;
import com.qa.pages.UserManagement;
import com.qa.util.TestBase;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;

public class ScromSteps 
{
	Scrom scr= new Scrom();
	EndUser end=new EndUser();
	Products prod;
	static String parentOrg, packagePath, childOrg;
	String downloadPath = System.getProperty("user.dir") + "\\src\\test\\java\\resources";

	@Then("user navigate to scrom url")
	public void user_navigate_to_scrom_url() 
	{
	   scr = new Scrom();
	   scr.navigateToScromUrl();
	}
	@Then("switch the window to default")
	public void switch_the_window_to_default() 
	{
		if(scr == null)
			scr = new Scrom();
	    scr.switchWindowDefault();
	}
	
	@Then("close existing window")
	public void close_existing_window() 
	{
		if(scr == null)
			scr = new Scrom();
	    scr.closeexistingWindow();
	}

	@Then("Review the completed courses on scrom page")
	public void review_the_completed_courses_on_scrom_pages() 
	{
		if(scr == null)
			scr = new Scrom();
		scr.Acknowledge();
	    scr.clickOnCompletedActivities();
	    scr.clickOnCompletedCourseReview();
	    scr.onlyExitCourse();
	    scr.switchWindowDefault();
	}
	@Then("user import the package and navigate to topic page for courses per name {string}, quarter {int}")
	public void user_import_the_package_and_navigate_to_topic_page_for_courses_per_name_type_and_quarter(String courseName, int quarter) 
	{
		if(scr == null)
			scr = new Scrom();
		
		Products.filePath =System.getProperty("user.dir")+ TestBase. prop.getProperty("downloadPath") + "\\" + courseName + ".zip";
	    System.out.println(Products.filePath);
	    JavascriptExecutor jse = (JavascriptExecutor)TestBase.driver;
		  jse.executeScript("window.scrollBy(0,250)");
		
		scr.uploadPackage(Products.filePath);
		scr.clickUploadPackage();
		scr.clickOnLaunch();
		if(!courseName.contains("Vsim"))
		{
			if(Students.email == null)
	        	scr.switchWindowSelf(Scrom.email, "Ansh", "G");
	        else
	        	scr.switchWindowSelf(Students.email,Students.firstName, Students.lastName);
			end.clickOnSubmitOnlyWithDate(end.changeDate(quarter));
		}
			
	}
	
	@Then("validate the error message for course launch in scrom")
	public void validate_the_error_message_for_course_launch() 
	{
		if(end == null)
			end = new EndUser();
		scr.validateCourseLaunchError();
	}
	
	
	
	@Then("user import the package and Register as per date {int} and course name {string}")
    public void user_import_the_package_as_per_quarter_and_course_name(int date, String courseName)
    {
		Products.filePath =System.getProperty("user.dir")+ TestBase. prop.getProperty("downloadPath") + "\\" + courseName + ".zip";
		 scr.uploadPackage(Products.filePath);
        scr.clickUploadPackage();
        scr.clickOnLaunch();
        if(Students.email == null)
        	scr.switchWindowSelf("Test", "Ansh", "G");
        else
        	scr.switchWindowSelf(Students.email,Students.firstName, Students.lastName);
        String dateUpdate = end.changeDate(date);
        end.clickOnSubmitOnlyWithDate(dateUpdate);
    	int count = end.getAvailableTopicNumberscrom();
    	System.out.println(count);
    	while(count >= 1)
	    {
    		scr.	startORResumeCourse();
//	    	completeCourse();
    		scr.	completeCoursetestCode();
    		scr.   onlyExitCourse();	
    		count = end.getAvailableTopicNumberscrom();
	    }
//    	end.cecmepopup();
		    scr.switchWindowDefault();
    }
	

	@Then("user import the package and Register as per date {int} , course name {string} and accept CMECE popup")
    public void user_import_the_package_as_per_quarter_and_course_name_CMECE(int date, String courseName)
    {
		Products.filePath =System.getProperty("user.dir")+ TestBase. prop.getProperty("downloadPath") + "\\" + courseName + ".zip";
		 scr.uploadPackage(Products.filePath);
        scr.clickUploadPackage();
        scr.clickOnLaunch();
        if(Students.email == null)
        	scr.switchWindowSelf("Test", "Ansh", "G");
        else
        	scr.switchWindowSelf(Students.email,Students.firstName, Students.lastName);
        String dateUpdate = end.changeDate(date);
        end.clickOnSubmitOnlyWithDate(dateUpdate);
    	int count = end.getAvailableTopicNumberscrom();
    	System.out.println(count);
    	while(count >= 1)
	    {
    		scr.	startORResumeCourse();
//	    	completeCourse();
    		scr.	completeCoursetestCode();
    		scr.   onlyExitCourse();	
    		count = end.getAvailableTopicNumberscrom();
	    }
    	end.cecmepopup();
		    scr.switchWindowDefault();
    }
	
	@Then("register the end user")
	public void register_the_end_user() 
	{
		if(!TestBase.driver.getCurrentUrl().contains("sc/guest/SignInForm"))
		scr.logout_without_quit();
		 scr.navigateToScromUrl();
	    scr.clickSignUpLink();
	    scr.enterUserDetails(Students.email, Students.firstName, Students.lastName);
	    scr.clickSignIn();
	}
	@Then("user import and launch the package as per name {string}, type {string} and quarter {int}")
	public void user_import_and_launch_the_package_as_per_name_type_and_quarter(String packageName, String packageType, int quarter) 
	{
		Products.filePath = downloadPath + "\\" + packageName + ".zip";
		System.out.println(Products.filePath);
		scr.uploadPackage(Products.filePath);
		scr.clickUploadPackage();
		scr.clickOnLaunch();
		if(packageType.equalsIgnoreCase("elearning"))
	    {
	    	scr.switchWindowElearningOnlyStart(quarter);
	    }	    	
	    else if(packageType.equalsIgnoreCase("bhf") || packageType.equalsIgnoreCase("responder") || packageType.equalsIgnoreCase("bls provider") || packageType.equalsIgnoreCase("bls entry"))
	    {
	    	scr.switchWindowNoEmailAsPerQuarterOnlyStart(quarter);
	    }
	}
	@Then("open the tab")
	public void open_the_tab() 
	{
	   
		scr.openTab();
	}
	
	@Then("register the end user with already added user")
	public void register_the_end_user_with_already_added_user() 
	{
		if(!scr.prop.getProperty("scromUrl"+scr.prop.getProperty("environment")).contains(TestBase.driver.getCurrentUrl()))
		{
		scr.logout_without_quit();
		}
		 scr.navigateToScromUrl();
	    scr.clickSignUpLink();
	    if(Admin.email == null) 
	    {
	    	if(User.userEmail != null)
			{
				scr.enterUserDetails(User.userEmail, "Ansh", "G");
			}
			else
			{
				scr.enterUserDetails(Students.email, Students.firstName, Students.lastName);
			}	
	    }
	    	
	    else
	    	scr.enterUserDetails(Admin.email, "Ansh", "G");
	    scr.clickSignIn();
	}
	@Then("user import the package only as per course name {string}")
	public void user_import_the_package_only_as_per_course_name(String courseName) 
	{
//		Products.filePath = downloadPath + "\\" + TestBase.courseListName.get(courseName) + ".zip";
		end = new EndUser();
        scr.uploadPackage(Products.filePath);
        scr.clickUploadPackage();
	}
	
	@Then("validate the error message for self registration disabled")
	public void validate_the_error_message_for_self_registration_disabled() 
	{
		scr.switchMidWindow();
	    scr.validateSelfRegisterMessage();
	}

	@Then("register the end user {string} {string}")
	public void register_the_end_user(String first,String lastname) 
	{
		scr.logout_without_quit();
		 scr.navigateToScromUrl();
	    scr.clickSignUpLink();
	    
	    DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		Students.email=User.getUserEmail(lastname+formattedEmail).replace(":", "").replace("-", "").replace(" ", "");
		Students.email= Students.email.replace("inbox.mailtrap.io", dateFormat.format(cal.getTime()).replace(":", "").replace("-", "").replace(" ", "")+".com");
		Students.firstName=first;
		Students.lastName=lastname;
		User.userEmail=Students.email;
		Scrom.email=email;
		System.out.println(User.userEmail);
	    scr.enterUserDetails(Students.email, Students.firstName, Students.lastName);
	    scr.clickSignIn();
	}
	@Then("user import the package and Register as per date {int}")
    public void user_import_the_package_as_per_quarter(int date)
    {
		//Products.filePath = downloadPath + "\\" + TestBase.courseProp.getProperty(courseName) + ".zip";
		end = new EndUser();
        scr.uploadPackage(Products.filePath);
        scr.clickUploadPackage();
        scr.clickOnLaunch();
        if(Students.email == Scrom.email)
        	scr.switchWindowSelf(Scrom.email, "Ansh", "G");
        else
        	scr.switchWindowSelf(Students.email,Students.firstName, Students.lastName);
        String dateUpdate = end.changeDate(date);
        end.clickOnSubmitOnlyWithDate(dateUpdate);
    	int count = end.getAvailableTopicNumberscrom();
    	while(count >= 1)
	    {
	    	end.startORResumeCourse();
	    	end.completeCourseTestCode();
	    	end.onlyExitCourse();
		    count = end.getAvailableTopicNumber();
	    }
        scr.switchWindowDefault();
    }
	@Then("user import the package and Register as per date {int} and launch course name {string}")
    public void user_import_the_package_as_per_quarter_and_launch_course_name(int date, String courseName)
    {
//		if(courseListName.containsKey( courseName+"Option"))
//			courseName=courseListName.get( courseName+"Option").toString();

//		Products.filePath = downloadPath + "\\" + TestBase.courseListName.get(courseName) + ".zip";
		end = new EndUser();
        scr.uploadPackage(Products.filePath);
        scr.clickUploadPackage();
        scr.clickOnLaunch();
        if(Students.email == Scrom.email)
        	scr.switchWindowSelf(Scrom.email, "Ansh", "G");
        else
        	scr.switchWindowSelf(Students.email,Students.firstName, Students.lastName);
        String dateUpdate = end.changeDate(date);
        end.clickOnSubmitOnlyWithDate(dateUpdate);
    	int count = end.getAvailableTopicNumberscrom();
    	if(count >= 1)
	    {
	    	end.startORResumeCourse();
	    	end.onlyExitCourse();
	    }
        scr.switchWindowDefault();
        try
        {
        Thread.sleep(5000);	
        }
        catch(Exception e)
        {
        	
        }
    }
	@Then("user login in scrom")
	public void use_login_for_scrom() 
	{
	    scr.enterUserDetail();
	  
	}
	
	@Then("user import the package with one topic left")
	public void user_mport_the_packagewith_one_topic_left() 
	{
		
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
		scr.complecourseoneTopic();
		
	}
	@Then("user import the package {string} with one topic left")
	public void user_mport_the_packagewith_one_topic_left(String date) 
	{
		
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
		scr.complecourseoneTopic(date);
		
	}
	
	@Then("user import the package and only launch")
	public void user_mport_the_packagewith_launch() 
	{
		
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
		scr.onlylaunch();
		
	}
	@Then("user import the package only")
	public void user_mport_the_packageonly() 
	{
		
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	   
		
	}
	@Then("user import the package {string} and only launch")
	public void user_import_the_packagewith_launch(String date) 
	{
		
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
		scr.onlylaunch(date);
		
	}
	@Then("user import the package {int} and only launch")
	public void user_import_the_packagewith_launch(int q) 
	{
		
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    String date=end.changeDate(q);
		scr.onlylaunch(date);
		
	}
	@Then("user import the package")
	public void user_import_the_package() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindow(Students.email);
	  
	}
	
	
	
	@Then("user import the package and validate the message {string}")
	public void user_import_thepackage(String msg) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchMessage(msg);
	  
	}
	
	@Then("user import the package {string} and validate the message {string}")
	public void user_import_thepackage(String course,String msg) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowandCompletePaymentAsCard(course,msg);
	  
	}
	
	@Then("user Resume Course in Scrom {string} and validate the message {string}")
	public void userimport_the_package(String course,String msg) throws InterruptedException 
	{
		prod = new Products();
	    scr.clickonHome();
	    scr.clickOnCourseLaunch(course);
	    scr.clickOnLaunch();
	    scr.switchMessage(msg);
	    
	}
//	@Then("Complete Claim CME in scrom")
//	public void Complete_Claim_CME() 
//	{
//		
//		scr.claimCredit();
//	
//	    
//	}
	@Then("review the given course {string}")
	public void review_the_given_course(String course) throws InterruptedException 
	{
		prod = new Products();
	    scr.clickonHome();
	    scr.clickOnCourseLaunch(course);
	    scr.clickOnLaunch();
	    scr.switchWindowithoutExitng(Students.email);
		
	}
	
	@Then("user import the package and without exiting")
	public void user_import_the_package_without() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowithoutExiting(Students.email);
	  
	}
	@Then("user import the package closing directly")
	public void user_import_the_package_directly() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowdireclty();
	  
	}
	
	@Then("user import the package quarter {string} and without exiting")
	public void user_import_the_package_without(String i) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowithoutExiting(Students.email,i);
	  
	}
	
	
	@Then("Exiting from Scrom Screen")
	public void exiting_from_scrom_screen() 
	{
		prod = new Products();
	    scr.exitButton();
	   
	}

	@Then("user import the package and upload Package")
	public void user_import_the_package_uploadPackage() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    
	   
	}

	@Then("user Resume Course in Scrom {string}")
	public void userimport_the_package(String course) throws InterruptedException 
	{
		prod = new Products();
	    scr.clickonHome();
	    scr.clickOnCourseLaunch(course);
	    scr.clickOnLaunch();
	    scr.switchWindowResume(Students.email);
	    
	}
	@Then("Reset Course in Scrom {string}")
	public void reset_course_in_scrom(String course) throws InterruptedException 
	{
		prod = new Products();
	    scr.clickonHome();
	    scr.clickOnCourseLaunch(course);
	    scr.clickOnResetProgress();
	    
	}
	
	@Then("user Resume Course {string} in Scrom")
	public void userimport_thepackage(String course) throws InterruptedException 
	{
		prod = new Products();
	    scr.clickonHome();
	    scr.clickOnCourseLaunch(course);
	    scr.clickOnLaunch();
	    scr.changefouse(0);
	    
	}
	

	@Then("user import the package quater")
	public void user_import_the_packag() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindow(Students.email);
	}
	@Then("user import the package quarter {int} based on topic")
	public void user_import_the_package_based_on_topic(int i) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowquater(Students.email,i);
	}
	@Then("user import the package quarter {int}")
	public void user_import_the_package(int i) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindow(Students.email,i);
	}
	
	
	@Then("user import the package quarter {int} validate version is each screen {string}")
	public void user_import_the_packageversion(int i,String version) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindow(i,version);
	}
	
	
	@Then("validate scrom Status {string}")
	public void validate_scrom_Status(String status) 
	{
		prod = new Products();
	   
	    scr.validateStatus(status);
	}
	@Then("user import and validate console Log {string}")
	public void user_import_the_package_and_validate_console_log(String log) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowandvalidatelog(log);
	}
	
	@Then("user import the package quarter {int} check if the topic are not displayed")
	public void user_importthe_package(int i) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.checkiftopicnotlocked(Students.email,i);
	}
	
	@Then("user import the package quarter {int} validate message {string}")
	public void user_importthe_package(int i,String msg) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.validateMsg(msg,i);
	}
	
	@Then("re-launch package quarter {int}")
	public void re_launch_the_package(int i) 
	{
		prod = new Products();
	    scr.clickOnLaunch();
	    scr.switchWindow(Students.email,i);
	}
	
	@Then("user import the package quarter {int} with one topic left")
	public void user_mport_the_packagewith_one_topic_left(int i) 
	{
		
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
		scr.complecourseoneTopic(i);
		
	}
	
	@Then("Review the course in scrom for quarter {int}")
	public void user_mport_thepackagewith_one_topic_left(int i) 
	{
		
		prod = new Products();
	    scr.clickOnLaunch();
//		scr.complecourseoneTopic(i);
		scr.changefouse(i)
		;
		
	}
	
	
	
	@Then("Review the course in scrom for quarter {int} and")
	public void user_mport_thepackagewith_one_topic_left2(int i) 
	{
		
		prod = new Products();
	    scr.clickOnLaunch();
//		scr.complecourseoneTopic(i);
		scr.changefouse(i)
		;
		scr.Acknowledge();
		
	}
	
	@Then("Review the course {string} in scrom for quarter {int}")
	public void user_mport_thepackagewith_one_topic_left(String course,int i)  throws InterruptedException 
	{
		
		prod = new Products();
		 scr.clickonHome();
		  scr.clickOnCourseLaunch(course);
		    scr.clickOnLaunch();
//		scr.complecourseoneTopic(i);
		scr.changefouse(i)
		;
		
	}
	
	
	@Then("Review the course in scrom")
	public void user_mport_thepackagewith_one_topic_left() 
	{
		
		prod = new Products();
	    scr.clickOnLaunch();
//		scr.complecourseoneTopic(i);
		scr.changefouse();
		scr.Acknowledge();
		;
		
	}
	
	@Then("Validate the message {string} and check if topic are in review status")
	public void validate_the_message_andcheck_iftopicareinreviewstatus(String msg) 
	
	{
		
		prod = new Products();
		scr.validatemessage(msg);
		scr.validatereviewButton();
		scr.closeTab();
//	    scr.clickOnLaunch();
//		scr.complecourseoneTopic(i);
//		scr.changefouse(i)
		;
		
	}
	
	@Then("check if topic are in review status")
	public void validate_tiftopicareinreviewstatus() 
	
	{
		
		prod = new Products();
	
		scr.validatereviewButton();
		scr.closeTab();
//	    scr.clickOnLaunch();
//		scr.complecourseoneTopic(i);
//		scr.changefouse(i)
		;
		
	}
	
	@Then("Fetch the topic list for {string} course")
	public void validate_tiftopicareinreviewstatus(String course) 
	
	{
		
		prod = new Products();
	
		scr.validatereviewButton(course);
		scr.closeTab();
//	    scr.clickOnLaunch();
//		scr.complecourseoneTopic(i);
//		scr.changefouse(i)
		;
		
	}
	
	
	
	@Then("check if topic are not in review status")
	public void validate_tifopicareinreviewstatus() 
	
	{
		
		prod = new Products();
	
		scr.validateNotreviewButton();
		scr.closeTab();
//	    scr.clickOnLaunch();
//		scr.complecourseoneTopic(i);
//		scr.changefouse(i)
		;
		
	}
	@Then("Validate Message {string} in scrom when Evaluation is not completed and trying to Claim CME CE")
	public void Complete_Claim_CME(String msg) 
	{
		
		scr.validatemsgClaimCME(msg);
			   
	    
	}
	
	@Then("Validate ecard in scrom for {string}")
	public void user_mport_thepackagewith_one_topic_left(String course) 
	{
		
		prod = new Products();

	    scr.viewEcardandvalidate(course);
		;
		
	}
	
	@Then("Validate ecard button is disabled in scrom")
	public void user_mport_thepackagdisabledewith_one_topic_left() 
	{
		
		prod = new Products();

	    scr.viewEcardandvalidatedisabled();
		;
		
	}
	@Then("Validate ecard and Certificate in scrom for {string}")
	public void user_Certificate_one_topic_left(String course) 
	{
		
		prod = new Products();

	    scr.viewCertificateandvalidate(course);
	    scr.viewEcardandvalidate(course);
		
		;
		
	}
	
	@Then("Validate Certificate in scrom for {string}")
	public void userCertificate_one_topic_left(String course) 
	{
		
		prod = new Products();

	    scr.viewCertificatevalidate(course);
	    
		;
		
	}
	
	@Then("Evaluate in scrom")
	public void evaluate() 
	{
		
		scr.evaluateCourse();
		scr.clickOnSubmit();

	    
	}
	
	@Then("Complete Claim CME in Scrom")
	public void Complete_Claim_CME() 
	{
		scr.clickOnSubmit();
		scr.claimCredit();
			
	    
	}
	@Then("Complete Claim CME Provider in Scrom")
	public void Complete_Claim_CME_pr() 
	{
		scr.clickOnSubmit();
		scr.claimCreditProvider();
			
	    
	}
	@Then("re-launch package quarter {int} with one topic left")
	public void re_launch_the_packageone(int i) 
	{
		prod = new Products();
	    scr.clickOnLaunch();
		scr.complecourseoneTopic(i);
		
	}
	@Then("user import the package quarter {int} Complete Course")
	public void userimport_the_package(int i) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindw(Students.email,i);
	}
	
	@Then("user import the package, complete the Payment and {int} Complete Course")
	public void userimport_the_package_and_complete_the_Payment(int i) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowandCompletePayment(Students.email,i);
	}
	
	
	@Then("user Resume Course in Scrom {string} and {int} Complete Course")
	public void userimport_the_package(String course,int i) throws InterruptedException 
	{
		prod = new Products();
	    scr.clickonHome();
	    scr.clickOnCourseLaunch(course);
	    scr.clickOnLaunch();
	    scr.switchWindw(Students.email,i);
//	    scr.switchWindowandCompletePayment(Students.email,i);
	    
	}
	@Then("user import the package, complete the Payment and Download Recipt")
	public void userimport_the_package_and_complete_the_Payment() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowandCompletePaymentandDownloadRecipt(Students.email);
	}
	
	
	@Then("Perform Payment and Subscription")
	public void userimport_the_package_and_complete_thperformPaymentAndSubscribee_Payment() 
	{
		prod = new Products();
		if(end == null)
			end = new EndUser();
		end.performPaymentAndSubscribe();
	}
	
	@Then("Perform Payment and Subscription with different email")
	public void userimport_the_package_and_complete_differentthperformPaymentAndSubscribee_Payment() 
	{
		prod = new Products();
		if(end == null)
			end = new EndUser();
		end.performPaymentAndSubscribe(end.secondaryEmail);
	}
	
	@Then("user import the package, complete the Payment and view Order Details")
	public void userimport_the_package_and_complete_the_Payment_view_Order_Details(DataTable table) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowandCompletePaymentandViewOrder(Students.email,table);
	}
	@Then("launch the course and Fetch the below Details in View Order Details")
	@Then("launch the course and view Order Details")
	public void lau_the_course_and_view_order_details(DataTable table) 
	{
		prod = new Products();
	    scr.clickOnLaunch();
	    scr.switchWindowandViewOrder(Students.email,table);
	}
	
	
	@Then("launch the course {string} and Fetch the below Details in View Order Details")
	public void lau_the_course_and_view_order_details(String course,DataTable table) 
	{
		prod = new Products();
	    scr.clickOnLaunch();
	    scr.switchWindowandViewOrder(Students.email,table,course);
	}
	
	
	@Then("launch the course and Download Receipt")
	public void lau_the_course_and_download_Receipt_btn() 
	{
		prod = new Products();
	    scr.clickOnLaunch();
	    scr.switchWindowandClick_Download_Receipt_Btn();
	}
	
	@Then("user import the package quarter {string} Complete Course")
	public void userimpor_the_package(String i) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindw(Students.email,i);
	}
	@Then("user import the package quarter {string} with one topic left")
	public void user_import_the_packagewith_one_topic_left(String i) 
	{
		
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.complecourseoneTopics(i);
		
	}
	
	@Then("user import the package quarter {string}")
	public void user_importthe_package(String i) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindow(Students.email,i);
	}
		
	@Then("user import the package quarter {int} close {string}")
	public void user_import_the_package(int i,String option) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowquit(Students.email,i,option);
	}
	@Then("user import the package quarter {int} and Register")
	public void user_import_the_packag(int i) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowSelf(Students.email,i);
	}
	@Then("user import the package and Register")
	public void user_import_the_ackag() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowSelf(Students.email);
	}
	@Then("user import the package and Register with one topic left")
	public void user_import_the_ckag() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowSelfone(Students.email);
	}
	@Then("user import the package and Register with optional email id")
	public void user_import_the_ackag_email() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowSelfwithoptional(Students.email);
	}
	@Then("user import the package and Register for Online")
	public void user_impor_the_ackag() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowonline(Students.email);
	}
	@Then("user import the package for Online")
	public void user_impor_theackag() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowoline(Students.email);
	}
	@Then("Should get error message Self Registration Error {string}")
	public void userimport_the_ackag(String msg) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.ValidateErrorMSg(msg);
	}
	
	@Then("user import the package {string}")
	public void user_import_the_package(String date) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindw(Students.email,date);
//	    scr.switchWindow(Students.email);
	}
	
	@Then("user import the package and exit")
	public void user_import_the_packageexit() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindows(Students.email);
	}
	
	@Then("Launch the course in Scrom url")
	public void launch_course_in_scrom_url() throws InterruptedException 
	{
		prod = new Products();
		scr.clickonCourse();
//	    scr.uploadPackage(Products.filePath);
//	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindow(Students.email);
	}
	
	@Then("Resume the course in Scrom {string}")
	public void launch_course_in_scrom_url(String course) throws InterruptedException 
	{
		prod = new Products();
		scr.clickOnCourseLaunch(course);
//	    scr.uploadPackage(Products.filePath);
//	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindow(Students.email);
	}
	
	
	@Then("user logout from scrom")
	public void user_logout_from_scrom() 
	{
		scr.logout();
	}
	@Then("user click on launch button")
	public void user_click_on_launch_button() {
		if(scr == null)
			scr = new Scrom();
		scr.clickOnLaunch();
	}

	@Then("user logout from scrom without quit")
	public void user_logout_from_application_without_quit() 
	{
		scr.logout_without_quit();
	}
	
	@Then("user delete the package")
	public void user_delete_the_package() 
	{
	    scr.deletePackage(Products.filePath);
	}
	
	@Then("user import the package without test date")
	public void user_import_the_packagewithout() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowwithout(Students.email);
	}

	@Then("get details of parent org")
	public void get_details_of_parent_org() 
	{
		parentOrg =TestBase.prop.getProperty("orgName");
	    packagePath = Products.filePath;
	}
	
	@Then("get details of child org")
	public void get_details_of_child_org() 
	{
	    childOrg = OrganizationSteps.name;
	}
	
	@Then("navigate to rqip url")
	public void navigate_to_rqip_url() 
	{
		scr.navigateToRQIPUrl();
	}
	@Then("get the topic list")
	public void get_the_topic_list() {
		if(scr == null)
			scr = new Scrom();
	    scr.getNumberRowsscr();
	}
	
	
	@Then("launch the topic and close the course window")
	public void launch_the_topic_and_close_the_course_window() {
		
		scr.startORResumeCourse();
		scr.onlyExitCourse();
    	scr.switchWindowDefault();
	}
	
	@Then("user import the package and validate consent notice")
	public void user_import_thepackage() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowConsentnotice(Students.email);
	  
	}
	
	@Then("user import the package Register and validate consent notice")
	public void user_import_the_package_Consent() 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowConsentnoticeSelf(Students.email);
	}
	
	
	@Then("user import the package validate version is each screen {string}")
	public void user_import_the_pckage(String version) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowVersion(version);
	  
	}
	


	@Then("user import the package validate the message {string}")
	public void user_importthepackage(String msg) 
	{
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchMessages(msg);
	  
	}
	@Then("switch the tab to Topics Screen")
	public void switch_the_tab_to_topics() 
	{
		scr.switchWindowCourseTopic();
	   
	}
	
	@Then("switch the tab to Payment Screen")
	public void switch_the_tab_to_PaymentScreen() 
	{
		scr.switchWindowPayment();
	   
	}
	
	
	@Then("Enter the Payment Details in Scrom")
	public void enter_the_payment_details_in_scrom() 
	{
		end = new EndUser();
		
		 end.performEnterPaymentDetailsOnly();
	   
	}
	

	@Then("validate Billing Details in Payment Screen in Scrom")
	public void enter_the_payment_details_in_scrom(DataTable table) 
	{
		if(end == null)
		end = new EndUser();
		for(int j=0;j<table.height();j++)
		 end.validatePaymentScreen(table.column(0).get(j),table.column(1).get(j));
	   
	}

	
	@Then("Click on Return To Merchant in Scrom")
	public void click_returnToMerchant() 
	{
		if(end == null)
			end = new EndUser();
	    end.click_returnToMerchant();
	    
	}
	
	@Then("Click on Payment Button in Scrom")
	public void click_PayNowBtn() 
	{
		if(end == null)
			end = new EndUser();
	    end.click_PayNowBtn();
	    
	}


	
	@Then("Enter Email ID and Click on Pay Now")
	public void click_onPayNow() 
	{
		if(end == null)
			end = new EndUser();
	    end.click_and_EnterEmail_payNowBtn();
	    
	}
	
	@Then("Validate Billing Address in payment Screen")
	public void validate_billing_address_in_paymentScreen() 
	{
		if(end == null)
			end = new EndUser();
	    end.click_and_EnterEmail_payNowBtn();
	    
	}
	
	@Then("Click on Order Receipt Button in Scrom")
	public void click_OrderPayNowBtn() 
	{
		
	    scr.click_order_ReceiptBtn();;
		Boolean flag=	Products.isFileDownloaded_Ext (Products.downloadPath , ".pdf");

	    Assert.assertTrue(flag,"Error Order Receipt not found");;
	    
	}

	

	@Then("Validate Order Summary contains Price break-up of the course in Scrom")
	public void validate_order_summary_contains_price_break_up_of_the_course(DataTable table) 
	{
		if(end == null)
			end = new EndUser();
		 for(int j=0;j<table.height();j++)
			 end.validate_order_summary(table.column(0).get(j),table.column(1).get(j));

	  
	    
	}
	
	
	@Then("user import the package as per name {string} and complete the Payment and view Order Details with date {int} {string}")
	public void userimport_the_package_as_per_name_andand_complete_the_Payment_view_Order_Details(String courseName,int dayCount, String dateType) 
	{
		Products.filePath = downloadPath + "\\" + courseName + ".zip";
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowandCompletePaymentandViewCancelRefundSection(Students.email,dayCount,dateType);
	}

	@Then("user import the package as per name {string} on quarter {int} and view Order Details with date {int} {string}")
	public void user_import_the_package_as_per_name_on_quarter_and_view_order_details_with_date(String courseName, Integer quarter, int dayCount, String dateType) {
		Products.filePath = downloadPath + "\\" + courseName + ".zip";
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    String dateUpdate = end.changeDate(quarter);
	    scr.switchTopicWindow();
        end.clickOnSubmitOnlyWithDate(dateUpdate);
        scr.clickViewOrderDetailsButton(dayCount, dateType);
        end.clickViewOrderCloseBtn();
        scr.switchWindowDefault();
	}
	
	@Then("user import the package as per name {string} and complete the Payment as card number {int}")
	public void userimport_the_package_as_per_name_and_complete_the_Payment(String courseName, int number) 
	{
		Products.filePath = downloadPath + "\\" + courseName + ".zip";
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchWindowandCompletePaymentAsCard(Students.email, number);
	}

	@Then("navigate to topic page for date {int} {string}")
	public void navigate_to_topic_page_for_date(int dayCount, String dateType) {
		String date = scr.changeDateAsPerTime(dayCount, dateType);
		end.clickOnSubmitOnlyWithDate(date);
	}

	@Then("click on cancel subscription button from view order details page")
	public void click_on_cancel_subscription_button_from_view_order_details_page() {
	    if(end == null)
	    	end = new EndUser();
	    end.clickViewOrderBtn();
	    scr.clickOnCancelSubscriptionButton();
	}

	@Then("select the cancel reason as {string} with reason of size {int}")
	public void select_the_cancel_reason_as_with_reason_of_size(String reason, int size) {
		if(scr == null)
	    	scr = new Scrom();
		scr.selectCancelReason(reason, size);
	}

	@Then("select only the cancel reason as {string}")
	public void select_the_cancel_reason(String reason) {
		if(scr == null)
	    	scr = new Scrom();
		scr.selectOnlyCancelReason(reason);
	}
	@Then("click on request cancellation btn")
	public void click_on_request_cancellation_butto() {
		if(scr == null)
	    	scr = new Scrom();
		scr.clickRequestCancellationbtn();
	}
	@Then("click on request cancellation button")
	public void click_on_request_cancellation_button() {
		if(scr == null)
	    	scr = new Scrom();
		scr.clickRequestCancellation();
	}

	@Then("click on cancel from confirm cancellation window")
	public void click_on_cancel_from_confirm_cancellation_window() {
		if(scr == null)
	    	scr = new Scrom();
		scr.clickCancelConfimCancellationWindow();
	}

	@Then("click on close from confirm cancellation window")
	public void click_on_close_from_confirm_cancellation_window() {
		if(scr == null)
	    	scr = new Scrom();
		scr.closeConfimCancellationWindow();
	}

	@Then("click on Cancel and Go Back button")
	public void click_on_Cancelrequest_cancellation_button() {
		if(scr == null)
	    	scr = new Scrom();
		scr.closeCancelandGoBackBtnCancellationWindow();
	}
	
	@Then("user import the package as per name {string}, launch and switch to topic window")
	public void user_import_the_package_as_per_name_launch_and_switch_to_topic_window(String courseName) {
		Products.filePath = downloadPath + "\\" + courseName + ".zip";
		prod = new Products();
	    scr.uploadPackage(Products.filePath);
	    scr.clickUploadPackage();
	    scr.clickOnLaunch();
	    scr.switchTopicWindow();
	}
	
	
	
	@Then("user Complete Course for quarter {int}")
	public void user_import_the_package_as_per_name_launch_and_switch_to_topic_window(int date) {
		  String dateUpdate = end.changeDate(date);
		  scr.clickOnSubmitOnlyWithDate(dateUpdate);
	        
		int count =scr. getNumberRows();

		System.out.println(count);
		for(int i =1; i <= count; i++)
	    {
				scr.startORResumeCourse();
			scr.completeCoursetestCode();
			scr. onlyExitCourse();	
	
	    }
		scr.switchWindowDefault();
	}
	
	

	@Then("validate the text limit error message as {string}")
	public void validate_the_text_limit_error_message(String message) {
	    scr.validateTextErrorMessage(message);
	}

	@Then("validate the retention of cancel reason")
	public void validate_the_retention_of_cancel_reason() {
	   scr.validateMessageRetention();
	}

	@Then("enter the cancel reason of size {int}")
	public void enter_the_cancel_reason_of_size(Integer size) {
	    scr.enterReasonText(size);
	}

	@Then("validate the disappearence error message for reason")
	public void validate_the_disappearence_error_message_for_reason() {
	    scr.validateRemovalErrorMessage();
	}

	@Then("enter the customize cancel reason as {string}")
	public void enter_the_customize_cancel_reason_as(String message) {
	    scr.enterCustomizeReasonText(message);
	}

	@Then("validate the confirm cancellation window")
	public void validate_the_confirm_cancellation_window() {
	    scr.validateConfirmCancellation();
	}

	@Then("validate the order summary from cancellation page for course {string} with plan for {string}")
	public void validate_the_order_summary_from_cancellation_page(String courseName, String plan) {
	    scr.validateOrderSummary(courseName, plan);
	}

	@Then("click on launch and complete the course from topic windowas per quarter {int}")
	public void click_on_launch_and_complete_the_course_from_topic_windowas_per_quarter(int date) {
		scr.clickOnLaunch();
		scr.switchTopicWindow();
        String dateUpdate = end.changeDate(date);
        end.clickOnSubmitOnlyWithDate(dateUpdate);
    	int count = end.getAvailableTopicNumberscrom();
    	System.out.println(count);
    	while(count >= 1)
	    {
    		scr.startORResumeCourse();
    		scr.completeCoursetestCode();
    		scr. onlyExitCourse();	
    		count = end.getAvailableTopicNumberscrom();
	    }
		scr.switchWindowDefault();
	}

	@Then("navigate to topic page for quarter {int}")
	public void navigate_to_topic_page_for_quarter(int quarter) {
		String dateUpdate = end.changeDate(quarter);
		end.clickOnSubmitOnlyWithDate(dateUpdate);
	}

	@Then("navigate to launch topic for course already uploaded by name {string}")
	public void navigate_to_launch_topic_for_course_already_uploaded_by_name(String course) {
	    scr.clickOnLibrary();
	    scr.clickOnUploadedCourse(course);
	}
	
	@Then("click on confirm cancellation on from confirm cancellation window")
	public void click_on_confirm_cancellation_on_from_confirm_cancellation_window() {
	    scr.clickConfirmCancellation();
	}
	
	@Then("validate Mandatory Error for Other Reason")
	public void click_on_conirm_cancellation_on_from_confirm_cancellation_window() {
	    scr.error_empty_reason();
	}
	
	@Then("validate Max limit Error for Other Reason")
	public void click_o_conirm_cancellation_on_from_confirm_cancellation_window() {
	    scr.error_maxCharlimit();
	}
	@Then("validate the cancel confirmation page details for {string} {string}")
	public void validate_the_cancel_confirmation_page_details_for(String number, String dayType) {
	   scr.validateCancelConfirmPageHeading();
	   scr.validateRefundAmountMessage(number,dayType);
	   scr.validateEmailRefundMessage();
	   scr.validateTransactionNumberMessage();
	}
	
	@Then("Validate Subscription plan valid until date on the Popup {int} Plan for course {string} in scrom")
	public void Subscribed_and_completevalid(int plan,String course) 
	{
		
		scr.validate_subscriptionvalid_until_date(course,plan);
	    
	}
	

	@Then("Delete dispatch by name {string}")
	public void delete_dispatch_by_name(String course) {
	    scr.clickOnLibrary();
	    scr.deletebyCourse(course);
	}
	@Then("Delete All dispatch")
	@Then("All Delete dispatch")
	public void All_delete_dispatch_by_name() {
	    scr.clickOnLibrary();
	    scr.allDeleteCourses();
	}

	@Then("click on view order details link")
	public void click_on_view_order_details_link() {
		 if(end == null)
		    	end = new EndUser();
		    end.clickViewOrderBtn();
	}
	
	@Then("validate contact link is available")
	public void validate_contact_link_is_available() {
		if(end == null)
	    	end = new EndUser();
		end.verifySupportDropNotAvailable();
	}

	@Then("user import the package and Register as per date {int} , course name {string} and handle CMECE popup")
    public void user_import_the_package_as_per_quarter_and_course_name_handle_CMECE(int date, String courseName)
    {
		Products.filePath =System.getProperty("user.dir")+ TestBase. prop.getProperty("downloadPath") + "\\" + courseName + ".zip";
		 scr.uploadPackage(Products.filePath);
        scr.clickUploadPackage();
        scr.clickOnLaunch();
        if(Students.email == null)
        	scr.switchWindowSelf("Test", "Ansh", "G");
        else
        	scr.switchWindowSelf(Students.email,Students.firstName, Students.lastName);
        String dateUpdate = end.changeDate(date);
        end.clickOnSubmitOnlyWithDate(dateUpdate);
    	int count = end.getAvailableTopicNumberscrom();
    	System.out.println(count);
    	while(count >= 1)
	    {
    		scr.	startORResumeCourse();
//	    	completeCourse();
    		scr.	completeCoursetestCode();
    		scr.   onlyExitCourse();	
    		if(end.validateCMEPopupAvailable())
    			end.cecmepopupforsub();
    		count = end.getAvailableTopicNumberscrom();
	    }
		    scr.switchWindowDefault();
    }
	
	@Then("click on claim cme button")
	public void click_on_claim_cme_button() {
		if(scr == null)
			scr = new Scrom();
	    scr.clickCME_ClaimButton();
	}
	
	@Then("validate the email field is mandatory")
	public void validate_the_email_field_is_mandatory() {
		if(scr == null)
			scr = new Scrom();
		scr.validate_CME_Email_Mandatory();
	}
	
	@Then("validate the email is prepopulated and not editable")
	public void validate_the_email_is_prepopulated_and_not_editable() {
		if(scr == null)
			scr = new Scrom();
		scr.validateUnEditEmail_prepopulated();
	}
	
	@Then("click on save button")
	public void click_on_save_button() {
		if(scr == null)
			scr = new Scrom();
		scr.clickSaveButtonCMEClaim();
	}
	
	@Then("validate the error message for emailID")
	public void validate_the_error_message_for_email_id() {
		if(scr == null)
			scr = new Scrom();
		scr.validateEmailErrorMessage();
	}
	@Then("validate the email is empty and editable")
	public void validate_the_email_is_empty_and_editable() {
		if(scr == null)
			scr = new Scrom();
		scr.validateUEditEmail_Empty();
	}
	
	@Then("user import the package and no Register as per date {int} , course name {string} and handle CMECE popup")
    public void user_import_the_package_and_no_register_as_per_date_and_course_name_handle_CMECE(int date, String courseName)
    {
		Products.filePath =System.getProperty("user.dir")+ TestBase. prop.getProperty("downloadPath") + "\\" + courseName + ".zip";
		 scr.uploadPackage(Products.filePath);
        scr.clickUploadPackage();
        scr.clickOnLaunch();
        scr.switchWindowCourseTopic();
        scr.clickSaveOnSelfRegistrationWindow();
        String dateUpdate = end.changeDate(date);
        end.clickOnSubmitOnlyWithDate(dateUpdate);
    	int count = end.getAvailableTopicNumberscrom();
    	System.out.println(count);
    	while(count >= 1)
	    {
    		scr.	startORResumeCourse();
//	    	completeCourse();
    		scr.	completeCoursetestCode();
    		scr.   onlyExitCourse();	
    		if(end.validateCMEPopupAvailable())
    			end.cecmepopupforsub();
    		count = end.getAvailableTopicNumberscrom();
	    }
		    scr.switchWindowDefault();
    }
	
	
}
