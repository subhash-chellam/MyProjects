package stepDefinitions;

import java.util.Map;

import com.qa.pages.OrganizationHome;
import com.qa.pages.Products;
import com.qa.util.TestBase;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;

public class ProductSteps  
{

	Products prod;
	OrganizationHome orgHome;
	
	@Then("navigate to product page")
	public void navigate_to_product_page() 
	{
		prod = new Products();
		String orgName = TestBase.prop.getProperty("orgName");
		System.out.println("org name from property is " + orgName);
		prod.clickOnProductsTab(); 
	}
	
	@Then("get product count and list")
	public void get_productCountandlist() 
	{
		prod = new Products();
		prod.getlistoffproduct();
	}
	


	
	@Then("update the product quantity as per name {string} by count {int}")
    public void update_the_product_quantity_as_per_name_by_count(String courseName, Integer count)
    {
        if(orgHome == null)
            orgHome = new OrganizationHome();
        String course[] = courseName.split(",");
        for(int i = 0; i <= course.length-1; i++)
        {
            int quantity = prod.countTotalQuantityProductByName(course[i]);
            prod.editProductQuantityByName(course[i], quantity + count);
        }
    }
	@Then("select the product product path for {string}")
	public void user_import_the_package_and_navigate_to_topic_page_for_courses_per_name_type_and_quarter(String courseName) 
	{
		Products.filePath =System.getProperty("user.dir")+ TestBase. prop.getProperty("downloadPath") + "\\" + courseName + ".zip";
		
	}
	@Then("change the file name with name {string} which having extension as {string}")
	public void change_the_file_name_with_name_which_having_extension_as(String newName, String extension) 
	{
		prod = new Products();
		
	    prod.changeFileName(newName, extension);
	}
	@Then("download the dispatch by name and dont delete {string}")
	public void download_the_dispatch_by_name_and_dont_delete(String courseName) throws Exception 
	{
	    prod.clickOnDownloadLinkByName("no", courseName);
	}
	@Then("add the multiple product to inventory {int} {string}")
	public void add_the_multiple_product_to_inventory(Integer quantity, String courseName) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		String course[] = courseName.split(",");
		for(int i = 0; i <= course.length-1; i++)
		{
		    prod.clickOnAddProductsButton();
		    prod.AddProductInventoryByNameAndCount(course[i], quantity);
		    orgHome.validateSucessMesssage();
		}
	}
	
	@Then("navigate to product History")
	public void navigate_to_product_history() throws InterruptedException 
	{
		prod = new Products();
		prod.clickonProductHistoryTab(); 
	}
	
	
	@Then("update the version {string}")
	public void updatetheversion(String course) throws InterruptedException 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		
		   prod.editproduct(course);
		    prod.editversion();
		   
		
	}
	
	@Then("update the version to scrom 1.2 {string}")
	public void updatetheversiontoscrom(String course) throws InterruptedException 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		
		   prod.editproduct(course);
		    prod.editversion12();
		   
		
	}

	@Then("update the package type {string} for course {string}")
	public void updatethepackagetype(String type,String course) throws InterruptedException 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		
		   prod.editproduct(course);
		    prod.editpackage(type);
		   
		
	}
	

	@Then("add the product")
	public void add_the_product() 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	    prod.clickOnAddProductsButton();
	    prod.enterProductDetails("manual");
	    orgHome.validateSucessMesssage();
	}
	@Then("add the product to inventory {int} {string}")
	public void add_the_product_to_inventory(Integer quantity, String courseName) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	    prod.clickOnAddProductsButton();
	    prod.AddProductInventoryByNameAndCount(courseName, quantity);
	    orgHome.validateSucessMesssage();
	}

	@Then("add the product_automatic")
	public void add_the_product_automatic() 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	    prod.clickOnAddProductsButton();
	    prod.enterProductDetails("automatic");
	    orgHome.validateSucessMesssage();
	}
	
	@Then("edit the product")
	public void edit_the_product() 
	{
	    prod.editProduct();
	    orgHome.validateSucessMesssage();
	}
	
	@Then("download the dispatch")
	public void download_the_dispatch() throws Exception 
	{
	    prod.clickOnDownloadLink("yes");
	}
	
	@Then("download the dispatch and dont delete")
	public void download_the_dispatch_and_dont_delete() throws Exception 
	{
	    prod.clickOnDownloadLink("no");
	}
	
	@Then("download the dispatch and dont delete {string}")
	public void download_the_dispatch_and_dont_delete(String course) throws Exception 
	{
	    prod.clickOnDownloadLink("no",course);
	}
	
	@Then("download the {string} dispatch and dont delete {string}")
	public void download_the_dispatch_and_ont_delete(String type,String course) throws Exception 
	{
	    prod.clickOnDownloadLink("no",course.replace("Â", ""),type);
	    
	}
	
	@Then("Click on Next Button")
	public void click_on_next_button() throws Exception 
	{
	    prod.nextbutton();
	    
	}
	
	@Then("add the product by name and enable recurrence {string} {string}")
	public void add_the_product_by_name_and_enable_recurrence(String type, String name) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	    prod.clickOnAddProductsButton();
	    prod.enterProductDetailsByNameAndRecurrence(type, name);
	    orgHome.validateSucessMesssage();
	}
	
	@Then("check the product if added by name and enable recurrence {string} {string}")
	public void check_theadd_the_product_by_name_and_enable_recurrence(String type, String name) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		if(!prod.validateifproductisadded(name))
		{
	    prod.clickOnAddProductsButton();
	    prod.enterProductDetailsByNameAndRecurrence(type, name);
	    orgHome.validateSucessMesssage();
		}
	}
	
	@Then("check the product if added by name {string} {string} {string}")
	public void add_themultipleproduct_by_name(String type, String names,String option) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		String course[] = names.split(",");
		
		for(int i = 0; i <= course.length-1; i++)
		{
			if(!prod.validateifproductisadded(course[i]))
			{
			prod.clickOnAddProductsButton();
		    prod.enterProductDetails(type, course[i],option);
		    orgHome.validateSucessMesssage();
		    }
		}
	}
	@Then("check the product if added by name {string} {string}")
	public void add_themultipleproduct_by_name(String type, String names) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		String course[] = names.split(",");
		
		for(int i = 0; i <= course.length-1; i++)
		{
			if(!prod.validateifproductisadded(course[i]))
			{
			prod.clickOnAddProductsButton();
			  prod.enterProductDetailsByName(type, course[i]);
		    orgHome.validateSucessMesssage();
		    }
		}
	}
	@Then("navigate to organization home")
	public void navigate_to_organization_home() 
	{
	    if(prod == null)
	    {
	    	prod = new Products();
	    }
	    prod.navigateOrgList();
	    
	}

	@Then("add multiple product {int}")
	public void add_multiple_product(int number) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		
		System.out.println(prod.getnumberProduct()+" "+number);
//	    prod.enterMultipleProductDetails("manual", number+prod.getnumberProduct(),prod.getnumberProduct()+2);	    
			prod.enterMultipleProductDetails("manual", number);	    
		orgHome.validateSucessMesssage();
	}

//	@Then("add multiple product {int}")
//	public void add_multiple_product(int number) 
//	{
//		if(orgHome == null)
//			orgHome = new OrganizationHome();
//		
//	    prod.enterMultipleProductDetails("manual", number,prod.getnumberProduct()+1);	    
//	    orgHome.validateSucessMesssage();
//	}

	@Then("check the product usage {int}")
	public void check_the_product_usage(int count) 
	{
	    prod.productUsageCount(count);
	    prod.navigateOrgList();
	}

	@Then("add the product by name {string} {string}")
	public void add_the_product_by_name(String type, String name) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	    prod.clickOnAddProductsButton();
	    prod.enterProductDetailsByName(type, name);
	    orgHome.validateSucessMesssage();
	}
	
	@Then("add NLN products by name for {string} {string}")
	public void add_NLN_product_by_name(String Subscription, String name) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		  String course[] = name.split(",");
			
	    
	    for(int i = 0; i <= course.length-1; i++)
		{
			if(!prod.validateifproductisadded(course[i]))
			{
			prod.clickOnAddProductsNLNButton();
			  prod.enterProductNLNDetailsByName(Subscription, course[i]);
		    orgHome.validateSucessMesssage();
		    }
		}
	}
	
	@Then("add NLN products by name {string} , {string} for student and {string} for Organization Pay")
	public void add_NLN_products_by_name(String name, String Subscription,String type) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		  String course[] = name.split(",");
			
	    
	    for(int i = 0; i <= course.length-1; i++)
		{
			if(!prod.validateifproductisadded(course[i]))
			{
			prod.clickOnAddProductsNLNButton();
			  prod.enterProductNLNDetailsByName(Subscription, course[i],type);
		    orgHome.validateSucessMesssage();
		    }
		}
	}
	

	@Then("add NLN Provider by name {string} , unlimited for student and {string} for Organization Pay")
	public void add_NLN_Provider_by_name(String names,String type) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		
         String course[] = names.split(",");
		
		for(int i = 0; i <= course.length-1; i++)
		{
			if(!prod.validateifproductisadded(course[i]))
			{
			prod.clickOnAddProductsNLNButton();
			  prod.enterProductNLNDetailsByNames( course[i],type);
		    orgHome.validateSucessMesssage();
		    }
		}
	 
	}
	
	@Then("add NLN Provider by name for {string}")
	public void add_NLN_product_by_names( String names) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		
         String course[] = names.split(",");
		
		for(int i = 0; i <= course.length-1; i++)
		{
			if(!prod.validateifproductisadded(course[i]))
			{
			prod.clickOnAddProductsNLNButton();
			  prod.enterProductNLNDetailsByNames( course[i]);
		    orgHome.validateSucessMesssage();
		    }
		}
	 
	}
	
	
	@Then("add the product by name {string} {string} and validate message {string}")
	public void add_the_product_by_name_and_validate_message(String type, String name,String msg) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	    prod.clickOnAddProductsButton();
	    prod.enterProductDetailsByName(type, name);
	    
	    if(TestBase.courseListName.containsKey(name+"Option"))
			msg=msg.replace("productname", TestBase.courseListName.get(name+"Option").toString()) ;

	   
	    orgHome.validateSucessMesssage(msg);
	}
	
	
	@Then("edit the product by name {string} {string} and validate message {string}")
	public void add_the_product_byname(String type, String name,String msg) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	    prod.clickOnEditProductsButton(name);
	    prod.editProductDetailsByName(type, name);
	    orgHome.validateSucessMesssage(msg);
	}
	
	@Then("edit the product by name {string} and change the payment to Student Pay only")
	public void add_the_product_bynamechangeTo_studneyPay(String name) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	    prod.clickOnEditProductsButton(name);
	    prod.changetoStudentPaymodeOnly();
	    orgHome.validateSucessMesssage();
	}
	
	@Then("edit the product by name {string} and Select the payment to Organization Pay")
	public void add_the_product_bynamechangeTo_OrganizationPay(String name) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	    prod.clickOnEditProductsButton(name);
	    prod.changetoOrgPaymodeOnly();
	    orgHome.validateSucessMesssage();
	}
	
	@Then("edit the CTC product by name {string} {string} and validate message {string}")
	public void add_the_ctcproduct_byname(String type, String name,String msg) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	    prod.clickOnEditProductsButton(name);
	    prod.editctcProductDetailsByName(type, name);
	    orgHome.validateSucessMesssage(msg);
	}
	
	@Then("view the product details by name {string}")
	public void view_the_product_byname(String name) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	    prod.clickOnEditProductsButton(name);
	  
	}
	@Then("validated the product details")
	public void view_the_product_byname(DataTable table) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
       for(int i=0;i<table.width();i++)
		prod.viewtheproduct(table.column(i).get(0),table.column(i).get(1));
	  
	}
	
	@Then("edit the product by name {string} {string}")
	public void add_the_product_byname(String type, String name) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	    prod.clickOnEditProductsButton(name);
	    prod.editProductDetailsByName(type, name);
	    orgHome.validateSucessMesssage();
	}
	@Then("edit product and change product type to unlimited {string}")
	public void add_the_product_byname(String name) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	    prod.clickOnEditProductsButton(name);
	    prod.editsProducttypeDetailsByName();
	    orgHome.validateSucessMesssage();
	}
	
	@Then("add the product by name {string} {string} and change the start date {string}")
	public void add_the_product_by_name(String type, String name,String date) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	    prod.clickOnAddProductsButton();
	    prod.onlyEnterProductDetailsByName(type, name,date);
	    prod.clickToAddProduct();
	    orgHome.validateSucessMesssage();
	}
	
	@Then("add the Elearning product by name {string} {string}")
	public void add_theElearning_product_by_name(String type, String name) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	    prod.clickOnAddProductsButton();
	    prod.enterElearningProductDetailsByName(type, name);
	    orgHome.validateSucessMesssage();
	}
	
	@Then("add the product by name and enable recurrence and add recurrence details")
	public void add_the_product_by_name_and_enable_recurrence_and_add_recurrence_details(DataTable productDetails) 
	{
		for(Map<String, String> dataSet : productDetails.asMaps())
		{
			if(orgHome == null)
				orgHome = new OrganizationHome();
			prod.clickOnAddProductsButton();
		    prod.onlyEnterProductDetailsByName(dataSet.get("type"), dataSet.get("name"));
		    prod.allowRecurrence();
//		    prod.clickRecurrenceCheckbox();
//		    prod.enterRecurrenceDetails(dataSet.get("number"),dataSet.get("time"),dataSet.get("criteria"));
		    prod.clickToAddProduct();
		    orgHome.validateSucessMesssage();
		}
	    
	}
	@Then("add the Elearning product by name and enable recurrence and add recurrence details")
	public void add_the_Elearningproduct_by_name_and_enable_recurrence_and_add_recurrence_details(DataTable productDetails) 
	{
		for(Map<String, String> dataSet : productDetails.asMaps())
		{
			if(orgHome == null)
				orgHome = new OrganizationHome();
			prod.clickOnAddProductsButton();
		    prod.onlyEnterElearningProductDetailsByName(dataSet.get("type"), dataSet.get("name"));
		    prod.allowRecurrence();
//		    prod.clickRecurrenceCheckbox();
//		    prod.enterRecurrenceDetails(dataSet.get("number"),dataSet.get("time"),dataSet.get("criteria"));
		    prod.clickToAddProduct();
		    orgHome.validateSucessMesssage();
		}
	    
	}
	
	
	@Then("add the product by name and enable recurrence and add recurrence details for LMS")
	public void add_the_product_by_name_and_enable_recurrence_and_add_recurrence_detailslms(DataTable productDetails) 
	{
		for(Map<String, String> dataSet : productDetails.asMaps())
		{
			if(orgHome == null)
				orgHome = new OrganizationHome();
			prod.clickOnAddProductsButton();
		    prod.onlyEnterProductDetailsByName(dataSet.get("type"), dataSet.get("name"));
		    prod.allowRecurrence();
		    prod.clickRecurrenceCheckbox();
		    prod.enterRecurrenceDetails(dataSet.get("number"),dataSet.get("time"),dataSet.get("criteria"));
		    prod.clickToAddProduct();
		    orgHome.validateSucessMesssage();
		}
	    
	}
	
	@Then("add the product by name and  enable recurrence without selecting the check box")
	public void add_theproduct_by_name_and_enable_recurrence_and_add_recurrence_detailslms(DataTable productDetails) 
	{
		for(Map<String, String> dataSet : productDetails.asMaps())
		{
			if(orgHome == null)
				orgHome = new OrganizationHome();
			prod.clickOnAddProductsButton();
		    prod.onlyEnterProductDetailsByName(dataSet.get("type"), dataSet.get("name"));
		    prod.allowRecurrence();
		    prod.enterRecurrenceDetailsshouldbedisable(dataSet.get("number"),dataSet.get("time"),dataSet.get("criteria"));
		 
		}
	    
	}
	@Then("add the multiple product by name {string} {string}")
	public void add_the_multiple_product_by_name(String type, String names) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		String course[] = names.replace("Â", "").split(",");
		for(int i = 0; i <= course.length-1; i++)
		{
			prod.clickOnAddProductsButton();
		    prod.enterProductDetailsByName(type, course[i]);
		    orgHome.validateSucessMesssage();
		    prod.clickOnProductsTab();
		}
	}
	
	@Then("add the multiple product by name {string} {string} multiple dispatch")
	public void add_the_multiple_product_by_name_multiple_dispatch(String type, String names) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		String course[] = names.replace("Â", "").split(",");
		for(int i = 0; i <= course.length-1; i++)
		{
			prod.clickOnAddProductsButton();
		    prod.enterProductDetailsByName_with_multiple(type, course[i]);
		    
		    orgHome.validateSucessMesssage();
		}
	}
	
	@Then("add the multiple product by name {string} {string} {int}")
	public void add_the_multiple_product_by_name(String type, String names,int count) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		String course[] = names.split(",");
		for(int i = 0; i <= course.length-1; i++)
		{
			prod.clickOnAddProductsButton();
		    prod.enterProductDetailsByName(type, course[i],count);
		    orgHome.validateSucessMesssage();
		}
	}
	@Then("validate the enable recurrence functionality as {string}")
	public void validate_the_enable_recurrence_functionality_as(String availability) 
	{
	    prod.validateRecurrenceFrequencyAvailability(availability);
	}

	@Then("add the product details by name {string} {string}")
	public void add_the_product_details_by_name(String type, String name) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
	    prod.clickOnAddProductsButton();
	    prod.onlyEnterProductDetailsByName(type, name);
	}
	@Then("add the multiple product by name {string} {string} {string}")
	public void add_the_multiple_product_by_name(String type, String names,String option) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		String course[] = names.split(",");
		for(int i = 0; i <= course.length-1; i++)
		{
			prod.clickOnAddProductsButton();
		    prod.enterProductDetailsByName(type, course[i],option);
		    orgHome.validateSucessMesssage();
		}
	}
	@Then("add product by name {string} {string} {string}")
	public void add_themultiple_product_by_name(String type, String names,String option) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		String course[] = names.split(",");
		for(int i = 0; i <= course.length-1; i++)
		{
			prod.clickOnAddProductsButton();
		    prod.enterProductDetails(type, course[i],option);
		    orgHome.validateSucessMesssage();
		}
	}
	
	@Then("add product by name {string} {string} {string} dont save")
	public void add_themultiple_productby_name(String type, String names,String option) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		
			prod.clickOnAddProductsButton();
			   prod.enterProductDetailsdontsave(type,  names, option);
				 
	}
	
	@Then("add product by name {string} {string} {string} for CTC Org")
	public void add_themultiple_product_by_name_for_CTC(String type, String names,String option) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		String course[] = names.split(",");
		for(int i = 0; i <= course.length-1; i++)
		{
			prod.clickOnAddProductsButton();
		    prod.enterProductDetailsCTC(type,  course[i], option);
		    orgHome.validateSucessMesssage();
		}
	}

	@Then("edit product by name {string} {string} {string}")
	public void edit_product_by_name(String type, String names,String option) throws InterruptedException 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		String course[] = names.split(",");
		for(int i = 0; i <= course.length-1; i++)
		{
			 prod.editproducts(course[i]);
		    prod.entereditProductDetails(type, course[i],option);
		    orgHome.validateSucessMesssage();
		}
	}
	

	@Then("edit product by name and status of Recurrence {string} {string}")
	public void edit_product_by_nameRecurrence(String names,String option) throws InterruptedException 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		String course[] = names.split(",");
		for(int i = 0; i <= course.length-1; i++)
		{
			 prod.editproducts(course[i]);
		    prod.entereditProductDetailschangestatus(option);
		    orgHome.validateSucessMesssage();
		}
	}
	@Then("edit product by name and Recuurence {string} {string} {string}")
	public void edit_product_by_amRecurrence(String names,String option,String dur) throws InterruptedException 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
			 prod.editproducts(names);
		    prod.entereditProductDetailschangestatus(option);
		
	}
	@Then("edit product elearning by name {string} {string} {string}")
	public void edit_product_y_name(String type, String names,String option) throws InterruptedException 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		String course[] = names.split(",");
		for(int i = 0; i <= course.length-1; i++)
		{
			 prod.editproducts(course[i]);
		    prod.entereditProductDetailselearing(type, course[i],option);
		    orgHome.validateSucessMesssage();
		}
	}


	@Then("edit product by name {string} {string} {string} for CTC Org")
	public void edit_product_by_name_ctc(String type, String names,String option) throws InterruptedException 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		String course[] = names.split(",");
		for(int i = 0; i <= course.length-1; i++)
		{
			 prod.editproducts(course[i]);
		    prod.entereditProductDetailsCTC(type, course[i],option);
		    orgHome.validateSucessMesssage();
		}
	}

@Then("click on add product button")
public void click_on_add_product_button() {
	prod.clickOnAddProductsButton();
}

@Then("validate the if the product is added {string}")
public void click_on_add_product_button(String names) {
	String course[] = names.split(",");

	for(int i = 0; i <= course.length-1; i++)
	{
	prod.validateproduct(course[i]);
	}
}



@Then("verify that End date on LMS field is removed")
public void verify_that_end_date_on_lms_field_is_removed() {
   prod.verifyenddatepresence(); 
}
@Then("verify that table contains header {string}")
public void verify_that_table_contains_header(String string) {
 prod.validatetableheader(string);
}

@Then("Verify there exists label in add {string}")
public void verify_there_exists_label_in_add(String string) {
	 prod.validatelabelinaddandeditscreen(string);
}

@Then("Verify there exists label in edit {string}")
public void verify_there_exists_label_in_edit(String string) {
    // Write code here that turns the phrase above into concrete actions
	 prod.validatelabelinaddandeditscreen1(string);
}
@Then("click on edit product button")
public void click_on_edit_product_button() throws InterruptedException {
 prod.editProductclickCTC(); 
}
@Then("click on edit product button LMS")
public void click_on_edit_product_button_lms() throws InterruptedException {
	prod.editProductclickLMS(); 
}

@Then("click on purchase history and verify headers {string}  and {string}")
public void click_on_purchase_history_and_verify_headers_and(String string, String string2) throws InterruptedException {
 prod.verifypurchasehistory(string,string2);
}
@Then("Verify the start date on LMS is set to current date")
public void verify_the_start_date_on_lms_is_set_to_current_date() {
    prod.startdatetocurrentdate();
}

@Then("Verify the start date on LMS is set to {string}")
public void verify_the_start_date_on_lms_is_set_to(String string) {
     prod.startdatesettoselecteddate(string);
}
@Then("Verify the product Subscription From Unlimited to limited")
public void verifySubscriptionMessageFromUnlimitedToLimited() {
	prod.getProductSubscription();
	prod.VerifyclickonUnlimitedtolimited();
}

@Then("Verify the header is present {string}")
public void VerifyTheHeaderIsPresent(String string) {
	prod.SelectFromTable(string);
}

@Then("Verify {string} text is present in column {string} {int} {int}")
public void verifyUnlimitedTextIsPresent(String contractQuantity,String cellValueToCompare,int ColumntoIterate, int ToGetvalueFromcolumn) {
	prod.getValueFromColumn(cellValueToCompare, ColumntoIterate, ToGetvalueFromcolumn, contractQuantity);
	
}

@Then("click On Actions button {string} {int} {int} {int}")
public void selectActionColumn(String cellValueToCompare,int ColumntoIterate, int ToGetvalueFromcolumn, int selectActionsFromColumns) {
	prod.selectvalueFromActions(cellValueToCompare, ColumntoIterate, ToGetvalueFromcolumn, selectActionsFromColumns);
	prod.ActionColumn("Product subscription details updated successfully.");
}

@Then("validate the download package name with {string} for course {string}")
public void validate_the_download_package_name_with_for_course(String cycle, String courseName) {
    prod.getProductCodeByName(courseName);
    prod.validateDownloadFileName(cycle);
}

@Then("validate the number of cycle available in download product screen {string}")
public void validate_the_number_of_cycle_available_in_download_product_screen(String courseName)  throws Exception{
    prod.validateCycleNumber(courseName);
}	

@Then("edit the recurrence type of product {string}")
public void edit_the_recurrence_type_of_product(String courseName) 
{

    prod.editMultiScromProductByName(courseName);
  
}


@Then("add the multiple product with student purchase by name {string} {string}")
public void add_the_multiple_product_with_student_purchase_by_name(String type, String names) 
{
    if(orgHome == null)
        orgHome = new OrganizationHome();
    String course[] = names.split(",");
    for(int i = 0; i <= course.length-1; i++)
    {
        prod.clickOnAddProductsButton();
        course[i] = course[i].trim();
        System.out.println(course[i] + " from feature file and " + TestBase.courseListName.get(course[i]).toString() + " course from property file");
        prod.enterProductDetailsByNameWithStudentPurchase(type, TestBase.courseListName.get(course[i]).toString().trim(),"15 month plan");
        orgHome.validateSucessMesssage();
    }
}


@Then("add the automatic NLN product {string} if not available")
public void add_the_automatic_nln_product_if_not_available(String courseName) {
    if(prod == null)
        prod = new Products();
    String course[] = courseName.split(",");
    for(int i = 0; i <= course.length-1; i++)
    {
        prod.clickOnProductsTab();
        boolean flag = prod.validateProductAvailability(TestBase.courseListName.get(course[i]).toString());
        if(flag == false) {
            add_the_multiple_product_with_student_purchase_by_name("automatic", course[i]);
        	}
    	}
	}

	@Then("add the automatic NLN product with both pay {string} if not available")
	public void add_the_automatic_nln_product_with_both_pay_if_not_available(String courseName) throws InterruptedException {
		 if(prod == null)
		        prod = new Products();
		    String course[] = courseName.split(",");
		    for(int i = 0; i <= course.length-1; i++)
		    {
		        prod.clickOnProductsTab();
		        boolean flag = prod.validateProductAvailabilityWithBothPayType(TestBase.courseListName.get(course[i]).toString());
		        if(flag == false) {
		        	boolean flagProductAvailable = prod.validateProductAvailability(TestBase.courseListName.get(course[i]).toString());
		        	if(flagProductAvailable == true) {
		        		String paymentMode = prod.getProductAvailablePaymentType(TestBase.courseListName.get(course[i]).toString());
		        		if(paymentMode.equals("Organization")) {
		        			prod.editproduct(course[i].toString());
		        			prod.editProduct_Add_StudentPay(TestBase.courseListName.get(course[i]).toString(), "15 month plan");
		        		}
		        		else {
		        			prod.editproduct(course[i].toString());
		        			prod.editProduct_Add_OrgPay("automatic");
		        		}
		        	}
		        	else {
		        		 prod.clickOnAddProductsButton();
		        	        course[i] = course[i].trim();
		        	        System.out.println(course[i] + " from feature file and " + TestBase.courseListName.get(course[i]).toString() + " course from property file");
		        	        prod.enterProductDetailsByNameWithBothPurchase("automatic", 
		        	        		TestBase.courseListName.get(course[i]).toString().trim(),"15 month plan");
		        	        orgHome.validateSucessMesssage();
		        	}
		        	}
		    	}
			}


}
