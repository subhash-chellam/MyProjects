package stepDefinitions;

import org.openqa.selenium.By;

import com.qa.pages.CE_Report;
import com.qa.pages.Compliance;
import com.qa.pages.ConsumptionReport;
import com.qa.pages.OrganizationDetails;
import com.qa.pages.OrganizationHome;
import com.qa.pages.OrganizationSetting;
import com.qa.pages.ProgressReport;
import com.qa.pages.Students;
import com.qa.pages.User;
import com.qa.pages.UserManagement;
import com.qa.pages.UtilisationReport;
import com.qa.util.TestBase;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import junit.framework.Assert;


public class UtilisationStep {

	UtilisationReport utilisation=new UtilisationReport();
	
	@Then("validate the details on Utilisation report page")
	public void export_and_validate_the_details() 
	{
			User	usr = new User();
			
			
			Students	std = new Students();
			boolean flag = usr.checkCSVFilePresent();
			if(flag == true)
				std.deleteFile(Students.filePath);

		   utilisation.verifyDownloadFile();
		   utilisation.compareDetails();
	}
	
	@Then("validate download report and validate details on Utilisation report page")
	public void export_ad_validate_the_details() 
	{
			User	usr = new User();
			
			
			Students	std = new Students();
			boolean flag = usr.checkCSVFilePresent();
			if(flag == true)
				std.deleteFile(Students.filePath);
			utilisation.clickDownloadButton();
		   utilisation.verifyDownloadFile();
		   utilisation.compareDetails();
	}
	

	@Then("click on email report button on Utilisation report page")
	public void click_on_email_report_button_on_ce_report_page() {
			utilisation.clickExportButton();
	}
	
	@Then("validate the notice window on Utilisation report page")
	public void validate_the_notice_window_on_ce_report_page() {
			utilisation.validateEmailDialogueBox(User.userEmail);
	}
	
	
	@Then("navigate to Utilisation report page")
	public void navigate_to_consumption_report_page() 
	{
//		utilisation = new ConsumptionReport();
		utilisation.navigateUtilisationReport();
//		TestBase.driver.navigate().to("https://qa-maurya-rqi1stop.laerdalblr.in/admin/subscription_course");
	}
	
	
	@Then("enter the valid date range on Utilisation report page")
	public void enter_the_valid_date_range_on_ce_report_page() {
		
		
		utilisation.validFromDateValue();
		utilisation.validEndDateValue();
	}
	
	@Then("select all products from dropdown on Utilisation report page")
	public void select_all_products_from_dropdown_Utilisation_report() 
	{
		utilisation.selectAllProducts();
	}
	
	
	@Then("select {string} products without searching from dropdown on Utilisation report page")
	public void select_all_products_from_dropdown_fromUtilisation_report(String product) 
	{
		utilisation.selectProductwithout(product);
	}
	@Then("select {string} products from dropdown on Utilisation report page")
	public void select_all_products_from_dropdown_Utilisation_report(String product) 
	{
		utilisation.selectProduct(product);
	}
	
	@Then("select {string} partial products from dropdown on Utilisation report page")
	public void select_all_products_from_dropdownUtilisation_report(String product) 
	{
		utilisation.selectProduct(product);
	}
	
	
	@Then("search Blocked products from dropdown on Utilisation report page \\(should not display)")
	public void search_from_dropdown_Utilisation_report() 
	{
		utilisation.BlockedProduct();
	}
	
	
	@Then("get the list of product in Utilisation report page")
	public void select_all_products_from_dropdown() 
	{
		utilisation.getAllProducts();
	}
	
	@Then("Validate list of product {string} in Utilisation report page")
	public void select_all_products_from_dropdown(String product) 
	{
		utilisation.getAllProducts(product);
	}
	
	
	@Then("get org created date in Utilisation report page")
	public void select_alproducts_from_dropdown() throws Exception 
	{
		utilisation.getOrgCreateDate();
	}
	
	@Then("Validate Message {string} in Utilisation report page")
	@Then("Validate Mandatory Message {string} in Utilisation report page")
	@Then("Validate Error Message {string} in Utilisation report page")
	public void navigate_to_compliance_report_page(String message) 
	{
	   
		utilisation.validateLabel(message);
	    
	}
	
	
	@Then("Validate footer load message {string} in Utilisation report page")
	public void validate_footer_load_message(String message) 
	{
	   
		utilisation.validatefooterloadmessage(message);
	    
	}
	@Then("Validate footer load message not displayed {string} in Utilisation report page")
	public void validate_footer_load_notdisplayedmessage(String message) 
	{
	   
		utilisation.validatefooterloadmessage(message);
	    
	}
	
	@Then("Validate Message not displayed {string} in Utilisation report page")
	public void navigate_to_copliance_report_page(String message) 
	{
	   
		utilisation.validateLabelnotdisplay(message);
	    
	}
	
	
	@Then("select the {string} as per name on Utilisation report page")
    public void select_the_salesforce_id_as_per_name(String type) throws Exception
	{
		utilisation.clickOnOrganizationdropDown();
		
		switch(type)
		{
		case "Salesforce ID" :utilisation.selectSalesForceIDByName();
		break;
		case "Organization ID" :utilisation.selectOrgID();
		break;
		case "Organization Name" :utilisation.selectOrgName();
		break;
		
		case "Salesforce ID partial" :utilisation.selectSalesForceIDByName(OrganizationDetails.SalesforceName.substring(0,OrganizationDetails.SalesforceName.length()-3));
		break;
		case "Organization ID partial" :utilisation.selectOrgID(OrganizationHome.exceptionid.substring(0,OrganizationHome.exceptionid.length()-2));
		break;
		case "Organization Name partial" :utilisation.selectOrgName(OrganizationHome.exceptionorg.substring(0,OrganizationHome.exceptionorg.length()-3));
		break;
		case "Organization inactive/blocked/deleted" :utilisation.selectOrgNamenotfound();
		break;
	
		}
        
    }
	
	
	@Then("Organization Unit Filters should be disabled on Utilisation report page")
    public void select_the_salesorce_id_as_per_name() throws Exception
	{
		utilisation.organizationUnitFiltersdisabled();
		
		
        
    }
	
	@Then("Click Organization Unit Filters on Utilisation report page")
    public void clickhe_salesorce_id_as_per_name() throws Exception
	{
		utilisation.clickorganizationUnitFilters();
		
		
        
    }
	
	@Then("Organization Name field should not be displayed on Utilisation report page")
    public void select_the_salesforce_id_as_per_name() throws Exception
	{
		utilisation.clickOnOrganizationdropDownddisabled();
		
		
        
    }
	
	@Then("Validate Organization Name and if field is disabled on Utilisation report page")
    public void select_the_salesforce_id_as_per_nam() throws Exception
	{
		utilisation.OrganizationNamefield();
		
		
        
    }
	
	
	@Then("Click on Search Button on Utilisation report page")
	public void clickonSearchButton() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		
		utilisation.clickOnsearchbutton();
	 }
	
	@Then("Click on Search Button in Organization Unit Filters on Utilisation report page")
	public void clickon_SearchButton() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		
		utilisation.clickOn_searchbutton();
	 }
	   @Then("click on Organization unit filter option on Utilisation report page")
	   public void click_on_course_filter_option_on_progress_report_page() 
	   {
		   utilisation.clickorgUnitFilter();
	   }

	   
	   @Then("single select institute level filter status on Utilisation report page {string}")
	   public void single_select_org_level_filter_status_on_progress_report_page(String course) {
		   utilisation.selectSingleOrgLevelFilter(course);
		   utilisation.validateOrgLevelFilterFilterAvailability();
	   }
	   
	   @Then("multi select institute level filter status on Utilisation report page {int}")
	   public void multi_select_org_level_filter_status_on_progress_report_page(int count) {
		   
		   for(int i = 0; i < count; i++) {
			   utilisation.selectMultiOrgLevelFilter();	
		   }
		   utilisation.validateOrgLevelFilterFilterAvailability();
	   }
	   
	   @Then("unSelect all institute level filter status on Utilisation report page")
	   public void un_select_all_org_level_filter_status_on_progress_report_page() {
		   utilisation.unSelectAllOrgLevelFilter();
		   utilisation.validateOrgLevelFilterFilterAvailability();
//		   utilisation.clickOnMoreFilterSearchButton();
	   }

	   @Then("select all institute level filter status on Utilisation report page")
	   public void select_all_org_level_filter_status_on_progress_report_page() {
		   utilisation.selectAllOrgLevelFilter();
		   utilisation.validateOrgLevelFilterFilterAvailability();
//		   utilisation.clickOnMoreFilterSearchButton();
	   }
	   
	   @Then("Validate Utilisation Table on Utilisation report page")
		public void view_error_log_failedrow_andvalidateebook(DataTable table) {
			
		   
			
			System.out.println(table.height());
			for(int j=1;j<table.height();j++)
			for(int i=0;i<table.width();i++)
				utilisation.validateUtilisationTable (table.column(i).get(0),table.column(i).get(j),TestBase.prop.get("orgName").toString());
			
		}

	   @And("Validate From and To date placeholder")
	   public void validateFromandToDatePlaceholder() {
		   utilisation.validFromDatePlaceHolder();
//		   utilisation.validateOrgLevelFilterFilterAvailability();
		   utilisation.validToDatePlaceHolder();
//		   utilisation.clickOnMoreFilterSearchButton();
	   }
	   
	   
	   @And("Validate placeholder for OrgName Field")
	   public void validate_placeholder_for_orgname_field() {
		   utilisation.validateOrgFieldPlaceHolder();
//		   utilisation.validateOrgLevelFilterFilterAvailability();
//		   utilisation.validToDatePlaceHolder();
//		   utilisation.clickOnMoreFilterSearchButton();
	   }
	   
	   @And("Validate placeholder for Level 2 filter Field")
	   public void validate_placeholder_for_filter() {
		   utilisation.validateLevel2PlaceHolder();
//		   utilisation.validateOrgLevelFilterFilterAvailability();
//		   utilisation.validToDatePlaceHolder();
//		   utilisation.clickOnMoreFilterSearchButton();
	   }
	   
	   @And("Validate placeholder for Level 3 filter Field")
	   public void validate_placeholder_Level_3for_filter() {
		   utilisation.validateLevel2PlaceHolder();
//		   utilisation.validateOrgLevelFilterFilterAvailability();
//		   utilisation.validToDatePlaceHolder();
//		   utilisation.clickOnMoreFilterSearchButton();
	   }
	   
	   @And("Validate placeholder for product Field")
	   public void validate_placeholder_for_product_field() {
		   utilisation.validatePlaceHolderProduct();
//		   utilisation.validateOrgLevelFilterFilterAvailability();
//		   utilisation.validToDatePlaceHolder();
//		   utilisation.clickOnMoreFilterSearchButton();
	   }
	   
	   @And("Validate placeholder for product Field {string}")
	   public void validate_placeholder_for_product_field(String text) {
		   utilisation.validatePlaceHolderProduct(text);
//		   utilisation.validateOrgLevelFilterFilterAvailability();
//		   utilisation.validToDatePlaceHolder();
//		   utilisation.clickOnMoreFilterSearchButton();
	   }
	   
	   
		@And("validate tool tip {string}")
	    public void validate_PseudoAnonymization_tip(String toolTip) throws Exception
	    {
//	        orgDetails = new OrganizationDetails();
	        utilisation.validate_toolTip(toolTip);
	       
	    }
		
		@Then("Select end date as Today \\(today's date should be disable)")
		public void select_end_date_as_Today() {
			
//			utilisation.validFromDateValue();
			utilisation.validEndDateValueasToday();
		}
		
		
		@Then("Select from date before 19 Oct 2023 \\(date should be disable)")
		public void select_from_date_19_oct() {
			
//			utilisation.validFromDateValue();
			utilisation.validFromDateValuebefore();
		}

		
		@Then("Select from date before org created date \\(date should be disable)")
		public void select_from_date_before_prgCreateddate() {
			
//			utilisation.validFromDateValue();
			utilisation.validFromDateValuebeforeorgcreatedDate();
		}

		
		@Then("validate Table Header Utilization report")
		public void validateTableHeader(DataTable table) {
			
//			utilisation.validFromDateValue();
			utilisation.validateHeaderfor_subscription_reportHeader(table.asList());
		}

		
		
		

		@Then("Click on Clear on Utilisation report page")
		public void clickonclear() 
		{
			utilisation.clickonClear();
		}
		
		@Then("Click on checkbox on Utilisation report page")
		public void clickonclearcheckbox() 
		{
			utilisation.clickonClear();
		}
		
		@Then("get the number of unit {string}")
		public void clickonclear(String unitnme) 
		{
			utilisation.get_unit_level(unitnme);
		}
		  @And("validate the number of filter for filter {int}")
		   public void validate_placeholder_for_filtr(int size) {
			   utilisation.validatetheoption(size);
//			   selectunitfilter
		  }
		  
		  
		  @And("Validate the number of filter {int}")
		   public void validate_placeholder_for_fiter(int size) {
			   utilisation.validateNumber(size);
//			   selectunitfilter
		  }
		  
		  @And("enter unit name {string} in unit filter {int}")
		   public void validate_placeholder_for_filter(String unitname,int size) {
			   utilisation.selectunitfilter(size,unitname);
//			   selectunitfilter
		  }
		  
		  @And("validate placeholder in unit filter {int}")
		   public void validate_placeholder_for_filter(int size) {
			   utilisation.selectPlaceholderunitfilter(size);
//			   selectunitfilter
		  }
		  
		  
		  @And("enter select all unit name in unit filter {int}")
		   public void validate_placeholderfor_filter(int size) {
			   utilisation.selectunitfilter(size);
//			   selectunitfilter
		  }
		  
		  @And("Validate the select all is disabled filter {int}")
		   public void validate_placeholder_fr_filter(int size) {
			   utilisation.selectshouldbedisable(size);
//			   selectunitfilter
		  }
		  
		  
		  @And("Validate the select all if removed filter {int}")
		   public void validate_placeholder_fr_filterremoved(int size) {
			   utilisation.selectshouldberemove(size);
//			   selectunitfilter
		  }
		  
		  @And("Validate the label Show direct utilization count and description")
		   public void validate_placeholder_fr_filterremoved() {
			   utilisation.validatelabel();
//			   selectunitfilter
		  }
		  
		  @And("Validate the Show direct utilization count is disabled")
		   public void validate_paceholder_fr_filterremoved() {
			   
			  Assert.fail("test");
			  //Vini added validation code for this
			  utilisation.validatelabel();
//			   selectunitfilter
		  }
		  
		  
		  @And("By Default select will be unchecked for show direct utilization count")
		   public void byDefault() {
			   utilisation.Bydefault();
//			   selectunitfilter
		  }
		  
		  
		  @Then("Validate Utilisation Table using Excel on Utilisation report page for dataset {string}")
			public void viw_error_log_failedrow_andvalidateebook(String keyset) {
				
			   
					
					utilisation.validateUtilisationTable (keyset);
				
			}

}
