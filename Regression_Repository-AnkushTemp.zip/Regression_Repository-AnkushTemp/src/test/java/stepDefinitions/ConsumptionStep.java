package stepDefinitions;

import org.openqa.selenium.By;

import com.qa.pages.Compliance;
import com.qa.pages.ConsumptionReport;
import com.qa.pages.OrganizationSetting;
import com.qa.pages.ProgressReport;
import com.qa.pages.Students;
import com.qa.pages.User;
import com.qa.pages.UserManagement;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import junit.framework.Assert;


public class ConsumptionStep {

	ConsumptionReport comReport= new ConsumptionReport();
	UserManagement userM=new UserManagement();
	Students std;
static	String contractNumber;
static	String ConsumptionQTY,contractQTY;
	@Then("Validate Message {string}")
	@Then("Validate Error Message {string}")
	public void navigate_to_compliance_report_page(String message) 
	{
	   
		comReport.validateLabel(message);
	    
	}
	
	@Then("select the salesforce id as per name")
    public void select_the_salesforce_id_as_per_name()
    {
        if(comReport == null)
        	comReport = new ConsumptionReport();
        comReport.selectSalesForceIDByName();
    }
	@Then("export the global consumption report and validate the details {int}")
	public void export_the_global_consumption_report_and_validate_the_details(int productCount) 
	{
		std = new Students();
		comReport = new ConsumptionReport();
		boolean flag = comReport.checkCSVFilePresent();
		if(flag == true)
			std.deleteFile(ConsumptionReport.filePath);
		System.out.println("Other files are deleted if available");
		comReport.clickExportButton();
		comReport.verifyDownloadFile();
		comReport.validateReportData(productCount);
	}
	@Then("select all details from dropdown")
	public void select_all_details_from_dropdown() 
	{
		comReport.selectSalesForceID();
		comReport.selectOrganizationID();
		comReport.selectProduct();
	}
	
	@Then("delete the consumption report")
	public void delete_the_consumption_report() 
	{
		if(std == null)
			std = new Students();
	    std.deleteFile(ConsumptionReport.filePath);
	}
	@Then("Click on Search Button")
	public void clickonSearchButton() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		
		comReport.clickOnsearchbutton();
	   }
	@Then("navigate to consumption report page")
	public void navigate_to_consumption_report_page() 
	{
		comReport = new ConsumptionReport();
		comReport.navigateConsumptionReport();
	}
	@Then("export the report and validate the details {int}")
	public void export_the_report_and_validate_the_details(int productCount) 
	{
		std = new Students();
		boolean flag = comReport.checkCSVFilePresent();
		if(flag == true)
			std.deleteFile(ConsumptionReport.filePath);
		System.out.println("Other files are deleted if available");
		comReport.clickExportButton();
		comReport.verifyDownloadFile();
		comReport.validateReportData(productCount);
	}
	@Then("validate the total contract quantity {int} and total consumed quantity {int}")
	public void validate_the_total_contract_quantity_and_total_consumed_quantity(int contractQuantity, int totalQuantity) 
	{
		comReport.validateTotalContract(contractQuantity);
	    comReport.validateTotalConsumed(totalQuantity);
	}
	@Then("validate the consumed license count as {int} with course name {string}")
	public void validate_the_consumed_license_count_as_with_course_name(Integer count, String courseName) 
	{
		comReport.validateConsumedWithCourseName(courseName, count);
	}
	@Then("select the dates")
	public void select_the_dates() throws InterruptedException 
	{
		comReport.clickStartDate();
		comReport.selecftDate();
	    comReport.clickEndDate();
	    comReport.selectDate();
	}
	@Then("get values of contract quantity and consumed quantity")
	public void get_values_of_contract_quantity_and_consumed_quantity() 
	{
		comReport.getTotalContract();
		comReport.getTotalConsumed();
	}
	@Then("select the dates in Global Consumption Report")
	public void select_the_datesin_Global_Consumption_Report() throws InterruptedException 
	{
		comReport.clickStartDateinglobal();
		comReport.selecftDate();
	    comReport.clickEndDateinglobal();
	    comReport.selectDateinglobal();
	}
	@Then("get values of contract quantity and consumed quantity for all product")
	public void get_values_of_contract_quantity_and_consumed_quantityall() 
	{
		comReport.getTotalContractAllproduct();
		comReport.getTotalConsumedallproduct();
	}
	@Then("select all products from dropdown")
	public void select_all_products_from_dropdown() 
	{
		comReport.selectAllProducts();
	}
	@Then("Click on Search")
	public void clickonSearch() 
	{
		userM.clickSearch();
	}
	@Then("Click on Search Report")
	public void clickonSearh() 
	{
		userM.clickSearchBtn();
	}
	
	
	
	@Then("Print number of Contract Quantity")
	public void printNumberofContract() throws InterruptedException 
	{
		comReport.printContract();
	    
	}
	@Then("Click on Clear")
	public void clickonclear() 
	{
		comReport.clickonClear();
	}
	@Then("Select From date {string} from date {string}")
	public void selectfromdate(String date,String fdate) 
	{

				comReport.selectfromdate(date,fdate );
	}

	@Then("Select SFID {string}")
	public void selectSFID(String text) 
	{

				comReport.selectSFID( text);
	}
	@Then("Select Ordid {string}")
	public void selectOrdid(String text) 
	{

				comReport.selectOrgid( text);
	}
	@Then("Select product Name {string}")
	public void selectpoductName(String text) 
	{

				comReport.selectproductName( text);
	}

	@Then("Validate Details Table {string}")
	public void validateDetailTable(String text) throws InterruptedException 
	{

				comReport.validateDetailTable( text);
	}
	@Then("Validate Contract Qty {string}")
	public void validateContractQty(String course) throws InterruptedException 
	{

				;
				Assert.assertEquals(Integer.parseInt(comReport.getContractQty( course)), Integer.parseInt(contractNumber)+1);
	}
	

	@Then("Validate Contract Qty {string} in product History")
	public void validateContractQtyin_Product(String course) throws InterruptedException 
	{
		System.out.println(contractQTY);
				;
				System.out.println(comReport.getContractQtyproductHistory( course));
							Assert.assertEquals(Integer.parseInt(comReport.getContractQtyproductHistory( course)), Integer.parseInt(contractQTY)+1);
	}
	
	@Then("Validate Contract Qty {string} in Consumption Report")
	public void validateContractQtyin_ProductConsumption(String course) throws InterruptedException 
	{
		   if(comReport.getContractQtyConsumptionReport( course).equals("NA"))
		   {
				Assert.assertEquals(0, Integer.parseInt(contractQTY));
		   }
		   else
				Assert.assertEquals(Integer.parseInt(comReport.getContractQtyConsumptionReport( course)), Integer.parseInt(contractQTY));
				   
				;
	}
	
	@Then("Validate Contract Qty {string} in Global Consumption Report")
	public void validateContractQtyin_ProductConsumtion(String course) throws InterruptedException 
	{
		   if(comReport.getContractQtyGlobalConsumptionReport( course).equals("NA"))
		   {
				Assert.assertEquals(0, Integer.parseInt(contractQTY));
		   }
		   else
				Assert.assertEquals(Integer.parseInt(comReport.getContractQtyGlobalConsumptionReport( course)), Integer.parseInt(contractQTY));
				   
				;
	}
	
	@Then("Validate Consumption Qty {string} in Global Consumption Report")
	public void validateContractQtyinProuctConsumption(String course) throws InterruptedException 
	{
					
				Assert.assertEquals(Integer.parseInt(comReport.getQtyGlobalConsumptionReport( course)), Integer.parseInt(ConsumptionQTY)+1);
	}
	
	
	
	
	@Then("Validate Consumption Qty is not changed for {string} in Consumption Report")
	public void validateContractQtyinroductConsumption(String course) throws InterruptedException 
	{
					
				Assert.assertEquals(Integer.parseInt(comReport.getQtyConsumptionReport( course)), Integer.parseInt(ConsumptionQTY));
	}
	
	@Then("Validate Contract Qty is not changed for {string} in Consumption Report")
	public void validateContractQtyin_roductConsumption(String course) throws InterruptedException 
	{
		   if(comReport.getContractQtyConsumptionReport( course).equals("NA"))
		   {
				Assert.assertEquals(0, Integer.parseInt(contractQTY));
		   }
		   else
				Assert.assertEquals(Integer.parseInt(comReport.getContractQtyConsumptionReport( course)), Integer.parseInt(contractQTY));
				   
				;
	}
	
	

	@Then("Validate Contract Qty is not changed for {string} in Global Consumption Report")
	public void validateContractQtyin_ProductConsution(String course) throws InterruptedException 
	{
		   if(comReport.getContractQtyGlobalConsumptionReport( course).equals("NA"))
		   {
				Assert.assertEquals(0, Integer.parseInt(contractQTY));
		   }
		   else
				Assert.assertEquals(Integer.parseInt(comReport.getContractQtyGlobalConsumptionReport( course)), Integer.parseInt(contractQTY));
				   
				;
	}
	
	
	
	
	@Then("Validate Consumption Qty is not changed for {string} in Global Consumption Report")
	public void validateContractQtyinProuctConsuption(String course) throws InterruptedException 
	{
					
				Assert.assertEquals(Integer.parseInt(comReport.getQtyGlobalConsumptionReport( course)), Integer.parseInt(ConsumptionQTY));
	}
	
	
	@Then("Validate Consumption Qty {string} in Consumption Report")
	public void validateContractQtyinProductConsumption(String course) throws InterruptedException 
	{
					
				Assert.assertEquals(Integer.parseInt(comReport.getQtyConsumptionReport( course)), Integer.parseInt(ConsumptionQTY)+1);
	}
	
	
	@Then("Validate Consumption Qty {string} in multiple product in Consumption Report")
	public void validateContractQtyinProductConsumptionmultiple(String courses) throws InterruptedException 
	{
		 String course[] = courses.split(",");
		    for(int i = 0; i <= course.length-1; i++)
		    {	
				Assert.assertEquals(Integer.parseInt(comReport.getQtyConsumptionReport( course[i])), Integer.parseInt(comReport.getMapConsumptionReport( course[i]))+1);

		    }
	}
	
	@Then("Validate if Consumption Qty it not changed {string} in multiple product in Consumption Report")
	public void validateContractQty_inProductConsumptionmultiple(String courses) throws InterruptedException 
	{
		 String course[] = courses.split(",");
		    for(int i = 0; i <= course.length-1; i++)
		    {	
				Assert.assertEquals(Integer.parseInt(comReport.getQtyConsumptionReport( course[i])), Integer.parseInt(comReport.getMapConsumptionReport( course[i])));

		    }
	}
	
	
	@Then("Validate Consumption Qty {string} in multiple product in Global Consumption Report")
	public void validateContractQtyinProuctConsumptioGlobaln(String courses) throws InterruptedException 
	{
		
		 String course[] = courses.split(",");
		    for(int i = 0; i <= course.length-1; i++)
		    {	
				Assert.assertEquals(Integer.parseInt(comReport.getQtyGlobalConsumptionReport( course[i])), Integer.parseInt(comReport.getMapGlobalConsumptionReport( course[i]))+1);
		    }
   }
	
	
	@Then("Validate Consumption Qty {string} in Consumption Report new org")
	public void validateContractQtyinProductConsumptionn(String course) throws InterruptedException 
	{
						contractNumber="0";
				;
				Assert.assertEquals(Integer.parseInt(comReport.getQtyConsumptionReport( course)), Integer.parseInt(contractNumber)+1);
	}
	 
	@Then("Validate if Consumption Qty is zero for course {string}")
	public void validateContractQtyinProductConsumptionzero(String course) throws InterruptedException 
	{
				Assert.assertEquals(Integer.parseInt(comReport.getQtyConsumptionReport( course)), 0);
	}
	
	 
	
	@Then("get current Contract qty {string}")
	public void getcurrent(String qty) throws InterruptedException 
	{

		contractQTY=	comReport.getContractQty( qty);
		if(contractQTY.contains("NA"))
			contractQTY="0";
		System.out.println(contractQTY);
	}
	
	@Then("get current Contract qty {string} in product screen")
	public void getcurrentp(String qty) throws InterruptedException 
	{

		contractQTY=	comReport.getContractQtyproduct( qty);
		if(contractQTY.contains("NA"))
			contractQTY="0";
		System.out.println(contractQTY);
	}
	
	@Then("Validate Contract Qty {string} in product screen")
	public void validateContractQtyproduct(String course) throws InterruptedException 
	{
		System.out.println(comReport.getContractQtyproduct( course));
		System.out.println(contractQTY);
		
				;
				Assert.assertEquals(Integer.parseInt(comReport.getContractQtyproduct( course)), Integer.parseInt(contractQTY)+1);
	}
	@Then("get current Consumption qty {string}")
	public void getConsumptioncurrent(String course) throws InterruptedException 
	{

		ConsumptionQTY=	comReport.getQtyConsumptionReport( course);
		System.out.println(ConsumptionQTY);
	}
	
	@Then("get current Consumption qty {string} in multiple product")
	public void getConsumptioncurrentmultipleProduct(String courses) throws InterruptedException 
	{

		  String course[] = courses.split(",");
		    for(int i = 0; i <= course.length-1; i++)
		    {
		comReport.getQtyConsumptionReport(course[i],course[i]);
	
		    }
	}
	
	@Then("get current Contract qty {string} in Global Consumption Report")
	public void getcurren(String qty) throws InterruptedException 
	{

		contractQTY=	comReport.getContractQtyGlobalConsumptionReport( qty);
		System.out.println(contractQTY);
	}
	
	@Then("get current Consumption qty {string} in Global Consumption Report")
	public void getConsumptioncurret(String course) throws InterruptedException 
	{

		ConsumptionQTY=	comReport.getQtyGlobalConsumptionReport( course);
		System.out.println(ConsumptionQTY);
	}
	
	
	@Then("get current Consumption qty {string} in multiple product for Global Consumption Report")
	public void getConsumptioncurretGlobal(String courses) throws InterruptedException 
	{

		 String course[] = courses.split(",");
		    for(int i = 0; i <= course.length-1; i++)
		    {
		comReport.getQtyGlobalConsumptionReport(course[i],course[i]);
		    }
		System.out.println(ConsumptionQTY);
	}
	@Then("validate current Consumption qty {string}")
	public void validatecurrent(String product) throws InterruptedException 
	{
		if(product.contains("NA"))
			Assert.assertEquals("NA", "NA");
		else
		Assert.assertEquals(Integer.parseInt(comReport.getQtyConsumptionReport( product)), Integer.parseInt(comReport.getQtyConsumptionReport(product))+1);

	}
	@Then("Verify pagination Functionality for consumption report grid")
	public void verify_pagination_functionality_for_consumption_report_grid() throws InterruptedException {
		comReport.verifypagination_consumptionreport();
	   
	}
	@Then("validate and compare the total contract quantity and total consumed quantity difference {int}")
	public void validate_and_compare_the_total_contract_quantity_and_total_consumed_quantity_difference(int number) 
	{
		comReport.compareTotalContract();	
		comReport.compareTotalConsumed(number);
	}


	@Then("validate and compare the total contract quantity and total consumed quantity is zero")
	public void validateand_compare_the_total_contract_quantity_and_total_consumed_quantity_difference() 
	{
		comReport.getTotalConsumed();
		comReport.getTotalContract();
		Assert.assertEquals(0, comReport.oldTotalCount);
		comReport.getTotalConsumed();
		Assert.assertEquals(0, comReport.oldTotalConsumed);
		
	}

	@Then("select the org id")
    public void select_the_org_id()
    {
        if(comReport == null)
        	comReport = new ConsumptionReport();
        comReport.selectAllOrganizationID();
    }
    
    @Then("select all the available product")
    public void select_all_the_available_product()
    {
        if(comReport == null)
        	comReport = new ConsumptionReport();
        comReport.selectProduct();
    }
    
    @Then("click on search button")
    public void click_on_search_button()
    {
        if(comReport == null)
        	comReport = new ConsumptionReport();
        comReport.clickSearchButton();
    }
    
    @Then("validate the search result")
    public void validate_the_search_result()
    {
        if(comReport == null)
        	comReport = new ConsumptionReport();
        comReport.validateSummary();
        comReport.validateEntries();
        comReport.pagination();
        comReport.validateHeader();
    }
    
    @Then("validate future date is disabled")
    public void validate_future_date_is_disabled()
    {
        if(comReport == null)
        	comReport = new ConsumptionReport();
        int day = comReport.getDay(1, "days");
        comReport.clickStartDate();
        comReport.validateDisableDate(day);
        comReport.clickEndDate();
        comReport.validateDisableDate(day);
    }
    
    @Then("validate past date is not allowed")
    public void validate_past_date_is_not_allowed()
    {
        if(comReport == null)
        	comReport = new ConsumptionReport();
        int day = comReport.getDay(0, "days");
        comReport.clickStartDate();
        comReport.selectDate(day);
        day = comReport.getDay(-1, "days");
        comReport.clickEndDate();
        comReport.validateDisableDate(day);
    }
    @Then("validate the search result on consumptiom report page")
    public void validate_the_search_result_on_consumptiom_report_page()
    {
        if(comReport == null)
        	comReport = new ConsumptionReport();
        comReport.validateSummary();
        comReport.validateEntries();
        comReport.pagination();
        comReport.validateHeaderOrgAdmin();
    }
    
	@Then("validate product dropdown is multiple select")
	public void validate_product_dropdown_is_multiple_select() {
		if(comReport == null)
			comReport = new ConsumptionReport();
		comReport.validateProductMultipleSelect();
	}
    @Then("validate no records available on consumption report page")
	public void validate_no_records_available() 
	{
		if(comReport == null)
			comReport = new ConsumptionReport();
		comReport.validateNoReportGenerated();
	}

    @And("verify the columns order in consumption Report")
	public void verify_the_columns_order_in_comReport_Report(DataTable data) throws Exception 
	{
		comReport.consumptionStatusColumnsValidation(data.asList(),"beforeSearch");
	}
    
    @Then("validate number of rows display {int} in consumption Report")
	public void validate_multiplecourse_isnot_available(int count)
	{
    	comReport.validaterow(count);
		
	}
    @Then("Click on Clear in Global Consumption Report")
	public void clickonclearinGlobalConsumptionReport() 
	{
		comReport.clickonClearGlobal();
	}

    @Then("click on search button in Global Consumption Report")
    public void click_on_search_buttonGlobalConsumptionReport()
    {
        if(comReport == null)
        	comReport = new ConsumptionReport();
        comReport.clickSearchButtonGlobalConsumptionReport();
    }
    @Then("Select Orgid {string}")
	public void selectOrgid(String text) 
	{
    	comReport.selectOrgid( text);
	}
	
	@Then("click on org unit and validate the popup")
	public void click_on_org_unit_and_validate_the_popup() {
		if(comReport == null)
			comReport = new ConsumptionReport();
		comReport.clickUnitLinkAndValidatePopup();
	}
	@Then("select the date range for {int} {string}")
    public void select_the_date_range_for(Integer range, String duration)
    {
        if(comReport == null)
        	comReport = new ConsumptionReport();
        int day = comReport.getDay(range, duration);
        comReport.clickStartDate();
        comReport.selectDate(day);
        day = comReport.getDay(0, "days");
        comReport.clickEndDate();
        comReport.selectDate(day);    
    }

	@Then("select the date range for {int} {string} in Global Consumption Report")
    public void select_the_date_range_forin_Global_Consumption_Report(Integer range, String duration)
    {
        if(comReport == null)
        	comReport = new ConsumptionReport();
        int day = comReport.getDay(range, duration);
        comReport.clickStartDateinglobal();
        comReport.selectDateGlobl(day);
        day = comReport.getDay(0, "days");
        comReport.clickEndDateinglobal();
        comReport.selectDateGlobl(day);    
    }

	  @Then("validate future date is disabled in Global Consumption Report")
	    public void validate_future_date_isConsumption_disabled()
	    {
	        if(comReport == null)
	        	comReport = new ConsumptionReport();
	        int day = comReport.getDay(1, "days");
	        comReport.clickStartDateinglobal();
	        comReport.validateDisableDate(day);
	        comReport.clickEndDateinglobal();
	        comReport.validateDisableDate(day);
	    }
	@Then("validate salesforce id dropdown is single select")
	public void validate_salesforce_id_dropdown_is_single_select() {
		if(comReport == null)
			comReport = new ConsumptionReport();
		comReport.validateSalesForceIDSingleSelect();
	}
	

	@Then("validate organization dropdown is single select")
	public void validate_organization_dropdown_is_single_select() {
		 if(comReport == null)
	        	comReport = new ConsumptionReport();
		 comReport.validateOrganizationSingleSelect();
	}
	

	@Then("validate organization level dropdown is single select")
	public void validate_organization_level_dropdown_is_single_select() {
		if(comReport == null)
			comReport = new ConsumptionReport();
		comReport.validateOrgLevelSingleSelect();
	}
	
	@Then("validate the org level and unit name dropdown")
	public void validate_the_org_level_and_unit_name_dropdown() {
		if(comReport == null)
			comReport = new ConsumptionReport();
		comReport.selectOrgLevelDropdown();
	}
	@Then("validate and compare the total contract {string} and consumed quantity {string} for all product")
	public void get_values_of_contract_quantity_and_consumed_quantityall(String cquantity,String consumedQty) 
	{
		comReport.getTotalContractAllproduct(cquantity);
		comReport.getTotalConsumedallproduct(consumedQty);
	}
	@Then("export and validate the details on consumption report page")
	public void export_and_validate_the_details() 
	{
			User	usr = new User();
			
			
			Students	std = new Students();
			boolean flag = usr.checkCSVFilePresent();
			if(flag == true)
				std.deleteFile(Students.filePath);
//			comp.clickExportButton();
//		    comp.verifyDownloadFile();

		 comReport.clickExportButton();
		comReport.verifyDownloadFile();
		comReport.compareDetails();
	}
	
}
