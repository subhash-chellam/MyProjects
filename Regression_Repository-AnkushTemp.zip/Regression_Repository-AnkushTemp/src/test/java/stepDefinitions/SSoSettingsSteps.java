package stepDefinitions;

import com.qa.pages.ReportEncryption;
import com.qa.pages.SSOSetting;
import io.cucumber.java.en.Then;

public class SSoSettingsSteps 
{
	SSOSetting sso;
	ReportEncryption report;

	@Then("generate the SSO setting")
	public void generate_the_sso_setting() 
	{
	    sso = new SSOSetting();
	    sso.clickOnSSOTab();
	    sso.clickOnGenerateButton();
	    sso.closeTab();
	}
	
	
	@Then("select The value from Head Content {string}")
	public void selectThevaluefromHeadContent(String value) {
		sso = new SSOSetting();
		report = new ReportEncryption();
		report.selectThevaluefromHeadContent(value);
		
	}
	
}
