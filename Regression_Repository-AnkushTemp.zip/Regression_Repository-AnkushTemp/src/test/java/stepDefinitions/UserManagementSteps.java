package stepDefinitions;

import java.util.Set;

import org.testng.Assert;

import com.mysql.cj.jdbc.Driver;
import com.qa.pages.DashBoard;
import com.qa.pages.EndUser;
import com.qa.pages.OrganizationDetails;
import com.qa.pages.Products;
import com.qa.pages.User;
import com.qa.pages.UserManagement;
import com.qa.util.TestBase;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;

public class UserManagementSteps extends TestBase
{
	UserManagement usrMg;
	EndUser end;
	DashBoard db;

	@Then("search the user by email")
	public void search_the_user_by_email() 
	{
//		User.userEmail="20221109175554010@yopmail.com";
//		User.userId="2022-11-08 19:21:38";
//	
		usrMg = new UserManagement();
	    usrMg.searchByEmail(User.userEmail);
	 
//		usrMg.searchByEmail("20221108164910010@yopmail.com");
	    usrMg.clickSearch();
	}
	
	@Then("search the user by email {int} from list")
	public void search_the_user_by_email(int i) 
	{
//		User.userEmail="20221109175554010@yopmail.com";
//		User.userId="2022-11-08 19:21:38";
//	
		usrMg = new UserManagement();
	    usrMg.searchByEmail(User.usrEmail[i-1]);
	 
//		usrMg.searchByEmail("20221108164910010@yopmail.com");
	    usrMg.clickSearch();
	}


	@Then("launch the multiple course as per the name {string} with one topic left")
	public void launch_the_multiple_course_as_per_the_name_with_one_topic_left(String coursesName)
	{
		if(end == null)
			end = new EndUser();
	    usrMg.switchTab();
	    String name[] = coursesName.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	boolean flag = end.launchCourseWithName(name[i]);
	    	if(flag == true)
		    {
	    		 end.clickOnSubmitOnly();
	    		 int count = end.getNumberRows();
	    		 System.out.println("count is " + count);
	    		 if(count > 1)
	    		 {
	    		    while(count>1)
	    		    {
	    		    	end.startORResumeCourse();
	    		    	end.completeCourse();
	    			    end.onlyExitCourse();
	    			    count = end.getTopicAvaialble();
	    		    }
	    		 }
	    		 else
	 	    	{
	 	    		end.startORResumeCourse();
	 	    		end.onlyExitCourse();
	 		    }
	    		 end.clickEndUserMyCoursesLink();
		    }
	    	
	    }
		    usrMg.switchTab();
		    usrMg.closeOtherTab();
	}
	@Then("launch the multiple course as per the name {string} with only one topic")
	public void launch_the_multiple_course_as_per_the_name_with_only_one_topic(String coursesName)
	{
		if(end == null)
			end = new EndUser();
	    usrMg.switchTab();
	    String name[] = coursesName.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	boolean flag = end.launchCourseWithName(name[i]);
	    	if(flag == true)
		    {
	    		 end.clickOnSubmitOnly();
	    		 end.startORResumeCourse();
	    		 end.getVendorSharableId();
				 end.onlyExitCourse();

		    }
	    	
	    }
		    usrMg.switchTab();
		    usrMg.closeOtherTab();
	}

	@Then("Validate table details {string}")
	public void validate_table_details(String table) throws InterruptedException 
	{
		usrMg = new UserManagement();
	    usrMg.validateTable(table);
	
	    
	}
	@Then("switch and close other tab")
	public void switch_and_close_other_tab() 
	{
		if(usrMg == null)
			usrMg = new UserManagement();
		usrMg.switchTab();
		usrMg.closeOtherTab();
	}
	
	@Then("click on manage courses button")
	public void click_on_manage_courses_button() {
	  usrMg = new UserManagement();
	  usrMg.clickManagecoursesbutton();
	}
	@Then("Click on Add Course Button")
	public void ClickonAddCourse() {
	  usrMg = new UserManagement();
	  usrMg.clickaddcoursesbutton();
	}
	
	@Then("Select Course {string}")
	public void selectCourse(String course) {
	  usrMg = new UserManagement();
	  usrMg.selectCourse(course);
	}
@Then("click on topics and mark set as completed")
	public void click_on_topics_and_mark_set_as_completed() {
		 usrMg = new UserManagement();
		  usrMg.clickTopicsbutton();
		  usrMg.clicksetascompleted();
	}

@Then("click on topics for {string} and mark set as completed")
public void click_on_topics_and_mark_set_as_completed(String Course) {
	 usrMg = new UserManagement();
	  usrMg.clickTopicsbutton(Course);
	  usrMg.clicksetascompleted();
}

@Then("validate Assign Date")
public void validate_Assign_Date() {
	if(end == null)
		end = new EndUser();
 end.validateAssignDate();
}


	@Then("enter the remediation review {string}")
	public void enter_the_remediation_review(String string) {
		 usrMg = new UserManagement();
		  usrMg.remediationreview(string);
	}
	@Then("complete the multiple whole courses online {string} as per the date {string}")
	public void complete_the_multiple_whole_course_as_per_the_date_online(String names, String courseDate) 
	{
		if(end == null)
			end = new EndUser();
	    usrMg.switchTab();
	    String name[] = names.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
//	    	end.runScriptForPastDate(courseDate);
		    boolean flag = end.launchCourseWithName(name[i]);
		    System.out.println(flag);
		    if(flag == true)
		    {
		    	end.clickOnSubmitOnlyWithDate();
//			    int count = end.getNumberRows();
//			    System.out.println("count is " + count);
//			    for(int j =1; j <= count; j++)
//			    {
			    	end.startORResumeCourseOnline();
//			    	end.completeCourse();
				    end.onlyExitCourse();
				    
			    }
			    end.clickEndUserProgramLink();
		    }
		    
	    }
	
	@Then("complete the multiple whole courses online {string} as per the date {string} as Student")
	public void complete_the_multiple_whole_course_as_per_the_date_online_as_Student(String names, String courseDate) 
	{
		if(end == null)
			end = new EndUser();
//	    usrMg.switchTab();
	    String name[] = names.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
//	    	end.runScriptForPastDate(courseDate);
		    boolean flag = end.launchCourseWithName(name[i]);
		    System.out.println(flag);
		    if(flag == true)
		    {
		    	end.clickOnSubmitOnlyWithDate();
//			    int count = end.getNumberRows();
//			    System.out.println("count is " + count);
//			    for(int j =1; j <= count; j++)
//			    {
			    	end.startORResumeCourseOnline();
//			    	end.completeCourse();
				    end.onlyExitCourse();
				    
			    }
			    end.clickEndUserProgramLinkonline();
		    }
		    
	    }
	@Then("navigate to proxy user page")
	@Then("navigate to end user page")
	public void navigate_to_end_user_page() 
	{
		if(usrMg == null)
			usrMg = new UserManagement();
	    usrMg.selectProxyUser();
	}
	
	@Then("Validate if No record found in End User Portal")
	public void check_no_() 
	{
		if(usrMg == null)
			usrMg = new UserManagement();
	    usrMg.endUser_Norecordsfound();
	}
	@Then("complete the course and get topic list")
	public void complete_the_course_and_topic_list() 
	{
	    end = new EndUser();
	    usrMg.switchTab();
	    end.launchUserCourse1();
	    end.clickOnSubmitOnly();
	    int count = end.getNumberRows();
	    System.out.println("count is " + count);
	    for(int i =1; i <= count; i++)
	    {
	    	end.startORResumeCourse();
	    	end.completeCourse();
		    end.onlyExitCourse();
		    
	    }
	    usrMg.switchTab();
	    usrMg.closeOtherTab();
	}
	@Then("launch the course with name {string}")
	public void launch_the_course_with_name(String name)
	{
	if(end == null)
	end = new EndUser();
	end.launchCourseWithName(name);
	end.clickOnSubmitOnly();
	}
	
	@Then("Validate Course Status as {string} and Button as {string} for {string} course")
	public void launch_the_course_with_names(String status,String btn,String name)
	{
	if(end == null)
	end = new EndUser();
	end.validateCourseStatus(status,name,btn);
	
	}
	
	
	@Then("Validate Button as {string} for {string} course")
	public void launch_the_Button_with_names(String btn,String name)
	{
	if(end == null)
	end = new EndUser();
	end.validateCourseStatusOrgPay(name,btn);
	
	}
	
	
	@Then("complete the course")
	public void complete_the_course() 
	{
	    end = new EndUser();
	    usrMg.switchTab();
	    end.launchUserCourse1();
	    end.clickOnSubmitOnly();
	    int count = end.getNumberRows();
	    System.out.println("count is " + count);
	    for(int i =1; i <= count; i++)
	    {
	    	end.startORResumeCourse();
	    	end.completeCourse();
		    end.onlyExitCourse();
		    
	    }
	    usrMg.switchTab();
	    usrMg.closeOtherTab();
	}
	
	@Then("complete the course name {string}")
	public void complete_the_course(String course) 
	{
	    end = new EndUser();
	    usrMg.switchTab();
	    end.launchCourseWithName(course);
	    end.clickOnSubmitOnly();
	    int count = end.getNumberRows();
	    System.out.println("count is " + count);
	    for(int i =1; i <= count; i++)
	    {
	    	end.startORResumeCourse();
	    	end.completeCourse();
		    end.onlyExitCourse();
		    
	    }
	    usrMg.switchTab();
	    usrMg.closeOtherTab();
	}
	
	@Then("Launch the course with {string} without exit the course with {string}")
	public void Launch_the_course_with_name_with_exit_course(String course,String courseDate) 
	{
	    end = new EndUser();
	    usrMg.switchTab();
	    end.launchCourseWithName(course);
	    end.clickOnSubmitOnlyWithDate(courseDate);
		
	    int count = end.getNumberRows();
	    System.out.println("count is " + count);
	   
	    	end.startORResumeCourse();

	}
	
	@Then("Exit from course")
	public void Exit_From_course() 
	{
		end = new EndUser();
	   
	      end.onlyExitCourse();
	}
	
	@Then("activate the course")
	public void activate_the_course() 
	{
		end = new EndUser();
	    usrMg.switchTab();
	    end.launchUserCourse1();
	    end.clickOnSubmitOnly();
	    usrMg.switchTab();
	    usrMg.closeOtherTab();
	}
	@Then("activate the course name {string}")
	public void activatethe_course(String course) 
	{
		end = new EndUser();
	    usrMg.switchTab();
	    end.launchCourseWithName(course);
	    end.clickOnSubmitOnly();
	    usrMg.switchTab();
	    usrMg.closeOtherTab();
	}
	
	@Then("navigate to organization page")
	public void navigate_to_organization_page() 
	{
		if(usrMg == null)
			usrMg = new UserManagement();
	    db = new DashBoard();
	    usrMg.navigateDashboard();
	    db.selectOrgpanel();
	}

	@Then("Validate Ends On {int} year and Completed {string}")
	public void validateEndsOn_year_and_completed(int year,String day) 
	{
	    end.validateEndOnAndComplete(year,day);
	}

	@Then("complete the course topics as per the date {string}")
	public void complete_the_course_topics_as_per_the_date(String courseDate) 
	{
		end = new EndUser();
	    usrMg.switchTab();
	    end.runScriptForPastDate(courseDate);
	    end.launchUserCourse1();
	    end.clickOnSubmitOnlyWithDate(courseDate);
	    int count = end.getAvailableTopicNumber();
	    System.out.println("count is " + count);
	    for(int i =1; i <= count; i++)
	    {
	    	end.startORResumeCourse();
	    	end.completeCourse();
		    end.onlyExitCourse();
		    
	    }
	    
	}
	@Then("Review the completed courses and ecard {string}")
	public void review_the_completedcourses(String q1) 
	{
		if(end == null)
			end = new EndUser();
	    end.navigateCompletedPrograms();
	    end.clickOnCompletedCourseReviews();
	    end.clickOnSubmitOnlyWithDate(q1);
	    end.clickOnCompletedCourseEcard();
	    end.clickEndUserProgramLink();
	}
	@Then("Review the completed courses {string} and ecard {int}")
	public void review_the_completed_courses(String course,int q1) 
	{
		if(end == null)
			end = new EndUser();
	    end.navigateCompletedPrograms();
	    end.clickOnCompletedCourseReviews(course);
	    String date = end.changeDate(q1);
	    end.clickOnSubmitOnlyWithDate(date);
	    end.clickOnCompletedCourseEcard(course);
	    end.clickEndUserProgramLink();
	}
	
	@Then("{string} Course should be available in Completed Tab")
	public void review_the_completed_availablecourses(String course) 
	{
		if(end == null)
			end = new EndUser();
	    end.navigateCompletedPrograms();
	    end.validateCourseiscompleted(course);
	   
	}
	@Then("Review the completed {string} courses ecard and Certificate if applicable {int}")
	public void review_the_completedcourses(String course,int q1) 
	{
		if(end == null)
			end = new EndUser();
	    end.navigateCompletedPrograms();
	    end.clickOnCompletedCourseReviews(course);
	    String date = end.changeDate(q1);
	    end.clickOnSubmitOnlyWithDate(date);
	    end.clickOnCompletedCourseEcard(course);
	    end.clickOnCompletedCourseCertificate(course);
	    end.clickEndUserProgramLink();
	}
	
	@Then("Click on View Ecard for {string} course")
	public void click_on_view_ecard(String course) 
	{
		if(end == null)
			end = new EndUser();
	    end.navigateCompletedPrograms();
	    end.clickOnCompletedCourseViewEcard(course);
	    end.clickOnViewEcard(course);
	  
	}
	
	@Then("View Ecard is not present for {string} course")
	public void view_ecard_is_not_present_for(String course) 
	{
		if(end == null)
			end = new EndUser();
	    end.navigateCompletedPrograms();
	    end.view_ecard_is_not_present(course);
	  	  
	}
	
	@Then("Click on View Ecard Link for {string} course")
	public void click_on_view_ecardBtn(String course) 
	{
		if(end == null)
			end = new EndUser();
	    end.navigateCompletedPrograms();
	    end.clickOnCompletedCourseViewEcardLinkinLogin(course);
	    end.clickOnViewEcard(course,3);
	  
	}
	
	@Then("Click on View Ecard Link for {string} course in proxy user")
	public void click_on_view_ecardBtnproxy(String course) 
	{
		if(end == null)
			end = new EndUser();
	    end.navigateCompletedPrograms();
	    end.clickOnCompletedCourseViewEcardLink(course);
	    end.clickOnViewEcard(course);
	  
	}
	
	@Then("Select Filter {string} status")
	public void select_filter_status(String status) 
	{
		if(end == null)
			end = new EndUser();
	    end.selectFilterstatus(status);
	  
	}
	
	@Then("Select Filter {string} status in Completed Tab")
	public void select_filter_status_Completed_Tab(String status) 
	{
		if(end == null)
			end = new EndUser();
	    end.selectFilterstatusInCompleteTab(status);
	  
	}
	
	
	@Then("Validate if Expire date {string} in Current Tab")
	public void validate_if_Expire_date_in_current_tab(String status) 
	{
		if(end == null)
			end = new EndUser();
	    end.validateExpiresDateInCurrnetTab(status);
	  
	}
	
	@Then("Validate if Subscribed present in Current Tab")
	public void validate_if_Expire_date_in_current_tab() 
	{
		if(end == null)
			end = new EndUser();
	    end.SubscribedOnCompletedTab();
	  
	}
	
	
	@Then("Validate if Subscribed present in Current Tab for {string} course")
	public void validate_if_Subscribed_date_in_current_tab(String course) 
	{
		if(end == null)
			end = new EndUser();
	    end.SubscribedOnCompletedTab(course);
	  
	}
	
	
	
	@Then("Validate if Expire date {string} in Current Tab for {int} month")
	public void validate_if_Expire_date_in_current_tab(String status,int month) 
	{
		if(end == null)
			end = new EndUser();
	    end.validateExpiresDateInCurrnetTab(status,month);
	  
	}
	
	@Then("Validate if Expire date {string} in Current Tab for {int} month for {string} course")
	public void validate_if_Expire_date_in_current_tab(String status,int month,String course) 
	{
		if(end == null)
			end = new EndUser();
	    end.validateExpiresDateInCurrnetTab(status,month,course);
	  
	}
	
	@Then("Validate if Expire date {string} in Completed Tab")
	public void validate_if_Expire_date_in_Completed_tab(String status) 
	{
		if(end == null)
			end = new EndUser();
	    end.validateExpiresDateInCompleteTab(status);
	  
	}
	
	@Then("Validate if {string} Course is in Completed Tab")
	public void validate_if_e_in_Completed_tab(String course) throws InterruptedException 
	{
		if(end == null)
			end = new EndUser();
	    end.validateIfCourseIsAvalble(course);
	  
	}
	
	@Then("Review the completed {string} courses and Review the Course on Course Completion for {int} quarter")
	public void review_the_completedcourses2(String course,int q1) 
	{
		if(end == null)
			end = new EndUser();
	    end.navigateCompletedPrograms();
	    end.clickOnCompletedCourseReviews(course);
	    String date = end.changeDate(q1);
	    end.clickOnSubmitOnlyWithDate(date);
	    end.clickOncompletedActivitiesButton();
		  
	    end.validateIfReviewtheCourse(date);
	    end.clickEndUserProgramLink();
	}
	
	@Then("Review the completed {string} courses Certificate {int}")
	public void review_the_Certificatecompletedcourses(String course,int q1) 
	{
		if(end == null)
			end = new EndUser();
	    end.navigateCompletedPrograms();
	    end.clickOnCompletedCourseReviews(course);
	    String date = end.changeDate(q1);
	    end.clickOnSubmitOnlyWithDate(date);
	    end.clickOnCompletedCourseCertificate(course);
	    end.clickEndUserProgramLink();
	}
	
	
	@Then("complete the whole course as per the date {string}")
	public void complete_the_whole_course_as_per_the_date(String courseDate) 
	{
		end = new EndUser();
	    usrMg.switchTab();
	    end.runScriptForPastDate(courseDate);
	    end.launchUserCourse1();
	    end.clickOnSubmitOnlyWithDate(courseDate);
	    int count = end.getNumberRows();
	    System.out.println("count is " + count);
	    for(int i =1; i <= count; i++)
	    {
	    	end.startORResumeCourse();
	    	end.completeCourse();
		    end.onlyExitCourse();
		    
	    }
	    usrMg.switchTab();
	    usrMg.closeOtherTab();
	}
	@Then("user activate course as name {string} with quarter {int}")
    public void click_on_activate_course_as_name(String courseName, int quarter)
    {
        if(end == null)
        	end = new EndUser();
        end.launchCourseWithName(courseName);
        String date = end.changeDate(quarter);
        end.runScriptForPastDate(date);
        end.clickOnSubmitOnlyWithDate(date);
        end.clickEndUserProgramLink();
    }
	@Then("switch the tab")
	public void switch_the_tab()
	{
		if(usrMg == null)
			usrMg = new UserManagement();
		usrMg.switchTab();
	   
	}
	
	@Then("switch the tab to user")
	public void switch_the_tab_to_user()
	{
		if(usrMg == null)
			usrMg = new UserManagement();
		usrMg.switchTab();
	}
	
	@Then("switch the tab to scrom")
	public void switch_the_tab_to_scrom()
	{
		if(usrMg == null)
			usrMg = new UserManagement();
		usrMg.switchTab();
	}
	
	@Then("navigate to user programs")
	public void navigate_to_user_programs() 
	{
		if(end == null)
			end = new EndUser();
	    end.clickEndUserProgramLink();
	}
	
	@Then("Give the date {string} for the course")
	public void give_the_date_for_the_course(String date) 
	{
		end = new EndUser();
		end.runScriptForPastDate(date);
	    end.launchUserCourse1();
	    end.clickOnSubmitOnlyWithDate(date);
	}
	
	@Then("Give the date {int} for the course")
	public void give_the_date_for_the_course(int q) 
	{
		end = new EndUser();
		 String date = end.changeDate(q);
		end.runScriptForPastDate(date);
	    end.launchUserCourse1();
	    end.clickOnSubmitOnlyWithDate(date);
	}
	

	@Then("Give the date {int} for the course {string}")
	public void give_the_date_for_the_course(int q,String course) 
	{
		end = new EndUser();
		 String date = end.changeDate(q);
		end.runScriptForPastDate(date);
	    end.launchCourseWithName(course);
	    end.clickOnSubmitOnlyWithDate(date);
	}
	@Then("activate the course as per the date {string}")
	public void activate_the_course_as_per_the_date(String date) 
	{
		if(end == null)
			end = new EndUser();
	    usrMg.switchTab();
	    end.runScriptForPastDate(date);
	    end.launchUserCourse1();
	    end.clickOnSubmitOnlyWithDate(date);
	    usrMg.switchTab();
	    usrMg.closeOtherTab();
	}
	@Then("view ecard from course topic page")
	public void view_ecard_from_course_topic_page() 
	{
    if(end == null)
    	end = new EndUser();
    end.clickEcardButton();
    end.switchToCertificatePage();
    end.clickviewCertficateButtonPage();
    end.switchToPDFPage();
	}
	@Then("switch to application tab and close other")
	public void switch_to_application_tab_and_close_other() 
	{
		end.switchToApplicationPage();
	}

	@Then("user launch course as name {string} with quarter {int}")
    public void click_on_launch_course_as_name_with_quarter(String courseName, int quarter)
    {
        if(end == null)
        	end = new EndUser();
        end.launchCourseWithName(courseName);
        String date = end.changeDate(quarter);
        end.runScriptForPastDate(date);
        end.clickOnSubmitOnlyWithDate(date);
        end.startORResumeCourse();
        end.onlyExitCourse();
        end.clickEndUserProgramLink();
    }
	@Then("validate the course {string} topics are locked as per the quarter date {int}")
    public void validate_the_course_topics_are_locked_as_per_the_quarter_date(String courses, Integer quarter)
    {
        if(end == null)
        	end = new EndUser();
        String name[] = courses.split(",");
        for(int i = 0; i <= name.length-1; i++)
        {
            String date = end.changeDate(quarter);
            end.runScriptForPastDate(date);
            boolean flag = end.launchCourseWithName(name[i]);
             if(flag == true)
                {
            	 end.clickOnSubmitOnlyWithDate(date);
                    int lockCount = end.validateAvailableTopicLocked();
                    System.out.println("count is " + lockCount);
                    Assert.assertTrue(lockCount >= 1);
                }
             end.clickEndUserProgramLink();
        }
    }

	@Then("complete the multiple whole courses {string} as per the date {string}")
	public void complete_the_multiple_whole_course_as_per_the_date(String names, String courseDate) 
	{
		if(end == null)
			end = new EndUser();
	    usrMg.switchTab();
	    String name[] = names.split(",");
	    
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	
	    	end.runScriptForPastDate(courseDate);
		    boolean flag = end.launchCourseWithName(name[i]);
		    System.out.println(flag);
		    if(flag == true)
		    {
		    	
		    	end.clickOnSubmitOnlyWithDate(courseDate);
			    int count = end.getNumberRows();
			    System.out.println("count is " + count);
			    for(int j =1; j <= count; j++)
			    {
			    	end.startORResumeCourse();
//			    	end.completeCourse();
			    	end.completeCourseTestCode();
				    end.onlyExitCourse();
				    
			    }
			    end.clickEndUserProgramLink();
		    }
		    
	    }
	}
	
	@Then("complete the multiple whole courses {string} as per the date {string} as Student")
	public void complete_themultiple_whole_course_as_per_the_date(String names, String courseDate) 
	{
		if(end == null)
			end = new EndUser();
//	    usrMg.switchTab();
	    String name[] = names.split(",");
	    
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	
	    	end.runScriptForPastDate(courseDate);
		    boolean flag = end.launchCourseWithName(name[i]);
		    System.out.println(flag);
		    if(flag == true)
		    {
		    	end.clickOnSubmitOnlyWithDate(courseDate);
			    int count = end.getNumberRows();
			    System.out.println("count is " + count);
			    for(int j =1; j <= count; j++)
			    {
			    	end.startORResumeCourse();
			    	end.completeCourseTestCode();
				    end.onlyExitCourse();
				    
			    }
			    end.cecmepopup(name[i]);
			    end.clickEndUserProgramLink();
		    }
		    
	    }
	}
	
	@Then("complete the multiple whole courses {string} as per the date {string} as Student and close CE CME popup")
	public void complete_themultiple_whole_course_as_per_the_dateCE(String names, String courseDate) 
	{
		if(end == null)
			end = new EndUser();
//	    usrMg.switchTab();
	    String name[] = names.split(",");
	    
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	
	    	end.runScriptForPastDate(courseDate);
		    boolean flag = end.launchCourseWithName(name[i]);
		    System.out.println(flag);
		    if(flag == true)
		    {
		    	end.clickOnSubmitOnlyWithDate(courseDate);
			    int count = end.getNumberRows();
			    System.out.println("count is " + count);
			    for(int j =1; j <= count; j++)
			    {
			    	end.startORResumeCourse();
			    	end.completeCourseTestCode();
				    end.onlyExitCourse();
				    
			    }
			    end.closececmepopup();
			    end.clickEndUserProgramLink();
		    }
		    
	    }
	}
	
	@Then("complete the multiple whole courses {string} as per the date {string} close {string}")
	public void complete_the_multiple_whole_course_as_per_the_date(String names, String courseDate,String close) 
	{
		if(end == null)
			end = new EndUser();
	    usrMg.switchTab();
	    String name[] = names.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	end.runScriptForPastDate(courseDate);
		    boolean flag = end.launchCourseWithName(name[i]);
		    System.out.println(flag);
		    if(flag == true)
		    {
		    	end.clickOnSubmitOnlyWithDate(courseDate);
			    int count = end.getNumberRows();
			    System.out.println("count is " + count);
			    for(int j =1; ;)
			    {
			    	end.startORResumeCourse();
			    	end.completeCourse();
			    	
			    	j++;
			    		if(j <= count)
			    		{
			    			  end.onlyExitCourse();
					 		
			    		}
			    		else
			    		{
			    			if(close.contains("closeWithoutExit"))
			    		{
			    					    			break;
			    		}
			    			else
			    			{
			    				end.onlyExitCourse();
			    				   break;
			    			}
			    		}
			    		
			    }
			    
			    if(close.contains("close"))
		    	{
	    		 TestBase.driver.close();
	    			Set <String> allWindowHandles = TestBase. driver.getWindowHandles();
	    			System.out.println(allWindowHandles.size());
	    			TestBase.driver.switchTo().window(allWindowHandles.toArray()[0].toString());
	    		
	    			
		    		break;
		    	}
	    	
	    	
			   
			    
			   
		    }
		    
	    }
	    
	   
	}
	
	@Then("complete the multiple courses {string} topics as per the date {string}")
	public void complete_the_multiple_course_topics_as_per_the_date(String names, String courseDate) 
	{
		if(end == null)
			end = new EndUser();
	    String name[] = names.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	end.runScriptForPastDate(courseDate);
		    boolean flag = end.launchCourseWithName(name[i]);
		    System.out.println(flag);
		    if(flag == true)
		    {
		    	end.clickOnSubmitOnlyWithDate(courseDate);
			    int count = end.getAvailableTopicNumber();
			    System.out.println("count is " + count);
			    for(int j =1; j <= count; j++)
			    {
			    	end.startORResumeCourse();
//			    	end.completeCourse();
			    	end.completeCourseTestCode();
				    end.onlyExitCourse();
				    
			    }
			    end.evaluateCourse();
			    end.clickEndUserProgramLink();
		    }
		    
	    }
	}
	@Then("Resume and complete the multiple courses {string} topics as per the date {string}")
	public void complete_themultiple_scourse_topics_as_per_the_date(String names, String courseDate) 
	{
		if(end == null)
			end = new EndUser();
//		usrMg.switchTab();
	    String name[] = names.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	end.runScriptForPastDate(courseDate);
		    boolean flag = end.launchCourseWithNameResume(name[i]);
		    System.out.println(flag);
		    if(flag == true)
		    {
		    	end.clickOnSubmitOnlyWithDate(courseDate);
			    int count = end.getAvailableTopicNumber();
			    System.out.println("count is " + count);
			    for(int j =1; j <= count; j++)
			    {
			    	end.startORResumeCourse();
			    	end.completeCourse();
				    end.onlyExitCourse();
				    
			    }
			    end.evaluateCourse();
			    end.clickEndUserProgramLink();
		    }
		    
	    }
	
	}
	@Then("activate the multiple course as per the name {string}")
	public void activate_the_multiple_course_as_per_name(String coursesName) 
	{
		if(end == null)
			end = new EndUser();
	    usrMg.switchTab();
	    String name[] = coursesName.split(",");
	    System.err.println("testttt");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	end.startCourseWithName(name[i]);
	    }
	    System.err.println("testttt");
		    usrMg.switchTab();
		    usrMg.closeOtherTab();
	}
	@Then("launch the multiple whole courses {string} as per the quarter date {int}")
	public void launch_the_multiple_whole_courses_as_per_the_quarter_date(String names, int quarter) 
	{
		if(end == null)
			end = new EndUser();
		String name[] = names.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	String date = end.changeDate(quarter);
	    	end.runScriptForPastDate(date);
	    	boolean flag = end.launchCourseWithName(name[i]);
		    System.out.println(flag);
		    if(flag == true)
		    {
		    	end.clickOnSubmitOnlyWithDate(date);
		    	int count = end.getAvailableTopicNumber();
			    System.out.println("count is " + count);
		    	end.startORResumeCourse();
			    end.onlyExitCourse();
			   }
			    end.clickEndUserProgramLink();
		    }
		    
	    }
	@Then("navigate to coure topic page as per name {string} with quarter {int}")
	public void navigate_to_coure_topic_page_as_per_name_with_quarter(String courses, Integer quarter) 
	{
		
		EndUser	proxy = new EndUser();
		String name[] = courses.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	String date = proxy.changeDate(quarter);
	    	proxy.runScriptForPastDate(date);
	    	boolean flag = proxy.launchCourseWithName(name[i]);
	    	 if(flag == true)
			    {
			    	proxy.clickOnSubmitOnlyWithDate(date);
			    }
	    }
	}
	@Then("give the date for completed course as per quarter {int}")
	public void give_the_date_for_completed_course(int quarter) 
	{
		String courseDate = end.changeDate(quarter);
		end.clickOnSubmitOnlyWithDate(courseDate);
	}
	@Then("navigate to manage course page")
	public void navigate_to_manage_course_page() 
	{
		if(end == null)
			end = new EndUser();
//		if(proxy == null)
//			proxy = new ProxyUser();
		end.clickEndUserProgramLink();
	}

	@Then("validate the error message for course launch as course name {string} with quarter {int}")
	public void validate_the_error_message_for_course_launch_as_course_name(String courseName, int quarter) 
	{
		
		EndUser	proxy = new EndUser();
		proxy.launchCourseWithName(courseName);
        String date = proxy.changeDate(quarter);
    	proxy.runScriptForPastDate(date);
        proxy.clickOnSubmitOnlyWithDate(date);
		proxy.validateCourseLaunchError();
	}
	 @Then("validate the UI details for proxy user")
		public void validate_the_ui_details_for_proxy_user() 
		{
		 if(end == null)
				end = new EndUser();
		 end.validateHeaderFooter();
		 end.validateMenuOption();
		 end.validateSupportOption();
		 end.validateWelcome();
		 end.validateSideMenuOption();
		}
	 
	 @Then("validate the links on page for proxy user")
		public void validate_the_links_on_page_for_proxy_user() 
		{
		 if(end == null)
				end = new EndUser();
		 end.validateResponseForLink();
		}
	    @Then("No programs available is displayed")
		@Then("validate the row count for active courses")
		public void validate_the_row_count_for_active_courses() 
		{
//			if(proxy == null)
//				proxy = new ProxyUser();
			end.courseNotAvaialble();
		}
		
	@Then("complete the multiple whole courses {string} as per the quarter date {int}")
	public void complete_the_multiple_whole_course_as_per_the_quarter_date(String names, int quarter)
	{
	if(end == null)
	end = new EndUser();
	if(usrMg == null)
		usrMg= new UserManagement();
	
	usrMg.switchTab();
	String name[] = names.split(",");
	for(int i = 0; i <= name.length-1; i++)
	{
	String date = end.changeDate(quarter);
	end.runScriptForPastDate(date);
	boolean flag = end.launchCourseWithName(name[i]);
	System.out.println(flag);
	if(flag == true)
	{
	end.clickOnSubmitOnlyWithDate(date);
	System.out.println(date);
	int count = end.getNumberRows();
	System.out.println("count is " + count);
	for(int j =1; j <= count; j++)
	{
	end.startORResumeCourse();
	end.completeCourseTestCode();
	end.onlyExitCourse();

	}
	end.clickEndUserProgramLink();
	}

	}
	}
	
	@Then("validate the error message for given course launch {string} with date {int}")
	public void validate_the_error_message_for_given_course_launch_with_date(String names, int quarter) 
	{
		if(end == null)
			end = new EndUser();
		String name[] = names.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	end.launchCourseWithName(name[i]);
	    	String date = end.changeDate(quarter);
		    end.clickOnSubmitOnlyWithDate(date);
		    end.validateCourseLaunchError();
		    end.clickEndUserProgramLink();
	    }
	}
	@Then("complete the multiple whole course {string} as per the quarter date {int}")
	public void complete_the_multiple_whole_cours_as_per_the_quarter_date(String names, int quarter)
	{
	if(end == null)
	end = new EndUser();
	if(usrMg == null)
		usrMg= new UserManagement();
	
	String name[] = names.split(",");
	for(int i = 0; i <= name.length-1; i++)
	{
	String date = end.changeDate(quarter);
	end.runScriptForPastDate(date);
	boolean flag = end.launchCourseWithName(name[i]);
	System.out.println(flag);
	if(flag == true)
	{
	end.clickOnSubmitOnlyWithDate(date);
	System.out.println(date);
	int count = end.getNumberRows();
	System.out.println("count is " + count);
	for(int j =1; j <= count; j++)
	{
	end.startORResumeCourse();
	end.completeCourseTestCode();
	end.onlyExitCourse();

	}
	  end.cecmepopup(name[i]);
	  end.evaluateCourse(name[i]);
	end.clickEndUserProgramLink();
	}

	}
	}
	@Then("complete the multiple whole course {string} as per the quarter date {int} for TRcourse")
	public void complete_the_multiple_whole_cours_as_per_the_quarter_dateforTr(String names, int quarter)
	{
	if(end == null)
	end = new EndUser();
	if(usrMg == null)
		usrMg= new UserManagement();
	
	String name[] = names.split(",");
	for(int i = 0; i <= name.length-1; i++)
	{
	String date = end.changeDate(quarter);
	end.runScriptForPastDate(date);
	boolean flag = end.launchCourseWithName(name[i]);
	System.out.println(flag);
	if(flag == true)
	{
	end.clickOnSubmitOnlyWithDate(date);
	System.out.println(date);
	int count = end.getNumberRows();
	System.out.println("count is " + count);
	for(int j =1; j < count; j++)
	{
	end.startORResumeCourse();
	end.completeCourseTestCode();
	end.onlyExitCourse();

	}
	  end.cecmepopup(name[i]);
	  end.evaluateCourse(name[i]);
	end.clickEndUserProgramLink();
	}

	}
	}
	
	@Then("launch the course with name {string} as per the quarter date {int} and validate ecard")
	public void launch_the_course_with_name(String name,int q)
	{
	if(end == null)
	end = new EndUser();
	end.clickOnCurrentPrograms();
	end.launchCourseWithName(name);
	String date = end.changeDate(q);
	end.clickOnSubmitOnlyWithDate(date);
	end.clickOnCompletedCourseEcard(name);
	 end.clickEndUserProgramLink();
	}

	@Then("Fetch the below Details for course {string} as per the quarter date {int} in view Order Details in Current Tab")
	@Then("launch the course with name {string} as per the quarter date {int} and view Order Details")
	public void launch_the_course_with_name_and_view_Order_Details(String name,int q,DataTable table)
	{
	if(end == null)
	end = new EndUser();
	end.clickOnCurrentPrograms();
	end.launchCourseWithName(name);
	String date = end.changeDate(q);
	end.clickOnSubmitOnlyWithDate(date);
	end.clickViewOrderBtn();
//	 end.clickEndUserProgramLink();
	 for(int j=0;j<table.height();j++)
		 end.validate_OrderDetail(table.column(0).get(j),table.column(1).get(j));
	 end.clickViewOrderCloseBtn();
	 end.clickEndUserProgramLink();
	}

	
	@Then("Fetch the below Details for multiple courses {string} as per the quarter date {int} in view Order Details in Current Tab")
	@Then("launch the multiple course with name {string} as per the quarter date {int} and view Order Details")
	public void launch_the_courses_with_name_and_view_Order_Details(String names,int q,DataTable table)
	{
	if(end == null)
	end = new EndUser();
	String name[] = names.split(",");
	for(int i = 0; i <= name.length-1; i++)
	{
	end.clickOnCurrentPrograms();
	end.launchCourseWithNameequal(name[i]);
	String date = end.changeDate(q);
	end.clickOnSubmitOnlyWithDate(date);
	end.clickViewOrderBtn();
//	 end.clickEndUserProgramLink();
	 for(int j=0;j<table.height();j++)
		 end.validate_OrderDetail(table.column(0).get(j),table.column(1).get(j),name[i]);
	 end.clickViewOrderCloseBtn();
	 end.clickEndUserProgramLink();
	}
	}
	@Then("launch the course with name {string} as per the quarter date {int} and Download Receipt in Current Tab")
	public void launch_the_course_in_completed_Tab_with_name_and_Download_Receipt_in_Cur(String name,int q)
	{
	if(end == null)
	end = new EndUser();
	end.clickOnCurrentPrograms();
	end.launchCourseWithName(name);
	String date = end.changeDate(q);
	end.clickOnSubmitOnlyWithDate(date);
	end.clickViewOrderBtn();
	 end.clickdownloadReceiptBtn();

		Boolean flag=	Products.isFileDownloaded_Ext (Products.downloadPath , ".pdf");

	    Assert.assertTrue(flag,"Error Order Receipt not found");;
	 end.clickEndUserProgramLink();
	}
	
	@Then("Fetch the below Details for course {string} as per the quarter date {int} in view Order Details")
	@Then("launch the course in completed tab with name {string} as per the quarter date {int} and view Order Details")
	public void launch_the_course_in_completed_Tab_with_name_and_view_Order_Details(String name,int q,DataTable table)
	{
	if(end == null)
	end = new EndUser();
	end.clickOnCompletedPrograms();
	  end.clickOnCompletedCourseReviews(name);
	String date = end.changeDate(q);
	end.clickOnSubmitOnlyWithDate(date);
	end.clickViewOrderBtn();
//	 end.clickEndUserProgramLink();
	 for(int j=0;j<table.height();j++)
		 end.validate_OrderDetail(table.column(0).get(j),table.column(1).get(j));
	 end.clickViewOrderCloseBtn();
	 end.clickEndUserProgramLink();
	}
	
	@Then("launch the course in completed tab with name {string} as per the quarter date {int} and Download Receipt")
	public void launch_the_course_in_completed_Tab_with_name_and_Download_Receopt(String name,int q)
	{
	if(end == null)
	end = new EndUser();
	end.clickOnCompletedPrograms();
	  end.clickOnCompletedCourseReviews(name);
	String date = end.changeDate(q);
	end.clickOnSubmitOnlyWithDate(date);
	end.clickViewOrderBtn();
	 end.clickdownloadReceiptBtn();

		Boolean flag=	Products.isFileDownloaded_Ext (Products.downloadPath , ".pdf");

	    Assert.assertTrue(flag,"Error Order Receipt not found");;
	 end.clickEndUserProgramLink();
	}
	
	@Then("launch the course with name {string} as per the quarter date {int}")
	public void launch_the_course_with_name_Cme(String name,int q)
	{
	if(end == null)
	end = new EndUser();
	end.clickOnCurrentPrograms();
	end.launchCourseWithName(name);
	String date = end.changeDate(q);
	end.clickOnSubmitOnlyWithDate(date);
	}
	@Then("complete the multiple courses {string} topics as per the quarter date {int}")
	public void complete_the_multiple_course_topics_as_per_the_quarter_date(String names, int quarter) throws InterruptedException
	{
	if(end == null)
	end = new EndUser();
	String name[] = names.split(",");
	for(int i = 0; i <= name.length-1; i++)
	{
	String date = end.changeDate(quarter);
	end.runScriptForPastDate(date);
	boolean flag = end.launchCourseWithName(name[i]);
	System.out.println(flag);
	if(flag == true)
	{
	end.clickOnSubmitOnlyWithDate(date);
	int count = end.getAvailableTopicNumber();
	System.out.println("count is " + count);
	
	for(int j =1; j <= count; j++)
	{
		Thread.sleep(5000);
		end.startORResumeCourse();
	end.completeCourseTestCode();
	end.onlyExitCourse();
	}
	end.clickEndUserProgramLink();
	}

	}
	}
	@Then("Launch the multiple courses {string} topics as per the date {string} with one topic left")
	public void Launch_the_multiple_course_topics_as_per_the_date_with_one_topic_left(String names, String courseDate) 
	{
		if(end == null)
			end = new EndUser();
	    String name[] = names.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	end.runScriptForPastDate(courseDate);
		    boolean flag = end.launchCourseWithName(name[i]);
		    System.out.println(flag);
		    if(flag == true)
		    {
		    	end.clickOnSubmitOnlyWithDate(courseDate);
			    int count = end.getAvailableTopicNumber();
			    System.out.println("count is " + count);
			    if(count > 1)
			    {
			    	for(int j =1; j <= count-1; j++)
				    {
				    	end.startORResumeCourse();
				    	end.completeCourse();
					    end.onlyExitCourse();
					    
				    }
			    }
			    else
			    {
			    	end.startORResumeCourse();
			    	end.completeCourse();
				    end.onlyExitCourse();
			    }
			    
			    end.clickEndUserProgramLink();
		    }
		    
	    }
	}
	
	
	@Then("complete the multiple courses {string} in quarter {int} with one topic left")
	public void Launch_the_multiple_course_topics_as_per_the_date_with_one_topic_left(String names, int quarter) 
	{
		if(end == null)
			end = new EndUser();
	    String name[] = names.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	String date = end.changeDate(quarter);
	    	end.runScriptForPastDate(date);
		    boolean flag = end.launchCourseWithName(name[i]);
		    System.out.println(flag);
		    if(flag == true)
		    {
		    	end.clickOnSubmitOnlyWithDate(date);
			    int count = end.getAvailableTopicNumber();
			    System.out.println("count is " + count);
			    if(count > 1)
			    {
			    	for(int j =1; j <= count-1; j++)
				    {
				    	end.startORResumeCourse();
				    	end.completeCourseTestCode();
					    end.onlyExitCourse();
					    
				    }
			    }
			    else
			    {
			    	end.startORResumeCourse();
//			    	end.completeCourseTestCode();
				    end.onlyExitCourse();
			    }
			    
			    end.clickEndUserProgramLink();
		    }
		    
	    }
	}

	@Then("delete the user on usermanagement screen")
	public void delete_the_user_on_usermanagement_screen() {
		if(usrMg == null)
			usrMg = new UserManagement();
		usrMg.deleteDearchedUser();
	}
	

	@Then("Subscribed and complete the Payment")
	public void Subscribed_and_complete() 
	{
		if(end == null)
			end = new EndUser();
	    end.subscribeBtn();
	    end.performPaymentAndSubscribe();
	    
	}
	
	@Then("Subscribed and complete the Payment and use different email Id")
	public void Subscribed_and_complete_and_use_different_email_Id() 
	{
		if(end == null)
			end = new EndUser();
		User.userEmail=User.getUserEmail();
	    end.subscribeBtn();
	    end.performPaymentAndSubscribe();
	    
	}
	
	
	@Then("Validate Subscription Expiration {int}")
	public void Subscribed_and_complete(int plan) 
	{
		if(end == null)
			end = new EndUser();
	    end.validate_subscriptionExpiration(plan);
	    
	}
	
	@Then("Validate Subscription plan valid until date on the Popup {int} Plan for course {string}")
	public void Subscribed_and_completevalid(int plan,String course) 
	{
		if(end == null)
			end = new EndUser();
	    end.validate_subscriptionvalid_until_date(course,plan);
	    
	}
	
	
	
	@Then("Validate Payment Required Label is present")
	public void payNowRequiredLabel() 
	{
		if(end == null)
			end = new EndUser();
	    end.payNowRequiredLabel();
	    
	}
	
	@Then("Validate Payment Required Label is present for {string} course")
	public void payNowRequiredLabel(String course) 
	{
		if(end == null)
			end = new EndUser();
	    end.payNowRequiredLabel(course);
	    
	}
	
	

	@Then("Entering Payment Details")
	public void Entering_payment_details() 
	{
		if(end == null)
			end = new EndUser();
	    end.subscribeBtn();
	    end.performPaymentAndSubscribeWithoutClickOnPayNow();
	    
	}



	

	@Then("Click on Subscribe Button")
	public void click_on_Subscribe_Button() 
	{
		if(end == null)
			end = new EndUser();
	    end.subscribeBtn();
	    
	}
	
	@Then("Click on Return To Merchant")
	public void click_returnToMerchant() 
	{
		if(end == null)
			end = new EndUser();
	    end.click_returnToMerchant();
	    
	}
	
	

	@Then("Validate Order Summary contains Price break-up of the course")
	public void validate_order_summary_contains_price_break_up_of_the_course(DataTable table) 
	{
		if(end == null)
			end = new EndUser();
		 for(int j=0;j<table.height();j++)
			 end.validate_order_summary(table.column(0).get(j),table.column(1).get(j));

	  
	    
	}
	@Then("Validate Billing Address")
	public void Validate_Billing_Address() 
	{
		if(end == null)
			end = new EndUser();
			 end.validate_Billing_Address();
	    
	}
	
	@Then("Validate Course Description {string}")
	public void Validate_Course_Description(String course) 
	{
		if(end == null)
			end = new EndUser();
			 end.validate_courseDescription(course);
	    
	}
	
	@Then("Validate Subscription Plan {string}")
	public void Validate_Subscription_plan(String plan) 
	{
		if(end == null)
			end = new EndUser();
			 end.validate_Subscription_Plan(plan);
	    
	}
	@Then("Click on Term and Condition and Validate Term and Condition")
	public void Validate_Subscription_plan() 
	{
		if(end == null)
			end = new EndUser();
			 end.clickonTermAndConditionnAndValidateTermandCondition();
	    
	}
	
	@Then("Click on Close Button Popup")
	public void click_on_close_button() 
	{
		if(end == null)
			end = new EndUser();
	    end.click_closeBtn();
	    
	}
	
	                  
	
	@Then("Click on Cancel and Go Back Btn")
	public void click_on_cancel_and_go_back() 
	{
		if(end == null)
			end = new EndUser();
	    end.click_cancel_order();
	    
	}
	
	@Then("Click on Launch Now Button in Popup")
	public void click_on_Launch_Now_button() 
	{
		if(end == null)
			end = new EndUser();
	    end.click_launch_NowBtn();
	    
	}
	
	@Then("Click on Order Receipt Button in Popup")
	public void click_on_Order_Receipt_button() 
	{
		if(end == null)
			end = new EndUser();
	    end.click_order_ReceiptBtn();;

		Boolean flag=	Products.isFileDownloaded_Ext (Products.downloadPath , ".pdf");

	    Assert.assertTrue(flag,"Error Order Receipt not found");;
	}
	
	@Then("Click on Order Receipt Button in Popup and dont delete pdf")
	public void click_on_Order_Receipt_buttondelete() 
	{
		if(end == null)
			end = new EndUser();
	    end.click_order_ReceiptBtn();;

		Boolean flag=	Products.isFileDownloaded_Ext_withoutDelete (Products.downloadPath , ".pdf");

	    Assert.assertTrue(flag,"Error Order Receipt not found");;
	}
	@Then("complete the topic for launched course as per the quarter date {int}")
	public void complete_the_topic_for_launched_course_as_per_the_quarter_date(int quarter)
	{
	if(end == null)
	end = new EndUser();
	if(usrMg == null)
		usrMg= new UserManagement();
	

	String date = end.changeDate(quarter);
   end.clickOnSubmitOnlyWithDate(date);
	System.out.println(date);
	int count = end.getNumberRows();
	Assert.assertNotEquals(count, 0);
	System.out.println("count is " + count);
	for(int j =1; j <= count; j++)
	{
	end.startORResumeCourse();
	end.completeCourseTestCode();
	end.onlyExitCourse();
	}
	end.clickEndUserProgramLink();
	
	}

	@Then("Subscribed and complete the Payment for {int} available courses")
	public void Subscribed_and_complete_for_all_available_courses(int number) 
	{
		if(end == null)
			end = new EndUser();
		for(int i = 1; i <= number; i++) {
		    end.subscribeBtn();
		    end.performPaymentAndSubscribeForSpartans(i);
		    end.click_closeBtn();
		}
	}
	
	@Then("Subscribed and complete the Payment for {string} courses")
	public void Subscribed_and_complete_for_all_available_courses(String courses) 
	{
		if(end == null)
			end = new EndUser();
		end.clickOnCurrentPrograms();
		    end.subscribeBtn(courses);
		    end.performPaymentAndSubscribe();

	}

	
	@Then("Subscribed and complete the Payment for {string} courses using different email")
	public void Subscribed_and_complete_for_all_available_coursesusing(String courses) 
	{
		if(end == null)
			end = new EndUser();
		
		    end.subscribeBtn(courses);
		  
		    end.performPaymentAndSubscribe(end.secondaryEmail);

	}

	
	@Then("navigate to topic list of course with name {string} as per the quarter date {int}")
	public void navigate_to_topic_list_of_course_with_name_Cme(String name,int q)
	{
	if(end == null)
	end = new EndUser();
	end.clickOnCurrentPrograms();
	end.launchNLNCourseWithName(name);
	String date = end.changeDate(q);
	end.clickOnSubmitOnlyWithDate(date);
	}

	@Then("validate the cancel and refund section under view order details with date {int} {string}")
	public void validate_the_cancel_and_refund_section_under_view_order_details_with_date(int dayCount, String dateType) {
		if(end == null)
			end = new EndUser();
		end.clickViewOrderBtn();
		end.validateCancelRefundSection(dayCount,dateType);
		 end.clickViewOrderCloseBtn();
		 end.clickEndUserProgramLink();
	}

	@Then("launch the whole courses {string} as per the quarter date {int}")
	public void launch_the_whole_courses_as_per_the_quarter_date(String names, int quarter) 
	{
		if(end == null)
			end = new EndUser();
		String date = end.changeDate(quarter);
    	end.runScriptForPastDate(date);
    	boolean flag = end.launchNLNCourseWithName(names);
	    System.out.println(flag);
	    if(flag == true)
	    {
	    	end.clickOnSubmitOnlyWithDate(date);
	    	int count = end.getAvailableTopicNumber();
		    System.out.println("count is " + count);
	    	end.startORResumeCourse();
		    end.onlyExitCourse();
		   }
	    }

	@Then("launch the multiple courses {string} and navigate back to list page as per the quarter date {int}")
	public void launch_the_multiple_courses_and_navigate_back_to_list_page_as_per_the_quarter_date(String names, int quarter) {
		if(end == null)
			end = new EndUser();
		 String name[] = names.split(",");
		    for(int i = 0; i <= name.length-1; i++)
		    {
		String date = end.changeDate(quarter);
    	end.runScriptForPastDate(date);
    	boolean flag = end.launchNLNCourseWithName(name[i]);
	    System.out.println(flag);
	    if(flag == true)
	    {
	    	end.clickOnSubmitOnlyWithDate(date);
	    	int count = end.getAvailableTopicNumber();
		    System.out.println("count is " + count);
	    	end.startORResumeCourse();
		    end.onlyExitCourse();
		   }
	    end.clickEndUserProgramLink();
		    }
	   }

	@Then("validate the cancel and refund section under view order details for launched course")
	public void validate_the_cancel_and_refund_section_under_view_order_details_for_launched_course() {
		if(end == null)
			end = new EndUser();
		end.clickViewOrderBtn();
		end.validateCancelRefundSectionForLaunchedCourse();
		 end.clickViewOrderCloseBtn();
		 end.clickEndUserProgramLink();
	}

	@Then("navigate to course list")
	public void navigate_to_course_list() {
	    end.clickEndUserProgramLink();
	}

	@Then("click on cancel subscription button from view order details page for proxy user")
	public void click_on_cancel_subscription_button_from_view_order_details_page_for_proxy_user() {
	    if(end == null)
	    	end = new EndUser();
	    end.clickViewOrderBtn();
	    end.clickOnCancelSubscriptionButtonForProxyUser();
	}

	@Then("validate the warning section on cancel page")
	public void validate_the_warning_section_on_cancel_page() {
		 if(end == null)
		    	end = new EndUser();
		    end.validateWarningHeadingCancelPage();
		    end.validateWarningTextCancelPage();
	}

	@Then("validate the error section on cancel page for count {int}")
	public void validate_the_error_section_on_cancel_page_for_count(Integer number) {
		 if(end == null)
		    	end = new EndUser();
		    end.validateErrorMessageWithCountCancelPage(number);
		    end.validateErrorListWithCountCancelPage(number);
	}

	@Then("click on cancel button from cancel page")
	public void click_on_cancel_button_from_cancel_page() {
		if(end == null)
	    	end = new EndUser();
	    end.clickCancelAndGoBackButton();
	}
	
	@Then("validate the view order details not available for course")
	public void validate_the_view_order_details_not_available_for_course() {
		if(end == null)
			end = new EndUser();
		end.validateViewOrderBtnUnavailable();
	}
	
	@Then("navigate to course list without refresh")
	public void navigate_to_course_list_without_refresh() {
//	    end.clickEndUserProgramLinkWithoutRefresh();
	}
	
	@Then("Fetch the topic list for course {string} as per the quarter date {int}")
	public void Fetch_the_course_with_name_and_view_Order_Details(String names,int q)
	{
	if(end == null)
	end = new EndUser();
	String name[] = names.split(",");
	for(int i = 0; i <= name.length-1; i++)
	{
	end.clickOnCurrentPrograms();
	end.launchCourseWithName(name[i]);
	String date = end.changeDate(q);
	end.clickOnSubmitOnlyWithDate(date);
    end.clickOncompletedActivitiesButton();
	
     end.getTopicList(name[i], date);
	 end.clickEndUserProgramLink();
	}
	}

	
	@Then("Fetch the topic list for course {string} as per the quarter date {int} in Completed Programs")
	public void Fetch_the_course_with_name_and_view_Order_DetailsCompletedPrograms(String names,int q)
	{
	if(end == null)
	end = new EndUser();
	String name[] = names.split(",");
	for(int i = 0; i <= name.length-1; i++)
	{
	 end.navigateCompletedPrograms();
	    end.clickOnCompletedCourseReviews(name[i]);
	    String date = end.changeDate(q);
	end.clickOnSubmitOnlyWithDate(date);
    end.clickOncompletedActivitiesButton();
	
     end.getTopicList(name[i], date);
	 end.clickEndUserProgramLink();
	}
	}
	
	@Then("navigate to edit user detail page")
	public void navigate_to_edit_user_detail_page() {
	   if(usrMg == null)
		   usrMg = new UserManagement();
	   usrMg.selectEditUser();
	}
	
	@Then("navigate to role details tab")
	public void navigate_to_role_details_tab() {
		if(usrMg == null)
			   usrMg = new UserManagement();
		   usrMg.selectRoleDetailsTab();
	}
	
	@Then("assign the {string} roles to the user")
	public void assign_the_roles_to_the_user(String roles) {
		if(usrMg == null)
			   usrMg = new UserManagement();
		String roleList[] = roles.split(",");
		for (String role : roleList) {
			usrMg.selectRole(role);
		}
	}
	
	@Then("search the main user")
	public void search_the_main_user() 
	{
		usrMg = new UserManagement();
	    usrMg.searchByEmail(prop.getProperty("userEmailId"+prop.getProperty("environment")));
	    usrMg.clickSearch();
	}
	
	@Then("get the organization name")
	public void get_the_organization_name() {
		if(usrMg == null)
			usrMg = new UserManagement();
		usrMg.getOrganizationName();
	}
	
	@Then("navigate to dashboard")
	public void navigate_to_dashboard() 
	{
		if(usrMg == null)
			usrMg = new UserManagement();
	    db = new DashBoard();
	    usrMg.navigateDashboard();
	}


}

