package stepDefinitions;

import com.qa.pages.DemographicTemplateSetting;
import com.qa.pages.IltReports;
import com.qa.pages.OrganizationHome;
import com.qa.pages.OrganizationSetting;
import com.qa.pages.Student;
import com.qa.pages.User;
import com.qa.util.TestBase;

import io.cucumber.java.en.Then;

public class DemographicTemplateSettingSteps {

	OrganizationHome orgHome;
	OrganizationSetting orgSet;
	DemographicTemplateSetting demoTempSet;
	User user;
	Student st;
	IltReports iltReport;


	@Then("click on Demographic template settings")
	public void click_on_Demographic_template_settings() {
		demoTempSet = new DemographicTemplateSetting();
		demoTempSet.clickDemographicTemplateSetting();
	}
	
	
	@Then("select encryption method")
	public void select_encryption_method() {
		demoTempSet = new DemographicTemplateSetting();
		demoTempSet.selectEncryptionMethod();
	}
	
	@Then("verify encryption method {string}")
	public void select_encryption_method(String message) {
		demoTempSet = new DemographicTemplateSetting();
		demoTempSet.verifySelectEncryptionMethod();
	}
	
	@Then("verify upload key must be disabled")
	public void verify_upload_key_must_be_disabled() {
		demoTempSet = new DemographicTemplateSetting();
		demoTempSet.verifyUploadKeyDisabled();
	}
	
	@Then("select the encryption method and verify upload key should be enabled")
	public void select_encryption_method_and_verify_upload_key_should_be_enabled() {
		demoTempSet = new DemographicTemplateSetting();
		demoTempSet.selectValueAndUploadEnabled();
	}
	
	@Then("enter valid group name in column header and click on add column with message {string}")
	public void enter_valid_group_name_in_column_header_and_click_on_add_column_with_message(String message) {
		demoTempSet = new DemographicTemplateSetting();
		demoTempSet.addColumn(message);
	}
	
	@Then("click on delete icon and click on delete button to delete with message {string}")
	public void click_on_delete_icon_and_click_on_delete_buttn_to_delete_with_message(String message) {
		demoTempSet = new DemographicTemplateSetting();
		demoTempSet.deleteColumn(message);
	}
	
	
	@Then("Click generate key and verify the success message {string}")
	public void Click_generate_key_and_verify_the_success_message(String message) {
		demoTempSet = new DemographicTemplateSetting();
		demoTempSet.generateKeyAndVerifySuccessMsg(message);
	}
	
	
	@Then("verify View Key link and click on View Key and close the popup")
	public void verify_view_key_link_and_click_on_view_key_and_close_the_popup() {
		demoTempSet = new DemographicTemplateSetting();
		demoTempSet.verifyViewKeyLinkAndClosePopup();
	}
	
	@Then("click generate new key and verify the success message {string}")
	public void click_generate_new_key_and_verify_the_success_message(String message) {
		demoTempSet = new DemographicTemplateSetting();
		demoTempSet.regenerateKeyAndVerifySuccessMsg(message);
	}
	
	
	@Then("click Remove encryption and verify the success message {string}")
	public void click_remove_encryption_and_verify_the_success_message(String message) {
		demoTempSet = new DemographicTemplateSetting();
		demoTempSet.removeEncryptionKeyAndVerifyMsg(message);
	}
	
	

	
	
}