package stepDefinitions;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import com.qa.pages.Admin;
import com.qa.util.ScreenCapture;
import com.qa.util.TestBase;
import io.cucumber.java.After;

//@RunWith(Cucumber.class)
public class hooksMethods extends TestBase
{
	ScreenCapture screen;
	
	//@After
    public void afterScenario()
	{
		try 
		{
			Admin.email = null;
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		//driver.quit();
    }
}
