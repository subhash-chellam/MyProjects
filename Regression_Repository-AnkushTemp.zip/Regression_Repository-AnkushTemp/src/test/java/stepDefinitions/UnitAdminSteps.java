package stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.qa.pages.Students;
import com.qa.pages.UnitAdmin;

import io.cucumber.java.en.Then;

public class UnitAdminSteps {

	UnitAdmin unit ;
	
	@Then("Click on user checkbox")
	public void clickOnUserCheckbox() 
	{
		unit = new UnitAdmin();
		unit.SelectUserIDCheckBox(); 
	}
	
	@Then("Check user checkbox is available")
	public void CheckUserCheckboxIsavailable() 
	{
		unit = new UnitAdmin();
		unit.CheckUserCheckboxIsavailable(); 
	}
	
	
	@Then("Verify {string} is exists in the list")
	public void downloaddemographic_report(String value) 
	{
		unit = new UnitAdmin();
		unit.Button_ActionItems();
		unit.SelectFromTheList(value);
		unit.Button_ActionItems();
	}
	
	@Then("click On Action DropDown and verify list contains {string}")
	public void clickOnActionDropDown(String DropdownValue) {
		unit = new UnitAdmin();
		unit.clickOnActionDropDown(DropdownValue);
	}
	
	@Then("check group Action")
	public void checkGroupAction() {
		unit = new UnitAdmin();
		unit.checkGroupAction();
	}
	
	@Then("check job title exists")
	public void checkEditJobTitle() {
		unit = new UnitAdmin();
		unit.checktitleExists();
	}
	
	@Then("check Available Options In OrgSettings Tab")
	public void checkAvailableOptionsInOrgSettingsTab() {
		unit = new UnitAdmin();
		unit.checkAvailableOptionsInOrgSettingsTab();
	}
	
	
	@Then("check job Title is enabled and Tabs in User details")
	public void checkjobTitleIsEnabled() {
		unit = new UnitAdmin();
		unit.checkTabsPresentInUserDetailsTab();
		unit.jobTitleIsEnabled();
	}
	
	
	@Then("check Delete User Is Present")
	public void checkDeleteUserIsPresent() {
		unit = new UnitAdmin();
		unit.checkDeleteUser();
	}
	
	
	@Then("Check all tabs is present in User Details Page")
	public void checkUserTabsIsPresent() {
		unit = new UnitAdmin();
		unit.checkTabsPresentInUserDetailsTab();
		unit.RemoveUser();
	}
	
	@Then("Check Url Contains my course")
	public void CheckUrlContains() {
		unit = new UnitAdmin();
		unit.CheckUrlContains();
	}
	
	@Then("Check all tabs is present for User Observer")
	public void checkUserTabsIsPresentForUnitObserver() {
		unit = new UnitAdmin();
		unit.checkTabsPresentInUserDetailsTab();
		
	}
	
	@Then("Check Assignment Button is Present")
	public void CheckAssignmentButtonIsPresent() {
		unit = new UnitAdmin();
		unit.createAssignment();
	}

	@Then("Check Assignment DropDown {string} is not Present")
	public void checkAssignmentDropDownIsPresent(String dropdownvalue) {
		unit = new UnitAdmin();
		unit.checkAssignmentDropDown(dropdownvalue);
	}
	
	@Then("Click On Action Button and Select value From list {string}")
	public void ClickOnActionButtonandSelectvalueFromlist(String dropdownvalue) {
		unit = new UnitAdmin();
		unit.ClickOnActionButtonandSelectvalueFromlist(dropdownvalue);
	}
	
	@Then("Check Dropdown Value Present In Usertable {string}")
	public void CheckDropdownValuePresentInUsertable(String dropdownvalue) {
		unit = new UnitAdmin();
		unit.CheckDropdownValuePresentInUsertable(dropdownvalue);
	}
	
	@Then("Check Dropdown Value not Present In Usertable {string}")
	public void CheckDropdownValuenotPresentInUsertable(String dropdownvalue) {
		unit = new UnitAdmin();
		unit.CheckDropdownValueNotPresentInUsertable(dropdownvalue);
	}

	
	@Then("select From Header tabs {string}")
	public void selectFromHeadertabs(String dropdownvalue) {
		unit = new UnitAdmin();
		unit.selectFromHeadertabs(dropdownvalue);
	}
	
	@Then("check value Present In DropDown value {string}")
	public void checkvaluePresentInDropDownvalue(String dropdownvalue) {
		unit = new UnitAdmin();
		unit.checkvaluePresentInDropDownvalue(dropdownvalue);
	}
	
	@Then("check value not Present In DropDown value {string}")
	public void checkvaluenotPresentInDropDownvalue(String dropdownvalue) {
		unit = new UnitAdmin();
		unit.checkvalueNotPresentInDropDownvalue(dropdownvalue);
	}
	
	@Then("Check Edit User Details Button exists")
	public void CheckEditUserDetails() {
		unit = new UnitAdmin();
		unit.CheckEditUserDetails();
	}
	
	@Then("click On Action Assignment")
	public void clickOnActionAssignment() {
		unit = new UnitAdmin();
		unit.clickOnActionAssignment();
	}
	
	@Then("View Group Details Text Is Present")
	public void ViewGroupDetailsText() {
		unit = new UnitAdmin();
		unit.ViewGroupDetailsText();
	}
	
	@Then("View Job Details Text Is Present")
	public void ViewJobTitleDetailsText() {
		unit = new UnitAdmin();
		unit.ViewJobTitleDetails();
	}
	
	@Then("Click on {string} Tab in edit\\/view user Screen")
	@Then("Select Link Org Tabs {string}")
	public void LinkOrgTabs(String value) {
		unit = new UnitAdmin();
		unit.LinkOrgTabs(value);
	}
	
	@Then("check Add To Group Button Exists In Group Tab")
	public void checkAddToGroupButtonExistsInGroupTab() {
		unit = new UnitAdmin();
		unit.checkAddToGroupButtonExistsInGroupTab();
	}
	
	@Then("check Options In User Group Tab {string}")
	public void checkOptionsInUserGroupTab(String value) {
		unit = new UnitAdmin();
		unit.mmgroupuser(value);
	}
	
	@Then("check view and delete In User Group Tab")
	public void checkOptionsInUserGroupTab() {
		unit = new UnitAdmin();
		unit.mmgroupuser();
	}
	
	@Then("Check dropdown values From list User Screen {string}")
	public void CheckdropdownvaluesFromlistuserScreen(String value) {
		unit = new UnitAdmin();
		unit.CheckdropdownvaluesFromlistuserScreen(value);
	}
	
	
	
	
	
	
	
	
	
	
	
}
