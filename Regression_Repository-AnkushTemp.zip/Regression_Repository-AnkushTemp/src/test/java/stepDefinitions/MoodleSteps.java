package stepDefinitions;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.qa.pages.Moodle;
import com.qa.pages.Products;
import com.qa.pages.Scrom;
import com.qa.pages.Students;
import com.qa.pages.User;
import com.qa.pages.UserManagement;

import io.cucumber.java.en.Then;

public class MoodleSteps {

	Moodle mood=new Moodle();
	Scrom scr = new Scrom();
	Products prod;
	static String parentOrg, packagePath, childOrg;
	
	@Then("user navigate to Moodle url")
	public void user_navigate_to_scrom_url() 
	{
	   
		mood.navigateToMoodleUrl();
	}

	@Then("Login as Moodle Admin")
	public void login_as_moodle_admin() 
	{
	   
		mood.loginasAdmin();
	}


	@Then("Login as Moodle as student")
	public void login_as_moodle_student() throws InterruptedException 
	{
	   
		mood.loginasStudent();
	}

	
	@Then("Click on Site Admin")
	public void clickonSiteAdmin() 
	{
	   
		mood.clickOnSiteSetting();
	}

	@Then("Click on User")
	public void clickonuser() 
	{
	   
		mood.clickOnuser();
	}
	
	@Then("Click on Add a new user")
	public void clickonaddnewUser() 
	{
	   
		mood.clickOnadduser();;
	}
	
	@Then("Create new User")
	public void createAddNewUser() 
	{
	  mood.enterUserDetails(Students.email, Students.firstName, Students.lastName);
//		 mood.enterUserDetails("shettyankush6444@yopmail.com", "Test", "Ankuhs");
	  
		
	}
	
	@Then("AddCreate new User in moodle")
	public void createAddNewUsermoodle() 
	{
		mood.clickOnuser();
		mood.clickOnadduser();;
		
	  mood.enterUserDetails(Students.email, Students.firstName, Students.lastName);
//		 mood.enterUserDetails("shettyankush6444@yopmail.com", "Test", "Ankuhs");
	  
		
	}
	
	@Then("Add User {string} {string} in Moodle")
	public void create_NewCourse(String name,String lastname) throws InterruptedException 
	{
		mood.clickOnSiteSetting();
		mood.clickOnuser();
		mood.clickOnadduser();;
//		mood.clickOnaddcourses();;
//	  mood.enterCoursesDetails(course);;
		
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		Students.email=name+lastname+formattedEmail+"@yopmail.com";
		User.userEmail=Students.email;
		  mood.enterUserDetails(Students.email,name, lastname);
	}
	@Then("Create new User {string} {string}")
	public void createAddNewUser(String name,String lastname) 
	{
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String email = dateFormat.format(cal.getTime());
		String formattedEmail = email.replace(":", "");
		Students.email=name+lastname+formattedEmail+"@yopmail.com";
		User.userEmail=Students.email;
	  mood.enterUserDetails(Students.email,name, lastname);
		
	}
	
	@Then("Select Course and Launch")
	public void selectoncourse() throws InterruptedException 
	{
	   
		mood.selectCourse();;
		 
		    scr.switchWindowMoodle(Students.email);
		  
		  //*[@id="first_name"]
//		    UserManagement		usrMg = new UserManagement();
//			usrMg.switchTab();
	}
	
	@Then("Select Course {string} and Complete for quarter {int}")
	public void selecton_course(String courseName,int q) throws InterruptedException 
	{
	   
		mood.selectCourse(courseName);;
		 
		    scr.switchWindowMoodlequater(q);
		  
		    
		    
		  //*[@id="first_name"]
//		    UserManagement		usrMg = new UserManagement();
//			usrMg.switchTab();
	}
	
	@Then("Select Course {string} and Complete for quarter {int} topics")
	public void selecton_coursequarter(String courseName,int q) throws InterruptedException 
	{
	   
		mood.selectCourse(courseName);;
		 
		    scr.switchWindowMoodlequarter(q);
		  
		  //*[@id="first_name"]
//		    UserManagement		usrMg = new UserManagement();
//			usrMg.switchTab();
	}
	
	@Then("Select Course and Launch quater {int}")
	public void selectoncourse(int quater) throws InterruptedException 
	{
	   
		mood.selectCourse();;
		 
		    scr.switchWindowMoodlequater(quater);
		  
		  //*[@id="first_name"]
//		    UserManagement		usrMg = new UserManagement();
//			usrMg.switchTab();
	}
	
	@Then("Select Course and Launch {string} {string}")
	public void selectoncourse(String name,String lastname) throws InterruptedException 
	{
	   
		mood.selectCourse();;
		 
		    scr.switchWindowMoodle(Students.email,name,lastname);
		  
		  //*[@id="first_name"]
//		    UserManagement		usrMg = new UserManagement();
//			usrMg.switchTab();
	}
	@Then("Click on Course")
	public void clickoncourse() 
	{
	   
		mood.clickOncourses();;
	}
	
	@Then("Click on Add Course")
	public void clickonaddcourse() 
	{
	   
		mood.clickOnaddcourses();;
	}
	@Then("Create new Course {string}")
	public void createNewCourse(String course) throws InterruptedException 
	{
	  mood.enterCoursesDetails(course);;
	}
	@Then("Logout from Moodle")
	public void logoutfrommoodle() throws InterruptedException 
	{
	  mood.clickonLogout();;
	}
	
	
	@Then("Add Course {string} and enroll user in Moodle")
	public void create_New_Course(String course) throws InterruptedException 
	{
		mood.clickOnSiteSetting();
		mood.clickOncourses();;
		mood.clickOnaddcourses();;
	   mood.enterCoursesDetails(course);;
	}
	
	@Then("Add User in Moodle")
	public void create_NewCourse() throws InterruptedException 
	{
		mood.clickOnSiteSetting();
		mood.clickOnuser();
		mood.clickOnadduser();;
//		mood.clickOnaddcourses();;
//	  mood.enterCoursesDetails(course);;
		  mood.enterUserDetails(Students.email, Students.firstName, Students.lastName);
	}
}
