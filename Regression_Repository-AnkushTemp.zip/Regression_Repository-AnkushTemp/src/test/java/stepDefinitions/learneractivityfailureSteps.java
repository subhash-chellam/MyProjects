package stepDefinitions;

import com.qa.pages.Compliance;
import com.qa.pages.ProgressReport;
import com.qa.pages.User;
import com.qa.pages.learneractivityfailure;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class learneractivityfailureSteps {

	learneractivityfailure lactFailure=new learneractivityfailure();
	
	@Then("navigate to learner activity failure log report page")
	public void navigate_to_compliance_report_page() 
	{
		lactFailure.clickOnReportLink();
		lactFailure.selectlearnerFailureLogLink();
	    
	}
	
	@Then("search the using email {string}")
	public void search_the_using_email(String user) 
	{
		
		lactFailure.usersearchEmail(user);
	}
	@Then("Validate the the learner activity failure log details for user {string}")
	public void Validate_the_learner_activity_failure_log_details(String username) 
	{
		lactFailure.ValidationtheColumnDetail(username);
	    
	}
	
	   @Then("search the job filter on Learner report page {string}")
	   public void search_the_job_filter_on_progress_report_page(String title) {
		  lactFailure.searchJobFilter(title);
		   lactFailure.validateJobFilterFilterAvailability();
		   lactFailure.SearchButtonMoreFilter();
	   }
	   
	   @Then("search the group filter on Learner report page {string}")
	   public void search_the_group_filter_on_progress_report_page(String group) {
		  
		   lactFailure.searchGroupFilter(group);
		   lactFailure.SearchButtonMoreFilter();
	   }

	   @Then("multi select user filter status as {string} on Learner report page")
	   public void multi_select_user_filter_status_as_on_progress_report_page(String filter) {
		   String[] filterList = filter.split(",");
		   for(int i = 0; i < filterList.length; i++) {
			   lactFailure.selectMultiUserStatusFilter(filterList[i]);	
		   }
		   
		   validate_the_filter_on_Learner_Activity_report_page("user status");
		   lactFailure.SearchButtonMoreFilter();
	   }


	@And("verify the columns order in learner Activity Report")
	public void verify_the_columns_order_in_compliance_Report(DataTable data) throws Exception {
		lactFailure.learnerActivityColumnsValidation(data.asList(), "beforeSearch");
	}

	@Then("Verify learner Activity No Reports Data Found")
	public void verifylearnerActivityNoReportsDataFound() {
		lactFailure.verifylearnerActivityNoReportsDataFound();
	}

	@Then("validate Learner Activity sorting of each column")
	public void validate_LearnerActivity_sorting_of_each_column() {
		if (lactFailure == null)
			lactFailure = new learneractivityfailure();

		lactFailure.validateLearnerActivitySortingEachColumn();
	}

	@Then("user Learner Activity click on export csv and validate")
	public void user_Learner_Activity_click_on_export_csv_and_validate() {
		if (lactFailure == null)
			lactFailure = new learneractivityfailure();
		lactFailure.exportCSV();
		lactFailure.validateCSVFile();
		lactFailure.ValidateHeaderOfCSVFile();
	}

	@Then("validate the {string} filter on Learner Activity report page")
	public void validate_the_filter_on_Learner_Activity_report_page(String filterName) {
		if (lactFailure == null)
			lactFailure = new learneractivityfailure();
		switch (filterName) {
		case "user status":
			lactFailure.validateUserStatusFilterAvailability();
			break;
		case "job filter":
			lactFailure.validateJobFilterFilterAvailability();
			break;
		case "group filter":
			lactFailure.validateGroupFilterFilterAvailability();
			break;
		default:
			break;
		}
	}

	@Then("click on course filter option on Learner Activity report page")
	public void click_on_course_filter_option_on_learner_Activity_report_page() {
		if (lactFailure == null)
			lactFailure = new learneractivityfailure();
		lactFailure.clickCourseFilter();
	}

	@Then("click On More Filters")
	public void clickOnMoreFilters() {
		if(lactFailure== null)
			lactFailure = new learneractivityfailure();
		lactFailure.clickOnMoreFilters();
	}
	
	
	@Then("click On Course Filters")
	public void clickOnCourseFilters() {
		if(lactFailure== null)
			lactFailure = new learneractivityfailure();
		lactFailure.clickOnCourseFilters();
	}
	
	@Then("click On Course UnselectAll Filters")
	public void clickOnUnselectAllFilters() {
		if(lactFailure== null)
			lactFailure = new learneractivityfailure();
		lactFailure.UnselectAllCourse();
	}
	
	  
	
	@Then("click On Course SelectAll Filters")
	public void clickOnSelectAllFilters() {
		if(lactFailure== null)
			lactFailure = new learneractivityfailure();
		lactFailure.selectAllCourse();
	}
	
	@Then("click Course Filter")
	public void clickCourseFilter() {
		if(lactFailure== null)
			lactFailure = new learneractivityfailure();
		lactFailure.SelectCourse();
	}
	
	

	@Then("multi select course filter status on learner activity report page {int}")
	public void multi_select_course_filter_status_on_learner_Activity_report_page(int count) {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		for(int i = 0; i < count; i++) {
			lactFailure.selectMultiUserCourseFilter();	
		}
		lactFailure.clickOnCourseFilterSearchButton();
	}
	
	
	@Then("multi select course filter status on learner report page {int}")
	public void multi_select_course_filte_status_on_learner_report_page(int count) {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		for(int i = 0; i < count; i++) {
			lactFailure.selectMultiCourseFilter();	
		}
	//	lactFailure.clickOnMoreFilterSearchButton();
	}
	
	@Then("multi select Job filter status on learner report page {int}")
	public void multi_select_job_filte_status_on_learner_report_page(int count) {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(int i = 0; i < count; i++) {
			lactFailure.selectMultiJobFilter();	
		}
	//	lactFailure.clickOnMoreFilterSearchButton();
	}
	
	
	@Then("click on course filter option on Learner report page")
	public void click_on_course_filter_option_on_pLearnerreportpage() {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
			lactFailure.clickCourseFilter();	
	}
	
	
	@Then("multi select group filter status on learner report page {int}")
	public void multi_select_group_filter_status_on_learner_report_page(int count) {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		for(int i = 0; i < count; i++) {
			lactFailure.selectMultiGroupFilter();	
		}
	//	lactFailure.clickOnMoreFilterSearchButton();
	}
	
	
	
	
	
	
	
	
	@Then("validate the learner activity records are available")
	public void validate_the_records_are_available() {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		lactFailure.validatelearnerActivityRecordAvailable();
	}
	

	@Then("click On Course Filter Search Button")
	public void click_On_Course_Filter_Search_Button() {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		lactFailure.clickOnCourseFilterSearchButton();
	}
	

	@Then("click On Course Clear Search Button")
	public void click_On_Course_Clear_Filter_Search_Button() {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		lactFailure.clickOnCourseClearSearch();
	}
	
	@Then("click On More Filter Clear Search Button")
	public void clickOnMoreFilterClearSearch() {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		lactFailure.clickOnMoreFilterClearSearch();
	}
	
	@Then("No Records found In Learner Activity page")
	public void No_Records_found_In_Learner_Activity_page() {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		lactFailure.NoRecordsFound();
	}
	
	@Then("Click on Job Title Filter")
	public void click_on_job_title_filter() {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		lactFailure.clickOnJobTitle();
	}
	
	@Then("click On Job Title Select All")
	public void click_On_Job_Title_Select_All() {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		lactFailure.clickOnJobTitleSelectAll();
	}
	
	@Then("click On Job Title Un Select All")
	public void click_On_Job_Title_Un_Select_All() {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		lactFailure.clickOnJobTitleUnSelectAll();
	}
	
	@Then("Click on Group Filter")
	public void click_on_group_filter() {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		lactFailure.clickOnGroup();
	}
	
	@Then("click On Group Select All")
	public void click_On_Group_Select_All() {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		lactFailure.clickOnGroupSelectAll();
	}
	
	@Then("click On Group Un Select All")
	public void click_On_Group_Un_Select_All() {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		lactFailure.clickOnGroupUnSelectAll();
	}
	
	@Then("click On Search More Filter")
	public void click_On_Search_More_Filter() {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		lactFailure.SearchButtonMoreFilter();
	}
	
	
	@Then("validate More Filters Availability")
	public void validateMoreFilterAvailability() {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		lactFailure.validateMoreFiltersAvailability();
	}
	
		
	@Then("click On Button Org Name")
	public void click_On_Button_Org_Name() {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		lactFailure.SearchButtonOrgName();
	}
	
	
	@Then("click On UnSelect Button Org Name")
	public void click_On_UnSelect_Org_Name() {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		lactFailure.SearchButtonUnSelectAll();
	}
	
	@Then("click On Select Button Org Name")
	public void click_On_Select_Org_Name() {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		lactFailure.SearchButtonSelectAll();
	}
	
	@Then("export and validate the details on Learner report page")
	public void export_and_validate_the_details() 
	{
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		
		boolean flag = lactFailure.checkCSVFilePresent();
		while(flag == true)
		{
			lactFailure.deleteFile(User.filePath);
			flag = lactFailure.checkCSVFilePresent();
		}			
		lactFailure.clickExportButton();
		lactFailure.verifyDownloadFile();
		lactFailure.compareDetails();
	}
	
	@Then ("click on Activity link")
	public void clickOnActivitylink() {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
		lactFailure.ClickOnActivitylink();
	}
	
	@Then("select Start Year{string} and month{string} and date{string}")
	public void selectStartDateMonthAndYear(String year, String month, String date) {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
	//	lactFailure.ClickonFromButton();
		lactFailure.selectStartDateMonthAndYear(year,month,date);
		
	}
	
	@Then("select Start date for Activity Date for user {string} and add days {int} in filter")
	public void selectStartDateMonthAdYear(String UserID,int day) {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
	//	lactFailure.ClickonFromButton();
		lactFailure.selectStartDateMonthAndYear(UserID,day);
		
	}
	
	@Then("select End date for Activity Date for user {string} and add days {int} in filter")
	public void selectEndDateMonthAdYear(String UserID,int day) {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
	//	lactFailure.ClickonFromButton();
		lactFailure.selectEndDateMonthAndYear(UserID,day);
		
	}
	@Then("select End Year{string} and month{string} and date{string}")
	public void selectEndDateMonthAndYear(String year, String month, String date) {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
	
		lactFailure.selectEndDateMonthAndYear(year,month,date);
		
	}

	@Then("Click on Activity Search Button")
	public void ClickOnActicitySearchButton() {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
	
		lactFailure.ActivityFilterSearchButton();
	}
	
	@Then("verify learner Activity No Records Are Present")
	public void verifylearnerActivityNoRecordsArePresent() throws InterruptedException {
		if(lactFailure == null)
			lactFailure = new learneractivityfailure();
	
		lactFailure.verifylearnerActivityNoRecordsArePresent();
	}
	
}
