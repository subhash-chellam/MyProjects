package stepDefinitions;

import org.testng.Assert;

import com.qa.pages.Compliance;
import com.qa.pages.EndUser;
import com.qa.pages.Healthcheck;
import com.qa.pages.ProgressReport;
import com.qa.pages.SFTP;
import com.qa.pages.Student;
import com.qa.pages.User;
import com.qa.pages.UserManagement;
import com.qa.pages.learneractivityfailure;
import com.qa.pages.studentPurchaseHistoryPage;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;

public class studentPurchaseHistoryStep {

	studentPurchaseHistoryPage studentPurchase=new studentPurchaseHistoryPage();
	

	@Then("navigate to Student Purchase History page")
	public void navigate_to_progress_report_page() 
	{
		
		studentPurchase.clickOnReportLink();
		studentPurchase.navigatetostudentPurchaseHistoryPage();
	}

	@Then("Clear Search in Student Purchase History page")
	public void navigate_to_progress_report_pagPurchasee() 
	{
		
		studentPurchase.clickonClear();
	
	}
	
	 @Then("click on more filter option in Student Purchase History page")
	   public void click_on_more_filter_option_on_progress_report_page() 
	   {
		   studentPurchase.clickMoreFilter();
	   }

	   
	@Then("select the dates in Student Purchase History page")
	public void select_the_datesin_Student_Purchase_Historypage() throws InterruptedException 
	{
		studentPurchase.clickStartDate();
		studentPurchase.selecfromDate();
		studentPurchase.clickEndDate();
		studentPurchase.selectDate();
	}
	

	 @Then("validate no records display on Student Purchase History page")
	    public void validate_no_records_display_on_progress_report_page()
	    {

			 studentPurchase.validateNoReportGenerated();
	    }
	@Then("validate the {string} filter on Student Purchase History page")
	public void validate_the_filter_on_Learner_Activity_report_page(String filterName) {
		switch (filterName) {
		case "User status filter":
			studentPurchase.validateUserStatusFilterAvailability();
			break;
		case "Product filter":
			studentPurchase.validateProductFilterAvailability();
			break;
		case "Purchase Type filter":
			studentPurchase.validatepurchaseTypeFilterAvailability();
			break;
		case "Purchase Status filter":
			studentPurchase.validatepurchaseStatusFilterAvailability();
			break;
		default:
			Assert.fail("Error filter name incorrect");
			break;
		}
	}
	
	@Then("multi select user filter status as {string} on Student Purchase History page")
	public void multi_select_user_filter_status_as_on_progress_report_page(String filter) {
		   String[] filterList = filter.split(",");
		   for(int i = 0; i < filterList.length; i++) {
			   studentPurchase.selectMultiUserStatusFilter(filterList[i]);	
		   }
		   
		   validate_the_filter_on_Learner_Activity_report_page("User status filter");
		   studentPurchase.SearchButtonMoreFilter();
	   }
	
	@Then("unSelect all user status  on Student Purchase History page")
	public void unSelect_all_user_status_on_compliance_Historyreport_page() {
		
		studentPurchase.unSelectAllStatus();
		studentPurchase.SearchButtonMoreFilter();
	}

	@Then("multi select Purchase Status filter as {string} on Student Purchase History page")
	public void multi_select_Purchase_filter_status_as_on_progress_report_page(String filter) {
		   String[] filterList = filter.split(",");
		   for(int i = 0; i < filterList.length; i++) {
			   studentPurchase.selectMultipurchaseStatusFilter(filterList[i]);	
		   }
		   
		   validate_the_filter_on_Learner_Activity_report_page("User status filter");
		   studentPurchase.SearchButtonMoreFilter();
	   }
	

	@Then("multi select Product filter as {string} on Student Purchase History page")
	public void multi_select_Product_filter_status_as_on_progress_report_page(String filter) {
		   String[] filterList = filter.split(",");
		   for(int i = 0; i < filterList.length; i++) {
			   studentPurchase.selectMultiProductFilter(filterList[i]);;	
		   }
		   
		   validate_the_filter_on_Learner_Activity_report_page("User status filter");
		   studentPurchase.SearchButtonMoreFilter();
	   }
	

	
	@Then("multi select Purchase Type filter Status as {string} on Student Purchase History page")
	public void multi_select_Purchase_Type_filter_status_as_on_progress_report_page(String filter) {
		   String[] filterList = filter.split(",");
		   for(int i = 0; i < filterList.length; i++) {
			   studentPurchase.selectMultipurchaseTypeFilter(filterList[i]);;	
		   }
		   
		   validate_the_filter_on_Learner_Activity_report_page("User status filter");
		   studentPurchase.SearchButtonMoreFilter();
	   }
	
	@Then("search the by {string} and value {string} on Student Purchase History page")
	public void search_the_newly_created_student(String searchBy,String value) 
	{
//		EndUser.OrderID="RQI0000500563";
		
		switch(searchBy)
		{
		case "User ID":studentPurchase.usersearchEmail(User.userId);
		break;
		case "Name":studentPurchase.usersearchEmail(value);
		break;
		case "Order ID":studentPurchase.usersearchEmail(EndUser.OrderID);
		break;
		
		default:Assert.fail("Error input");

		}
		
	}
	
	@Then("validate table detail on Student Purchase History page")
	public void validate_table_detail_in_student_tab(DataTable table) {
		
		for(int i=0;i<table.width();i++)
		for(int j=1;j<table.height();j++)
			studentPurchase.validateStudentPurchaseHistoryTable(table.column(i).get(0),table.column(i).get(j));
	
	}
	
	@Then("validate table detail for multiple course on Student Purchase History page")
	public void validate_table_detail_inmultiple_student_tab(DataTable table) {
		
		for(int j=1;j<table.height();j++)
		for(int i=1;i<table.width();i++)
		{
			System.out.println(table.column(0).get(j));
			studentPurchase.validateStudentPurchaseHistoryTablemultiple(table.column(i).get(0),table.column(i).get(j),table.column(0).get(j));
		}
	}
	
	@Then("export and validate the details on Student Purchase History page")
	public void export_and_validate_the_details() 
	{
		boolean flag = studentPurchase.checkCSVFilePresent();
		while(flag == true)
		{
			studentPurchase.deleteFile(studentPurchase.downloadPath);
			flag = studentPurchase.checkCSVFilePresent();
		}			
		studentPurchase.clickExportButton();
		studentPurchase.verifyDownloadFile();
		studentPurchase.compareDetails();
	}
	
	@Then("validate the page numbers on Student Purchase History page")
	public void validate_the_page_numbers_on_Student_Purchase_History_page() 
	{
	
		studentPurchase.validatePageNumbers();
		studentPurchase.getLocationPageNumber();
		studentPurchase.validatePaginationDropdown();
		studentPurchase.selectPaginationDropdown();
	}

	@Then("validate Student Purchase History check sorting of each column")
	public void validate_healthcheck_sorting_of_each_column() 
	{
		studentPurchase.validatePurchaseCheckSortingEachColumn();
	}
	
	@Then("validate filtered in {string} Column for {string} data in Student Purchase History")
	public void validate_Studentcheck_sorting_of_each_column(String coln,String value) 
	{
		studentPurchase.validatefilterdata(coln,value);
	}
	
	
//	@Then("Search course {string}")
//	public void Search_course_page(String course) 
//	{
//		health = new Healthcheck();
//		health.searchCourse(course);
//	}
//
//	@Then("Clear Search")
//	public void Clear_Search_page() 
//	{
//		health = new Healthcheck();
//		health.Clearsearch();
//	}
//
//
//
//
//	@Then("Validate Detail {string}")
//	public void Validate_Activity_Detail(String course) throws InterruptedException 
//	{
//		health.validateDetailsTable(course);
//	}
//	
//	@Then("Validate header {string}")
//	public void Validate_Header(String header) throws InterruptedException 
//	{
//		health.validateHeaderTable(header);
//	}
//	@Then("validate health check sorting of each column")
//	public void validate_healthcheck_sorting_of_each_column() 
//	{if(health==null)
//		health=new Healthcheck();
//	  
//	health.validateHealthCheckSortingEachColumn();
//	}
//	
//	 @Then("Verify Health check No Reports Data Found")
//	   public void verifyHealthCheckNoReportsDataFound() {
//		 health.verifyHealthCheckNoReportsDataFound();
//	   }
	   
}
