//package stepDefinitions;
//
//import com.qa.pages.ProgressReport_vini;
//import io.cucumber.java.en.Then;
//public class ProgressReportSteps_vini 
//{
//	ProgressReport_vini prog;
//	
//	@Then("navigate to progress report page")
//	public void navigate_to_progress_report_page() 
//	{
//		
//	    prog = new ProgressReport_vini();
//	    prog.clickOnReportLink();
//	    prog.navigateProgressReport();
//	}
//	
//	
//	@Then("validate the curriculum status on progress report")
//	public void validate_the_curriculum_status_on_progress_report() 
//	{
//	    prog.validateCurriculumStatusComplete();
//	}
//	
////Steps added by vinesha date: 4th April 2022
//	
//	@Then("click on reports tab")
//	public void click_on_reports_tab() {
//		prog = new ProgressReport_vini();
//	 prog.clickOnReportLink(); 
//	}
//
//
//	@Then("Export button disable")
//	public void export_button_disable() {
//		prog = new ProgressReport_vini();
//	 prog.buttonExportBttn(); 
//	}
//	@Then("Export button download")
//	public void export_button_downloa() {
//		prog = new ProgressReport_vini();
//	 prog.buttonExportBtn(); 
//	}
//
//	@Then("Select the {string}")
//	public void select_the(String string) {
//		prog = new ProgressReport_vini();
//	  prog.navigateProgressReport();
//	}
//	@Then("verify the header is displayed as {string}")
//	public void verify_the_header_is_displayed_as(String string) {
//	 prog.verifyheaderforreportspage(string);
//}
//	@Then("verify the report table headers being displayed {string}")
//	public void verify_the_report_table_headers_being_displayed(String string) throws InterruptedException {
//		prog = new ProgressReport_vini();
//		prog.verifytableheaders(string);
//	  
//	}
//	@Then("Verify pagination Functionality for report grid")
//	public void verify_pagination_functionality_for_report_grid() {
//		prog = new ProgressReport_vini();
//	prog.verifypagination();
//	}
//	@Then("click on the curriculam filters link")
//	public void click_on_the_curriculam_filters_link() throws InterruptedException {
//		prog = new ProgressReport_vini();
//	 prog.expandCurriculamfilters();
//	}
//
//	@Then("Verify the options available for curriculam status filters {string}")
//	public void verify_the_options_available_for_curriculam_status_link(String string) throws InterruptedException {
//		prog = new ProgressReport_vini();
//	prog.curriculamstatusoptionsCTC(string);
//	}
//	@Then("Verify the options available for curriculam status filters for LMS {string}")
//	public void verify_the_options_available_for_curriculam_status_link_for_lms(String string) throws InterruptedException {
//		prog = new ProgressReport_vini();
//		prog.curriculamstatusoptionsLMS(string);
//	}
//	@Then("click on more filters within progress report page")
//	public void click_on_more_filters_within_progress_report_page() throws InterruptedException {
//		prog = new ProgressReport_vini();
//		prog.expandmorefilterslink();
//	}
//
//	@Then("Verify the options available for user status filters {string}")
//	public void verify_the_options_available_for_user_status_filters(String string) throws InterruptedException {
//		prog = new ProgressReport_vini();
//		prog.userstatusoptions(string);
//	}
//	@Then("verify that active is default selected and select Inactive from userstatus dropdown")
//	public void verify_that_active_is_default_selected_and_select_inactive_from_userstatus_dropdown() throws InterruptedException {
//		prog = new ProgressReport_vini();
//		prog.verifydefaultselected();
//	}
//	@Then("verify the presence of Assignment Name filter {string}")
//	public void verify_the_presence_of_assignment_name_filter(String string) throws InterruptedException {
//		prog = new ProgressReport_vini();
//		prog.presenceofassignmentname(string);
//	}
//	@Then("unselect all selected assignments")
//	public void unselect_all_selected_assignments() throws InterruptedException {
//		prog = new ProgressReport_vini();
//		prog.assignmentunselectall();
//	}
//
//
//	@Then("select {int} assignments from the Assignment name filter")
//	public void select_assignments_from_the_assignment_name_filter(Integer int1) {
//        prog = new  ProgressReport_vini();
//        prog.selectionofassignmentnames(int1);
//        
//	}
//
//	@Then("click on search")
//	public void click_on_search() throws InterruptedException {
//		prog = new ProgressReport_vini();
//		prog.searchclick();
//	}
//	@Then("verify that values are displayed accordingly for assignment name")
//	public void verify_that_values_are_displayed_accordingly_for_assignment_name() {
//		prog = new ProgressReport_vini();
//		prog.recordsvalidationforassignmentnamefield();
//	}
//	@Then("verify presence of available date filter From and To  filters are {string}")
//	public void verify_presence_of_available_date_filter_from_and_to_filters_are(String string) {
//		prog = new ProgressReport_vini();
//		prog.assertionforavailabledate();
//	}
//
//	@Then("verify presence of Launched date filter From and To filters are {string}")
//	public void verify_presence_of_launched_date_filter_from_and_to_filters_are(String string) {
//		prog = new ProgressReport_vini();
//		prog.assertionforLauncheddate();
//	}
//	@Then("Select the {string} in Report")
//	public void select_the_in_report(String string) {
//		prog = new ProgressReport_vini();
//	  prog.navigateReport(string);
//	}
//	@Then("View Ecard Download")
//	public void clik_report() {
//		prog = new ProgressReport_vini();
//	  prog.viewecardDownload();
//	}
//	
//	@Then("Download Ecard Download")
//	public void click_report() {
//		prog = new ProgressReport_vini();
//	  prog.clickecardDownload();
//	}
//	@Then("Click on {string} Btn")
//	public void click_report(String string) {
//		prog = new ProgressReport_vini();
//	  prog.clickonfilter(string);
//	}
//	@Then("Click on {string}")
//	public void click_repor(String string) {
//		prog = new ProgressReport_vini();
//	  prog.clickonfilter(string);
//	}
//	
//	@Then("Select notification title {string}")
//	public void selectnotification(String string) {
//		prog = new ProgressReport_vini();
//	  prog.selectNotificationFilter(string);
//	}
//	@Then("verify presence of Due date filter From and To filters are {string}")
//	public void verify_presence_of_due_date_filter_from_and_to_filters_are(String string) {
//		prog = new ProgressReport_vini();
//		prog.assertionduedateassertion();
//	}
//
//	@Then("verify presence of Completed date filter From and filters are {string}")
//	public void verify_presence_of_completed_date_filter_from_and_filters_are(String string) {
//		prog = new ProgressReport_vini();
//		prog.assertioncompletedate();
//	}
//
//
//	@Then("click on the hand icon to load the details")
//	public void click_on_the_hand_icon_to_load_the_details() throws InterruptedException {
//		prog = new ProgressReport_vini();
//		prog.clickhandicon();
//	}
//
//	@Then("Verify the headers {string} within course details popup displayed")
//	public void verify_the_headers_within_course_details_popup_displayed(String string) throws InterruptedException {
//		prog = new ProgressReport_vini();
//	prog.verifyactivityheaders(string);
//	}
//
//   @Then("Verify table data displayed as {string}")
//   public void verify_table_data_displayed_as(String string) throws InterruptedException {
//		prog = new ProgressReport_vini();
//	prog.verifyactivitytabledata(string);
//}
//   @Then("select {string} from curriculum name filter")
//	public void select_from_curriculum_name_filter(String string) throws InterruptedException {
//		prog = new ProgressReport_vini();
//		prog.selectthecurriculumname(string);
//	}
//   @Then("close the details pop up")
//	public void close_the_details_pop_up() throws InterruptedException {
//	   prog = new ProgressReport_vini();
//	   prog.clickonclose();
//	}
//
//
//
//}
