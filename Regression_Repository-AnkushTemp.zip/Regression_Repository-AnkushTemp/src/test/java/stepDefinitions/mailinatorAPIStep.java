package stepDefinitions;

import org.junit.Assert;

import com.qa.pages.KeyClock;
import com.qa.pages.UserManagement;
import com.qa.pages.mailinatorAPI;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;

public class mailinatorAPIStep {

	mailinatorAPI mail=new mailinatorAPI();
	
	@Then("navigate to mailinator check if {string} mail and {string}")
	public void navigate_to_mailinator_and_change_password(String mailTitle,String checkStatus) throws InterruptedException 
	{
		mail.validateifmail(checkStatus,mailTitle);
	    
	}
	
	@Then("delete all mail in mailinator")
	public void navigate_to_yopmail_and_change_password(String mailTitle,String checkStatus) throws InterruptedException 
	{
		mail.validateifmail(checkStatus,mailTitle);
	    
	}
	@Then("navigate to mailinator and validate the notifcation for user")
	public void navigate_to_mailinator_and_validate_the_notifcation_for_uer() 
	{
		mail.validatethnoemailisTriggred();
	
	}

	

	
	
	@Then("navigate to mailinator check if {string} mail occurs {int} times")
	public void navigate_to_mailinator_and_change_password(String mailTitle,int count) throws InterruptedException 
	{
		mail.validatethemailcount(mailTitle,count);
	    
	}
	
	@Then("navigate to mailinator API and count rows {int} for account created successfully")
	public void navigate_to_yopmail_and_count_rows_for_account_created_successfully(Integer count)
	{
		mail.validatethemailcount("Account created successfully.",count);
	}
	@Then("navigate to mailinator API and change password for admin")
	public void navigate_to_yopmail_and_change_password_for_admin()  throws InterruptedException 
	{
		mail.validateifmail("Change Password","Account created successfully.");
	    
	}
	

	@Then("navigate to mailinator API and click on change password")
	public void navigate_toyopmail_and_change_password() throws InterruptedException 
	{
		mail.clickOnPwdChangeLink_Admin("Change Password","Account created successfully.");
		

	    
	}
	@Then("navigate to mailinator API and change password")
	public void navigate_to_yopmail_and_change_password() 
	{
		try {
			mail.validateifmail("Change Password","Account created successfully.");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			    
	}
	

	@Then("navigate to mailinator API and validate the notifcation for organization admin")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_organization_admin() throws InterruptedException 
	{
		mail.validateifmail("Validate If Existing","Account created successfully.");
//		key.loginYopmailForOrgAdmin();
	}
	
	@Then("navigate to mailinator API and validate the notifcation for unit admin as new user")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_unit_admin_as_new_user() throws InterruptedException 
	{

		mail.validateifmail("Validate If Existing","Account created successfully.");
		mail.validateifmail("Validate If Existing","UnitAdminLMSSubjecttitle");

	}
	@Then("navigate to mailinator API and validate the notifcation for student")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_student()  throws InterruptedException 
	{
		mail.validateifmail("Validate If Existing","Account created successfully.");
		
	}
	@Then("navigate to mailinator API and validate the notifcation for unit observer as new user")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_unit_observer_as_new_user()  throws InterruptedException 
	{
		mail.validateifmail("Validate If Existing","Account created successfully.");
		mail.validateifmail("Validate If Existing","UnitObserverLMSSubjecttitle");

	}
	
	@Then("navigate to mailinator API and validate the notifcation for assignment completed by user")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_assignment_completed_by_user() throws InterruptedException 
	{
		mail.validateifmail("Validate If Existing","Account created successfully.");
		mail.validateifmail("Validate If Existing","New Assignment available");
		mail.validateifmail("Validate If Existing","Assignment completed");

	}
	@Then("navigate to mailinator API and validate the notifcation for email update by student")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_email_update_by_student()  throws InterruptedException 
	{
	
		mail.validateifmail("Validate If Existing","Email Updated Successfully");

		
	}
	
	
	@Then("navigate to mailinator API and validate the notifcation for unit admin as new user for CTC")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_unit_admin_as_new_user_for_CTC() throws InterruptedException 
	{
		mail.validateifmail("Validate If Existing","Account created successfully.");
		mail.validateifmail("Validate If Existing","UnitAdminCTCSubjecttitle");

	}
	@Then("navigate to mailinator API and validate the notifcation for unit observer as new user for CTC")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_unit_observer_as_new_user_for_CTC()  throws InterruptedException
	{
		mail.validateifmail("Validate If Existing","Account created successfully.");
		mail.validateifmail("Validate If Existing","UnitObserverCTCSubjecttitle");

	}

	
	
	@Then("navigate to mailinator API and validate the email content for account created successfully")
	public void navigate_to_mailinatorAPI_and_validate_the_notifcation_for_unit_observer_as_new_user_for_CTC()  throws InterruptedException
	{
		mail.validatemailbody("Validate If Existing","Account created successfully.");
	
	}

	@Then("navigate to mailinator API and validate the email content for new assignment available")
	public void navigate_to_mailinatorAPI_and_validate_the_notifcation_for_assignmentavailable_as_new_user_for_CTC()  throws InterruptedException
	{
		mail.validatemailbody("Validate If Existing","New assignment available");
	
	}

	@Then("navigate to mailinator API and validate the email content for Assignment completed")
	public void navigate_to_mailinatorAPI_and_validate_the_notifcation_for_Assignmentcompleted_as_new_user_for_CTC()  throws InterruptedException
	{
		mail.validatemailbody("Validate If Existing","Assignment completed");
	
	}

	@Then("navigate to mailinator API and validate the email content for unit admin as new user for CTC")
	public void navigate_to_mailinatorAPI_and_validate_the_notifcationadmin_for_Assignmentcompleted_as_new_user_for_CTC()  throws InterruptedException
	{
		mail.validatemailbody("Validate If Existing","UnitAdminCTCSubjecttitle");
	
	}
	@Then("navigate to mailinator API and validate the email content for unit observer as new user for CTC")
	public void navigate_to_mailinatorAPI_and_validate_the_nmailinatorAPIotifcation_for_Assignmentcompleted_as_new_user_for_CTC()  throws InterruptedException
	{
		mail.validatemailbody("Validate If Existing","UnitObserverCTCSubjecttitle");
	
	}

	@Then("navigate to mailinator API and validate the notifcation for user")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_uer(DataTable table) 
	{
	String subjectmail=mail.getmailsubject();
	System.err.println(subjectmail);
		   for(int i=0;i<table.height();i++)
		   {
			   boolean flag=false;
			   for(int j=0;j<subjectmail.split(",").length;j++)
			   {
				 System.out.println(table.column(0).get(i)); 
				 System.out.println(table.width());
			   if(table.column(0).get(i).contains(subjectmail.split(",")[j]))
				   flag=true;
			   }
			 Assert.assertTrue( "Message "+table.column(0).get(i),flag);
		   }
		   System.err.println(table.height());
		   
		   System.err.println(subjectmail.split(",").length);
		   Assert.assertTrue(  table.height()==subjectmail.split(",").length);
		      
	}

	
}
