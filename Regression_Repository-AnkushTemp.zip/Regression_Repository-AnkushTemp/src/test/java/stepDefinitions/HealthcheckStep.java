package stepDefinitions;

import com.qa.pages.Healthcheck;
import com.qa.pages.SFTP;

import io.cucumber.java.en.Then;

public class HealthcheckStep {

	Healthcheck health;
	@Then("Search course {string}")
	public void Search_course_page(String course) 
	{
		health = new Healthcheck();
		health.searchCourse(course);
	}

	@Then("Clear Search")
	public void Clear_Search_page() 
	{
		health = new Healthcheck();
		health.Clearsearch();
	}




	@Then("Validate Detail {string}")
	public void Validate_Activity_Detail(String course) throws InterruptedException 
	{
		health.validateDetailsTable(course);
	}
	
	@Then("Validate header {string}")
	public void Validate_Header(String header) throws InterruptedException 
	{
		health.validateHeaderTable(header);
	}
	@Then("validate health check sorting of each column")
	public void validate_healthcheck_sorting_of_each_column() 
	{if(health==null)
		health=new Healthcheck();
	  
	health.validateHealthCheckSortingEachColumn();
	}
	
	 @Then("Verify Health check No Reports Data Found")
	   public void verifyHealthCheckNoReportsDataFound() {
		 health.verifyHealthCheckNoReportsDataFound();
	   }
	   
}
