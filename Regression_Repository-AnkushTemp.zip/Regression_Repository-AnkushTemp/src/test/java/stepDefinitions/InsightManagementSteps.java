package stepDefinitions;

import com.qa.pages.InsightManagement;
import com.qa.pages.OrganizationHome;
import io.cucumber.java.en.Then;
public class InsightManagementSteps 
{

	InsightManagement insight;
	OrganizationHome orgHome;
	
	@Then("add the application")
	public void add_the_application() 
	{
	    insight = new InsightManagement();
	    orgHome = new OrganizationHome();
	    insight.clickOnAddApplication();
	    insight.addAppDetails();
	    orgHome.validateSucessMesssage();
	}

	@Then("delete the application")
	public void delete_the_application() 
	{
		if(insight == null)
			insight = new InsightManagement();
	    insight.deleteAppInsight();
	    if(orgHome == null)
	    	orgHome = new OrganizationHome();
	    orgHome.validateSucessMesssage();
	}

	@Then("navigate to edit application page")
	public void navigate_to_edit_application_page() 
	{
		if(insight == null)
			insight = new InsightManagement();
		insight.clickOnEditApplication();
	}
	
	@Then("remove all the details and check behavior")
	public void remove_all_the_details_and_check_behavior() 
	{
		if(insight == null)
			insight = new InsightManagement();
	    insight.removeAllAppDetails();
	}
	
	@Then("enter more than {int} characters in name and check behavior")
	public void enter_more_than_characters_in_name_and_check_behavior(Integer length) 
	{
		if(insight == null)
			insight = new InsightManagement();
		insight.enterNameWithGivenLength(length);
	}
	
	@Then("enter url in name field and check the behavior")
	public void enter_url_in_name_field_and_check_the_behavior() 
	{
		if(insight == null)
			insight = new InsightManagement();
		insight.enterNameWithURL();
	}
	
	@Then("edit the name and save the details")
	public void edit_the_name_and_save_the_details() 
	{
		if(insight == null)
			insight = new InsightManagement();
		insight.editName();
		orgHome.validateSucessMesssage();
	}
	
	@Then("remove the description and check behavior")
	public void remove_the_description_and_check_behavior() 
	{
		if(insight == null)
			insight = new InsightManagement();
		insight.removeDescriptionAppDetails();
	}

	@Then("enter the invalid url and check behavior")
	public void enter_the_invalid_url_and_check_behavior() 
	{
		if(insight == null)
			insight = new InsightManagement();
		insight.enterInvalidUrl();
	}
	
	@Then("edit the description and save the details")
	public void edit_the_description_and_save_the_details() 
	{
		if(insight == null)
			insight = new InsightManagement();
		insight.editDesription();
	}

	@Then("delete the multiple application")
	public void delete_the_multiple_application() 
	{
		if(insight == null)
			insight = new InsightManagement();
	    insight.deleteMultipleAppInsight();
	    if(orgHome == null)
	    	orgHome = new OrganizationHome();
	    orgHome.validateSucessMesssage();
	}
}
