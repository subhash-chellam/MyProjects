package stepDefinitions;

import com.qa.pages.Analytics;
import com.qa.pages.InsightManagement;
import com.qa.pages.User;

import io.cucumber.java.en.Then;

public class AnalyticsSteps 
{
	Analytics analytics;
	
	@Then("navigate to analytics page")
	public void navigate_to_analytics_page() 
	{
		User usr=new User();
		usr.pageLoad();
		analytics = new Analytics();
		analytics.clickOnAnalyticsTab(); 
	}
	
	@Then("enable the application")
	public void enable_the_application() 
	{
		User usr=new User();
		usr.pageLoad();
	    analytics.toggleAnalytics();
	    System.out.println(InsightManagement.insightAppName);
	    analytics.enableInsightApp(InsightManagement.insightAppName);
	}

	@Then("toggle the application")
	public void toggle_the_application() 
	{
		User usr=new User();
		usr.pageLoad();
	    analytics.toggleAnalytics();
	}
	@Then("Check and toggle it to {string} in the application")
	public void Checktoggle_the_application(String status) 
	{
//		User usr=new User();
//		usr.pageLoad();
	    analytics.checktoggleAnalytics(status);
	}
	
	
	@Then("click on analytics dropdown and validate")
	public void click_on_analytics_dropdown_and_validate() 
	{
		User usr=new User();
		usr.pageLoad();
	    analytics.validateAnalyticsDropdown(InsightManagement.insightAppName);
	}

	@Then("validate application not available")
	public void validate_application_not_available() 
	{
		User usr=new User();
		usr.pageLoad();
	    analytics.validateApplicationAbsent(InsightManagement.insightAppName);
	}
	
	@Then("validate application not available in access organization")
	public void validate_application_not_available_in_access_organization() 
	{
		User usr=new User();
		usr.pageLoad();
	    analytics.validateAnalyticsDropdownNotAvailable(InsightManagement.insightAppName);
	}

	@Then("validate the description")
	public void validate_the_description() 
	{
		User usr=new User();
		usr.pageLoad();
	    analytics.validateDescription(InsightManagement.description);
	}

	@Then("enable the application and select {string}")
	public void enable_the_application_and_select(String appName) 
	{
		User usr=new User();
		usr.pageLoad();
		 analytics.toggleAnalytics();
		 analytics.enableMulitpleInsightAppSave(appName);
	}

	@Then("select the application and save {string}")
	public void select_the_application_and_select(String appName) 
	{
		User usr=new User();
		usr.pageLoad();
		 analytics.MulitpleInsightAppSave(appName);
	}

	
	@Then("click on analytics dropdown and validate {string} and check the version {string}")
	public void click_on_analytics_dropdown_and_validate_and_check_the_version(String allApp, String versionApp) 
	{
		User usr=new User();
		usr.pageLoad();
		if(analytics == null)
			analytics = new Analytics();
	    analytics.validateAnalyticsDropdownAndSelect(allApp, versionApp);
	}
	
	@Then("validate the version")
	public void validate_the_version() 
	{
		User usr=new User();
		usr.pageLoad();
	    analytics.getFrameSourceValidate();
	}
	
	@Then("validate the error message for not selecting insight application")
	public void validate_the_error_message_for_not_selecting_insight_application() 
	{
		User usr=new User();
		usr.pageLoad();
	    analytics.validateErrorForNotSelectApplication();
	}
	
	@Then("validate {string} warning message")
	public void validate_warning_message(String status) 
	{
		User usr=new User();
		usr.pageLoad();
	    analytics.validateWarningMessageForApplication(status);
	}
	
	@Then("click {string} on warning message")
	public void click_on_warning_message(String name)
	{User usr=new User();
	usr.pageLoad();
	    analytics.clickOnButton(name);
	}

	@Then("Navigate to analytics in Access Detail page")
	public void navigate_to_analytic() 
	{
		analytics.clickOnAnalyticsinaccessTab();
	}
	
	@Then("Validate if Analytics Report Loaded")
	public void validateifAnalytics() 
	{
		analytics.validateifAnalytics();
	}
	
}
