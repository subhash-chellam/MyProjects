package stepDefinitions;

import com.qa.pages.CourseManagement;
import com.qa.pages.DashBoard;
import com.qa.pages.EndUser;
import com.qa.pages.OrganizationAccess;
import com.qa.pages.User;
import com.qa.pages.UserManagement;
import com.qa.util.TestBase;

import io.cucumber.java.en.Then;

public class DashBoardSteps 
{
	DashBoard db;
	UserManagement usrMg;
	EndUser end;
	
	@Then("navigate to user management page")
	public void navigate_to_user_management_page() 
	{
		db = new DashBoard();
		db.clickUserMgmtDropDown();
		db.clickUserManagementOption();
	}
	
	@Then("wait for {int} minute")
	public void wait_for_1_minute(int i) 
	{
		db = new DashBoard();
		db.waitfor1min(i);
	
	}
	
	@Then("navigate to course management")
	public void navigate_to_course_management() 
	{
		db = new DashBoard();
		db.clickCourseMgmtDropDown();
		db.clickCourseManagementOption();
	}
	
	@Then("evaluate the course")
	public void evaluate_the_course() 
	{
	    if(CourseManagement.evaluationStatus.toLowerCase().equalsIgnoreCase("yes"))
	    {
	    	usrMg = new UserManagement();
	    	end = new EndUser();
	    	db.clickUserMgmtDropDown();
			db.clickUserManagementOption();
			usrMg.searchByEmail(User.userEmail);
			usrMg.clickSearch();
		    usrMg.selectProxyUser();
		    end = new EndUser();
		    usrMg.switchTab();		    
		    end.launchUserCourse1();
		    System.out.println("Value of end user flag is " + EndUser.flag);
		    if(EndUser.flag == false)
		    {
		    	end.clickOnCompletedPrograms();
		    	end.launchUserCourse1();
		    }		    
		    end.clickOnSubmitOnly();
		    end.evaluateCourse();
		    usrMg.switchTab();
		    usrMg.closeOtherTab();
	    }
	}
	
	@Then("evaluate the course from end user")
	public void evaluate_the_course_from_end_user() 
	{
		if(end == null)
			end = new EndUser();
		end.evaluateCourse();
	}

	@Then("Resume the course {string}")
	public void resume_the_course(String name) 
	{
		if(end == null)
			end = new EndUser();
		end.launchCourseWithNameResume(name);
    	
	}
	@Then("click on admin dashboard within profile link")
	public void click_on_admin_dashboard_within_profile_link() {
		OrganizationAccess orgAccess = new OrganizationAccess();
		orgAccess.gotoadmindashboard();
	}
	@Then("navigate to usercourse management manage user course page")
	public void navigate_to_usercourse_management_manage_user_course_page() {
		db = new DashBoard();
		db.clickUsercourseMgmtDropDown();
		db.clickManageusercourseOption(); 
	}
	@Then("navigate to insight management")
	public void navigate_to_insight_management() 
	{
		db = new DashBoard();
		db.clickCourseMgmtDropDown();
		db.clickInsightManagementOption();
	}

	@Then("click on organization panel")
	public void click_on_organization_panel() 
	{
		db = new DashBoard();
	    db.selectOrgpanel();
	}

	@Then("get the number of cycle")
	public void get_the_number_of_cycle() {
	    db.getNumberOfCycle();
	}
	
	@Then("user click on user course management")
	public void user_click_on_user_course_management() {
		db = new DashBoard();
		db.clickUsercourseMgmtDropDown();
	}
	
	@Then("validate the count of options available as {int}")
	public void validate_the_count_of_options_available_as(Integer count) {
		 if(db == null)
		    	db = new DashBoard();
		 db.validateCountOptionsUserCourseMgmt(count);
	}
	
	@Then("validate {string} options not available")
	public void validate_claims_options_not_available(String value) {
	    if(db == null)
	    	db = new DashBoard();
	    db.validateUserCourseMgmtOptions(value);
	}
	
	@Then("validate {string} options available")
	public void validate_claims_options_available(String value) {
	    if(db == null)
	    	db = new DashBoard();
	    db.validateUserCourseMgmtOptionsAvailable(value);
	}
	
	@Then("navigate to usercourse management generate user cme claims page")
	public void navigate_to_usercourse_management_generate_user_cme_claims_page() {
		db = new DashBoard();
		db.clickUsercourseMgmtDropDown();
		db.clickGenerateClaimsOption(); 
	}
	
	@Then("validate {string} tab not available")
	public void validate_claims_tab_not_available(String value) {
	    if(db == null)
	    	db = new DashBoard();
	    db.validateGenerateClaimsTabOptions(value);
	}
	
	@Then("navigate to user role management page")
	public void navigate_to_user_role_management_page() {
		db = new DashBoard();
		db.clickUserMgmtDropDown();
		db.clickUserRoleManagementOption();
	}
	
	@Then("validate the role {string} is available")
	public void validate_the_role_is_available(String roleName) {
		 if(db == null)
		    	db = new DashBoard();
		    db.validateRoleAvailable(roleName);
	}
	
	

}

