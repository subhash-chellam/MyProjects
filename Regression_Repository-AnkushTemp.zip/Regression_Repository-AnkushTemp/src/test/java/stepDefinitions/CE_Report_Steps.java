package stepDefinitions;

import com.qa.pages.CE_Report;
import com.qa.pages.MailTrapAPI;
import com.qa.pages.User;
import com.qa.util.TestBase;

import io.cucumber.java.en.Then;

public class CE_Report_Steps extends TestBase{
	
	CE_Report ce;
	MailTrapAPI mtp;

	@Then("validate user is able to access CE report")
	public void validate_user_is_able_to_access_ce_report() {
	    ce = new CE_Report();
	    ce.ceReportHeading();
	}
	
	@Then("validate only CE report is available")
	public void validate_only_ce_report_is_available() {
	    if(ce == null)
	    	ce = new CE_Report();
	    ce.validateReportOptionCount(1);
	}
	
	@Then("user logout from ce report page")
	public void user_logout_from_ce_report_page() {
		 if(ce == null)
		    	ce = new CE_Report();
		 ce.logout();
	}

	@Then("validate user is not able to access CE report")
	public void validate_user_is_not_able_to_access_ce_report() {
		 if(ce == null)
		    	ce = new CE_Report();
		 ce.ceReportHeadingNotAvailable();
	}

	@Then("validate CE report is not available")
	public void validate_ce_report_is_not_available() {
		if(ce == null)
	    	ce = new CE_Report();
	    ce.validateCE_ReportNotAvailable();
	}
	
	@Then("validate the platform id is available")
	public void validate_the_platform_id_is_available() {
		if(ce == null)
	    	ce = new CE_Report();
	}
	
	@Then("validate the available filters and their default values on CE report page")
	public void validate_the_available_filters_and_their_default_values_on_ce_report_page() {
		if(ce == null)
	    	ce = new CE_Report();
		ce.validateFromFilter_DefaultValues();
		ce.validateToFilter_DefaultValues();
	}
	
	@Then("enter the valid date range on CE report page")
	public void enter_the_valid_date_range_on_ce_report_page() {
		if(ce == null)
	    	ce = new CE_Report();
		ce.validFromDateValue();
		ce.validEndDateValue();
	}
	
	@Then("clear the search result on CE report page")
	public void clear_the_search_result_on_ce_report_page() {
		if(ce == null)
	    	ce = new CE_Report();
		ce.clickClearButton();
	}
	
	@Then("validate the default value for CE type filter on CE report page")
	public void validate_the_default_value_for_ce_type_filter_on_ce_report_page() {
		if(ce == null)
	    	ce = new CE_Report();
		ce.validateCEFilter_DefaultValues();
	}
	
	@Then("validate values present as {string} for CE type on CE report page")
	public void validate_values_present_as_for_ce_type_on_ce_report_page(String values) {
		if(ce == null)
	    	ce = new CE_Report();
		ce.validateCEFilterAllValues(values);
	}
	
	@Then("validate export button is disable on CE report page")
	public void validate_export_button_is_disable_on_ce_report_page() {
		if(ce == null)
	    	ce = new CE_Report();
		ce.validateDisableExportButton("yes");
	}
	
	@Then("validate export button is enable on CE report page")
	public void validate_export_button_is_enable_on_ce_report_page() {
		if(ce == null)
	    	ce = new CE_Report();
		ce.validateDisableExportButton("no");
	}
	
	@Then("select the value {string} for CE type on CE report page")
	public void select_the_value_for_ce_type_on_ce_report_page(String value) {
		if(ce == null)
	    	ce = new CE_Report();
		ce.enterCEFilterValue(value);
	}
	
	@Then("click on email report button on CE report page")
	public void click_on_email_report_button_on_ce_report_page() {
		if(ce == null)
	    	ce = new CE_Report();
		ce.clickExportButton();
	}
	
	@Then("validate the notice window on CE report page")
	public void validate_the_notice_window_on_ce_report_page() {
		if(ce == null)
	    	ce = new CE_Report();
		ce.validateEmailDialogueBox(User.userEmail);
	}
	
	@Then("click on close button on CE report page")
	public void click_on_close_button_on_ce_report_page() {
		if(ce == null)
	    	ce = new CE_Report();
		ce.closeEmailDialogueBox();
	}

	@Then("validate values present in sorting order for CE type on CE report page")
	public void validate_values_present_in_sorting_order_for_ce_type_on_ce_report_page() {
		if(ce == null)
	    	ce = new CE_Report();
		ce.validateSortingCEFilterValues();
	}
	
	@Then("click on link to download report {string} from application")
	public void click_on_link_to_download_report_from_application(String string) {
		if(ce == null)
	    	ce = new CE_Report();
		ce.clickDownloadReport();
	}

}
