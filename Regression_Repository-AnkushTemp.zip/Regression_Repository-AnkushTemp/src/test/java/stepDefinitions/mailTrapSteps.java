package stepDefinitions;

import org.junit.Assert;

import com.qa.pages.AssignmentReport;
import com.qa.pages.EndUser;
import com.qa.pages.MailTrapAPI;
import com.qa.pages.User;
import com.qa.pages.UtilisationReport;
import com.qa.pages.mailinatorAPI;
import com.qa.util.TestBase;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;

public class mailTrapSteps {

	MailTrapAPI mail=new MailTrapAPI();
	
	
	
	@Then("navigate to mailTrap check if {string} mail occurs {int} times")
	public void navigate_to_mailinator_and_change_password(String mailTitle,int count) throws InterruptedException 
	{
		mail.validatethemailcount(mailTitle,count);
	    
	}
	

	@Then("navigate to mailTrap check if {string} mail and {string}")
	public void navigate_to_mailTrap_and_change_password(String mailTitle,String checkStatus) throws InterruptedException 
	{
		mail.validateifmail(checkStatus,mailTitle);
	    
	}
	
	@Then("delete all mail in mailTrap")
	public void navigate_to_yopmail_and_change_password(String mailTitle,String checkStatus) throws InterruptedException 
	{
		mail.validateifmail(checkStatus,mailTitle);
	    
	}
	@Then("navigate to mailTrap and validate the notifcation for user")
	public void navigate_to_mailinator_and_validate_the_notifcation_for_uer() 
	{
		mail.validatethnoemailisTriggred();
	
	}

	

	
	
	
	
	@Then("navigate to mailTrap API and count rows {int} for account created successfully")
	public void navigate_to_yopmail_and_count_rows_for_account_created_successfully(Integer count)
	{
		mail.validatethemailcount("createdAccountMailTitle",count);
	}
	@Then("navigate to mailTrap API and change password for admin")
	public void navigate_to_yopmail_and_change_password_for_admin()  throws InterruptedException 
	{
		mail.validateifmail("Change Password","createdAccountMailTitle");
	    
	}
	

	@Then("navigate to mailTrap API and click on change password")
	public void navigate_toyopmail_and_change_password() throws InterruptedException 
	{
		mail.clickOnPwdChangeLink_Admin("Change Password","createdAccountMailTitle");
		

	    
	}
	@Then("navigate to mailTrap API and change password")
	public void navigate_to_yopmail_and_change_password() 
	{
		try {
			mail.validateifmail("Change Password","createdAccountMailTitle");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			    
	}
	

	@Then("navigate to mailTrap API and validate the notifcation for organization admin")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_organization_admin() throws InterruptedException 
	{
		mail.validateifmail("Validate If Existing","createdAccountMailTitle");
//		key.loginYopmailForOrgAdmin();
	}
	
	@Then("navigate to mailTrap API and validate the notifcation for unit admin as new user")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_unit_admin_as_new_user() throws InterruptedException 
	{

		mail.validateifmail("Validate If Existing","createdAccountMailTitle");
		mail.validateifmail("Validate If Existing","UnitAdminLMSSubjecttitle");

	}
	@Then("navigate to mailTrap API and validate the notifcation for student")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_student()  throws InterruptedException 
	{
		mail.validateifmail("Validate If Existing","createdAccountMailTitle");
		
	}
	@Then("navigate to mailTrap API and validate the notifcation for unit observer as new user")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_unit_observer_as_new_user()  throws InterruptedException 
	{
		mail.validateifmail("Validate If Existing","createdAccountMailTitle");
		mail.validateifmail("Validate If Existing","UnitObserverLMSSubjecttitle");

	}
	
	@Then("navigate to mailTrap API and validate the notifcation for assignment completed by user")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_assignment_completed_by_user() throws InterruptedException 
	{
		mail.validateifmail("Validate If Existing","createdAccountMailTitle");
		mail.validateifmail("Validate If Existing","New_AssignmentMailTitle");
		mail.validateifmail("Validate If Existing","Assignment_completed_MailTitle");

	}
	@Then("navigate to mailTrap API and validate the notifcation for email update by student")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_email_update_by_student()  throws InterruptedException 
	{
	
		mail.validateifmail("Validate If Existing","Email_Updated_MailTitle");

		
	}
	
	
	@Then("navigate to mailTrap API and validate the notifcation for unit admin as new user for CTC")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_unit_admin_as_new_user_for_CTC() throws InterruptedException 
	{
		mail.validateifmail("Validate If Existing","createdAccountMailTitle");
		mail.validateifmail("Validate If Existing","UnitAdminCTCSubjecttitle");

	}
	@Then("navigate to mailTrap API and validate the notifcation for unit observer as new user for CTC")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_unit_observer_as_new_user_for_CTC()  throws InterruptedException
	{
		mail.validateifmail("Validate If Existing","createdAccountMailTitle");
		mail.validateifmail("Validate If Existing","UnitObserverCTCSubjecttitle");

	}

	@Then("navigate to mailTrap API and validate the email content for {string} for {int} month Plan")
	public void navigate_to_mailinatorAPI_and_validate_the_notifcation_for_assignmentavailable_as_new_user_for_CTC(String mailTitle,int month)  throws InterruptedException
	{
		
		
		mail.validatemailbodyDetails("Validate If Existing",mailTitle,month);
	
	}
	
	@Then("navigate to mailTrap API and validate the email content for {string} for {int} month Plan for LMS org")
	public void navigate_to_mailinatorAPI_and_validate_the_notifcation_for_assignmentavailable_as_new_user_for_LMS(String mailTitle,int month)  throws InterruptedException
	{
		
		
		mail.validatemailbodyDetailsLMS("Validate If Existing",mailTitle,month);
	
	}
	
	@Then("navigate to mailTrap API and validate if able to download order pdf from {string} mail")
	public void navigate_to_mailinatorAPI_and_validate_the_notifcation_for_assignmentavailable_as_new_user_mailfor_CTC(String mailTitle)  throws InterruptedException
	{
		
		
		mail.validatemailbodyDetails("Validate If Existing",mailTitle);
	
	}
	@Then("navigate to mailTrap API and validate if able to download order pdf from {string} mail for diffrent Mail")
	public void navigate_to_mailinatorAPI_and_validate_the_notifcation_for_assignmentavailable_as_new_user_mailfor_MailCTC(String mailTitle)  throws InterruptedException
	{
		
	User.userEmail=	EndUser.secondaryEmail;
		mail.validatemailbodyDetails("Validate If Existing",mailTitle);
	
	}
	@Then("navigate to mailTrap API and validate the email content for account created successfully")
	public void navigate_to_mailinatorAPI_and_validate_the_notifcation_for_unit_observer_as_new_user_for_CTC()  throws InterruptedException
	{
		mail.validatemailbody("Validate If Existing","createdAccountMailTitle");
		
	}

	@Then("navigate to mailTrap API and validate the email content for new assignment available")
	public void navigate_to_mailinatorAPI_and_validate_the_notifcation_for_assignmentavailable_as_new_user_for_CTC()  throws InterruptedException
	{
		mail.validatemailbody("Validate If Existing","New_AssignmentMailTitle");
	
	}

	@Then("navigate to mailTrap API and validate the email content for Assignment completed")
	public void navigate_to_mailinatorAPI_and_validate_the_notifcation_for_Assignmentcompleted_as_new_user_for_CTC()  throws InterruptedException
	{
		mail.validatemailbody("Validate If Existing","Assignment completed");
	
	}

	@Then("navigate to mailTrap API and validate the email content for unit admin as new user for CTC")
	public void navigate_to_mailinatorAPI_and_validate_the_notifcationadmin_for_Assignmentcompleted_as_new_user_for_CTC()  throws InterruptedException
	{
		mail.validatemailbody("Validate If Existing","UnitAdminCTCSubjecttitle");
	
	}
	@Then("navigate to mailTrap API and validate the email content for unit observer as new user for CTC")
	public void navigate_to_mailinatorAPI_and_validate_the_nmailinatorAPIotifcation_for_Assignmentcompleted_as_new_user_for_CTC()  throws InterruptedException
	{
		mail.validatemailbody("Validate If Existing","UnitObserverCTCSubjecttitle");
	
	}

	@Then("navigate to mailTrap API and validate the notifcation for user")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_uer(DataTable table) 
	{
	String subjectmail=mail.getmailsubject();
	System.err.println(subjectmail);
		   for(int i=0;i<table.height();i++)
		   {
			   boolean flag=false;
			   for(int j=0;j<subjectmail.split(",").length;j++)
			   {
				 System.out.println(table.column(0).get(i)); 
				 System.out.println(table.width());
				 String subjct=table.column(0).get(i);
					if(AssignmentReport.checkifParmeterAvailable(subjct))
						subjct=AssignmentReport.getParmeterAvailable(subjct);
			     System.out.println(subjct);
			     System.out.println(subjectmail.split(",")[j]);
			     
			   if(subjct.contains(subjectmail.split(",")[j]))
				   flag=true;
			   }
			 Assert.assertTrue( "Message "+table.column(0).get(i),flag);
		   }
		   System.err.println(table.height());
		   
		   System.err.println(subjectmail.split(",").length);
		   Assert.assertTrue(  table.height()==subjectmail.split(",").length);
		      
	}
	
	@Then("navigate to mailTrap API and validate the notifcation for user {string}")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_uer(String mailTile) 
	{
	String subjectmail=mail.getmailsubject();
	System.err.println(subjectmail);
	boolean flag=false;
	   
	for(int j=0;j<subjectmail.split(",").length;j++)
	   {
		 String subjct=mail.getupdatedSubjectTitle(mailTile);
			if(AssignmentReport.checkifParmeterAvailable(subjct))
				subjct=AssignmentReport.getParmeterAvailable(subjct);
	     System.out.println(subjct);
	     System.out.println(subjectmail.split(",")[j]);
	     
	   if(subjct.contains(subjectmail.split(",")[j]))
		   flag=true;
	   }
	 Assert.assertTrue( "Message "+mailTile,flag);
	  
		      
	}
	
	@Then("navigate to mailTrap API and validate the notifcation for multiple user {int} {string}")
	public void navigate_to_yopmail_and_validate_the_notifcation_for_uer(int user,String mailTile) 
	{
	for(int i=0;i<User.usrEmail.length;i++)
	{
		User.userEmail=User.usrEmail[i];
	String subjectmail=mail.getmailsubject();
	System.err.println(subjectmail);
	boolean flag=false;
	   
	for(int j=0;j<subjectmail.split(",").length;j++)
	   {
		 String subjct=mail.getupdatedSubjectTitle(mailTile);
			if(AssignmentReport.checkifParmeterAvailable(subjct))
				subjct=AssignmentReport.getParmeterAvailable(subjct);
	     System.out.println(subjct);
	     System.out.println(subjectmail.split(",")[j]);
	     
	   if(subjct.contains(subjectmail.split(",")[j]))
		   flag=true;
	   }
	 Assert.assertTrue( "Message "+mailTile,flag);
	}
		      
	}

	@Then("navigate to mailtrap and validate the email content for course cancellation")
	public void navigate_to_mailtrap_and_validate_the_email_content_for_course_cancellation() {
	    if(mail == null)
	    	mail = new MailTrapAPI();
	    String messageID =  mail.validateMailAsPerSubject("Order cancellation and refund initiated - ");
	    mail.validateEmailContentCourseCancellation(messageID);
	}
	
	@Then("navigate to mailtrap and reset password page")
	public void navigate_to_mailinator_and_reset_password_page() 
	{
		if(mail == null)
	    	mail = new MailTrapAPI();
		String subject = "Forgot Password";
		String messageID = mail.validateMailAsPerSubject(subject);
		String url = mail.getEmailBody(messageID);
		mail.navigateURL(url);
	}
	
	@Then("navigate to mailinator API and validate the email should not contain {string} for subject {string}")
	public void navigate_to_mailinatorAPI_and_validate_the_email_should_not_contain_for_subject(String text, String subject)  throws InterruptedException
	{
		mail.validatemailbodyText(text,subject);
	
	}
	
	@Then("validate the email content for CE report page {string}")
	public void validate_the_email_content_for_ce_report_page(String type) {
		mail = new MailTrapAPI();
		String messageID = mail.validateMailAsPerSubject("RQI for NRP CE report - " + type);
		mail.validateEmailContentCE_Type(messageID);
	}
	
	@Then("click on link to download report {string} from mailtrap")
	public void click_on_link_to_download_report_from_mailtrap(String type) {
		mail = new MailTrapAPI();
		String messageID = mail.validateMailAsPerSubject("RQI for NRP CE report - " + type);
		String url= mail.getLink(messageID);
		mail.navigateURL(url);
		
	}


	@Then("validate the email content for Utilisation report page")
	public void validate_the_email_content_for_Utilisation_report_page() {
		mail = new MailTrapAPI();
//		{org_name}- 01/20/2024 to 01/31/2024
		String messageID = mail.validateMailAsPerSubject("Utilization Report for "+TestBase.prop.getProperty("orgName")+" "+UtilisationReport.dateFrom+" to "+UtilisationReport.dateTo);
		mail.validateEmailContentUtilizationReport(messageID);
	}
	
}
