package stepDefinitions;

import org.junit.Assert;

import com.qa.pages.CourseManagement;
import com.qa.pages.EndUser;
import com.qa.pages.OrganizationHome;
import com.qa.pages.User;
import com.qa.pages.UserManagement;
import io.cucumber.java.en.Then;
import com.qa.util.TestBase;
import com.qa.util.reuseableCode;

import io.cucumber.datatable.DataTable;

public class EndUserSteps 
{
	EndUser end;
	UserManagement usrMg;
	OrganizationHome orgHome;
	@Then("verify homepage displayed for end user")
	public void verify_homepage_displayed_for_end_user() 
	{
	    end = new EndUser();
	    end.verifyHomePage();
	}

	@Then("verify context items availability under page source")
	public void verify_context_items_availability_under_page_source() 
	{
		if(end == null)
			end = new EndUser();
		if(orgHome == null)
			orgHome = new OrganizationHome();
		
	    end.validateContextItems(orgHome.contextId,orgHome.contextLabel,orgHome.contextTitle);
	}
	@Then("Review the completed courses without exit")
	public void review_the_completed_courses_without_exit() 
	{
		if(end == null)
			end = new EndUser();
	    end.clickOnCompletedActivities();
	    end.clickOnCompletedCourseReview();
	}
	@Then("give the date for completed course")
	public void give_the_date_for_completed_course() 
	{
		if(end == null)
			end = new EndUser();
		end.clickOnSubmitOnlyWithDate();
	}
	@Then("validate the date shared for future assignments {int} {string}")
	public void validate_the_date_shared_for_future_assignments(Integer count, String dateType) 
	{
	    end.validateDateShared(count + 1, dateType);
	}
	@Then("validate the row count for future assignments {int}")
	public void validate_the_row_count_for_future_assignments(int expectedRowCount) 
	{
	    end.validateRowCountActiveCourses(expectedRowCount + 1);
	}

	@Then("validate the row count for assignments {int} course name {string}")
	public void validate_the_row_count_fo_assignments(int expectedRowCount,String course) 
	{	if(end == null)
		end = new EndUser();
	
	    end.validateRowCountActiveCourses(expectedRowCount,course);
	}
	
	@Then("validate the row count for assignments {int} current course name {string}")
	public void validate_the_row_count_fo_currnetassignments(int expectedRowCount,String course) throws InterruptedException 
	{	if(end == null)
		end = new EndUser();
	
	    end.validateRowCountCurrentCourses(expectedRowCount,course);
	}
	
	
	@Then("validate the row count for future assignments {int} course name {string}")
	public void validate_the_row_count_for_future_assignments(int expectedRowCount,String course) 
	{
	    end.validateRowCountActiveCourses(expectedRowCount + 1,course);
	}
	@Then("navigate to url for future assignments as per date {int} {string}")
	public void navigate_to_url_for_future_assignments_as_per_date(Integer numCount, String dateType) 
	{
		if(end == null)
			end = new EndUser();
	    end.launchFurtureAssignmentUrl(numCount, dateType);
	}
	@Then("survey the completed courses {string}")
	public void survey_the_completed_courses(String name) 
	{
		if(end == null)
			end = new EndUser();
		if(usrMg == null)
			usrMg = new UserManagement();
		end.launchCourseWithName(name);
		end.clickOnSubmitOnlyWithDate("");
		end.surveyCourse();
	   
	}
	
	@Then("evaluate the course {string}")
	public void evaluate_the_course(String name) 
	{
		if(end == null)
			end = new EndUser();
		if(usrMg == null)
			usrMg = new UserManagement();
		end.launchCourseWithName(name);
		end.clickOnSubmitOnlyWithDate("");
	    end.evaluateCourse();
	
	    
	}

	@Then("evaluate the courses")
	public void evaluate_the_course() 
	{
		if(end == null)
			end = new EndUser();
		if(usrMg == null)
			usrMg = new UserManagement();
	    end.evaluateCourse();
	
	    
	}
	@Then("Validate Message {string} when Evaluation is not completed and trying to Claim CME CE")
	public void Complete_Claim_CME(String msg) 
	{
		if(end == null)
			end = new EndUser();
		if(usrMg == null)
			usrMg = new UserManagement();
			    end.validatemsgClaimCME(msg);
			    end.clickEndUserProgramLink();
	    
	}
	
	@Then("Complete Claim CME")
	public void Complete_Claim_CME() 
	{
		if(end == null)
			end = new EndUser();
		if(usrMg == null)
			usrMg = new UserManagement();
				end.clickOnSubmitOnlyWithDate();
			    end.claimCredit();
			
	    
	}
	
	@Then("navigate to my account page for end user")
	public void navigate_to_my_account_page_for_end_user() 
	{
		if(end == null)
			end = new EndUser();
	    end.clickMyAccount();
	}
	
	@Then("user launch and exit the course")
	public void user_launch_and_exit_the_course() 
	{
	    end.launchCourse();
	    end.startORResumeCourse();
	    end.exitCourse();
	}
	
	@Then("end user logout")
	public void end_user_logout() 
	{
	    end.clickLogOut();
	}
	
	@Then("validate if No programs available is displayed")
	@Then("validate if course is removed")
	public void end_user_logouts() 
	{
		if(end == null)
			end = new EndUser();
	
	    end.nocoursepresent();
	}
	
	
	@Then("validate if No programs available is displayed in Complete Tab")
	public void completeTab() 
	{
		if(end == null)
			end = new EndUser();
	
	    end.nocoursepresntCompleteTab();
	}
	
	@Then("Click on Expired Courses Toggle Button")
	public void click_on_Expire() 
	{
		if(end == null)
			end = new EndUser();
	
	    end.clickOnexpireToggleButton();
	}
	
	
	
	@Then("user click on activate course")
	public void user_click_on_activate_course() 
	{
		if(end == null)
			end = new EndUser();
		usrMg = new UserManagement();
		usrMg.switchTab();
	    end.clickActivate();
	    usrMg.switchTab();
	    usrMg.closeOtherTab();
	}
	
	@Then("click on launch course")
	public void click_on_launch_course() 
	{
		if(end == null)
			end = new EndUser();
		usrMg = new UserManagement();
		usrMg.switchTab();
	    end.launchUserCourse1();
	    end.clickOnSubmitOnly();
	    end.startCourse();
		end.exitCourse();
	    usrMg.switchTab();
	    usrMg.closeOtherTab();
	}
	
	@Then("user launch course")
	public void user_launch_course() 
	{
		if(end == null)
			end = new EndUser();
		usrMg = new UserManagement();
	    usrMg.switchTab();
	    end.launchUserCourse1();
	    end.clickOnSubmitOnly();
		end.startCourse();
		end.exitCourse();
		usrMg.switchTab();
	    usrMg.closeOtherTab();
	}
	
	@Then("validate the course available")
	public void validate_the_course_available() 
	{
		end = new EndUser();
		int count = end.getNumberRows();
		Assert.assertTrue(count >= 1);
	}
	
	@Then("validate the courses available")
	public void validatethe_course_available() 
	{
		if(end == null)
			end = new EndUser();
		boolean flag = end.validateCourseAvailable();
		Assert.assertTrue(flag);
	}
	
	@Then("user launch course and validate the course available")
	public void user_launch_course_and_validate_the_course_available() 
	{
		if(end == null)
			end = new EndUser();
		usrMg = new UserManagement();
	    usrMg.switchTab();
	    end.launchUserCourse1();
	    end.clickOnSubmitOnly();
	    int count = end.getNumberRows();
		Assert.assertTrue(count >= 1);
		usrMg.switchTab();
	    usrMg.closeOtherTab();
	}
	
	@Then("navigate to complete programs and review the given course {string}")
	public void navigate_to_complete_programs_and_review_the_given_course(String course) 
	{
		if(end == null)
			end = new EndUser();
		if(usrMg == null)
			usrMg = new UserManagement();
		end.navigateCompletedPrograms();
		end.clickOnCompletedCourseReviews(course);
	}
	
	
	
	@Then("give the date for completed course {string}")
	public void give_the_date_for_completed_course(String date) 
	{
		if(end == null)
			end = new EndUser();
		
		end.clickOnSubmitOnlyWithDate(date);
	}
	
	@Then("give the date for completed course {int}")
	public void give_the_date_for_completed_course(int q) 
	{
		if(end == null)
			end = new EndUser();
		String date=end.changeDate(q);
		end.clickOnSubmitOnlyWithDate(date);
	}

	@Then("Review the completed courses")
	public void review_the_completed_courses() 
	{
		if(end == null)
			end = new EndUser();
	    end.clickOnCompletedActivities();
	    end.clickOnCompletedCourseReview();
	    end.onlyExitCourse();
	}
	@Then("Click on Completed and Expired program Tab")
	public void click_on_completed_and_expired_program_tab() 
	{
		if(end == null)
			end = new EndUser();
	    end.navigateCompletedPrograms();
	   
	}
	@Then("validate the error message for course launch")
	public void validate_the_error_message_for_course_launch() 
	{
		if(end == null)
			end = new EndUser();
		end.validateCourseLaunchError();
	}
	
	@Then("validate the error message for given course launch {string} with date {string}")
	public void validate_the_error_message_for_given_course_launch_with_date(String names, String courseDate) 
	{
		if(end == null)
			end = new EndUser();
		String name[] = names.split(",");
	    for(int i = 0; i <= name.length-1; i++)
	    {
	    	end.launchCourseWithName(name[i]);
		    end.clickOnSubmitOnlyWithDate(courseDate);
		    end.validateCourseLaunchError();
		    end.clickEndUserProgramLink();
	    }
	}
	@Then("just launch the course {string} and submit the date as per quarter date {int}")
	public void just_launch_the_course_and_submit_the_date_as_per_quarter_date(String names, int quarter) {
		if(end == null)
			end = new EndUser();
			if(usrMg == null)
				usrMg= new UserManagement();

			String name[] = names.split(",");
			for(int i = 0; i <= name.length-1; i++)
			{
			String date = end.changeDate(quarter);
			end.runScriptForPastDate(date);
			boolean flag = end.launchCourseWithName(name[i]);
			System.out.println(flag);
			if(flag == true)
			{
			end.clickOnSubmitOnlyWithDate(date);
			System.out.println(date);
			}
	}
	}
	@Then("Select {string} within APP CM_CE popup")
	public void select_within_app_cm_ce_popup(String string) {
		if(end == null)
			end = new EndUser();
		end.jobtitleselectionwithinCM_CEpopup(string);
	}

	@Then("Select {string} within APP CM_CE edit popup")
	public void select_within_app_cm_ce_edit_popup(String string) throws Exception {
		if(end == null)
			end = new EndUser();
		end.jobtitleselectionwithinCM_CEpopupfromedit(string);
	}

	@Then("Enter the details as below")
	public void enter_the_details_as_below(DataTable dataTable) throws Exception {
		if(end == null)
			end = new EndUser();
		reuseableCode.waitforsec(1);
		for(int j=0;j<dataTable.height();j++)
		{
		dataTable.column(0).get(j);
		TestBase.dataMap.put(dataTable.column(0).get(j),dataTable.column(1).get(j));
		}
		end.validatetabledatawithinCM_CEpopup();

	}

	@Then("Click on submit within CM_CE pop up")
	public void click_on_submit_within_cm_ce_pop_up() throws InterruptedException {
		if(end == null)
			end = new EndUser();
		end.cecmepopupsubmit();
		String date = end.changeDate(0);
		end.runScriptForPastDate(date);
		end.clickOnSubmitOnlyWithDate(date);
		Thread.sleep(5000);
	}

	@Then("verify the view link is displayed in the launch program page")
	public void verify_the_view_link_is_displayed_in_the_launch_program_page() {
		if(end == null)
			end = new EndUser();
		end.verifyviewprofileispresent();
	}
	@Then("Click on the view CE details link in the launch program page")
	public void click_on_the_view_ce_details_link_in_the_launch_program_page() throws InterruptedException {
		if(end == null)
			end = new EndUser();
		end.clickonviewCElink();
	}
	//@Then("verify the details displaying are same as entered values")
	//public void verify_the_details_displaying_are_same_as_entered_values(DataTable table) {
//		if(end == null)
//			end = new EndUser();
//		 for(int j=0;j<table.height();j++)
//			 end.validate_Viewdetails_CMCE(table.column(0).get(j),table.column(1).get(j));
	//}

	@Then("verify the details displaying are same as entered values")
	public void verify_the_details_displaying_are_same_as_entered_values(DataTable table) throws Exception {
		if(end == null)
			end = new EndUser();
		 for(int j=0;j<table.height();j++)
			 end.validate_Viewdetails_CMCE(table.column(0).get(j),table.column(1).get(j));
	}
	@Then("verify the details displaying are same as entered values from myprograms page")
	public void verify_the_details_displaying_are_same_as_entered_values_from_myprograms_page(DataTable dataTable) throws Exception {
		reuseableCode.waitforsec(1);
		for(int j=0;j<dataTable.height();j++)
		{
		dataTable.column(0).get(j);
		TestBase.dataMap.put(dataTable.column(0).get(j),dataTable.column(1).get(j));
		}
		end.validate_Viewdetails_CMCE1();
	}
	@Then("Click on edit button within the pop up")
	public void click_on_edit_button_within_the_pop_up() throws InterruptedException {
		if(end == null)
			end = new EndUser();
		end.clickonsubmitbutton();
	}

	@Then("clear all mandatory fields with data as input")
	public void clear_all_mandatory_fields_with_data_as_input() throws Exception {
		if(end == null)
			end = new EndUser();
		end.clearallmandatoryfields();
	}

	@Then("verify the following error messages are displayed {string}")
	public void verify_the_following_error_messages_are_displayed(String string) {

		if(end == null)
			end = new EndUser();
		String errormessages[] = string.split(",");
		for(int i = 0; i <= errormessages.length-1; i++)
		{
			end.Validatetheerrormessage(errormessages[i]);
		}
	}
	@Then("close the AAP Cm CE pop up")
	public void close_the_aap_cm_ce_pop_up() throws Exception {
		if(end == null)
			end = new EndUser();
		end.closeAPP_cecmepopup();
	}

	@Then("Navigate to My programs page")
	public void navigate_to_my_programs_page() {
		if(end == null)
			end = new EndUser();
			    end.clickEndUserProgramLink();
	}
	@Then("Click on NRP CE profile link within my programs page")
	public void click_on_nrp_ce_profile_link_within_my_programs_page() throws Exception {
		if(end == null)
			end = new EndUser();
			    end.clickNRPCElink_Myprograms();
	}

	@Then("complete the course after AAP_CE entering profile details {string}")
	public void complete_the_course_after_aap_ce_entering_profile_details(String names) {
		{
			if(end == null)
			end = new EndUser();
			if(usrMg == null)
				usrMg= new UserManagement();		
			String name[] = names.split(",");
			for(int i = 0; i <= name.length-1; i++)
			{
			int count = end.getNumberRows();
			System.out.println("count is " + count);
			for(int j =1; j <= count; j++)
			{
			end.startORResumeCourse();
			end.completeCourseTestCode();
			end.onlyExitCourse();

			}
			end.cecmepopupforsub();
			  end.clickEndUserProgramLink();
			}

			}
	}
	@Then("launch course and complete only {int} topics and exit {string}")
	public void launch_course_and_complete_only_topics_and_exit(Integer int1, String string) {
		{
			if(end == null)
			end = new EndUser();
			if(usrMg == null)
				usrMg= new UserManagement();		
			int count = end.getNumberRows();
			System.out.println("count is " + count);
			for(int j =1; j <= int1; j++)
			{
			end.startORResumeCourse();
			end.completeCourseTestCode();
			end.onlyExitCourse();
			}

			}
	}
	@Then("click on  kebab icon within the completed and expired programs")
	public void click_on_kebab_icon_within_the_completed_and_expired_programs() throws InterruptedException {
		if(end == null)
			end = new EndUser();
			    end.clickonkebabicon_completedprograms();
	}
	@Then("verify that NRP CE profile link is displayed")
	public void verify_that_nrp_ce_profile_link_is_displayed() throws InterruptedException {
		if(end == null)
			end = new EndUser();
			    end.VerifyNRP_CEprofilelink();
	}

	@Then("click on the NRP CE profile from kebab icon")
	public void click_on_the_nrp_ce_profile_from_kebab_icon() throws InterruptedException {
		if(end == null)
			end = new EndUser();
			    end.clickNRP_CEprofilekebab();
	}
	

@Then("navigate to reference page for end user")
	public void navigate_to_reference_page_for_end_user() 
	{
	    end.clickReferenceLibrary();
	}
	
	@Then("navigate to my program page for end user")
	public void navigate_to_my_program_page_for_end_user() 
	{
	    end.clickMyProgram();
	}
	
}
