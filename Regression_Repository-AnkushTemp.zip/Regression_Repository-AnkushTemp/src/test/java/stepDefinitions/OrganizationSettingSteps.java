package stepDefinitions;

import org.junit.Assert;

import com.qa.pages.IltReports;
import com.qa.pages.OrganizationHome;
import com.qa.pages.OrganizationSetting;
import com.qa.pages.OrganizationSettings;
import com.qa.pages.Student;
import com.qa.pages.User;
import com.qa.util.TestBase;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;

public class OrganizationSettingSteps {

	OrganizationHome orgHome;
	OrganizationSetting orgSet;
	User user;
	Student st;
	IltReports iltReport;

	/*
	 * @Then("create level unit") public void create_level_unit() { if(orgHome ==
	 * null) orgHome = new OrganizationHome(); orgSet = new OrganizationSetting();
	 * orgSet.navigateLevel2(); orgSet.deleteAutomatedUnit();
	 * orgSet.clickOnCreateLevelButton();
	 * orgSet.enterLevelDetails("187 s washington st", "Tiffin", "United States",
	 * "Ohio", "44883"); orgSet.clickCreateUnit(); orgHome.validateSucessMesssage();
	 * }
	 */

	@Then("create level unit with message {string}")
	public void create_level_unit_with_message(String message) 
	{
		if(orgHome == null)
			orgHome = new OrganizationHome();
		orgSet = new OrganizationSetting();
		orgSet.navigateLevel2();
		orgSet.deleteAutomatedUnit();
		orgSet.clickOnCreateLevelButton();
		orgSet.enterLevelDetails("187 s washington st", "Tiffin", "United States", "Ohio", "44883");
		orgSet.clickCreateUnit();
		orgHome.validateSucessMesssage(message);
	}

	/*
	 * @Then("edit the unit") public void edit_the_unit() { if (orgSet == null)
	 * orgSet = new OrganizationSetting(); if (orgHome == null) orgHome = new
	 * OrganizationHome(); orgSet.navigateLevel2(); orgSet.clickActionButton();
	 * orgSet.clickEditButton(); orgSet.editUnitDetails(); orgSet.clickCreateUnit();
	 * orgHome.validateSucessMesssage("Level 2 has been updated successfully"); }
	 */
	/*
	 * @Then("view unit details") public void view_unit_details() { if (orgSet ==
	 * null) orgSet = new OrganizationSetting(); orgSet.viewAutomatedUnit(); }
	 */

	/*
	 * @Then("add the already available learner as unit admin") public void
	 * add_the_already_available_learner_as_unit_admin() { if (orgHome == null)
	 * orgHome = new OrganizationHome(); orgSet.clickOnUnitAdminButton(); if
	 * (User.userEmail != null) orgSet.searchAvailableUser(User.userEmail); else
	 * orgSet.searchAvailableUser(Student.email); orgSet.selectAvailableUser();
	 * orgSet.clickAddUnitAdmin(); orgSet.checkRowAvailable();
	 * orgHome.validateSucessMesssage(); }
	 */

	/*
	 * @Then("add the new learner as unit admin") public void
	 * add_the_new_learner_as_unit_admin() { orgSet.clickOnUnitAdminButton();
	 * orgSet.addLearnerDetailsManually(); orgSet.clickAddUnitAdminManually();
	 * orgSet.checkRowAvailable(); orgHome.validateSucessMesssage(); }
	 */

	/*
	 * @Then("add the new learner as unit observer") public void
	 * add_the_new_learner_as_unit_observer() { orgSet.clickOnUnitObserverButton();
	 * orgSet.addLearnerDetailsManually(); orgSet.clickAddUnitObserverManually();
	 * orgSet.checkRowAvailable(); orgHome.validateSucessMesssage(); }
	 */
	
	@Then("Delete an unit")
	public void delete_an_unit() {
		orgSet = new OrganizationSetting();
//		 orgSet.viewAutomatedUnit();
		orgSet.deleteAutomatedUnit();

	}

	@Then("Delete an unit and validate the message {string}")
	public void delete_an_unit(String msg) {
		orgSet = new OrganizationSetting();
		// orgSet.viewAutomatedUnit();
		orgSet.deleteAutomatedUnit();

	}

////////////////////////////////////////////////////// JOB TITLE //////////////////////////////////////////////////

	/*
	 * @Then("click on Title tab") public void click_on_title_tab() { orgSet = new
	 * OrganizationSetting(); orgSet.navigateTitle(); }
	 */

	/*
	 * @Then("User create the Title") public void user_create_the_title() { orgHome
	 * = new OrganizationHome(); orgSet.clickOnCreateTitle();
	 * orgSet.enterTitleDetails(); orgSet.clickOnCreateButton();
	 * orgHome.validateSucessMesssage(); }
	 */

	/*
	 * @Then("User search the Title") public void user_search_the_title() {
	 * orgSet.searchTitleName(); orgSet.validateSearchTitleResult(); }
	 */
	/*
	 * @Then("User edit the Title") public void user_edit_the_title() {
	 * orgSet.clickOnEditTitle(); orgSet.enterUpdatedTitleDetails();
	 * orgSet.clickOnSaveButton(); orgHome.validateSucessMesssage(); }
	 */

	@Then("click on Create Organization")
	public void click_on_create_organization() {
		orgSet = new OrganizationSetting();
		orgSet.clickCreateOrganization();
	}

	@Then("validate {string} field is not showing for CTC org")
	public void verify_fields_is_not_showing_for_ctc_org(String value) {
		orgSet = new OrganizationSetting();
		orgSet.verifylmsinfoForCtcOrg(value);
	}

	@Then("Click on Job Titles")
	public void click_on_job_titles() {
		orgSet = new OrganizationSetting();
		orgSet.navigateTitle();
	}

	@Then("Click on Create Job title")
	public void click_on_create_job_title() {
		orgSet = new OrganizationSetting();
		orgHome = new OrganizationHome();
		orgSet.clickOnCreateTitle();
		orgSet.enterTitleDetails();
		orgSet.clickOnCreateButton();
		orgHome.validateSucessMesssage();
	}

	@Then("view the job title")
	public void view_the_job() {
		orgSet = new OrganizationSetting();
		orgSet.clickOnViewJob();
		orgSet.validateJob();

	}

	@Then("Verify demographic settings tab availability")
	public void verify_demographic_settings_tab_availability() {
		orgSet = new OrganizationSetting();
		orgSet.validateDemographicSettings();
	}
	
	////////////////////////////////// TECHNICAL CONTACTS /////////////////////////////////////////////

	@Then("Click on Technical Contacts with message {string}")
	public void click_on_technical_contacts_with_message(String message) {
		orgSet = new OrganizationSetting();
		orgSet.AddTechnicalContacts();
	//	orgSet.validateSucessMesssage(TestBase.parameters.getProperty(message)); //Technical_Contact_Success_Message
		orgSet.validateSucessMesssage(message); 
	}

	@Then("Click on Edit and update the technical contacts with message {string}")
	public void click_on_edit_and_update_the_technical_contacts_with_message(String message) {
		orgSet = new OrganizationSetting();
		orgSet.EditTechnicalContacts();
	//	orgSet.validateUpdateSucessMesssage(TestBase.parameters.getProperty(message)); // 
		orgSet.validateUpdateSucessMesssage(message);
	}

	@Then("Delete the technical contacts with message {string}")
	public void delete_the_technical_contacts(String message) {
		orgSet = new OrganizationSetting();
		orgSet.deleteTechnicalContacts();
		orgSet.validateDeleteSucessMesssage(message);
	}

	


	///////////////////////////////////////////// GROUP
	///////////////////////////////////////////// ////////////////////////////////////////////////////

	/*
	 * @Then("click on Group tab") public void click_on_group_tab() { orgSet = new
	 * OrganizationSetting(); orgSet.navigateGroup(); }
	 */

	/*
	 * @Then("User create the group") public void user_create_the_group() { if
	 * (orgHome == null) orgHome = new OrganizationHome();
	 * orgSet.clickOnCreateGroup(); orgSet.enterGroupDetails();
	 * orgSet.clickOnCreate(); orgHome.validateSucessMesssage(); }
	 */

	/*
	 * @Then("User search the group") public void user_search_the_group() {
	 * orgSet.searchGroupName(); orgSet.validateSearchResult(); }
	 */

	/*
	 * @Then("User edit the group") public void user_edit_the_group() {
	 * orgSet.clickOnEditGroup(); orgSet.enterUpdatedGroupDetails();
	 * orgSet.clickOnCreate(); orgHome.validateSucessMesssage(); }
	 */

	/*
	 * @Then("Add User to group") public void Adduser_edit_the_group() {
	 * orgSet.clickOnEditGroup(); orgSet.addusergroup(User.userEmail);
	 * orgSet.clickOnCreate(); orgHome.validateSucessMesssage(); }
	 */

	/*
	 * @Then("view the group") public void view_the_group() {
	 * orgSet.clickOnViewGroup(); orgSet.validateGroup(); }
	 */

	/*
	 * @Then("User create another group") public void user_create_another_group() {
	 * if (orgHome == null) orgHome = new OrganizationHome();
	 * orgSet.clickOnCreateGroup(); orgSet.enterOtherGroupDetails();
	 * orgSet.clickOnCreate(); orgHome.validateSucessMesssage(); }
	 */

	/*
	 * @Then("User search another group") public void user_search_another_group() {
	 * orgSet.searchOtherGroupName(); orgSet.validateAnotherSearchResult(); }
	 */

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/*
	 * @Then("view unit details {string} and validate the edited details") public
	 * void view_unit_details(String level) { orgSet.viewAutomatedUnit(); // need to
	 * compare the updated details // orgSet.validateUnitDetai }
	 */
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	@Then("click on Purchase History")
	public void click_on_purchase_history() {
		orgSet = new OrganizationSetting();
		orgSet.clickOnPurchaseHistory();
	}
	
	@Then("click on Export to CSV")
	public void click_on_export_to_csv() throws Exception {
		orgSet = new OrganizationSetting();
		orgSet.clickExportToCsv();
	}
	
	@Then("click on Export to excel")
	public void click_on_export_to_excel() throws Exception {
		orgSet = new OrganizationSetting();
		orgSet.clickExportToExcel();
	}
	
	@Then("click on Export to PDF")
	public void click_on_export_to_pdf() throws Exception {
		orgSet = new OrganizationSetting();
		orgSet.clickExportToPdf();
	}
	
	
	@Then("upload the report for failure validations")
	public void upload_the_report_for_failure_validations() 
	{
	  orgSet = new OrganizationSetting();
      orgSet.uploadFileForFailureValidations();
	}
	
	
	@Then("click on manage students")
	public void click_on_manage_students() {
		st = new Student();
		st.navigateToStudentTab();
	}
	
	@Then("click on demographic report")
	public void click_on_demographic_report() {
		orgSet = new OrganizationSetting();
		orgSet.clickDemographicReport();
	}
	

	
	@Then("enter start and end date and click on search and clear search")
	public void enterStartAndEndDateToSearch() {
		orgSet = new OrganizationSetting();
		orgSet.validateDemographicReportSearch();
		orgSet.clearSearchFilter();
	}

	@Then("click on demographic settings")
	public void click_on_demographic_settings() {
		orgSet = new OrganizationSetting();
		orgSet.clickDemographicSettings();
	}
	
	@Then("verify org admin can change the selection to Full Feed Large File Processing option and save with message {string}")
	public void verify_org_admin_can_change_the_selection_to_full_feed_large_file_processing_option(String message) {
		orgSet = new OrganizationSetting();
		orgSet.clickDemographicSettings();
		orgSet.saveDemographicSettingsWithFullFeed();
		orgSet.saveDemographicSettings(message);
		//orgSet.saveDemographicSettings(TestBase.parameters.getProperty(message));
	}

	@Then("get the unit count from organization setting page")
	public void get_the_unit_count_from_organization_setting_page() {
	    if(orgSet == null)
	    	orgSet = new OrganizationSetting();
	    orgSet.getUnitCount();
	}
//////////////////////////////////////////////////////////P2 Cases ////////////////////////////////////////

@Then("create level other unit with message {string}")
public void create_level_other_unit_with_message(String message) 
{
if(orgHome == null)
orgHome = new OrganizationHome();
orgSet = new OrganizationSetting();
orgSet.navigateLevel2();
orgSet.clickOnCreateLevelButton();
orgSet.enterAnotherLevelDetails("187 s washington st", "Tiffin", "United States", "Ohio", "44883");
orgSet.clickCreateUnit();
orgHome.validateSucessMesssage(message);
}


@Then("create level other unit")
public void create_level_other_unit_with_message() 
{
if(orgHome == null)
orgHome = new OrganizationHome();
orgSet = new OrganizationSetting();
orgSet.navigateLevel2();
orgSet.clickOnCreateLevelButton();
orgSet.enterAnotherLevelDetails("187 s washington st", "Tiffin", "United States", "Ohio", "44883");
orgSet.clickCreateUnit();
}
@Then("get the group count from organization setting page")
public void get_the_group_count_from_organization_setting_page() {
    if(orgSet == null)
    	orgSet = new OrganizationSetting();
    orgSet.getGroupCount();
}

@Then("get the user count for group from organization setting page")
public void get_the_user_count_from_group_organization_setting_page() {
    if(orgSet == null)
    	orgSet = new OrganizationSetting();
    orgSet.getMemberCount();
}

@Then("validate the user count from organization setting page {int}")
public void validate_the_user_count_from_group_organization_setting_page(int count) {
    if(orgSet == null)
    	orgSet = new OrganizationSetting();
    Assert.assertTrue(OrganizationSettings.memberCount == count);
}


@Then("create unit on next level with message {string}")
public void create_unit_on_next_level_with_message(String message) 
{
	if(orgHome == null)
		orgHome = new OrganizationHome();
	orgSet = new OrganizationSetting();
    orgSet.navigateLevel3();
    orgSet.deleteAutomatedUnit();
    orgSet.clickOnCreateLevelButton();
    orgSet.enterLevelDetailsWithUnits("187 s washington st", "Tiffin", "United States", "Ohio", "44883", 3);
    orgSet.clickCreateUnit();
    orgHome.validateSucessMesssage(message);
}


@Then("get level with unit name for unit admin")
public void get_level_with_unit_name_for_unit_admin() {
    if(orgSet== null)
    	orgSet = new OrganizationSetting();
	orgSet.getLevelAndUnitNamesForUnitAdmin();
}
	
@Then("get level with unit name")
public void get_level_with_unit_name() {
    if(orgSet== null)
    	orgSet = new OrganizationSetting();
	orgSet.getLevelAndUnitNames();
}

}
