package com.qa.pages;

import org.testng.annotations.Test;

import stepDefinitions.LoginSteps;

public class NewTest {
  @Test
  public void f() {
	  LoginSteps login=new LoginSteps();
	  login.browser_is_launched_or_Using();
  }
}
