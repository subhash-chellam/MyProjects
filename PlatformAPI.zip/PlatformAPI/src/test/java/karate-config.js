function fn() {
GExecutionId= "";
  var config = {
	GExecutionId:"SomeValue",
    testEndPoint : 'http://172.19.211.237:8080/atoms',
    AuthURL :'http://172.19.211.237:8080/atoms/oauth2/token'
  }
  karate.configure('connectTimeout', 5000);
  karate.configure('readTimeout', 5000);
  return config;
}