function waitUntil(arg){
	console.log("From Function");
	while (true) {
		console.log(arg.eid);
		var result = karate.call("AppStatusValidation.feature", arg);
		var greeting = result.response;
	    karate.log('poll response', greeting); 
	    console.log("From Function");
	    if (greeting.status != "RUNNING") {
	    	karate.log('condition satisfied, exiting');
	        return;
	        }
	        karate.log('sleeping');
	        java.lang.Thread.sleep(10000);
	   }
}