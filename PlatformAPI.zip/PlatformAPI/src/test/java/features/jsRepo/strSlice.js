 
 function strSlice(args){
	console.log('Count =',args.length)
	let str = args.substr(args.length - 36, 36)
	console.log (str)
	return str
}