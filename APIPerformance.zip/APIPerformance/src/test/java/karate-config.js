function fn() {
 
  var config = {
		GExecutionId: "LaerdalAPITest",
		testEndPoint: 'https://stg-rqi1stop.laerdalblr.in/v1/api/',
		AuthURL: 'https://stg-rqi1stop.laerdalblr.in/v1/api/tokens'
  }

  return config;
}